(window.webpackJsonp = window.webpackJsonp || []).push([
    [19], {
        ALeE: function(e, t, a) {
            "use strict";
            a.r(t), a.d(t, "setMaxStake", (function() {
                return i
            })), a.d(t, "getRandomFromArray", (function() {
                return c
            })), a.d(t, "setPhase", (function() {
                return f
            })), a.d(t, "setCompetitionType", (function() {
                return C
            })), a.d(t, "setMaxCombiGroup", (function() {
                return p
            })), a.d(t, "setParticipantsLength", (function() {
                return g
            })), a.d(t, "parser", (function() {
                return H
            }));
            var n, s, r, o, u = a("1hBs"),
                d = a("mv+f"),
                h = a("fnUq"),
                i = d.setMaxStake,
                c = d.getRandomFromArray,
                f = function(e) {
                    r = e
                },
                C = function(e) {
                    o = e
                };

            function m() {
                return !!r
            }

            function Q() {
                return r
            }

            function l() {
                return o
            }

            function y() {
                return Q() === u.model.ChEventBlockData.PhaseEnum.GROUPS
            }
            var k = ((n = {})[u.model.ChEventBlockData.PhaseEnum.Q8] = {
                q: u.ChMarkets.Qualify,
                s: u.ChMarkets.Qualify_2,
                f: u.ChMarkets.Qualify_3,
                c: u.ChMarkets.Qualify_4
            }, n[u.model.ChEventBlockData.PhaseEnum.Q4] = {
                s: u.ChMarkets.Qualify,
                f: u.ChMarkets.Qualify_2,
                c: u.ChMarkets.Qualify_3
            }, n[u.model.ChEventBlockData.PhaseEnum.SEMIFINAL] = {
                f: u.ChMarkets.Qualify,
                c: u.ChMarkets.Qualify_2
            }, n[u.model.ChEventBlockData.PhaseEnum.FINAL] = {
                c: u.ChMarkets.Qualify
            }, n);

            function O() {
                return Object.keys(k[Q()])
            }

            function E(e) {
                return k[Q()][e]
            }
            var A = ((s = {})[u.model.ChEventBlockData.PhaseEnum.Q8] = {
                1: {
                    q: u.ChOdds.QHome,
                    s: u.ChOdds.QHome_2,
                    f: u.ChOdds.QHome_3,
                    c: u.ChOdds.QHome_4
                },
                2: {
                    q: u.ChOdds.QAway,
                    s: u.ChOdds.QAway_2,
                    f: u.ChOdds.QAway_3,
                    c: u.ChOdds.QAway_4
                }
            }, s[u.model.ChEventBlockData.PhaseEnum.Q4] = {
                1: {
                    s: u.ChOdds.QHome,
                    f: u.ChOdds.QHome_2,
                    c: u.ChOdds.QHome_3
                },
                2: {
                    s: u.ChOdds.QAway,
                    f: u.ChOdds.QAway_2,
                    c: u.ChOdds.QAway_3
                }
            }, s[u.model.ChEventBlockData.PhaseEnum.SEMIFINAL] = {
                1: {
                    f: u.ChOdds.QHome,
                    c: u.ChOdds.QHome_2
                },
                2: {
                    f: u.ChOdds.QAway,
                    c: u.ChOdds.QAway_2
                }
            }, s[u.model.ChEventBlockData.PhaseEnum.FINAL] = {
                1: {
                    c: u.ChOdds.QHome
                },
                2: {
                    c: u.ChOdds.QAway
                }
            }, s);

            function M(e, t) {
                return A[Q()][e][t]
            }

            function v(e) {
                return O().includes(e)
            }
            var _ = 0;

            function p(e) {
                _ = e
            }

            function w() {
                return _
            }
            var P = 0;

            function g(e) {
                P = e
            }

            function B() {
                return P
            }
            var H = {
                parse: function(e) {
                    return h.parse(e, {
                        getRandomFromArray: c,
                        hasPhase: m,
                        isQualifyAvailable: v,
                        isGroupsPhase: y,
                        getPhase: Q,
                        getCompetitionType: l,
                        getQualifyOddId: M,
                        getAvailablesRounds: O,
                        getQualifyMarket: E,
                        getMaxCombiGroup: w,
                        getParticipantsLength: B,
                        getMaxStake: d.getMaxStake
                    })
                }
            }
        }
    }
]);