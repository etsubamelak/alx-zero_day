(window.webpackJsonp = window.webpackJsonp || []).push([
    [25], {
        V5Ma: function(l, n, u) {
            "use strict";
            u.r(n), u.d(n, "RacesModuleNgFactory", (function() {
                return kn
            }));
            var t = u("CcnG"),
                e = function() {},
                c = u("pMnS"),
                r = u("qIYQ"),
                a = u("2z2z"),
                s = u("mYlp"),
                i = u("E6sH"),
                o = u("1UiX"),
                b = u("cS+c"),
                d = u("Md+g"),
                p = u("eZM8"),
                h = u("fHz3"),
                f = u("iGSx"),
                _ = u("l+fh"),
                k = u("t01L"),
                m = function() {
                    function l(l) {
                        this.coreService = l
                    }
                    return l.prototype.ngOnInit = function() {
                        this.game = this.gameType.toLowerCase(), this.getRaceSilk(), this.widthSize = this.width + "px", this.heightSize = this.height + "px"
                    }, l.prototype.ngOnChanges = function(l) {
                        l.raceSilk && !l.raceSilk.isFirstChange() && this.getRaceSilk()
                    }, l.prototype.getRaceSilk = function() {
                        this.raceSilkSrc = this.coreService.getAssetsController().getRacesGameAssetsManager().getSilk(this.gameType, this.raceSilk)
                    }, l
                }(),
                g = [
                    [".race-silk[_ngcontent-%COMP%]{display:inline-block;width:100%;height:100%;font-size:24px;font-weight:700;text-align:center}.race-silk__img[_ngcontent-%COMP%]{width:100%;height:100%}"]
                ],
                I = t.Gb({
                    encapsulation: 0,
                    styles: g,
                    data: {}
                });

            function U(l) {
                return t.ec(2, [(l()(), t.Ib(0, 0, null, null, 1, "div", [
                    ["class", "grid grid-middle grid-center race-silk"]
                ], null, null, null, null, null)), (l()(), t.Ib(1, 0, null, null, 0, "img", [
                    ["class", "race-silk__img"]
                ], [
                    [8, "src", 4],
                    [8, "width", 0],
                    [8, "height", 0]
                ], null, null, null, null))], null, (function(l, n) {
                    var u = n.component;
                    l(n, 1, 0, u.raceSilkSrc, u.width, u.height)
                }))
            }
            t.Eb("grv-races-race-silk", m, (function(l) {
                return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 1, "grv-races-race-silk", [], [
                    [4, "width", null],
                    [4, "height", null]
                ], null, null, U, I)), t.Hb(1, 638976, null, 0, m, [k.a], null, null)], (function(l, n) {
                    l(n, 1, 0)
                }), (function(l, n) {
                    l(n, 0, 0, t.Ub(n, 1).widthSize, t.Ub(n, 1).heightSize)
                }))
            }), {
                gameType: "gameType",
                raceSilk: "raceSilk",
                width: "width",
                height: "height"
            }, {}, []);
            var W = u("5EE+"),
                v = u("Ip0R"),
                y = function() {
                    function l() {}
                    return l.prototype.transform = function(l) {
                        return l.split(" ")
                    }, l
                }(),
                w = u("CrY/"),
                M = function() {
                    function l() {
                        this.isActive = !1, this.isDisabled = !1, this.participantClick = new t.q, this.gameValue = w.coreModel.GameType.ValEnum, this.names = [], this.isNumber = !1
                    }
                    return l.prototype.ngOnInit = function() {
                        this.isNumber = !isNaN(Number(this.dorsal)), this.trotting = this.gameType && this.gameType.toUpperCase() === w.coreModel.GameType.ValEnum.TROTTING, this.dogRaces = this.gameType && this.gameType.toUpperCase() === w.coreModel.GameType.ValEnum.DOG, this.raceParticipantTemplate = this.gameType && (this.gameType.toUpperCase() === w.coreModel.GameType.ValEnum.MOTORBIKE || this.gameType.toUpperCase() === w.coreModel.GameType.ValEnum.KART), this.names = this.getNames(), this.dogRaces && (this.dogId = this.getDogId())
                    }, l.prototype.ngOnChanges = function(l) {
                        (l.gameType && !l.gameType.isFirstChange() || l.isActive) && this.setRacesOddClass(), l.participant && (this.name = this.getName())
                    }, l.prototype.onClick = function() {
                        this.isDisabled || this.participantClick.emit()
                    }, l.prototype.isDisabledToBet = function() {
                        return this.odd && this.odd._clData && (this.isDisabled = parseFloat(this.odd.value) <= 1.01), this.isDisabled
                    }, l.prototype.setRacesOddClass = function() {
                        this.isActive ? this.racesOddClass = this.gameType ? "participant--" + this.gameType + " participant--" + this.gameType + "-" + this.dorsal : "participant__extra-market participant__extra-market--selected" : this.racesOddClass = this.gameType ? "" : "participant__extra-market"
                    }, l.prototype.getName = function() {
                        return this.participant.name
                    }, l.prototype.getNames = function() {
                        if (this.participant && (this.participant.isMotorbikeParticipant() || this.participant.isKartParticipant())) return [this.participant.name]
                    }, l.prototype.getDogId = function() {
                        return "dog_" + this.participant.id
                    }, l
                }(),
                j = [
                    [".participant[_ngcontent-%COMP%]{height:100%;cursor:pointer}.participant--disabled[_ngcontent-%COMP%]{cursor:default}.participant__dorsal[_ngcontent-%COMP%]{position:relative;font-size:32px;font-weight:700;border-radius:2px;padding:6px 0}.participant__name[_ngcontent-%COMP%]{font-size:14px;font-weight:700;text-transform:uppercase;text-align:center;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;width:78px}.participant__value[_ngcontent-%COMP%]{padding:4px 4px 3px;margin-top:10px;font-size:18px;font-weight:400;text-align:center;border-radius:2px}.participant__value--disabled[_ngcontent-%COMP%]{border:0}.participant__extra-market[_ngcontent-%COMP%]{font-size:22px;font-weight:700;text-transform:capitalize}.participant__extra-market--selected[_ngcontent-%COMP%]{opacity:1}.participant--dog-6[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{padding:0 14px;border-radius:50%}.grid-end[_ngcontent-%COMP%]{justify-content:flex-end}.number-trotting[_ngcontent-%COMP%]{width:25.8px;height:19.5px;font-size:16px;line-height:50px;text-align:left}"]
                ],
                S = t.Gb({
                    encapsulation: 0,
                    styles: j,
                    data: {}
                });

            function x(l) {
                return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 1, "grv-races-race-silk", [
                    ["class", "silk-vertical-list"]
                ], [
                    [4, "width", null],
                    [4, "height", null]
                ], null, null, U, I)), t.Hb(1, 638976, null, 0, m, [k.a], {
                    gameType: [0, "gameType"],
                    raceSilk: [1, "raceSilk"],
                    width: [2, "width"],
                    height: [3, "height"]
                }, null)], (function(l, n) {
                    var u = n.component;
                    l(n, 1, 0, u.gameType, u.dorsal, 46, 46)
                }), (function(l, n) {
                    l(n, 0, 0, t.Ub(n, 1).widthSize, t.Ub(n, 1).heightSize)
                }))
            }

            function C(l) {
                return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 1, "span", [], [
                    [2, "number-trotting", null]
                ], null, null, null, null)), (l()(), t.cc(1, null, ["", ""]))], null, (function(l, n) {
                    var u = n.component;
                    l(n, 0, 0, u.trotting), l(n, 1, 0, u.dorsal)
                }))
            }

            function O(l) {
                return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 2, "span", [], null, null, null, null, null)), (l()(), t.cc(1, null, ["", ""])), t.Wb(131072, W.r, [W.k, t.i])], null, (function(l, n) {
                    var u = n.component;
                    l(n, 1, 0, t.dc(n, 1, 0, t.Ub(n, 2).transform(u.dorsal, "DOG")))
                }))
            }

            function P(l) {
                return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 3, null, null, null, null, null, null, null)), (l()(), t.Ib(1, 0, null, null, 2, "span", [], null, null, null, null, null)), (l()(), t.cc(2, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i])], null, (function(l, n) {
                    var u = n.component;
                    l(n, 2, 0, t.dc(n, 2, 0, t.Ub(n, 3).transform(u.dogId)))
                }))
            }

            function T(l) {
                return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 3, "span", [], null, null, null, null, null)), (l()(), t.Ib(1, 0, null, null, 2, "span", [], null, null, null, null, null)), (l()(), t.cc(2, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i])], null, (function(l, n) {
                    l(n, 2, 0, t.dc(n, 2, 0, t.Ub(n, 3).transform(n.context.$implicit)))
                }))
            }

            function A(l) {
                return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 2, null, null, null, null, null, null, null)), (l()(), t.xb(16777216, null, null, 1, null, T)), t.Hb(2, 278528, null, 0, v.l, [t.eb, t.Z, t.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), (l()(), t.xb(0, null, null, 0))], (function(l, n) {
                    l(n, 2, 0, n.component.names)
                }), null)
            }

            function E(l) {
                return t.ec(0, [(l()(), t.xb(16777216, null, null, 1, null, A)), t.Hb(1, 16384, null, 0, v.m, [t.eb, t.Z], {
                    ngIf: [0, "ngIf"],
                    ngIfElse: [1, "ngIfElse"]
                }, null), (l()(), t.xb(0, null, null, 0))], (function(l, n) {
                    l(n, 1, 0, n.component.raceParticipantTemplate, t.Ub(n.parent, 4))
                }), null)
            }

            function H(l) {
                return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 2, "span", [], null, null, null, null, null)), (l()(), t.Ib(1, 0, null, null, 1, "span", [], null, null, null, null, null)), (l()(), t.cc(2, null, ["", ""]))], null, (function(l, n) {
                    l(n, 2, 0, n.context.$implicit)
                }))
            }

            function X(l) {
                return t.ec(0, [(l()(), t.xb(16777216, null, null, 2, null, H)), t.Hb(1, 278528, null, 0, v.l, [t.eb, t.Z, t.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), t.Yb(2, 1), (l()(), t.xb(0, null, null, 0))], (function(l, n) {
                    var u = n.component,
                        e = t.dc(n, 1, 0, l(n, 2, 0, t.Ub(n.parent.parent, 0), u.name));
                    l(n, 1, 0, e)
                }), null)
            }

            function D(l) {
                return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 4, "div", [
                    ["class", "participant__name"]
                ], null, null, null, null, null)), (l()(), t.xb(16777216, null, null, 1, null, P)), t.Hb(2, 16384, null, 0, v.m, [t.eb, t.Z], {
                    ngIf: [0, "ngIf"],
                    ngIfElse: [1, "ngIfElse"]
                }, null), (l()(), t.xb(0, [
                    ["participantTemplate", 2]
                ], null, 0, null, E)), (l()(), t.xb(0, [
                    ["defaultParticipantTemplate", 2]
                ], null, 0, null, X))], (function(l, n) {
                    l(n, 2, 0, n.component.dogRaces, t.Ub(n, 3))
                }), null)
            }

            function B(l) {
                return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 1, "div", [
                    ["class", "participant__value"]
                ], null, null, null, null, null)), (l()(), t.cc(1, null, ["", ""]))], null, (function(l, n) {
                    l(n, 1, 0, n.component.odd.value)
                }))
            }

            function N(l) {
                return t.ec(2, [t.Wb(0, y, []), (l()(), t.Ib(1, 0, null, null, 12, "div", [
                    ["class", "grid grid-column participant"]
                ], [
                    [2, "participant--disabled", null]
                ], null, null, null, null)), (l()(), t.Ib(2, 0, null, null, 9, "div", [], null, null, null, null, null)), t.Zb(512, null, v.x, v.y, [t.A, t.B, t.o, t.P]), t.Hb(4, 278528, null, 0, v.k, [v.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), (l()(), t.xb(16777216, null, null, 1, null, x)), t.Hb(6, 16384, null, 0, v.m, [t.eb, t.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), t.xb(16777216, null, null, 1, null, C)), t.Hb(8, 16384, null, 0, v.m, [t.eb, t.Z], {
                    ngIf: [0, "ngIf"],
                    ngIfElse: [1, "ngIfElse"]
                }, null), (l()(), t.xb(0, [
                    ["isString", 2]
                ], null, 0, null, O)), (l()(), t.xb(16777216, null, null, 1, null, D)), t.Hb(11, 16384, null, 0, v.m, [t.eb, t.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), t.xb(16777216, null, null, 1, null, B)), t.Hb(13, 16384, null, 0, v.m, [t.eb, t.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(l, n) {
                    var u = n.component;
                    l(n, 4, 0, t.Mb(1, "col grid grid-column grid-middle participant__dorsal ", u.racesOddClass, ""), u.trotting ? "grid-end" : "grid-center"), l(n, 6, 0, u.trotting), l(n, 8, 0, u.isNumber, t.Ub(n, 9)), l(n, 11, 0, u.participant && !u.trotting), l(n, 13, 0, u.odd)
                }), (function(l, n) {
                    l(n, 1, 0, n.component.isDisabledToBet())
                }))
            }
            t.Eb("grc-races-participant", M, (function(l) {
                return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 1, "grc-races-participant", [], null, [
                    [null, "click"]
                ], (function(l, n, u) {
                    var e = !0;
                    "click" === n && (e = !1 !== t.Ub(l, 1).onClick() && e);
                    return e
                }), N, S)), t.Hb(1, 638976, null, 0, M, [], null, null)], (function(l, n) {
                    l(n, 1, 0)
                }), null)
            }), {
                dorsal: "dorsal",
                isActive: "isActive",
                isDisabled: "isDisabled",
                odd: "odd",
                gameType: "gameType",
                participant: "participant"
            }, {
                participantClick: "participantClick"
            }, []);
            var F = u("XAsR"),
                G = u("M3um"),
                z = u("mv7g"),
                R = u("+69r"),
                V = u("GhKF"),
                q = u("3cbp"),
                Z = function() {
                    function l() {
                        this.markets = [], this.hasSelectAllButton = !0, this.isMarketEnabled = !0, this.isMarket = !0, this.selectedChange = new t.q, this.participantSelected = new t.q, this.selectAllClicked = new t.q
                    }
                    return l.prototype.ngOnInit = function() {
                        this.markets[0] && (this.selected = this.markets[0].id)
                    }, l.prototype.onSelected = function(l) {
                        this.selected = l, this.selectedChange.emit(this.selected)
                    }, l.prototype.onSelectAllClicked = function() {
                        this.selectAllClicked.emit()
                    }, l
                }(),
                K = [
                    [".market-selector__select-all[_ngcontent-%COMP%]{position:absolute;top:0;right:0;padding:10px 14px;margin-right:37px;font-size:16px;font-weight:700;text-transform:capitalize;cursor:pointer}"]
                ],
                Y = t.Gb({
                    encapsulation: 0,
                    styles: K,
                    data: {}
                });

            function $(l) {
                return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 2, "div", [
                    ["actionButton", ""],
                    ["class", "market-selector__select-all"]
                ], null, [
                    [null, "click"]
                ], (function(l, n, u) {
                    var t = !0,
                        e = l.component;
                    "click" === n && (t = !1 !== e.onSelectAllClicked() && t);
                    return t
                }), null, null)), (l()(), t.cc(1, null, [" ", " "])), t.Wb(131072, W.j, [W.k, t.i])], null, (function(l, n) {
                    l(n, 1, 0, t.dc(n, 1, 0, t.Ub(n, 2).transform("ch_select_all")))
                }))
            }

            function Q(l) {
                return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 1, "grc-tab", [], null, null, null, F.b, F.a)), t.Hb(1, 114688, [
                    [1, 4]
                ], 0, G.a, [], {
                    header: [0, "header"],
                    id: [1, "id"]
                }, null)], (function(l, n) {
                    l(n, 1, 0, n.context.$implicit.value, n.context.$implicit.id)
                }), null)
            }

            function L(l) {
                return t.ec(2, [(l()(), t.Ib(0, 0, null, null, 10, "grc-tab-set", [
                    ["tabSetClass", "races-tab-set"]
                ], [
                    [8, "className", 0]
                ], [
                    [null, "selectedChange"]
                ], (function(l, n, u) {
                    var t = !0,
                        e = l.component;
                    "selectedChange" === n && (t = !1 !== e.onSelected(u) && t);
                    return t
                }), z.b, z.a)), t.Hb(1, 4308992, null, 2, R.a, [t.i], {
                    sameContent: [0, "sameContent"],
                    hasBorder: [1, "hasBorder"],
                    selected: [2, "selected"],
                    disabled: [3, "disabled"],
                    tabSetClass: [4, "tabSetClass"]
                }, {
                    selectedChange: "selectedChange"
                }), t.ac(603979776, 1, {
                    tabsContent: 1
                }), t.ac(603979776, 2, {
                    tabsFixedContent: 1
                }), (l()(), t.xb(16777216, null, 0, 1, null, $)), t.Hb(5, 16384, null, 0, v.m, [t.eb, t.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), t.xb(16777216, null, null, 1, null, Q)), t.Hb(7, 278528, null, 0, v.l, [t.eb, t.Z, t.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), (l()(), t.Ib(8, 0, null, null, 2, "grc-tab-fixed", [
                    ["side", "content"]
                ], null, null, null, V.b, V.a)), t.Hb(9, 114688, [
                    [2, 4]
                ], 0, q.a, [], {
                    side: [0, "side"]
                }, null), t.Tb(0, 0)], (function(l, n) {
                    var u = n.component;
                    l(n, 1, 0, !0, !0, u.selected, !u.isMarketEnabled, "races-tab-set"), l(n, 5, 0, u.hasSelectAllButton), l(n, 7, 0, u.markets);
                    l(n, 9, 0, "content")
                }), (function(l, n) {
                    l(n, 0, 0, t.Ub(n, 1).tabSetClass)
                }))
            }
            t.Eb("grc-races-market-selector", Z, (function(l) {
                return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 1, "grc-races-market-selector", [], null, null, null, L, Y)), t.Hb(1, 114688, null, 0, Z, [], null, null)], (function(l, n) {
                    l(n, 1, 0)
                }), null)
            }), {
                markets: "markets",
                hasSelectAllButton: "hasSelectAllButton",
                selected: "selected",
                isMarketEnabled: "isMarketEnabled",
                isMarket: "isMarket"
            }, {
                selectedChange: "selectedChange",
                participantSelected: "participantSelected",
                selectAllClicked: "selectAllClicked"
            }, ["*"]);
            var J, ll = u("n3kJ"),
                nl = u("67Y/"),
                ul = u("ijKR"),
                tl = u("D1+H"),
                el = u("Z/Mk"),
                cl = (J = function(l, n) {
                    return (J = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(l, n) {
                            l.__proto__ = n
                        } || function(l, n) {
                            for (var u in n) Object.prototype.hasOwnProperty.call(n, u) && (l[u] = n[u])
                        })(l, n)
                }, function(l, n) {
                    function u() {
                        this.constructor = l
                    }
                    J(l, n), l.prototype = null === n ? Object.create(n) : (u.prototype = n.prototype, new u)
                }),
                rl = function(l) {
                    function n(n) {
                        var u = l.call(this) || this;
                        return u.i18NService = n, u.hasEnterSystemSection = !1, u.HorseMarkets = w.HorseMarkets, u.throttingMarketsEnable = !1, u.close = new t.q, u
                    }
                    return cl(n, l), n.prototype.ngOnInit = function() {
                        this.throttingMarketsEnable ? this.title = "" + this.i18NService.get("ch_h12_races") : this.title = "" + this.i18NService.get("ch_h6d6_races")
                    }, n
                }(el.a),
                al = function() {
                    var l = function(n, u) {
                        return (l = Object.setPrototypeOf || {
                                __proto__: []
                            }
                            instanceof Array && function(l, n) {
                                l.__proto__ = n
                            } || function(l, n) {
                                for (var u in n) Object.prototype.hasOwnProperty.call(n, u) && (l[u] = n[u])
                            })(n, u)
                    };
                    return function(n, u) {
                        function t() {
                            this.constructor = n
                        }
                        l(n, u), n.prototype = null === u ? Object.create(u) : (t.prototype = u.prototype, new t)
                    }
                }(),
                sl = function(l) {
                    function n(n) {
                        var u = l.call(this) || this;
                        return u.i18NService = n, u.hasEnterSystemSection = !1, u.KartMarkets = w.KartMarkets, u.close = new t.q, u
                    }
                    return al(n, l), n.prototype.ngOnInit = function() {
                        this.title = "" + this.i18NService.get("ch_karts_racing")
                    }, n
                }(el.a),
                il = function() {
                    var l = function(n, u) {
                        return (l = Object.setPrototypeOf || {
                                __proto__: []
                            }
                            instanceof Array && function(l, n) {
                                l.__proto__ = n
                            } || function(l, n) {
                                for (var u in n) Object.prototype.hasOwnProperty.call(n, u) && (l[u] = n[u])
                            })(n, u)
                    };
                    return function(n, u) {
                        function t() {
                            this.constructor = n
                        }
                        l(n, u), n.prototype = null === u ? Object.create(u) : (t.prototype = u.prototype, new t)
                    }
                }(),
                ol = function(l) {
                    function n(n) {
                        var u = l.call(this) || this;
                        return u.i18NService = n, u.hasEnterSystemSection = !1, u.MotorbikeMarkets = w.MotorbikeMarkets, u.close = new t.q, u
                    }
                    return il(n, l), n.prototype.ngOnInit = function() {
                        this.title = "" + this.i18NService.get("ch_motorbikes_races")
                    }, n
                }(el.a),
                bl = function() {
                    var l = function(n, u) {
                        return (l = Object.setPrototypeOf || {
                                __proto__: []
                            }
                            instanceof Array && function(l, n) {
                                l.__proto__ = n
                            } || function(l, n) {
                                for (var u in n) Object.prototype.hasOwnProperty.call(n, u) && (l[u] = n[u])
                            })(n, u)
                    };
                    return function(n, u) {
                        function t() {
                            this.constructor = n
                        }
                        l(n, u), n.prototype = null === u ? Object.create(u) : (t.prototype = u.prototype, new t)
                    }
                }(),
                dl = function(l) {
                    function n(n) {
                        var u = l.call(this) || this;
                        return u.i18NService = n, u.hasEnterSystemSection = !1, u.SpeedwayMarkets = w.SpeedwayMarkets, u.close = new t.q, u
                    }
                    return bl(n, l), n.prototype.ngOnInit = function() {
                        this.title = "" + this.i18NService.get("ch_spdt_races")
                    }, n
                }(el.a),
                pl = function() {
                    var l = function(n, u) {
                        return (l = Object.setPrototypeOf || {
                                __proto__: []
                            }
                            instanceof Array && function(l, n) {
                                l.__proto__ = n
                            } || function(l, n) {
                                for (var u in n) Object.prototype.hasOwnProperty.call(n, u) && (l[u] = n[u])
                            })(n, u)
                    };
                    return function(n, u) {
                        function t() {
                            this.constructor = n
                        }
                        l(n, u), n.prototype = null === u ? Object.create(u) : (t.prototype = u.prototype, new t)
                    }
                }(),
                hl = function(l) {
                    function n(n, u) {
                        var t = l.call(this, n) || this;
                        return t.shopAdminService = u, t.DogMarkets = w.DogMarkets, t.HorseMarkets = w.HorseMarkets, t.isExtra = !0, t.participantsSelectedForAnyOrder = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12], t.numParticipantsColumns = 0, t.dependencies = ["win", "doubleQuinella", "trifecta"], t.fastBetHelpComponent = {
                            KART: sl,
                            MOTORBIKE: ol,
                            SPEEDWAYDIRTTRACK: dl,
                            DOGHORSE: rl
                        }, t
                    }
                    return pl(n, l), n.prototype.onChangeTab = function(l, n) {
                        this.selections[l].type = n, this.marketId = n, this.clearParticipantDependencies(l)
                    }, n.prototype.onSpecialChangeTab = function(l, n) {
                        this.selections[l].odds = this.getOdds(n), this.filterOddsNotEnabledToBet(), this.onChangeTab(l, n)
                    }, n.prototype.onParticipantSelected = function(l, n, u) {
                        var t = this.selections[l].participants.indexOf(n);
                        t > -1 ? (this.selections[l].participants.splice(t, 1), 0 === this.marketParticipants(l) && this.clearParticipantDependencies(l)) : this.selections[l].participants.push(n), this.updateBetslipConfiguration(), "anyOrder" === l && this.updateParticipantsSelectedForAnyOrder(l, u, n)
                    }, n.prototype.isParticipantSelected = function(l, n) {
                        return this.selections[l].participants.includes(n)
                    }, n.prototype.canSelectParticipant = function(l, n) {
                        var u = this;
                        return !(this.selections[n].odds && !(this.selections[n].odds && this.selections[n].odds[l - 1] && this.selections[n].odds[l - 1].value && this.selections[n].odds[l - 1].value > 1.01)) && !this.dependencies.some((function(t) {
                            var e = !1;
                            return t !== n && (e = u.isParticipantSelected(t, l)), e
                        }))
                    }, n.prototype.canSelectParticipantAnyOrder = function(l, n, u) {
                        return "three_any_order" === n ? this.participantsSelectedForAnyOrder.includes(u) && this.participantsSelectedForAnyOrder.length === this.event.data.participants.length - 3 : this.participantsSelectedForAnyOrder.includes(u) && this.participantsSelectedForAnyOrder.length === this.event.data.participants.length - 4
                    }, n.prototype.updateParticipantsSelectedForAnyOrder = function(l, n, u) {
                        if (this.participantsSelectedForAnyOrder.includes(u)) {
                            var t = this.participantsSelectedForAnyOrder.indexOf(u);
                            t > -1 && this.participantsSelectedForAnyOrder.splice(t, 1)
                        } else this.participantsSelectedForAnyOrder.push(u);
                        this.canSelectParticipantAnyOrder(l, n, u)
                    }, n.prototype.onSelectAllButtonClicked = function(l) {
                        var n = this;
                        this.selectedsPlusNotEnabledsToBet(l) < this.participants().length ? this.participants().forEach((function(u, t) {
                            n.isEnabledToBet(l, t) && !n.isParticipantSelected(l, t + 1) && n.selections[l].participants.push(t + 1)
                        })) : this.selections[l].participants = [], this.updateBetslipConfiguration()
                    }, n.prototype.onWinSelectAllButtonClicked = function(l) {
                        var n = this;
                        this.marketParticipants(l) + this.participantsBlockedByDependencie(l) < this.participants().length ? this.participants().forEach((function(u, t) {
                            !n.isParticipantSelected(l, t + 1) && n.canSelectParticipant(t + 1, l) && n.selections[l].participants.push(t + 1)
                        })) : (this.selections[l].participants = [], this.clearParticipantDependencies(l)), this.updateBetslipConfiguration()
                    }, n.prototype.isDoubleQuinellaMarketEnabled = function(l) {
                        return this.marketParticipants(l) >= 1 && this.marketParticipants(l) < this.participants().length
                    }, n.prototype.isTrifectaMarketEnabled = function(l, n) {
                        return this.marketParticipants(l) >= 1 && this.participantsBlockedByDependencie(l) + this.selectedsPlusNotEnabledsToBet(l) < this.participants().length || this.marketParticipants(n) >= 1
                    }, n.prototype.getFastBetStake = function() {
                        return this.betslipService.getStake()
                    }, n.prototype.hasParticipantsSelected = function(l) {
                        return 0 !== this.selections[l].participants.length
                    }, n.prototype.onResetTabs = function() {
                        var l = this;
                        this.subscriptions.add(this.betslipService.onClear.subscribe((function() {
                            l.configureMarketSelectors(), l.resetSelectionForAnyOrder()
                        }))), this.subscriptions.add(this.betslipService.addBet.subscribe((function(n) {
                            l.configureMarketSelectors(), l.resetSelectionForAnyOrder()
                        })))
                    }, n.prototype.resetSelectionForAnyOrder = function() {
                        this.participantsSelectedForAnyOrder = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
                    }, n.prototype.onBeforeInit = function() {
                        var n = this;
                        return l.prototype.onBeforeInit.call(this).pipe(Object(nl.a)((function() {
                            n.onClearBetslipUserSelections(), n.onEventBlockControllerReadyToStart(n.eventBlock), n.baseService.activateGame(!0), n.onResetTabs()
                        })))
                    }, n.prototype.configureHeader = function() {
                        var l = this;
                        this.baseService.setHeaderState({
                            gameName: this.playlist.descriptionTag,
                            eventName: "#" + this.getEventId(),
                            countdownEventBlockController: this.eventBlockController,
                            playList: this.playlist,
                            buttons: [{
                                title: "ch_results_history",
                                callback: function() {
                                    return l.shopAdminService.openResultHistory(l.playlist)
                                },
                                shortcuts: [ll.a.ResultHistory],
                                disabled: !this.isResultsHistoryButtonVisible()
                            }]
                        })
                    }, n.prototype.configureFastbet = function() {
                        var l = this;
                        this.betslipService.getFastbetParser(this.playlist.id, "races").subscribe((function(n) {
                            n.setParticipants(l.participants().length), n.setGameType({
                                val: l.playlist.gameType.val
                            });
                            var u = l.playlist.filter;
                            n.setPodium(u.numPodium), u && 12 === u.numParticipants ? n.enableThrottingMarkets() : n.disableThrottingMarkets()
                        }))
                    }, n.prototype.configureBetslip = function() {
                        var l = this;
                        this.betslipService.setConfiguration({
                            betMode: w.BetModeEnum.SINGLEBETMODE,
                            preStake: function() {
                                return l.createBets()
                            },
                            prefixMarket: function(n) {
                                return l.getMarketPrefix(n)
                            },
                            fastbetHelp: function() {
                                return l.openFastBetHelpPage()
                            },
                            fastbetStake: function() {
                                return l.getFastBetStake()
                            }
                        })
                    }, n.prototype.onEventBlockControllerReadyToStart = function(l) {
                        this.event = l.events[0];
                        var n = this.event.data.participants.length;
                        this.numParticipantsColumns = this.getNumParticipantsColumns(n), this.configureMarketSelectors()
                    }, n.prototype.onEventBlockControllerClosedMarkets = function(l) {
                        this.onClearBetslipUserSelections()
                    }, n.prototype.onClearBetslipUserSelections = function() {
                        var l = this;
                        this.selections && Object.keys(this.selections).forEach((function(n) {
                            l.selections[n].participants = []
                        })), this.updateBetslipConfiguration()
                    }, n.prototype.isResultsHistoryButtonVisible = function() {
                        return this.betslipService.getShopadminProfileSettings().showResults
                    }, n.prototype.openFastBetHelpPage = function() {
                        var l = this,
                            n = this.playlist.filter.isHorseFilter() && this.playlist.filter,
                            u = n && 12 === n.numParticipants || this.playlist.gameType.val.toUpperCase() === w.coreModel.GameType.ValEnum.TROTTING;
                        this.modalService.open("base-front", this.fastBetHelpComponent[this.getGameType().toUpperCase()], {
                            inputs: {
                                throttingMarketsEnable: u,
                                participants: this.participants().length
                            },
                            outputs: {
                                close: function() {
                                    l.modalService.close("base-front")
                                }
                            }
                        })
                    }, n.prototype.filterOddsNotEnabledToBet = function() {
                        var l = this,
                            n = this.selections.placeShow.participants;
                        this.selections.placeShow.participants = n.filter((function(n) {
                            return l.isEnabledToBet("placeShow", n - 1)
                        }))
                    }, n.prototype.isEnabledToBet = function(l, n) {
                        var u = !0;
                        return this.selections[l].odds && this.selections[l].odds[n] && this.selections[l].odds[n]._clData && (u = this.selections[l].odds[n]._clData.isEnabledToBet()), u
                    }, n.prototype.getGameType = function() {
                        var l = this.playlist.gameType.val;
                        return l = l === w.coreModel.GameType.ValEnum.DOG || l === w.coreModel.GameType.ValEnum.HORSE || l === w.coreModel.GameType.ValEnum.TROTTING ? "" + w.coreModel.GameType.ValEnum.DOG + w.coreModel.GameType.ValEnum.HORSE : l === w.coreModel.GameType.ValEnum.SPEEDWAY || l === w.coreModel.GameType.ValEnum.DIRTTRACK ? "" + w.coreModel.GameType.ValEnum.SPEEDWAY + w.coreModel.GameType.ValEnum.DIRTTRACK : "" + l.slice(0, l.length - 1) + l.slice(-1).toLocaleLowerCase()
                    }, n.prototype.getMarketPrefix = function(l) {
                        var n = this,
                            u = Object.keys(this.selections),
                            t = null;
                        return u.forEach((function(u) {
                            return n.selections[u].tabs.forEach((function(n) {
                                n.id === l.marketId && (t = n.value)
                            }))
                        })), t ? t + " " : t
                    }, n.prototype.selectedsPlusNotEnabledsToBet = function(l) {
                        return this.marketParticipants(l) + this.participantsNotEnabledsToBet(l)
                    }, n.prototype.participantsBlockedByDependencie = function(l) {
                        var n = this,
                            u = 0;
                        return this.participants().forEach((function(t, e) {
                            n.canSelectParticipant(e + 1, l) || (u += 1)
                        })), u
                    }, n.prototype.participantsNotEnabledsToBet = function(l) {
                        var n = this,
                            u = 0;
                        return this.participants().forEach((function(t, e) {
                            n.isEnabledToBet(l, e) || (u += 1)
                        })), u
                    }, n.prototype.marketParticipants = function(l) {
                        return this.selections[l].participants.length
                    }, n.prototype.participants = function() {
                        return this.event && this.event.data.participants || []
                    }, n.prototype.getEventId = function() {
                        return this.eventBlock.events[0].eventId
                    }, n.prototype.configureMarketSelectors = function() {
                        var l = this.participants().length > 4,
                            n = 12 === this.participants().length;
                        this.selections = {
                            win: {
                                type: w.DogMarkets.win,
                                tabs: n ? [{
                                    id: w.DogMarkets.win,
                                    value: this.i18NService.getMarketTag(w.DogMarkets.win)
                                }, {
                                    id: w.HorseMarkets.second_place,
                                    value: this.i18NService.getMarketTag(w.HorseMarkets.second_place)
                                }, {
                                    id: w.HorseMarkets.third_place,
                                    value: this.i18NService.getMarketTag(w.HorseMarkets.third_place)
                                }, {
                                    id: w.HorseMarkets.fourth_place_worse,
                                    value: this.i18NService.getMarketTag(w.HorseMarkets.fourth_place_worse)
                                }] : [{
                                    id: w.DogMarkets.win,
                                    value: this.i18NService.getMarketTag(w.DogMarkets.win)
                                }],
                                participants: [],
                                odds: this.getOdds(w.DogMarkets.win)
                            },
                            doubleQuinella: {
                                type: w.DogMarkets.exacta,
                                tabs: [{
                                    id: w.DogMarkets.exacta,
                                    value: this.i18NService.getMarketTag(w.DogMarkets.exacta)
                                }, {
                                    id: w.DogMarkets.quinella,
                                    value: this.i18NService.getMarketTag(w.DogMarkets.quinella)
                                }],
                                participants: []
                            },
                            trifecta: {
                                type: w.DogMarkets.trifecta,
                                tabs: l ? [{
                                    id: w.DogMarkets.trifecta,
                                    value: this.i18NService.getMarketTag(w.DogMarkets.trifecta)
                                }] : [],
                                participants: []
                            },
                            placeShow: {
                                type: w.DogMarkets.place,
                                tabs: l ? [{
                                    id: w.DogMarkets.place,
                                    value: this.i18NService.getMarketTag(w.DogMarkets.place)
                                }, {
                                    id: w.DogMarkets.show,
                                    value: this.i18NService.getMarketTag(w.DogMarkets.show)
                                }] : [{
                                    id: w.DogMarkets.place,
                                    value: this.i18NService.getMarketTag(w.DogMarkets.place)
                                }],
                                participants: [],
                                odds: this.getOdds(w.DogMarkets.place)
                            },
                            system: {
                                type: w.DogMarkets.system_two,
                                tabs: n ? [{
                                    id: w.DogMarkets.system_two,
                                    value: this.i18NService.getMarketGroupTag(w.DogMarkets.system_two)
                                }, {
                                    id: w.DogMarkets.system_three,
                                    value: this.i18NService.getMarketGroupTag(w.DogMarkets.system_three)
                                }, {
                                    id: w.HorseMarkets.system_four_any_order,
                                    value: this.i18NService.getMarketGroupTag(w.HorseMarkets.system_four_any_order)
                                }] : l ? [{
                                    id: w.DogMarkets.system_two,
                                    value: this.i18NService.getMarketGroupTag(w.DogMarkets.system_two)
                                }, {
                                    id: w.DogMarkets.system_three,
                                    value: this.i18NService.getMarketGroupTag(w.DogMarkets.system_three)
                                }] : [{
                                    id: w.DogMarkets.system_two,
                                    value: this.i18NService.getMarketGroupTag(w.DogMarkets.system_two)
                                }],
                                participants: []
                            },
                            extra: {
                                type: "Extra",
                                tabs: n ? [] : [{
                                    id: "Extra",
                                    value: this.i18NService.getMarketGroupTag("extra")
                                }],
                                participants: []
                            },
                            anyOrder: {
                                type: w.HorseMarkets.three_any_order,
                                tabs: n ? [{
                                    id: w.HorseMarkets.three_any_order,
                                    value: this.i18NService.getMarketTag(w.HorseMarkets.three_any_order)
                                }, {
                                    id: w.HorseMarkets.four_any_order,
                                    value: this.i18NService.getMarketGroupTag(w.HorseMarkets.four_any_order)
                                }] : [],
                                participants: []
                            }
                        }
                    }, n.prototype.getOdds = function(l) {
                        return this.event.data._clData.marketMap.get(l).odds
                    }, n.prototype.clearParticipantDependencies = function(l) {
                        var n = this,
                            u = this.dependencies.indexOf(l); - 1 !== u && this.dependencies.slice(u + 1).forEach((function(l) {
                            n.selections[l].participants = []
                        }))
                    }, n.prototype.createBets = function() {
                        var l = this,
                            n = {
                                marketId: this.selections.win.type.toString(),
                                selectionArray: this.selections.win.participants.map((function(l) {
                                    return l.toString()
                                }))
                            },
                            u = this.hasParticipantsSelected("doubleQuinella") ? {
                                marketId: this.selections.doubleQuinella.type.toString(),
                                selectionArray: this.selections.doubleQuinella.participants.map((function(l) {
                                    return l.toString()
                                }))
                            } : null,
                            t = this.hasParticipantsSelected("trifecta") ? {
                                marketId: this.selections.trifecta.type.toString(),
                                selectionArray: this.selections.trifecta.participants.map((function(l) {
                                    return l.toString()
                                }))
                            } : null,
                            e = this.hasParticipantsSelected("anyOrder") ? {
                                marketId: this.selections.anyOrder.type.toString(),
                                oddId: this.selections.anyOrder.type.split("_order").join(""),
                                betParam: this.selections.anyOrder.participants.map((function(l) {
                                    return l.toString()
                                })).join(",")
                            } : null,
                            c = this.hasSystemBetCorrectParticipants(this.selections.system) ? {
                                marketId: this.selections.system.type.toString(),
                                oddId: this.event.data._clData.marketMap.get(this.selections.system.type).odds[0].id,
                                betParam: this.selections.system.participants.map((function(l) {
                                    return l.toString()
                                })).join(",")
                            } : null,
                            r = w.SessionController.gameManager.getDogGame().createBetsFromArrays(n, u, t);
                        if (c) {
                            var a = this.coreService.getCashierProfileSettings().duplicateTips;
                            this.isSystemBetDuplicated(c) && !a ? (this.selections.system.participants = [], this.notificationsService.warning("" + this.i18NService.get("ch_duplicate_bet")), this.cd.detectChanges()) : r.push(c)
                        }
                        if (r.length + this.selections.extra.participants.length + this.selections.placeShow.participants.length + this.selections.anyOrder.participants.length > 0) {
                            var s = r.map((function(n) {
                                return {
                                    playlist: l.playlist,
                                    eventBlock: l.eventBlock,
                                    event: l.event,
                                    odd: l.event.data._clData.oddMap.get(n.oddId),
                                    betParam: n.betParam
                                }
                            }));
                            if (this.selections.extra.participants.forEach((function(n) {
                                    s.push({
                                        playlist: l.playlist,
                                        eventBlock: l.eventBlock,
                                        event: l.event,
                                        odd: l.event.data._clData.oddMap.get(n.toString())
                                    })
                                })), this.selections.placeShow.participants.forEach((function(n) {
                                    l.selections.placeShow.type;
                                    s.push({
                                        playlist: l.playlist,
                                        eventBlock: l.eventBlock,
                                        event: l.event,
                                        odd: l.event.data._clData.marketMap.get(l.selections.placeShow.type).odds[n - 1]
                                    })
                                })), e) {
                                var i = this.selections.anyOrder.type,
                                    o = this.selections.anyOrder.participants.slice().sort((function(l, n) {
                                        return +l - +n
                                    })),
                                    b = o.join(","),
                                    d = "" + i.split("order").join("") + o.join("_"),
                                    p = this.event.data._clData.marketMap.get(this.selections.anyOrder.type).odds.filter((function(l) {
                                        return l.id === d
                                    }));
                                s.push({
                                    playlist: this.playlist,
                                    eventBlock: this.eventBlock,
                                    event: this.event,
                                    odd: p[0],
                                    betParam: b.toString()
                                })
                            }
                            this.betslipService.addBets(s) && this.onClearBetslipUserSelections(), this.cd.detectChanges()
                        }
                    }, n.prototype.isSystemBetDuplicated = function(l) {
                        var n = this.betslipService.getBetslipInfo().events[0];
                        if (n) {
                            var u = l.betParam.split(",").sort().join(",");
                            return n.bets.some((function(n) {
                                return n.marketId === l.marketId && n.betParam.split(",").sort().join(",") === u
                            }))
                        }
                    }, n.prototype.hasSystemBetCorrectParticipants = function(l) {
                        var n = !1;
                        return (l.type === w.DogMarkets.system_two && l.participants.length >= 2 || l.type === w.DogMarkets.system_three && l.participants.length >= 3 || l.type === w.HorseMarkets.system_four_any_order && l.participants.length >= 4) && (n = !0), n
                    }, n.prototype.updateBetslipConfiguration = function() {
                        var l = this,
                            n = Object.keys(this.selections || {}).some((function(n) {
                                return l.selections[n].participants.length > 0
                            }));
                        this.betslipService.updateConfiguration({
                            hasOptionsSelected: n
                        })
                    }, n.prototype.getNumParticipantsColumns = function(l) {
                        return l / (l > 6 ? 2 : 1)
                    }, n
                }(tl.a),
                fl = [
                    [".races[_ngcontent-%COMP%]{height:100%}.races[_ngcontent-%COMP%] > .col[_ngcontent-%COMP%]:first-child{margin-right:2px}.races[_ngcontent-%COMP%] > .col[_ngcontent-%COMP%]:last-child{margin-left:2px}.races__market-container[_ngcontent-%COMP%]{position:relative;max-height:33.33%;padding:12px 30px 10px}.races__participants[_ngcontent-%COMP%]{height:100%;padding:10px 30px}.races__participants[_ngcontent-%COMP%]   .grc-races-participant[_ngcontent-%COMP%]{max-height:45%;padding:0 7px 4px}.races__paddings[_ngcontent-%COMP%] > .col[_ngcontent-%COMP%]:first-child{padding-right:26px}.races__paddings[_ngcontent-%COMP%] > .col[_ngcontent-%COMP%]:last-child{padding-left:26px}"]
                ],
                _l = t.Gb({
                    encapsulation: 0,
                    styles: fl,
                    data: {}
                });

            function kl(l) {
                return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 1, "grc-races-participant", [
                    ["class", "col grc-races-participant"]
                ], [
                    [4, "padding-top", null]
                ], [
                    [null, "participantClick"],
                    [null, "click"]
                ], (function(l, n, u) {
                    var e = !0,
                        c = l.component;
                    "click" === n && (e = !1 !== t.Ub(l, 1).onClick() && e);
                    "participantClick" === n && (e = !1 !== c.onParticipantSelected("win", l.context.index + 1) && e);
                    return e
                }), N, S)), t.Hb(1, 638976, null, 0, M, [], {
                    dorsal: [0, "dorsal"],
                    isActive: [1, "isActive"],
                    isDisabled: [2, "isDisabled"],
                    odd: [3, "odd"],
                    gameType: [4, "gameType"],
                    participant: [5, "participant"]
                }, {
                    participantClick: "participantClick"
                })], (function(l, n) {
                    var u = n.component;
                    l(n, 1, 0, n.context.index + 1, u.isParticipantSelected("win", n.context.index + 1), !u.canSelectParticipant(n.context.index + 1, "win"), u.selections.win.odds[n.context.index], u.gameType, n.context.$implicit)
                }), (function(l, n) {
                    var u = n.component;
                    l(n, 0, 0, n.context.index >= u.numParticipantsColumns ? "5px" : "0")
                }))
            }

            function ml(l) {
                return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 1, "grc-races-participant", [
                    ["class", "col grc-races-participant"]
                ], [
                    [4, "padding-top", null]
                ], [
                    [null, "participantClick"],
                    [null, "click"]
                ], (function(l, n, u) {
                    var e = !0,
                        c = l.component;
                    "click" === n && (e = !1 !== t.Ub(l, 1).onClick() && e);
                    "participantClick" === n && (e = !1 !== c.onParticipantSelected("doubleQuinella", l.context.index + 1) && e);
                    return e
                }), N, S)), t.Hb(1, 638976, null, 0, M, [], {
                    dorsal: [0, "dorsal"],
                    isActive: [1, "isActive"],
                    isDisabled: [2, "isDisabled"],
                    gameType: [3, "gameType"],
                    participant: [4, "participant"]
                }, {
                    participantClick: "participantClick"
                })], (function(l, n) {
                    var u = n.component;
                    l(n, 1, 0, n.context.index + 1, u.isParticipantSelected("doubleQuinella", n.context.index + 1), 0 === u.selections.win.participants.length || !u.canSelectParticipant(n.context.index + 1, "doubleQuinella") || "win" !== u.selections.win.type, u.gameType, n.context.$implicit)
                }), (function(l, n) {
                    var u = n.component;
                    l(n, 0, 0, n.context.index >= u.numParticipantsColumns ? "5px" : "0")
                }))
            }

            function gl(l) {
                return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 1, "grc-races-participant", [
                    ["class", "col grc-races-participant"]
                ], [
                    [4, "padding-top", null]
                ], [
                    [null, "participantClick"],
                    [null, "click"]
                ], (function(l, n, u) {
                    var e = !0,
                        c = l.component;
                    "click" === n && (e = !1 !== t.Ub(l, 1).onClick() && e);
                    "participantClick" === n && (e = !1 !== c.onParticipantSelected("trifecta", l.context.index + 1) && e);
                    return e
                }), N, S)), t.Hb(1, 638976, null, 0, M, [], {
                    dorsal: [0, "dorsal"],
                    isActive: [1, "isActive"],
                    isDisabled: [2, "isDisabled"],
                    gameType: [3, "gameType"],
                    participant: [4, "participant"]
                }, {
                    participantClick: "participantClick"
                })], (function(l, n) {
                    var u = n.component;
                    l(n, 1, 0, n.context.index + 1, u.isParticipantSelected("trifecta", n.context.index + 1), !t.Ub(n.parent, 1).isMarketEnabled || 0 === u.selections.doubleQuinella.participants.length || !u.canSelectParticipant(n.context.index + 1, "trifecta"), u.gameType, n.context.$implicit)
                }), (function(l, n) {
                    var u = n.component;
                    l(n, 0, 0, n.context.index >= u.numParticipantsColumns ? "5px" : "0")
                }))
            }

            function Il(l) {
                return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 4, "grc-races-market-selector", [
                    ["class", "col races__market-container"]
                ], null, [
                    [null, "selectedChange"]
                ], (function(l, n, u) {
                    var t = !0,
                        e = l.component;
                    "selectedChange" === n && (t = !1 !== e.onChangeTab("trifecta", u) && t);
                    return t
                }), L, Y)), t.Hb(1, 114688, [
                    ["trifectaMarketSelector", 4]
                ], 0, Z, [], {
                    markets: [0, "markets"],
                    hasSelectAllButton: [1, "hasSelectAllButton"],
                    selected: [2, "selected"],
                    isMarketEnabled: [3, "isMarketEnabled"]
                }, {
                    selectedChange: "selectedChange"
                }), (l()(), t.Ib(2, 0, null, 0, 2, "div", [], [
                    [8, "className", 0]
                ], null, null, null, null)), (l()(), t.xb(16777216, null, null, 1, null, gl)), t.Hb(4, 278528, null, 0, v.l, [t.eb, t.Z, t.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(l, n) {
                    var u = n.component;
                    l(n, 1, 0, u.selections.trifecta.tabs, !1, u.selections.trifecta.type, u.isTrifectaMarketEnabled("doubleQuinella", "trifecta") && u.selections.doubleQuinella.type !== u.DogMarkets.quinella), l(n, 4, 0, u.event.data.participants)
                }), (function(l, n) {
                    var u = n.component;
                    l(n, 2, 0, t.Mb(1, "grid grid-", u.numParticipantsColumns, " races__participants"))
                }))
            }

            function Ul(l) {
                return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 1, "grc-races-participant", [
                    ["class", "col grc-races-participant"]
                ], [
                    [4, "padding-top", null]
                ], [
                    [null, "participantClick"],
                    [null, "click"]
                ], (function(l, n, u) {
                    var e = !0,
                        c = l.component;
                    "click" === n && (e = !1 !== t.Ub(l, 1).onClick() && e);
                    "participantClick" === n && (e = !1 !== c.onParticipantSelected("placeShow", l.context.index + 1) && e);
                    return e
                }), N, S)), t.Hb(1, 638976, null, 0, M, [], {
                    dorsal: [0, "dorsal"],
                    isActive: [1, "isActive"],
                    isDisabled: [2, "isDisabled"],
                    odd: [3, "odd"],
                    gameType: [4, "gameType"],
                    participant: [5, "participant"]
                }, {
                    participantClick: "participantClick"
                })], (function(l, n) {
                    var u = n.component;
                    l(n, 1, 0, n.context.index + 1, u.isParticipantSelected("placeShow", n.context.index + 1), !u.selections.placeShow.odds[n.context.index]._clData.isEnabledToBet(), u.selections.placeShow.odds[n.context.index], u.gameType, n.context.$implicit)
                }), (function(l, n) {
                    var u = n.component;
                    l(n, 0, 0, n.context.index >= u.numParticipantsColumns ? "5px" : "0")
                }))
            }

            function Wl(l) {
                return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 1, "grc-races-participant", [
                    ["class", "col grc-races-participant"]
                ], [
                    [4, "padding-top", null]
                ], [
                    [null, "participantClick"],
                    [null, "click"]
                ], (function(l, n, u) {
                    var e = !0,
                        c = l.component;
                    "click" === n && (e = !1 !== t.Ub(l, 1).onClick() && e);
                    "participantClick" === n && (e = !1 !== c.onParticipantSelected("system", l.context.index + 1) && e);
                    return e
                }), N, S)), t.Hb(1, 638976, null, 0, M, [], {
                    dorsal: [0, "dorsal"],
                    isActive: [1, "isActive"],
                    gameType: [2, "gameType"],
                    participant: [3, "participant"]
                }, {
                    participantClick: "participantClick"
                })], (function(l, n) {
                    var u = n.component;
                    l(n, 1, 0, n.context.index + 1, u.isParticipantSelected("system", n.context.index + 1), u.gameType, n.context.$implicit)
                }), (function(l, n) {
                    var u = n.component;
                    l(n, 0, 0, n.context.index >= u.numParticipantsColumns ? "5px" : "0")
                }))
            }

            function vl(l) {
                return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 1, "grc-races-participant", [
                    ["class", "col grc-races-participant"]
                ], null, [
                    [null, "participantClick"],
                    [null, "click"]
                ], (function(l, n, u) {
                    var e = !0,
                        c = l.component;
                    "click" === n && (e = !1 !== t.Ub(l, 1).onClick() && e);
                    "participantClick" === n && (e = !1 !== c.onParticipantSelected("extra", l.context.$implicit.id) && e);
                    return e
                }), N, S)), t.Hb(1, 638976, null, 0, M, [], {
                    dorsal: [0, "dorsal"],
                    isActive: [1, "isActive"],
                    isDisabled: [2, "isDisabled"],
                    odd: [3, "odd"]
                }, {
                    participantClick: "participantClick"
                })], (function(l, n) {
                    var u = n.component,
                        t = n.context.$implicit.id,
                        e = u.isParticipantSelected("extra", n.context.$implicit.id),
                        c = !n.context.$implicit._clData.isEnabledToBet();
                    l(n, 1, 0, t, e, c, n.context.$implicit)
                }), null)
            }

            function yl(l) {
                return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 1, "grc-races-participant", [
                    ["class", "col grc-races-participant"]
                ], null, [
                    [null, "participantClick"],
                    [null, "click"]
                ], (function(l, n, u) {
                    var e = !0,
                        c = l.component;
                    "click" === n && (e = !1 !== t.Ub(l, 1).onClick() && e);
                    "participantClick" === n && (e = !1 !== c.onParticipantSelected("extra", l.context.$implicit.id) && e);
                    return e
                }), N, S)), t.Hb(1, 638976, null, 0, M, [], {
                    dorsal: [0, "dorsal"],
                    isActive: [1, "isActive"],
                    isDisabled: [2, "isDisabled"],
                    odd: [3, "odd"]
                }, {
                    participantClick: "participantClick"
                })], (function(l, n) {
                    var u = n.component,
                        t = n.context.$implicit.id,
                        e = u.isParticipantSelected("extra", n.context.$implicit.id),
                        c = !n.context.$implicit._clData.isEnabledToBet();
                    l(n, 1, 0, t, e, c, n.context.$implicit)
                }), null)
            }

            function wl(l) {
                return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 8, "grc-races-market-selector", [
                    ["class", "col races__market-container"]
                ], null, null, null, L, Y)), t.Hb(1, 114688, null, 0, Z, [], {
                    markets: [0, "markets"],
                    hasSelectAllButton: [1, "hasSelectAllButton"]
                }, null), (l()(), t.Ib(2, 0, null, 0, 6, "div", [
                    ["class", "grid races__participants races__paddings"]
                ], null, null, null, null, null)), (l()(), t.Ib(3, 0, null, null, 2, "div", [
                    ["class", "col col-6 grid grid-2"]
                ], null, null, null, null, null)), (l()(), t.xb(16777216, null, null, 1, null, vl)), t.Hb(5, 278528, null, 0, v.l, [t.eb, t.Z, t.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), (l()(), t.Ib(6, 0, null, null, 2, "div", [
                    ["class", "col col-6 grid grid-2"]
                ], null, null, null, null, null)), (l()(), t.xb(16777216, null, null, 1, null, yl)), t.Hb(8, 278528, null, 0, v.l, [t.eb, t.Z, t.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(l, n) {
                    var u = n.component;
                    l(n, 1, 0, u.selections.extra.tabs, !1);
                    var t;
                    l(n, 5, 0, null == (t = u.event.data._clData.marketMap.get(u.DogMarkets.even_odd)) ? null : t.odds);
                    var e;
                    l(n, 8, 0, null == (e = u.event.data._clData.marketMap.get(u.DogMarkets.over_under)) ? null : e.odds)
                }), null)
            }

            function Ml(l) {
                return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 1, "grc-races-participant", [
                    ["class", "col grc-races-participant"]
                ], [
                    [4, "padding-top", null]
                ], [
                    [null, "participantClick"],
                    [null, "click"]
                ], (function(l, n, u) {
                    var e = !0,
                        c = l.component;
                    "click" === n && (e = !1 !== t.Ub(l, 1).onClick() && e);
                    "participantClick" === n && (e = !1 !== c.onParticipantSelected("anyOrder", l.context.index + 1, c.selections.anyOrder.type) && e);
                    return e
                }), N, S)), t.Hb(1, 638976, null, 0, M, [], {
                    dorsal: [0, "dorsal"],
                    isActive: [1, "isActive"],
                    isDisabled: [2, "isDisabled"],
                    gameType: [3, "gameType"],
                    participant: [4, "participant"]
                }, {
                    participantClick: "participantClick"
                })], (function(l, n) {
                    var u = n.component;
                    l(n, 1, 0, n.context.index + 1, u.isParticipantSelected("anyOrder", n.context.index + 1), u.canSelectParticipantAnyOrder("anyOrder", u.selections.anyOrder.type, n.context.index + 1), u.gameType, n.context.$implicit)
                }), (function(l, n) {
                    var u = n.component;
                    l(n, 0, 0, n.context.index >= u.numParticipantsColumns ? "5px" : "0")
                }))
            }

            function jl(l) {
                return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 4, "grc-races-market-selector", [
                    ["class", "col races__market-container"]
                ], null, [
                    [null, "selectedChange"]
                ], (function(l, n, u) {
                    var t = !0,
                        e = l.component;
                    "selectedChange" === n && (t = !1 !== e.onChangeTab("anyOrder", u) && t);
                    return t
                }), L, Y)), t.Hb(1, 114688, null, 0, Z, [], {
                    markets: [0, "markets"],
                    hasSelectAllButton: [1, "hasSelectAllButton"],
                    selected: [2, "selected"]
                }, {
                    selectedChange: "selectedChange"
                }), (l()(), t.Ib(2, 0, null, 0, 2, "div", [], [
                    [8, "className", 0]
                ], null, null, null, null)), (l()(), t.xb(16777216, null, null, 1, null, Ml)), t.Hb(4, 278528, null, 0, v.l, [t.eb, t.Z, t.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(l, n) {
                    var u = n.component;
                    l(n, 1, 0, u.selections.anyOrder.tabs, !1, u.selections.anyOrder.type), l(n, 4, 0, u.event.data.participants)
                }), (function(l, n) {
                    var u = n.component;
                    l(n, 2, 0, t.Mb(1, "grid grid-", u.numParticipantsColumns, " races__participants"))
                }))
            }

            function Sl(l) {
                return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 28, "div", [
                    ["class", "races grid"]
                ], null, null, null, null, null)), (l()(), t.Ib(1, 0, null, null, 12, "div", [
                    ["class", "col grid grid-column"]
                ], null, null, null, null, null)), (l()(), t.Ib(2, 0, null, null, 4, "grc-races-market-selector", [
                    ["class", "col races__market-container"]
                ], null, [
                    [null, "selectedChange"],
                    [null, "selectAllClicked"]
                ], (function(l, n, u) {
                    var t = !0,
                        e = l.component;
                    "selectedChange" === n && (t = !1 !== e.onSpecialChangeTab("win", u) && t);
                    "selectAllClicked" === n && (t = !1 !== e.onWinSelectAllButtonClicked("win") && t);
                    return t
                }), L, Y)), t.Hb(3, 114688, null, 0, Z, [], {
                    markets: [0, "markets"],
                    selected: [1, "selected"]
                }, {
                    selectedChange: "selectedChange",
                    selectAllClicked: "selectAllClicked"
                }), (l()(), t.Ib(4, 0, null, 0, 2, "div", [], [
                    [8, "className", 0]
                ], null, null, null, null)), (l()(), t.xb(16777216, null, null, 1, null, kl)), t.Hb(6, 278528, null, 0, v.l, [t.eb, t.Z, t.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), (l()(), t.Ib(7, 0, null, null, 4, "grc-races-market-selector", [
                    ["class", "col races__market-container"]
                ], null, [
                    [null, "selectedChange"]
                ], (function(l, n, u) {
                    var t = !0,
                        e = l.component;
                    "selectedChange" === n && (t = !1 !== e.onChangeTab("doubleQuinella", u) && t);
                    return t
                }), L, Y)), t.Hb(8, 114688, null, 0, Z, [], {
                    markets: [0, "markets"],
                    hasSelectAllButton: [1, "hasSelectAllButton"],
                    selected: [2, "selected"],
                    isMarketEnabled: [3, "isMarketEnabled"]
                }, {
                    selectedChange: "selectedChange"
                }), (l()(), t.Ib(9, 0, null, 0, 2, "div", [], [
                    [8, "className", 0]
                ], null, null, null, null)), (l()(), t.xb(16777216, null, null, 1, null, ml)), t.Hb(11, 278528, null, 0, v.l, [t.eb, t.Z, t.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), (l()(), t.xb(16777216, null, null, 1, null, Il)), t.Hb(13, 16384, null, 0, v.m, [t.eb, t.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), t.Ib(14, 0, null, null, 14, "div", [
                    ["class", "col grid grid-column"]
                ], null, null, null, null, null)), (l()(), t.Ib(15, 0, null, null, 4, "grc-races-market-selector", [
                    ["class", "col races__market-container"]
                ], null, [
                    [null, "selectedChange"],
                    [null, "selectAllClicked"]
                ], (function(l, n, u) {
                    var t = !0,
                        e = l.component;
                    "selectedChange" === n && (t = !1 !== e.onSpecialChangeTab("placeShow", u) && t);
                    "selectAllClicked" === n && (t = !1 !== e.onSelectAllButtonClicked("placeShow") && t);
                    return t
                }), L, Y)), t.Hb(16, 114688, null, 0, Z, [], {
                    markets: [0, "markets"],
                    selected: [1, "selected"]
                }, {
                    selectedChange: "selectedChange",
                    selectAllClicked: "selectAllClicked"
                }), (l()(), t.Ib(17, 0, null, 0, 2, "div", [], [
                    [8, "className", 0]
                ], null, null, null, null)), (l()(), t.xb(16777216, null, null, 1, null, Ul)), t.Hb(19, 278528, null, 0, v.l, [t.eb, t.Z, t.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), (l()(), t.Ib(20, 0, null, null, 4, "grc-races-market-selector", [
                    ["class", "col races__market-container"]
                ], null, [
                    [null, "selectedChange"],
                    [null, "selectAllClicked"]
                ], (function(l, n, u) {
                    var t = !0,
                        e = l.component;
                    "selectedChange" === n && (t = !1 !== e.onChangeTab("system", u) && t);
                    "selectAllClicked" === n && (t = !1 !== e.onSelectAllButtonClicked("system") && t);
                    return t
                }), L, Y)), t.Hb(21, 114688, null, 0, Z, [], {
                    markets: [0, "markets"],
                    selected: [1, "selected"]
                }, {
                    selectedChange: "selectedChange",
                    selectAllClicked: "selectAllClicked"
                }), (l()(), t.Ib(22, 0, null, 0, 2, "div", [], [
                    [8, "className", 0]
                ], null, null, null, null)), (l()(), t.xb(16777216, null, null, 1, null, Wl)), t.Hb(24, 278528, null, 0, v.l, [t.eb, t.Z, t.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), (l()(), t.xb(16777216, null, null, 1, null, wl)), t.Hb(26, 16384, null, 0, v.m, [t.eb, t.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), t.xb(16777216, null, null, 1, null, jl)), t.Hb(28, 16384, null, 0, v.m, [t.eb, t.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(l, n) {
                    var u = n.component;
                    l(n, 3, 0, u.selections.win.tabs, u.selections.win.type), l(n, 6, 0, u.event.data.participants);
                    l(n, 8, 0, u.selections.doubleQuinella.tabs, !1, u.selections.doubleQuinella.type, u.isDoubleQuinellaMarketEnabled("win") && "win" === u.selections.win.type), l(n, 11, 0, u.event.data.participants), l(n, 13, 0, u.selections.trifecta.tabs.length > 0), l(n, 16, 0, u.selections.placeShow.tabs, u.selections.placeShow.type), l(n, 19, 0, u.event.data.participants), l(n, 21, 0, u.selections.system.tabs, u.selections.system.type), l(n, 24, 0, u.event.data.participants), l(n, 26, 0, u.selections.extra.tabs.length > 0 && u.event.data.participants.length < 10), l(n, 28, 0, 12 === u.event.data.participants.length)
                }), (function(l, n) {
                    var u = n.component;
                    l(n, 4, 0, t.Mb(1, "grid grid-", u.numParticipantsColumns, " races__participants")), l(n, 9, 0, t.Mb(1, "grid grid-", u.numParticipantsColumns, " races__participants")), l(n, 17, 0, t.Mb(1, "grid grid-", u.numParticipantsColumns, " races__participants")), l(n, 22, 0, t.Mb(1, "grid grid-", u.numParticipantsColumns, " races__participants"))
                }))
            }

            function xl(l) {
                return t.ec(2, [(l()(), t.xb(16777216, null, null, 1, null, Sl)), t.Hb(1, 16384, null, 0, v.m, [t.eb, t.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(l, n) {
                    l(n, 1, 0, n.component.selections)
                }), null)
            }
            var Cl = t.Eb("grc-page-races", hl, (function(l) {
                    return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 1, "grc-page-races", [], null, null, null, xl, _l)), t.Hb(1, 245760, null, 0, hl, [t.y, ul.a], null, null)], (function(l, n) {
                        l(n, 1, 0)
                    }), null)
                }), {
                    participant: "participant"
                }, {}, []),
                Ol = u("6nHF"),
                Pl = u("0ZGX"),
                Tl = [
                    [".fastbet-help-doghorse[_ngcontent-%COMP%]{max-width:1500px;max-height:985px;padding:30px;overflow-y:scroll;font-family:OpenSans;font-size:16px}.fastbet-help-doghorse__row[_ngcontent-%COMP%]{line-height:20px}.fastbet-help-doghorse__row[_ngcontent-%COMP%]:not(:first-child)   td[_ngcontent-%COMP%]:not(:last-child){text-transform:uppercase}.fastbet-help-doghorse__row[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]{padding:16px 0 16px 18px}.fastbet-help-doghorse__row[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:first-child{width:20%;font-weight:700}.fastbet-help-doghorse__row[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:nth-child(2), .fastbet-help-doghorse__row[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:nth-child(3){width:20%}.fastbet-help-doghorse__row[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:last-child{width:30%;padding-right:16px}.fastbet-help-doghorse__title[_ngcontent-%COMP%]{font-size:28px;font-weight:700;text-transform:capitalize}.fastbet-help-doghorse__codes[_ngcontent-%COMP%]{width:100%;margin-top:10px;margin-bottom:21px;font-size:16px}.fastbet-help-doghorse__close[_ngcontent-%COMP%]{position:absolute;top:30px;right:55px;z-index:99999;font-size:24px;cursor:pointer}"]
                ],
                Al = t.Gb({
                    encapsulation: 0,
                    styles: Tl,
                    data: {}
                });

            function El(l) {
                return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(1, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(2, null, ["", ""])), t.Wb(131072, W.q, [W.k, t.i]), (l()(), t.Ib(4, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(5, null, ["Y4 [4 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(7, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(8, null, ["Y41-2-3-4+5 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(10, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(11, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(13, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i])], null, (function(l, n) {
                    l(n, 2, 0, t.dc(n, 2, 0, t.Ub(n, 3).transform("system_four"))), l(n, 5, 0, t.dc(n, 5, 0, t.Ub(n, 6).transform("ch_selections"))), l(n, 8, 0, t.dc(n, 8, 0, t.Ub(n, 9).transform("ch_return")));
                    var u = t.dc(n, 11, 0, t.Ub(n, 14).transform("ch_combination_fourth", l(n, 13, 0, t.dc(n, 11, 0, t.Ub(n, 12).transform(5)))));
                    l(n, 11, 0, u)
                }))
            }

            function Hl(l) {
                return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 28, null, null, null, null, null, null, null)), (l()(), t.Ib(1, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(2, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(3, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(5, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["DI / PA"])), (l()(), t.Ib(7, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(8, null, ["PA+7 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(10, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(11, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(13, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(15, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(16, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(17, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(19, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["O / U"])), (l()(), t.Ib(21, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(22, null, ["O+8 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(24, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(25, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(27, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i])], null, (function(l, n) {
                    var u = n.component;
                    l(n, 3, 0, t.dc(n, 3, 0, t.Ub(n, 4).transform(u.HorseMarkets.even_odd))), l(n, 8, 0, t.dc(n, 8, 0, t.Ub(n, 9).transform("ch_return")));
                    var e = t.dc(n, 11, 0, t.Ub(n, 14).transform("ch_winner_even", l(n, 13, 0, t.dc(n, 11, 0, t.Ub(n, 12).transform(7)))));
                    l(n, 11, 0, e), l(n, 17, 0, t.dc(n, 17, 0, t.Ub(n, 18).transform(u.HorseMarkets.over_under))), l(n, 22, 0, t.dc(n, 22, 0, t.Ub(n, 23).transform("ch_return")));
                    var c = t.dc(n, 25, 0, t.Ub(n, 28).transform("ch_winner_higher_half_range", l(n, 27, 0, t.dc(n, 25, 0, t.Ub(n, 26).transform(8)))));
                    l(n, 25, 0, c)
                }))
            }

            function Xl(l) {
                return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(1, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(2, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(4, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(5, null, ["S [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(7, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(8, null, ["S7+5 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(10, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(11, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(13, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(15, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(16, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(17, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(19, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(20, null, ["TA [3 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(22, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(23, null, ["TA4-8-10+8 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(25, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(26, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(28, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(30, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(31, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(32, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(34, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(35, null, ["FA [4 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(37, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(38, null, ["FA1-3-5-9+5 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(40, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(41, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(43, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(45, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(46, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(47, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(49, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(50, null, ["F [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(52, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(53, null, ["F3+7 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(55, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(56, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(58, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i])], null, (function(l, n) {
                    var u = n.component;
                    l(n, 2, 0, t.dc(n, 2, 0, t.Ub(n, 3).transform(u.HorseMarkets.second_place))), l(n, 5, 0, t.dc(n, 5, 0, t.Ub(n, 6).transform("ch_selection"))), l(n, 8, 0, t.dc(n, 8, 0, t.Ub(n, 9).transform("ch_return")));
                    var e = t.dc(n, 11, 0, t.Ub(n, 14).transform("ch_7_2nd", l(n, 13, 0, t.dc(n, 11, 0, t.Ub(n, 12).transform(5)))));
                    l(n, 11, 0, e), l(n, 17, 0, t.dc(n, 17, 0, t.Ub(n, 18).transform(u.HorseMarkets.three_any_order))), l(n, 20, 0, t.dc(n, 20, 0, t.Ub(n, 21).transform("ch_selections"))), l(n, 23, 0, t.dc(n, 23, 0, t.Ub(n, 24).transform("ch_return")));
                    var c = t.dc(n, 26, 0, t.Ub(n, 29).transform("ch_4_8_10_1st_2nd_3rd", l(n, 28, 0, t.dc(n, 26, 0, t.Ub(n, 27).transform(8)))));
                    l(n, 26, 0, c), l(n, 32, 0, t.dc(n, 32, 0, t.Ub(n, 33).transform(u.HorseMarkets.four_any_order))), l(n, 35, 0, t.dc(n, 35, 0, t.Ub(n, 36).transform("ch_selections"))), l(n, 38, 0, t.dc(n, 38, 0, t.Ub(n, 39).transform("ch_return")));
                    var r = t.dc(n, 41, 0, t.Ub(n, 44).transform("ch_1_3_5_9_1st_2nd_3rd_4th", l(n, 43, 0, t.dc(n, 41, 0, t.Ub(n, 42).transform(5)))));
                    l(n, 41, 0, r), l(n, 47, 0, t.dc(n, 47, 0, t.Ub(n, 48).transform(u.HorseMarkets.fourth_place_worse))), l(n, 50, 0, t.dc(n, 50, 0, t.Ub(n, 51).transform("ch_selection"))), l(n, 53, 0, t.dc(n, 53, 0, t.Ub(n, 54).transform("ch_return")));
                    var a = t.dc(n, 56, 0, t.Ub(n, 59).transform("ch_3_4th_or_worse", l(n, 58, 0, t.dc(n, 56, 0, t.Ub(n, 57).transform(7)))));
                    l(n, 56, 0, a)
                }))
            }

            function Dl(l) {
                return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 15, null, null, null, null, null, null, null)), (l()(), t.Ib(1, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(2, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(3, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(5, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(6, null, ["FAX [5-12 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(8, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(9, null, ["FAX1-7-3-5-2+4 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(11, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(12, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(14, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i])], null, (function(l, n) {
                    var u = n.component;
                    l(n, 3, 0, t.dc(n, 3, 0, t.Ub(n, 4).transform(u.HorseMarkets.four_any_order))), l(n, 6, 0, t.dc(n, 6, 0, t.Ub(n, 7).transform("ch_slctns"))), l(n, 9, 0, t.dc(n, 9, 0, t.Ub(n, 10).transform("ch_return")));
                    var e = t.dc(n, 12, 0, t.Ub(n, 15).transform("ch_1_7_3_5_2_1st_2nd_3rd_4th_combination", l(n, 14, 0, t.dc(n, 12, 0, t.Ub(n, 13).transform(4)))));
                    l(n, 12, 0, e)
                }))
            }

            function Bl(l) {
                return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 28, null, null, null, null, null, null, null)), (l()(), t.Ib(1, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(2, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(3, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(5, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["DP%"])), (l()(), t.Ib(7, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(8, null, ["DP%+7 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(10, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(11, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(13, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(15, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(16, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(17, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(19, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["OU%"])), (l()(), t.Ib(21, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(22, null, ["OU%+8 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(24, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(25, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(27, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i])], null, (function(l, n) {
                    var u = n.component;
                    l(n, 3, 0, t.dc(n, 3, 0, t.Ub(n, 4).transform(u.HorseMarkets.even_odd))), l(n, 8, 0, t.dc(n, 8, 0, t.Ub(n, 9).transform("ch_return")));
                    var e = t.dc(n, 11, 0, t.Ub(n, 14).transform("ch_winner_even_odd", l(n, 13, 0, t.dc(n, 11, 0, t.Ub(n, 12).transform(7)))));
                    l(n, 11, 0, e), l(n, 17, 0, t.dc(n, 17, 0, t.Ub(n, 18).transform(u.HorseMarkets.over_under))), l(n, 22, 0, t.dc(n, 22, 0, t.Ub(n, 23).transform("ch_return")));
                    var c = t.dc(n, 25, 0, t.Ub(n, 28).transform("ch_winner_higher_lower_range", l(n, 27, 0, t.dc(n, 25, 0, t.Ub(n, 26).transform(8)))));
                    l(n, 25, 0, c)
                }))
            }

            function Nl(l) {
                return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(1, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(2, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(4, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["S%"])), (l()(), t.Ib(6, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(7, null, ["S%+5 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(9, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(10, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(12, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(14, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(15, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(16, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(18, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["TA%"])), (l()(), t.Ib(20, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(21, null, ["TA%+8 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(23, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(24, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(26, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(28, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(29, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(30, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(32, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["FA%"])), (l()(), t.Ib(34, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(35, null, ["FA%+5 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(37, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(38, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(40, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(42, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(43, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(44, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(46, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["F%"])), (l()(), t.Ib(48, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(49, null, ["F%+7 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(51, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(52, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(54, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i])], null, (function(l, n) {
                    var u = n.component;
                    l(n, 2, 0, t.dc(n, 2, 0, t.Ub(n, 3).transform(u.HorseMarkets.second_place))), l(n, 7, 0, t.dc(n, 7, 0, t.Ub(n, 8).transform("ch_return")));
                    var e = t.dc(n, 10, 0, t.Ub(n, 13).transform("ch_random_second", l(n, 12, 0, t.dc(n, 10, 0, t.Ub(n, 11).transform(5)))));
                    l(n, 10, 0, e), l(n, 16, 0, t.dc(n, 16, 0, t.Ub(n, 17).transform(u.HorseMarkets.three_any_order))), l(n, 21, 0, t.dc(n, 21, 0, t.Ub(n, 22).transform("ch_return")));
                    var c = t.dc(n, 24, 0, t.Ub(n, 27).transform("ch_random_1st_2nd_3rd", l(n, 26, 0, t.dc(n, 24, 0, t.Ub(n, 25).transform(8)))));
                    l(n, 24, 0, c), l(n, 30, 0, t.dc(n, 30, 0, t.Ub(n, 31).transform(u.HorseMarkets.four_any_order))), l(n, 35, 0, t.dc(n, 35, 0, t.Ub(n, 36).transform("ch_return")));
                    var r = t.dc(n, 38, 0, t.Ub(n, 41).transform("ch_random_1st_2nd_3rd_4th", l(n, 40, 0, t.dc(n, 38, 0, t.Ub(n, 39).transform(5)))));
                    l(n, 38, 0, r), l(n, 44, 0, t.dc(n, 44, 0, t.Ub(n, 45).transform(u.HorseMarkets.fourth_place_worse))), l(n, 49, 0, t.dc(n, 49, 0, t.Ub(n, 50).transform("ch_return")));
                    var a = t.dc(n, 52, 0, t.Ub(n, 55).transform("ch_random_4th_or_worse", l(n, 54, 0, t.dc(n, 52, 0, t.Ub(n, 53).transform(7)))));
                    l(n, 52, 0, a)
                }))
            }

            function Fl(l) {
                return t.ec(2, [(l()(), t.Ib(0, 0, null, null, 335, "div", [
                    ["class", "fastbet-help-doghorse"]
                ], null, null, null, null, null)), (l()(), t.Ib(1, 0, null, null, 0, "div", [
                    ["class", "fastbet-help-doghorse__close icon icon-cancel"]
                ], null, [
                    [null, "click"]
                ], (function(l, n, u) {
                    var t = !0,
                        e = l.component;
                    "click" === n && (t = !1 !== e.close.emit() && t);
                    return t
                }), null, null)), (l()(), t.Ib(2, 0, null, null, 1, "gr-fastbet-help-header", [], null, null, null, Ol.b, Ol.a)), t.Hb(3, 114688, null, 0, Pl.a, [], {
                    title: [0, "title"],
                    hasEnterSystemSection: [1, "hasEnterSystemSection"]
                }, null), (l()(), t.Ib(4, 0, null, null, 2, "h1", [
                    ["class", "fastbet-help-doghorse__title"]
                ], null, null, null, null, null)), (l()(), t.cc(5, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(7, 0, null, null, 138, "table", [
                    ["class", "fastbet-help-doghorse__codes"]
                ], null, null, null, null, null)), (l()(), t.Ib(8, 0, null, null, 12, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(9, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(10, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(12, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(13, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(15, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(16, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(18, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(19, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(21, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(22, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(23, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(25, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(26, null, ["V [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(28, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(29, null, ["V5+1 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(31, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(32, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(34, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(36, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(37, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(38, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(40, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(41, null, ["AO [2 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(43, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(44, null, ["AO1-5+2 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(46, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(47, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(49, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(51, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(52, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(53, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(55, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(56, null, ["AS [2 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(58, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(59, null, ["AS4-2+3 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(61, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(62, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(64, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(66, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(67, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(68, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(70, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(71, null, ["T [3 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(73, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(74, null, ["T3-1-4+4 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(76, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(77, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(79, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(81, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(82, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(83, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(85, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(86, null, ["2P [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(88, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(89, null, ["2P4+5 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(91, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(92, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(94, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(96, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(97, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(98, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(100, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(101, null, ["3P [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(103, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(104, null, ["3P6+6 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(106, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(107, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(109, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(111, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(112, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(113, null, ["", ""])), t.Wb(131072, W.q, [W.k, t.i]), (l()(), t.Ib(115, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(116, null, ["Y2 [2 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(118, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(119, null, ["Y21-4+5 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(121, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(122, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(124, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(126, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(127, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(128, null, ["", ""])), t.Wb(131072, W.q, [W.k, t.i]), (l()(), t.Ib(130, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(131, null, ["Y3 [3 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(133, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(134, null, ["Y32-3-6+6 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(136, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(137, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(139, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.xb(16777216, null, null, 1, null, El)), t.Hb(142, 16384, null, 0, v.m, [t.eb, t.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), t.xb(16777216, null, null, 1, null, Hl)), t.Hb(144, 16384, null, 0, v.m, [t.eb, t.Z], {
                    ngIf: [0, "ngIf"],
                    ngIfElse: [1, "ngIfElse"]
                }, null), (l()(), t.xb(0, [
                    ["throttingMarketsTemplate", 2]
                ], null, 0, null, Xl)), (l()(), t.Ib(146, 0, null, null, 0, "br", [], null, null, null, null, null)), (l()(), t.Ib(147, 0, null, null, 3, "h1", [
                    ["class", "fastbet-help-doghorse__title"]
                ], null, null, null, null, null)), (l()(), t.cc(148, null, ["", " ( ", ")"])), t.Wb(131072, W.j, [W.k, t.i]), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(151, 0, null, null, 78, "table", [
                    ["class", "fastbet-help-doghorse__codes"]
                ], null, null, null, null, null)), (l()(), t.Ib(152, 0, null, null, 12, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(153, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(154, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(156, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(157, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(159, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(160, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(162, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(163, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(165, 0, null, null, 15, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(166, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(167, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(169, 0, null, null, 3, "td", [], null, null, null, null, null)), (l()(), t.cc(170, null, ["VX [", "] / [2-5 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(173, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(174, null, ["VX3/1-2-4+1 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(176, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(177, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(179, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(181, 0, null, null, 15, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(182, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(183, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(185, 0, null, null, 3, "td", [], null, null, null, null, null)), (l()(), t.cc(186, null, ["AX [2-5 ", "] / [1-4 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(189, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(190, null, ["AX1-2/3-4+2 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(192, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(193, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(195, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(197, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(198, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(199, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(201, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(202, null, ["TNX [3-6 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(204, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(205, null, ["TNX1-2-3-4+3 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(207, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(208, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(210, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(212, 0, null, null, 15, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(213, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(214, null, ["1 ", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(216, 0, null, null, 3, "td", [], null, null, null, null, null)), (l()(), t.cc(217, null, ["1PX [", "] / [2-5 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(220, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(221, null, ["1PX1/2-3-4+4 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(223, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(224, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(226, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.xb(16777216, null, null, 1, null, Dl)), t.Hb(229, 16384, null, 0, v.m, [t.eb, t.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), t.Ib(230, 0, null, null, 0, "br", [], null, null, null, null, null)), (l()(), t.Ib(231, 0, null, null, 3, "h1", [
                    ["class", "fastbet-help-doghorse__title"]
                ], null, null, null, null, null)), (l()(), t.cc(232, null, ["", " ( ", ")"])), t.Wb(131072, W.j, [W.k, t.i]), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(235, 0, null, null, 100, "table", [
                    ["class", "fastbet-help-doghorse__codes"]
                ], null, null, null, null, null)), (l()(), t.Ib(236, 0, null, null, 12, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(237, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(238, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(240, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(241, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(243, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(244, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(246, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(247, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(249, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(250, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(251, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(253, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["V%"])), (l()(), t.Ib(255, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(256, null, ["V%+1 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(258, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(259, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(261, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(263, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(264, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(265, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(267, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["AO%"])), (l()(), t.Ib(269, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(270, null, ["AO%+2 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(272, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(273, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(275, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(277, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(278, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(279, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(281, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["AS%"])), (l()(), t.Ib(283, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(284, null, ["AS%+3 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(286, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(287, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(289, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(291, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(292, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(293, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(295, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["T%"])), (l()(), t.Ib(297, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(298, null, ["T%+4 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(300, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(301, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(303, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(305, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(306, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(307, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(309, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["2P%"])), (l()(), t.Ib(311, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(312, null, ["2P%+5 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(314, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(315, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(317, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(319, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-doghorse__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(320, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(321, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(323, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["3P%"])), (l()(), t.Ib(325, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(326, null, ["3P%+6 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(328, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(329, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(331, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.xb(16777216, null, null, 1, null, Bl)), t.Hb(334, 16384, null, 0, v.m, [t.eb, t.Z], {
                    ngIf: [0, "ngIf"],
                    ngIfElse: [1, "ngIfElse"]
                }, null), (l()(), t.xb(0, [
                    ["throttingRandomMarketsTemplate", 2]
                ], null, 0, null, Nl))], (function(l, n) {
                    var u = n.component;
                    l(n, 3, 0, u.title, u.hasEnterSystemSection), l(n, 142, 0, 12 === u.participants), l(n, 144, 0, !u.throttingMarketsEnable, t.Ub(n, 145)), l(n, 229, 0, u.throttingMarketsEnable), l(n, 334, 0, !u.throttingMarketsEnable, t.Ub(n, 335))
                }), (function(l, n) {
                    var u = n.component;
                    l(n, 5, 0, t.dc(n, 5, 0, t.Ub(n, 6).transform("ch_codes"))), l(n, 10, 0, t.dc(n, 10, 0, t.Ub(n, 11).transform("ch_market"))), l(n, 13, 0, t.dc(n, 13, 0, t.Ub(n, 14).transform("ch_code"))), l(n, 16, 0, t.dc(n, 16, 0, t.Ub(n, 17).transform("ch_examples"))), l(n, 19, 0, t.dc(n, 19, 0, t.Ub(n, 20).transform("ch_description"))), l(n, 23, 0, t.dc(n, 23, 0, t.Ub(n, 24).transform(u.HorseMarkets.win))), l(n, 26, 0, t.dc(n, 26, 0, t.Ub(n, 27).transform("ch_selection"))), l(n, 29, 0, t.dc(n, 29, 0, t.Ub(n, 30).transform("ch_return")));
                    var e = t.dc(n, 32, 0, t.Ub(n, 35).transform("ch_5_1st", l(n, 34, 0, t.dc(n, 32, 0, t.Ub(n, 33).transform(1)))));
                    l(n, 32, 0, e), l(n, 38, 0, t.dc(n, 38, 0, t.Ub(n, 39).transform(u.HorseMarkets.exacta))), l(n, 41, 0, t.dc(n, 41, 0, t.Ub(n, 42).transform("ch_selections"))), l(n, 44, 0, t.dc(n, 44, 0, t.Ub(n, 45).transform("ch_return")));
                    var c = t.dc(n, 47, 0, t.Ub(n, 50).transform("ch_1_1st_5_2nd", l(n, 49, 0, t.dc(n, 47, 0, t.Ub(n, 48).transform(2)))));
                    l(n, 47, 0, c), l(n, 53, 0, t.dc(n, 53, 0, t.Ub(n, 54).transform(u.HorseMarkets.quinella))), l(n, 56, 0, t.dc(n, 56, 0, t.Ub(n, 57).transform("ch_selections"))), l(n, 59, 0, t.dc(n, 59, 0, t.Ub(n, 60).transform("ch_return")));
                    var r = t.dc(n, 62, 0, t.Ub(n, 65).transform("ch_4_2_1st_2nd", l(n, 64, 0, t.dc(n, 62, 0, t.Ub(n, 63).transform(3)))));
                    l(n, 62, 0, r), l(n, 68, 0, t.dc(n, 68, 0, t.Ub(n, 69).transform(u.HorseMarkets.trifecta))), l(n, 71, 0, t.dc(n, 71, 0, t.Ub(n, 72).transform("ch_selections"))), l(n, 74, 0, t.dc(n, 74, 0, t.Ub(n, 75).transform("ch_return")));
                    var a = t.dc(n, 77, 0, t.Ub(n, 80).transform("ch_3_1st_1_2nd_4_3rd", l(n, 79, 0, t.dc(n, 77, 0, t.Ub(n, 78).transform(4)))));
                    l(n, 77, 0, a), l(n, 83, 0, t.dc(n, 83, 0, t.Ub(n, 84).transform(u.HorseMarkets.place))), l(n, 86, 0, t.dc(n, 86, 0, t.Ub(n, 87).transform("ch_selection"))), l(n, 89, 0, t.dc(n, 89, 0, t.Ub(n, 90).transform("ch_return")));
                    var s = t.dc(n, 92, 0, t.Ub(n, 95).transform("ch_4_1st_2nd", l(n, 94, 0, t.dc(n, 92, 0, t.Ub(n, 93).transform(5)))));
                    l(n, 92, 0, s), l(n, 98, 0, t.dc(n, 98, 0, t.Ub(n, 99).transform(u.HorseMarkets.show))), l(n, 101, 0, t.dc(n, 101, 0, t.Ub(n, 102).transform("ch_selection"))), l(n, 104, 0, t.dc(n, 104, 0, t.Ub(n, 105).transform("ch_return")));
                    var i = t.dc(n, 107, 0, t.Ub(n, 110).transform("ch_6_1st_2nd_3rd", l(n, 109, 0, t.dc(n, 107, 0, t.Ub(n, 108).transform(6)))));
                    l(n, 107, 0, i), l(n, 113, 0, t.dc(n, 113, 0, t.Ub(n, 114).transform("system_two"))), l(n, 116, 0, t.dc(n, 116, 0, t.Ub(n, 117).transform("ch_selections"))), l(n, 119, 0, t.dc(n, 119, 0, t.Ub(n, 120).transform("ch_return")));
                    var o = t.dc(n, 122, 0, t.Ub(n, 125).transform("ch_combination_double", l(n, 124, 0, t.dc(n, 122, 0, t.Ub(n, 123).transform(5)))));
                    l(n, 122, 0, o), l(n, 128, 0, t.dc(n, 128, 0, t.Ub(n, 129).transform("system_three"))), l(n, 131, 0, t.dc(n, 131, 0, t.Ub(n, 132).transform("ch_selections"))), l(n, 134, 0, t.dc(n, 134, 0, t.Ub(n, 135).transform("ch_return")));
                    var b = t.dc(n, 137, 0, t.Ub(n, 140).transform("ch_combination_triple", l(n, 139, 0, t.dc(n, 137, 0, t.Ub(n, 138).transform(6)))));
                    l(n, 137, 0, b), l(n, 148, 0, t.dc(n, 148, 0, t.Ub(n, 149).transform("ch_codes")), t.dc(n, 148, 1, t.Ub(n, 150).transform("ch_combination_bets"))), l(n, 154, 0, t.dc(n, 154, 0, t.Ub(n, 155).transform("ch_market"))), l(n, 157, 0, t.dc(n, 157, 0, t.Ub(n, 158).transform("ch_code"))), l(n, 160, 0, t.dc(n, 160, 0, t.Ub(n, 161).transform("ch_examples"))), l(n, 163, 0, t.dc(n, 163, 0, t.Ub(n, 164).transform("ch_description"))), l(n, 167, 0, t.dc(n, 167, 0, t.Ub(n, 168).transform("ch_winning_trio"))), l(n, 170, 0, t.dc(n, 170, 0, t.Ub(n, 171).transform("ch_slctn")), t.dc(n, 170, 1, t.Ub(n, 172).transform("ch_slctns"))), l(n, 174, 0, t.dc(n, 174, 0, t.Ub(n, 175).transform("ch_return")));
                    var d = t.dc(n, 177, 0, t.Ub(n, 180).transform("ch_3_1st_combination", l(n, 179, 0, t.dc(n, 177, 0, t.Ub(n, 178).transform(1)))));
                    l(n, 177, 0, d), l(n, 183, 0, t.dc(n, 183, 0, t.Ub(n, 184).transform("ch_coupled_trio"))), l(n, 186, 0, t.dc(n, 186, 0, t.Ub(n, 187).transform("ch_slctns")), t.dc(n, 186, 1, t.Ub(n, 188).transform("ch_slctns"))), l(n, 190, 0, t.dc(n, 190, 0, t.Ub(n, 191).transform("ch_return")));
                    var p = t.dc(n, 193, 0, t.Ub(n, 196).transform("ch_1_2_1st_2nd_combination", l(n, 195, 0, t.dc(n, 193, 0, t.Ub(n, 194).transform(2)))));
                    l(n, 193, 0, p), l(n, 199, 0, t.dc(n, 199, 0, t.Ub(n, 200).transform("ch_turning_trio"))), l(n, 202, 0, t.dc(n, 202, 0, t.Ub(n, 203).transform("ch_selections"))), l(n, 205, 0, t.dc(n, 205, 0, t.Ub(n, 206).transform("ch_return")));
                    var h = t.dc(n, 208, 0, t.Ub(n, 211).transform("ch_subset_participants", l(n, 210, 0, t.dc(n, 208, 0, t.Ub(n, 209).transform(3)))));
                    l(n, 208, 0, h), l(n, 214, 0, t.dc(n, 214, 0, t.Ub(n, 215).transform("ch_located_trio"))), l(n, 217, 0, t.dc(n, 217, 0, t.Ub(n, 218).transform("ch_slctn")), t.dc(n, 217, 1, t.Ub(n, 219).transform("ch_slctns"))), l(n, 221, 0, t.dc(n, 221, 0, t.Ub(n, 222).transform("ch_return")));
                    var f = t.dc(n, 224, 0, t.Ub(n, 227).transform("ch_1_1st_2nd_3rd_subset", l(n, 226, 0, t.dc(n, 224, 0, t.Ub(n, 225).transform(4)))));
                    l(n, 224, 0, f), l(n, 232, 0, t.dc(n, 232, 0, t.Ub(n, 233).transform("ch_codes")), t.dc(n, 232, 1, t.Ub(n, 234).transform("ch_random"))), l(n, 238, 0, t.dc(n, 238, 0, t.Ub(n, 239).transform("ch_market"))), l(n, 241, 0, t.dc(n, 241, 0, t.Ub(n, 242).transform("ch_code"))), l(n, 244, 0, t.dc(n, 244, 0, t.Ub(n, 245).transform("ch_examples"))), l(n, 247, 0, t.dc(n, 247, 0, t.Ub(n, 248).transform("ch_description"))), l(n, 251, 0, t.dc(n, 251, 0, t.Ub(n, 252).transform(u.HorseMarkets.win))), l(n, 256, 0, t.dc(n, 256, 0, t.Ub(n, 257).transform("ch_return")));
                    var _ = t.dc(n, 259, 0, t.Ub(n, 262).transform("ch_random_winner", l(n, 261, 0, t.dc(n, 259, 0, t.Ub(n, 260).transform(1)))));
                    l(n, 259, 0, _), l(n, 265, 0, t.dc(n, 265, 0, t.Ub(n, 266).transform(u.HorseMarkets.exacta))), l(n, 270, 0, t.dc(n, 270, 0, t.Ub(n, 271).transform("ch_return")));
                    var k = t.dc(n, 273, 0, t.Ub(n, 276).transform("ch_1st_2nd", l(n, 275, 0, t.dc(n, 273, 0, t.Ub(n, 274).transform(2)))));
                    l(n, 273, 0, k), l(n, 279, 0, t.dc(n, 279, 0, t.Ub(n, 280).transform(u.HorseMarkets.quinella))), l(n, 284, 0, t.dc(n, 284, 0, t.Ub(n, 285).transform("ch_return")));
                    var m = t.dc(n, 287, 0, t.Ub(n, 290).transform("ch_random_1st_2nd", l(n, 289, 0, t.dc(n, 287, 0, t.Ub(n, 288).transform(3)))));
                    l(n, 287, 0, m), l(n, 293, 0, t.dc(n, 293, 0, t.Ub(n, 294).transform(u.HorseMarkets.trifecta))), l(n, 298, 0, t.dc(n, 298, 0, t.Ub(n, 299).transform("ch_return")));
                    var g = t.dc(n, 301, 0, t.Ub(n, 304).transform("ch_1st_2nd_3rd", l(n, 303, 0, t.dc(n, 301, 0, t.Ub(n, 302).transform(4)))));
                    l(n, 301, 0, g), l(n, 307, 0, t.dc(n, 307, 0, t.Ub(n, 308).transform(u.HorseMarkets.place))), l(n, 312, 0, t.dc(n, 312, 0, t.Ub(n, 313).transform("ch_return")));
                    var I = t.dc(n, 315, 0, t.Ub(n, 318).transform("ch_participant_1st_2nd", l(n, 317, 0, t.dc(n, 315, 0, t.Ub(n, 316).transform(5)))));
                    l(n, 315, 0, I), l(n, 321, 0, t.dc(n, 321, 0, t.Ub(n, 322).transform(u.HorseMarkets.show))), l(n, 326, 0, t.dc(n, 326, 0, t.Ub(n, 327).transform("ch_return")));
                    var U = t.dc(n, 329, 0, t.Ub(n, 332).transform("ch_random_participant_1st_2nd_3rd", l(n, 331, 0, t.dc(n, 329, 0, t.Ub(n, 330).transform(6)))));
                    l(n, 329, 0, U)
                }))
            }
            var Gl = t.Eb("gr-fastbet-help-doghorse", rl, (function(l) {
                    return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 1, "gr-fastbet-help-doghorse", [], null, null, null, Fl, Al)), t.Hb(1, 114688, null, 0, rl, [W.k], null, null)], (function(l, n) {
                        l(n, 1, 0)
                    }), null)
                }), {
                    participants: "participants",
                    throttingMarketsEnable: "throttingMarketsEnable"
                }, {
                    close: "close"
                }, []),
                zl = [
                    [".fastbet-help-kart[_ngcontent-%COMP%]{max-width:1500px;max-height:985px;padding:30px;overflow-y:scroll;font-family:OpenSans;font-size:16px}.fastbet-help-kart__row[_ngcontent-%COMP%]{line-height:20px}.fastbet-help-kart__row[_ngcontent-%COMP%]:not(:first-child)   td[_ngcontent-%COMP%]:not(:last-child){text-transform:uppercase}.fastbet-help-kart__row[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]{padding:16px 0 16px 18px}.fastbet-help-kart__row[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:first-child{width:20%;font-weight:700}.fastbet-help-kart__row[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:nth-child(2), .fastbet-help-kart__row[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:nth-child(3){width:20%}.fastbet-help-kart__row[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:last-child{width:30%;padding-right:16px}.fastbet-help-kart__title[_ngcontent-%COMP%]{font-size:28px;font-weight:700;text-transform:capitalize}.fastbet-help-kart__codes[_ngcontent-%COMP%]{width:100%;margin-top:10px;margin-bottom:21px;font-size:16px}.fastbet-help-kart__close[_ngcontent-%COMP%]{position:absolute;top:30px;right:55px;z-index:99999;font-size:24px;cursor:pointer}"]
                ],
                Rl = t.Gb({
                    encapsulation: 0,
                    styles: zl,
                    data: {}
                });

            function Vl(l) {
                return t.ec(2, [(l()(), t.Ib(0, 0, null, null, 381, "div", [
                    ["class", "fastbet-help-kart"]
                ], null, null, null, null, null)), (l()(), t.Ib(1, 0, null, null, 0, "div", [
                    ["class", "fastbet-help-kart__close icon icon-cancel"]
                ], null, [
                    [null, "click"]
                ], (function(l, n, u) {
                    var t = !0,
                        e = l.component;
                    "click" === n && (t = !1 !== e.close.emit() && t);
                    return t
                }), null, null)), (l()(), t.Ib(2, 0, null, null, 1, "gr-fastbet-help-header", [], null, null, null, Ol.b, Ol.a)), t.Hb(3, 114688, null, 0, Pl.a, [], {
                    title: [0, "title"],
                    hasEnterSystemSection: [1, "hasEnterSystemSection"]
                }, null), (l()(), t.Ib(4, 0, null, null, 2, "h1", [
                    ["class", "fastbet-help-kart__title"]
                ], null, null, null, null, null)), (l()(), t.cc(5, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(7, 0, null, null, 161, "table", [
                    ["class", "fastbet-help-kart__codes"]
                ], null, null, null, null, null)), (l()(), t.Ib(8, 0, null, null, 12, "tr", [
                    ["class", "fastbet-help-kart__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(9, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(10, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(12, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(13, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(15, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(16, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(18, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(19, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(21, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-kart__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(22, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(23, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(25, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(26, null, ["V [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(28, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(29, null, ["V5+1 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(31, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(32, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(34, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(36, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-kart__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(37, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(38, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(40, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(41, null, ["AO [2 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(43, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(44, null, ["AO1-5+2 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(46, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(47, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(49, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(51, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-kart__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(52, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(53, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(55, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(56, null, ["AS [2 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(58, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(59, null, ["AS4-2+3 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(61, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(62, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(64, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(66, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-kart__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(67, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(68, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(70, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(71, null, ["T [3 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(73, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(74, null, ["T3-1-4+4 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(76, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(77, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(79, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(81, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-kart__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(82, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(83, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(85, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(86, null, ["2P [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(88, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(89, null, ["2P4+5 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(91, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(92, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(94, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(96, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-kart__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(97, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(98, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(100, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(101, null, ["3P [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(103, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(104, null, ["3P6+6 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(106, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(107, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(109, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(111, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-kart__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(112, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(113, null, ["", ""])), t.Wb(131072, W.q, [W.k, t.i]), (l()(), t.Ib(115, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(116, null, ["Y2 [2 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(118, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(119, null, ["Y21-4+5 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(121, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(122, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(124, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(126, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-kart__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(127, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(128, null, ["", ""])), t.Wb(131072, W.q, [W.k, t.i]), (l()(), t.Ib(130, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(131, null, ["Y3 [3 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(133, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(134, null, ["Y32-3-6+6 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(136, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(137, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(139, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(141, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-kart__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(142, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(143, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(145, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["DI / PA"])), (l()(), t.Ib(147, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(148, null, ["PA+7 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(150, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(151, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(153, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(155, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-kart__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(156, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(157, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(159, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["O / U"])), (l()(), t.Ib(161, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(162, null, ["O+8 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(164, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(165, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(167, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(169, 0, null, null, 0, "br", [], null, null, null, null, null)), (l()(), t.Ib(170, 0, null, null, 3, "h1", [
                    ["class", "fastbet-help-kart__title"]
                ], null, null, null, null, null)), (l()(), t.cc(171, null, ["", " (", ")"])), t.Wb(131072, W.j, [W.k, t.i]), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(174, 0, null, null, 76, "table", [
                    ["class", "fastbet-help-kart__codes"]
                ], null, null, null, null, null)), (l()(), t.Ib(175, 0, null, null, 12, "tr", [
                    ["class", "fastbet-help-kart__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(176, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(177, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(179, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(180, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(182, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(183, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(185, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(186, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(188, 0, null, null, 15, "tr", [
                    ["class", "fastbet-help-kart__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(189, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(190, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(192, 0, null, null, 3, "td", [], null, null, null, null, null)), (l()(), t.cc(193, null, ["VX [", "] / [2-5 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(196, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(197, null, ["VX3/1-2-4+1 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(199, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(200, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(202, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(204, 0, null, null, 15, "tr", [
                    ["class", "fastbet-help-kart__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(205, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(206, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(208, 0, null, null, 3, "td", [], null, null, null, null, null)), (l()(), t.cc(209, null, ["AX [2-5 ", "] / [1-4 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(212, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(213, null, ["AX1-2/3-4+2 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(215, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(216, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(218, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(220, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-kart__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(221, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(222, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(224, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(225, null, ["TNX [3-6 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(227, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(228, null, ["TNX1-2-3-4+3 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(230, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(231, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(233, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(235, 0, null, null, 15, "tr", [
                    ["class", "fastbet-help-kart__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(236, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(237, null, ["1 ", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(239, 0, null, null, 3, "td", [], null, null, null, null, null)), (l()(), t.cc(240, null, ["1PX [", "] / [2-5 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(243, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(244, null, ["1PX1/2-3-4+4 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(246, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(247, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(249, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(251, 0, null, null, 0, "br", [], null, null, null, null, null)), (l()(), t.Ib(252, 0, null, null, 3, "h1", [
                    ["class", "fastbet-help-kart__title"]
                ], null, null, null, null, null)), (l()(), t.cc(253, null, ["", " (", ")"])), t.Wb(131072, W.j, [W.k, t.i]), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(256, 0, null, null, 125, "table", [
                    ["class", "fastbet-help-kart__codes"]
                ], null, null, null, null, null)), (l()(), t.Ib(257, 0, null, null, 12, "tr", [
                    ["class", "fastbet-help-kart__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(258, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(259, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(261, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(262, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(264, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(265, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(267, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(268, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(270, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-kart__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(271, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(272, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(274, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["V%"])), (l()(), t.Ib(276, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(277, null, ["V%+1 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(279, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(280, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(282, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(284, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-kart__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(285, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(286, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(288, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["AO%"])), (l()(), t.Ib(290, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(291, null, ["AO%+2 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(293, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(294, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(296, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(298, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-kart__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(299, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(300, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(302, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["AS%"])), (l()(), t.Ib(304, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(305, null, ["AS%+3 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(307, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(308, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(310, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(312, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-kart__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(313, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(314, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(316, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["T%"])), (l()(), t.Ib(318, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(319, null, ["T%+4 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(321, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(322, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(324, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(326, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-kart__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(327, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(328, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(330, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["2P%"])), (l()(), t.Ib(332, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(333, null, ["2P%+5 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(335, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(336, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(338, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(340, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-kart__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(341, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(342, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(344, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["3P%"])), (l()(), t.Ib(346, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(347, null, ["3P%+6 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(349, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(350, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(352, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(354, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-kart__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(355, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(356, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(358, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["DP%"])), (l()(), t.Ib(360, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(361, null, ["DP%+7 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(363, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(364, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(366, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(368, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-kart__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(369, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(370, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(372, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["OU%"])), (l()(), t.Ib(374, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(375, null, ["OU%+8 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(377, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(378, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(380, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i])], (function(l, n) {
                    var u = n.component;
                    l(n, 3, 0, u.title, u.hasEnterSystemSection)
                }), (function(l, n) {
                    var u = n.component;
                    l(n, 5, 0, t.dc(n, 5, 0, t.Ub(n, 6).transform("ch_codes"))), l(n, 10, 0, t.dc(n, 10, 0, t.Ub(n, 11).transform("ch_market"))), l(n, 13, 0, t.dc(n, 13, 0, t.Ub(n, 14).transform("ch_code"))), l(n, 16, 0, t.dc(n, 16, 0, t.Ub(n, 17).transform("ch_examples"))), l(n, 19, 0, t.dc(n, 19, 0, t.Ub(n, 20).transform("ch_description"))), l(n, 23, 0, t.dc(n, 23, 0, t.Ub(n, 24).transform(u.KartMarkets.win))), l(n, 26, 0, t.dc(n, 26, 0, t.Ub(n, 27).transform("ch_selection"))), l(n, 29, 0, t.dc(n, 29, 0, t.Ub(n, 30).transform("ch_return")));
                    var e = t.dc(n, 32, 0, t.Ub(n, 35).transform("ch_5_1st", l(n, 34, 0, t.dc(n, 32, 0, t.Ub(n, 33).transform(1)))));
                    l(n, 32, 0, e), l(n, 38, 0, t.dc(n, 38, 0, t.Ub(n, 39).transform(u.KartMarkets.exacta))), l(n, 41, 0, t.dc(n, 41, 0, t.Ub(n, 42).transform("ch_selections"))), l(n, 44, 0, t.dc(n, 44, 0, t.Ub(n, 45).transform("ch_return")));
                    var c = t.dc(n, 47, 0, t.Ub(n, 50).transform("ch_1_1st_5_2nd", l(n, 49, 0, t.dc(n, 47, 0, t.Ub(n, 48).transform(2)))));
                    l(n, 47, 0, c), l(n, 53, 0, t.dc(n, 53, 0, t.Ub(n, 54).transform(u.KartMarkets.quinella))), l(n, 56, 0, t.dc(n, 56, 0, t.Ub(n, 57).transform("ch_selections"))), l(n, 59, 0, t.dc(n, 59, 0, t.Ub(n, 60).transform("ch_return")));
                    var r = t.dc(n, 62, 0, t.Ub(n, 65).transform("ch_4_2_1st_2nd", l(n, 64, 0, t.dc(n, 62, 0, t.Ub(n, 63).transform(3)))));
                    l(n, 62, 0, r), l(n, 68, 0, t.dc(n, 68, 0, t.Ub(n, 69).transform(u.KartMarkets.trifecta))), l(n, 71, 0, t.dc(n, 71, 0, t.Ub(n, 72).transform("ch_selections"))), l(n, 74, 0, t.dc(n, 74, 0, t.Ub(n, 75).transform("ch_return")));
                    var a = t.dc(n, 77, 0, t.Ub(n, 80).transform("ch_3_1st_1_2nd_4_3rd", l(n, 79, 0, t.dc(n, 77, 0, t.Ub(n, 78).transform(4)))));
                    l(n, 77, 0, a), l(n, 83, 0, t.dc(n, 83, 0, t.Ub(n, 84).transform(u.KartMarkets.place))), l(n, 86, 0, t.dc(n, 86, 0, t.Ub(n, 87).transform("ch_selection"))), l(n, 89, 0, t.dc(n, 89, 0, t.Ub(n, 90).transform("ch_return")));
                    var s = t.dc(n, 92, 0, t.Ub(n, 95).transform("ch_4_1st_2nd", l(n, 94, 0, t.dc(n, 92, 0, t.Ub(n, 93).transform(5)))));
                    l(n, 92, 0, s), l(n, 98, 0, t.dc(n, 98, 0, t.Ub(n, 99).transform(u.KartMarkets.show))), l(n, 101, 0, t.dc(n, 101, 0, t.Ub(n, 102).transform("ch_selection"))), l(n, 104, 0, t.dc(n, 104, 0, t.Ub(n, 105).transform("ch_return")));
                    var i = t.dc(n, 107, 0, t.Ub(n, 110).transform("ch_6_1st_2nd_3rd", l(n, 109, 0, t.dc(n, 107, 0, t.Ub(n, 108).transform(6)))));
                    l(n, 107, 0, i), l(n, 113, 0, t.dc(n, 113, 0, t.Ub(n, 114).transform("system_two"))), l(n, 116, 0, t.dc(n, 116, 0, t.Ub(n, 117).transform("ch_selections"))), l(n, 119, 0, t.dc(n, 119, 0, t.Ub(n, 120).transform("ch_return")));
                    var o = t.dc(n, 122, 0, t.Ub(n, 125).transform("ch_combination_double", l(n, 124, 0, t.dc(n, 122, 0, t.Ub(n, 123).transform(5)))));
                    l(n, 122, 0, o), l(n, 128, 0, t.dc(n, 128, 0, t.Ub(n, 129).transform("system_three"))), l(n, 131, 0, t.dc(n, 131, 0, t.Ub(n, 132).transform("ch_selections"))), l(n, 134, 0, t.dc(n, 134, 0, t.Ub(n, 135).transform("ch_return")));
                    var b = t.dc(n, 137, 0, t.Ub(n, 140).transform("ch_combination_triple", l(n, 139, 0, t.dc(n, 137, 0, t.Ub(n, 138).transform(6)))));
                    l(n, 137, 0, b), l(n, 143, 0, t.dc(n, 143, 0, t.Ub(n, 144).transform(u.KartMarkets.even_odd))), l(n, 148, 0, t.dc(n, 148, 0, t.Ub(n, 149).transform("ch_return")));
                    var d = t.dc(n, 151, 0, t.Ub(n, 154).transform("ch_winner_even", l(n, 153, 0, t.dc(n, 151, 0, t.Ub(n, 152).transform(7)))));
                    l(n, 151, 0, d), l(n, 157, 0, t.dc(n, 157, 0, t.Ub(n, 158).transform(u.KartMarkets.over_under))), l(n, 162, 0, t.dc(n, 162, 0, t.Ub(n, 163).transform("ch_return")));
                    var p = t.dc(n, 165, 0, t.Ub(n, 168).transform("ch_winner_higher_half_range", l(n, 167, 0, t.dc(n, 165, 0, t.Ub(n, 166).transform(8)))));
                    l(n, 165, 0, p), l(n, 171, 0, t.dc(n, 171, 0, t.Ub(n, 172).transform("ch_codes")), t.dc(n, 171, 1, t.Ub(n, 173).transform("ch_combination_bets"))), l(n, 177, 0, t.dc(n, 177, 0, t.Ub(n, 178).transform("ch_market"))), l(n, 180, 0, t.dc(n, 180, 0, t.Ub(n, 181).transform("ch_code"))), l(n, 183, 0, t.dc(n, 183, 0, t.Ub(n, 184).transform("ch_examples"))), l(n, 186, 0, t.dc(n, 186, 0, t.Ub(n, 187).transform("ch_description"))), l(n, 190, 0, t.dc(n, 190, 0, t.Ub(n, 191).transform("ch_winning_trio"))), l(n, 193, 0, t.dc(n, 193, 0, t.Ub(n, 194).transform("ch_slctn")), t.dc(n, 193, 1, t.Ub(n, 195).transform("ch_slctns"))), l(n, 197, 0, t.dc(n, 197, 0, t.Ub(n, 198).transform("ch_return")));
                    var h = t.dc(n, 200, 0, t.Ub(n, 203).transform("ch_3_1st_combination", l(n, 202, 0, t.dc(n, 200, 0, t.Ub(n, 201).transform(1)))));
                    l(n, 200, 0, h), l(n, 206, 0, t.dc(n, 206, 0, t.Ub(n, 207).transform("ch_coupled_trio"))), l(n, 209, 0, t.dc(n, 209, 0, t.Ub(n, 210).transform("ch_slctns")), t.dc(n, 209, 1, t.Ub(n, 211).transform("ch_slctns"))), l(n, 213, 0, t.dc(n, 213, 0, t.Ub(n, 214).transform("ch_return")));
                    var f = t.dc(n, 216, 0, t.Ub(n, 219).transform("ch_1_2_1st_2nd_combination", l(n, 218, 0, t.dc(n, 216, 0, t.Ub(n, 217).transform(2)))));
                    l(n, 216, 0, f), l(n, 222, 0, t.dc(n, 222, 0, t.Ub(n, 223).transform("ch_turning_trio"))), l(n, 225, 0, t.dc(n, 225, 0, t.Ub(n, 226).transform("ch_selections"))), l(n, 228, 0, t.dc(n, 228, 0, t.Ub(n, 229).transform("ch_return")));
                    var _ = t.dc(n, 231, 0, t.Ub(n, 234).transform("ch_subset_participants", l(n, 233, 0, t.dc(n, 231, 0, t.Ub(n, 232).transform(3)))));
                    l(n, 231, 0, _), l(n, 237, 0, t.dc(n, 237, 0, t.Ub(n, 238).transform("ch_located_trio"))), l(n, 240, 0, t.dc(n, 240, 0, t.Ub(n, 241).transform("ch_slctn")), t.dc(n, 240, 1, t.Ub(n, 242).transform("ch_slctns"))), l(n, 244, 0, t.dc(n, 244, 0, t.Ub(n, 245).transform("ch_return")));
                    var k = t.dc(n, 247, 0, t.Ub(n, 250).transform("ch_1_1st_2nd_3rd_subset", l(n, 249, 0, t.dc(n, 247, 0, t.Ub(n, 248).transform(4)))));
                    l(n, 247, 0, k), l(n, 253, 0, t.dc(n, 253, 0, t.Ub(n, 254).transform("ch_codes")), t.dc(n, 253, 1, t.Ub(n, 255).transform("ch_random"))), l(n, 259, 0, t.dc(n, 259, 0, t.Ub(n, 260).transform("ch_market"))), l(n, 262, 0, t.dc(n, 262, 0, t.Ub(n, 263).transform("ch_code"))), l(n, 265, 0, t.dc(n, 265, 0, t.Ub(n, 266).transform("ch_examples"))), l(n, 268, 0, t.dc(n, 268, 0, t.Ub(n, 269).transform("ch_description"))), l(n, 272, 0, t.dc(n, 272, 0, t.Ub(n, 273).transform(u.KartMarkets.win))), l(n, 277, 0, t.dc(n, 277, 0, t.Ub(n, 278).transform("ch_return")));
                    var m = t.dc(n, 280, 0, t.Ub(n, 283).transform("ch_random_winner", l(n, 282, 0, t.dc(n, 280, 0, t.Ub(n, 281).transform(1)))));
                    l(n, 280, 0, m), l(n, 286, 0, t.dc(n, 286, 0, t.Ub(n, 287).transform(u.KartMarkets.exacta))), l(n, 291, 0, t.dc(n, 291, 0, t.Ub(n, 292).transform("ch_return")));
                    var g = t.dc(n, 294, 0, t.Ub(n, 297).transform("ch_1st_2nd", l(n, 296, 0, t.dc(n, 294, 0, t.Ub(n, 295).transform(2)))));
                    l(n, 294, 0, g), l(n, 300, 0, t.dc(n, 300, 0, t.Ub(n, 301).transform(u.KartMarkets.quinella))), l(n, 305, 0, t.dc(n, 305, 0, t.Ub(n, 306).transform("ch_return")));
                    var I = t.dc(n, 308, 0, t.Ub(n, 311).transform("ch_random_1st_2nd", l(n, 310, 0, t.dc(n, 308, 0, t.Ub(n, 309).transform(3)))));
                    l(n, 308, 0, I), l(n, 314, 0, t.dc(n, 314, 0, t.Ub(n, 315).transform(u.KartMarkets.trifecta))), l(n, 319, 0, t.dc(n, 319, 0, t.Ub(n, 320).transform("ch_return")));
                    var U = t.dc(n, 322, 0, t.Ub(n, 325).transform("ch_1st_2nd_3rd", l(n, 324, 0, t.dc(n, 322, 0, t.Ub(n, 323).transform(4)))));
                    l(n, 322, 0, U), l(n, 328, 0, t.dc(n, 328, 0, t.Ub(n, 329).transform(u.KartMarkets.place))), l(n, 333, 0, t.dc(n, 333, 0, t.Ub(n, 334).transform("ch_return")));
                    var W = t.dc(n, 336, 0, t.Ub(n, 339).transform("ch_participant_1st_2nd", l(n, 338, 0, t.dc(n, 336, 0, t.Ub(n, 337).transform(5)))));
                    l(n, 336, 0, W), l(n, 342, 0, t.dc(n, 342, 0, t.Ub(n, 343).transform(u.KartMarkets.show))), l(n, 347, 0, t.dc(n, 347, 0, t.Ub(n, 348).transform("ch_return")));
                    var v = t.dc(n, 350, 0, t.Ub(n, 353).transform("ch_random_participant_1st_2nd_3rd", l(n, 352, 0, t.dc(n, 350, 0, t.Ub(n, 351).transform(6)))));
                    l(n, 350, 0, v), l(n, 356, 0, t.dc(n, 356, 0, t.Ub(n, 357).transform(u.KartMarkets.even_odd))), l(n, 361, 0, t.dc(n, 361, 0, t.Ub(n, 362).transform("ch_return")));
                    var y = t.dc(n, 364, 0, t.Ub(n, 367).transform("ch_winner_even_odd", l(n, 366, 0, t.dc(n, 364, 0, t.Ub(n, 365).transform(7)))));
                    l(n, 364, 0, y), l(n, 370, 0, t.dc(n, 370, 0, t.Ub(n, 371).transform(u.KartMarkets.over_under))), l(n, 375, 0, t.dc(n, 375, 0, t.Ub(n, 376).transform("ch_return")));
                    var w = t.dc(n, 378, 0, t.Ub(n, 381).transform("ch_winner_higher_lower_range", l(n, 380, 0, t.dc(n, 378, 0, t.Ub(n, 379).transform(8)))));
                    l(n, 378, 0, w)
                }))
            }
            var ql = t.Eb("gr-fastbet-help-kart", sl, (function(l) {
                    return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 1, "gr-fastbet-help-kart", [], null, null, null, Vl, Rl)), t.Hb(1, 114688, null, 0, sl, [W.k], null, null)], (function(l, n) {
                        l(n, 1, 0)
                    }), null)
                }), {
                    participants: "participants"
                }, {
                    close: "close"
                }, []),
                Zl = [
                    [".fastbet-help-motorbike[_ngcontent-%COMP%]{max-width:1500px;max-height:985px;padding:30px;overflow-y:scroll;font-family:OpenSans;font-size:16px}.fastbet-help-motorbike__row[_ngcontent-%COMP%]{line-height:20px}.fastbet-help-motorbike__row[_ngcontent-%COMP%]:not(:first-child)   td[_ngcontent-%COMP%]:not(:last-child){text-transform:uppercase}.fastbet-help-motorbike__row[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]{padding:16px 0 16px 18px}.fastbet-help-motorbike__row[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:first-child{width:20%;font-weight:700}.fastbet-help-motorbike__row[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:nth-child(2), .fastbet-help-motorbike__row[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:nth-child(3){width:20%}.fastbet-help-motorbike__row[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:last-child{width:30%;padding-right:16px}.fastbet-help-motorbike__title[_ngcontent-%COMP%]{font-size:28px;font-weight:700;text-transform:capitalize}.fastbet-help-motorbike__codes[_ngcontent-%COMP%]{width:100%;margin-top:10px;margin-bottom:21px;font-size:16px}.fastbet-help-motorbike__close[_ngcontent-%COMP%]{position:absolute;top:30px;right:55px;z-index:99999;font-size:24px;cursor:pointer}"]
                ],
                Kl = t.Gb({
                    encapsulation: 0,
                    styles: Zl,
                    data: {}
                });

            function Yl(l) {
                return t.ec(2, [(l()(), t.Ib(0, 0, null, null, 381, "div", [
                    ["class", "fastbet-help-motorbike"]
                ], null, null, null, null, null)), (l()(), t.Ib(1, 0, null, null, 0, "div", [
                    ["class", "fastbet-help-motorbike__close icon icon-cancel"]
                ], null, [
                    [null, "click"]
                ], (function(l, n, u) {
                    var t = !0,
                        e = l.component;
                    "click" === n && (t = !1 !== e.close.emit() && t);
                    return t
                }), null, null)), (l()(), t.Ib(2, 0, null, null, 1, "gr-fastbet-help-header", [], null, null, null, Ol.b, Ol.a)), t.Hb(3, 114688, null, 0, Pl.a, [], {
                    title: [0, "title"],
                    hasEnterSystemSection: [1, "hasEnterSystemSection"]
                }, null), (l()(), t.Ib(4, 0, null, null, 2, "h1", [
                    ["class", "fastbet-help-motorbike__title"]
                ], null, null, null, null, null)), (l()(), t.cc(5, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(7, 0, null, null, 161, "table", [
                    ["class", "fastbet-help-motorbike__codes"]
                ], null, null, null, null, null)), (l()(), t.Ib(8, 0, null, null, 12, "tr", [
                    ["class", "fastbet-help-motorbike__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(9, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(10, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(12, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(13, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(15, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(16, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(18, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(19, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(21, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-motorbike__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(22, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(23, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(25, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(26, null, ["V [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(28, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(29, null, ["V5+1 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(31, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(32, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(34, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(36, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-motorbike__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(37, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(38, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(40, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(41, null, ["AO [2 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(43, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(44, null, ["AO1-5+2 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(46, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(47, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(49, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(51, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-motorbike__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(52, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(53, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(55, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(56, null, ["AS [2 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(58, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(59, null, ["AS4-2+3 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(61, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(62, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(64, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(66, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-motorbike__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(67, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(68, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(70, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(71, null, ["T [3 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(73, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(74, null, ["T3-1-4+4 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(76, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(77, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(79, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(81, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-motorbike__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(82, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(83, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(85, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(86, null, ["2P [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(88, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(89, null, ["2P4+5 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(91, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(92, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(94, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(96, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-motorbike__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(97, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(98, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(100, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(101, null, ["3P [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(103, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(104, null, ["3P6+6 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(106, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(107, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(109, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(111, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-motorbike__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(112, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(113, null, ["", ""])), t.Wb(131072, W.q, [W.k, t.i]), (l()(), t.Ib(115, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(116, null, ["Y2 [2 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(118, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(119, null, ["Y21-4+5 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(121, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(122, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(124, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(126, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-motorbike__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(127, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(128, null, ["", ""])), t.Wb(131072, W.q, [W.k, t.i]), (l()(), t.Ib(130, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(131, null, ["Y3 [3 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(133, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(134, null, ["Y32-3-6+6 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(136, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(137, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(139, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(141, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-motorbike__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(142, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(143, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(145, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["DI / PA"])), (l()(), t.Ib(147, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(148, null, ["PA+7 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(150, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(151, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(153, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(155, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-motorbike__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(156, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(157, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(159, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["O / U"])), (l()(), t.Ib(161, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(162, null, ["O+8 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(164, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(165, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(167, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(169, 0, null, null, 0, "br", [], null, null, null, null, null)), (l()(), t.Ib(170, 0, null, null, 3, "h1", [
                    ["class", "fastbet-help-motorbike__title"]
                ], null, null, null, null, null)), (l()(), t.cc(171, null, ["", " (", ")"])), t.Wb(131072, W.j, [W.k, t.i]), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(174, 0, null, null, 76, "table", [
                    ["class", "fastbet-help-motorbike__codes"]
                ], null, null, null, null, null)), (l()(), t.Ib(175, 0, null, null, 12, "tr", [
                    ["class", "fastbet-help-motorbike__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(176, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(177, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(179, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(180, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(182, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(183, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(185, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(186, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(188, 0, null, null, 15, "tr", [
                    ["class", "fastbet-help-motorbike__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(189, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(190, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(192, 0, null, null, 3, "td", [], null, null, null, null, null)), (l()(), t.cc(193, null, ["VX [", "] / [2-5 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(196, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(197, null, ["VX3/1-2-4+1 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(199, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(200, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(202, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(204, 0, null, null, 15, "tr", [
                    ["class", "fastbet-help-motorbike__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(205, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(206, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(208, 0, null, null, 3, "td", [], null, null, null, null, null)), (l()(), t.cc(209, null, ["AX [2-5 ", "] / [1-4 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(212, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(213, null, ["AX1-2/3-4+2 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(215, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(216, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(218, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(220, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-motorbike__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(221, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(222, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(224, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(225, null, ["TNX [3-6 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(227, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(228, null, ["TNX1-2-3-4+3 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(230, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(231, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(233, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(235, 0, null, null, 15, "tr", [
                    ["class", "fastbet-help-motorbike__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(236, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(237, null, ["1 ", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(239, 0, null, null, 3, "td", [], null, null, null, null, null)), (l()(), t.cc(240, null, ["1PX [", "] / [2-5 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(243, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(244, null, ["1PX1/2-3-4+4 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(246, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(247, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(249, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(251, 0, null, null, 0, "br", [], null, null, null, null, null)), (l()(), t.Ib(252, 0, null, null, 3, "h1", [
                    ["class", "fastbet-help-motorbike__title"]
                ], null, null, null, null, null)), (l()(), t.cc(253, null, ["", " (", ")"])), t.Wb(131072, W.j, [W.k, t.i]), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(256, 0, null, null, 125, "table", [
                    ["class", "fastbet-help-motorbike__codes"]
                ], null, null, null, null, null)), (l()(), t.Ib(257, 0, null, null, 12, "tr", [
                    ["class", "fastbet-help-motorbike__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(258, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(259, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(261, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(262, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(264, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(265, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(267, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(268, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(270, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-motorbike__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(271, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(272, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(274, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["V%"])), (l()(), t.Ib(276, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(277, null, ["V%+1 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(279, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(280, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(282, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(284, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-motorbike__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(285, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(286, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(288, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["AO%"])), (l()(), t.Ib(290, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(291, null, ["AO%+2 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(293, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(294, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(296, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(298, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-motorbike__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(299, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(300, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(302, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["AS%"])), (l()(), t.Ib(304, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(305, null, ["AS%+3 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(307, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(308, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(310, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(312, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-motorbike__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(313, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(314, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(316, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["T%"])), (l()(), t.Ib(318, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(319, null, ["T%+4 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(321, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(322, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(324, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(326, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-motorbike__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(327, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(328, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(330, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["2P%"])), (l()(), t.Ib(332, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(333, null, ["2P%+5 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(335, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(336, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(338, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(340, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-motorbike__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(341, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(342, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(344, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["3P%"])), (l()(), t.Ib(346, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(347, null, ["3P%+6 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(349, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(350, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(352, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(354, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-motorbike__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(355, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(356, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(358, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["DP%"])), (l()(), t.Ib(360, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(361, null, ["DP%+7 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(363, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(364, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(366, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(368, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-motorbike__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(369, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(370, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(372, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["OU%"])), (l()(), t.Ib(374, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(375, null, ["OU%+8 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(377, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(378, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(380, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i])], (function(l, n) {
                    var u = n.component;
                    l(n, 3, 0, u.title, u.hasEnterSystemSection)
                }), (function(l, n) {
                    var u = n.component;
                    l(n, 5, 0, t.dc(n, 5, 0, t.Ub(n, 6).transform("ch_codes"))), l(n, 10, 0, t.dc(n, 10, 0, t.Ub(n, 11).transform("ch_market"))), l(n, 13, 0, t.dc(n, 13, 0, t.Ub(n, 14).transform("ch_code"))), l(n, 16, 0, t.dc(n, 16, 0, t.Ub(n, 17).transform("ch_examples"))), l(n, 19, 0, t.dc(n, 19, 0, t.Ub(n, 20).transform("ch_description"))), l(n, 23, 0, t.dc(n, 23, 0, t.Ub(n, 24).transform(u.MotorbikeMarkets.win))), l(n, 26, 0, t.dc(n, 26, 0, t.Ub(n, 27).transform("ch_selection"))), l(n, 29, 0, t.dc(n, 29, 0, t.Ub(n, 30).transform("ch_return")));
                    var e = t.dc(n, 32, 0, t.Ub(n, 35).transform("ch_5_1st", l(n, 34, 0, t.dc(n, 32, 0, t.Ub(n, 33).transform(1)))));
                    l(n, 32, 0, e), l(n, 38, 0, t.dc(n, 38, 0, t.Ub(n, 39).transform(u.MotorbikeMarkets.exacta))), l(n, 41, 0, t.dc(n, 41, 0, t.Ub(n, 42).transform("ch_selections"))), l(n, 44, 0, t.dc(n, 44, 0, t.Ub(n, 45).transform("ch_return")));
                    var c = t.dc(n, 47, 0, t.Ub(n, 50).transform("ch_1_1st_5_2nd", l(n, 49, 0, t.dc(n, 47, 0, t.Ub(n, 48).transform(2)))));
                    l(n, 47, 0, c), l(n, 53, 0, t.dc(n, 53, 0, t.Ub(n, 54).transform(u.MotorbikeMarkets.quinella))), l(n, 56, 0, t.dc(n, 56, 0, t.Ub(n, 57).transform("ch_selections"))), l(n, 59, 0, t.dc(n, 59, 0, t.Ub(n, 60).transform("ch_return")));
                    var r = t.dc(n, 62, 0, t.Ub(n, 65).transform("ch_4_2_1st_2nd", l(n, 64, 0, t.dc(n, 62, 0, t.Ub(n, 63).transform(3)))));
                    l(n, 62, 0, r), l(n, 68, 0, t.dc(n, 68, 0, t.Ub(n, 69).transform(u.MotorbikeMarkets.trifecta))), l(n, 71, 0, t.dc(n, 71, 0, t.Ub(n, 72).transform("ch_selections"))), l(n, 74, 0, t.dc(n, 74, 0, t.Ub(n, 75).transform("ch_return")));
                    var a = t.dc(n, 77, 0, t.Ub(n, 80).transform("ch_3_1st_1_2nd_4_3rd", l(n, 79, 0, t.dc(n, 77, 0, t.Ub(n, 78).transform(4)))));
                    l(n, 77, 0, a), l(n, 83, 0, t.dc(n, 83, 0, t.Ub(n, 84).transform(u.MotorbikeMarkets.place))), l(n, 86, 0, t.dc(n, 86, 0, t.Ub(n, 87).transform("ch_selection"))), l(n, 89, 0, t.dc(n, 89, 0, t.Ub(n, 90).transform("ch_return")));
                    var s = t.dc(n, 92, 0, t.Ub(n, 95).transform("ch_4_1st_2nd", l(n, 94, 0, t.dc(n, 92, 0, t.Ub(n, 93).transform(5)))));
                    l(n, 92, 0, s), l(n, 98, 0, t.dc(n, 98, 0, t.Ub(n, 99).transform(u.MotorbikeMarkets.show))), l(n, 101, 0, t.dc(n, 101, 0, t.Ub(n, 102).transform("ch_selection"))), l(n, 104, 0, t.dc(n, 104, 0, t.Ub(n, 105).transform("ch_return")));
                    var i = t.dc(n, 107, 0, t.Ub(n, 110).transform("ch_6_1st_2nd_3rd", l(n, 109, 0, t.dc(n, 107, 0, t.Ub(n, 108).transform(6)))));
                    l(n, 107, 0, i), l(n, 113, 0, t.dc(n, 113, 0, t.Ub(n, 114).transform("system_two"))), l(n, 116, 0, t.dc(n, 116, 0, t.Ub(n, 117).transform("ch_selections"))), l(n, 119, 0, t.dc(n, 119, 0, t.Ub(n, 120).transform("ch_return")));
                    var o = t.dc(n, 122, 0, t.Ub(n, 125).transform("ch_combination_double", l(n, 124, 0, t.dc(n, 122, 0, t.Ub(n, 123).transform(5)))));
                    l(n, 122, 0, o), l(n, 128, 0, t.dc(n, 128, 0, t.Ub(n, 129).transform("system_three"))), l(n, 131, 0, t.dc(n, 131, 0, t.Ub(n, 132).transform("ch_selections"))), l(n, 134, 0, t.dc(n, 134, 0, t.Ub(n, 135).transform("ch_return")));
                    var b = t.dc(n, 137, 0, t.Ub(n, 140).transform("ch_combination_triple", l(n, 139, 0, t.dc(n, 137, 0, t.Ub(n, 138).transform(6)))));
                    l(n, 137, 0, b), l(n, 143, 0, t.dc(n, 143, 0, t.Ub(n, 144).transform(u.MotorbikeMarkets.even_odd))), l(n, 148, 0, t.dc(n, 148, 0, t.Ub(n, 149).transform("ch_return")));
                    var d = t.dc(n, 151, 0, t.Ub(n, 154).transform("ch_winner_even", l(n, 153, 0, t.dc(n, 151, 0, t.Ub(n, 152).transform(7)))));
                    l(n, 151, 0, d), l(n, 157, 0, t.dc(n, 157, 0, t.Ub(n, 158).transform(u.MotorbikeMarkets.over_under))), l(n, 162, 0, t.dc(n, 162, 0, t.Ub(n, 163).transform("ch_return")));
                    var p = t.dc(n, 165, 0, t.Ub(n, 168).transform("ch_winner_higher_half_range", l(n, 167, 0, t.dc(n, 165, 0, t.Ub(n, 166).transform(8)))));
                    l(n, 165, 0, p), l(n, 171, 0, t.dc(n, 171, 0, t.Ub(n, 172).transform("ch_codes")), t.dc(n, 171, 1, t.Ub(n, 173).transform("ch_combination_bets"))), l(n, 177, 0, t.dc(n, 177, 0, t.Ub(n, 178).transform("ch_market"))), l(n, 180, 0, t.dc(n, 180, 0, t.Ub(n, 181).transform("ch_code"))), l(n, 183, 0, t.dc(n, 183, 0, t.Ub(n, 184).transform("ch_examples"))), l(n, 186, 0, t.dc(n, 186, 0, t.Ub(n, 187).transform("ch_description"))), l(n, 190, 0, t.dc(n, 190, 0, t.Ub(n, 191).transform("ch_winning_trio"))), l(n, 193, 0, t.dc(n, 193, 0, t.Ub(n, 194).transform("ch_slctn")), t.dc(n, 193, 1, t.Ub(n, 195).transform("ch_slctns"))), l(n, 197, 0, t.dc(n, 197, 0, t.Ub(n, 198).transform("ch_return")));
                    var h = t.dc(n, 200, 0, t.Ub(n, 203).transform("ch_3_1st_combination", l(n, 202, 0, t.dc(n, 200, 0, t.Ub(n, 201).transform(1)))));
                    l(n, 200, 0, h), l(n, 206, 0, t.dc(n, 206, 0, t.Ub(n, 207).transform("ch_coupled_trio"))), l(n, 209, 0, t.dc(n, 209, 0, t.Ub(n, 210).transform("ch_slctns")), t.dc(n, 209, 1, t.Ub(n, 211).transform("ch_slctns"))), l(n, 213, 0, t.dc(n, 213, 0, t.Ub(n, 214).transform("ch_return")));
                    var f = t.dc(n, 216, 0, t.Ub(n, 219).transform("ch_1_2_1st_2nd_combination", l(n, 218, 0, t.dc(n, 216, 0, t.Ub(n, 217).transform(2)))));
                    l(n, 216, 0, f), l(n, 222, 0, t.dc(n, 222, 0, t.Ub(n, 223).transform("ch_turning_trio"))), l(n, 225, 0, t.dc(n, 225, 0, t.Ub(n, 226).transform("ch_selections"))), l(n, 228, 0, t.dc(n, 228, 0, t.Ub(n, 229).transform("ch_return")));
                    var _ = t.dc(n, 231, 0, t.Ub(n, 234).transform("ch_subset_participants", l(n, 233, 0, t.dc(n, 231, 0, t.Ub(n, 232).transform(3)))));
                    l(n, 231, 0, _), l(n, 237, 0, t.dc(n, 237, 0, t.Ub(n, 238).transform("ch_located_trio"))), l(n, 240, 0, t.dc(n, 240, 0, t.Ub(n, 241).transform("ch_slctn")), t.dc(n, 240, 1, t.Ub(n, 242).transform("ch_slctns"))), l(n, 244, 0, t.dc(n, 244, 0, t.Ub(n, 245).transform("ch_return")));
                    var k = t.dc(n, 247, 0, t.Ub(n, 250).transform("ch_1_1st_2nd_3rd_subset", l(n, 249, 0, t.dc(n, 247, 0, t.Ub(n, 248).transform(4)))));
                    l(n, 247, 0, k), l(n, 253, 0, t.dc(n, 253, 0, t.Ub(n, 254).transform("ch_codes")), t.dc(n, 253, 1, t.Ub(n, 255).transform("ch_random"))), l(n, 259, 0, t.dc(n, 259, 0, t.Ub(n, 260).transform("ch_market"))), l(n, 262, 0, t.dc(n, 262, 0, t.Ub(n, 263).transform("ch_code"))), l(n, 265, 0, t.dc(n, 265, 0, t.Ub(n, 266).transform("ch_examples"))), l(n, 268, 0, t.dc(n, 268, 0, t.Ub(n, 269).transform("ch_description"))), l(n, 272, 0, t.dc(n, 272, 0, t.Ub(n, 273).transform(u.MotorbikeMarkets.win))), l(n, 277, 0, t.dc(n, 277, 0, t.Ub(n, 278).transform("ch_return")));
                    var m = t.dc(n, 280, 0, t.Ub(n, 283).transform("ch_random_winner", l(n, 282, 0, t.dc(n, 280, 0, t.Ub(n, 281).transform(1)))));
                    l(n, 280, 0, m), l(n, 286, 0, t.dc(n, 286, 0, t.Ub(n, 287).transform(u.MotorbikeMarkets.exacta))), l(n, 291, 0, t.dc(n, 291, 0, t.Ub(n, 292).transform("ch_return")));
                    var g = t.dc(n, 294, 0, t.Ub(n, 297).transform("ch_1st_2nd", l(n, 296, 0, t.dc(n, 294, 0, t.Ub(n, 295).transform(2)))));
                    l(n, 294, 0, g), l(n, 300, 0, t.dc(n, 300, 0, t.Ub(n, 301).transform(u.MotorbikeMarkets.quinella))), l(n, 305, 0, t.dc(n, 305, 0, t.Ub(n, 306).transform("ch_return")));
                    var I = t.dc(n, 308, 0, t.Ub(n, 311).transform("ch_random_1st_2nd", l(n, 310, 0, t.dc(n, 308, 0, t.Ub(n, 309).transform(3)))));
                    l(n, 308, 0, I), l(n, 314, 0, t.dc(n, 314, 0, t.Ub(n, 315).transform(u.MotorbikeMarkets.trifecta))), l(n, 319, 0, t.dc(n, 319, 0, t.Ub(n, 320).transform("ch_return")));
                    var U = t.dc(n, 322, 0, t.Ub(n, 325).transform("ch_1st_2nd_3rd", l(n, 324, 0, t.dc(n, 322, 0, t.Ub(n, 323).transform(4)))));
                    l(n, 322, 0, U), l(n, 328, 0, t.dc(n, 328, 0, t.Ub(n, 329).transform(u.MotorbikeMarkets.place))), l(n, 333, 0, t.dc(n, 333, 0, t.Ub(n, 334).transform("ch_return")));
                    var W = t.dc(n, 336, 0, t.Ub(n, 339).transform("ch_participant_1st_2nd", l(n, 338, 0, t.dc(n, 336, 0, t.Ub(n, 337).transform(5)))));
                    l(n, 336, 0, W), l(n, 342, 0, t.dc(n, 342, 0, t.Ub(n, 343).transform(u.MotorbikeMarkets.show))), l(n, 347, 0, t.dc(n, 347, 0, t.Ub(n, 348).transform("ch_return")));
                    var v = t.dc(n, 350, 0, t.Ub(n, 353).transform("ch_random_participant_1st_2nd_3rd", l(n, 352, 0, t.dc(n, 350, 0, t.Ub(n, 351).transform(6)))));
                    l(n, 350, 0, v), l(n, 356, 0, t.dc(n, 356, 0, t.Ub(n, 357).transform(u.MotorbikeMarkets.even_odd))), l(n, 361, 0, t.dc(n, 361, 0, t.Ub(n, 362).transform("ch_return")));
                    var y = t.dc(n, 364, 0, t.Ub(n, 367).transform("ch_winner_even_odd", l(n, 366, 0, t.dc(n, 364, 0, t.Ub(n, 365).transform(7)))));
                    l(n, 364, 0, y), l(n, 370, 0, t.dc(n, 370, 0, t.Ub(n, 371).transform(u.MotorbikeMarkets.over_under))), l(n, 375, 0, t.dc(n, 375, 0, t.Ub(n, 376).transform("ch_return")));
                    var w = t.dc(n, 378, 0, t.Ub(n, 381).transform("ch_winner_higher_lower_range", l(n, 380, 0, t.dc(n, 378, 0, t.Ub(n, 379).transform(8)))));
                    l(n, 378, 0, w)
                }))
            }
            var $l = t.Eb("gr-fastbet-help-motorbike", ol, (function(l) {
                    return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 1, "gr-fastbet-help-motorbike", [], null, null, null, Yl, Kl)), t.Hb(1, 114688, null, 0, ol, [W.k], null, null)], (function(l, n) {
                        l(n, 1, 0)
                    }), null)
                }), {
                    participants: "participants"
                }, {
                    close: "close"
                }, []),
                Ql = [
                    [".fastbet-help-speedwaydirttrack[_ngcontent-%COMP%]{max-width:1500px;max-height:985px;padding:30px;overflow-y:scroll;font-family:OpenSans;font-size:16px}.fastbet-help-speedwaydirttrack__row[_ngcontent-%COMP%]{line-height:20px}.fastbet-help-speedwaydirttrack__row[_ngcontent-%COMP%]:not(:first-child)   td[_ngcontent-%COMP%]:not(:last-child){text-transform:uppercase}.fastbet-help-speedwaydirttrack__row[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]{padding:16px 0 16px 18px}.fastbet-help-speedwaydirttrack__row[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:first-child{width:20%;font-weight:700}.fastbet-help-speedwaydirttrack__row[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:nth-child(2), .fastbet-help-speedwaydirttrack__row[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:nth-child(3){width:20%}.fastbet-help-speedwaydirttrack__row[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:last-child{width:30%;padding-right:16px}.fastbet-help-speedwaydirttrack__title[_ngcontent-%COMP%]{font-size:28px;font-weight:700;text-transform:capitalize}.fastbet-help-speedwaydirttrack__codes[_ngcontent-%COMP%]{width:100%;margin-top:10px;margin-bottom:21px;font-size:16px}.fastbet-help-speedwaydirttrack__close[_ngcontent-%COMP%]{position:absolute;top:30px;right:55px;z-index:99999;font-size:24px;cursor:pointer}"]
                ],
                Ll = t.Gb({
                    encapsulation: 0,
                    styles: Ql,
                    data: {}
                });

            function Jl(l) {
                return t.ec(2, [(l()(), t.Ib(0, 0, null, null, 226, "div", [
                    ["class", "fastbet-help-speedwaydirttrack"]
                ], null, null, null, null, null)), (l()(), t.Ib(1, 0, null, null, 0, "div", [
                    ["class", "fastbet-help-speedwaydirttrack__close icon icon-cancel"]
                ], null, [
                    [null, "click"]
                ], (function(l, n, u) {
                    var t = !0,
                        e = l.component;
                    "click" === n && (t = !1 !== e.close.emit() && t);
                    return t
                }), null, null)), (l()(), t.Ib(2, 0, null, null, 1, "gr-fastbet-help-header", [], null, null, null, Ol.b, Ol.a)), t.Hb(3, 114688, null, 0, Pl.a, [], {
                    title: [0, "title"],
                    hasEnterSystemSection: [1, "hasEnterSystemSection"]
                }, null), (l()(), t.Ib(4, 0, null, null, 2, "h1", [
                    ["class", "fastbet-help-speedwaydirttrack__title"]
                ], null, null, null, null, null)), (l()(), t.cc(5, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(7, 0, null, null, 116, "table", [
                    ["class", "fastbet-help-speedwaydirttrack__codes"]
                ], null, null, null, null, null)), (l()(), t.Ib(8, 0, null, null, 12, "tr", [
                    ["class", "fastbet-help-speedwaydirttrack__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(9, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(10, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(12, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(13, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(15, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(16, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(18, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(19, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(21, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-speedwaydirttrack__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(22, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(23, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(25, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(26, null, ["V [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(28, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(29, null, ["V4+1 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(31, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(32, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(34, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(36, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-speedwaydirttrack__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(37, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(38, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(40, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(41, null, ["AO [2 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(43, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(44, null, ["AO1-4+2 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(46, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(47, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(49, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(51, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-speedwaydirttrack__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(52, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(53, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(55, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(56, null, ["AS [2 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(58, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(59, null, ["AS4-2+3 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(61, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(62, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(64, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(66, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-speedwaydirttrack__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(67, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(68, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(70, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(71, null, ["2P [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(73, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(74, null, ["2P4+4 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(76, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(77, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(79, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(81, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-speedwaydirttrack__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(82, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(83, null, ["", ""])), t.Wb(131072, W.q, [W.k, t.i]), (l()(), t.Ib(85, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(86, null, ["Y2 [2 ", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(88, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(89, null, ["Y21-4+5 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(91, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(92, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(94, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(96, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-speedwaydirttrack__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(97, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(98, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(100, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["DI / PA"])), (l()(), t.Ib(102, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(103, null, ["PA+5 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(105, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(106, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(108, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(110, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-speedwaydirttrack__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(111, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(112, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(114, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["O / U"])), (l()(), t.Ib(116, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(117, null, ["O+6 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(119, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(120, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(122, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(124, 0, null, null, 0, "br", [], null, null, null, null, null)), (l()(), t.Ib(125, 0, null, null, 3, "h1", [
                    ["class", "fastbet-help-speedwaydirttrack__title"]
                ], null, null, null, null, null)), (l()(), t.cc(126, null, ["", " (", ")"])), t.Wb(131072, W.j, [W.k, t.i]), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(129, 0, null, null, 97, "table", [
                    ["class", "fastbet-help-speedwaydirttrack__codes"]
                ], null, null, null, null, null)), (l()(), t.Ib(130, 0, null, null, 12, "tr", [
                    ["class", "fastbet-help-speedwaydirttrack__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(131, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(132, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(134, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(135, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(137, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(138, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(140, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(141, null, ["", ""])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(143, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-speedwaydirttrack__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(144, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(145, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(147, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["V%"])), (l()(), t.Ib(149, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(150, null, ["V%+1 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(152, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(153, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(155, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(157, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-speedwaydirttrack__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(158, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(159, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(161, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["AO%"])), (l()(), t.Ib(163, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(164, null, ["AO%+2 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(166, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(167, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(169, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(171, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-speedwaydirttrack__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(172, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(173, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(175, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["AS%"])), (l()(), t.Ib(177, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(178, null, ["AS%+3 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(180, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(181, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(183, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(185, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-speedwaydirttrack__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(186, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(187, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(189, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["2P%"])), (l()(), t.Ib(191, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(192, null, ["2P%+5 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(194, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(195, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(197, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(199, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-speedwaydirttrack__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(200, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(201, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(203, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["DP%"])), (l()(), t.Ib(205, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(206, null, ["DP%+7 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(208, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(209, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(211, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(213, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-speedwaydirttrack__row"]
                ], null, null, null, null, null)), (l()(), t.Ib(214, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(215, null, ["", ""])), t.Wb(131072, W.p, [W.k, t.i]), (l()(), t.Ib(217, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), t.cc(-1, null, ["OU%"])), (l()(), t.Ib(219, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), t.cc(220, null, ["OU%+8 [", "]"])), t.Wb(131072, W.j, [W.k, t.i]), (l()(), t.Ib(222, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), t.cc(223, null, ["", ""])), t.Wb(131072, W.b, [W.k, t.i]), t.Xb(225, {
                    stake: 0
                }), t.Wb(131072, W.j, [W.k, t.i])], (function(l, n) {
                    var u = n.component;
                    l(n, 3, 0, u.title, u.hasEnterSystemSection)
                }), (function(l, n) {
                    var u = n.component;
                    l(n, 5, 0, t.dc(n, 5, 0, t.Ub(n, 6).transform("ch_codes"))), l(n, 10, 0, t.dc(n, 10, 0, t.Ub(n, 11).transform("ch_market"))), l(n, 13, 0, t.dc(n, 13, 0, t.Ub(n, 14).transform("ch_code"))), l(n, 16, 0, t.dc(n, 16, 0, t.Ub(n, 17).transform("ch_examples"))), l(n, 19, 0, t.dc(n, 19, 0, t.Ub(n, 20).transform("ch_description"))), l(n, 23, 0, t.dc(n, 23, 0, t.Ub(n, 24).transform(u.SpeedwayMarkets.win))), l(n, 26, 0, t.dc(n, 26, 0, t.Ub(n, 27).transform("ch_selection"))), l(n, 29, 0, t.dc(n, 29, 0, t.Ub(n, 30).transform("ch_return")));
                    var e = t.dc(n, 32, 0, t.Ub(n, 35).transform("ch_4_1st", l(n, 34, 0, t.dc(n, 32, 0, t.Ub(n, 33).transform(1)))));
                    l(n, 32, 0, e), l(n, 38, 0, t.dc(n, 38, 0, t.Ub(n, 39).transform(u.SpeedwayMarkets.exacta))), l(n, 41, 0, t.dc(n, 41, 0, t.Ub(n, 42).transform("ch_selections"))), l(n, 44, 0, t.dc(n, 44, 0, t.Ub(n, 45).transform("ch_return")));
                    var c = t.dc(n, 47, 0, t.Ub(n, 50).transform("ch_1_1st_4_2nd", l(n, 49, 0, t.dc(n, 47, 0, t.Ub(n, 48).transform(2)))));
                    l(n, 47, 0, c), l(n, 53, 0, t.dc(n, 53, 0, t.Ub(n, 54).transform(u.SpeedwayMarkets.quinella))), l(n, 56, 0, t.dc(n, 56, 0, t.Ub(n, 57).transform("ch_selections"))), l(n, 59, 0, t.dc(n, 59, 0, t.Ub(n, 60).transform("ch_return")));
                    var r = t.dc(n, 62, 0, t.Ub(n, 65).transform("ch_4_1st_2_2nd", l(n, 64, 0, t.dc(n, 62, 0, t.Ub(n, 63).transform(3)))));
                    l(n, 62, 0, r), l(n, 68, 0, t.dc(n, 68, 0, t.Ub(n, 69).transform(u.SpeedwayMarkets.place))), l(n, 71, 0, t.dc(n, 71, 0, t.Ub(n, 72).transform("ch_selection"))), l(n, 74, 0, t.dc(n, 74, 0, t.Ub(n, 75).transform("ch_return")));
                    var a = t.dc(n, 77, 0, t.Ub(n, 80).transform("ch_4_1st_2nd", l(n, 79, 0, t.dc(n, 77, 0, t.Ub(n, 78).transform(5)))));
                    l(n, 77, 0, a), l(n, 83, 0, t.dc(n, 83, 0, t.Ub(n, 84).transform("system_two"))), l(n, 86, 0, t.dc(n, 86, 0, t.Ub(n, 87).transform("ch_selections"))), l(n, 89, 0, t.dc(n, 89, 0, t.Ub(n, 90).transform("ch_return")));
                    var s = t.dc(n, 92, 0, t.Ub(n, 95).transform("ch_combination_double", l(n, 94, 0, t.dc(n, 92, 0, t.Ub(n, 93).transform(5)))));
                    l(n, 92, 0, s), l(n, 98, 0, t.dc(n, 98, 0, t.Ub(n, 99).transform(u.SpeedwayMarkets.even_odd))), l(n, 103, 0, t.dc(n, 103, 0, t.Ub(n, 104).transform("ch_return")));
                    var i = t.dc(n, 106, 0, t.Ub(n, 109).transform("ch_winner_even", l(n, 108, 0, t.dc(n, 106, 0, t.Ub(n, 107).transform(5)))));
                    l(n, 106, 0, i), l(n, 112, 0, t.dc(n, 112, 0, t.Ub(n, 113).transform(u.SpeedwayMarkets.over_under))), l(n, 117, 0, t.dc(n, 117, 0, t.Ub(n, 118).transform("ch_return")));
                    var o = t.dc(n, 120, 0, t.Ub(n, 123).transform("ch_winner_higher_half_range", l(n, 122, 0, t.dc(n, 120, 0, t.Ub(n, 121).transform(6)))));
                    l(n, 120, 0, o), l(n, 126, 0, t.dc(n, 126, 0, t.Ub(n, 127).transform("ch_codes")), t.dc(n, 126, 1, t.Ub(n, 128).transform("ch_random"))), l(n, 132, 0, t.dc(n, 132, 0, t.Ub(n, 133).transform("ch_market"))), l(n, 135, 0, t.dc(n, 135, 0, t.Ub(n, 136).transform("ch_code"))), l(n, 138, 0, t.dc(n, 138, 0, t.Ub(n, 139).transform("ch_examples"))), l(n, 141, 0, t.dc(n, 141, 0, t.Ub(n, 142).transform("ch_description"))), l(n, 145, 0, t.dc(n, 145, 0, t.Ub(n, 146).transform(u.SpeedwayMarkets.win))), l(n, 150, 0, t.dc(n, 150, 0, t.Ub(n, 151).transform("ch_return")));
                    var b = t.dc(n, 153, 0, t.Ub(n, 156).transform("ch_random_winner", l(n, 155, 0, t.dc(n, 153, 0, t.Ub(n, 154).transform(1)))));
                    l(n, 153, 0, b), l(n, 159, 0, t.dc(n, 159, 0, t.Ub(n, 160).transform(u.SpeedwayMarkets.exacta))), l(n, 164, 0, t.dc(n, 164, 0, t.Ub(n, 165).transform("ch_return")));
                    var d = t.dc(n, 167, 0, t.Ub(n, 170).transform("ch_1st_2nd", l(n, 169, 0, t.dc(n, 167, 0, t.Ub(n, 168).transform(2)))));
                    l(n, 167, 0, d), l(n, 173, 0, t.dc(n, 173, 0, t.Ub(n, 174).transform(u.SpeedwayMarkets.quinella))), l(n, 178, 0, t.dc(n, 178, 0, t.Ub(n, 179).transform("ch_return")));
                    var p = t.dc(n, 181, 0, t.Ub(n, 184).transform("ch_random_1st_2nd", l(n, 183, 0, t.dc(n, 181, 0, t.Ub(n, 182).transform(3)))));
                    l(n, 181, 0, p), l(n, 187, 0, t.dc(n, 187, 0, t.Ub(n, 188).transform(u.SpeedwayMarkets.place))), l(n, 192, 0, t.dc(n, 192, 0, t.Ub(n, 193).transform("ch_return")));
                    var h = t.dc(n, 195, 0, t.Ub(n, 198).transform("ch_participant_1st_2nd", l(n, 197, 0, t.dc(n, 195, 0, t.Ub(n, 196).transform(5)))));
                    l(n, 195, 0, h), l(n, 201, 0, t.dc(n, 201, 0, t.Ub(n, 202).transform(u.SpeedwayMarkets.even_odd))), l(n, 206, 0, t.dc(n, 206, 0, t.Ub(n, 207).transform("ch_return")));
                    var f = t.dc(n, 209, 0, t.Ub(n, 212).transform("ch_winner_even_odd", l(n, 211, 0, t.dc(n, 209, 0, t.Ub(n, 210).transform(7)))));
                    l(n, 209, 0, f), l(n, 215, 0, t.dc(n, 215, 0, t.Ub(n, 216).transform(u.SpeedwayMarkets.over_under))), l(n, 220, 0, t.dc(n, 220, 0, t.Ub(n, 221).transform("ch_return")));
                    var _ = t.dc(n, 223, 0, t.Ub(n, 226).transform("ch_winner_higher_lower_range", l(n, 225, 0, t.dc(n, 223, 0, t.Ub(n, 224).transform(8)))));
                    l(n, 223, 0, _)
                }))
            }
            var ln = t.Eb("gr-fastbet-help-speedwaydirttrack", dl, (function(l) {
                    return t.ec(0, [(l()(), t.Ib(0, 0, null, null, 1, "gr-fastbet-help-speedwaydirttrack", [], null, null, null, Jl, Ll)), t.Hb(1, 114688, null, 0, dl, [W.k], null, null)], (function(l, n) {
                        l(n, 1, 0)
                    }), null)
                }), {
                    participants: "participants"
                }, {
                    close: "close"
                }, []),
                nn = u("gIcY"),
                un = u("M3iF"),
                tn = u("tfG9"),
                en = u("t/Na"),
                cn = u("7oEI"),
                rn = u("ojct"),
                an = u("hIlf"),
                sn = u("ssOW"),
                on = u("96LH"),
                bn = u("ZYCi"),
                dn = u("4hpQ"),
                pn = u("7x4Y"),
                hn = u("QFAn"),
                fn = u("iz+u"),
                _n = u("sJrH"),
                kn = t.Fb(e, [], (function(l) {
                    return t.Rb([t.Sb(512, t.l, t.qb, [
                        [8, [c.a, r.a, a.a, s.c, i.a, o.a, b.a, d.a, p.a, h.a, f.a, _.a, Cl, Gl, ql, $l, ln]],
                        [3, t.l], t.G
                    ]), t.Sb(4608, v.o, v.n, [t.C, [2, v.C]]), t.Sb(4608, nn.r, nn.r, []), t.Sb(4608, un.c, un.c, []), t.Sb(4608, tn.a, tn.a, [v.d]), t.Sb(4608, en.h, en.n, [v.d, t.L, en.l]), t.Sb(4608, en.o, en.o, [en.h, en.m]), t.Sb(5120, en.a, (function(l) {
                        return [l]
                    }), [en.o]), t.Sb(4608, en.k, en.k, []), t.Sb(6144, en.i, null, [en.k]), t.Sb(4608, en.g, en.g, [en.i]), t.Sb(6144, en.b, null, [en.g]), t.Sb(4608, en.f, en.j, [en.b, t.y]), t.Sb(4608, en.c, en.c, [en.f]), t.Sb(4608, cn.a, cn.a, [t.l, rn.a]), t.Sb(4608, an.a, an.a, [en.c, sn.a]), t.Sb(4608, on.a, on.a, [k.a, an.a]), t.Sb(1073742336, v.c, v.c, []), t.Sb(1073742336, bn.p, bn.p, [
                        [2, bn.u],
                        [2, bn.l]
                    ]), t.Sb(1073742336, W.h, W.h, []), t.Sb(1073742336, dn.a, dn.a, []), t.Sb(1073742336, nn.q, nn.q, []), t.Sb(1073742336, nn.e, nn.e, []), t.Sb(1073742336, pn.a, pn.a, []), t.Sb(1073742336, un.b, un.b, []), t.Sb(1073742336, hn.a, hn.a, []), t.Sb(1073742336, fn.a, fn.a, []), t.Sb(1073742336, en.e, en.e, []), t.Sb(1073742336, en.d, en.d, []), t.Sb(1073742336, _n.a, _n.a, []), t.Sb(1073742336, e, e, []), t.Sb(256, en.l, "XSRF-TOKEN", []), t.Sb(256, en.m, "X-XSRF-TOKEN", []), t.Sb(1024, bn.j, (function() {
                        return [
                            [{
                                path: "",
                                component: hl,
                                resolve: {
                                    ThemeResolver: on.a
                                }
                            }]
                        ]
                    }), []), t.Sb(256, sn.a, "clients/{{name}}/races.skin.css", [])])
                }))
        }
    }
]);