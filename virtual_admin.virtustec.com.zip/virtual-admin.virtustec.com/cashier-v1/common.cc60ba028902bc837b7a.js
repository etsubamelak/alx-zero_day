(window.webpackJsonp = window.webpackJsonp || []).push([
    [0], {
        "/N0Y": function(e, t, n) {
            "use strict";

            function r(e, t) {
                return void 0 === t && (t = "text/css"), new Promise((function(n, r) {
                    var o = new XMLHttpRequest;
                    o.onreadystatechange = function() {
                        if (o.readyState === XMLHttpRequest.DONE)
                            if (200 === o.status)
                                if ("image/png" === t) {
                                    var i = new FileReader;
                                    i.onload = function() {
                                        n(i.result)
                                    }, i.readAsDataURL(o.response)
                                } else n(o.responseText);
                        else 404 === o.status && r(new Error("ERROR: " + e + " not found (404)"))
                    }, o.open("GET", e), "image/png" === t && (o.responseType = "blob"), o.setRequestHeader("Accept", t), o.setRequestHeader("Content-Type", t), o.send()
                }))
            }
            n.d(t, "a", (function() {
                return r
            }))
        },
        "31BE": function(e, t, n) {
            "use strict";
            n.d(t, "a", (function() {
                return c
            }));
            var r, o = n("aGNc"),
                i = n("p0Sj"),
                l = n("VnD/"),
                s = n("xMyE"),
                a = n("D1+H"),
                u = (r = function(e, t) {
                    return (r = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(e, t) {
                            e.__proto__ = t
                        } || function(e, t) {
                            for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                        })(e, t)
                }, function(e, t) {
                    function n() {
                        this.constructor = e
                    }
                    r(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                }),
                c = function(e) {
                    function t(t) {
                        return e.call(this, t) || this
                    }
                    return u(t, e), t.prototype.ngOnDestroy = function() {
                        e.prototype.ngOnDestroy.call(this)
                    }, t.prototype.onAfterInit = function() {
                        var t = this;
                        return this.subscriptions.add(this.betslipService.onRebet.pipe(Object(o.a)(!0), Object(i.a)(this.betslipService.hasRebets()), Object(l.a)((function(e) {
                            return e
                        })), Object(s.a)((function() {
                            return t.betslipService.rebet(t.eventBlock, t.eventBlock.events[0])
                        }))).subscribe()), e.prototype.onAfterInit.call(this)
                    }, t
                }(a.a)
        },
        "Dx3/": function(e, t, n) {
            "use strict";
            n.d(t, "b", (function() {
                return r
            })), n.d(t, "c", (function() {
                return o
            })), n.d(t, "a", (function() {
                return i
            }));
            var r = "__CONNECTED__",
                o = "__DISCONNECTED__",
                i = "__CONNECTED_TOO__"
        },
        GH7p: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, "BrowserPrinter", (function() {
                return a
            }));
            var r = n("yKJU"),
                o = n("Ucdj"),
                i = n("CrY/"),
                l = function(e, t, n, r) {
                    return new(n || (n = Promise))((function(o, i) {
                        function l(e) {
                            try {
                                a(r.next(e))
                            } catch (t) {
                                i(t)
                            }
                        }

                        function s(e) {
                            try {
                                a(r.throw(e))
                            } catch (t) {
                                i(t)
                            }
                        }

                        function a(e) {
                            var t;
                            e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                                e(t)
                            }))).then(l, s)
                        }
                        a((r = r.apply(e, t || [])).next())
                    }))
                },
                s = function(e, t) {
                    var n, r, o, i, l = {
                        label: 0,
                        sent: function() {
                            if (1 & o[0]) throw o[1];
                            return o[1]
                        },
                        trys: [],
                        ops: []
                    };
                    return i = {
                        next: s(0),
                        throw: s(1),
                        return: s(2)
                    }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                        return this
                    }), i;

                    function s(i) {
                        return function(s) {
                            return function(i) {
                                if (n) throw new TypeError("Generator is already executing.");
                                for (; l;) try {
                                    if (n = 1, r && (o = 2 & i[0] ? r.return : i[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, i[1])).done) return o;
                                    switch (r = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                        case 0:
                                        case 1:
                                            o = i;
                                            break;
                                        case 4:
                                            return l.label++, {
                                                value: i[1],
                                                done: !1
                                            };
                                        case 5:
                                            l.label++, r = i[1], i = [0];
                                            continue;
                                        case 7:
                                            i = l.ops.pop(), l.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = l.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                                l = 0;
                                                continue
                                            }
                                            if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                                l.label = i[1];
                                                break
                                            }
                                            if (6 === i[0] && l.label < o[1]) {
                                                l.label = o[1], o = i;
                                                break
                                            }
                                            if (o && l.label < o[2]) {
                                                l.label = o[2], l.ops.push(i);
                                                break
                                            }
                                            o[2] && l.ops.pop(), l.trys.pop();
                                            continue
                                    }
                                    i = t.call(e, l)
                                } catch (s) {
                                    i = [6, s], r = 0
                                } finally {
                                    n = o = 0
                                }
                                if (5 & i[0]) throw i[1];
                                return {
                                    value: i[0] ? i[1] : void 0,
                                    done: !0
                                }
                            }([i, s])
                        }
                    }
                },
                a = function() {
                    function e(e, t, n) {
                        this.printerControllerConfig = e, this.onTicketPrinted = t, this.i18n = n, this.hasInitError = null, this.printer = new r.a
                    }
                    return e.prototype.getPrintersAvailable = function(e) {
                        return l(this, void 0, void 0, (function() {
                            return s(this, (function(e) {
                                return [2, void 0]
                            }))
                        }))
                    }, e.prototype.getPrinterToUse = function() {
                        return l(this, void 0, void 0, (function() {
                            return s(this, (function(e) {
                                throw new Error("ERROR: BROWSER MODE not support getPrinterToUse method.")
                            }))
                        }))
                    }, e.prototype.cleanPrinterToUse = function() {
                        return l(this, void 0, void 0, (function() {
                            return s(this, (function(e) {
                                throw new Error("ERROR: BROWSER MODE not support cleanPrinterToUse method.")
                            }))
                        }))
                    }, e.prototype.setPrinterToUse = function(e) {
                        return l(this, void 0, void 0, (function() {
                            return s(this, (function(e) {
                                throw new Error("ERROR: BROWSER MODE not support setPrinterToUse method.")
                            }))
                        }))
                    }, e.prototype.init = function() {
                        return l(this, void 0, void 0, (function() {
                            var e;
                            return s(this, (function(t) {
                                e = {
                                    scope: i.coreModel.ErrorInfo.ScopeEnum.CLIENT,
                                    errorCode: null,
                                    message: "BROWSERPRINTER_NOT_INIT",
                                    param: null,
                                    resource: null,
                                    extData: null,
                                    expiredTime: null
                                };
                                try {
                                    return [2, !0]
                                } catch (n) {
                                    throw console.log(n), e.param = n, this.hasInitError = e, n
                                }
                                return [2]
                            }))
                        }))
                    }, e.prototype.print = function(e) {
                        return l(this, void 0, void 0, (function() {
                            var t, n, r, l, a, u, c, p;
                            return s(this, (function(s) {
                                switch (s.label) {
                                    case 0:
                                        return this.isManagerAvailable() ? (t = i.coreModel.PrintProfileSettings.ContentTypeEnum.HTML, [4, this.loadTicketGenerator(t)]) : [3, 9];
                                    case 1:
                                        s.sent(), (n = new o.a).serverTickets = e.map((function(e) {
                                            return e.serverTicket
                                        })), r = e.length, l = 0, s.label = 2;
                                    case 2:
                                        if (!(l < r)) return [3, 8];
                                        a = e[l], s.label = 3;
                                    case 3:
                                        return s.trys.push([3, 6, , 7]), [4, this.ticketGenerator.createTicketBody(a)];
                                    case 4:
                                        return u = s.sent(), [4, this.printer.printHtml(u, {
                                            printMode: this.printerControllerConfig.browserPrinterMode ? this.printerControllerConfig.browserPrinterMode : o.b.DEFAULT,
                                            popupProperties: this.getWindowPopupProperties(),
                                            stylesheets: this.printerControllerConfig.cssBasePath + "ticket.css"
                                        })];
                                    case 5:
                                        return s.sent(), this.onTicketPrinted.execute({
                                            error: null,
                                            serverTicket: a.serverTicket,
                                            length: r,
                                            ndx: l
                                        }), n.successPrint.push(a.serverTicket), [3, 7];
                                    case 6:
                                        return c = s.sent(), p = {
                                            error: c,
                                            serverTicket: a.serverTicket
                                        }, n.failPrint.push(p), [3, 7];
                                    case 7:
                                        return l++, [3, 2];
                                    case 8:
                                        return [2, n];
                                    case 9:
                                        throw new Error("ERROR: BrowserPrinter - print, no Manager available.")
                                }
                            }))
                        }))
                    }, e.prototype.printCashTicket = function(e) {
                        return l(this, void 0, void 0, (function() {
                            var t, n, r, l;
                            return s(this, (function(s) {
                                switch (s.label) {
                                    case 0:
                                        return this.isManagerAvailable() ? (t = i.coreModel.PrintProfileSettings.ContentTypeEnum.HTML, [4, this.loadTicketGenerator(t)]) : [3, 7];
                                    case 1:
                                        s.sent(), (n = new o.h).serverTicket = e.serverTicket, n.length = 1, n.ndx = 0, n.error = null, s.label = 2;
                                    case 2:
                                        return s.trys.push([2, 5, , 6]), [4, this.ticketGenerator.createCashTicketBody(e)];
                                    case 3:
                                        return r = s.sent(), [4, this.printer.printHtml(r, {
                                            printMode: this.printerControllerConfig.browserPrinterMode ? this.printerControllerConfig.browserPrinterMode : o.b.DEFAULT,
                                            popupProperties: this.getWindowPopupProperties(),
                                            stylesheets: this.printerControllerConfig.cssBasePath + "ticket.css"
                                        })];
                                    case 4:
                                        return s.sent(), this.onTicketPrinted.execute(n), [3, 6];
                                    case 5:
                                        return l = s.sent(), n.error = l, this.onTicketPrinted.execute(n), [3, 6];
                                    case 6:
                                        return [2, n];
                                    case 7:
                                        throw new Error("ERROR: BrowserPrinter - print, no Manager available.")
                                }
                            }))
                        }))
                    }, e.prototype.printLocalUserTicket = function(e, t) {
                        return l(this, void 0, void 0, (function() {
                            var n, r, l, a;
                            return s(this, (function(s) {
                                switch (s.label) {
                                    case 0:
                                        return this.isManagerAvailable() ? (n = i.coreModel.PrintProfileSettings.ContentTypeEnum.HTML, [4, this.loadTicketGenerator(n)]) : [3, 7];
                                    case 1:
                                        s.sent(), (r = new o.h).serverTicket = e.serverTicket, r.length = 1, r.ndx = 0, r.error = null, s.label = 2;
                                    case 2:
                                        return s.trys.push([2, 5, , 6]), [4, this.ticketGenerator.createLocalUserTicketBody(e, t)];
                                    case 3:
                                        return l = s.sent(), [4, this.printer.printHtml(l, {
                                            printMode: this.printerControllerConfig.browserPrinterMode ? this.printerControllerConfig.browserPrinterMode : o.b.DEFAULT,
                                            popupProperties: this.getWindowPopupProperties(),
                                            stylesheets: this.printerControllerConfig.cssBasePath + "ticket.css"
                                        })];
                                    case 4:
                                        return s.sent(), this.onTicketPrinted.execute(r), [3, 6];
                                    case 5:
                                        return a = s.sent(), r.error = a, this.onTicketPrinted.execute(r), [3, 6];
                                    case 6:
                                        return [2, r];
                                    case 7:
                                        throw new Error("ERROR: BrowserPrinter - print, no Manager available.")
                                }
                            }))
                        }))
                    }, e.prototype.printReport = function(e) {
                        return l(this, void 0, void 0, (function() {
                            var t, n;
                            return s(this, (function(r) {
                                switch (r.label) {
                                    case 0:
                                        return this.isManagerAvailable() ? (t = i.coreModel.PrintProfileSettings.ContentTypeEnum.HTML, [4, this.loadTicketGenerator(t)]) : [3, 7];
                                    case 1:
                                        r.sent(), r.label = 2;
                                    case 2:
                                        return r.trys.push([2, 5, , 6]), [4, this.ticketGenerator.createReportBody(e)];
                                    case 3:
                                        return n = r.sent(), [4, this.printer.printHtml(n, {
                                            printMode: this.printerControllerConfig.browserPrinterMode ? this.printerControllerConfig.browserPrinterMode : o.b.DEFAULT,
                                            popupProperties: this.getWindowPopupProperties(),
                                            stylesheets: this.printerControllerConfig.cssBasePath + "ticket.css"
                                        })];
                                    case 4:
                                        return r.sent(), [2];
                                    case 5:
                                        throw r.sent();
                                    case 6:
                                        return [3, 8];
                                    case 7:
                                        throw new Error("ERROR: BrowserPrinter - printReport, no Manager available.");
                                    case 8:
                                        return [2]
                                }
                            }))
                        }))
                    }, e.prototype.printLastResults = function(e) {
                        return l(this, void 0, void 0, (function() {
                            var t, n;
                            return s(this, (function(r) {
                                switch (r.label) {
                                    case 0:
                                        return this.isManagerAvailable() ? (t = i.coreModel.PrintProfileSettings.ContentTypeEnum.HTML, [4, this.loadTicketGenerator(t)]) : [3, 7];
                                    case 1:
                                        r.sent(), r.label = 2;
                                    case 2:
                                        return r.trys.push([2, 5, , 6]), [4, this.ticketGenerator.createLastResultsBody(e)];
                                    case 3:
                                        return n = r.sent(), [4, this.printer.printHtml(n, {
                                            printMode: this.printerControllerConfig.browserPrinterMode ? this.printerControllerConfig.browserPrinterMode : o.b.DEFAULT,
                                            popupProperties: this.getWindowPopupProperties(),
                                            stylesheets: this.printerControllerConfig.cssBasePath + "ticket.css"
                                        })];
                                    case 4:
                                        return r.sent(), [2];
                                    case 5:
                                        throw r.sent();
                                    case 6:
                                        return [3, 8];
                                    case 7:
                                        throw new Error("ERROR: BrowserPrinter - printLastResults, no Manager available.");
                                    case 8:
                                        return [2]
                                }
                            }))
                        }))
                    }, e.prototype.setLanguage = function(e) {
                        return l(this, void 0, void 0, (function() {
                            return s(this, (function(t) {
                                if (!this.isManagerAvailable()) throw new Error("ERROR: BrowserPrinter - setLanguage, no Manager available.");
                                return this.printerControllerConfig.langCode = e, [2]
                            }))
                        }))
                    }, e.prototype.setOddFormat = function(e) {
                        return l(this, void 0, void 0, (function() {
                            return s(this, (function(t) {
                                if (!this.isManagerAvailable()) throw new Error("ERROR: BrowserPrinter - setOddFormat, no Manager available.");
                                return this.printerControllerConfig.oddFormat = e, [2]
                            }))
                        }))
                    }, e.prototype.isManagerAvailable = function() {
                        if (null === this.hasInitError) return !0;
                        throw this.hasInitError
                    }, e.prototype.loadTicketGenerator = function(e) {
                        return l(this, void 0, void 0, (function() {
                            var t;
                            return s(this, (function(r) {
                                switch (r.label) {
                                    case 0:
                                        return e !== i.coreModel.PrintProfileSettings.ContentTypeEnum.HTML ? [3, 2] : [4, Promise.all([n.e(0), n.e(9)]).then(n.bind(null, "EACO"))];
                                    case 1:
                                        return t = r.sent(), this.ticketGenerator = new t.HtmlTicketGenerator(this.printerControllerConfig, this.i18n), [3, 4];
                                    case 2:
                                        return [4, Promise.all([n.e(0), n.e(11)]).then(n.bind(null, "iURD"))];
                                    case 3:
                                        t = r.sent(), this.ticketGenerator = new t.PosTicketGenerator(this.printerControllerConfig, this.i18n), r.label = 4;
                                    case 4:
                                        return [4, this.ticketGenerator.init()];
                                    case 5:
                                        return [2, r.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.preloadCSS = function(e) {
                        return new Promise((function(t, n) {
                            var r = document.createElement("link");
                            r.setAttribute("rel", "stylesheet"), r.setAttribute("type", "text/css"), r.onload = function() {
                                t(!0)
                            }, r.setAttribute("href", e), document.getElementsByTagName("head")[0].appendChild(r)
                        }))
                    }, e.prototype.getWindowPopupProperties = function() {
                        return this.printerControllerConfig.browserPrinterMode === o.b.WINDOW_POPUP ? "fullscreen=yes" : ""
                    }, e
                }()
        },
        MakA: function(e, t, n) {
            "use strict";
            n.d(t, "a", (function() {
                return c
            })), n.d(t, "b", (function() {
                return f
            }));
            var r = n("CcnG"),
                o = (n("CrY/"), n("pugT")),
                i = n("sylN"),
                l = function() {
                    function e(e, t) {
                        this.cd = e, this.betslipService = t, this.isInactive = !1, this.isActive = !1, this.isDisabled = !1, this.subscriptions = new o.a
                    }
                    return e.prototype.ngOnInit = function() {
                        this.onInit()
                    }, e.prototype.ngOnChanges = function(e) {
                        (e.event && !e.event.isFirstChange() || e.odd && !e.odd.isFirstChange()) && (this.unsubscribe(), this.remove(), this.onInit())
                    }, e.prototype.ngOnDestroy = function() {
                        this.unsubscribe()
                    }, e.prototype.onClick = function() {
                        this.isDisabled || (this.isActive ? this.remove() : this.add())
                    }, e.prototype.onInit = function() {
                        this.odd ? (this.isDisabled = !this.odd._clData.isEnabledToBet(), this.isActive = this.betslipService.hasOdd(this.event, this.odd), this.ticketSubscriptions()) : this.isInactive = !0
                    }, e.prototype.unsubscribe = function() {
                        this.subscriptions.unsubscribe()
                    }, e.prototype.add = function() {
                        this.isActive || this.isInactive || this.betslipService.addBets([{
                            playlist: this.event._clData.playlist,
                            eventBlock: this.event._clData.parentEventBlock,
                            event: this.event,
                            odd: this.odd
                        }])
                    }, e.prototype.remove = function() {
                        this.isActive && this.betslipService.removeBet(this.event._clData.playlist.id, this.event.eventId, this.odd.id)
                    }, e.prototype.ticketSubscriptions = function() {
                        var e = this;
                        this.subscriptions = new o.a, this.subscriptions.add(this.betslipService.onTicketBetAdded.subscribe((function(t) {
                            t.some((function(t) {
                                return e.equals({
                                    playlistId: t.eventBlock.playlistId,
                                    eventId: t.event.eventId,
                                    oddId: t.oddId
                                })
                            })) && e.activate()
                        }))), this.subscriptions.add(this.betslipService.onTicketBetRemoved.subscribe((function(t) {
                            e.equals({
                                playlistId: t.playlistId,
                                eventId: t.eventId,
                                oddId: t.oddId
                            }) && e.deactivate()
                        }))), this.subscriptions.add(this.betslipService.onClear.subscribe((function() {
                            e.deactivate()
                        })))
                    }, e.prototype.equals = function(e) {
                        return e.eventId === this.event.eventId && e.playlistId === this.event._clData.playlist.id && e.oddId === this.odd.id
                    }, e.prototype.activate = function() {
                        this.isActive = !0, this.cd.markForCheck()
                    }, e.prototype.deactivate = function() {
                        this.isActive = !1, this.cd.markForCheck()
                    }, e
                }(),
                s = n("Ip0R"),
                a = n("2Iqj"),
                u = [
                    [".odd[_ngcontent-%COMP%]{width:100%;height:100%;font-size:22px;font-weight:700;text-align:center;cursor:pointer;border-radius:2px;box-shadow:0 0 2px 0 rgba(0,0,0,.14),0 2px 2px 0 rgba(0,0,0,.12),0 1px 3px 0 rgba(0,0,0,.2)}.odd__info[_ngcontent-%COMP%]{position:relative;height:100%}.odd__name[_ngcontent-%COMP%]{padding:5px 0 7px;font-size:18px}.odd__value[_ngcontent-%COMP%]{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%)}.odd.odd--disabled[_ngcontent-%COMP%]{opacity:.2}.odd--inactive[_ngcontent-%COMP%]{opacity:.3}.more-markets--padding[_ngcontent-%COMP%]{padding-bottom:7px}"]
                ],
                c = r.Gb({
                    encapsulation: 0,
                    styles: u,
                    data: {}
                });

            function p(e) {
                return r.ec(0, [(e()(), r.Ib(0, 0, null, null, 1, "div", [
                    ["class", "odd__name"]
                ], null, null, null, null, null)), r.Tb(null, 0)], null, null)
            }

            function d(e) {
                return r.ec(0, [(e()(), r.Ib(0, 0, null, null, 1, null, null, null, null, null, null, null)), (e()(), r.cc(1, null, [" ", " "]))], null, (function(e, t) {
                    e(t, 1, 0, t.component.odd.value)
                }))
            }

            function h(e) {
                return r.ec(0, [(e()(), r.Ib(0, 0, null, null, 1, "span", [
                    ["class", "odd--inactive"]
                ], null, null, null, null, null)), (e()(), r.cc(-1, null, ["-"]))], null, null)
            }

            function f(e) {
                return r.ec(2, [(e()(), r.Ib(0, 0, null, null, 10, "div", [
                    ["class", "odd"],
                    ["grcOdd", ""]
                ], [
                    [2, "odd--inactive", null],
                    [2, "odd--active", null],
                    [2, "odd--disabled", null]
                ], [
                    [null, "click"]
                ], (function(e, t, n) {
                    var o = !0;
                    "click" === t && (o = !1 !== r.Ub(e, 1).onClick() && o);
                    return o
                }), null, null)), r.Hb(1, 737280, null, 0, l, [r.i, i.a], {
                    odd: [0, "odd"],
                    event: [1, "event"]
                }, null), (e()(), r.Ib(2, 0, null, null, 8, "div", [
                    ["class", "odd__info"]
                ], null, null, null, null, null)), (e()(), r.xb(16777216, null, null, 1, null, p)), r.Hb(4, 16384, null, 0, s.m, [r.eb, r.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (e()(), r.Ib(5, 0, null, null, 5, "div", [], null, null, null, null, null)), r.Zb(512, null, s.x, s.y, [r.A, r.B, r.o, r.P]), r.Hb(7, 278528, null, 0, s.k, [s.x], {
                    ngClass: [0, "ngClass"]
                }, null), (e()(), r.xb(16777216, null, null, 1, null, d)), r.Hb(9, 16384, null, 0, s.m, [r.eb, r.Z], {
                    ngIf: [0, "ngIf"],
                    ngIfElse: [1, "ngIfElse"]
                }, null), (e()(), r.xb(0, [
                    ["noValue", 2]
                ], null, 0, null, h))], (function(e, t) {
                    var n = t.component;
                    e(t, 1, 0, n.odd, n.event), e(t, 4, 0, n.showName), e(t, 7, 0, n.showName ? "more-markets--padding" : "odd__value"), e(t, 9, 0, n.odd && n.odd.value, r.Ub(t, 10))
                }), (function(e, t) {
                    e(t, 0, 0, r.Ub(t, 1).isInactive, r.Ub(t, 1).isActive, r.Ub(t, 1).isDisabled)
                }))
            }
            r.Eb("grc-odd", a.a, (function(e) {
                return r.ec(0, [(e()(), r.Ib(0, 0, null, null, 1, "grc-odd", [], null, null, null, f, c)), r.Hb(1, 114688, null, 0, a.a, [], null, null)], (function(e, t) {
                    e(t, 1, 0)
                }), null)
            }), {
                odd: "odd",
                event: "event",
                showName: "showName"
            }, {}, ["*"])
        },
        NBmb: function(e, t, n) {
            "use strict";
            n.d(t, "a", (function() {
                return a
            }));
            var r = n("WGel"),
                o = n("CrY/"),
                i = n("Qkcr"),
                l = n("ceZE"),
                s = n("Ucdj"),
                a = function() {
                    function e() {}
                    return e.createStaticAssets = function(e, t, n, r) {
                        var i, l, s = null != t ? t : "default",
                            a = null,
                            u = n + "/" + s + "/" + s + "_brand.svg",
                            c = null,
                            p = !1;
                        if (e) {
                            switch (a = n + "/default/", c = "ticket_", e.gameType.val) {
                                case o.coreModel.GameType.ValEnum.BASKET:
                                    a += "basket.svg", c += "basket";
                                    break;
                                case o.coreModel.GameType.ValEnum.CH:
                                    if (e.filter && e.filter.isChFilter()) switch (e.filter.competitionSubType) {
                                        case "LEAGUE":
                                            a += "league.svg", c += "league";
                                            break;
                                        case "CHAMPION":
                                            a += "champions.svg", c += "champions";
                                            break;
                                        case "CUP":
                                            a += "cup.svg", c += "cup";
                                            break;
                                        case "SOCCER":
                                            a += "soccer.svg", c += "soccer";
                                            break;
                                        case "LIBERTADORES":
                                            a += "libertadores.svg", c += "libertadores";
                                            break;
                                        case "WORLDCUP":
                                            a += "worldcup.svg", c += "worldcup";
                                            break;
                                        case "EUROCUP":
                                            a += "eurocup.svg", c += "eurocup";
                                            break;
                                        case "AFRICACUP":
                                            a += "africacup.svg", c += "africacup"
                                    }
                                    break;
                                case o.coreModel.GameType.ValEnum.KN:
                                    if (e.filter && e.filter.isKnFilter()) {
                                        if (e.assets && e.assets.isKnAssets() && e.assets.iconId && "kinel8" === e.assets.iconId.toLowerCase()) {
                                            a += "kinel8.svg", c += "kinel8";
                                            break
                                        }
                                        e.mode === o.coreModel.Playlist.ModeEnum.LIVE ? (a += "live-keno.svg", c += "keno") : e.filter && e.filter.isKnFilter() && (e.filter.mode === o.coreModel.KnFilter.ModeEnum.DELUXE ? (a += "kd.svg", c += "keno") : (a += "keno.svg", c += "keno"))
                                    }
                                    break;
                                case o.coreModel.GameType.ValEnum.SN:
                                    e.filter && e.filter.isSnFilter() && (e.filter.mode === o.coreModel.SnFilter.ModeEnum.CLASSIC ? e.filter.spinType === o.coreModel.SnFilter.SpinTypeEnum.EUROPEAN ? (a += "sn.svg", c += "sn") : (a += "sn-american.svg", c += "sn") : e.filter.spinType === o.coreModel.SnFilter.SpinTypeEnum.EUROPEAN ? (a += "sn-royale.svg", c += "sn") : (a += "sn-am-royale.svg", c += "sn"));
                                    break;
                                case o.coreModel.GameType.ValEnum.S2W:
                                    a += "s2.svg", c += "s2w";
                                    break;
                                case o.coreModel.GameType.ValEnum.DIRTTRACK:
                                    a += "dirttrack.svg", c += "dirttrack";
                                    break;
                                case o.coreModel.GameType.ValEnum.DOG:
                                    a += "dog.svg", c += "dog";
                                    break;
                                case o.coreModel.GameType.ValEnum.FIGHT:
                                    a += "fight.svg", c += "fight";
                                    break;
                                case o.coreModel.GameType.ValEnum.GRANDPRIX:
                                    a += "grandprix.svg", c += "grandprix";
                                    break;
                                case o.coreModel.GameType.ValEnum.HORSE:
                                    a += "horse-" + ((null == e ? void 0 : e.filter.isHorseFilter()) && (null == e ? void 0 : e.filter.numParticipants)) + ".svg", c += "horse";
                                    break;
                                case o.coreModel.GameType.ValEnum.KART:
                                    a += "kart.svg", c += "kart";
                                    break;
                                case o.coreModel.GameType.ValEnum.LL:
                                    a += "m6.svg", c += "ll";
                                    break;
                                case o.coreModel.GameType.ValEnum.MOTORBIKE:
                                    a += "motorbike.svg", c += "motorbike";
                                    break;
                                case o.coreModel.GameType.ValEnum.RAINBOW:
                                    var d = "COLOR_COLOR" === (null === (i = null == e ? void 0 : e.assets) || void 0 === i ? void 0 : i.layout) ? "color-color" : "rainbow";
                                    a += d + ".svg", c += d;
                                    break;
                                case o.coreModel.GameType.ValEnum.SPEEDWAY:
                                    a += "speedway.svg", c += "speedway";
                                    break;
                                case o.coreModel.GameType.ValEnum.SX:
                                    "kings_lucky_ball" === (null === (l = null == e ? void 0 : e.assets) || void 0 === l ? void 0 : l.iconId) ? a += "klb.svg": a += "sx.svg", c += "sx";
                                    break;
                                case o.coreModel.GameType.ValEnum.TROTTING:
                                    a += "trotting.svg", c += "trotting";
                                    break;
                                case o.coreModel.GameType.ValEnum.GENERIC:
                                    a += "generic.svg", c += "generic";
                                    break;
                                case o.coreModel.GameType.ValEnum.MMA:
                                    e.filter && e.filter.isMmaFilter() && (e.filter.competitionType === o.coreModel.MmaFilter.CompetitionTypeEnum.SINGLE ? (a += "mma.svg", c += "mma") : (a += "mma-tournament.svg", c += "mma-tournament"));
                                    break;
                                default:
                                    throw new Error("ERROR: game " + e.gameType.val)
                            }
                            var h = o.coreModel.GameType.ValEnum;
                            p = [h.LL, h.SN, h.SX, h.KN, h.S2W, h.RAINBOW].findIndex((function(t) {
                                return t === e.gameType.val
                            })) >= 0
                        }
                        if (r === o.coreModel.PrintProfileSettings.ContentTypeEnum.POS) {
                            if (!/(https?:\/\/)/g.test(n)) {
                                var f = window.location;
                                a = a ? "" + f.origin + f.pathname + a : null, u = u ? "" + f.origin + f.pathname + u : null
                            }
                            a = a ? a.replace(".svg", ".png") : null, u = u ? u.replace(".svg", ".png") : null
                        }
                        return {
                            logoImg: {
                                url: a,
                                gameI18nTag: c,
                                brand: u
                            },
                            bodyImg: "",
                            disableOddFormat: p
                        }
                    }, e.createBarcode = function(e, t) {
                        return "" + l.a.padLeft(e.toString(), 9, "0") + (t || "")
                    }, e.createQRUrl = function(e, t, n) {
                        return e + "/?t=" + Number(t.replace(/[a-zA-Z]/g, "")).toString()
                    }, e.getTicketContentType = function(t, n, r) {
                        var i = e.isSupportedLangToPOSPrinting(r),
                            l = o.coreModel.PrintProfileSettings.ContentTypeEnum.HTML;
                        return t === o.coreModel.PrintProfileSettings.ContentTypeEnum.POS && n === s.e.BET && i && (l = o.coreModel.PrintProfileSettings.ContentTypeEnum.POS), l
                    }, e.isSupportedLangToPOSPrinting = function(e) {
                        return !["ru_RU", "ko_KR", "ja_JP", "ar_AR", "th_TH", "ka_GE", "hi_IN", "vi_VN", "zh_CN", "zh_TW"].includes(e)
                    }, e.getOddFormat = function(e, t) {
                        switch (t) {
                            case o.coreModel.Odd.OddFormatEnum.FRACTIONAL:
                                return e._clData.fractionalValue;
                            case o.coreModel.Odd.OddFormatEnum.AMERICAN:
                                return e._clData.americanValue;
                            case o.coreModel.Odd.OddFormatEnum.AMERICAN_ROUNDED:
                                return e._clData.americanRoundedValue;
                            case o.coreModel.Odd.OddFormatEnum.MALAY:
                                return e._clData.malayValue;
                            case o.coreModel.Odd.OddFormatEnum.HK:
                                return e._clData.hongKongValue;
                            case o.coreModel.Odd.OddFormatEnum.INDO:
                                return e._clData.indoValue;
                            default:
                                return e.oddValue
                        }
                    }, e.getMarketTag = function(e, t, n) {
                        return e === i.GameType.ValEnum.GRANDPRIX && t === o.GrandprixMarkets.show ? n.lcm.i18n.getMarketTag("grandprix_show", "", r.TagsProfile.TICKET) : n.lcm.i18n.getMarketTag(t, "", r.TagsProfile.TICKET)
                    }, e
                }()
        },
        Poww: function(e, t, n) {
            "use strict";
            n.d(t, "a", (function() {
                return s
            })), n.d(t, "b", (function() {
                return u
            }));
            var r = n("CcnG"),
                o = n("Ip0R"),
                i = n("D3N7"),
                l = [
                    ["[_nghost-%COMP%]   .grid[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{margin-bottom:6px}.multiplier[_ngcontent-%COMP%]{display:flex;height:66px;align-items:center;justify-content:center;margin:2px;font-size:24px;font-weight:700;cursor:pointer;border-radius:1px;text-transform:lowercase}"]
                ],
                s = r.Gb({
                    encapsulation: 0,
                    styles: l,
                    data: {}
                });

            function a(e) {
                return r.ec(0, [(e()(), r.Ib(0, 0, null, null, 1, "div", [
                    ["class", "col multiplier"]
                ], [
                    [2, "multiplier--active", null]
                ], [
                    [null, "click"]
                ], (function(e, t, n) {
                    var r = !0,
                        o = e.component;
                    "click" === t && (r = !1 !== o.onClick(e.context.$implicit) && r);
                    return r
                }), null, null)), (e()(), r.cc(1, null, [" X", " "]))], null, (function(e, t) {
                    e(t, 0, 0, t.component.isSelected(t.context.$implicit)), e(t, 1, 0, t.context.$implicit)
                }))
            }

            function u(e) {
                return r.ec(2, [(e()(), r.Ib(0, 0, null, null, 2, "div", [
                    ["class", "grid"]
                ], null, null, null, null, null)), (e()(), r.xb(16777216, null, null, 1, null, a)), r.Hb(2, 278528, null, 0, o.l, [r.eb, r.Z, r.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(e, t) {
                    e(t, 2, 0, t.component.multipliers)
                }), null)
            }
            r.Eb("grc-betslip-multiplier", i.a, (function(e) {
                return r.ec(0, [(e()(), r.Ib(0, 0, null, null, 1, "grc-betslip-multiplier", [], null, null, null, u, s)), r.Hb(1, 114688, null, 0, i.a, [], null, null)], (function(e, t) {
                    e(t, 1, 0)
                }), null)
            }), {
                multipliers: "multipliers",
                maxMultiplier: "maxMultiplier"
            }, {
                multiplier: "multiplier",
                isMultiplierInvalid: "isMultiplierInvalid"
            }, [])
        },
        VYBt: function(e, t, n) {
            "use strict";
            n.d(t, "a", (function() {
                return s
            })), n.d(t, "b", (function() {
                return u
            }));
            var r = n("CcnG"),
                o = n("Ip0R"),
                i = n("5y7H"),
                l = [
                    ["[_nghost-%COMP%] > .grid[_ngcontent-%COMP%] > .col[_ngcontent-%COMP%]{padding:6px}.quick-pick[_ngcontent-%COMP%]{font-weight:700}.quick-pick__title[_ngcontent-%COMP%]{margin-bottom:17px;font-size:26px;text-transform:capitalize}.quick-pick__button[_ngcontent-%COMP%]{padding:20px 0;font-size:22px;text-align:center;cursor:pointer;border-radius:2px}"]
                ],
                s = r.Gb({
                    encapsulation: 0,
                    styles: l,
                    data: {}
                });

            function a(e) {
                return r.ec(0, [(e()(), r.Ib(0, 0, null, null, 2, "div", [
                    ["class", "col"]
                ], null, null, null, null, null)), (e()(), r.Ib(1, 0, null, null, 1, "div", [
                    ["class", "quick-pick__button"]
                ], null, [
                    [null, "click"]
                ], (function(e, t, n) {
                    var r = !0,
                        o = e.component;
                    "click" === t && (r = !1 !== o.onClick(e.context.$implicit) && r);
                    return r
                }), null, null)), (e()(), r.cc(2, null, ["", ""]))], null, (function(e, t) {
                    e(t, 2, 0, t.context.$implicit)
                }))
            }

            function u(e) {
                return r.ec(2, [(e()(), r.Ib(0, 0, null, null, 2, "div", [
                    ["class", "grid quick-pick"]
                ], null, null, null, null, null)), (e()(), r.xb(16777216, null, null, 1, null, a)), r.Hb(2, 278528, null, 0, o.l, [r.eb, r.Z, r.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(e, t) {
                    e(t, 2, 0, t.component.numbers)
                }), null)
            }
            r.Eb("gr-quick-pick", i.a, (function(e) {
                return r.ec(0, [(e()(), r.Ib(0, 0, null, null, 1, "gr-quick-pick", [], null, null, null, u, s)), r.Hb(1, 49152, null, 0, i.a, [], null, null)], null, null)
            }), {
                numbers: "numbers"
            }, {
                numberSelected: "numberSelected"
            }, [])
        },
        "mv+f": function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, "setMaxStake", (function() {
                return o
            })), n.d(t, "getMaxStake", (function() {
                return i
            })), n.d(t, "getRandomFromArray", (function() {
                return l
            }));
            var r = Number.MAX_SAFE_INTEGER;

            function o(e) {
                r = e
            }

            function i() {
                return r
            }

            function l(e) {
                return e[Math.floor(Math.random() * e.length)]
            }
        },
        tSS3: function(e, t, n) {
            "use strict";
            n.d(t, "a", (function() {
                return u
            }));
            var r = n("NBmb"),
                o = function() {
                    function e(e) {
                        this.i18n = e
                    }
                    return e.prototype.getCredit = function(e, t, n) {
                        return void 0 === n && (n = !1), this.i18n.location.getCredit(e, {
                            currency: t,
                            useCode: n
                        })
                    }, e.prototype.getPercent = function(e) {
                        return this.i18n.location.getPercentage(e)
                    }, e.prototype.setLanguage = function(e) {
                        return this.i18n.use(e)
                    }, e
                }(),
                i = n("CrY/"),
                l = n("/N0Y"),
                s = function(e, t, n, r) {
                    return new(n || (n = Promise))((function(o, i) {
                        function l(e) {
                            try {
                                a(r.next(e))
                            } catch (t) {
                                i(t)
                            }
                        }

                        function s(e) {
                            try {
                                a(r.throw(e))
                            } catch (t) {
                                i(t)
                            }
                        }

                        function a(e) {
                            var t;
                            e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                                e(t)
                            }))).then(l, s)
                        }
                        a((r = r.apply(e, t || [])).next())
                    }))
                },
                a = function(e, t) {
                    var n, r, o, i, l = {
                        label: 0,
                        sent: function() {
                            if (1 & o[0]) throw o[1];
                            return o[1]
                        },
                        trys: [],
                        ops: []
                    };
                    return i = {
                        next: s(0),
                        throw: s(1),
                        return: s(2)
                    }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                        return this
                    }), i;

                    function s(i) {
                        return function(s) {
                            return function(i) {
                                if (n) throw new TypeError("Generator is already executing.");
                                for (; l;) try {
                                    if (n = 1, r && (o = 2 & i[0] ? r.return : i[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, i[1])).done) return o;
                                    switch (r = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                        case 0:
                                        case 1:
                                            o = i;
                                            break;
                                        case 4:
                                            return l.label++, {
                                                value: i[1],
                                                done: !1
                                            };
                                        case 5:
                                            l.label++, r = i[1], i = [0];
                                            continue;
                                        case 7:
                                            i = l.ops.pop(), l.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = l.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                                l = 0;
                                                continue
                                            }
                                            if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                                l.label = i[1];
                                                break
                                            }
                                            if (6 === i[0] && l.label < o[1]) {
                                                l.label = o[1], o = i;
                                                break
                                            }
                                            if (o && l.label < o[2]) {
                                                l.label = o[2], l.ops.push(i);
                                                break
                                            }
                                            o[2] && l.ops.pop(), l.trys.pop();
                                            continue
                                    }
                                    i = t.call(e, l)
                                } catch (s) {
                                    i = [6, s], r = 0
                                } finally {
                                    n = o = 0
                                }
                                if (5 & i[0]) throw i[1];
                                return {
                                    value: i[0] ? i[1] : void 0,
                                    done: !0
                                }
                            }([i, s])
                        }
                    }
                },
                u = function() {
                    function e(e, t) {
                        this.printerControllerConfig = e, this.i18nFromController = t, this.locationManager = new o(this.i18nFromController), this.computerName = ""
                    }
                    return e.prototype.init = function() {
                        return s(this, void 0, void 0, (function() {
                            return a(this, (function(e) {
                                try {
                                    return [2, !0]
                                } catch (t) {
                                    throw console.log(t), t
                                }
                                return [2]
                            }))
                        }))
                    }, e.prototype.buildConfig = function(e) {
                        return s(this, void 0, void 0, (function() {
                            var t, n, o, s;
                            return a(this, (function(a) {
                                switch (a.label) {
                                    case 0:
                                        t = null;
                                        try {
                                            t = e.serverTicket.details.events[0]._clData.playlist
                                        } catch (u) {}
                                        if (n = r.a.createStaticAssets(t, this.printerControllerConfig.skin, this.printerControllerConfig.logoBasePath, this.contentType), this.contentType !== i.coreModel.PrintProfileSettings.ContentTypeEnum.HTML) return [3, 5];
                                        a.label = 1;
                                    case 1:
                                        return a.trys.push([1, 4, , 5]), n.logoImg && n.logoImg.url ? [4, Object(l.a)(n.logoImg.url, "image/svg")] : [3, 3];
                                    case 2:
                                        o = a.sent(), n.logoImg.raw = o, a.label = 3;
                                    case 3:
                                        return [3, 5];
                                    case 4:
                                        return s = a.sent(), console.error(s), [3, 5];
                                    case 5:
                                        return [2, {
                                            assets: {
                                                logoImg: n.logoImg,
                                                bodyImg: n.bodyImg,
                                                barcode: null,
                                                qr: null
                                            },
                                            computerName: this.computerName,
                                            config: this.printerControllerConfig.formatConfig,
                                            serverTicket: e.serverTicket,
                                            isCopy: e.isCopy,
                                            lcm: this.locationManager,
                                            extendData: {},
                                            showHashCode: this.printerControllerConfig.showHashCode,
                                            oddFormat: n.disableOddFormat ? null : this.printerControllerConfig.oddFormat
                                        }]
                                }
                            }))
                        }))
                    }, e.prototype.buildConfigCashTicket = function(e) {
                        return s(this, void 0, void 0, (function() {
                            var t, n, o;
                            return a(this, (function(s) {
                                switch (s.label) {
                                    case 0:
                                        if (t = r.a.createStaticAssets(null, this.printerControllerConfig.skin, this.printerControllerConfig.logoBasePath, this.contentType), this.contentType !== i.coreModel.PrintProfileSettings.ContentTypeEnum.HTML) return [3, 5];
                                        s.label = 1;
                                    case 1:
                                        return s.trys.push([1, 4, , 5]), t.logoImg && t.logoImg.url ? [4, Object(l.a)(t.logoImg.url, "image/svg")] : [3, 3];
                                    case 2:
                                        n = s.sent(), t.logoImg.raw = n, s.label = 3;
                                    case 3:
                                        return [3, 5];
                                    case 4:
                                        return o = s.sent(), console.error(o), [3, 5];
                                    case 5:
                                        return [2, {
                                            assets: {
                                                logoImg: t.logoImg,
                                                bodyImg: t.bodyImg,
                                                barcode: null,
                                                qr: null
                                            },
                                            computerName: this.computerName,
                                            config: this.printerControllerConfig.formatConfig,
                                            serverTicket: e.serverTicket,
                                            isCopy: !1,
                                            lcm: this.locationManager,
                                            extendData: {},
                                            showHashCode: this.printerControllerConfig.showHashCode,
                                            oddFormat: t.disableOddFormat ? null : this.printerControllerConfig.oddFormat
                                        }]
                                }
                            }))
                        }))
                    }, e.prototype.buildConfigLocalUserTicket = function(e) {
                        return s(this, void 0, void 0, (function() {
                            var t, n, o;
                            return a(this, (function(s) {
                                switch (s.label) {
                                    case 0:
                                        if (t = r.a.createStaticAssets(null, this.printerControllerConfig.skin, this.printerControllerConfig.logoBasePath, this.contentType), this.contentType !== i.coreModel.PrintProfileSettings.ContentTypeEnum.HTML) return [3, 5];
                                        s.label = 1;
                                    case 1:
                                        return s.trys.push([1, 4, , 5]), t.logoImg && t.logoImg.url ? [4, Object(l.a)(t.logoImg.url, "image/svg")] : [3, 3];
                                    case 2:
                                        n = s.sent(), t.logoImg.raw = n, s.label = 3;
                                    case 3:
                                        return [3, 5];
                                    case 4:
                                        return o = s.sent(), console.error(o), [3, 5];
                                    case 5:
                                        return [2, {
                                            assets: {
                                                logoImg: t.logoImg,
                                                bodyImg: t.bodyImg,
                                                barcode: null,
                                                qr: null
                                            },
                                            computerName: this.computerName,
                                            config: this.printerControllerConfig.formatConfig,
                                            serverTicket: e.serverTicket,
                                            isCopy: !1,
                                            lcm: this.locationManager,
                                            extendData: {},
                                            showHashCode: this.printerControllerConfig.showHashCode,
                                            oddFormat: t.disableOddFormat ? null : this.printerControllerConfig.oddFormat
                                        }]
                                }
                            }))
                        }))
                    }, e.prototype.buildConfigReport = function(e) {
                        return s(this, void 0, void 0, (function() {
                            var t;
                            return a(this, (function(n) {
                                return t = r.a.createStaticAssets(null, this.printerControllerConfig.skin, this.printerControllerConfig.logoBasePath, this.contentType), [2, {
                                    assets: {
                                        logoImg: t.logoImg
                                    },
                                    config: this.printerControllerConfig.formatConfig,
                                    lcm: this.locationManager,
                                    report: e
                                }]
                            }))
                        }))
                    }, e.prototype.buildConfigLastResults = function(e) {
                        return s(this, void 0, void 0, (function() {
                            var t, n, o;
                            return a(this, (function(s) {
                                switch (s.label) {
                                    case 0:
                                        if (t = r.a.createStaticAssets(e[0].events[0]._clData.playlist, this.printerControllerConfig.skin, this.printerControllerConfig.logoBasePath, this.contentType), this.contentType !== i.coreModel.PrintProfileSettings.ContentTypeEnum.HTML) return [3, 4];
                                        s.label = 1;
                                    case 1:
                                        return s.trys.push([1, 3, , 4]), [4, Object(l.a)(t.logoImg.url, "image/svg")];
                                    case 2:
                                        return n = s.sent(), t.logoImg.raw = n, [3, 4];
                                    case 3:
                                        return o = s.sent(), console.error(o), [3, 4];
                                    case 4:
                                        return [2, {
                                            eventBlocks: e,
                                            assets: {
                                                logoImg: t.logoImg
                                            },
                                            config: this.printerControllerConfig.formatConfig,
                                            lcm: this.locationManager
                                        }]
                                }
                            }))
                        }))
                    }, e.prototype.setLanguage = function(e) {
                        return this.locationManager.setLanguage(e)
                    }, e
                }()
        },
        yKJU: function(e, t, n) {
            "use strict";
            n.d(t, "a", (function() {
                return o
            }));
            var r = n("Ucdj"),
                o = function() {
                    function e() {}
                    return e.prototype.getfullHTML = function(e, t) {
                        return this._getMarkup(e, t, !1)
                    }, e.prototype.printElement = function(e, t) {
                        var n = this;
                        return new Promise((function(r, o) {
                            var i = e.outerHTML;
                            n._print(i, t).then((function(e) {
                                r(e)
                            }))
                        }))
                    }, e.prototype.printHtml = function(e, t) {
                        var n = this;
                        return new Promise((function(r, o) {
                            n._print(e, t).then((function(e) {
                                r(e)
                            }))
                        }))
                    }, e.prototype._print = function(e, t) {
                        var n = this;
                        return new Promise((function(o, i) {
                            t = {
                                printMode: (t = t || {}).printMode || r.b.DEFAULT,
                                pageTitle: t.pageTitle || "",
                                templateString: t.templateString || "",
                                popupProperties: t.popupProperties || "",
                                stylesheets: t.stylesheets || null,
                                styles: t.styles || null
                            };
                            var l, s, a, u, c = n._getMarkup(e, t),
                                p = !0;
                            t.printMode === r.b.WINDOW_POPUP || t.printMode === r.b.WINDOW ? (l = window.open("about:blank", "_blank", t.popupProperties), a = l.document, p = !1) : (u = "printElement_" + Math.round(99999 * Math.random()).toString(), (s = document.createElement("iframe")).setAttribute("id", u), s.setAttribute("src", "about:blank"), s.setAttribute("frameBorder", "0"), s.setAttribute("scrolling", "no"), s.setAttribute("style", "position:fixed;top:20%;z-index:-1"), document.body.appendChild(s), (a = s.contentWindow || s.contentDocument).document && (a = a.document), s = document.frames ? document.frames[u] : document.getElementById(u), l = s.contentWindow || s), focus(), a.open(), setTimeout((function() {
                                l.addEventListener("load", (function(e) {
                                    p ? (l.printPage(), s && (document.body.removeChild(document.getElementById(u)), o(!0))) : o(!1)
                                })), a.write(c), a.close()
                            }))
                        }))
                    }, e.prototype._getBaseHref = function() {
                        var e = window.location.port ? ":" + window.location.port : "";
                        return window.location.protocol + "//" + window.location.hostname + e + window.location.pathname
                    }, e.prototype._getMarkup = function(e, t, n) {
                        void 0 === n && (n = !0);
                        var o = t.templateString,
                            i = new RegExp(/{{\s*printBody\s*}}/gi),
                            l = [],
                            s = [],
                            a = [];
                        return o && i.test(o) && (e = o.replace(i, e)), a.push('<html><head><meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" /><meta charset="UTF-8"><title>' + (t.pageTitle || "") + "</title>"), t.stylesheets && (l = Array.isArray(t.stylesheets) ? t.stylesheets : [t.stylesheets]), l.forEach((function(e) {
                            a.push('<link rel="stylesheet" href="' + e + '">')
                        })), t.styles && (s = Array.isArray(t.styles) ? t.styles : [t.styles]), s.forEach((function(e) {
                            a.push('<style type="text/css">' + e + "</style>")
                        })), a.push('<base href="' + this._getBaseHref() + '" />'), a.push('</head><body class="pe-body cashier-ticket">'), a.push(e), !n || t.printMode !== r.b.WINDOW_POPUP && t.printMode !== r.b.DEFAULT || a.push('<script type="text/javascript">function printPage(){focus();print();' + (t.printMode === r.b.WINDOW_POPUP ? "close();" : "") + "}<\/script>"), a.push("</body></html>"), a.join("")
                    }, e
                }()
        }
    }
]);