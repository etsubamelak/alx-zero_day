(window.webpackJsonp = window.webpackJsonp || []).push([
    [3], {
        "6nHF": function(t, e, n) {
            "use strict";
            n.d(e, "a", (function() {
                return c
            })), n.d(e, "b", (function() {
                return d
            }));
            var l = n("CcnG"),
                o = n("Ip0R"),
                r = n("5EE+"),
                i = n("0ZGX"),
                s = [
                    [".fastbet-help-header[_ngcontent-%COMP%]{width:100%;margin-bottom:20px;font-family:OpenSans;font-size:14px;color:#000;background-color:#eaeaea}.fastbet-help-header[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]:first-child   td[_ngcontent-%COMP%]{padding:30px 0 10px 18px}.fastbet-help-header[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]:not(:first-child)   td[_ngcontent-%COMP%]{padding:16px 0 10px 18px}.fastbet-help-header[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]:last-child   td[_ngcontent-%COMP%]{padding-bottom:30px}.fastbet-help-header[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:first-child{font-weight:700}.fastbet-help-header--no-system-section[_ngcontent-%COMP%]{width:78%}.fastbet-help-header--indentation[_ngcontent-%COMP%]{padding-left:1.7em;text-indent:-1em}.fastbet-help-header--capitalize[_ngcontent-%COMP%]{text-transform:capitalize}.fastbet-help-header--uppercase[_ngcontent-%COMP%]{text-transform:uppercase}.title[_ngcontent-%COMP%]{margin-top:31px;margin-bottom:18px;font-size:44px;font-weight:700;color:#000;text-transform:capitalize}"]
                ],
                c = l.Gb({
                    encapsulation: 0,
                    styles: s,
                    data: {}
                });

            function u(t) {
                return l.ec(0, [(t()(), l.Ib(0, 0, null, null, 5, "span", [], null, null, null, null, null)), l.Zb(512, null, o.x, o.y, [l.A, l.B, l.o, l.P]), l.Hb(2, 278528, null, 0, o.k, [o.x], {
                    ngClass: [0, "ngClass"]
                }, null), l.Xb(3, {
                    "text-bold": 0
                }), (t()(), l.cc(4, null, ["[", "] -"])), l.Wb(131072, r.j, [r.k, l.i])], (function(t, e) {
                    var n = t(e, 3, 0, !e.component.hasEnterSystemSection);
                    t(e, 2, 0, n)
                }), (function(t, e) {
                    t(e, 4, 0, l.dc(e, 4, 0, l.Ub(e, 5).transform("ch_match_number")))
                }))
            }

            function a(t) {
                return l.ec(0, [(t()(), l.Ib(0, 0, null, null, 5, "td", [], null, null, null, null, null)), l.Zb(512, null, o.x, o.y, [l.A, l.B, l.o, l.P]), l.Hb(2, 278528, null, 0, o.k, [o.x], {
                    ngClass: [0, "ngClass"]
                }, null), l.Xb(3, {
                    "text-bold": 0
                }), (t()(), l.cc(4, null, ["", ":"])), l.Wb(131072, r.j, [r.k, l.i])], (function(t, e) {
                    var n = t(e, 3, 0, e.component.hasEnterSystemSection);
                    t(e, 2, 0, n)
                }), (function(t, e) {
                    t(e, 4, 0, l.dc(e, 4, 0, l.Ub(e, 5).transform("ch_system_bets")))
                }))
            }

            function h(t) {
                return l.ec(0, [(t()(), l.Ib(0, 0, null, null, 2, "span", [], null, null, null, null, null)), (t()(), l.cc(1, null, ["[", "] -"])), l.Wb(131072, r.j, [r.k, l.i])], null, (function(t, e) {
                    t(e, 1, 0, l.dc(e, 1, 0, l.Ub(e, 2).transform("ch_match_number")))
                }))
            }

            function b(t) {
                return l.ec(0, [(t()(), l.Ib(0, 0, null, null, 3, "td", [], null, null, null, null, null)), (t()(), l.Ib(1, 0, null, null, 2, "span", [
                    ["class", "fastbet-help-header--indentation"]
                ], null, null, null, null, null)), (t()(), l.cc(2, null, ["1 - ", ""])), l.Wb(131072, r.j, [r.k, l.i])], null, (function(t, e) {
                    t(e, 2, 0, l.dc(e, 2, 0, l.Ub(e, 3).transform("ch_switch_combi")))
                }))
            }

            function p(t) {
                return l.ec(0, [(t()(), l.Ib(0, 0, null, null, 10, "td", [], null, null, null, null, null)), (t()(), l.Ib(1, 0, null, null, 9, "span", [
                    ["class", "fastbet-help-header--indentation"]
                ], null, null, null, null, null)), (t()(), l.cc(2, null, ["2 - ", ": [", "] - [", "] "])), l.Wb(131072, r.j, [r.k, l.i]), l.Wb(131072, r.j, [r.k, l.i]), l.Wb(131072, r.j, [r.k, l.i]), (t()(), l.Ib(6, 0, null, null, 2, "span", [
                    ["class", "fastbet-help-header--uppercase"]
                ], null, null, null, null, null)), (t()(), l.cc(7, null, ["[", "] "])), l.Wb(131072, r.j, [r.k, l.i]), (t()(), l.cc(9, null, [" (", ") "])), l.Wb(131072, r.j, [r.k, l.i])], null, (function(t, e) {
                    t(e, 2, 0, l.dc(e, 2, 0, l.Ub(e, 3).transform("ch_enter_selections")), l.dc(e, 2, 1, l.Ub(e, 4).transform("ch_match_number")), l.dc(e, 2, 2, l.Ub(e, 5).transform("ch_code"))), t(e, 7, 0, l.dc(e, 7, 0, l.Ub(e, 8).transform("ch_return"))), t(e, 9, 0, l.dc(e, 9, 0, l.Ub(e, 10).transform("ch_repeat_selection")))
                }))
            }

            function f(t) {
                return l.ec(0, [(t()(), l.Ib(0, 0, null, null, 10, "td", [], null, null, null, null, null)), (t()(), l.Ib(1, 0, null, null, 9, "span", [
                    ["class", "fastbet-help-header--indentation"]
                ], null, null, null, null, null)), (t()(), l.cc(2, null, ["3 - ", ": * [", "] + "])), l.Wb(131072, r.j, [r.k, l.i]), l.Wb(131072, r.j, [r.k, l.i]), (t()(), l.Ib(5, 0, null, null, 5, "span", [
                    ["class", "fastbet-help-header--capitalize"]
                ], null, null, null, null, null)), (t()(), l.cc(6, null, ["[", "] "])), l.Wb(131072, r.j, [r.k, l.i]), (t()(), l.Ib(8, 0, null, null, 2, "span", [
                    ["class", "fastbet-help-header--uppercase"]
                ], null, null, null, null, null)), (t()(), l.cc(9, null, ["[", "]"])), l.Wb(131072, r.j, [r.k, l.i])], null, (function(t, e) {
                    t(e, 2, 0, l.dc(e, 2, 0, l.Ub(e, 3).transform("ch_enter_system_bets")), l.dc(e, 2, 1, l.Ub(e, 4).transform("ch_grouping_size"))), t(e, 6, 0, l.dc(e, 6, 0, l.Ub(e, 7).transform("ch_stake_amount"))), t(e, 9, 0, l.dc(e, 9, 0, l.Ub(e, 10).transform("ch_return")))
                }))
            }

            function d(t) {
                return l.ec(2, [(t()(), l.Ib(0, 0, null, null, 3, "h1", [
                    ["class", "title"]
                ], null, null, null, null, null)), (t()(), l.cc(1, null, ["", ": ", ""])), l.Wb(131072, r.j, [r.k, l.i]), l.Wb(131072, r.j, [r.k, l.i]), (t()(), l.Ib(4, 0, null, null, 62, "table", [
                    ["class", "fastbet-help-header"]
                ], null, null, null, null, null)), (t()(), l.Ib(5, 0, null, null, 19, "tr", [], null, null, null, null, null)), (t()(), l.Ib(6, 0, null, null, 2, "td", [], null, null, null, null, null)), (t()(), l.cc(7, null, ["", ":"])), l.Wb(131072, r.j, [r.k, l.i]), (t()(), l.Ib(9, 0, null, null, 13, "td", [], null, null, null, null, null)), (t()(), l.xb(16777216, null, null, 1, null, u)), l.Hb(11, 16384, null, 0, o.m, [l.eb, l.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (t()(), l.cc(12, null, [" [", "] + "])), l.Wb(131072, r.j, [r.k, l.i]), (t()(), l.Ib(14, 0, null, null, 8, "span", [
                    ["class", "fastbet-help-header--capitalize"]
                ], null, null, null, null, null)), l.Zb(512, null, o.x, o.y, [l.A, l.B, l.o, l.P]), l.Hb(16, 278528, null, 0, o.k, [o.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), l.Xb(17, {
                    "fastbet-help-header--no-system-section": 0
                }), (t()(), l.cc(18, null, ["[", "] "])), l.Wb(131072, r.j, [r.k, l.i]), (t()(), l.Ib(20, 0, null, null, 2, "span", [
                    ["class", "fastbet-help-header--uppercase"]
                ], null, null, null, null, null)), (t()(), l.cc(21, null, ["[", "]"])), l.Wb(131072, r.j, [r.k, l.i]), (t()(), l.xb(16777216, null, null, 1, null, a)), l.Hb(24, 16384, null, 0, o.m, [l.eb, l.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (t()(), l.Ib(25, 0, null, null, 16, "tr", [], null, null, null, null, null)), (t()(), l.Ib(26, 0, null, null, 2, "td", [], null, null, null, null, null)), (t()(), l.cc(27, null, ["", ":"])), l.Wb(131072, r.j, [r.k, l.i]), (t()(), l.Ib(29, 0, null, null, 10, "td", [], null, null, null, null, null)), l.Zb(512, null, o.x, o.y, [l.A, l.B, l.o, l.P]), l.Hb(31, 278528, null, 0, o.k, [o.x], {
                    ngClass: [0, "ngClass"]
                }, null), l.Xb(32, {
                    "fastbet-help-header--no-system-section": 0
                }), (t()(), l.xb(16777216, null, null, 1, null, h)), l.Hb(34, 16384, null, 0, o.m, [l.eb, l.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (t()(), l.cc(35, null, [" [", "] "])), l.Wb(131072, r.j, [r.k, l.i]), (t()(), l.Ib(37, 0, null, null, 2, "span", [
                    ["class", "fastbet-help-header--uppercase"]
                ], null, null, null, null, null)), (t()(), l.cc(38, null, ["[", "]"])), l.Wb(131072, r.j, [r.k, l.i]), (t()(), l.xb(16777216, null, null, 1, null, b)), l.Hb(41, 16384, null, 0, o.m, [l.eb, l.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (t()(), l.Ib(42, 0, null, null, 12, "tr", [], null, null, null, null, null)), (t()(), l.Ib(43, 0, null, null, 2, "td", [], null, null, null, null, null)), (t()(), l.cc(44, null, ["", ":"])), l.Wb(131072, r.j, [r.k, l.i]), (t()(), l.Ib(46, 0, null, null, 6, "td", [], null, null, null, null, null)), l.Zb(512, null, o.x, o.y, [l.A, l.B, l.o, l.P]), l.Hb(48, 278528, null, 0, o.k, [o.x], {
                    ngClass: [0, "ngClass"]
                }, null), l.Xb(49, {
                    "fastbet-help-header--no-system-section": 0
                }), (t()(), l.Ib(50, 0, null, null, 2, "span", [
                    ["class", "fastbet-help-header--uppercase"]
                ], null, null, null, null, null)), (t()(), l.cc(51, null, ["[", "]"])), l.Wb(131072, r.j, [r.k, l.i]), (t()(), l.xb(16777216, null, null, 1, null, p)), l.Hb(54, 16384, null, 0, o.m, [l.eb, l.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (t()(), l.Ib(55, 0, null, null, 11, "tr", [], null, null, null, null, null)), (t()(), l.Ib(56, 0, null, null, 2, "td", [], null, null, null, null, null)), (t()(), l.cc(57, null, ["", ":"])), l.Wb(131072, r.j, [r.k, l.i]), (t()(), l.Ib(59, 0, null, null, 5, "td", [], null, null, null, null, null)), l.Zb(512, null, o.x, o.y, [l.A, l.B, l.o, l.P]), l.Hb(61, 278528, null, 0, o.k, [o.x], {
                    ngClass: [0, "ngClass"]
                }, null), l.Xb(62, {
                    "fastbet-help-header--no-system-section": 0
                }), (t()(), l.cc(63, null, ["", ""])), l.Wb(131072, r.j, [r.k, l.i]), (t()(), l.xb(16777216, null, null, 1, null, f)), l.Hb(66, 16384, null, 0, o.m, [l.eb, l.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(t, e) {
                    var n = e.component;
                    t(e, 11, 0, n.hasEnterSystemSection);
                    var l = t(e, 17, 0, !n.hasEnterSystemSection);
                    t(e, 16, 0, "fastbet-help-header--capitalize", l), t(e, 24, 0, n.hasEnterSystemSection);
                    var o = t(e, 32, 0, !n.hasEnterSystemSection);
                    t(e, 31, 0, o), t(e, 34, 0, n.hasEnterSystemSection), t(e, 41, 0, n.hasEnterSystemSection);
                    var r = t(e, 49, 0, !n.hasEnterSystemSection);
                    t(e, 48, 0, r), t(e, 54, 0, n.hasEnterSystemSection);
                    var i = t(e, 62, 0, !n.hasEnterSystemSection);
                    t(e, 61, 0, i), t(e, 66, 0, n.hasEnterSystemSection)
                }), (function(t, e) {
                    var n = e.component;
                    t(e, 1, 0, l.dc(e, 1, 0, l.Ub(e, 2).transform("ch_fast_bet")), l.dc(e, 1, 1, l.Ub(e, 3).transform(n.title))), t(e, 7, 0, l.dc(e, 7, 0, l.Ub(e, 8).transform("ch_add_stake"))), t(e, 12, 0, l.dc(e, 12, 0, l.Ub(e, 13).transform("ch_code"))), t(e, 18, 0, l.dc(e, 18, 0, l.Ub(e, 19).transform("ch_stake_amount"))), t(e, 21, 0, l.dc(e, 21, 0, l.Ub(e, 22).transform("ch_return"))), t(e, 27, 0, l.dc(e, 27, 0, l.Ub(e, 28).transform("ch_add_default_stake"))), t(e, 35, 0, l.dc(e, 35, 0, l.Ub(e, 36).transform("ch_code"))), t(e, 38, 0, l.dc(e, 38, 0, l.Ub(e, 39).transform("ch_return"))), t(e, 44, 0, l.dc(e, 44, 0, l.Ub(e, 45).transform("ch_delete_bet"))), t(e, 51, 0, l.dc(e, 51, 0, l.Ub(e, 52).transform("ch_backspace"))), t(e, 57, 0, l.dc(e, 57, 0, l.Ub(e, 58).transform("ch_print_ticket"))), t(e, 63, 0, l.dc(e, 63, 0, l.Ub(e, 64).transform("ch_hit_return")))
                }))
            }
            l.Eb("gr-fastbet-help-header", i.a, (function(t) {
                return l.ec(0, [(t()(), l.Ib(0, 0, null, null, 1, "gr-fastbet-help-header", [], null, null, null, d, c)), l.Hb(1, 114688, null, 0, i.a, [], null, null)], (function(t, e) {
                    t(e, 1, 0)
                }), null)
            }), {
                title: "title",
                hasEnterSystemSection: "hasEnterSystemSection"
            }, {}, [])
        },
        "96LH": function(t, e, n) {
            "use strict";
            n.d(e, "a", (function() {
                return l
            }));
            n("hg3l"), n("t01L");
            var l = function() {
                function t(t, e) {
                    this.coreService = t, this.themeService = e
                }
                return t.prototype.resolve = function() {
                    return this.themeService.load({
                        name: this.coreService.getSessionController().getSessionSettings().localizationContext.skin.toLowerCase()
                    })
                }, t
            }()
        },
        "D1+H": function(t, e, n) {
            "use strict";
            n.d(e, "a", (function() {
                return _
            }));
            var l = n("CcnG"),
                o = n("ZYCi"),
                r = n("5EE+"),
                i = n("CrY/"),
                s = n("pugT"),
                c = n("F/XL"),
                u = n("XlPw"),
                a = n("0/uQ"),
                h = n("9Z1F"),
                b = n("psW0"),
                p = n("xMyE"),
                f = n("15JJ"),
                d = n("7oEI"),
                v = n("GNnp"),
                C = n("+iOv"),
                m = n("sylN"),
                g = n("t01L"),
                S = n("sB3t"),
                E = n("NTJ2"),
                k = function(t, e, n, l) {
                    return new(n || (n = Promise))((function(o, r) {
                        function i(t) {
                            try {
                                c(l.next(t))
                            } catch (e) {
                                r(e)
                            }
                        }

                        function s(t) {
                            try {
                                c(l.throw(t))
                            } catch (e) {
                                r(e)
                            }
                        }

                        function c(t) {
                            var e;
                            t.done ? o(t.value) : (e = t.value, e instanceof n ? e : new n((function(t) {
                                t(e)
                            }))).then(i, s)
                        }
                        c((l = l.apply(t, e || [])).next())
                    }))
                },
                y = function(t, e) {
                    var n, l, o, r, i = {
                        label: 0,
                        sent: function() {
                            if (1 & o[0]) throw o[1];
                            return o[1]
                        },
                        trys: [],
                        ops: []
                    };
                    return r = {
                        next: s(0),
                        throw: s(1),
                        return: s(2)
                    }, "function" == typeof Symbol && (r[Symbol.iterator] = function() {
                        return this
                    }), r;

                    function s(r) {
                        return function(s) {
                            return function(r) {
                                if (n) throw new TypeError("Generator is already executing.");
                                for (; i;) try {
                                    if (n = 1, l && (o = 2 & r[0] ? l.return : r[0] ? l.throw || ((o = l.return) && o.call(l), 0) : l.next) && !(o = o.call(l, r[1])).done) return o;
                                    switch (l = 0, o && (r = [2 & r[0], o.value]), r[0]) {
                                        case 0:
                                        case 1:
                                            o = r;
                                            break;
                                        case 4:
                                            return i.label++, {
                                                value: r[1],
                                                done: !1
                                            };
                                        case 5:
                                            i.label++, l = r[1], r = [0];
                                            continue;
                                        case 7:
                                            r = i.ops.pop(), i.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = i.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== r[0] && 2 !== r[0])) {
                                                i = 0;
                                                continue
                                            }
                                            if (3 === r[0] && (!o || r[1] > o[0] && r[1] < o[3])) {
                                                i.label = r[1];
                                                break
                                            }
                                            if (6 === r[0] && i.label < o[1]) {
                                                i.label = o[1], o = r;
                                                break
                                            }
                                            if (o && i.label < o[2]) {
                                                i.label = o[2], i.ops.push(r);
                                                break
                                            }
                                            o[2] && i.ops.pop(), i.trys.pop();
                                            continue
                                    }
                                    r = e.call(t, i)
                                } catch (s) {
                                    r = [6, s], l = 0
                                } finally {
                                    n = o = 0
                                }
                                if (5 & r[0]) throw r[1];
                                return {
                                    value: r[0] ? r[1] : void 0,
                                    done: !0
                                }
                            }([r, s])
                        }
                    }
                },
                _ = function() {
                    function t(t) {
                        this.injector = t, this.RETRY_INTERVAL_ON_EVENDATA_NO_SERVICE = 25e3, this.isInitialized = !1, this.subscriptions = new s.a, this.route = this.injector.get(o.a), this.router = this.injector.get(o.l), this.cd = this.injector.get(l.i), this.coreService = this.injector.get(g.a), this.betslipService = this.injector.get(m.a), this.baseService = this.injector.get(E.a), this.modalService = this.injector.get(d.a), this.i18NService = this.injector.get(r.k), this.notificationsService = this.injector.get(v.a)
                    }
                    return t.prototype.ngOnInit = function() {
                        var t = this;
                        this.hasCheckServiceError = !1, this.routeSubscription = this.route.paramMap.subscribe((function(e) {
                            t.currentParams = e, t.isInitialized && t.onDestroy(), t.onInit(e), t.isInitialized = !0
                        })), this.currentConnStateSubscription = this.baseService.currentConnState$.subscribe((function(e) {
                            e === i.ConnectionStateEnum.CONNECTED ? (t.onDestroy(), t.onInit(t.currentParams)) : e === i.ConnectionStateEnum.DISCONNECTED && (clearInterval(t.checkServiceErrorTimer), t.checkServiceErrorTimer = null, clearTimeout(t.modalTimeout), t.modalTimeout = null)
                        }))
                    }, t.prototype.ngOnDestroy = function() {
                        this.routeSubscription.unsubscribe(), this.currentConnStateSubscription.unsubscribe(), this.subscriptions.unsubscribe(), this.initCoreSubscription.unsubscribe(), clearTimeout(this.initTimeout), this.onDestroy()
                    }, t.prototype.onBeforeInit = function() {
                        return Object(c.a)(null)
                    }, t.prototype.onAfterInit = function() {
                        return Object(c.a)(null)
                    }, t.prototype.configureBetslip = function() {}, t.prototype.configureHeader = function() {}, t.prototype.configureShortcuts = function() {}, t.prototype.configureFastbet = function() {}, t.prototype.onClearBetslipUserSelections = function() {}, t.prototype.onEventBlockControllerClosedMarkets = function(t) {}, t.prototype.onEventBlockControllerEventData = function(t) {}, t.prototype.onEventBlockControllerReadyToStart = function(t) {}, t.prototype.onUpdateEventBlock = function() {}, t.prototype.onInit = function(t) {
                        var e = this;
                        this.baseService.closeMarkets(!1), this.subscriptions = new s.a, this.getPlaylist(+t.get("playlistId")), this.gameType = this.playlist.gameType.val.toLowerCase(), this.setHeader(), this.configureEBControllerConfigItem(), this.betslipService.clear(), this.coreService.currentGameType = this.playlist.gameType.val, this.initCoreSubscription = this.initEventBlockController().pipe(Object(h.a)((function(n) {
                            return n && e.handlerInitEventBlockControllerErrors(n), "NOT_BETTABLE_CONTENT" !== (null == n ? void 0 : n.message) || e.hasConnectionError() || e.hasServiceError() || (e.initTimeout = setTimeout((function() {
                                e.initCoreSubscription.unsubscribe(), e.onInit(t)
                            }), 1e4)), Object(u.a)(n)
                        })), Object(b.a)((function(t) {
                            try {
                                e.modalService.close("base-main-section")
                            } catch (n) {}
                            return e.posInit()
                        }))).subscribe()
                    }, t.prototype.getGameMode = function() {
                        return this.playlist.mode
                    }, t.prototype.hasContentAvailable = function() {
                        return this.eventBlockController instanceof i.EBControllerScheduled && "HAS_CONTENT" === this.eventBlockController.contentStatus
                    }, t.prototype.getStats = function() {
                        return k(this, void 0, void 0, (function() {
                            return y(this, (function(t) {
                                return [2, this.eventBlockController.getCurrentLazyStats(i.GetCurrentStatsMode.ON_PREAMBLE)]
                            }))
                        }))
                    }, t.prototype.getCurrentPayTable = function() {
                        return this.eventBlockController.getCurrentPayTable()
                    }, t.prototype.getS2WheelsPaytable = function() {
                        var t, e = [];
                        this.coreService.getSessionController().sessionSettings.calculationContext.oddContext.gameOddSettings.forEach((function(e) {
                            e.isS2wGameOddSettings() && (t = e)
                        }));
                        var n = t.payTable;
                        return Object.entries(n).forEach((function(t) {
                            var n = t[0],
                                l = t[1];
                            e.push({
                                oddId: n,
                                value: l
                            })
                        })), e
                    }, t.prototype.getEBControllerConfigItem = function() {
                        return {}
                    }, t.prototype.posInit = function() {
                        var t = this;
                        return this.displayNoContentScreen(), this.updateCurrentEventBlock(), this.eventBlock = this.eventBlockController.getCurrentEventBlockClosed(), this.eventBlock && this.eventBlock._clData.clientStatus === i.coreModel.EventBlock.ClientStatusEnum.CLOSEDMARKETS || (this.eventBlock = this.eventBlockController.getCurrentEventBlockOpen()), this.onBeforeInit().pipe(Object(p.a)((function() {
                            t.configureBetslip(), t.configureHeader(), t.setMaxMultiplier()
                        })), Object(b.a)((function() {
                            return t.onAfterInit()
                        })), Object(p.a)((function() {
                            t.subscribeEventBlockEvents(), t.configureShortcuts(), t.eventBlock && t.baseService.closeMarkets(t.eventBlock._clData.clientStatus === i.coreModel.EventBlock.ClientStatusEnum.CLOSEDMARKETS), t.cd.markForCheck()
                        })))
                    }, t.prototype.configureEBControllerConfigItem = function() {
                        this.eventBlockController.setConfig(Object.assign({}, this.eventBlockController.getConfig(), this.getEBControllerConfigItem()))
                    }, t.prototype.onDestroy = function() {
                        clearInterval(this.checkServiceErrorTimer), this.checkServiceErrorTimer = null, clearTimeout(this.modalTimeout), this.modalTimeout = null, this.subscriptions.unsubscribe(), this.initCoreSubscription.unsubscribe(), clearTimeout(this.initTimeout), this.baseService.activateGame(!1), this.betslipService.removeCurrentFastbetParser(), this.closeModalWindows(), this.stopEventBlockController(), this.coreService.isInitialized() && this.betslipService.clear()
                    }, t.prototype.closeModalWindows = function() {
                        this.modalService.close("base-main-section"), this.modalService.close("base-front"), this.modalService.close("base-information"), this.modalService.close("base-help")
                    }, t.prototype.setHeader = function() {
                        this.baseService.setHeaderState({
                            gameName: this.playlist.descriptionTag,
                            playList: this.playlist
                        })
                    }, t.prototype.setMaxMultiplier = function() {
                        this.betslipService.setMaxMultiplier(this.getWindowOpenSize())
                    }, t.prototype.getWindowOpenSize = function() {
                        return this.eventBlockController.getEventBlockOpen().length
                    }, t.prototype.initEventBlockController = function() {
                        var t;
                        return this.addEventblockDataErrorSubscription(), this.eventBlockController instanceof i.EBControllerScheduled && (this.eventBlockController.isRunning() || this.eventBlockController.isPaused() ? this.eventBlockController.isPaused() && (t = Object(a.a)(this.eventBlockController.unpause(!1))) : t = Object(a.a)(this.eventBlockController.init(!1))), t || (t = Object(c.a)([])), t
                    }, t.prototype.stopEventBlockController = function() {
                        this.eventBlockController instanceof i.EBControllerScheduled && this.eventBlockController && !this.eventBlockController.isPaused() && this.eventBlockController.pause()
                    }, t.prototype.getPlaylist = function(t) {
                        this.playlist = this.coreService.getPlaylistById(t), this.eventBlockController = this.coreService.getEventControllerByPlaylistId(t, this.getGameMode())
                    }, t.prototype.updateEventBlock = function(t) {
                        this.eventBlock = t, this.configureHeader(), this.setMaxMultiplier(), this.onUpdateEventBlock(), this.cd.detectChanges()
                    }, t.prototype.displayNoContentScreen = function() {
                        var t = this;
                        if (!this.hasContentAvailable()) {
                            this.betslipService.enableFastbet(!1);
                            var e, n = this.coreService.getNextEventblockDataDependOfPreviousResult(this.playlist.gameType);
                            e = n ? this.playlist.filter.isMmaFilter() ? "vw_waiting_for_results" : "vw_waiting_for_all_matches_to_finish" : "ch_empty_ebd_content", this.hasConnectionError() ? e = "Connections problems. Retrying reconnection, wait a moment..." : this.hasServiceError() && (e = "Service problems. Checking service status, wait a moment..."), this.modalTimeout = setTimeout((function() {
                                t.modalService.open("base-main-section", C.a, {
                                    inputs: {
                                        isProcessing: !1,
                                        message: e
                                    }
                                })
                            }), 3e3)
                        }
                    }, t.prototype.displayEventPlayingScreen = function() {
                        if (!this.hasContentAvailable()) {
                            var t = this.playlist.filter.isMmaFilter() ? "vw_waiting_for_results" : "vw_waiting_for_all_matches_to_finish";
                            this.betslipService.enableFastbet(!1), this.modalService.open("base-main-section", C.a, {
                                inputs: {
                                    isProcessing: !1,
                                    message: t
                                }
                            })
                        }
                    }, t.prototype.initEventBlockControllerErrorDialog = function(t) {
                        var e = this;
                        this.modalService.openDialog("base", {
                            type: "danger",
                            icon: "icon icon-warning",
                            iconColor: "#d43548",
                            text: "" + this.i18NService.get("ch_" + t.message.toLowerCase()),
                            buttons: [{
                                type: "danger",
                                text: "" + this.i18NService.get("ch_dismiss"),
                                action: function() {
                                    e.modalService.close("base")
                                }
                            }]
                        })
                    }, t.prototype.updateCurrentEventBlock = function() {
                        if ("HAS_CONTENT" === this.eventBlockController.contentStatus) {
                            this.baseService.closeMarkets(!1);
                            var t = this.eventBlockController.getCurrentEventBlockOpen();
                            t && (this.onEventBlockControllerReadyToStart(t), this.updateEventBlock(t), this.configureFastbet(), this.betslipService.enableFastbet(!0))
                        }
                    }, t.prototype.handlerInitEventBlockControllerErrors = function(t) {
                        t.message && ("NOT_BETTABLE_CONTENT" === t.message || this.hasConnectionError() || this.hasServiceError() ? this.displayNoContentScreen() : this.initEventBlockControllerErrorDialog(t))
                    }, t.prototype.subscribeEventBlockEvents = function() {
                        var t = this;
                        this.subscriptions.add(Object(S.a)(this.eventBlockController.onClosedMarkets).subscribe((function(e) {
                            t.baseService.closeMarkets(!0), t.betslipService.clear(), t.onEventBlockControllerClosedMarkets(e), t.setMaxMultiplier(), t.cd.detectChanges()
                        }))), this.subscriptions.add(Object(S.a)(this.eventBlockController.onContentStatusChange).pipe(Object(f.a)((function(e) {
                            return "HAS_CONTENT" === e.contentStatus ? Object(c.a)(e).pipe(Object(p.a)((function() {
                                t.modalService.close("base-main-section"), t.updateCurrentEventBlock()
                            })), Object(h.a)((function(t) {
                                return Object(c.a)(t)
                            }))) : Object(S.a)(t.eventBlockController.onAllPlayerStart).pipe(Object(p.a)((function() {
                                t.configureHeader(), t.baseService.closeMarkets(!1), t.displayEventPlayingScreen()
                            })))
                        })), Object(h.a)((function(t) {
                            return Object(c.a)(t)
                        }))).subscribe()), this.subscriptions.add(Object(S.a)(this.eventBlockController.onEventData).subscribe((function(e) {
                            t.onEventBlockControllerEventData(e), t.cd.detectChanges()
                        }))), this.subscriptions.add(Object(S.a)(this.eventBlockController.onAllPlayerStart).subscribe((function() {
                            t.updateCurrentEventBlock(), t.cd.detectChanges()
                        }))), this.subscriptions.add(Object(S.a)(this.eventBlockController.onAllPlayerEnd).subscribe((function() {
                            t.updateCurrentEventBlock(), t.cd.detectChanges()
                        }))), this.subscriptions.add(Object(S.a)(this.eventBlockController.onResultTimeout).subscribe((function() {
                            t.baseService.closedMarkets.next(!1), t.displayNoContentScreen(), t.updateCurrentEventBlock(), t.cd.detectChanges()
                        }))), this.subscriptions.add(this.betslipService.onClear.subscribe((function() {
                            t.onClearBetslipUserSelections(), t.cd.detectChanges()
                        })))
                    }, t.prototype.hasServiceError = function() {
                        var t;
                        if (!(null === (t = this.eventBlockController) || void 0 === t ? void 0 : t.eventDataError)) return !1;
                        var e = i.coreUtils.ErrorManager.getSessionError(i.coreUtils.SessionErrorCodEnum.TIMEOUT_PROBLEMS).message;
                        return (this.eventBlockController.eventDataError.message === i.coreUtils.ERROR_PROXY_API_CONNECTION_PROBLEMS.message || this.eventBlockController.eventDataError.message === e) && 0 === this.eventBlockController.getEventBlockOpen().length
                    }, t.prototype.hasConnectionError = function() {
                        return this.coreService.getSessionController().connection.connDiagnosis.currentConnDiagnosisData.connState === i.ConnectionStateEnum.DISCONNECTED
                    }, t.prototype.addEventblockDataErrorSubscription = function() {
                        var t = this;
                        this.subscriptions.add(Object(S.a)(this.eventBlockController.onEventDataError).subscribe((function() {
                            if (t.RETRY_INTERVAL_ON_EVENDATA_NO_SERVICE >= 1e3) {
                                if (t.hasServiceError()) {
                                    if (!t.checkServiceErrorTimer) {
                                        t.hasCheckServiceError = !0;
                                        try {
                                            t.baseService.closeMarkets(!1)
                                        } catch (e) {}
                                        t.onDestroy(), t.onInit(t.currentParams), t.checkServiceErrorTimer = setInterval((function() {
                                            if (t.hasServiceError()) {
                                                try {
                                                    t.baseService.closeMarkets(!1)
                                                } catch (e) {}
                                                t.onDestroy(), t.onInit(t.currentParams)
                                            } else clearInterval(t.checkServiceErrorTimer), t.checkServiceErrorTimer = null, t.hasCheckServiceError = !1
                                        }), t.RETRY_INTERVAL_ON_EVENDATA_NO_SERVICE)
                                    }
                                    t.displayNoContentScreen()
                                } else t.onDestroy(), t.onInit(t.currentParams);
                                t.cd.detectChanges()
                            }
                        })))
                    }, t
                }()
        },
        "Z/Mk": function(t, e, n) {
            "use strict";
            n.d(e, "a", (function() {
                return l
            }));
            var l = function() {
                function t() {}
                return t.prototype.ngOnInit = function() {}, t
            }()
        }
    }
]);