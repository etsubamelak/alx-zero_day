(window.webpackJsonp = window.webpackJsonp || []).push([
    [7], {
        CAXR: function(r, t, e) {
            "use strict";
            e.r(t), e.d(t, "SyntaxError", (function() {
                return c
            })), e.d(t, "parse", (function() {
                return u
            }));
            var a, n = (a = function(r, t) {
                    return (a = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(r, t) {
                            r.__proto__ = t
                        } || function(r, t) {
                            for (var e in t) t.hasOwnProperty(e) && (r[e] = t[e])
                        })(r, t)
                }, function(r, t) {
                    function e() {
                        this.constructor = r
                    }
                    a(r, t), r.prototype = null === t ? Object.create(t) : (e.prototype = t.prototype, new e)
                }),
                o = function() {
                    return (o = Object.assign || function(r) {
                        for (var t, e = 1, a = arguments.length; e < a; e++)
                            for (var n in t = arguments[e]) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
                        return r
                    }).apply(this, arguments)
                },
                c = function(r) {
                    function t(e, a, n, o) {
                        var c = r.call(this) || this;
                        return c.message = e, c.expected = a, c.found = n, c.location = o, c.name = "SyntaxError", "function" == typeof Error.captureStackTrace && Error.captureStackTrace(c, t), c
                    }
                    return n(t, r), t.buildMessage = function(r, t) {
                        function e(r) {
                            return r.charCodeAt(0).toString(16).toUpperCase()
                        }

                        function a(r) {
                            return r.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\0/g, "\\0").replace(/\t/g, "\\t").replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/[\x00-\x0F]/g, (function(r) {
                                return "\\x0" + e(r)
                            })).replace(/[\x10-\x1F\x7F-\x9F]/g, (function(r) {
                                return "\\x" + e(r)
                            }))
                        }

                        function n(r) {
                            return r.replace(/\\/g, "\\\\").replace(/\]/g, "\\]").replace(/\^/g, "\\^").replace(/-/g, "\\-").replace(/\0/g, "\\0").replace(/\t/g, "\\t").replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/[\x00-\x0F]/g, (function(r) {
                                return "\\x0" + e(r)
                            })).replace(/[\x10-\x1F\x7F-\x9F]/g, (function(r) {
                                return "\\x" + e(r)
                            }))
                        }

                        function o(r) {
                            switch (r.type) {
                                case "literal":
                                    return '"' + a(r.text) + '"';
                                case "class":
                                    var t = r.parts.map((function(r) {
                                        return Array.isArray(r) ? n(r[0]) + "-" + n(r[1]) : n(r)
                                    }));
                                    return "[" + (r.inverted ? "^" : "") + t + "]";
                                case "any":
                                    return "any character";
                                case "end":
                                    return "end of input";
                                case "other":
                                    return r.description
                            }
                        }
                        return "Expected " + function(r) {
                            var t, e, a = r.map(o);
                            if (a.sort(), a.length > 0) {
                                for (t = 1, e = 1; t < a.length; t++) a[t - 1] !== a[t] && (a[e] = a[t], e++);
                                a.length = e
                            }
                            switch (a.length) {
                                case 1:
                                    return a[0];
                                case 2:
                                    return a[0] + " or " + a[1];
                                default:
                                    return a.slice(0, -1).join(", ") + ", or " + a[a.length - 1]
                            }
                        }(r) + " but " + (((c = t) ? '"' + a(c) + '"' : "end of input") + " found.");
                        var c
                    }, t
                }(Error);
            var u = function(r, t) {
                t = void 0 !== t ? t : {};
                var e, a, n = {},
                    u = {
                        Main: rr
                    },
                    i = rr,
                    s = H("|", !1),
                    d = H("v", !0),
                    l = H("%", !1),
                    f = function() {
                        return t.randomParticipants(1)
                    },
                    h = H("2", !1),
                    A = H("p", !0),
                    p = H("3", !1),
                    C = H("a", !0),
                    v = H("o", !0),
                    g = H("-", !1),
                    m = function() {
                        return t.randomParticipants(2)
                    },
                    _ = H("s", !0),
                    b = H("t", !0),
                    w = function() {
                        return t.randomParticipants(3)
                    },
                    k = H("d", !0),
                    P = H("i", !0),
                    y = H("u", !0),
                    L = H("y", !0),
                    x = H("4", !1),
                    M = H("x", !0),
                    O = H("/", !1),
                    j = H("n", !0),
                    E = H("1", !1),
                    F = H("f", !0),
                    S = H("+", !1),
                    R = H("0", !1),
                    I = /^[1-9]/,
                    D = K([
                        ["1", "9"]
                    ], !1, !1),
                    T = /^[0-9]/,
                    q = K([
                        ["0", "9"]
                    ], !1, !1),
                    J = function() {
                        return Number(r.substring(U, V))
                    },
                    N = H(".", !1),
                    V = 0,
                    U = 0,
                    X = [{
                        line: 1,
                        column: 1
                    }],
                    z = 0,
                    B = [],
                    G = 0;
                if (void 0 !== t.startRule) {
                    if (!(t.startRule in u)) throw new Error("Can't start parsing from rule \"" + t.startRule + '".');
                    i = u[t.startRule]
                }

                function H(r, t) {
                    return {
                        type: "literal",
                        text: r,
                        ignoreCase: t
                    }
                }

                function K(r, t, e) {
                    return {
                        type: "class",
                        parts: r,
                        inverted: t,
                        ignoreCase: e
                    }
                }

                function Q(r) {
                    return {
                        type: "other",
                        description: r
                    }
                }

                function W(t) {
                    var e, a = X[t];
                    if (a) return a;
                    for (e = t - 1; !X[e];) e--;
                    for (a = {
                            line: (a = X[e]).line,
                            column: a.column
                        }; e < t;) 10 === r.charCodeAt(e) ? (a.line++, a.column = 1) : a.column++, e++;
                    return X[t] = a, a
                }

                function Y(r, t) {
                    var e = W(r),
                        a = W(t);
                    return {
                        start: {
                            offset: r,
                            line: e.line,
                            column: e.column
                        },
                        end: {
                            offset: t,
                            line: a.line,
                            column: a.column
                        }
                    }
                }

                function Z(r) {
                    V < z || (V > z && (z = V, B = []), B.push(r))
                }

                function $(r, t, e) {
                    return new c(c.buildMessage(r, t), r, t, e)
                }

                function rr() {
                    var t, e;
                    return t = V, (e = function t() {
                        var e, a, o, c;
                        e = V, (a = tr()) !== n ? (124 === r.charCodeAt(V) ? (o = "|", V++) : (o = n, 0 === G && Z(s)), o !== n && (c = t()) !== n ? (U = e, u = c, a = a.concat(u), e = a) : (V = e, e = n)) : (V = e, e = n);
                        var u;
                        e === n && (e = V, (a = tr()) !== n && (U = e, a = function(r) {
                            return r.slice()
                        }(a)), e = a);
                        return e
                    }()) !== n && (U = t, e = e), t = e
                }

                function tr() {
                    var e, c, u, i, s;
                    return e = V, (c = function() {
                        var e, o, c;
                        (e = function() {
                            var e, a, o, c;
                            e = V, "v" === r.substr(V, 1).toLowerCase() ? (a = r.charAt(V), V++) : (a = n, 0 === G && Z(d));
                            a !== n ? ((o = or()) === n && (o = V, 37 === r.charCodeAt(V) ? (c = "%", V++) : (c = n, 0 === G && Z(l)), c !== n && (U = o, c = f()), o = c), o !== n ? (U = e, u = o, t.isParticipant(u) || cr("Invalid participant"), a = {
                                market: t.getMarkets().win,
                                odd: t.getOdds()["win_" + u]
                            }, e = a) : (V = e, e = n)) : (V = e, e = n);
                            var u;
                            return e
                        }()) === n && (e = function() {
                            var e, a, o, c, u;
                            e = V, 50 === r.charCodeAt(V) ? (a = "2", V++) : (a = n, 0 === G && Z(h));
                            a !== n ? ("p" === r.substr(V, 1).toLowerCase() ? (o = r.charAt(V), V++) : (o = n, 0 === G && Z(A)), o !== n ? ((c = or()) === n && (c = V, 37 === r.charCodeAt(V) ? (u = "%", V++) : (u = n, 0 === G && Z(l)), u !== n && (U = c, u = f()), c = u), c !== n ? (U = e, i = c, t.isParticipant(i) || cr("Invalid participant"), a = {
                                market: t.getMarkets().place,
                                odd: t.getOdds()["place_" + i]
                            }, e = a) : (V = e, e = n)) : (V = e, e = n)) : (V = e, e = n);
                            var i;
                            return e
                        }()) === n && (e = function() {
                            var e, a, o, c, u, i, s;
                            e = V, "a" === r.substr(V, 1).toLowerCase() ? (a = r.charAt(V), V++) : (a = n, 0 === G && Z(C));
                            a !== n ? ("o" === r.substr(V, 1).toLowerCase() ? (o = r.charAt(V), V++) : (o = n, 0 === G && Z(v)), o !== n ? (c = V, (u = or()) !== n ? (45 === r.charCodeAt(V) ? (i = "-", V++) : (i = n, 0 === G && Z(g)), i !== n && (s = or()) !== n ? c = u = [u, i, s] : (V = c, c = n)) : (V = c, c = n), c === n && (c = V, 37 === r.charCodeAt(V) ? (u = "%", V++) : (u = n, 0 === G && Z(l)), u !== n && (U = c, u = m()), c = u), c !== n ? (U = e, d = (d = c).filter((function(r) {
                                return "-" !== r
                            })).join("_"), t.allAreParticipants(d, 2) || cr(), a = {
                                market: t.getMarkets().exacta,
                                odd: t.getOdds()["exacta_" + d]
                            }, e = a) : (V = e, e = n)) : (V = e, e = n)) : (V = e, e = n);
                            var d;
                            return e
                        }()) === n && (e = function() {
                            var e, a, o, c, u, i, s;
                            e = V, "a" === r.substr(V, 1).toLowerCase() ? (a = r.charAt(V), V++) : (a = n, 0 === G && Z(C));
                            a !== n ? ("s" === r.substr(V, 1).toLowerCase() ? (o = r.charAt(V), V++) : (o = n, 0 === G && Z(_)), o !== n ? (c = V, (u = or()) !== n ? (45 === r.charCodeAt(V) ? (i = "-", V++) : (i = n, 0 === G && Z(g)), i !== n && (s = or()) !== n ? c = u = [u, i, s] : (V = c, c = n)) : (V = c, c = n), c === n && (c = V, 37 === r.charCodeAt(V) ? (u = "%", V++) : (u = n, 0 === G && Z(l)), u !== n && (U = c, u = m()), c = u), c !== n ? (U = e, d = (d = c).filter((function(r) {
                                return "-" !== r
                            })).sort((function(r, t) {
                                return r - t
                            })).join("_"), t.allAreParticipants(d, 2) || cr(), a = {
                                market: t.getMarkets().quinella,
                                odd: t.getOdds()["quinella_" + d]
                            }, e = a) : (V = e, e = n)) : (V = e, e = n)) : (V = e, e = n);
                            var d;
                            return e
                        }()) === n && (e = V, (o = er()) !== n ? ((c = function() {
                            var e, a, o, c, u, i, s, d;
                            e = V, "t" === r.substr(V, 1).toLowerCase() ? (a = r.charAt(V), V++) : (a = n, 0 === G && Z(b));
                            a !== n ? (o = V, (c = or()) !== n ? (45 === r.charCodeAt(V) ? (u = "-", V++) : (u = n, 0 === G && Z(g)), u !== n && (i = or()) !== n ? (45 === r.charCodeAt(V) ? (s = "-", V++) : (s = n, 0 === G && Z(g)), s !== n && (d = or()) !== n ? o = c = [c, u, i, s, d] : (V = o, o = n)) : (V = o, o = n)) : (V = o, o = n), o === n && (o = V, 37 === r.charCodeAt(V) ? (c = "%", V++) : (c = n, 0 === G && Z(l)), c !== n && (U = o, c = w()), o = c), o !== n ? (U = e, f = (f = o).filter((function(r) {
                                return "-" !== r
                            })).join("_"), t.allAreParticipants(f, 3) || cr(), a = {
                                market: t.getMarkets().trifecta,
                                odd: "trifecta_" + f,
                                betParam: f.replace(/_/g, ",")
                            }, e = a) : (V = e, e = n)) : (V = e, e = n);
                            var f;
                            return e
                        }()) === n && (c = function() {
                            var e, a, o, c, u;
                            e = V, 51 === r.charCodeAt(V) ? (a = "3", V++) : (a = n, 0 === G && Z(p));
                            a !== n ? ("p" === r.substr(V, 1).toLowerCase() ? (o = r.charAt(V), V++) : (o = n, 0 === G && Z(A)), o !== n ? ((c = or()) === n && (c = V, 37 === r.charCodeAt(V) ? (u = "%", V++) : (u = n, 0 === G && Z(l)), u !== n && (U = c, u = f()), c = u), c !== n ? (U = e, i = c, t.isParticipant(i) || cr("Invalid participant"), a = {
                                market: t.getMarkets().show,
                                odd: t.getOdds()["show_" + i]
                            }, e = a) : (V = e, e = n)) : (V = e, e = n)) : (V = e, e = n);
                            var i;
                            return e
                        }()), c !== n ? (U = e, e = o = c) : (V = e, e = n)) : (V = e, e = n), e === n && (e = V, o = V, G++, c = ar(), G--, c === n ? o = void 0 : (V = o, o = n), o !== n ? ((c = function() {
                            var e, a, o;
                            e = V, "d" === r.substr(V, 1).toLowerCase() ? (a = r.charAt(V), V++) : (a = n, 0 === G && Z(k));
                            a !== n ? ("i" === r.substr(V, 1).toLowerCase() ? (o = r.charAt(V), V++) : (o = n, 0 === G && Z(P)), o !== n ? (U = e, a = {
                                market: t.getMarkets().even_odd,
                                odd: t.getOdds().odd
                            }, e = a) : (V = e, e = n)) : (V = e, e = n);
                            return e
                        }()) === n && (c = function() {
                            var e, a, o;
                            e = V, "p" === r.substr(V, 1).toLowerCase() ? (a = r.charAt(V), V++) : (a = n, 0 === G && Z(A));
                            a !== n ? ("a" === r.substr(V, 1).toLowerCase() ? (o = r.charAt(V), V++) : (o = n, 0 === G && Z(C)), o !== n ? (U = e, a = {
                                market: t.getMarkets().even_odd,
                                odd: t.getOdds().even
                            }, e = a) : (V = e, e = n)) : (V = e, e = n);
                            return e
                        }()) === n && (c = function() {
                            var e, a, o, c;
                            e = V, "d" === r.substr(V, 1).toLowerCase() ? (a = r.charAt(V), V++) : (a = n, 0 === G && Z(k));
                            a !== n ? ("p" === r.substr(V, 1).toLowerCase() ? (o = r.charAt(V), V++) : (o = n, 0 === G && Z(A)), o !== n ? (37 === r.charCodeAt(V) ? (c = "%", V++) : (c = n, 0 === G && Z(l)), c !== n ? (U = e, u = t.getMarkets().even_odd, i = [t.getOdds().even, t.getOdds().odd], a = {
                                market: u,
                                odd: t.getRandomFromArray(i)
                            }, e = a) : (V = e, e = n)) : (V = e, e = n)) : (V = e, e = n);
                            var u, i;
                            return e
                        }()) === n && (c = function() {
                            var e, a, o, c;
                            e = V, "o" === r.substr(V, 1).toLowerCase() ? (a = r.charAt(V), V++) : (a = n, 0 === G && Z(v));
                            a !== n ? ("u" === r.substr(V, 1).toLowerCase() ? (o = r.charAt(V), V++) : (o = n, 0 === G && Z(y)), o !== n ? (37 === r.charCodeAt(V) ? (c = "%", V++) : (c = n, 0 === G && Z(l)), c !== n ? (U = e, u = t.getMarkets().over_under, i = [t.getOdds().over, t.getOdds().under], a = {
                                market: u,
                                odd: t.getRandomFromArray(i)
                            }, e = a) : (V = e, e = n)) : (V = e, e = n)) : (V = e, e = n);
                            var u, i;
                            return e
                        }()) === n && (c = function() {
                            var e, a;
                            e = V, "o" === r.substr(V, 1).toLowerCase() ? (a = r.charAt(V), V++) : (a = n, 0 === G && Z(v));
                            a !== n && (U = e, a = {
                                market: t.getMarkets().over_under,
                                odd: t.getOdds().over
                            });
                            return e = a
                        }()) === n && (c = function() {
                            var e, a;
                            e = V, "u" === r.substr(V, 1).toLowerCase() ? (a = r.charAt(V), V++) : (a = n, 0 === G && Z(y));
                            a !== n && (U = e, a = {
                                market: t.getMarkets().over_under,
                                odd: t.getOdds().under
                            });
                            return e = a
                        }()), c !== n ? (U = e, e = o = c) : (V = e, e = n)) : (V = e, e = n), e === n && (e = function() {
                            var e, o, c, u, i, s;
                            e = V, U = V, o = (o = function() {
                                return t.isSumOfPlacesEnabled()
                            }()) ? void 0 : n;
                            if (o !== n)
                                if ("s" === r.substr(V, 1).toLowerCase() ? (c = r.charAt(V), V++) : (c = n, 0 === G && Z(_)), c !== n)
                                    if ("u" === r.substr(V, 1).toLowerCase() ? (u = r.charAt(V), V++) : (u = n, 0 === G && Z(y)), u !== n) {
                                        if (i = [], (s = or()) !== n)
                                            for (; s !== n;) i.push(s), s = or();
                                        else i = n;
                                        i !== n ? (U = e, o = function(r) {
                                            r = Number(r.join(""));
                                            var e = t.sumOfPlacesValidator(r),
                                                n = e[0];
                                            e[1] ? n || (a = function() {
                                                var e = t.sumOfPlacesValidator(r),
                                                    a = e[0],
                                                    n = e[1];
                                                return a && n
                                            }) : cr();
                                            var o = t.getMarkets().sum_places,
                                                c = t.getOdds()["sum_places_" + r];
                                            return {
                                                market: o,
                                                odd: n ? c : void 0
                                            }
                                        }(i), e = o) : (V = e, e = n)
                                    } else V = e, e = n;
                            else V = e, e = n;
                            else V = e, e = n;
                            return e
                        }())));
                        return e
                    }()) === n && (c = function() {
                        var e, a, o;
                        e = V, a = V, G++, o = ar(), G--, o !== n ? (V = a, a = void 0) : a = n;
                        a !== n ? ((o = function() {
                            var e, a, o, c;
                            e = V, "s" === r.substr(V, 1).toLowerCase() ? (a = r.charAt(V), V++) : (a = n, 0 === G && Z(_));
                            a !== n ? ((o = or()) === n && (o = V, 37 === r.charCodeAt(V) ? (c = "%", V++) : (c = n, 0 === G && Z(l)), c !== n && (U = o, c = f()), o = c), o !== n ? (U = e, u = o, t.isParticipant(u) || cr("Invalid participant"), a = {
                                market: t.getMarkets().second_place,
                                odd: t.getOdds()["second_" + u]
                            }, e = a) : (V = e, e = n)) : (V = e, e = n);
                            var u;
                            return e
                        }()) === n && (o = function() {
                            var e, a, o, c, u, i, s, d, f;
                            e = V, "t" === r.substr(V, 1).toLowerCase() ? (a = r.charAt(V), V++) : (a = n, 0 === G && Z(b));
                            a !== n ? ("a" === r.substr(V, 1).toLowerCase() ? (o = r.charAt(V), V++) : (o = n, 0 === G && Z(C)), o !== n ? (c = V, (u = or()) !== n ? (45 === r.charCodeAt(V) ? (i = "-", V++) : (i = n, 0 === G && Z(g)), i !== n && (s = or()) !== n ? (45 === r.charCodeAt(V) ? (d = "-", V++) : (d = n, 0 === G && Z(g)), d !== n && (f = or()) !== n ? c = u = [u, i, s, d, f] : (V = c, c = n)) : (V = c, c = n)) : (V = c, c = n), c === n && (c = V, 37 === r.charCodeAt(V) ? (u = "%", V++) : (u = n, 0 === G && Z(l)), u !== n && (U = c, u = w()), c = u), c !== n ? (U = e, h = (h = c).filter((function(r) {
                                return "-" !== r
                            })).sort((function(r, t) {
                                return r - t
                            })).join("_"), t.allAreParticipants(h, 3) || cr(), a = {
                                market: t.getMarkets().three_any_order,
                                odd: "three_any_" + h,
                                betParam: h.replace(/_/g, ",")
                            }, e = a) : (V = e, e = n)) : (V = e, e = n)) : (V = e, e = n);
                            var h;
                            return e
                        }()) === n && (o = function() {
                            var e, a, o, c, u, i, s, d, f, h, A;
                            e = V, "f" === r.substr(V, 1).toLowerCase() ? (a = r.charAt(V), V++) : (a = n, 0 === G && Z(F));
                            a !== n ? ("a" === r.substr(V, 1).toLowerCase() ? (o = r.charAt(V), V++) : (o = n, 0 === G && Z(C)), o !== n ? (c = V, (u = or()) !== n ? (45 === r.charCodeAt(V) ? (i = "-", V++) : (i = n, 0 === G && Z(g)), i !== n && (s = or()) !== n ? (45 === r.charCodeAt(V) ? (d = "-", V++) : (d = n, 0 === G && Z(g)), d !== n && (f = or()) !== n ? (45 === r.charCodeAt(V) ? (h = "-", V++) : (h = n, 0 === G && Z(g)), h !== n && (A = or()) !== n ? c = u = [u, i, s, d, f, h, A] : (V = c, c = n)) : (V = c, c = n)) : (V = c, c = n)) : (V = c, c = n), c === n && (c = V, 37 === r.charCodeAt(V) ? (u = "%", V++) : (u = n, 0 === G && Z(l)), u !== n && (U = c, u = t.randomParticipants(4)), c = u), c !== n ? (U = e, p = (p = c).filter((function(r) {
                                return "-" !== r
                            })).sort((function(r, t) {
                                return r - t
                            })).join("_"), t.allAreParticipants(p, 4) || cr(), a = {
                                market: t.getMarkets().four_any_order,
                                odd: "four_any_" + p,
                                betParam: p.replace(/_/g, ",")
                            }, e = a) : (V = e, e = n)) : (V = e, e = n)) : (V = e, e = n);
                            var p;
                            return e
                        }()) === n && (o = function() {
                            var e, a, o, c;
                            e = V, "f" === r.substr(V, 1).toLowerCase() ? (a = r.charAt(V), V++) : (a = n, 0 === G && Z(F));
                            a !== n ? ((o = or()) === n && (o = V, 37 === r.charCodeAt(V) ? (c = "%", V++) : (c = n, 0 === G && Z(l)), c !== n && (U = o, c = f()), o = c), o !== n ? (U = e, u = o, t.isParticipant(u) || cr("Invalid participant"), a = {
                                market: t.getMarkets().fourth_place_worse,
                                odd: t.getOdds()["fourth_" + u]
                            }, e = a) : (V = e, e = n)) : (V = e, e = n);
                            var u;
                            return e
                        }()), o !== n ? (U = e, e = a = o) : (V = e, e = n)) : (V = e, e = n);
                        return e
                    }()) === n && (c = function() {
                        var e, a;
                        (e = function() {
                            var e, a, o, c, u, i, s;
                            e = V, "y" === r.substr(V, 1).toLowerCase() ? (a = r.charAt(V), V++) : (a = n, 0 === G && Z(L));
                            a !== n ? (50 === r.charCodeAt(V) ? (o = "2", V++) : (o = n, 0 === G && Z(h)), o !== n ? (c = V, (u = or()) !== n ? (45 === r.charCodeAt(V) ? (i = "-", V++) : (i = n, 0 === G && Z(g)), i !== n && (s = or()) !== n ? c = u = [u, i, s] : (V = c, c = n)) : (V = c, c = n), c !== n ? (U = e, d = (d = c).filter((function(r) {
                                return "-" !== r
                            })).join("_"), t.allAreParticipants(d, 2) || cr(), a = {
                                market: t.getMarkets().system_two,
                                odd: t.getOdds().system_two,
                                betParam: d.replace(/_/g, ",")
                            }, e = a) : (V = e, e = n)) : (V = e, e = n)) : (V = e, e = n);
                            var d;
                            return e
                        }()) === n && (e = V, function() {
                            var r;
                            U = V, r = (r = function() {
                                return t.isSystemThreeMarketEnabled()
                            }()) ? void 0 : n;
                            return r
                        }() !== n && (a = function() {
                            var e, a, o, c, u, i, s, d, l;
                            e = V, "y" === r.substr(V, 1).toLowerCase() ? (a = r.charAt(V), V++) : (a = n, 0 === G && Z(L));
                            a !== n ? (51 === r.charCodeAt(V) ? (o = "3", V++) : (o = n, 0 === G && Z(p)), o !== n ? (c = V, (u = or()) !== n ? (45 === r.charCodeAt(V) ? (i = "-", V++) : (i = n, 0 === G && Z(g)), i !== n && (s = or()) !== n ? (45 === r.charCodeAt(V) ? (d = "-", V++) : (d = n, 0 === G && Z(g)), d !== n && (l = or()) !== n ? c = u = [u, i, s, d, l] : (V = c, c = n)) : (V = c, c = n)) : (V = c, c = n), c !== n ? (U = e, f = (f = c).filter((function(r) {
                                return "-" !== r
                            })).join("_"), t.allAreParticipants(f, 3) || cr(), a = {
                                market: t.getMarkets().system_three,
                                odd: t.getOdds().system_three,
                                betParam: f.replace(/_/g, ",")
                            }, e = a) : (V = e, e = n)) : (V = e, e = n)) : (V = e, e = n);
                            var f;
                            return e
                        }()) !== n ? (U = e, e = a) : (V = e, e = n), e === n && (e = V, function() {
                            var r;
                            U = V, r = (r = function() {
                                return t.isSystemFourMarketEnabled()
                            }()) ? void 0 : n;
                            return r
                        }() !== n && (a = function() {
                            var e, a, o, c, u, i, s, d, l, f, h;
                            e = V, "y" === r.substr(V, 1).toLowerCase() ? (a = r.charAt(V), V++) : (a = n, 0 === G && Z(L));
                            a !== n ? (52 === r.charCodeAt(V) ? (o = "4", V++) : (o = n, 0 === G && Z(x)), o !== n ? (c = V, (u = or()) !== n ? (45 === r.charCodeAt(V) ? (i = "-", V++) : (i = n, 0 === G && Z(g)), i !== n && (s = or()) !== n ? (45 === r.charCodeAt(V) ? (d = "-", V++) : (d = n, 0 === G && Z(g)), d !== n && (l = or()) !== n ? (45 === r.charCodeAt(V) ? (f = "-", V++) : (f = n, 0 === G && Z(g)), f !== n && (h = or()) !== n ? c = u = [u, i, s, d, l, f, h] : (V = c, c = n)) : (V = c, c = n)) : (V = c, c = n)) : (V = c, c = n), c !== n ? (U = e, A = (A = c).filter((function(r) {
                                return "-" !== r
                            })).join("_"), t.allAreParticipants(A, 4) || cr(), a = {
                                market: t.getMarkets().system_four_any_order,
                                odd: t.getOdds().system_four_any,
                                betParam: A.replace(/_/g, ",")
                            }, e = a) : (V = e, e = n)) : (V = e, e = n)) : (V = e, e = n);
                            var A;
                            return e
                        }()) !== n ? (U = e, e = a) : (V = e, e = n)));
                        return e
                    }()), c !== n ? ((u = nr()) === n && (u = null), u !== n ? (U = e, i = c, s = u, a && !a() && cr("", 1), a = void 0, e = c = [o({}, i, s || {})]) : (V = e, e = n)) : (V = e, e = n), e === n && (e = V, (c = function() {
                        var e, a;
                        e = V, er() !== n ? ((a = function() {
                            var e, a, o, c, u, i, s, l, f, h, A, p, C, v;
                            e = V, "v" === r.substr(V, 1).toLowerCase() ? (a = r.charAt(V), V++) : (a = n, 0 === G && Z(d));
                            a !== n ? ("x" === r.substr(V, 1).toLowerCase() ? (o = r.charAt(V), V++) : (o = n, 0 === G && Z(M)), o !== n && (c = or()) !== n ? (47 === r.charCodeAt(V) ? (u = "/", V++) : (u = n, 0 === G && Z(O)), u !== n ? (i = V, (s = or()) !== n ? (45 === r.charCodeAt(V) ? (l = "-", V++) : (l = n, 0 === G && Z(g)), l !== n && (f = or()) !== n ? (h = V, 45 === r.charCodeAt(V) ? (A = "-", V++) : (A = n, 0 === G && Z(g)), A !== n && (p = or()) !== n ? h = A = [A, p] : (V = h, h = n), h === n && (h = null), h !== n ? (A = V, 45 === r.charCodeAt(V) ? (p = "-", V++) : (p = n, 0 === G && Z(g)), p !== n && (C = or()) !== n ? A = p = [p, C] : (V = A, A = n), A === n && (A = null), A !== n ? (p = V, 45 === r.charCodeAt(V) ? (C = "-", V++) : (C = n, 0 === G && Z(g)), C !== n && (v = or()) !== n ? p = C = [C, v] : (V = p, p = n), p === n && (p = null), p !== n ? i = s = [s, l, f, h, A, p] : (V = i, i = n)) : (V = i, i = n)) : (V = i, i = n)) : (V = i, i = n)) : (V = i, i = n), i !== n ? (U = e, a = function(r, e) {
                                e = ur(e, 1 / 0).filter((function(r) {
                                    return "-" !== r && r
                                })).join("_"), t.isParticipant(r) && t.allAreParticipants(e, 2, 5) && !t.hasDuplicatedParticipant(r + "_" + e) || cr();
                                var a = t.getMarkets().trifecta;
                                return t.combinatorial.getPermutations(e, 2).map((function(t) {
                                    var e = "trifecta_" + r + "_" + t,
                                        n = r + "," + t.replace(/_/g, ",");
                                    return {
                                        market: a,
                                        odd: e,
                                        betParam: n
                                    }
                                }))
                            }(c, i), e = a) : (V = e, e = n)) : (V = e, e = n)) : (V = e, e = n)) : (V = e, e = n);
                            return e
                        }()) === n && (a = function() {
                            var e, a, o, c, u, i, s, d, l, f, h, A;
                            e = V, "a" === r.substr(V, 1).toLowerCase() ? (a = r.charAt(V), V++) : (a = n, 0 === G && Z(C));
                            a !== n ? ("x" === r.substr(V, 1).toLowerCase() ? (o = r.charAt(V), V++) : (o = n, 0 === G && Z(M)), o !== n ? (c = V, (u = or()) !== n ? (45 === r.charCodeAt(V) ? (i = "-", V++) : (i = n, 0 === G && Z(g)), i !== n && (s = or()) !== n ? (d = V, 45 === r.charCodeAt(V) ? (l = "-", V++) : (l = n, 0 === G && Z(g)), l !== n && (f = or()) !== n ? d = l = [l, f] : (V = d, d = n), d === n && (d = null), d !== n ? (l = V, 45 === r.charCodeAt(V) ? (f = "-", V++) : (f = n, 0 === G && Z(g)), f !== n && (h = or()) !== n ? l = f = [f, h] : (V = l, l = n), l === n && (l = null), l !== n ? (f = V, 45 === r.charCodeAt(V) ? (h = "-", V++) : (h = n, 0 === G && Z(g)), h !== n && (A = or()) !== n ? f = h = [h, A] : (V = f, f = n), f === n && (f = null), f !== n ? c = u = [u, i, s, d, l, f] : (V = c, c = n)) : (V = c, c = n)) : (V = c, c = n)) : (V = c, c = n)) : (V = c, c = n), c !== n ? (47 === r.charCodeAt(V) ? (u = "/", V++) : (u = n, 0 === G && Z(O)), u !== n ? (i = V, (s = or()) !== n ? (d = V, 45 === r.charCodeAt(V) ? (l = "-", V++) : (l = n, 0 === G && Z(g)), l !== n && (f = or()) !== n ? d = l = [l, f] : (V = d, d = n), d === n && (d = null), d !== n ? (l = V, 45 === r.charCodeAt(V) ? (f = "-", V++) : (f = n, 0 === G && Z(g)), f !== n && (h = or()) !== n ? l = f = [f, h] : (V = l, l = n), l === n && (l = null), l !== n ? (f = V, 45 === r.charCodeAt(V) ? (h = "-", V++) : (h = n, 0 === G && Z(g)), h !== n && (A = or()) !== n ? f = h = [h, A] : (V = f, f = n), f === n && (f = null), f !== n ? i = s = [s, d, l, f] : (V = i, i = n)) : (V = i, i = n)) : (V = i, i = n)) : (V = i, i = n), i !== n ? (U = e, a = function(r, e) {
                                r = ur(r, 1 / 0).filter((function(r) {
                                    return "-" !== r && r
                                })).join("_"), e = ur(e, 1 / 0).filter((function(r) {
                                    return "-" !== r && r
                                })).join("_"), t.allAreParticipants(r, 2, 5) && t.allAreParticipants(e, 1, 4) && !t.hasDuplicatedParticipant(r + "_" + e) || cr();
                                var a = t.getMarkets().trifecta;
                                return t.combinatorial.getPermutations(r, 2).map((function(r) {
                                    return e.split("_").map((function(t) {
                                        var e = "trifecta_" + r + "_" + t,
                                            n = r.replace(/_/g, ",") + "," + t;
                                        return {
                                            market: a,
                                            odd: e,
                                            betParam: n
                                        }
                                    }))
                                })).reduce((function(r, t) {
                                    return r.concat(t)
                                }), [])
                            }(c, i), e = a) : (V = e, e = n)) : (V = e, e = n)) : (V = e, e = n)) : (V = e, e = n)) : (V = e, e = n);
                            return e
                        }()) === n && (a = function() {
                            var e, a, o, c, u, i, s, d, l, f, h, A, p, C, v;
                            e = V, "t" === r.substr(V, 1).toLowerCase() ? (a = r.charAt(V), V++) : (a = n, 0 === G && Z(b));
                            a !== n ? ("n" === r.substr(V, 1).toLowerCase() ? (o = r.charAt(V), V++) : (o = n, 0 === G && Z(j)), o !== n ? ("x" === r.substr(V, 1).toLowerCase() ? (c = r.charAt(V), V++) : (c = n, 0 === G && Z(M)), c !== n ? (u = V, (i = or()) !== n ? (45 === r.charCodeAt(V) ? (s = "-", V++) : (s = n, 0 === G && Z(g)), s !== n && (d = or()) !== n ? (45 === r.charCodeAt(V) ? (l = "-", V++) : (l = n, 0 === G && Z(g)), l !== n && (f = or()) !== n ? (h = V, 45 === r.charCodeAt(V) ? (A = "-", V++) : (A = n, 0 === G && Z(g)), A !== n && (p = or()) !== n ? h = A = [A, p] : (V = h, h = n), h === n && (h = null), h !== n ? (A = V, 45 === r.charCodeAt(V) ? (p = "-", V++) : (p = n, 0 === G && Z(g)), p !== n && (C = or()) !== n ? A = p = [p, C] : (V = A, A = n), A === n && (A = null), A !== n ? (p = V, 45 === r.charCodeAt(V) ? (C = "-", V++) : (C = n, 0 === G && Z(g)), C !== n && (v = or()) !== n ? p = C = [C, v] : (V = p, p = n), p === n && (p = null), p !== n ? u = i = [i, s, d, l, f, h, A, p] : (V = u, u = n)) : (V = u, u = n)) : (V = u, u = n)) : (V = u, u = n)) : (V = u, u = n)) : (V = u, u = n), u !== n ? (U = e, a = function(r) {
                                r = ur(r, 1 / 0).filter((function(r) {
                                    return "-" !== r && r
                                })).join("_"), t.allAreParticipants(r, 3, 6) || cr();
                                var e = t.getMarkets().trifecta;
                                return t.combinatorial.getPermutations(r, 3).map((function(r) {
                                    var t = "trifecta_" + r,
                                        a = r.replace(/_/g, ",");
                                    return {
                                        market: e,
                                        odd: t,
                                        betParam: a
                                    }
                                }))
                            }(u), e = a) : (V = e, e = n)) : (V = e, e = n)) : (V = e, e = n)) : (V = e, e = n);
                            return e
                        }()) === n && (a = function() {
                            var e, a, o, c, u, i, s, d, l, f, h, p, C, v, m;
                            e = V, 49 === r.charCodeAt(V) ? (a = "1", V++) : (a = n, 0 === G && Z(E));
                            a !== n ? ("p" === r.substr(V, 1).toLowerCase() ? (o = r.charAt(V), V++) : (o = n, 0 === G && Z(A)), o !== n ? ("x" === r.substr(V, 1).toLowerCase() ? (c = r.charAt(V), V++) : (c = n, 0 === G && Z(M)), c !== n && (u = or()) !== n ? (47 === r.charCodeAt(V) ? (i = "/", V++) : (i = n, 0 === G && Z(O)), i !== n ? (s = V, (d = or()) !== n ? (45 === r.charCodeAt(V) ? (l = "-", V++) : (l = n, 0 === G && Z(g)), l !== n && (f = or()) !== n ? (h = V, 45 === r.charCodeAt(V) ? (p = "-", V++) : (p = n, 0 === G && Z(g)), p !== n && (C = or()) !== n ? h = p = [p, C] : (V = h, h = n), h === n && (h = null), h !== n ? (p = V, 45 === r.charCodeAt(V) ? (C = "-", V++) : (C = n, 0 === G && Z(g)), C !== n && (v = or()) !== n ? p = C = [C, v] : (V = p, p = n), p === n && (p = null), p !== n ? (C = V, 45 === r.charCodeAt(V) ? (v = "-", V++) : (v = n, 0 === G && Z(g)), v !== n && (m = or()) !== n ? C = v = [v, m] : (V = C, C = n), C === n && (C = null), C !== n ? s = d = [d, l, f, h, p, C] : (V = s, s = n)) : (V = s, s = n)) : (V = s, s = n)) : (V = s, s = n)) : (V = s, s = n), s !== n ? (U = e, a = function(r, e) {
                                e = ur(e, 1 / 0).filter((function(r) {
                                    return "-" !== r && r
                                })).join("_"), t.isParticipant(r) && t.allAreParticipants(e, 2, 5) && !t.hasDuplicatedParticipant(r + "_" + e) || cr();
                                var a = t.getMarkets().trifecta;
                                return t.combinatorial.getPermutations(r + "_" + e, 3).filter((function(t) {
                                    return t.indexOf(r) > -1
                                })).map((function(r) {
                                    var t = "trifecta_" + r,
                                        e = r.replace(/_/g, ",");
                                    return {
                                        market: a,
                                        odd: t,
                                        betParam: e
                                    }
                                }))
                            }(u, s), e = a) : (V = e, e = n)) : (V = e, e = n)) : (V = e, e = n)) : (V = e, e = n)) : (V = e, e = n);
                            return e
                        }()), a !== n ? (U = e, e = a) : (V = e, e = n)) : (V = e, e = n);
                        return e
                    }()) === n && (c = function() {
                        var e, a, o;
                        e = V, a = V, G++, o = ar(), G--, o !== n ? (V = a, a = void 0) : a = n;
                        a !== n && (o = function() {
                            var e, a, o, c, u, i, s, d, l, f, h, A, p, v, m, _, b, w, k, P, y, L, x;
                            e = V, "f" === r.substr(V, 1).toLowerCase() ? (a = r.charAt(V), V++) : (a = n, 0 === G && Z(F));
                            a !== n ? ("a" === r.substr(V, 1).toLowerCase() ? (o = r.charAt(V), V++) : (o = n, 0 === G && Z(C)), o !== n ? ("x" === r.substr(V, 1).toLowerCase() ? (c = r.charAt(V), V++) : (c = n, 0 === G && Z(M)), c !== n ? (u = V, (i = or()) !== n ? (45 === r.charCodeAt(V) ? (s = "-", V++) : (s = n, 0 === G && Z(g)), s !== n && (d = or()) !== n ? (45 === r.charCodeAt(V) ? (l = "-", V++) : (l = n, 0 === G && Z(g)), l !== n && (f = or()) !== n ? (45 === r.charCodeAt(V) ? (h = "-", V++) : (h = n, 0 === G && Z(g)), h !== n && (A = or()) !== n ? (45 === r.charCodeAt(V) ? (p = "-", V++) : (p = n, 0 === G && Z(g)), p !== n && (v = or()) !== n ? (m = V, 45 === r.charCodeAt(V) ? (_ = "-", V++) : (_ = n, 0 === G && Z(g)), _ !== n && (b = or()) !== n ? m = _ = [_, b] : (V = m, m = n), m === n && (m = null), m !== n ? (_ = V, 45 === r.charCodeAt(V) ? (b = "-", V++) : (b = n, 0 === G && Z(g)), b !== n && (w = or()) !== n ? _ = b = [b, w] : (V = _, _ = n), _ === n && (_ = null), _ !== n ? (b = V, 45 === r.charCodeAt(V) ? (w = "-", V++) : (w = n, 0 === G && Z(g)), w !== n && (k = or()) !== n ? b = w = [w, k] : (V = b, b = n), b === n && (b = null), b !== n ? (w = V, 45 === r.charCodeAt(V) ? (k = "-", V++) : (k = n, 0 === G && Z(g)), k !== n && (P = or()) !== n ? w = k = [k, P] : (V = w, w = n), w === n && (w = null), w !== n ? (k = V, 45 === r.charCodeAt(V) ? (P = "-", V++) : (P = n, 0 === G && Z(g)), P !== n && (y = or()) !== n ? k = P = [P, y] : (V = k, k = n), k === n && (k = null), k !== n ? (P = V, 45 === r.charCodeAt(V) ? (y = "-", V++) : (y = n, 0 === G && Z(g)), y !== n && (L = or()) !== n ? P = y = [y, L] : (V = P, P = n), P === n && (P = null), P !== n ? (y = V, 45 === r.charCodeAt(V) ? (L = "-", V++) : (L = n, 0 === G && Z(g)), L !== n && (x = or()) !== n ? y = L = [L, x] : (V = y, y = n), y === n && (y = null), y !== n ? u = i = [i, s, d, l, f, h, A, p, v, m, _, b, w, k, P, y] : (V = u, u = n)) : (V = u, u = n)) : (V = u, u = n)) : (V = u, u = n)) : (V = u, u = n)) : (V = u, u = n)) : (V = u, u = n)) : (V = u, u = n)) : (V = u, u = n)) : (V = u, u = n)) : (V = u, u = n)) : (V = u, u = n), u !== n ? (U = e, a = function(r) {
                                r = ur(r, 1 / 0).filter((function(r) {
                                    return "-" !== r && r
                                })).sort((function(r, t) {
                                    return r - t
                                })).join("_"), t.allAreParticipants(r, 5, 12) && !t.hasDuplicatedParticipant(r) || cr();
                                var e = t.getMarkets().four_any_order;
                                return t.combinatorial.getPermutations(r, 4).filter((function(r) {
                                    return r.split("_").every((function(r, t, e) {
                                        return 0 === t || +r > +e[t - 1]
                                    }))
                                })).map((function(r) {
                                    var t = "four_any_" + r,
                                        a = r.replace(/_/g, ",");
                                    return {
                                        market: e,
                                        odd: t,
                                        betParam: a
                                    }
                                }))
                            }(u), e = a) : (V = e, e = n)) : (V = e, e = n)) : (V = e, e = n)) : (V = e, e = n);
                            return e
                        }()) !== n ? (U = e, e = a = o) : (V = e, e = n);
                        return e
                    }()), c !== n ? ((u = nr()) === n && (u = null), u !== n ? (U = e, e = c = function(r, t) {
                        return r.map((function(r) {
                            return o({}, r, t || {})
                        }))
                    }(c, u)) : (V = e, e = n)) : (V = e, e = n)), e
                }

                function er() {
                    return U = V, t.getPodium() >= 3 ? void 0 : n
                }

                function ar() {
                    return U = V, t.isThrottingMarketsEnabled() ? void 0 : n
                }

                function nr() {
                    var e, a, o, c;
                    return e = V, 43 === r.charCodeAt(V) ? (a = "+", V++) : (a = n, 0 === G && Z(S)), a !== n && (o = function() {
                        var t, e, a, o, c, u;
                        if (t = V, e = V, (a = or()) !== n)
                            if (46 === r.charCodeAt(V) ? (o = ".", V++) : (o = n, 0 === G && Z(N)), o !== n) {
                                if (c = [], T.test(r.charAt(V)) ? (u = r.charAt(V), V++) : (u = n, 0 === G && Z(q)), u !== n)
                                    for (; u !== n;) c.push(u), T.test(r.charAt(V)) ? (u = r.charAt(V), V++) : (u = n, 0 === G && Z(q));
                                else c = n;
                                c !== n ? e = a = [a, o, c] : (V = e, e = n)
                            } else V = e, e = n;
                        else V = e, e = n;
                        e === n && (e = or());
                        e !== n && (U = t, e = J());
                        return t = e
                    }()) !== n ? (U = e, (c = o) > t.getMaxStake() && cr("Max stake is " + t.getMaxStake()), e = a = {
                        stake: c
                    }) : (V = e, e = n), e
                }

                function or() {
                    var t, e, a, o, c;
                    if (t = V, 48 === r.charCodeAt(V) ? (e = "0", V++) : (e = n, 0 === G && Z(R)), e === n)
                        if (e = V, I.test(r.charAt(V)) ? (a = r.charAt(V), V++) : (a = n, 0 === G && Z(D)), a !== n) {
                            for (o = [], T.test(r.charAt(V)) ? (c = r.charAt(V), V++) : (c = n, 0 === G && Z(q)); c !== n;) o.push(c), T.test(r.charAt(V)) ? (c = r.charAt(V), V++) : (c = n, 0 === G && Z(q));
                            o !== n ? e = a = [a, o] : (V = e, e = n)
                        } else V = e, e = n;
                    return e !== n && (U = t, e = J()), t = e
                }

                function cr(t, e) {
                    void 0 === t && (t = ""), void 0 === e && (e = 0),
                        function(t, e) {
                            throw e = void 0 !== e ? e : Y(U, V), $([Q(t)], r.substring(U, V), e)
                        }(t, Y(V - 1 - e, V))
                }

                function ur(r, t) {
                    return void 0 === t && (t = 1), t > 0 ? r.reduce((function(r, e) {
                        return r.concat(Array.isArray(e) ? ur(e, t - 1) : e)
                    }), []) : r.slice()
                }
                if ((e = i()) !== n && V === r.length) return e;
                throw e !== n && V < r.length && Z({
                    type: "end"
                }), $(B, z < r.length ? r.charAt(z) : null, z < r.length ? Y(z, z + 1) : Y(z, z))
            }
        }
    }
]);