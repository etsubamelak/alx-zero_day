(window.webpackJsonp = window.webpackJsonp || []).push([
    [4], {
        "+1aa": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "NoAccumulatedTruncate", _
                }
                return n(t, e), t
            }(_("IJP8").CurrencyPolicy);
            t.NoAccumulatedTruncate = r
        },
        "+DwJ": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "FootballEventBlockStats", _.classification = [], t && t.classification && t.classification.forEach((function(e) {
                            _.classification.push(new r.FootballClassificationEntry(e))
                        })), _
                    }
                    return n(t, e), t
                }(_("HZPa").EventBlockStats);
            t.FootballEventBlockStats = o
        },
        "+Lil": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "S7EventBlockData", t && (_.croupierName = t.croupierName, _.videoUrl = t.videoUrl, _.presenterVideoUrl = t.presenterVideoUrl, _.presenterImageUrl = t.presenterImageUrl, _.placeBetsIdentUrl = t.placeBetsIdentUrl, _.betsClosedIdentsUrl = t.betsClosedIdentsUrl, _.gameIdentUrl = t.gameIdentUrl, t.drawDate ? _.drawDate = new Date(t.drawDate.toString()) : _.drawDate = null, t.updateDate ? _.updateDate = new Date(t.updateDate.toString()) : _.updateDate = null), _
                }
                return n(t, e), t
            }(_("AjTw").EventBlockData);
            t.S7EventBlockData = r
        },
        "+p5m": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "S2WGameOddSettings", t && (_.payTable = t.payTable ? new r.S2WPayTable(t.payTable) : null), _
                    }
                    return n(t, e), t
                }(_("ZMgZ").GameOddSettings);
            t.S2WGameOddSettings = o
        },
        "/VPC": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "LottoResultReport", _
                }
                return n(t, e), t
            }(_("fU0W").Report);
            t.LottoResultReport = r
        },
        "/VyY": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.marketId = e.marketId, this.oddId = e.oddId, this.oddValue = e.oddValue, this.stake = e.stake, this.cancelledStake = e.cancelledStake, this.betParam = e.betParam, this.status = e.status, this.profitType = e.profitType, e.timeSolved ? this.timeSolved = new Date(e.timeSolved.toString()) : this.timeSolved = null)
            };
            t.TicketBet = a,
                function(e) {
                    ! function(e) {
                        e.OPEN = "OPEN", e.WON = "WON", e.CASHOUT = "CASHOUT", e.LOST = "LOST", e.CANCEL = "CANCEL", e.NA = "NA"
                    }(e.StatusEnum || (e.StatusEnum = {}))
                }(a = t.TicketBet || (t.TicketBet = {})), t.TicketBet = a,
                function(e) {
                    ! function(e) {
                        e.ALLWON = "ALLWON", e.HALFWON = "HALFWON", e.REFUND = "REFUND", e.HALFLOST = "HALFLOST", e.NONE = "NONE"
                    }(e.ProfitTypeEnum || (e.ProfitTypeEnum = {}))
                }(a = t.TicketBet || (t.TicketBet = {})), t.TicketBet = a
        },
        "/qIM": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    e && (this.key = e.key, this.policy = e.policy ? new a.CurrencyPolicy(e.policy) : null, this.limits = e.limits ? new a.LimitsCurrencySetting(e.limits) : null)
                };
            t.TicketCurrencySetting = n
        },
        "02bP": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "ChEventBlockData", t && (_.champId = t.champId, _.weekDay = t.weekDay, _.legOrder = t.legOrder, _.phase = t.phase, _.matchDay = t.matchDay), _
                }
                return n(t, e), t
            }(_("AjTw").EventBlockData);
            t.ChEventBlockData = r,
                function(e) {
                    ! function(e) {
                        e.GROUPS = "GROUPS", e.Q32 = "Q32", e.Q16 = "Q16", e.Q8 = "Q8", e.Q4 = "Q4", e.SEMIFINAL = "SEMIFINAL", e.FINAL = "FINAL"
                    }(e.PhaseEnum || (e.PhaseEnum = {}))
                }(r = t.ChEventBlockData || (t.ChEventBlockData = {})), t.ChEventBlockData = r
        },
        "04Qv": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                var t = this;
                this.participants = [], this.finalOutcome = [], e && (this.eventId = e.eventId, e.participants && e.participants.forEach((function(e) {
                    t.participants.push(e)
                })), e.finalOutcome && e.finalOutcome.forEach((function(e) {
                    t.finalOutcome.push(e)
                })), this.penalty = e.penalty, this.classifiedTeam = e.classifiedTeam)
            };
            t.ChEventKnockoutClassificationEntry = a
        },
        "0B+E": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "BasketAssets", _
                }
                return n(t, e), t
            }(_("8xXt").Assets);
            t.BasketAssets = r
        },
        "0LOy": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "S7EventResultData", _.result = [], t && t.result && t.result.forEach((function(e) {
                        _.result.push(e)
                    })), _
                }
                return n(t, e), t
            }(_("RUMs").EventResultData);
            t.S7EventResultData = r
        },
        "0jIh": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                var t = this;
                this.historyMatches = [], e && e.historyMatches && e.historyMatches.forEach((function(e) {
                    t.historyMatches.push(e)
                }))
            };
            t.ChTeamHistoryResults = a
        },
        "0nN5": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "TaxContext", _.currencies = [], t && t.currencies && t.currencies.forEach((function(e) {
                            _.currencies.push(new r.TaxCurrency(e))
                        })), _
                    }
                    return n(t, e), t
                }(_("eSR3").Context);
            t.TaxContext = o
        },
        "1+xn": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                var t = this;
                this.content = [], e && (this.key = e.key, e.content && e.content.forEach((function(e) {
                    t.content.push(e)
                })), this.speed = e.speed)
            };
            t.TickerGameSetting = a,
                function(e) {
                    ! function(e) {
                        e.PREAMBLE = "PREAMBLE", e.INGAME = "INGAME", e.RESULT = "RESULT"
                    }(e.KeyEnum || (e.KeyEnum = {}))
                }(a = t.TickerGameSetting || (t.TickerGameSetting = {})), t.TickerGameSetting = a
        },
        "1KSo": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "LlFilter", _
                }
                return n(t, e), t
            }(_("zE96").Filter);
            t.LlFilter = r
        },
        "1SOG": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.unitSessionStatus = [], e && (e.serverTimeStamp ? this.serverTimeStamp = new Date(e.serverTimeStamp.toString()) : this.serverTimeStamp = null, e.unitSessionStatus && e.unitSessionStatus.forEach((function(e) {
                        t.unitSessionStatus.push(new a.UnitSessionStatus(e))
                    })))
                };
            t.BulkSyncResponse = n
        },
        "1hBs": function(e, t, _) {
            "use strict";

            function a(e) {
                for (var _ in e) t.hasOwnProperty(_) || (t[_] = e[_])
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var n = _("tb2k");
            t.model = n;
            var r = _("o4iV");
            t.services = r, a(_("PWJJ")), a(_("ffvd")), a(_("7u87"))
        },
        "1jO/": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "LlEventLiveStats", _.result = [], t && t.result && t.result.forEach((function(e) {
                        _.result.push(e)
                    })), _
                }
                return n(t, e), t
            }(_("O4ZI").EventLiveStats);
            t.LlEventLiveStats = r
        },
        "1kxM": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                var t = this;
                this.entityType = [], e && (e.entityType && e.entityType.forEach((function(e) {
                    t.entityType.push(e)
                })), this.id = e.id, this.name = e.name, this.extId = e.extId, this.extData = e.extData, this.status = e.status)
            };
            t.Entity = a
        },
        "1t07": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "RaceGameEventData", t && (_.trackCondition = t.trackCondition), _
                }
                return n(t, e), t
            }(_("VqjV").GameEventData);
            t.RaceGameEventData = r
        },
        "1y+E": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "LottofiveEventResultData", _.drawResult = [], _.drawMachine = [], t && (t.drawResult && t.drawResult.forEach((function(e) {
                        _.drawResult.push(e)
                    })), t.drawMachine && t.drawMachine.forEach((function(e) {
                        _.drawMachine.push(e)
                    })), _.resultVideoURL = t.resultVideoURL), _
                }
                return n(t, e), t
            }(_("RUMs").EventResultData);
            t.LottofiveEventResultData = r
        },
        "23Rb": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                var t = this;
                this.lastResults = [], e && (this.homeMatches = e.homeMatches, this.awayMatches = e.awayMatches, this.wonHome = e.wonHome, this.wonAway = e.wonAway, this.drawHome = e.drawHome, this.drawAway = e.drawAway, this.lostHome = e.lostHome, this.lostAway = e.lostAway, this.wonPerc = e.wonPerc, this.wonHomePerc = e.wonHomePerc, this.wonAwayPerc = e.wonAwayPerc, this.drawPerc = e.drawPerc, this.drawHomePerc = e.drawHomePerc, this.drawAwayPerc = e.drawAwayPerc, this.lostPerc = e.lostPerc, this.lostHomePerc = e.lostHomePerc, this.lostAwayPerc = e.lostAwayPerc, this.goalsForHome = e.goalsForHome, this.goalsForAway = e.goalsForAway, this.goalsForPerMatch = e.goalsForPerMatch, this.goalsForPerMatchHome = e.goalsForPerMatchHome, this.goalsForPerMatchAway = e.goalsForPerMatchAway, this.goalsAgainstHome = e.goalsAgainstHome, this.goalsAgainstAway = e.goalsAgainstAway, this.goalsAgainstPerMatch = e.goalsAgainstPerMatch, this.goalsAgainstPerMatchHome = e.goalsAgainstPerMatchHome, this.goalsAgainstPerMatchAway = e.goalsAgainstPerMatchAway, e.lastResults && e.lastResults.forEach((function(e) {
                    t.lastResults.push(e)
                })))
            };
            t.ChTeamStat = a
        },
        "2TKF": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "LkGameOddSettings", _.payTable = [], t && t.payTable && t.payTable.forEach((function(e) {
                        _.payTable.push(e)
                    })), _
                }
                return n(t, e), t
            }(_("ZMgZ").GameOddSettings);
            t.LkGameOddSettings = r
        },
        "2WT7": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "SpeedwayGameOddSettings", _
                }
                return n(t, e), t
            }(_("aDCO").GameFixedOddSettings);
            t.SpeedwayGameOddSettings = r
        },
        "2mgP": function(e, t, _) {
            "use strict";
            var a, n, r, o, i, s, c, l, u, d, p, h, f, y, m, w, v, x, T, O, S, b, P, H, A;
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e) {
                    e.money_line = "money_line", e.home_minus_4_5_away_plus_4_5 = "home_minus_4_5_away_plus_4_5", e.home_plus_4_5_away_minus_4_5 = "home_plus_4_5_away_minus_4_5", e.home_minus_3_5_away_plus_3_5 = "home_minus_3_5_away_plus_3_5", e.home_plus_3_5_away_minus_3_5 = "home_plus_3_5_away_minus_3_5", e.home_minus_2_5_away_plus_2_5 = "home_minus_2_5_away_plus_2_5", e.home_plus_2_5_away_minus_2_5 = "home_plus_2_5_away_minus_2_5", e.home_minus_1_5_away_plus_1_5 = "home_minus_1_5_away_plus_1_5", e.home_plus_1_5_away_minus_1_5 = "home_plus_1_5_away_minus_1_5", e.over_under_30_5 = "over_under_30_5", e.over_under_31_5 = "over_under_31_5", e.over_under_32_5 = "over_under_32_5", e.over_under_33_5 = "over_under_33_5", e.over_under_34_5 = "over_under_34_5", e.over_under_35_5 = "over_under_35_5", e.over_under_36_5 = "over_under_36_5", e.over_under_37_5 = "over_under_37_5", e.over_under_38_5 = "over_under_38_5", e.over_under_39_5 = "over_under_39_5", e.over_under_40_5 = "over_under_40_5", e.race_21 = "race_21"
                }(H = t.BasketMarkets || (t.BasketMarkets = {})),
                function(e) {
                    e.home = "home", e.away = "away", e.home_minus_4_5 = "home_minus_4_5", e.away_plus_4_5 = "away_plus_4_5", e.home_plus_4_5 = "home_plus_4_5", e.away_minus_4_5 = "away_minus_4_5", e.home_minus_3_5 = "home_minus_3_5", e.away_plus_3_5 = "away_plus_3_5", e.home_plus_3_5 = "home_plus_3_5", e.away_minus_3_5 = "away_minus_3_5", e.home_minus_2_5 = "home_minus_2_5", e.away_plus_2_5 = "away_plus_2_5", e.home_plus_2_5 = "home_plus_2_5", e.away_minus_2_5 = "away_minus_2_5", e.home_minus_1_5 = "home_minus_1_5", e.away_plus_1_5 = "away_plus_1_5", e.home_plus_1_5 = "home_plus_1_5", e.away_minus_1_5 = "away_minus_1_5", e.over_30_5 = "over_30_5", e.under_30_5 = "under_30_5", e.over_31_5 = "over_31_5", e.under_31_5 = "under_31_5", e.over_32_5 = "over_32_5", e.under_32_5 = "under_32_5", e.over_33_5 = "over_33_5", e.under_33_5 = "under_33_5", e.over_34_5 = "over_34_5", e.under_34_5 = "under_34_5", e.over_35_5 = "over_35_5", e.under_35_5 = "under_35_5", e.over_36_5 = "over_36_5", e.under_36_5 = "under_36_5", e.over_37_5 = "over_37_5", e.under_37_5 = "under_37_5", e.over_38_5 = "over_38_5", e.under_38_5 = "under_38_5", e.over_39_5 = "over_39_5", e.under_39_5 = "under_39_5", e.over_40_5 = "over_40_5", e.under_40_5 = "under_40_5", e.yes = "yes", e.no = "no"
                }(A = t.BasketOdds || (t.BasketOdds = {})), t.BasketMarketsTemplate = ((a = {})[H.money_line] = ((n = {})[A.home] = A.home, n[A.away] = A.away, n), a[H.home_minus_4_5_away_plus_4_5] = ((r = {})[A.home_minus_4_5] = A.home_minus_4_5, r[A.away_plus_4_5] = A.away_plus_4_5, r), a[H.home_plus_4_5_away_minus_4_5] = ((o = {})[A.home_plus_4_5] = A.home_plus_4_5, o[A.away_minus_4_5] = A.away_minus_4_5, o), a[H.home_minus_3_5_away_plus_3_5] = ((i = {})[A.home_minus_3_5] = A.home_minus_3_5, i[A.away_plus_3_5] = A.away_plus_3_5, i), a[H.home_plus_3_5_away_minus_3_5] = ((s = {})[A.home_plus_3_5] = A.home_plus_3_5, s[A.away_minus_3_5] = A.away_minus_3_5, s), a[H.home_minus_2_5_away_plus_2_5] = ((c = {})[A.home_minus_2_5] = A.home_minus_2_5, c[A.away_plus_2_5] = A.away_plus_2_5, c), a[H.home_plus_2_5_away_minus_2_5] = ((l = {})[A.home_plus_2_5] = A.home_plus_2_5, l[A.away_minus_2_5] = A.away_minus_2_5, l), a[H.home_minus_1_5_away_plus_1_5] = ((u = {})[A.home_minus_1_5] = A.home_minus_1_5, u[A.away_plus_1_5] = A.away_plus_1_5, u), a[H.home_plus_1_5_away_minus_1_5] = ((d = {})[A.home_plus_1_5] = A.home_plus_1_5, d[A.away_minus_1_5] = A.away_minus_1_5, d), a[H.over_under_30_5] = ((p = {})[A.over_30_5] = A.over_30_5, p[A.under_30_5] = A.under_30_5, p), a[H.over_under_31_5] = ((h = {})[A.over_31_5] = A.over_31_5, h[A.under_31_5] = A.under_31_5, h), a[H.over_under_32_5] = ((f = {})[A.over_32_5] = A.over_32_5, f[A.under_32_5] = A.under_32_5, f), a[H.over_under_33_5] = ((y = {})[A.over_33_5] = A.over_33_5, y[A.under_33_5] = A.under_33_5, y), a[H.over_under_34_5] = ((m = {})[A.over_34_5] = A.over_34_5, m[A.under_34_5] = A.under_34_5, m), a[H.over_under_35_5] = ((w = {})[A.over_35_5] = A.over_35_5, w[A.under_35_5] = A.under_35_5, w), a[H.over_under_36_5] = ((v = {})[A.over_36_5] = A.over_36_5, v[A.under_36_5] = A.under_36_5, v), a[H.over_under_37_5] = ((x = {})[A.over_37_5] = A.over_37_5, x[A.under_37_5] = A.under_37_5, x), a[H.over_under_38_5] = ((T = {})[A.over_38_5] = A.over_38_5, T[A.under_38_5] = A.under_38_5, T), a[H.over_under_39_5] = ((O = {})[A.over_39_5] = A.over_39_5, O[A.under_39_5] = A.under_39_5, O), a[H.over_under_40_5] = ((S = {})[A.over_40_5] = A.over_40_5, S[A.under_40_5] = A.under_40_5, S), a[H.race_21] = ((b = {})[A.yes] = A.yes, b[A.no] = A.no, b), a), t.BasketOddsTemplate = ((P = {})[A.home] = H.money_line, P[A.away] = H.money_line, P[A.home_minus_4_5] = H.home_minus_4_5_away_plus_4_5, P[A.away_plus_4_5] = H.home_minus_4_5_away_plus_4_5, P[A.home_plus_4_5] = H.home_plus_4_5_away_minus_4_5, P[A.away_minus_4_5] = H.home_plus_4_5_away_minus_4_5, P[A.home_minus_3_5] = H.home_minus_3_5_away_plus_3_5, P[A.away_plus_3_5] = H.home_minus_3_5_away_plus_3_5, P[A.home_plus_3_5] = H.home_plus_3_5_away_minus_3_5, P[A.away_minus_3_5] = H.home_plus_3_5_away_minus_3_5, P[A.home_minus_2_5] = H.home_minus_2_5_away_plus_2_5, P[A.away_plus_2_5] = H.home_minus_2_5_away_plus_2_5, P[A.home_plus_2_5] = H.home_plus_2_5_away_minus_2_5, P[A.away_minus_2_5] = H.home_plus_2_5_away_minus_2_5, P[A.home_minus_1_5] = H.home_minus_1_5_away_plus_1_5, P[A.away_plus_1_5] = H.home_minus_1_5_away_plus_1_5, P[A.home_plus_1_5] = H.home_plus_1_5_away_minus_1_5, P[A.away_minus_1_5] = H.home_plus_1_5_away_minus_1_5, P[A.over_30_5] = H.over_under_30_5, P[A.under_30_5] = H.over_under_30_5, P[A.over_31_5] = H.over_under_31_5, P[A.under_31_5] = H.over_under_31_5, P[A.over_32_5] = H.over_under_32_5, P[A.under_32_5] = H.over_under_32_5, P[A.over_33_5] = H.over_under_33_5, P[A.under_33_5] = H.over_under_33_5, P[A.over_34_5] = H.over_under_34_5, P[A.under_34_5] = H.over_under_34_5, P[A.over_35_5] = H.over_under_35_5, P[A.under_35_5] = H.over_under_35_5, P[A.over_36_5] = H.over_under_36_5, P[A.under_36_5] = H.over_under_36_5, P[A.over_37_5] = H.over_under_37_5, P[A.under_37_5] = H.over_under_37_5, P[A.over_38_5] = H.over_under_38_5, P[A.under_38_5] = H.over_under_38_5, P[A.over_39_5] = H.over_under_39_5, P[A.under_39_5] = H.over_under_39_5, P[A.over_40_5] = H.over_under_40_5, P[A.under_40_5] = H.over_under_40_5, P[A.yes] = H.race_21, P[A.no] = H.race_21, P)
        },
        "2xuN": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.stakeInput = e.stakeInput, this.betslipMode = e.betslipMode, this.standardViewBetMode = e.standardViewBetMode, this.tabViewSystemMode = e.tabViewSystemMode)
            };
            t.BetslipProfileSettings = a,
                function(e) {
                    ! function(e) {
                        e.KEYPAD = "KEYPAD", e.KEYPADANDTOKEN = "KEYPADANDTOKEN"
                    }(e.StakeInputEnum || (e.StakeInputEnum = {}))
                }(a = t.BetslipProfileSettings || (t.BetslipProfileSettings = {})), t.BetslipProfileSettings = a,
                function(e) {
                    ! function(e) {
                        e.STANDARD = "STANDARD", e.TAB = "TAB"
                    }(e.BetslipModeEnum || (e.BetslipModeEnum = {}))
                }(a = t.BetslipProfileSettings || (t.BetslipProfileSettings = {})), t.BetslipProfileSettings = a,
                function(e) {
                    ! function(e) {
                        e.LIST = "LIST", e.CHIPS = "CHIPS"
                    }(e.StandardViewBetModeEnum || (e.StandardViewBetModeEnum = {}))
                }(a = t.BetslipProfileSettings || (t.BetslipProfileSettings = {})), t.BetslipProfileSettings = a,
                function(e) {
                    ! function(e) {
                        e.LIST = "LIST", e.RADIO = "RADIO"
                    }(e.TabViewSystemModeEnum || (e.TabViewSystemModeEnum = {}))
                }(a = t.BetslipProfileSettings || (t.BetslipProfileSettings = {})), t.BetslipProfileSettings = a
        },
        "3G+M": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                var t = this;
                this.ticketTexts = [], e && (e.ticketTexts && e.ticketTexts.forEach((function(e) {
                    t.ticketTexts.push(e)
                })), this.ticketTopUrl = e.ticketTopUrl, this.legalText = e.legalText)
            };
            t.TicketAdvertisement = a
        },
        "3LWi": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                var t = this;
                this.drawResult = [], this.drawMachine = [], e && (e.eventTime ? this.eventTime = new Date(e.eventTime.toString()) : this.eventTime = null, e.drawResult && e.drawResult.forEach((function(e) {
                    t.drawResult.push(e)
                })), e.drawMachine && e.drawMachine.forEach((function(e) {
                    t.drawMachine.push(e)
                })))
            };
            t.CityResultData = a
        },
        "3Uo4": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "TrottingViewerProfileGameSettings", _
                }
                return n(t, e), t
            }(_("PBHJ").ViewerProfileGameSettings);
            t.TrottingViewerProfileGameSettings = r
        },
        "3piG": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.limitMaxPayout = e.limitMaxPayout, this.minWinning = e.minWinning, this.maxWinning = e.maxWinning, this.minBonus = e.minBonus, this.maxBonus = e.maxBonus)
            };
            t.ServerTicketWinningData = a
        },
        "3xEZ": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function() {
                    function e(e, t) {
                        if (void 0 === t && (t = !0), e && (this.classType = e.classType, t && this.classType)) switch (this.classType) {
                            case "LottoResultReportData":
                                return new a.LottoResultReportData(e);
                            case "MoveEntityReportData":
                                return new a.MoveEntityReportData(e);
                            case "PosReportData":
                                return new a.PosReportData(e);
                            case "SettlementReportData":
                                return new a.SettlementReportData(e)
                        }
                    }
                    return e.prototype.isLottoResultReportData = function() {
                        return "LottoResultReportData" === this.classType
                    }, e.prototype.isMoveEntityReportData = function() {
                        return "MoveEntityReportData" === this.classType
                    }, e.prototype.isPosReportData = function() {
                        return "PosReportData" === this.classType
                    }, e.prototype.isSettlementReportData = function() {
                        return "SettlementReportData" === this.classType
                    }, e
                }();
            t.ReportData = n
        },
        "45Qj": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                var t = this;
                this.playlistFilter = [], this.playlistBlocked = [], e && (this.jackpotId = e.jackpotId, this.jackpotName = e.jackpotName, this.jackpotDesc = e.jackpotDesc, this.targetId = e.targetId, this.targetType = e.targetType, e.playlistFilter && e.playlistFilter.forEach((function(e) {
                    t.playlistFilter.push(e)
                })), e.playlistBlocked && e.playlistBlocked.forEach((function(e) {
                    t.playlistBlocked.push(e)
                })))
            };
            t.JackpotConfigurationView = a,
                function(e) {
                    ! function(e) {
                        e.GLOBAL = "GLOBAL", e.CLIENT = "CLIENT", e.LOCAL = "LOCAL", e.LEVEL1 = "LEVEL1", e.LEVEL2 = "LEVEL2", e.LEVEL3 = "LEVEL3"
                    }(e.TargetTypeEnum || (e.TargetTypeEnum = {}))
                }(a = t.JackpotConfigurationView || (t.JackpotConfigurationView = {})), t.JackpotConfigurationView = a
        },
        "4CtW": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.start = e.start, this.end = e.end, this.duration = e.duration)
            };
            t.BasketTimeInterval = a
        },
        "4Lmp": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t, _) {
                    void 0 === _ && (_ = !0);
                    var a = e.call(this, t, !1) || this;
                    return a.classType = "RacesFilter", t && (a.maxProb = t.maxProb, a.minProb = t.minProb, a.risk = t.risk, a.raceType = t.raceType, a.contextParticipants = t.contextParticipants, a.resourcePathNameParticipants = t.resourcePathNameParticipants, a.contextVideo = t.contextVideo, a.resourcePathNameVideo = t.resourcePathNameVideo, a.numParticipants = t.numParticipants, a.numPodium = t.numPodium, a.libraryId = t.libraryId, a.inGameContentType = t.inGameContentType), a
                }
                return n(t, e), t
            }(_("zE96").Filter);
            t.RacesFilter = r,
                function(e) {
                    ! function(e) {
                        e.NORMAL = "NORMAL", e.MEDIUM = "MEDIUM", e.HIGH = "HIGH"
                    }(e.RiskEnum || (e.RiskEnum = {}))
                }(r = t.RacesFilter || (t.RacesFilter = {})), t.RacesFilter = r,
                function(e) {
                    ! function(e) {
                        e.SIMULATE = "SIMULATE", e.TABLE = "TABLE", e.FIXEDODDS = "FIXEDODDS", e.STATIC = "STATIC"
                    }(e.RaceTypeEnum || (e.RaceTypeEnum = {}))
                }(r = t.RacesFilter || (t.RacesFilter = {})), t.RacesFilter = r,
                function(e) {
                    ! function(e) {
                        e.VIDEOS = "VIDEOS", e.RENDER3D = "RENDER3D"
                    }(e.InGameContentTypeEnum || (e.InGameContentTypeEnum = {}))
                }(r = t.RacesFilter || (t.RacesFilter = {})), t.RacesFilter = r
        },
        "4Pbz": function(e, t, _) {
            "use strict";
            var a, n, r, o, i, s, c, l, u, d, p, h, f, y, m, w, v, x, T, O, S, b, P, H, A, E, g, k, q, M, C, B, D, G, R, j, I, L, F, U, N, W, V, K;
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e) {
                    e.AllIn1 = "AllIn1", e.AllIn2 = "AllIn2", e.AllIn3 = "AllIn3", e.AllIn4 = "AllIn4", e.AllIn5 = "AllIn5", e.AllIn6 = "AllIn6", e.AllIn7 = "AllIn7", e.Numbers = "Numbers", e.NoDraw1 = "NoDraw1", e.NoDraw2 = "NoDraw2", e.NoDraw3 = "NoDraw3", e.NoDraw4 = "NoDraw4", e.NoDraw5 = "NoDraw5", e.NoDraw6 = "NoDraw6", e.NoDraw7 = "NoDraw7", e.FirstBallColor = "FirstBallColor", e.LastBallColor = "LastBallColor", e.FirstAndSecondBallColor = "FirstAndSecondBallColor", e.WhiteBalls = "WhiteBalls", e.RedBalls = "RedBalls", e.SumUnder100 = "SumUnder100", e.SumUnderOver125 = "SumUnderOver125", e.SumUnderOver150 = "SumUnderOver150", e.SumUnderOver175 = "SumUnderOver175", e.SumOver200 = "SumOver200", e.SumWhiteUnderOver73 = "SumWhiteUnderOver73", e.SumRedUnderOver73 = "SumRedUnderOver73", e.CountWhiteUnderOver3 = "CountWhiteUnderOver3", e.CountWhiteUnderOver2 = "CountWhiteUnderOver2", e.CountWhiteUnderOver1 = "CountWhiteUnderOver1", e.CountRedUnderOver3 = "CountRedUnderOver3", e.CountRedUnderOver2 = "CountRedUnderOver2", e.CountRedUnderOver1 = "CountRedUnderOver1", e.OddEven = "OddEven", e.SumOddEven = "SumOddEven", e.FirstBallOddEven = "FirstBallOddEven", e.LastBallOddEven = "LastBallOddEven", e.FirstTwoBallsOddEven = "FirstTwoBallsOddEven", e.FirstAndSecondBallOddEven = "FirstAndSecondBallOddEven", e.FirstAndLastBallOddEven = "FirstAndLastBallOddEven"
                }(V = t.S7Markets || (t.S7Markets = {})),
                function(e) {
                    e.AllIn1 = "AllIn1", e.AllIn2 = "AllIn2", e.AllIn3 = "AllIn3", e.AllIn4 = "AllIn4", e.AllIn5 = "AllIn5", e.AllIn6 = "AllIn6", e.AllIn7 = "AllIn7", e.OneOutOf7 = "OneOutOf7", e.TwoOutOf7 = "TwoOutOf7", e.ThreeOutOf7 = "ThreeOutOf7", e.FourOutOf7 = "FourOutOf7", e.FiveOutOf7 = "FiveOutOf7", e.SixOutOf7 = "SixOutOf7", e.SevenOutOf7 = "SevenOutOf7", e.NoDraw1 = "NoDraw1", e.NoDraw2 = "NoDraw2", e.NoDraw3 = "NoDraw3", e.NoDraw4 = "NoDraw4", e.NoDraw5 = "NoDraw5", e.NoDraw6 = "NoDraw6", e.NoDraw7 = "NoDraw7", e.FirstBallWhite = "FirstBallWhite", e.FirstBallRed = "FirstBallRed", e.LastBallWhite = "LastBallWhite", e.LastBallRed = "LastBallRed", e.FirstAndSecondSameColor = "FirstAndSecondSameColor", e.FirstAndSecondDifferentColor = "FirstAndSecondDifferentColor", e.SevenWhiteBalls = "SevenWhiteBalls", e.SixWhiteBalls = "SixWhiteBalls", e.FiveWhiteBalls = "FiveWhiteBalls", e.FourWhiteBalls = "FourWhiteBalls", e.ThreeWhiteBalls = "ThreeWhiteBalls", e.TwoWhiteBalls = "TwoWhiteBalls", e.OneWhiteBalls = "OneWhiteBalls", e.SevenRedBalls = "SevenRedBalls", e.SixRedBalls = "SixRedBalls", e.FiveRedBalls = "FiveRedBalls", e.FourRedBalls = "FourRedBalls", e.ThreeRedBalls = "ThreeRedBalls", e.TwoRedBalls = "TwoRedBalls", e.OneRedBalls = "OneRedBalls", e.SumUnder100 = "SumUnder100", e.SumUnder125 = "SumUnder125", e.SumOver125 = "SumOver125", e.SumUnder150 = "SumUnder150", e.SumOver150 = "SumOver150", e.SumUnder175 = "SumUnder175", e.SumOver175 = "SumOver175", e.SumOver200 = "SumOver200", e.SumWhiteUnder73 = "SumWhiteUnder73", e.SumWhiteOver73 = "SumWhiteOver73", e.SumRedUnder73 = "SumRedUnder73", e.SumRedOver73 = "SumRedOver73", e.CountWhiteUnder3 = "CountWhiteUnder3", e.CountWhiteOver3 = "CountWhiteOver3", e.CountWhiteUnder2 = "CountWhiteUnder2", e.CountWhiteOver2 = "CountWhiteOver2", e.CountWhiteUnder1 = "CountWhiteUnder1", e.CountWhiteOver1 = "CountWhiteOver1", e.CountRedUnder3 = "CountRedUnder3", e.CountRedOver3 = "CountRedOver3", e.CountRedUnder2 = "CountRedUnder2", e.CountRedOver2 = "CountRedOver2", e.CountRedUnder1 = "CountRedUnder1", e.CountRedOver1 = "CountRedOver1", e.MoreOdd = "MoreOdd", e.MoreEven = "MoreEven", e.SumOdd = "SumOdd", e.SumEven = "SumEven", e.FirstBallOdd = "FirstBallOdd", e.FirstBallEven = "FirstBallEven", e.LastBallOdd = "LastBallOdd", e.LastBallEven = "LastBallEven", e.FirstTwoBallsOdd = "FirstTwoBallsOdd", e.FirstTwoBallsEven = "FirstTwoBallsEven", e.FirstOddAndSecondEven = "FirstOddAndSecondEven", e.FirstEvenAndSecondOdd = "FirstEvenAndSecondOdd", e.FirstOddAndLastEven = "FirstOddAndLastEven", e.FirstEvenAndLastOdd = "FirstEvenAndLastOdd"
                }(K = t.S7Odds || (t.S7Odds = {})), t.S7MarketsTemplate = ((a = {})[V.AllIn1] = ((n = {})[K.AllIn1] = K.AllIn1, n), a[V.AllIn2] = ((r = {})[K.AllIn2] = K.AllIn2, r), a[V.AllIn3] = ((o = {})[K.AllIn3] = K.AllIn3, o), a[V.AllIn4] = ((i = {})[K.AllIn4] = K.AllIn4, i), a[V.AllIn5] = ((s = {})[K.AllIn5] = K.AllIn5, s), a[V.AllIn6] = ((c = {})[K.AllIn6] = K.AllIn6, c), a[V.AllIn7] = ((l = {})[K.AllIn7] = K.AllIn7, l), a[V.Numbers] = ((u = {})[K.OneOutOf7] = K.OneOutOf7, u[K.TwoOutOf7] = K.TwoOutOf7, u[K.ThreeOutOf7] = K.ThreeOutOf7, u[K.FourOutOf7] = K.FourOutOf7, u[K.FiveOutOf7] = K.FiveOutOf7, u[K.SixOutOf7] = K.SixOutOf7, u[K.SevenOutOf7] = K.SevenOutOf7, u), a[V.NoDraw1] = ((d = {})[K.NoDraw1] = K.NoDraw1, d), a[V.NoDraw2] = ((p = {})[K.NoDraw2] = K.NoDraw2, p), a[V.NoDraw3] = ((h = {})[K.NoDraw3] = K.NoDraw3, h), a[V.NoDraw4] = ((f = {})[K.NoDraw4] = K.NoDraw4, f), a[V.NoDraw5] = ((y = {})[K.NoDraw5] = K.NoDraw5, y), a[V.NoDraw6] = ((m = {})[K.NoDraw6] = K.NoDraw6, m), a[V.NoDraw7] = ((w = {})[K.NoDraw7] = K.NoDraw7, w), a[V.FirstBallColor] = ((v = {})[K.FirstBallWhite] = K.FirstBallWhite, v[K.FirstBallRed] = K.FirstBallRed, v), a[V.LastBallColor] = ((x = {})[K.LastBallWhite] = K.LastBallWhite, x[K.LastBallRed] = K.LastBallRed, x), a[V.FirstAndSecondBallColor] = ((T = {})[K.FirstAndSecondSameColor] = K.FirstAndSecondSameColor, T[K.FirstAndSecondDifferentColor] = K.FirstAndSecondDifferentColor, T), a[V.WhiteBalls] = ((O = {})[K.SevenWhiteBalls] = K.SevenWhiteBalls, O[K.SixWhiteBalls] = K.SixWhiteBalls, O[K.FiveWhiteBalls] = K.FiveWhiteBalls, O[K.FourWhiteBalls] = K.FourWhiteBalls, O[K.ThreeWhiteBalls] = K.ThreeWhiteBalls, O[K.TwoWhiteBalls] = K.TwoWhiteBalls, O[K.OneWhiteBalls] = K.OneWhiteBalls, O), a[V.RedBalls] = ((S = {})[K.SevenRedBalls] = K.SevenRedBalls, S[K.SixRedBalls] = K.SixRedBalls, S[K.FiveRedBalls] = K.FiveRedBalls, S[K.FourRedBalls] = K.FourRedBalls, S[K.ThreeRedBalls] = K.ThreeRedBalls, S[K.TwoRedBalls] = K.TwoRedBalls, S[K.OneRedBalls] = K.OneRedBalls, S), a[V.SumUnder100] = ((b = {})[K.SumUnder100] = K.SumUnder100, b), a[V.SumUnderOver125] = ((P = {})[K.SumUnder125] = K.SumUnder125, P[K.SumOver125] = K.SumOver125, P), a[V.SumUnderOver150] = ((H = {})[K.SumUnder150] = K.SumUnder150, H[K.SumOver150] = K.SumOver150, H), a[V.SumUnderOver175] = ((A = {})[K.SumUnder175] = K.SumUnder175, A[K.SumOver175] = K.SumOver175, A), a[V.SumOver200] = ((E = {})[K.SumOver200] = K.SumOver200, E), a[V.SumWhiteUnderOver73] = ((g = {})[K.SumWhiteUnder73] = K.SumWhiteUnder73, g[K.SumWhiteOver73] = K.SumWhiteOver73, g), a[V.SumRedUnderOver73] = ((k = {})[K.SumRedUnder73] = K.SumRedUnder73, k[K.SumRedOver73] = K.SumRedOver73, k), a[V.CountWhiteUnderOver3] = ((q = {})[K.CountWhiteUnder3] = K.CountWhiteUnder3, q[K.CountWhiteOver3] = K.CountWhiteOver3, q), a[V.CountWhiteUnderOver2] = ((M = {})[K.CountWhiteUnder2] = K.CountWhiteUnder2, M[K.CountWhiteOver2] = K.CountWhiteOver2, M), a[V.CountWhiteUnderOver1] = ((C = {})[K.CountWhiteUnder1] = K.CountWhiteUnder1, C[K.CountWhiteOver1] = K.CountWhiteOver1, C), a[V.CountRedUnderOver3] = ((B = {})[K.CountRedUnder3] = K.CountRedUnder3, B[K.CountRedOver3] = K.CountRedOver3, B), a[V.CountRedUnderOver2] = ((D = {})[K.CountRedUnder2] = K.CountRedUnder2, D[K.CountRedOver2] = K.CountRedOver2, D), a[V.CountRedUnderOver1] = ((G = {})[K.CountRedUnder1] = K.CountRedUnder1, G[K.CountRedOver1] = K.CountRedOver1, G), a[V.OddEven] = ((R = {})[K.MoreOdd] = K.MoreOdd, R[K.MoreEven] = K.MoreEven, R), a[V.SumOddEven] = ((j = {})[K.SumOdd] = K.SumOdd, j[K.SumEven] = K.SumEven, j), a[V.FirstBallOddEven] = ((I = {})[K.FirstBallOdd] = K.FirstBallOdd, I[K.FirstBallEven] = K.FirstBallEven, I), a[V.LastBallOddEven] = ((L = {})[K.LastBallOdd] = K.LastBallOdd, L[K.LastBallEven] = K.LastBallEven, L), a[V.FirstTwoBallsOddEven] = ((F = {})[K.FirstTwoBallsOdd] = K.FirstTwoBallsOdd, F[K.FirstTwoBallsEven] = K.FirstTwoBallsEven, F), a[V.FirstAndSecondBallOddEven] = ((U = {})[K.FirstOddAndSecondEven] = K.FirstOddAndSecondEven, U[K.FirstEvenAndSecondOdd] = K.FirstEvenAndSecondOdd, U), a[V.FirstAndLastBallOddEven] = ((N = {})[K.FirstOddAndLastEven] = K.FirstOddAndLastEven, N[K.FirstEvenAndLastOdd] = K.FirstEvenAndLastOdd, N), a), t.S7OddsTemplate = ((W = {})[K.AllIn1] = V.AllIn1, W[K.AllIn2] = V.AllIn2, W[K.AllIn3] = V.AllIn3, W[K.AllIn4] = V.AllIn4, W[K.AllIn5] = V.AllIn5, W[K.AllIn6] = V.AllIn6, W[K.AllIn7] = V.AllIn7, W[K.OneOutOf7] = V.Numbers, W[K.TwoOutOf7] = V.Numbers, W[K.ThreeOutOf7] = V.Numbers, W[K.FourOutOf7] = V.Numbers, W[K.FiveOutOf7] = V.Numbers, W[K.SixOutOf7] = V.Numbers, W[K.SevenOutOf7] = V.Numbers, W[K.NoDraw1] = V.NoDraw1, W[K.NoDraw2] = V.NoDraw2, W[K.NoDraw3] = V.NoDraw3, W[K.NoDraw4] = V.NoDraw4, W[K.NoDraw5] = V.NoDraw5, W[K.NoDraw6] = V.NoDraw6, W[K.NoDraw7] = V.NoDraw7, W[K.FirstBallWhite] = V.FirstBallColor, W[K.FirstBallRed] = V.FirstBallColor, W[K.LastBallWhite] = V.LastBallColor, W[K.LastBallRed] = V.LastBallColor, W[K.FirstAndSecondSameColor] = V.FirstAndSecondBallColor, W[K.FirstAndSecondDifferentColor] = V.FirstAndSecondBallColor, W[K.SevenWhiteBalls] = V.WhiteBalls, W[K.SixWhiteBalls] = V.WhiteBalls, W[K.FiveWhiteBalls] = V.WhiteBalls, W[K.FourWhiteBalls] = V.WhiteBalls, W[K.ThreeWhiteBalls] = V.WhiteBalls, W[K.TwoWhiteBalls] = V.WhiteBalls, W[K.OneWhiteBalls] = V.WhiteBalls, W[K.SevenRedBalls] = V.RedBalls, W[K.SixRedBalls] = V.RedBalls, W[K.FiveRedBalls] = V.RedBalls, W[K.FourRedBalls] = V.RedBalls, W[K.ThreeRedBalls] = V.RedBalls, W[K.TwoRedBalls] = V.RedBalls, W[K.OneRedBalls] = V.RedBalls, W[K.SumUnder100] = V.SumUnder100, W[K.SumUnder125] = V.SumUnderOver125, W[K.SumOver125] = V.SumUnderOver125, W[K.SumUnder150] = V.SumUnderOver150, W[K.SumOver150] = V.SumUnderOver150, W[K.SumUnder175] = V.SumUnderOver175, W[K.SumOver175] = V.SumUnderOver175, W[K.SumOver200] = V.SumOver200, W[K.SumWhiteUnder73] = V.SumWhiteUnderOver73, W[K.SumWhiteOver73] = V.SumWhiteUnderOver73, W[K.SumRedUnder73] = V.SumRedUnderOver73, W[K.SumRedOver73] = V.SumRedUnderOver73, W[K.CountWhiteUnder3] = V.CountWhiteUnderOver3, W[K.CountWhiteOver3] = V.CountWhiteUnderOver3, W[K.CountWhiteUnder2] = V.CountWhiteUnderOver2, W[K.CountWhiteOver2] = V.CountWhiteUnderOver2, W[K.CountWhiteUnder1] = V.CountWhiteUnderOver1, W[K.CountWhiteOver1] = V.CountWhiteUnderOver1, W[K.CountRedUnder3] = V.CountRedUnderOver3, W[K.CountRedOver3] = V.CountRedUnderOver3, W[K.CountRedUnder2] = V.CountRedUnderOver2, W[K.CountRedOver2] = V.CountRedUnderOver2, W[K.CountRedUnder1] = V.CountRedUnderOver1, W[K.CountRedOver1] = V.CountRedUnderOver1, W[K.MoreOdd] = V.OddEven, W[K.MoreEven] = V.OddEven, W[K.SumOdd] = V.SumOddEven, W[K.SumEven] = V.SumOddEven, W[K.FirstBallOdd] = V.FirstBallOddEven, W[K.FirstBallEven] = V.FirstBallOddEven, W[K.LastBallOdd] = V.LastBallOddEven, W[K.LastBallEven] = V.LastBallOddEven, W[K.FirstTwoBallsOdd] = V.FirstTwoBallsOddEven, W[K.FirstTwoBallsEven] = V.FirstTwoBallsOddEven, W[K.FirstOddAndSecondEven] = V.FirstAndSecondBallOddEven, W[K.FirstEvenAndSecondOdd] = V.FirstAndSecondBallOddEven, W[K.FirstOddAndLastEven] = V.FirstAndLastBallOddEven, W[K.FirstEvenAndLastOdd] = V.FirstAndLastBallOddEven, W)
        },
        "4jhI": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "LocalizationContext", _.currencies = [], _.tags = [], t && (_.language = t.language, _.skin = t.skin, _.timezone = t.timezone, _.utcOffset = t.utcOffset, t.currencies && t.currencies.forEach((function(e) {
                            _.currencies.push(new r.LocalizationCurrencySettings(e))
                        })), _.defaultCurrency = t.defaultCurrency ? new r.Currency(t.defaultCurrency) : null, t.tags && t.tags.forEach((function(e) {
                            _.tags.push(e)
                        }))), _
                    }
                    return n(t, e), t
                }(_("eSR3").Context);
            t.LocalizationContext = o
        },
        "4kNH": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "GameContext", _.displays = [], t && t.displays && t.displays.forEach((function(e) {
                            _.displays.push(new r.Display(e))
                        })), _
                    }
                    return n(t, e), t
                }(_("eSR3").Context);
            t.GameContext = o
        },
        "4plE": function(e, t, _) {
            "use strict";
            var a, n, r, o, i, s, c, l, u, d, p, h, f, y;
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e) {
                    e.win = "win", e.exacta = "exacta", e.trifecta = "trifecta", e.place = "place", e.show = "show", e.quinella = "quinella", e.even_odd = "even_odd", e.over_under = "over_under", e.system_two = "system_two", e.system_three = "system_three"
                }(f = t.KartMarkets || (t.KartMarkets = {})),
                function(e) {
                    e.win_1 = "win_1", e.win_2 = "win_2", e.win_3 = "win_3", e.win_4 = "win_4", e.win_5 = "win_5", e.win_6 = "win_6", e.win_7 = "win_7", e.win_8 = "win_8", e.exacta_1_2 = "exacta_1_2", e.exacta_1_3 = "exacta_1_3", e.exacta_1_4 = "exacta_1_4", e.exacta_1_5 = "exacta_1_5", e.exacta_1_6 = "exacta_1_6", e.exacta_1_7 = "exacta_1_7", e.exacta_1_8 = "exacta_1_8", e.exacta_2_1 = "exacta_2_1", e.exacta_2_3 = "exacta_2_3", e.exacta_2_4 = "exacta_2_4", e.exacta_2_5 = "exacta_2_5", e.exacta_2_6 = "exacta_2_6", e.exacta_2_7 = "exacta_2_7", e.exacta_2_8 = "exacta_2_8", e.exacta_3_1 = "exacta_3_1", e.exacta_3_2 = "exacta_3_2", e.exacta_3_4 = "exacta_3_4", e.exacta_3_5 = "exacta_3_5", e.exacta_3_6 = "exacta_3_6", e.exacta_3_7 = "exacta_3_7", e.exacta_3_8 = "exacta_3_8", e.exacta_4_1 = "exacta_4_1", e.exacta_4_2 = "exacta_4_2", e.exacta_4_3 = "exacta_4_3", e.exacta_4_5 = "exacta_4_5", e.exacta_4_6 = "exacta_4_6", e.exacta_4_7 = "exacta_4_7", e.exacta_4_8 = "exacta_4_8", e.exacta_5_1 = "exacta_5_1", e.exacta_5_2 = "exacta_5_2", e.exacta_5_3 = "exacta_5_3", e.exacta_5_4 = "exacta_5_4", e.exacta_5_6 = "exacta_5_6", e.exacta_5_7 = "exacta_5_7", e.exacta_5_8 = "exacta_5_8", e.exacta_6_1 = "exacta_6_1", e.exacta_6_2 = "exacta_6_2", e.exacta_6_3 = "exacta_6_3", e.exacta_6_4 = "exacta_6_4", e.exacta_6_5 = "exacta_6_5", e.exacta_6_7 = "exacta_6_7", e.exacta_6_8 = "exacta_6_8", e.exacta_7_1 = "exacta_7_1", e.exacta_7_2 = "exacta_7_2", e.exacta_7_3 = "exacta_7_3", e.exacta_7_4 = "exacta_7_4", e.exacta_7_5 = "exacta_7_5", e.exacta_7_6 = "exacta_7_6", e.exacta_7_8 = "exacta_7_8", e.exacta_8_1 = "exacta_8_1", e.exacta_8_2 = "exacta_8_2", e.exacta_8_3 = "exacta_8_3", e.exacta_8_4 = "exacta_8_4", e.exacta_8_5 = "exacta_8_5", e.exacta_8_6 = "exacta_8_6", e.exacta_8_7 = "exacta_8_7", e.trifecta = "trifecta", e.place_1 = "place_1", e.place_2 = "place_2", e.place_3 = "place_3", e.place_4 = "place_4", e.place_5 = "place_5", e.place_6 = "place_6", e.place_7 = "place_7", e.place_8 = "place_8", e.show_1 = "show_1", e.show_2 = "show_2", e.show_3 = "show_3", e.show_4 = "show_4", e.show_5 = "show_5", e.show_6 = "show_6", e.show_7 = "show_7", e.show_8 = "show_8", e.quinella_1_2 = "quinella_1_2", e.quinella_1_3 = "quinella_1_3", e.quinella_1_4 = "quinella_1_4", e.quinella_1_5 = "quinella_1_5", e.quinella_1_6 = "quinella_1_6", e.quinella_1_7 = "quinella_1_7", e.quinella_1_8 = "quinella_1_8", e.quinella_2_3 = "quinella_2_3", e.quinella_2_4 = "quinella_2_4", e.quinella_2_5 = "quinella_2_5", e.quinella_2_6 = "quinella_2_6", e.quinella_2_7 = "quinella_2_7", e.quinella_2_8 = "quinella_2_8", e.quinella_3_4 = "quinella_3_4", e.quinella_3_5 = "quinella_3_5", e.quinella_3_6 = "quinella_3_6", e.quinella_3_7 = "quinella_3_7", e.quinella_3_8 = "quinella_3_8", e.quinella_4_5 = "quinella_4_5", e.quinella_4_6 = "quinella_4_6", e.quinella_4_7 = "quinella_4_7", e.quinella_4_8 = "quinella_4_8", e.quinella_5_6 = "quinella_5_6", e.quinella_5_7 = "quinella_5_7", e.quinella_5_8 = "quinella_5_8", e.quinella_6_7 = "quinella_6_7", e.quinella_6_8 = "quinella_6_8", e.quinella_7_8 = "quinella_7_8", e.even = "even", e.odd = "odd", e.over = "over", e.under = "under", e.system_two = "system_two", e.system_three = "system_three"
                }(y = t.KartOdds || (t.KartOdds = {})), t.KartMarketsTemplate = ((a = {})[f.win] = ((n = {})[y.win_1] = y.win_1, n[y.win_2] = y.win_2, n[y.win_3] = y.win_3, n[y.win_4] = y.win_4, n[y.win_5] = y.win_5, n[y.win_6] = y.win_6, n[y.win_7] = y.win_7, n[y.win_8] = y.win_8, n), a[f.exacta] = ((r = {})[y.exacta_1_2] = y.exacta_1_2, r[y.exacta_1_3] = y.exacta_1_3, r[y.exacta_1_4] = y.exacta_1_4, r[y.exacta_1_5] = y.exacta_1_5, r[y.exacta_1_6] = y.exacta_1_6, r[y.exacta_1_7] = y.exacta_1_7, r[y.exacta_1_8] = y.exacta_1_8, r[y.exacta_2_1] = y.exacta_2_1, r[y.exacta_2_3] = y.exacta_2_3, r[y.exacta_2_4] = y.exacta_2_4, r[y.exacta_2_5] = y.exacta_2_5, r[y.exacta_2_6] = y.exacta_2_6, r[y.exacta_2_7] = y.exacta_2_7, r[y.exacta_2_8] = y.exacta_2_8, r[y.exacta_3_1] = y.exacta_3_1, r[y.exacta_3_2] = y.exacta_3_2, r[y.exacta_3_4] = y.exacta_3_4, r[y.exacta_3_5] = y.exacta_3_5, r[y.exacta_3_6] = y.exacta_3_6, r[y.exacta_3_7] = y.exacta_3_7, r[y.exacta_3_8] = y.exacta_3_8, r[y.exacta_4_1] = y.exacta_4_1, r[y.exacta_4_2] = y.exacta_4_2, r[y.exacta_4_3] = y.exacta_4_3, r[y.exacta_4_5] = y.exacta_4_5, r[y.exacta_4_6] = y.exacta_4_6, r[y.exacta_4_7] = y.exacta_4_7, r[y.exacta_4_8] = y.exacta_4_8, r[y.exacta_5_1] = y.exacta_5_1, r[y.exacta_5_2] = y.exacta_5_2, r[y.exacta_5_3] = y.exacta_5_3, r[y.exacta_5_4] = y.exacta_5_4, r[y.exacta_5_6] = y.exacta_5_6, r[y.exacta_5_7] = y.exacta_5_7, r[y.exacta_5_8] = y.exacta_5_8, r[y.exacta_6_1] = y.exacta_6_1, r[y.exacta_6_2] = y.exacta_6_2, r[y.exacta_6_3] = y.exacta_6_3, r[y.exacta_6_4] = y.exacta_6_4, r[y.exacta_6_5] = y.exacta_6_5, r[y.exacta_6_7] = y.exacta_6_7, r[y.exacta_6_8] = y.exacta_6_8, r[y.exacta_7_1] = y.exacta_7_1, r[y.exacta_7_2] = y.exacta_7_2, r[y.exacta_7_3] = y.exacta_7_3, r[y.exacta_7_4] = y.exacta_7_4, r[y.exacta_7_5] = y.exacta_7_5, r[y.exacta_7_6] = y.exacta_7_6, r[y.exacta_7_8] = y.exacta_7_8, r[y.exacta_8_1] = y.exacta_8_1, r[y.exacta_8_2] = y.exacta_8_2, r[y.exacta_8_3] = y.exacta_8_3, r[y.exacta_8_4] = y.exacta_8_4, r[y.exacta_8_5] = y.exacta_8_5, r[y.exacta_8_6] = y.exacta_8_6, r[y.exacta_8_7] = y.exacta_8_7, r), a[f.trifecta] = ((o = {})[y.trifecta] = y.trifecta, o), a[f.place] = ((i = {})[y.place_1] = y.place_1, i[y.place_2] = y.place_2, i[y.place_3] = y.place_3, i[y.place_4] = y.place_4, i[y.place_5] = y.place_5, i[y.place_6] = y.place_6, i[y.place_7] = y.place_7, i[y.place_8] = y.place_8, i), a[f.show] = ((s = {})[y.show_1] = y.show_1, s[y.show_2] = y.show_2, s[y.show_3] = y.show_3, s[y.show_4] = y.show_4, s[y.show_5] = y.show_5, s[y.show_6] = y.show_6, s[y.show_7] = y.show_7, s[y.show_8] = y.show_8, s), a[f.quinella] = ((c = {})[y.quinella_1_2] = y.quinella_1_2, c[y.quinella_1_3] = y.quinella_1_3, c[y.quinella_1_4] = y.quinella_1_4, c[y.quinella_1_5] = y.quinella_1_5, c[y.quinella_1_6] = y.quinella_1_6, c[y.quinella_1_7] = y.quinella_1_7, c[y.quinella_1_8] = y.quinella_1_8, c[y.quinella_2_3] = y.quinella_2_3, c[y.quinella_2_4] = y.quinella_2_4, c[y.quinella_2_5] = y.quinella_2_5, c[y.quinella_2_6] = y.quinella_2_6, c[y.quinella_2_7] = y.quinella_2_7, c[y.quinella_2_8] = y.quinella_2_8, c[y.quinella_3_4] = y.quinella_3_4, c[y.quinella_3_5] = y.quinella_3_5, c[y.quinella_3_6] = y.quinella_3_6, c[y.quinella_3_7] = y.quinella_3_7, c[y.quinella_3_8] = y.quinella_3_8, c[y.quinella_4_5] = y.quinella_4_5, c[y.quinella_4_6] = y.quinella_4_6, c[y.quinella_4_7] = y.quinella_4_7, c[y.quinella_4_8] = y.quinella_4_8, c[y.quinella_5_6] = y.quinella_5_6, c[y.quinella_5_7] = y.quinella_5_7, c[y.quinella_5_8] = y.quinella_5_8, c[y.quinella_6_7] = y.quinella_6_7, c[y.quinella_6_8] = y.quinella_6_8, c[y.quinella_7_8] = y.quinella_7_8, c), a[f.even_odd] = ((l = {})[y.even] = y.even, l[y.odd] = y.odd, l), a[f.over_under] = ((u = {})[y.over] = y.over, u[y.under] = y.under, u), a[f.system_two] = ((d = {})[y.system_two] = y.system_two, d), a[f.system_three] = ((p = {})[y.system_three] = y.system_three, p), a), t.KartOddsTemplate = ((h = {})[y.win_1] = f.win, h[y.win_2] = f.win, h[y.win_3] = f.win, h[y.win_4] = f.win, h[y.win_5] = f.win, h[y.win_6] = f.win, h[y.win_7] = f.win, h[y.win_8] = f.win, h[y.exacta_1_2] = f.exacta, h[y.exacta_1_3] = f.exacta, h[y.exacta_1_4] = f.exacta, h[y.exacta_1_5] = f.exacta, h[y.exacta_1_6] = f.exacta, h[y.exacta_1_7] = f.exacta, h[y.exacta_1_8] = f.exacta, h[y.exacta_2_1] = f.exacta, h[y.exacta_2_3] = f.exacta, h[y.exacta_2_4] = f.exacta, h[y.exacta_2_5] = f.exacta, h[y.exacta_2_6] = f.exacta, h[y.exacta_2_7] = f.exacta, h[y.exacta_2_8] = f.exacta, h[y.exacta_3_1] = f.exacta, h[y.exacta_3_2] = f.exacta, h[y.exacta_3_4] = f.exacta, h[y.exacta_3_5] = f.exacta, h[y.exacta_3_6] = f.exacta, h[y.exacta_3_7] = f.exacta, h[y.exacta_3_8] = f.exacta, h[y.exacta_4_1] = f.exacta, h[y.exacta_4_2] = f.exacta, h[y.exacta_4_3] = f.exacta, h[y.exacta_4_5] = f.exacta, h[y.exacta_4_6] = f.exacta, h[y.exacta_4_7] = f.exacta, h[y.exacta_4_8] = f.exacta, h[y.exacta_5_1] = f.exacta, h[y.exacta_5_2] = f.exacta, h[y.exacta_5_3] = f.exacta, h[y.exacta_5_4] = f.exacta, h[y.exacta_5_6] = f.exacta, h[y.exacta_5_7] = f.exacta, h[y.exacta_5_8] = f.exacta, h[y.exacta_6_1] = f.exacta, h[y.exacta_6_2] = f.exacta, h[y.exacta_6_3] = f.exacta, h[y.exacta_6_4] = f.exacta, h[y.exacta_6_5] = f.exacta, h[y.exacta_6_7] = f.exacta, h[y.exacta_6_8] = f.exacta, h[y.exacta_7_1] = f.exacta, h[y.exacta_7_2] = f.exacta, h[y.exacta_7_3] = f.exacta, h[y.exacta_7_4] = f.exacta, h[y.exacta_7_5] = f.exacta, h[y.exacta_7_6] = f.exacta, h[y.exacta_7_8] = f.exacta, h[y.exacta_8_1] = f.exacta, h[y.exacta_8_2] = f.exacta, h[y.exacta_8_3] = f.exacta, h[y.exacta_8_4] = f.exacta, h[y.exacta_8_5] = f.exacta, h[y.exacta_8_6] = f.exacta, h[y.exacta_8_7] = f.exacta, h[y.trifecta] = f.trifecta, h[y.place_1] = f.place, h[y.place_2] = f.place, h[y.place_3] = f.place, h[y.place_4] = f.place, h[y.place_5] = f.place, h[y.place_6] = f.place, h[y.place_7] = f.place, h[y.place_8] = f.place, h[y.show_1] = f.show, h[y.show_2] = f.show, h[y.show_3] = f.show, h[y.show_4] = f.show, h[y.show_5] = f.show, h[y.show_6] = f.show, h[y.show_7] = f.show, h[y.show_8] = f.show, h[y.quinella_1_2] = f.quinella, h[y.quinella_1_3] = f.quinella, h[y.quinella_1_4] = f.quinella, h[y.quinella_1_5] = f.quinella, h[y.quinella_1_6] = f.quinella, h[y.quinella_1_7] = f.quinella, h[y.quinella_1_8] = f.quinella, h[y.quinella_2_3] = f.quinella, h[y.quinella_2_4] = f.quinella, h[y.quinella_2_5] = f.quinella, h[y.quinella_2_6] = f.quinella, h[y.quinella_2_7] = f.quinella, h[y.quinella_2_8] = f.quinella, h[y.quinella_3_4] = f.quinella, h[y.quinella_3_5] = f.quinella, h[y.quinella_3_6] = f.quinella, h[y.quinella_3_7] = f.quinella, h[y.quinella_3_8] = f.quinella, h[y.quinella_4_5] = f.quinella, h[y.quinella_4_6] = f.quinella, h[y.quinella_4_7] = f.quinella, h[y.quinella_4_8] = f.quinella, h[y.quinella_5_6] = f.quinella, h[y.quinella_5_7] = f.quinella, h[y.quinella_5_8] = f.quinella, h[y.quinella_6_7] = f.quinella, h[y.quinella_6_8] = f.quinella, h[y.quinella_7_8] = f.quinella, h[y.even] = f.even_odd, h[y.odd] = f.even_odd, h[y.over] = f.over_under, h[y.under] = f.over_under, h[y.system_two] = f.system_two, h[y.system_three] = f.system_three, h)
        },
        "55+H": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "BasketGameOddSettings", _
                }
                return n(t, e), t
            }(_("aDCO").GameFixedOddSettings);
            t.BasketGameOddSettings = r
        },
        "55WR": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "LogispinProfilesContext", t && (_.print = t.print ? new r.LogispinPrintProfileSettings(t.print) : null), _
                    }
                    return n(t, e), t
                }(_("eSR3").Context);
            t.LogispinProfilesContext = o
        },
        "5EKT": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.players = [], e && (this.total = e.total, e.players && e.players.forEach((function(e) {
                        t.players.push(new a.BasketPlayerScore(e))
                    })))
                };
            t.BasketTeamScore = n
        },
        "5f68": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "RotatingPlaylistContent", _.contents = [], t && t.contents && t.contents.forEach((function(e) {
                            _.contents.push(new r.PlaylistItemContent(e))
                        })), _
                    }
                    return n(t, e), t
                }(_("RKrn").Content);
            t.RotatingPlaylistContent = o
        },
        "5qDJ": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "DirttrackParticipant", t && (_.speed = t.speed, _.stamina = t.stamina, _.wins = t.wins), _
                }
                return n(t, e), t
            }(_("xeXX").RaceParticipant);
            t.DirttrackParticipant = r
        },
        "5sQN": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "SpeedwayAssets", _
                }
                return n(t, e), t
            }(_("vW0J").RacesAssets);
            t.SpeedwayAssets = r
        },
        "5uTo": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "LlEventResultData", _.result = [], t && t.result && t.result.forEach((function(e) {
                        _.result.push(e)
                    })), _
                }
                return n(t, e), t
            }(_("RUMs").EventResultData);
            t.LlEventResultData = r
        },
        "5vCD": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "FightGameEventData", _.victoryProb = [], t && t.victoryProb && t.victoryProb.forEach((function(e) {
                        _.victoryProb.push(e)
                    })), _
                }
                return n(t, e), t
            }(_("VqjV").GameEventData);
            t.FightGameEventData = r
        },
        "633v": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "LottofiveTicketEventData", _.drawResult = [], _.drawMachine = [], t && (_.name = t.name, t.drawResult && t.drawResult.forEach((function(e) {
                        _.drawResult.push(e)
                    })), t.drawMachine && t.drawMachine.forEach((function(e) {
                        _.drawMachine.push(e)
                    })), _.resultVideoURL = t.resultVideoURL), _
                }
                return n(t, e), t
            }(_("Dhrw").TicketEventData);
            t.LottofiveTicketEventData = r
        },
        "6Vd1": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.entityMessages = [], e && (e.serverTimeStamp ? this.serverTimeStamp = new Date(e.serverTimeStamp.toString()) : this.serverTimeStamp = null, this.entityId = e.entityId, this.entityPath = e.entityPath, e.entityMessages && e.entityMessages.forEach((function(e) {
                        t.entityMessages.push(new a.EntityMessage(e))
                    })), this.sessionStatus = e.sessionStatus ? new a.SessionStatus(e.sessionStatus) : null)
                };
            t.SyncData = n
        },
        "6f63": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.showTurnover = e.showTurnover, this.showTurnoverStaffName = e.showTurnoverStaffName, this.showOpenTickets = e.showOpenTickets, this.showTickets = e.showTickets, this.showCredit = e.showCredit, this.showResults = e.showResults, this.showReleaseNotes = e.showReleaseNotes, this.hideTicketId = e.hideTicketId, this.canCancel = e.canCancel)
            };
            t.ShopadminProfileSettings = a
        },
        "6pIh": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                var t = this;
                this.value = [], e && (this.key = e.key, e.value && e.value.forEach((function(e) {
                    t.value.push(e)
                })), this.symbol = e.symbol, this.decimals = e.decimals, this.step = e.step)
            };
            t.LocalizationCurrencySettings = a
        },
        "6xfI": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "ChViewerProfileGameSettings", t && (_.ingameLivescoreMode = t.ingameLivescoreMode, _.emblemType = t.emblemType, _.teamNameTextType = t.teamNameTextType), _
                }
                return n(t, e), t
            }(_("PBHJ").ViewerProfileGameSettings);
            t.ChViewerProfileGameSettings = r,
                function(e) {
                    ! function(e) {
                        e.DOWN = "DOWN", e.RIGHT = "RIGHT", e.FULLSCREEN = "FULLSCREEN"
                    }(e.IngameLivescoreModeEnum || (e.IngameLivescoreModeEnum = {}))
                }(r = t.ChViewerProfileGameSettings || (t.ChViewerProfileGameSettings = {})), t.ChViewerProfileGameSettings = r,
                function(e) {
                    ! function(e) {
                        e.NONE = "NONE", e.BADGE = "BADGE"
                    }(e.EmblemTypeEnum || (e.EmblemTypeEnum = {}))
                }(r = t.ChViewerProfileGameSettings || (t.ChViewerProfileGameSettings = {})), t.ChViewerProfileGameSettings = r,
                function(e) {
                    ! function(e) {
                        e._3LETTERS = "_3LETTERS", e.FULLTEAMNAME = "FULLTEAMNAME"
                    }(e.TeamNameTextTypeEnum || (e.TeamNameTextTypeEnum = {}))
                }(r = t.ChViewerProfileGameSettings || (t.ChViewerProfileGameSettings = {})), t.ChViewerProfileGameSettings = r
        },
        "71nI": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "LottofiveEventBlockStats", _.draws = {}, t && (t.draws && Object.keys(t.draws).forEach((function(e) {
                            _.draws[e] = new r.LottofiveEventBlockStatsData(t.draws[e])
                        })), _.record = t.record ? new r.Record(t.record) : null), _
                    }
                    return n(t, e), t
                }(_("HZPa").EventBlockStats);
            t.LottofiveEventBlockStats = o
        },
        "7D+D": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "SpeedwayFilter", _
                }
                return n(t, e), t
            }(_("4Lmp").RacesFilter);
            t.SpeedwayFilter = r
        },
        "7Lqh": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    e && (this.key = e.key, this.taxPolicy = e.taxPolicy ? new a.TaxPolicy(e.taxPolicy) : null)
                };
            t.TaxCurrency = n
        },
        "7O4k": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.betId = e.betId, this.oddValue = e.oddValue)
            };
            t.Bet = a
        },
        "7dea": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    e && (this.amount = e.amount, e.date ? this.date = new Date(e.date.toString()) : this.date = null, this.ticketId = e.ticketId, this.entity = e.entity ? new a.Entity(e.entity) : null)
                };
            t.JackpotTicket = n
        },
        "7fgt": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function() {
                    function e(e, t) {
                        if (void 0 === t && (t = !0), e && (this.classType = e.classType, this.displayId = e.displayId, this.enabled = e.enabled, this.priority = e.priority, t && this.classType)) switch (this.classType) {
                            case "SingleDisplay":
                                return new a.SingleDisplay(e);
                            case "MatrixDisplay":
                                return new a.MatrixDisplay(e)
                        }
                    }
                    return e.prototype.isSingleDisplay = function() {
                        return "SingleDisplay" === this.classType
                    }, e.prototype.isMatrixDisplay = function() {
                        return "MatrixDisplay" === this.classType
                    }, e
                }();
            t.Display = n
        },
        "7fw6": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "LottofiveEventStats", _.day = [], t && (t.day && t.day.forEach((function(e) {
                            _.day.push(new r.LottofiveStatsDay(e))
                        })), _.historic = t.historic ? new r.LottofiveStatEver(t.historic) : null), _
                    }
                    return n(t, e), t
                }(_("NbOC").EventStats);
            t.LottofiveEventStats = o
        },
        "7rHc": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "S7Assets", _
                }
                return n(t, e), t
            }(_("8xXt").Assets);
            t.S7Assets = r
        },
        "7u87": function(e, t, _) {
            "use strict";

            function a(e) {
                for (var _ in e) t.hasOwnProperty(_) || (t[_] = e[_])
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), a(_("ZUsh")), a(_("wbEv")), a(_("2mgP")), a(_("X6L1")), a(_("aPIh")), a(_("ej0j")), a(_("4Pbz")), a(_("AuZ2")), a(_("PHIG")), a(_("4plE")), a(_("H1Ir")), a(_("P4SD")), a(_("HslF")), a(_("dMdk")), a(_("bEZe")), a(_("L00D")), a(_("S790"))
        },
        "7we5": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "SnEventBlockStats", _.historic = [], t && t.historic && t.historic.forEach((function(e) {
                        _.historic.push(e)
                    })), _
                }
                return n(t, e), t
            }(_("HZPa").EventBlockStats);
            t.SnEventBlockStats = r
        },
        "8/Xl": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "SxGameOddSettings", t && (_.payTable = t.payTable ? new r.SxPayTable(t.payTable) : null), _
                    }
                    return n(t, e), t
                }(_("ZMgZ").GameOddSettings);
            t.SxGameOddSettings = o
        },
        "8D/f": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "S2WGameEventData", t && (_.presenterImageUrl = t.presenterImageUrl, _.croupierName = t.croupierName), _
                }
                return n(t, e), t
            }(_("VqjV").GameEventData);
            t.S2WGameEventData = r
        },
        "8QgB": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "HorseGameOddSettings", _
                }
                return n(t, e), t
            }(_("aDCO").GameFixedOddSettings);
            t.HorseGameOddSettings = r
        },
        "8QvV": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "FightGameOddSettings", _
                }
                return n(t, e), t
            }(_("aDCO").GameFixedOddSettings);
            t.FightGameOddSettings = r
        },
        "8jdZ": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "HorseEventBlockData", _
                }
                return n(t, e), t
            }(_("AjTw").EventBlockData);
            t.HorseEventBlockData = r
        },
        "8xXt": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function() {
                    function e(e, t) {
                        if (void 0 === t && (t = !0), e && (this.classType = e.classType, this.iconId = e.iconId, this.clientConfiguration = e.clientConfiguration, t && this.classType)) switch (this.classType) {
                            case "S7Assets":
                                return new a.S7Assets(e);
                            case "MotorbikeAssets":
                                return new a.MotorbikeAssets(e);
                            case "LlAssets":
                                return new a.LlAssets(e);
                            case "S2WAssets":
                                return new a.S2WAssets(e);
                            case "KartAssets":
                                return new a.KartAssets(e);
                            case "ChAssets":
                                return new a.ChAssets(e);
                            case "BasketAssets":
                                return new a.BasketAssets(e);
                            case "HorseAssets":
                                return new a.HorseAssets(e);
                            case "FightAssets":
                                return new a.FightAssets(e);
                            case "SxAssets":
                                return new a.SxAssets(e);
                            case "DogAssets":
                                return new a.DogAssets(e);
                            case "RacesAssets":
                                return new a.RacesAssets(e);
                            case "TrottingAssets":
                                return new a.TrottingAssets(e);
                            case "SpeedwayAssets":
                                return new a.SpeedwayAssets(e);
                            case "DirttrackAssets":
                                return new a.DirttrackAssets(e);
                            case "SnAssets":
                                return new a.SnAssets(e);
                            case "KnAssets":
                                return new a.KnAssets(e);
                            case "LottofiveAssets":
                                return new a.LottofiveAssets(e)
                        }
                    }
                    return e.prototype.isS7Assets = function() {
                        return "S7Assets" === this.classType
                    }, e.prototype.isMotorbikeAssets = function() {
                        return "MotorbikeAssets" === this.classType
                    }, e.prototype.isLlAssets = function() {
                        return "LlAssets" === this.classType
                    }, e.prototype.isS2WAssets = function() {
                        return "S2WAssets" === this.classType
                    }, e.prototype.isKartAssets = function() {
                        return "KartAssets" === this.classType
                    }, e.prototype.isChAssets = function() {
                        return "ChAssets" === this.classType
                    }, e.prototype.isBasketAssets = function() {
                        return "BasketAssets" === this.classType
                    }, e.prototype.isHorseAssets = function() {
                        return "HorseAssets" === this.classType
                    }, e.prototype.isFightAssets = function() {
                        return "FightAssets" === this.classType
                    }, e.prototype.isSxAssets = function() {
                        return "SxAssets" === this.classType
                    }, e.prototype.isDogAssets = function() {
                        return "DogAssets" === this.classType
                    }, e.prototype.isRacesAssets = function() {
                        return "RacesAssets" === this.classType
                    }, e.prototype.isTrottingAssets = function() {
                        return "TrottingAssets" === this.classType
                    }, e.prototype.isSpeedwayAssets = function() {
                        return "SpeedwayAssets" === this.classType
                    }, e.prototype.isDirttrackAssets = function() {
                        return "DirttrackAssets" === this.classType
                    }, e.prototype.isSnAssets = function() {
                        return "SnAssets" === this.classType
                    }, e.prototype.isKnAssets = function() {
                        return "KnAssets" === this.classType
                    }, e.prototype.isLottofiveAssets = function() {
                        return "LottofiveAssets" === this.classType
                    }, e
                }();
            t.Assets = n
        },
        "9+/D": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e) {
                    e.ACCOUNT = "ACCOUNT", e.CLIENT = "CLIENT", e.WALLET = "WALLET", e.USER = "USER", e.MANAGER = "MANAGER", e.API = "API", e.JACKPOT = "JACKPOT"
                }(t.EntityType || (t.EntityType = {}))
        },
        "9A4h": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "DogEventBlockData", _
                }
                return n(t, e), t
            }(_("AjTw").EventBlockData);
            t.DogEventBlockData = r
        },
        "9AYr": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "MotorbikeAssets", _
                }
                return n(t, e), t
            }(_("vW0J").RacesAssets);
            t.MotorbikeAssets = r
        },
        "9B1m": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.jackpotId = e.jackpotId, this.targetId = e.targetId, this.jackpotContribution = e.jackpotContribution)
            };
            t.JackpotContribution = a
        },
        "9Tc1": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "SxTicketEventData", t && (_.evResultData = t.evResultData ? new r.SxEventResultData(t.evResultData) : null), _
                    }
                    return n(t, e), t
                }(_("Dhrw").TicketEventData);
            t.SxTicketEventData = o
        },
        "9s30": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "HorseViewerProfileGameSettings", t && (_.trifectaLayout6paticipant = t.trifectaLayout6paticipant, _.preambleLayoutHorse12 = t.preambleLayoutHorse12, _.showCurrency = t.showCurrency), _
                }
                return n(t, e), t
            }(_("PBHJ").ViewerProfileGameSettings);
            t.HorseViewerProfileGameSettings = r,
                function(e) {
                    ! function(e) {
                        e.LEGACY = "LEGACY", e.COMPACT = "COMPACT"
                    }(e.TrifectaLayout6paticipantEnum || (e.TrifectaLayout6paticipantEnum = {}))
                }(r = t.HorseViewerProfileGameSettings || (t.HorseViewerProfileGameSettings = {})), t.HorseViewerProfileGameSettings = r,
                function(e) {
                    ! function(e) {
                        e.LEGACY = "LEGACY", e.COMPACT = "COMPACT"
                    }(e.PreambleLayoutHorse12Enum || (e.PreambleLayoutHorse12Enum = {}))
                }(r = t.HorseViewerProfileGameSettings || (t.HorseViewerProfileGameSettings = {})), t.HorseViewerProfileGameSettings = r
        },
        A071: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.mediaId = e.mediaId, this.mediaSignature = e.mediaSignature, this.mediaExpireTime = e.mediaExpireTime, this.happenings = e.happenings)
            };
            t.FootballVideoSlot = a
        },
        AD6I: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                var t = this;
                this.g = [], this.d = [], this.vh = [], this.gh = [], this.va = [], this.ga = [], e && (e.g && e.g.forEach((function(e) {
                    t.g.push(e)
                })), e.d && e.d.forEach((function(e) {
                    t.d.push(e)
                })), e.vh && e.vh.forEach((function(e) {
                    t.vh.push(e)
                })), e.gh && e.gh.forEach((function(e) {
                    t.gh.push(e)
                })), e.va && e.va.forEach((function(e) {
                    t.va.push(e)
                })), e.ga && e.ga.forEach((function(e) {
                    t.ga.push(e)
                })))
            };
            t.TeamToTeamPerformance = a
        },
        AFIj: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "DirttrackFilter", _
                }
                return n(t, e), t
            }(_("4Lmp").RacesFilter);
            t.DirttrackFilter = r
        },
        AWg6: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "S2WEventBlockData", t && (_.croupierName = t.croupierName, _.videoUrl = t.videoUrl, _.presenterVideoUrl = t.presenterVideoUrl, _.presenterImageUrl = t.presenterImageUrl, _.placeBetsIdentUrl = t.placeBetsIdentUrl, _.betsClosedIdentsUrl = t.betsClosedIdentsUrl, _.gameIdentUrl = t.gameIdentUrl, t.drawDate ? _.drawDate = new Date(t.drawDate.toString()) : _.drawDate = null, t.updateDate ? _.updateDate = new Date(t.updateDate.toString()) : _.updateDate = null), _
                }
                return n(t, e), t
            }(_("AjTw").EventBlockData);
            t.S2WEventBlockData = r
        },
        AYF8: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "PolandTaxPolicy", t && (_.stakeTax = t.stakeTax ? new r.CustomTax(t.stakeTax) : null, _.payoutTax = t.payoutTax ? new r.CustomThresholdTax(t.payoutTax) : null), _
                    }
                    return n(t, e), t
                }(_("PtXo").TaxPolicy);
            t.PolandTaxPolicy = o
        },
        AjTw: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function() {
                    function e(e, t) {
                        if (void 0 === t && (t = !0), e && (this.classType = e.classType, t && this.classType)) switch (this.classType) {
                            case "KartEventBlockData":
                                return new a.KartEventBlockData(e);
                            case "S2WEventBlockData":
                                return new a.S2WEventBlockData(e);
                            case "MotorbikeEventBlockData":
                                return new a.MotorbikeEventBlockData(e);
                            case "S7EventBlockData":
                                return new a.S7EventBlockData(e);
                            case "TrottingEventBlockData":
                                return new a.TrottingEventBlockData(e);
                            case "SpeedwayEventBlockData":
                                return new a.SpeedwayEventBlockData(e);
                            case "DirttrackEventBlockData":
                                return new a.DirttrackEventBlockData(e);
                            case "BasketEventBlockData":
                                return new a.BasketEventBlockData(e);
                            case "LlEventBlockData":
                                return new a.LlEventBlockData(e);
                            case "DogEventBlockData":
                                return new a.DogEventBlockData(e);
                            case "HorseEventBlockData":
                                return new a.HorseEventBlockData(e);
                            case "ChEventBlockData":
                                return new a.ChEventBlockData(e)
                        }
                    }
                    return e.prototype.isKartEventBlockData = function() {
                        return "KartEventBlockData" === this.classType
                    }, e.prototype.isS2WEventBlockData = function() {
                        return "S2WEventBlockData" === this.classType
                    }, e.prototype.isMotorbikeEventBlockData = function() {
                        return "MotorbikeEventBlockData" === this.classType
                    }, e.prototype.isS7EventBlockData = function() {
                        return "S7EventBlockData" === this.classType
                    }, e.prototype.isTrottingEventBlockData = function() {
                        return "TrottingEventBlockData" === this.classType
                    }, e.prototype.isSpeedwayEventBlockData = function() {
                        return "SpeedwayEventBlockData" === this.classType
                    }, e.prototype.isDirttrackEventBlockData = function() {
                        return "DirttrackEventBlockData" === this.classType
                    }, e.prototype.isBasketEventBlockData = function() {
                        return "BasketEventBlockData" === this.classType
                    }, e.prototype.isLlEventBlockData = function() {
                        return "LlEventBlockData" === this.classType
                    }, e.prototype.isDogEventBlockData = function() {
                        return "DogEventBlockData" === this.classType
                    }, e.prototype.isHorseEventBlockData = function() {
                        return "HorseEventBlockData" === this.classType
                    }, e.prototype.isChEventBlockData = function() {
                        return "ChEventBlockData" === this.classType
                    }, e
                }();
            t.EventBlockData = n
        },
        AuZ2: function(e, t, _) {
            "use strict";
            var a, n, r, o, i, s, c, l, u, d, p, h, f, y, m, w, v, x, T, O, S, b, P, H, A, E, g, k, q, M, C, B, D, G, R, j, I, L, F, U, N, W, V, K, J, Q, z, Y, Z, X, $, ee, te, _e, ae, ne, re, oe, ie, se, ce, le, ue, de, pe, he, fe, ye, me, we, ve, xe, Te, Oe, Se, be, Pe, He, Ae, Ee, ge, ke, qe, Me, Ce, Be, De, Ge, Re, je, Ie, Le, Fe, Ue, Ne, We, Ve, Ke, Je, Qe;
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e) {
                    e.Match_Result = "Match_Result", e.Double_Result = "Double_Result", e.Double_Chance = "Double_Chance", e.Correct_Score = "Correct_Score", e.Total_Goals = "Total_Goals", e.GoalGoal_NoGoal = "GoalGoal_NoGoal", e.Over_Under_0_5 = "Over_Under_0_5", e.Over_Under_1_5 = "Over_Under_1_5", e.Over_Under_2_5 = "Over_Under_2_5", e.Over_Under_3_5 = "Over_Under_3_5", e.Over_Under_4_5 = "Over_Under_4_5", e.HomeAwayScores_Over_Under_0_5 = "HomeAwayScores_Over_Under_0_5", e.HomeAwayScores_Over_Under_1_5 = "HomeAwayScores_Over_Under_1_5", e.HomeAwayScores_Over_Under_2_5 = "HomeAwayScores_Over_Under_2_5", e.HomeAwayScores_Over_Under_3_5 = "HomeAwayScores_Over_Under_3_5", e._1x2_Scores_Over_Under_1_5 = "_1x2_Scores_Over_Under_1_5", e._1x2_Scores_Over_Under_2_5 = "_1x2_Scores_Over_Under_2_5", e._1x2_Scores_Over_Under_3_5 = "_1x2_Scores_Over_Under_3_5", e.Qualify = "Qualify", e.Qualify_2 = "Qualify_2", e.Qualify_3 = "Qualify_3", e.Qualify_4 = "Qualify_4", e.Multigoal = "Multigoal", e.First_Half = "First_Half", e.Handicap_0 = "Handicap_0", e.Handicap_Home_0_25 = "Handicap_Home_0_25", e.Handicap_Away_0_25 = "Handicap_Away_0_25", e.Handicap_Home_0_5 = "Handicap_Home_0_5", e.Handicap_Away_0_5 = "Handicap_Away_0_5", e.Handicap_Home_0_75 = "Handicap_Home_0_75", e.Handicap_Away_0_75 = "Handicap_Away_0_75", e.Handicap_Home_1 = "Handicap_Home_1", e.Handicap_Away_1 = "Handicap_Away_1", e.Handicap_Home_1_25 = "Handicap_Home_1_25", e.Handicap_Away_1_25 = "Handicap_Away_1_25", e.Handicap_Home_1_5 = "Handicap_Home_1_5", e.Handicap_Away_1_5 = "Handicap_Away_1_5", e.Handicap_Home_1_75 = "Handicap_Home_1_75", e.Handicap_Away_1_75 = "Handicap_Away_1_75", e.Handicap_Home_2 = "Handicap_Home_2", e.Handicap_Away_2 = "Handicap_Away_2", e.Handicap_Home_2_25 = "Handicap_Home_2_25", e.Handicap_Away_2_25 = "Handicap_Away_2_25", e.Handicap_Home_2_5 = "Handicap_Home_2_5", e.Handicap_Away_2_5 = "Handicap_Away_2_5", e.Handicap_Home_2_75 = "Handicap_Home_2_75", e.Handicap_Away_2_75 = "Handicap_Away_2_75", e.Handicap_Home_3 = "Handicap_Home_3", e.Handicap_Away_3 = "Handicap_Away_3", e.Over_Under_2 = "Over_Under_2", e.Over_Under_3 = "Over_Under_3", e.Over_Under_1_75 = "Over_Under_1_75", e.Over_Under_2_25 = "Over_Under_2_25", e.Over_Under_2_75 = "Over_Under_2_75", e.FullTime_TotalGoals = "FullTime_TotalGoals", e.FullTime_Under_Over_2_5_GoalGoal_NoGoal = "FullTime_Under_Over_2_5_GoalGoal_NoGoal", e.Euro_Handicap_Home_1 = "Euro_Handicap_Home_1", e.Euro_Handicap_Home_2 = "Euro_Handicap_Home_2", e.Euro_Handicap_Away_1 = "Euro_Handicap_Away_1", e.Euro_Handicap_Away_2 = "Euro_Handicap_Away_2", e.HomeMultigoal_1_2 = "HomeMultigoal_1_2", e.AwayMultigoal_1_2 = "AwayMultigoal_1_2", e.Correct_Score_1H = "Correct_Score_1H", e.Correct_Score_HTFT = "Correct_Score_HTFT", e.FullTime_GoalGoalNoGoal = "FullTime_GoalGoalNoGoal", e.HT_Double_Chance = "HT_Double_Chance", e.HT_GoalGoal_NoGoal = "HT_GoalGoal_NoGoal", e.HT_OddEven = "HT_OddEven", e.HT_Over_Under_0_5 = "HT_Over_Under_0_5", e.HT_Over_Under_1_5 = "HT_Over_Under_1_5", e.HT_Total_Goals = "HT_Total_Goals", e.HT_Handicap_0 = "HT_Handicap_0", e.HT_Handicap_Home_0_25 = "HT_Handicap_Home_0_25", e.HT_Handicap_Away_0_25 = "HT_Handicap_Away_0_25", e.HT_Handicap_Home_0_5 = "HT_Handicap_Home_0_5", e.HT_Handicap_Away_0_5 = "HT_Handicap_Away_0_5", e.HT_Handicap_Home_0_75 = "HT_Handicap_Home_0_75", e.HT_Handicap_Away_0_75 = "HT_Handicap_Away_0_75", e.HT_Handicap_Home_1 = "HT_Handicap_Home_1", e.HT_Handicap_Away_1 = "HT_Handicap_Away_1", e.HT_Handicap_Home_1_25 = "HT_Handicap_Home_1_25", e.HT_Handicap_Away_1_25 = "HT_Handicap_Away_1_25", e.HT_Handicap_Home_1_5 = "HT_Handicap_Home_1_5", e.HT_Handicap_Away_1_5 = "HT_Handicap_Away_1_5", e.HT_Handicap_Home_1_75 = "HT_Handicap_Home_1_75", e.HT_Handicap_Away_1_75 = "HT_Handicap_Away_1_75", e.FT_OddEven = "FT_OddEven", e.Home_Total_Goals = "Home_Total_Goals", e.Away_Total_Goals = "Away_Total_Goals", e.Win_To_Nil = "Win_To_Nil", e.Margin_Victory = "Margin_Victory", e.HT_Over_Under_0_75 = "HT_Over_Under_0_75", e.HT_Over_Under_1 = "HT_Over_Under_1", e.HT_Over_Under_1_25 = "HT_Over_Under_1_25", e.HT_Over_Under_1_75 = "HT_Over_Under_1_75", e.HT_Over_Under_2 = "HT_Over_Under_2"
                }(Je = t.ChMarkets || (t.ChMarkets = {})),
                function(e) {
                    e.Home = "Home", e.Away = "Away", e.Draw = "Draw", e.HomeHome = "HomeHome", e.HomeDraw = "HomeDraw", e.HomeAway = "HomeAway", e.DrawHome = "DrawHome", e.DrawDraw = "DrawDraw", e.DrawAway = "DrawAway", e.AwayHome = "AwayHome", e.AwayDraw = "AwayDraw", e.AwayAway = "AwayAway", e.Draw_Away = "Draw_Away", e.Home_Away = "Home_Away", e.Home_Draw = "Home_Draw", e._0_0 = "_0_0", e._1_0 = "_1_0", e._2_0 = "_2_0", e._3_0 = "_3_0", e._4_0 = "_4_0", e._5_0 = "_5_0", e._6_0 = "_6_0", e._0_1 = "_0_1", e._1_1 = "_1_1", e._2_1 = "_2_1", e._3_1 = "_3_1", e._4_1 = "_4_1", e._5_1 = "_5_1", e._0_2 = "_0_2", e._1_2 = "_1_2", e._2_2 = "_2_2", e._3_2 = "_3_2", e._4_2 = "_4_2", e._0_3 = "_0_3", e._1_3 = "_1_3", e._2_3 = "_2_3", e._3_3 = "_3_3", e._0_4 = "_0_4", e._1_4 = "_1_4", e._2_4 = "_2_4", e._0_5 = "_0_5", e._1_5 = "_1_5", e._0_6 = "_0_6", e._0_Goals = "_0_Goals", e._1_Goals = "_1_Goals", e._2_Goals = "_2_Goals", e._3_Goals = "_3_Goals", e._4_Goals = "_4_Goals", e._5_Goals = "_5_Goals", e._6_Goals = "_6_Goals", e.nog = "nog", e.gg = "gg", e.under_0_5 = "under_0_5", e.over_0_5 = "over_0_5", e.under_1_5 = "under_1_5", e.over_1_5 = "over_1_5", e.under_2_5 = "under_2_5", e.over_2_5 = "over_2_5", e.under_3_5 = "under_3_5", e.over_3_5 = "over_3_5", e.under_4_5 = "under_4_5", e.over_4_5 = "over_4_5", e.Home_Scores_Over_0_5 = "Home_Scores_Over_0_5", e.Away_Scores_Over_0_5 = "Away_Scores_Over_0_5", e.Home_Scores_Under_0_5 = "Home_Scores_Under_0_5", e.Away_Scores_Under_0_5 = "Away_Scores_Under_0_5", e.Home_Scores_Over_1_5 = "Home_Scores_Over_1_5", e.Away_Scores_Over_1_5 = "Away_Scores_Over_1_5", e.Home_Scores_Under_1_5 = "Home_Scores_Under_1_5", e.Away_Scores_Under_1_5 = "Away_Scores_Under_1_5", e.Home_Scores_Over_2_5 = "Home_Scores_Over_2_5", e.Away_Scores_Over_2_5 = "Away_Scores_Over_2_5", e.Home_Scores_Under_2_5 = "Home_Scores_Under_2_5", e.Away_Scores_Under_2_5 = "Away_Scores_Under_2_5", e.Home_Scores_Over_3_5 = "Home_Scores_Over_3_5", e.Away_Scores_Over_3_5 = "Away_Scores_Over_3_5", e.Home_Scores_Under_3_5 = "Home_Scores_Under_3_5", e.Away_Scores_Under_3_5 = "Away_Scores_Under_3_5", e._1x2_Home_Scores_Over_1_5 = "_1x2_Home_Scores_Over_1_5", e._1x2_Draw_Scores_Over_1_5 = "_1x2_Draw_Scores_Over_1_5", e._1x2_Away_Scores_Over_1_5 = "_1x2_Away_Scores_Over_1_5", e._1x2_Home_Scores_Under_1_5 = "_1x2_Home_Scores_Under_1_5", e._1x2_Draw_Scores_Under_1_5 = "_1x2_Draw_Scores_Under_1_5", e._1x2_Away_Scores_Under_1_5 = "_1x2_Away_Scores_Under_1_5", e._1x2_Home_Scores_Over_2_5 = "_1x2_Home_Scores_Over_2_5", e._1x2_Draw_Scores_Over_2_5 = "_1x2_Draw_Scores_Over_2_5", e._1x2_Away_Scores_Over_2_5 = "_1x2_Away_Scores_Over_2_5", e._1x2_Home_Scores_Under_2_5 = "_1x2_Home_Scores_Under_2_5", e._1x2_Draw_Scores_Under_2_5 = "_1x2_Draw_Scores_Under_2_5", e._1x2_Away_Scores_Under_2_5 = "_1x2_Away_Scores_Under_2_5", e._1x2_Home_Scores_Over_3_5 = "_1x2_Home_Scores_Over_3_5", e._1x2_Draw_Scores_Over_3_5 = "_1x2_Draw_Scores_Over_3_5", e._1x2_Away_Scores_Over_3_5 = "_1x2_Away_Scores_Over_3_5", e._1x2_Home_Scores_Under_3_5 = "_1x2_Home_Scores_Under_3_5", e._1x2_Draw_Scores_Under_3_5 = "_1x2_Draw_Scores_Under_3_5", e._1x2_Away_Scores_Under_3_5 = "_1x2_Away_Scores_Under_3_5", e.QHome = "QHome", e.QAway = "QAway", e.QHome_2 = "QHome_2", e.QAway_2 = "QAway_2", e.QHome_3 = "QHome_3", e.QAway_3 = "QAway_3", e.QHome_4 = "QHome_4", e.QAway_4 = "QAway_4", e._0_0_Goals = "_0_0_Goals", e._0_1_Goals = "_0_1_Goals", e._0_2_Goals = "_0_2_Goals", e._0_3_Goals = "_0_3_Goals", e._0_4_Goals = "_0_4_Goals", e._0_5_Goals = "_0_5_Goals", e._0_6_Goals = "_0_6_Goals", e._1_1_Goals = "_1_1_Goals", e._1_2_Goals = "_1_2_Goals", e._1_3_Goals = "_1_3_Goals", e._1_4_Goals = "_1_4_Goals", e._1_5_Goals = "_1_5_Goals", e._1_6_Goals = "_1_6_Goals", e._2_2_Goals = "_2_2_Goals", e._2_3_Goals = "_2_3_Goals", e._2_4_Goals = "_2_4_Goals", e._2_5_Goals = "_2_5_Goals", e._2_6_Goals = "_2_6_Goals", e._3_3_Goals = "_3_3_Goals", e._3_4_Goals = "_3_4_Goals", e._3_5_Goals = "_3_5_Goals", e._3_6_Goals = "_3_6_Goals", e._4_4_Goals = "_4_4_Goals", e._4_5_Goals = "_4_5_Goals", e._4_6_Goals = "_4_6_Goals", e._5_5_Goals = "_5_5_Goals", e._5_6_Goals = "_5_6_Goals", e._6_6_Goals = "_6_6_Goals", e._1H_Home = "_1H_Home", e._1H_Draw = "_1H_Draw", e._1H_Away = "_1H_Away", e.Home_0 = "Home_0", e.Away_0 = "Away_0", e.Home_Minus_0_25 = "Home_Minus_0_25", e.Away_Plus_0_25 = "Away_Plus_0_25", e.Home_Plus_0_25 = "Home_Plus_0_25", e.Away_Minus_0_25 = "Away_Minus_0_25", e.Home_Minus_0_5 = "Home_Minus_0_5", e.Away_Plus_0_5 = "Away_Plus_0_5", e.Home_Plus_0_5 = "Home_Plus_0_5", e.Away_Minus_0_5 = "Away_Minus_0_5", e.Home_Minus_0_75 = "Home_Minus_0_75", e.Away_Plus_0_75 = "Away_Plus_0_75", e.Home_Plus_0_75 = "Home_Plus_0_75", e.Away_Minus_0_75 = "Away_Minus_0_75", e.Home_Minus_1 = "Home_Minus_1", e.Away_Plus_1 = "Away_Plus_1", e.Home_Plus_1 = "Home_Plus_1", e.Away_Minus_1 = "Away_Minus_1", e.Home_Minus_1_25 = "Home_Minus_1_25", e.Away_Plus_1_25 = "Away_Plus_1_25", e.Home_Plus_1_25 = "Home_Plus_1_25", e.Away_Minus_1_25 = "Away_Minus_1_25", e.Home_Minus_1_5 = "Home_Minus_1_5", e.Away_Plus_1_5 = "Away_Plus_1_5", e.Home_Plus_1_5 = "Home_Plus_1_5", e.Away_Minus_1_5 = "Away_Minus_1_5", e.Home_Minus_1_75 = "Home_Minus_1_75", e.Away_Plus_1_75 = "Away_Plus_1_75", e.Home_Plus_1_75 = "Home_Plus_1_75", e.Away_Minus_1_75 = "Away_Minus_1_75", e.Home_Minus_2 = "Home_Minus_2", e.Away_Plus_2 = "Away_Plus_2", e.Home_Plus_2 = "Home_Plus_2", e.Away_Minus_2 = "Away_Minus_2", e.Home_Minus_2_25 = "Home_Minus_2_25", e.Away_Plus_2_25 = "Away_Plus_2_25", e.Home_Plus_2_25 = "Home_Plus_2_25", e.Away_Minus_2_25 = "Away_Minus_2_25", e.Home_Minus_2_5 = "Home_Minus_2_5", e.Away_Plus_2_5 = "Away_Plus_2_5", e.Home_Plus_2_5 = "Home_Plus_2_5", e.Away_Minus_2_5 = "Away_Minus_2_5", e.Home_Minus_2_75 = "Home_Minus_2_75", e.Away_Plus_2_75 = "Away_Plus_2_75", e.Home_Plus_2_75 = "Home_Plus_2_75", e.Away_Minus_2_75 = "Away_Minus_2_75", e.Home_Minus_3 = "Home_Minus_3", e.Away_Plus_3 = "Away_Plus_3", e.Home_Plus_3 = "Home_Plus_3", e.Away_Minus_3 = "Away_Minus_3", e.under_2_0 = "under_2_0", e.over_2_0 = "over_2_0", e.under_3_0 = "under_3_0", e.over_3_0 = "over_3_0", e.under_1_75 = "under_1_75", e.over_1_75 = "over_1_75", e.under_2_25 = "under_2_25", e.over_2_25 = "over_2_25", e.under_2_75 = "under_2_75", e.over_2_75 = "over_2_75", e.Home_1 = "Home_1", e.Home_2 = "Home_2", e.Home_3 = "Home_3", e.Home_4 = "Home_4", e.Home_5 = "Home_5", e.Home_6 = "Home_6", e.Draw_0 = "Draw_0", e.Draw_2 = "Draw_2", e.Draw_4 = "Draw_4", e.Draw_6 = "Draw_6", e.Away_1 = "Away_1", e.Away_2 = "Away_2", e.Away_3 = "Away_3", e.Away_4 = "Away_4", e.Away_5 = "Away_5", e.Away_6 = "Away_6", e.Home_Over_2_5_GG = "Home_Over_2_5_GG", e.Draw_Over_2_5_GG = "Draw_Over_2_5_GG", e.Away_Over_2_5_GG = "Away_Over_2_5_GG", e.Home_Over_2_5_NG = "Home_Over_2_5_NG", e.Draw_Over_2_5_NG = "Draw_Over_2_5_NG", e.Away_Over_2_5_NG = "Away_Over_2_5_NG", e.Home_Under_2_5_GG = "Home_Under_2_5_GG", e.Draw_Under_2_5_GG = "Draw_Under_2_5_GG", e.Away_Under_2_5_GG = "Away_Under_2_5_GG", e.Home_Under_2_5_NG = "Home_Under_2_5_NG", e.Draw_Under_2_5_NG = "Draw_Under_2_5_NG", e.Away_Under_2_5_NG = "Away_Under_2_5_NG", e.Euro_Home_Minus_1 = "Euro_Home_Minus_1", e.Euro_Draw_Plus_1 = "Euro_Draw_Plus_1", e.Euro_Away_Plus_1 = "Euro_Away_Plus_1", e.Euro_Home_Minus_2 = "Euro_Home_Minus_2", e.Euro_Draw_Plus_2 = "Euro_Draw_Plus_2", e.Euro_Away_Plus_2 = "Euro_Away_Plus_2", e.Euro_Home_Plus_1 = "Euro_Home_Plus_1", e.Euro_Draw_Minus_1 = "Euro_Draw_Minus_1", e.Euro_Away_Minus_1 = "Euro_Away_Minus_1", e.Euro_Home_Plus_2 = "Euro_Home_Plus_2", e.Euro_Draw_Minus_2 = "Euro_Draw_Minus_2", e.Euro_Away_Minus_2 = "Euro_Away_Minus_2", e._Home_0_0_Goals = "_Home_0_0_Goals", e._Home_1_2_Goals = "_Home_1_2_Goals", e._Home_3_More_Goals = "_Home_3_More_Goals", e._Away_0_0_Goals = "_Away_0_0_Goals", e._Away_1_2_Goals = "_Away_1_2_Goals", e._Away_3_More_Goals = "_Away_3_More_Goals", e._1H_0_0 = "_1H_0_0", e._1H_1_0 = "_1H_1_0", e._1H_2_0 = "_1H_2_0", e._1H_3_0 = "_1H_3_0", e._1H_0_1 = "_1H_0_1", e._1H_1_1 = "_1H_1_1", e._1H_2_1 = "_1H_2_1", e._1H_0_2 = "_1H_0_2", e._1H_1_2 = "_1H_1_2", e._1H_0_3 = "_1H_0_3", e._00_00 = "_00_00", e._00_01 = "_00_01", e._00_02 = "_00_02", e._00_03 = "_00_03", e._00_10 = "_00_10", e._00_11 = "_00_11", e._00_12 = "_00_12", e._00_20 = "_00_20", e._00_21 = "_00_21", e._00_30 = "_00_30", e._10_10 = "_10_10", e._10_11 = "_10_11", e._10_12 = "_10_12", e._10_13 = "_10_13", e._10_20 = "_10_20", e._10_21 = "_10_21", e._10_22 = "_10_22", e._10_30 = "_10_30", e._10_31 = "_10_31", e._10_40 = "_10_40", e._20_20 = "_20_20", e._20_21 = "_20_21", e._20_22 = "_20_22", e._20_23 = "_20_23", e._20_30 = "_20_30", e._20_31 = "_20_31", e._20_32 = "_20_32", e._20_40 = "_20_40", e._20_41 = "_20_41", e._20_50 = "_20_50", e._30_30 = "_30_30", e._30_31 = "_30_31", e._30_32 = "_30_32", e._30_33 = "_30_33", e._30_40 = "_30_40", e._30_41 = "_30_41", e._30_42 = "_30_42", e._30_50 = "_30_50", e._30_51 = "_30_51", e._30_60 = "_30_60", e._01_01 = "_01_01", e._01_02 = "_01_02", e._01_03 = "_01_03", e._01_04 = "_01_04", e._01_11 = "_01_11", e._01_12 = "_01_12", e._01_13 = "_01_13", e._01_21 = "_01_21", e._01_22 = "_01_22", e._01_31 = "_01_31", e._11_11 = "_11_11", e._11_12 = "_11_12", e._11_13 = "_11_13", e._11_14 = "_11_14", e._11_21 = "_11_21", e._11_22 = "_11_22", e._11_23 = "_11_23", e._11_31 = "_11_31", e._11_32 = "_11_32", e._11_41 = "_11_41", e._21_21 = "_21_21", e._21_22 = "_21_22", e._21_23 = "_21_23", e._21_24 = "_21_24", e._21_31 = "_21_31", e._21_32 = "_21_32", e._21_33 = "_21_33", e._21_41 = "_21_41", e._21_42 = "_21_42", e._21_51 = "_21_51", e._02_02 = "_02_02", e._02_03 = "_02_03", e._02_04 = "_02_04", e._02_05 = "_02_05", e._02_12 = "_02_12", e._02_13 = "_02_13", e._02_14 = "_02_14", e._02_22 = "_02_22", e._02_23 = "_02_23", e._02_32 = "_02_32", e._12_12 = "_12_12", e._12_13 = "_12_13", e._12_14 = "_12_14", e._12_15 = "_12_15", e._12_22 = "_12_22", e._12_23 = "_12_23", e._12_24 = "_12_24", e._12_32 = "_12_32", e._12_33 = "_12_33", e._12_42 = "_12_42", e._03_03 = "_03_03", e._03_04 = "_03_04", e._03_05 = "_03_05", e._03_06 = "_03_06", e._03_13 = "_03_13", e._03_14 = "_03_14", e._03_15 = "_03_15", e._03_23 = "_03_23", e._03_24 = "_03_24", e._03_33 = "_03_33", e.Home_GoalGoal = "Home_GoalGoal", e.Draw_GoalGoal = "Draw_GoalGoal", e.Away_GoalGoal = "Away_GoalGoal", e.Home_NoGoal = "Home_NoGoal", e.Draw_NoGoal = "Draw_NoGoal", e.Away_NoGoal = "Away_NoGoal", e.HT_Draw_Away = "HT_Draw_Away", e.HT_Home_Away = "HT_Home_Away", e.HT_Home_Draw = "HT_Home_Draw", e.HT_nog = "HT_nog", e.HT_gg = "HT_gg", e.HT_Odd = "HT_Odd", e.HT_Even = "HT_Even", e.HT_under05 = "HT_under05", e.HT_over05 = "HT_over05", e.HT_under15 = "HT_under15", e.HT_over15 = "HT_over15", e.HT_0_Goals = "HT_0_Goals", e.HT_1_Goals = "HT_1_Goals", e.HT_2_Goals = "HT_2_Goals", e.HT_3_Goals = "HT_3_Goals", e.HT_Home_0 = "HT_Home_0", e.HT_Away_0 = "HT_Away_0", e.HT_Home_Minus_0_25 = "HT_Home_Minus_0_25", e.HT_Away_Plus_0_25 = "HT_Away_Plus_0_25", e.HT_Home_Plus_0_25 = "HT_Home_Plus_0_25", e.HT_Away_Minus_0_25 = "HT_Away_Minus_0_25", e.HT_Home_Minus_0_5 = "HT_Home_Minus_0_5", e.HT_Away_Plus_0_5 = "HT_Away_Plus_0_5", e.HT_Home_Plus_0_5 = "HT_Home_Plus_0_5", e.HT_Away_Minus_0_5 = "HT_Away_Minus_0_5", e.HT_Home_Minus_0_75 = "HT_Home_Minus_0_75", e.HT_Away_Plus_0_75 = "HT_Away_Plus_0_75", e.HT_Home_Plus_0_75 = "HT_Home_Plus_0_75", e.HT_Away_Minus_0_75 = "HT_Away_Minus_0_75", e.HT_Home_Minus_1 = "HT_Home_Minus_1", e.HT_Away_Plus_1 = "HT_Away_Plus_1", e.HT_Home_Plus_1 = "HT_Home_Plus_1", e.HT_Away_Minus_1 = "HT_Away_Minus_1", e.HT_Home_Minus_1_25 = "HT_Home_Minus_1_25", e.HT_Away_Plus_1_25 = "HT_Away_Plus_1_25", e.HT_Home_Plus_1_25 = "HT_Home_Plus_1_25", e.HT_Away_Minus_1_25 = "HT_Away_Minus_1_25", e.HT_Home_Minus_1_5 = "HT_Home_Minus_1_5", e.HT_Away_Plus_1_5 = "HT_Away_Plus_1_5", e.HT_Home_Plus_1_5 = "HT_Home_Plus_1_5", e.HT_Away_Minus_1_5 = "HT_Away_Minus_1_5", e.HT_Home_Minus_1_75 = "HT_Home_Minus_1_75", e.HT_Away_Plus_1_75 = "HT_Away_Plus_1_75", e.HT_Home_Plus_1_75 = "HT_Home_Plus_1_75", e.HT_Away_Minus_1_75 = "HT_Away_Minus_1_75", e.FT_Odd = "FT_Odd", e.FT_Even = "FT_Even", e.Home_0_Goals = "Home_0_Goals", e.Home_1_Goals = "Home_1_Goals", e.Home_2_Goals = "Home_2_Goals", e.Home_3_Goals = "Home_3_Goals", e.Home_4_Goals = "Home_4_Goals", e.Home_5_Goals = "Home_5_Goals", e.Home_6_Goals = "Home_6_Goals", e.Away_0_Goals = "Away_0_Goals", e.Away_1_Goals = "Away_1_Goals", e.Away_2_Goals = "Away_2_Goals", e.Away_3_Goals = "Away_3_Goals", e.Away_4_Goals = "Away_4_Goals", e.Away_5_Goals = "Away_5_Goals", e.Away_6_Goals = "Away_6_Goals", e.Home_Nil = "Home_Nil", e.Away_Nil = "Away_Nil", e.Home_By_1 = "Home_By_1", e.Home_By_2 = "Home_By_2", e.Home_By_3_More = "Home_By_3_More", e.Away_By_1 = "Away_By_1", e.Away_By_2 = "Away_By_2", e.Away_By_3_More = "Away_By_3_More", e.Draw_Goal_MV = "Draw_Goal_MV", e.Draw_No_Goal_MV = "Draw_No_Goal_MV", e.HT_under075 = "HT_under075", e.HT_over075 = "HT_over075", e.HT_under10 = "HT_under10", e.HT_over10 = "HT_over10", e.HT_under125 = "HT_under125", e.HT_over125 = "HT_over125", e.HT_under175 = "HT_under175", e.HT_over175 = "HT_over175", e.HT_under20 = "HT_under20", e.HT_over20 = "HT_over20"
                }(Qe = t.ChOdds || (t.ChOdds = {})), t.ChMarketsTemplate = ((a = {})[Je.Match_Result] = ((n = {})[Qe.Home] = Qe.Home, n[Qe.Away] = Qe.Away, n[Qe.Draw] = Qe.Draw, n), a[Je.Double_Result] = ((r = {})[Qe.HomeHome] = Qe.HomeHome, r[Qe.HomeDraw] = Qe.HomeDraw, r[Qe.HomeAway] = Qe.HomeAway, r[Qe.DrawHome] = Qe.DrawHome, r[Qe.DrawDraw] = Qe.DrawDraw, r[Qe.DrawAway] = Qe.DrawAway, r[Qe.AwayHome] = Qe.AwayHome, r[Qe.AwayDraw] = Qe.AwayDraw, r[Qe.AwayAway] = Qe.AwayAway, r), a[Je.Double_Chance] = ((o = {})[Qe.Draw_Away] = Qe.Draw_Away, o[Qe.Home_Away] = Qe.Home_Away, o[Qe.Home_Draw] = Qe.Home_Draw, o), a[Je.Correct_Score] = ((i = {})[Qe._0_0] = Qe._0_0, i[Qe._1_0] = Qe._1_0, i[Qe._2_0] = Qe._2_0, i[Qe._3_0] = Qe._3_0, i[Qe._4_0] = Qe._4_0, i[Qe._5_0] = Qe._5_0, i[Qe._6_0] = Qe._6_0, i[Qe._0_1] = Qe._0_1, i[Qe._1_1] = Qe._1_1, i[Qe._2_1] = Qe._2_1, i[Qe._3_1] = Qe._3_1, i[Qe._4_1] = Qe._4_1, i[Qe._5_1] = Qe._5_1, i[Qe._0_2] = Qe._0_2, i[Qe._1_2] = Qe._1_2, i[Qe._2_2] = Qe._2_2, i[Qe._3_2] = Qe._3_2, i[Qe._4_2] = Qe._4_2, i[Qe._0_3] = Qe._0_3, i[Qe._1_3] = Qe._1_3, i[Qe._2_3] = Qe._2_3, i[Qe._3_3] = Qe._3_3, i[Qe._0_4] = Qe._0_4, i[Qe._1_4] = Qe._1_4, i[Qe._2_4] = Qe._2_4, i[Qe._0_5] = Qe._0_5, i[Qe._1_5] = Qe._1_5, i[Qe._0_6] = Qe._0_6, i), a[Je.Total_Goals] = ((s = {})[Qe._0_Goals] = Qe._0_Goals, s[Qe._1_Goals] = Qe._1_Goals, s[Qe._2_Goals] = Qe._2_Goals, s[Qe._3_Goals] = Qe._3_Goals, s[Qe._4_Goals] = Qe._4_Goals, s[Qe._5_Goals] = Qe._5_Goals, s[Qe._6_Goals] = Qe._6_Goals, s), a[Je.GoalGoal_NoGoal] = ((c = {})[Qe.nog] = Qe.nog, c[Qe.gg] = Qe.gg, c), a[Je.Over_Under_0_5] = ((l = {})[Qe.under_0_5] = Qe.under_0_5, l[Qe.over_0_5] = Qe.over_0_5, l), a[Je.Over_Under_1_5] = ((u = {})[Qe.under_1_5] = Qe.under_1_5, u[Qe.over_1_5] = Qe.over_1_5, u), a[Je.Over_Under_2_5] = ((d = {})[Qe.under_2_5] = Qe.under_2_5, d[Qe.over_2_5] = Qe.over_2_5, d), a[Je.Over_Under_3_5] = ((p = {})[Qe.under_3_5] = Qe.under_3_5, p[Qe.over_3_5] = Qe.over_3_5, p), a[Je.Over_Under_4_5] = ((h = {})[Qe.under_4_5] = Qe.under_4_5, h[Qe.over_4_5] = Qe.over_4_5, h), a[Je.HomeAwayScores_Over_Under_0_5] = ((f = {})[Qe.Home_Scores_Over_0_5] = Qe.Home_Scores_Over_0_5, f[Qe.Away_Scores_Over_0_5] = Qe.Away_Scores_Over_0_5, f[Qe.Home_Scores_Under_0_5] = Qe.Home_Scores_Under_0_5, f[Qe.Away_Scores_Under_0_5] = Qe.Away_Scores_Under_0_5, f), a[Je.HomeAwayScores_Over_Under_1_5] = ((y = {})[Qe.Home_Scores_Over_1_5] = Qe.Home_Scores_Over_1_5, y[Qe.Away_Scores_Over_1_5] = Qe.Away_Scores_Over_1_5, y[Qe.Home_Scores_Under_1_5] = Qe.Home_Scores_Under_1_5, y[Qe.Away_Scores_Under_1_5] = Qe.Away_Scores_Under_1_5, y), a[Je.HomeAwayScores_Over_Under_2_5] = ((m = {})[Qe.Home_Scores_Over_2_5] = Qe.Home_Scores_Over_2_5, m[Qe.Away_Scores_Over_2_5] = Qe.Away_Scores_Over_2_5, m[Qe.Home_Scores_Under_2_5] = Qe.Home_Scores_Under_2_5, m[Qe.Away_Scores_Under_2_5] = Qe.Away_Scores_Under_2_5, m), a[Je.HomeAwayScores_Over_Under_3_5] = ((w = {})[Qe.Home_Scores_Over_3_5] = Qe.Home_Scores_Over_3_5, w[Qe.Away_Scores_Over_3_5] = Qe.Away_Scores_Over_3_5, w[Qe.Home_Scores_Under_3_5] = Qe.Home_Scores_Under_3_5, w[Qe.Away_Scores_Under_3_5] = Qe.Away_Scores_Under_3_5, w), a[Je._1x2_Scores_Over_Under_1_5] = ((v = {})[Qe._1x2_Home_Scores_Over_1_5] = Qe._1x2_Home_Scores_Over_1_5, v[Qe._1x2_Draw_Scores_Over_1_5] = Qe._1x2_Draw_Scores_Over_1_5, v[Qe._1x2_Away_Scores_Over_1_5] = Qe._1x2_Away_Scores_Over_1_5, v[Qe._1x2_Home_Scores_Under_1_5] = Qe._1x2_Home_Scores_Under_1_5, v[Qe._1x2_Draw_Scores_Under_1_5] = Qe._1x2_Draw_Scores_Under_1_5, v[Qe._1x2_Away_Scores_Under_1_5] = Qe._1x2_Away_Scores_Under_1_5, v), a[Je._1x2_Scores_Over_Under_2_5] = ((x = {})[Qe._1x2_Home_Scores_Over_2_5] = Qe._1x2_Home_Scores_Over_2_5, x[Qe._1x2_Draw_Scores_Over_2_5] = Qe._1x2_Draw_Scores_Over_2_5, x[Qe._1x2_Away_Scores_Over_2_5] = Qe._1x2_Away_Scores_Over_2_5, x[Qe._1x2_Home_Scores_Under_2_5] = Qe._1x2_Home_Scores_Under_2_5, x[Qe._1x2_Draw_Scores_Under_2_5] = Qe._1x2_Draw_Scores_Under_2_5, x[Qe._1x2_Away_Scores_Under_2_5] = Qe._1x2_Away_Scores_Under_2_5, x), a[Je._1x2_Scores_Over_Under_3_5] = ((T = {})[Qe._1x2_Home_Scores_Over_3_5] = Qe._1x2_Home_Scores_Over_3_5, T[Qe._1x2_Draw_Scores_Over_3_5] = Qe._1x2_Draw_Scores_Over_3_5, T[Qe._1x2_Away_Scores_Over_3_5] = Qe._1x2_Away_Scores_Over_3_5, T[Qe._1x2_Home_Scores_Under_3_5] = Qe._1x2_Home_Scores_Under_3_5, T[Qe._1x2_Draw_Scores_Under_3_5] = Qe._1x2_Draw_Scores_Under_3_5, T[Qe._1x2_Away_Scores_Under_3_5] = Qe._1x2_Away_Scores_Under_3_5, T), a[Je.Qualify] = ((O = {})[Qe.QHome] = Qe.QHome, O[Qe.QAway] = Qe.QAway, O), a[Je.Qualify_2] = ((S = {})[Qe.QHome_2] = Qe.QHome_2, S[Qe.QAway_2] = Qe.QAway_2, S), a[Je.Qualify_3] = ((b = {})[Qe.QHome_3] = Qe.QHome_3, b[Qe.QAway_3] = Qe.QAway_3, b), a[Je.Qualify_4] = ((P = {})[Qe.QHome_4] = Qe.QHome_4, P[Qe.QAway_4] = Qe.QAway_4, P), a[Je.Multigoal] = ((H = {})[Qe._0_0_Goals] = Qe._0_0_Goals, H[Qe._0_1_Goals] = Qe._0_1_Goals, H[Qe._0_2_Goals] = Qe._0_2_Goals, H[Qe._0_3_Goals] = Qe._0_3_Goals, H[Qe._0_4_Goals] = Qe._0_4_Goals, H[Qe._0_5_Goals] = Qe._0_5_Goals, H[Qe._0_6_Goals] = Qe._0_6_Goals, H[Qe._1_1_Goals] = Qe._1_1_Goals, H[Qe._1_2_Goals] = Qe._1_2_Goals, H[Qe._1_3_Goals] = Qe._1_3_Goals, H[Qe._1_4_Goals] = Qe._1_4_Goals, H[Qe._1_5_Goals] = Qe._1_5_Goals, H[Qe._1_6_Goals] = Qe._1_6_Goals, H[Qe._2_2_Goals] = Qe._2_2_Goals, H[Qe._2_3_Goals] = Qe._2_3_Goals, H[Qe._2_4_Goals] = Qe._2_4_Goals, H[Qe._2_5_Goals] = Qe._2_5_Goals, H[Qe._2_6_Goals] = Qe._2_6_Goals, H[Qe._3_3_Goals] = Qe._3_3_Goals, H[Qe._3_4_Goals] = Qe._3_4_Goals, H[Qe._3_5_Goals] = Qe._3_5_Goals, H[Qe._3_6_Goals] = Qe._3_6_Goals, H[Qe._4_4_Goals] = Qe._4_4_Goals, H[Qe._4_5_Goals] = Qe._4_5_Goals, H[Qe._4_6_Goals] = Qe._4_6_Goals, H[Qe._5_5_Goals] = Qe._5_5_Goals, H[Qe._5_6_Goals] = Qe._5_6_Goals, H[Qe._6_6_Goals] = Qe._6_6_Goals, H), a[Je.First_Half] = ((A = {})[Qe._1H_Home] = Qe._1H_Home, A[Qe._1H_Draw] = Qe._1H_Draw, A[Qe._1H_Away] = Qe._1H_Away, A), a[Je.Handicap_0] = ((E = {})[Qe.Home_0] = Qe.Home_0, E[Qe.Away_0] = Qe.Away_0, E), a[Je.Handicap_Home_0_25] = ((g = {})[Qe.Home_Minus_0_25] = Qe.Home_Minus_0_25, g[Qe.Away_Plus_0_25] = Qe.Away_Plus_0_25, g), a[Je.Handicap_Away_0_25] = ((k = {})[Qe.Home_Plus_0_25] = Qe.Home_Plus_0_25, k[Qe.Away_Minus_0_25] = Qe.Away_Minus_0_25, k), a[Je.Handicap_Home_0_5] = ((q = {})[Qe.Home_Minus_0_5] = Qe.Home_Minus_0_5, q[Qe.Away_Plus_0_5] = Qe.Away_Plus_0_5, q), a[Je.Handicap_Away_0_5] = ((M = {})[Qe.Home_Plus_0_5] = Qe.Home_Plus_0_5, M[Qe.Away_Minus_0_5] = Qe.Away_Minus_0_5, M), a[Je.Handicap_Home_0_75] = ((C = {})[Qe.Home_Minus_0_75] = Qe.Home_Minus_0_75, C[Qe.Away_Plus_0_75] = Qe.Away_Plus_0_75, C), a[Je.Handicap_Away_0_75] = ((B = {})[Qe.Home_Plus_0_75] = Qe.Home_Plus_0_75, B[Qe.Away_Minus_0_75] = Qe.Away_Minus_0_75, B), a[Je.Handicap_Home_1] = ((D = {})[Qe.Home_Minus_1] = Qe.Home_Minus_1, D[Qe.Away_Plus_1] = Qe.Away_Plus_1, D), a[Je.Handicap_Away_1] = ((G = {})[Qe.Home_Plus_1] = Qe.Home_Plus_1, G[Qe.Away_Minus_1] = Qe.Away_Minus_1, G), a[Je.Handicap_Home_1_25] = ((R = {})[Qe.Home_Minus_1_25] = Qe.Home_Minus_1_25, R[Qe.Away_Plus_1_25] = Qe.Away_Plus_1_25, R), a[Je.Handicap_Away_1_25] = ((j = {})[Qe.Home_Plus_1_25] = Qe.Home_Plus_1_25, j[Qe.Away_Minus_1_25] = Qe.Away_Minus_1_25, j), a[Je.Handicap_Home_1_5] = ((I = {})[Qe.Home_Minus_1_5] = Qe.Home_Minus_1_5, I[Qe.Away_Plus_1_5] = Qe.Away_Plus_1_5, I), a[Je.Handicap_Away_1_5] = ((L = {})[Qe.Home_Plus_1_5] = Qe.Home_Plus_1_5, L[Qe.Away_Minus_1_5] = Qe.Away_Minus_1_5, L), a[Je.Handicap_Home_1_75] = ((F = {})[Qe.Home_Minus_1_75] = Qe.Home_Minus_1_75, F[Qe.Away_Plus_1_75] = Qe.Away_Plus_1_75, F), a[Je.Handicap_Away_1_75] = ((U = {})[Qe.Home_Plus_1_75] = Qe.Home_Plus_1_75, U[Qe.Away_Minus_1_75] = Qe.Away_Minus_1_75, U), a[Je.Handicap_Home_2] = ((N = {})[Qe.Home_Minus_2] = Qe.Home_Minus_2, N[Qe.Away_Plus_2] = Qe.Away_Plus_2, N), a[Je.Handicap_Away_2] = ((W = {})[Qe.Home_Plus_2] = Qe.Home_Plus_2, W[Qe.Away_Minus_2] = Qe.Away_Minus_2, W), a[Je.Handicap_Home_2_25] = ((V = {})[Qe.Home_Minus_2_25] = Qe.Home_Minus_2_25, V[Qe.Away_Plus_2_25] = Qe.Away_Plus_2_25, V), a[Je.Handicap_Away_2_25] = ((K = {})[Qe.Home_Plus_2_25] = Qe.Home_Plus_2_25, K[Qe.Away_Minus_2_25] = Qe.Away_Minus_2_25, K), a[Je.Handicap_Home_2_5] = ((J = {})[Qe.Home_Minus_2_5] = Qe.Home_Minus_2_5, J[Qe.Away_Plus_2_5] = Qe.Away_Plus_2_5, J), a[Je.Handicap_Away_2_5] = ((Q = {})[Qe.Home_Plus_2_5] = Qe.Home_Plus_2_5, Q[Qe.Away_Minus_2_5] = Qe.Away_Minus_2_5, Q), a[Je.Handicap_Home_2_75] = ((z = {})[Qe.Home_Minus_2_75] = Qe.Home_Minus_2_75, z[Qe.Away_Plus_2_75] = Qe.Away_Plus_2_75, z), a[Je.Handicap_Away_2_75] = ((Y = {})[Qe.Home_Plus_2_75] = Qe.Home_Plus_2_75, Y[Qe.Away_Minus_2_75] = Qe.Away_Minus_2_75, Y), a[Je.Handicap_Home_3] = ((Z = {})[Qe.Home_Minus_3] = Qe.Home_Minus_3, Z[Qe.Away_Plus_3] = Qe.Away_Plus_3, Z), a[Je.Handicap_Away_3] = ((X = {})[Qe.Home_Plus_3] = Qe.Home_Plus_3, X[Qe.Away_Minus_3] = Qe.Away_Minus_3, X), a[Je.Over_Under_2] = (($ = {})[Qe.under_2_0] = Qe.under_2_0, $[Qe.over_2_0] = Qe.over_2_0, $), a[Je.Over_Under_3] = ((ee = {})[Qe.under_3_0] = Qe.under_3_0, ee[Qe.over_3_0] = Qe.over_3_0, ee), a[Je.Over_Under_1_75] = ((te = {})[Qe.under_1_75] = Qe.under_1_75, te[Qe.over_1_75] = Qe.over_1_75, te), a[Je.Over_Under_2_25] = ((_e = {})[Qe.under_2_25] = Qe.under_2_25, _e[Qe.over_2_25] = Qe.over_2_25, _e), a[Je.Over_Under_2_75] = ((ae = {})[Qe.under_2_75] = Qe.under_2_75, ae[Qe.over_2_75] = Qe.over_2_75, ae), a[Je.FullTime_TotalGoals] = ((ne = {})[Qe.Home_1] = Qe.Home_1, ne[Qe.Home_2] = Qe.Home_2, ne[Qe.Home_3] = Qe.Home_3, ne[Qe.Home_4] = Qe.Home_4, ne[Qe.Home_5] = Qe.Home_5, ne[Qe.Home_6] = Qe.Home_6, ne[Qe.Draw_0] = Qe.Draw_0, ne[Qe.Draw_2] = Qe.Draw_2, ne[Qe.Draw_4] = Qe.Draw_4, ne[Qe.Draw_6] = Qe.Draw_6, ne[Qe.Away_1] = Qe.Away_1, ne[Qe.Away_2] = Qe.Away_2, ne[Qe.Away_3] = Qe.Away_3, ne[Qe.Away_4] = Qe.Away_4, ne[Qe.Away_5] = Qe.Away_5, ne[Qe.Away_6] = Qe.Away_6, ne), a[Je.FullTime_Under_Over_2_5_GoalGoal_NoGoal] = ((re = {})[Qe.Home_Over_2_5_GG] = Qe.Home_Over_2_5_GG, re[Qe.Draw_Over_2_5_GG] = Qe.Draw_Over_2_5_GG, re[Qe.Away_Over_2_5_GG] = Qe.Away_Over_2_5_GG, re[Qe.Home_Over_2_5_NG] = Qe.Home_Over_2_5_NG, re[Qe.Draw_Over_2_5_NG] = Qe.Draw_Over_2_5_NG, re[Qe.Away_Over_2_5_NG] = Qe.Away_Over_2_5_NG, re[Qe.Home_Under_2_5_GG] = Qe.Home_Under_2_5_GG, re[Qe.Draw_Under_2_5_GG] = Qe.Draw_Under_2_5_GG, re[Qe.Away_Under_2_5_GG] = Qe.Away_Under_2_5_GG, re[Qe.Home_Under_2_5_NG] = Qe.Home_Under_2_5_NG, re[Qe.Draw_Under_2_5_NG] = Qe.Draw_Under_2_5_NG, re[Qe.Away_Under_2_5_NG] = Qe.Away_Under_2_5_NG, re), a[Je.Euro_Handicap_Home_1] = ((oe = {})[Qe.Euro_Home_Minus_1] = Qe.Euro_Home_Minus_1, oe[Qe.Euro_Draw_Plus_1] = Qe.Euro_Draw_Plus_1, oe[Qe.Euro_Away_Plus_1] = Qe.Euro_Away_Plus_1, oe), a[Je.Euro_Handicap_Home_2] = ((ie = {})[Qe.Euro_Home_Minus_2] = Qe.Euro_Home_Minus_2, ie[Qe.Euro_Draw_Plus_2] = Qe.Euro_Draw_Plus_2, ie[Qe.Euro_Away_Plus_2] = Qe.Euro_Away_Plus_2, ie), a[Je.Euro_Handicap_Away_1] = ((se = {})[Qe.Euro_Home_Plus_1] = Qe.Euro_Home_Plus_1, se[Qe.Euro_Draw_Minus_1] = Qe.Euro_Draw_Minus_1, se[Qe.Euro_Away_Minus_1] = Qe.Euro_Away_Minus_1, se), a[Je.Euro_Handicap_Away_2] = ((ce = {})[Qe.Euro_Home_Plus_2] = Qe.Euro_Home_Plus_2, ce[Qe.Euro_Draw_Minus_2] = Qe.Euro_Draw_Minus_2, ce[Qe.Euro_Away_Minus_2] = Qe.Euro_Away_Minus_2, ce), a[Je.HomeMultigoal_1_2] = ((le = {})[Qe._Home_0_0_Goals] = Qe._Home_0_0_Goals, le[Qe._Home_1_2_Goals] = Qe._Home_1_2_Goals, le[Qe._Home_3_More_Goals] = Qe._Home_3_More_Goals, le), a[Je.AwayMultigoal_1_2] = ((ue = {})[Qe._Away_0_0_Goals] = Qe._Away_0_0_Goals, ue[Qe._Away_1_2_Goals] = Qe._Away_1_2_Goals, ue[Qe._Away_3_More_Goals] = Qe._Away_3_More_Goals, ue), a[Je.Correct_Score_1H] = ((de = {})[Qe._1H_0_0] = Qe._1H_0_0, de[Qe._1H_1_0] = Qe._1H_1_0, de[Qe._1H_2_0] = Qe._1H_2_0, de[Qe._1H_3_0] = Qe._1H_3_0, de[Qe._1H_0_1] = Qe._1H_0_1, de[Qe._1H_1_1] = Qe._1H_1_1, de[Qe._1H_2_1] = Qe._1H_2_1, de[Qe._1H_0_2] = Qe._1H_0_2, de[Qe._1H_1_2] = Qe._1H_1_2, de[Qe._1H_0_3] = Qe._1H_0_3, de), a[Je.Correct_Score_HTFT] = ((pe = {})[Qe._00_00] = Qe._00_00, pe[Qe._00_01] = Qe._00_01, pe[Qe._00_02] = Qe._00_02, pe[Qe._00_03] = Qe._00_03, pe[Qe._00_10] = Qe._00_10, pe[Qe._00_11] = Qe._00_11, pe[Qe._00_12] = Qe._00_12, pe[Qe._00_20] = Qe._00_20, pe[Qe._00_21] = Qe._00_21, pe[Qe._00_30] = Qe._00_30, pe[Qe._10_10] = Qe._10_10, pe[Qe._10_11] = Qe._10_11, pe[Qe._10_12] = Qe._10_12, pe[Qe._10_13] = Qe._10_13, pe[Qe._10_20] = Qe._10_20, pe[Qe._10_21] = Qe._10_21, pe[Qe._10_22] = Qe._10_22, pe[Qe._10_30] = Qe._10_30, pe[Qe._10_31] = Qe._10_31, pe[Qe._10_40] = Qe._10_40, pe[Qe._20_20] = Qe._20_20, pe[Qe._20_21] = Qe._20_21, pe[Qe._20_22] = Qe._20_22, pe[Qe._20_23] = Qe._20_23, pe[Qe._20_30] = Qe._20_30, pe[Qe._20_31] = Qe._20_31, pe[Qe._20_32] = Qe._20_32, pe[Qe._20_40] = Qe._20_40, pe[Qe._20_41] = Qe._20_41, pe[Qe._20_50] = Qe._20_50, pe[Qe._30_30] = Qe._30_30, pe[Qe._30_31] = Qe._30_31, pe[Qe._30_32] = Qe._30_32, pe[Qe._30_33] = Qe._30_33, pe[Qe._30_40] = Qe._30_40, pe[Qe._30_41] = Qe._30_41, pe[Qe._30_42] = Qe._30_42, pe[Qe._30_50] = Qe._30_50, pe[Qe._30_51] = Qe._30_51, pe[Qe._30_60] = Qe._30_60, pe[Qe._01_01] = Qe._01_01, pe[Qe._01_02] = Qe._01_02, pe[Qe._01_03] = Qe._01_03, pe[Qe._01_04] = Qe._01_04, pe[Qe._01_11] = Qe._01_11, pe[Qe._01_12] = Qe._01_12, pe[Qe._01_13] = Qe._01_13, pe[Qe._01_21] = Qe._01_21, pe[Qe._01_22] = Qe._01_22, pe[Qe._01_31] = Qe._01_31, pe[Qe._11_11] = Qe._11_11, pe[Qe._11_12] = Qe._11_12, pe[Qe._11_13] = Qe._11_13, pe[Qe._11_14] = Qe._11_14, pe[Qe._11_21] = Qe._11_21, pe[Qe._11_22] = Qe._11_22, pe[Qe._11_23] = Qe._11_23, pe[Qe._11_31] = Qe._11_31, pe[Qe._11_32] = Qe._11_32, pe[Qe._11_41] = Qe._11_41, pe[Qe._21_21] = Qe._21_21, pe[Qe._21_22] = Qe._21_22, pe[Qe._21_23] = Qe._21_23, pe[Qe._21_24] = Qe._21_24, pe[Qe._21_31] = Qe._21_31, pe[Qe._21_32] = Qe._21_32, pe[Qe._21_33] = Qe._21_33, pe[Qe._21_41] = Qe._21_41, pe[Qe._21_42] = Qe._21_42, pe[Qe._21_51] = Qe._21_51, pe[Qe._02_02] = Qe._02_02, pe[Qe._02_03] = Qe._02_03, pe[Qe._02_04] = Qe._02_04, pe[Qe._02_05] = Qe._02_05, pe[Qe._02_12] = Qe._02_12, pe[Qe._02_13] = Qe._02_13, pe[Qe._02_14] = Qe._02_14, pe[Qe._02_22] = Qe._02_22, pe[Qe._02_23] = Qe._02_23, pe[Qe._02_32] = Qe._02_32, pe[Qe._12_12] = Qe._12_12, pe[Qe._12_13] = Qe._12_13, pe[Qe._12_14] = Qe._12_14, pe[Qe._12_15] = Qe._12_15, pe[Qe._12_22] = Qe._12_22, pe[Qe._12_23] = Qe._12_23, pe[Qe._12_24] = Qe._12_24, pe[Qe._12_32] = Qe._12_32, pe[Qe._12_33] = Qe._12_33, pe[Qe._12_42] = Qe._12_42, pe[Qe._03_03] = Qe._03_03, pe[Qe._03_04] = Qe._03_04, pe[Qe._03_05] = Qe._03_05, pe[Qe._03_06] = Qe._03_06, pe[Qe._03_13] = Qe._03_13, pe[Qe._03_14] = Qe._03_14, pe[Qe._03_15] = Qe._03_15, pe[Qe._03_23] = Qe._03_23, pe[Qe._03_24] = Qe._03_24, pe[Qe._03_33] = Qe._03_33, pe), a[Je.FullTime_GoalGoalNoGoal] = ((he = {})[Qe.Home_GoalGoal] = Qe.Home_GoalGoal, he[Qe.Draw_GoalGoal] = Qe.Draw_GoalGoal, he[Qe.Away_GoalGoal] = Qe.Away_GoalGoal, he[Qe.Home_NoGoal] = Qe.Home_NoGoal, he[Qe.Draw_NoGoal] = Qe.Draw_NoGoal, he[Qe.Away_NoGoal] = Qe.Away_NoGoal, he), a[Je.HT_Double_Chance] = ((fe = {})[Qe.HT_Draw_Away] = Qe.HT_Draw_Away, fe[Qe.HT_Home_Away] = Qe.HT_Home_Away, fe[Qe.HT_Home_Draw] = Qe.HT_Home_Draw, fe), a[Je.HT_GoalGoal_NoGoal] = ((ye = {})[Qe.HT_nog] = Qe.HT_nog, ye[Qe.HT_gg] = Qe.HT_gg, ye), a[Je.HT_OddEven] = ((me = {})[Qe.HT_Odd] = Qe.HT_Odd, me[Qe.HT_Even] = Qe.HT_Even, me), a[Je.HT_Over_Under_0_5] = ((we = {})[Qe.HT_under05] = Qe.HT_under05, we[Qe.HT_over05] = Qe.HT_over05, we), a[Je.HT_Over_Under_1_5] = ((ve = {})[Qe.HT_under15] = Qe.HT_under15, ve[Qe.HT_over15] = Qe.HT_over15, ve), a[Je.HT_Total_Goals] = ((xe = {})[Qe.HT_0_Goals] = Qe.HT_0_Goals, xe[Qe.HT_1_Goals] = Qe.HT_1_Goals, xe[Qe.HT_2_Goals] = Qe.HT_2_Goals, xe[Qe.HT_3_Goals] = Qe.HT_3_Goals, xe), a[Je.HT_Handicap_0] = ((Te = {})[Qe.HT_Home_0] = Qe.HT_Home_0, Te[Qe.HT_Away_0] = Qe.HT_Away_0, Te), a[Je.HT_Handicap_Home_0_25] = ((Oe = {})[Qe.HT_Home_Minus_0_25] = Qe.HT_Home_Minus_0_25, Oe[Qe.HT_Away_Plus_0_25] = Qe.HT_Away_Plus_0_25, Oe), a[Je.HT_Handicap_Away_0_25] = ((Se = {})[Qe.HT_Home_Plus_0_25] = Qe.HT_Home_Plus_0_25, Se[Qe.HT_Away_Minus_0_25] = Qe.HT_Away_Minus_0_25, Se), a[Je.HT_Handicap_Home_0_5] = ((be = {})[Qe.HT_Home_Minus_0_5] = Qe.HT_Home_Minus_0_5, be[Qe.HT_Away_Plus_0_5] = Qe.HT_Away_Plus_0_5, be), a[Je.HT_Handicap_Away_0_5] = ((Pe = {})[Qe.HT_Home_Plus_0_5] = Qe.HT_Home_Plus_0_5, Pe[Qe.HT_Away_Minus_0_5] = Qe.HT_Away_Minus_0_5, Pe), a[Je.HT_Handicap_Home_0_75] = ((He = {})[Qe.HT_Home_Minus_0_75] = Qe.HT_Home_Minus_0_75, He[Qe.HT_Away_Plus_0_75] = Qe.HT_Away_Plus_0_75, He), a[Je.HT_Handicap_Away_0_75] = ((Ae = {})[Qe.HT_Home_Plus_0_75] = Qe.HT_Home_Plus_0_75, Ae[Qe.HT_Away_Minus_0_75] = Qe.HT_Away_Minus_0_75, Ae), a[Je.HT_Handicap_Home_1] = ((Ee = {})[Qe.HT_Home_Minus_1] = Qe.HT_Home_Minus_1, Ee[Qe.HT_Away_Plus_1] = Qe.HT_Away_Plus_1, Ee), a[Je.HT_Handicap_Away_1] = ((ge = {})[Qe.HT_Home_Plus_1] = Qe.HT_Home_Plus_1, ge[Qe.HT_Away_Minus_1] = Qe.HT_Away_Minus_1, ge), a[Je.HT_Handicap_Home_1_25] = ((ke = {})[Qe.HT_Home_Minus_1_25] = Qe.HT_Home_Minus_1_25, ke[Qe.HT_Away_Plus_1_25] = Qe.HT_Away_Plus_1_25, ke), a[Je.HT_Handicap_Away_1_25] = ((qe = {})[Qe.HT_Home_Plus_1_25] = Qe.HT_Home_Plus_1_25, qe[Qe.HT_Away_Minus_1_25] = Qe.HT_Away_Minus_1_25, qe), a[Je.HT_Handicap_Home_1_5] = ((Me = {})[Qe.HT_Home_Minus_1_5] = Qe.HT_Home_Minus_1_5, Me[Qe.HT_Away_Plus_1_5] = Qe.HT_Away_Plus_1_5, Me), a[Je.HT_Handicap_Away_1_5] = ((Ce = {})[Qe.HT_Home_Plus_1_5] = Qe.HT_Home_Plus_1_5, Ce[Qe.HT_Away_Minus_1_5] = Qe.HT_Away_Minus_1_5, Ce), a[Je.HT_Handicap_Home_1_75] = ((Be = {})[Qe.HT_Home_Minus_1_75] = Qe.HT_Home_Minus_1_75, Be[Qe.HT_Away_Plus_1_75] = Qe.HT_Away_Plus_1_75, Be), a[Je.HT_Handicap_Away_1_75] = ((De = {})[Qe.HT_Home_Plus_1_75] = Qe.HT_Home_Plus_1_75, De[Qe.HT_Away_Minus_1_75] = Qe.HT_Away_Minus_1_75, De), a[Je.FT_OddEven] = ((Ge = {})[Qe.FT_Odd] = Qe.FT_Odd, Ge[Qe.FT_Even] = Qe.FT_Even, Ge), a[Je.Home_Total_Goals] = ((Re = {})[Qe.Home_0_Goals] = Qe.Home_0_Goals, Re[Qe.Home_1_Goals] = Qe.Home_1_Goals, Re[Qe.Home_2_Goals] = Qe.Home_2_Goals, Re[Qe.Home_3_Goals] = Qe.Home_3_Goals, Re[Qe.Home_4_Goals] = Qe.Home_4_Goals, Re[Qe.Home_5_Goals] = Qe.Home_5_Goals, Re[Qe.Home_6_Goals] = Qe.Home_6_Goals, Re), a[Je.Away_Total_Goals] = ((je = {})[Qe.Away_0_Goals] = Qe.Away_0_Goals, je[Qe.Away_1_Goals] = Qe.Away_1_Goals, je[Qe.Away_2_Goals] = Qe.Away_2_Goals, je[Qe.Away_3_Goals] = Qe.Away_3_Goals, je[Qe.Away_4_Goals] = Qe.Away_4_Goals, je[Qe.Away_5_Goals] = Qe.Away_5_Goals, je[Qe.Away_6_Goals] = Qe.Away_6_Goals, je), a[Je.Win_To_Nil] = ((Ie = {})[Qe.Home_Nil] = Qe.Home_Nil, Ie[Qe.Away_Nil] = Qe.Away_Nil, Ie), a[Je.Margin_Victory] = ((Le = {})[Qe.Home_By_1] = Qe.Home_By_1, Le[Qe.Home_By_2] = Qe.Home_By_2, Le[Qe.Home_By_3_More] = Qe.Home_By_3_More, Le[Qe.Away_By_1] = Qe.Away_By_1, Le[Qe.Away_By_2] = Qe.Away_By_2, Le[Qe.Away_By_3_More] = Qe.Away_By_3_More, Le[Qe.Draw_Goal_MV] = Qe.Draw_Goal_MV, Le[Qe.Draw_No_Goal_MV] = Qe.Draw_No_Goal_MV, Le), a[Je.HT_Over_Under_0_75] = ((Fe = {})[Qe.HT_under075] = Qe.HT_under075, Fe[Qe.HT_over075] = Qe.HT_over075, Fe), a[Je.HT_Over_Under_1] = ((Ue = {})[Qe.HT_under10] = Qe.HT_under10, Ue[Qe.HT_over10] = Qe.HT_over10, Ue), a[Je.HT_Over_Under_1_25] = ((Ne = {})[Qe.HT_under125] = Qe.HT_under125, Ne[Qe.HT_over125] = Qe.HT_over125, Ne), a[Je.HT_Over_Under_1_75] = ((We = {})[Qe.HT_under175] = Qe.HT_under175, We[Qe.HT_over175] = Qe.HT_over175, We), a[Je.HT_Over_Under_2] = ((Ve = {})[Qe.HT_under20] = Qe.HT_under20, Ve[Qe.HT_over20] = Qe.HT_over20, Ve), a), t.ChOddsTemplate = ((Ke = {})[Qe.Home] = Je.Match_Result, Ke[Qe.Away] = Je.Match_Result, Ke[Qe.Draw] = Je.Match_Result, Ke[Qe.HomeHome] = Je.Double_Result, Ke[Qe.HomeDraw] = Je.Double_Result, Ke[Qe.HomeAway] = Je.Double_Result, Ke[Qe.DrawHome] = Je.Double_Result, Ke[Qe.DrawDraw] = Je.Double_Result, Ke[Qe.DrawAway] = Je.Double_Result, Ke[Qe.AwayHome] = Je.Double_Result, Ke[Qe.AwayDraw] = Je.Double_Result, Ke[Qe.AwayAway] = Je.Double_Result, Ke[Qe.Draw_Away] = Je.Double_Chance, Ke[Qe.Home_Away] = Je.Double_Chance, Ke[Qe.Home_Draw] = Je.Double_Chance, Ke[Qe._0_0] = Je.Correct_Score, Ke[Qe._1_0] = Je.Correct_Score, Ke[Qe._2_0] = Je.Correct_Score, Ke[Qe._3_0] = Je.Correct_Score, Ke[Qe._4_0] = Je.Correct_Score, Ke[Qe._5_0] = Je.Correct_Score, Ke[Qe._6_0] = Je.Correct_Score, Ke[Qe._0_1] = Je.Correct_Score, Ke[Qe._1_1] = Je.Correct_Score, Ke[Qe._2_1] = Je.Correct_Score, Ke[Qe._3_1] = Je.Correct_Score, Ke[Qe._4_1] = Je.Correct_Score, Ke[Qe._5_1] = Je.Correct_Score, Ke[Qe._0_2] = Je.Correct_Score, Ke[Qe._1_2] = Je.Correct_Score, Ke[Qe._2_2] = Je.Correct_Score, Ke[Qe._3_2] = Je.Correct_Score, Ke[Qe._4_2] = Je.Correct_Score, Ke[Qe._0_3] = Je.Correct_Score, Ke[Qe._1_3] = Je.Correct_Score, Ke[Qe._2_3] = Je.Correct_Score, Ke[Qe._3_3] = Je.Correct_Score, Ke[Qe._0_4] = Je.Correct_Score, Ke[Qe._1_4] = Je.Correct_Score, Ke[Qe._2_4] = Je.Correct_Score, Ke[Qe._0_5] = Je.Correct_Score, Ke[Qe._1_5] = Je.Correct_Score, Ke[Qe._0_6] = Je.Correct_Score, Ke[Qe._0_Goals] = Je.Total_Goals, Ke[Qe._1_Goals] = Je.Total_Goals, Ke[Qe._2_Goals] = Je.Total_Goals, Ke[Qe._3_Goals] = Je.Total_Goals, Ke[Qe._4_Goals] = Je.Total_Goals, Ke[Qe._5_Goals] = Je.Total_Goals, Ke[Qe._6_Goals] = Je.Total_Goals, Ke[Qe.nog] = Je.GoalGoal_NoGoal, Ke[Qe.gg] = Je.GoalGoal_NoGoal, Ke[Qe.under_0_5] = Je.Over_Under_0_5, Ke[Qe.over_0_5] = Je.Over_Under_0_5, Ke[Qe.under_1_5] = Je.Over_Under_1_5, Ke[Qe.over_1_5] = Je.Over_Under_1_5, Ke[Qe.under_2_5] = Je.Over_Under_2_5, Ke[Qe.over_2_5] = Je.Over_Under_2_5, Ke[Qe.under_3_5] = Je.Over_Under_3_5, Ke[Qe.over_3_5] = Je.Over_Under_3_5, Ke[Qe.under_4_5] = Je.Over_Under_4_5, Ke[Qe.over_4_5] = Je.Over_Under_4_5, Ke[Qe.Home_Scores_Over_0_5] = Je.HomeAwayScores_Over_Under_0_5, Ke[Qe.Away_Scores_Over_0_5] = Je.HomeAwayScores_Over_Under_0_5, Ke[Qe.Home_Scores_Under_0_5] = Je.HomeAwayScores_Over_Under_0_5, Ke[Qe.Away_Scores_Under_0_5] = Je.HomeAwayScores_Over_Under_0_5, Ke[Qe.Home_Scores_Over_1_5] = Je.HomeAwayScores_Over_Under_1_5, Ke[Qe.Away_Scores_Over_1_5] = Je.HomeAwayScores_Over_Under_1_5, Ke[Qe.Home_Scores_Under_1_5] = Je.HomeAwayScores_Over_Under_1_5, Ke[Qe.Away_Scores_Under_1_5] = Je.HomeAwayScores_Over_Under_1_5, Ke[Qe.Home_Scores_Over_2_5] = Je.HomeAwayScores_Over_Under_2_5, Ke[Qe.Away_Scores_Over_2_5] = Je.HomeAwayScores_Over_Under_2_5, Ke[Qe.Home_Scores_Under_2_5] = Je.HomeAwayScores_Over_Under_2_5, Ke[Qe.Away_Scores_Under_2_5] = Je.HomeAwayScores_Over_Under_2_5, Ke[Qe.Home_Scores_Over_3_5] = Je.HomeAwayScores_Over_Under_3_5, Ke[Qe.Away_Scores_Over_3_5] = Je.HomeAwayScores_Over_Under_3_5, Ke[Qe.Home_Scores_Under_3_5] = Je.HomeAwayScores_Over_Under_3_5, Ke[Qe.Away_Scores_Under_3_5] = Je.HomeAwayScores_Over_Under_3_5, Ke[Qe._1x2_Home_Scores_Over_1_5] = Je._1x2_Scores_Over_Under_1_5, Ke[Qe._1x2_Draw_Scores_Over_1_5] = Je._1x2_Scores_Over_Under_1_5, Ke[Qe._1x2_Away_Scores_Over_1_5] = Je._1x2_Scores_Over_Under_1_5, Ke[Qe._1x2_Home_Scores_Under_1_5] = Je._1x2_Scores_Over_Under_1_5, Ke[Qe._1x2_Draw_Scores_Under_1_5] = Je._1x2_Scores_Over_Under_1_5, Ke[Qe._1x2_Away_Scores_Under_1_5] = Je._1x2_Scores_Over_Under_1_5, Ke[Qe._1x2_Home_Scores_Over_2_5] = Je._1x2_Scores_Over_Under_2_5, Ke[Qe._1x2_Draw_Scores_Over_2_5] = Je._1x2_Scores_Over_Under_2_5, Ke[Qe._1x2_Away_Scores_Over_2_5] = Je._1x2_Scores_Over_Under_2_5, Ke[Qe._1x2_Home_Scores_Under_2_5] = Je._1x2_Scores_Over_Under_2_5, Ke[Qe._1x2_Draw_Scores_Under_2_5] = Je._1x2_Scores_Over_Under_2_5, Ke[Qe._1x2_Away_Scores_Under_2_5] = Je._1x2_Scores_Over_Under_2_5, Ke[Qe._1x2_Home_Scores_Over_3_5] = Je._1x2_Scores_Over_Under_3_5, Ke[Qe._1x2_Draw_Scores_Over_3_5] = Je._1x2_Scores_Over_Under_3_5, Ke[Qe._1x2_Away_Scores_Over_3_5] = Je._1x2_Scores_Over_Under_3_5, Ke[Qe._1x2_Home_Scores_Under_3_5] = Je._1x2_Scores_Over_Under_3_5, Ke[Qe._1x2_Draw_Scores_Under_3_5] = Je._1x2_Scores_Over_Under_3_5, Ke[Qe._1x2_Away_Scores_Under_3_5] = Je._1x2_Scores_Over_Under_3_5, Ke[Qe.QHome] = Je.Qualify, Ke[Qe.QAway] = Je.Qualify, Ke[Qe.QHome_2] = Je.Qualify_2, Ke[Qe.QAway_2] = Je.Qualify_2, Ke[Qe.QHome_3] = Je.Qualify_3, Ke[Qe.QAway_3] = Je.Qualify_3, Ke[Qe.QHome_4] = Je.Qualify_4, Ke[Qe.QAway_4] = Je.Qualify_4, Ke[Qe._0_0_Goals] = Je.Multigoal, Ke[Qe._0_1_Goals] = Je.Multigoal, Ke[Qe._0_2_Goals] = Je.Multigoal, Ke[Qe._0_3_Goals] = Je.Multigoal, Ke[Qe._0_4_Goals] = Je.Multigoal, Ke[Qe._0_5_Goals] = Je.Multigoal, Ke[Qe._0_6_Goals] = Je.Multigoal, Ke[Qe._1_1_Goals] = Je.Multigoal, Ke[Qe._1_2_Goals] = Je.Multigoal, Ke[Qe._1_3_Goals] = Je.Multigoal, Ke[Qe._1_4_Goals] = Je.Multigoal, Ke[Qe._1_5_Goals] = Je.Multigoal, Ke[Qe._1_6_Goals] = Je.Multigoal, Ke[Qe._2_2_Goals] = Je.Multigoal, Ke[Qe._2_3_Goals] = Je.Multigoal, Ke[Qe._2_4_Goals] = Je.Multigoal, Ke[Qe._2_5_Goals] = Je.Multigoal, Ke[Qe._2_6_Goals] = Je.Multigoal, Ke[Qe._3_3_Goals] = Je.Multigoal, Ke[Qe._3_4_Goals] = Je.Multigoal, Ke[Qe._3_5_Goals] = Je.Multigoal, Ke[Qe._3_6_Goals] = Je.Multigoal, Ke[Qe._4_4_Goals] = Je.Multigoal, Ke[Qe._4_5_Goals] = Je.Multigoal, Ke[Qe._4_6_Goals] = Je.Multigoal, Ke[Qe._5_5_Goals] = Je.Multigoal, Ke[Qe._5_6_Goals] = Je.Multigoal, Ke[Qe._6_6_Goals] = Je.Multigoal, Ke[Qe._1H_Home] = Je.First_Half, Ke[Qe._1H_Draw] = Je.First_Half, Ke[Qe._1H_Away] = Je.First_Half, Ke[Qe.Home_0] = Je.Handicap_0, Ke[Qe.Away_0] = Je.Handicap_0, Ke[Qe.Home_Minus_0_25] = Je.Handicap_Home_0_25, Ke[Qe.Away_Plus_0_25] = Je.Handicap_Home_0_25, Ke[Qe.Home_Plus_0_25] = Je.Handicap_Away_0_25, Ke[Qe.Away_Minus_0_25] = Je.Handicap_Away_0_25, Ke[Qe.Home_Minus_0_5] = Je.Handicap_Home_0_5, Ke[Qe.Away_Plus_0_5] = Je.Handicap_Home_0_5, Ke[Qe.Home_Plus_0_5] = Je.Handicap_Away_0_5, Ke[Qe.Away_Minus_0_5] = Je.Handicap_Away_0_5, Ke[Qe.Home_Minus_0_75] = Je.Handicap_Home_0_75, Ke[Qe.Away_Plus_0_75] = Je.Handicap_Home_0_75, Ke[Qe.Home_Plus_0_75] = Je.Handicap_Away_0_75, Ke[Qe.Away_Minus_0_75] = Je.Handicap_Away_0_75, Ke[Qe.Home_Minus_1] = Je.Handicap_Home_1, Ke[Qe.Away_Plus_1] = Je.Handicap_Home_1, Ke[Qe.Home_Plus_1] = Je.Handicap_Away_1, Ke[Qe.Away_Minus_1] = Je.Handicap_Away_1, Ke[Qe.Home_Minus_1_25] = Je.Handicap_Home_1_25, Ke[Qe.Away_Plus_1_25] = Je.Handicap_Home_1_25, Ke[Qe.Home_Plus_1_25] = Je.Handicap_Away_1_25, Ke[Qe.Away_Minus_1_25] = Je.Handicap_Away_1_25, Ke[Qe.Home_Minus_1_5] = Je.Handicap_Home_1_5, Ke[Qe.Away_Plus_1_5] = Je.Handicap_Home_1_5, Ke[Qe.Home_Plus_1_5] = Je.Handicap_Away_1_5, Ke[Qe.Away_Minus_1_5] = Je.Handicap_Away_1_5, Ke[Qe.Home_Minus_1_75] = Je.Handicap_Home_1_75, Ke[Qe.Away_Plus_1_75] = Je.Handicap_Home_1_75, Ke[Qe.Home_Plus_1_75] = Je.Handicap_Away_1_75, Ke[Qe.Away_Minus_1_75] = Je.Handicap_Away_1_75, Ke[Qe.Home_Minus_2] = Je.Handicap_Home_2, Ke[Qe.Away_Plus_2] = Je.Handicap_Home_2, Ke[Qe.Home_Plus_2] = Je.Handicap_Away_2, Ke[Qe.Away_Minus_2] = Je.Handicap_Away_2, Ke[Qe.Home_Minus_2_25] = Je.Handicap_Home_2_25, Ke[Qe.Away_Plus_2_25] = Je.Handicap_Home_2_25, Ke[Qe.Home_Plus_2_25] = Je.Handicap_Away_2_25, Ke[Qe.Away_Minus_2_25] = Je.Handicap_Away_2_25, Ke[Qe.Home_Minus_2_5] = Je.Handicap_Home_2_5, Ke[Qe.Away_Plus_2_5] = Je.Handicap_Home_2_5, Ke[Qe.Home_Plus_2_5] = Je.Handicap_Away_2_5, Ke[Qe.Away_Minus_2_5] = Je.Handicap_Away_2_5, Ke[Qe.Home_Minus_2_75] = Je.Handicap_Home_2_75, Ke[Qe.Away_Plus_2_75] = Je.Handicap_Home_2_75, Ke[Qe.Home_Plus_2_75] = Je.Handicap_Away_2_75, Ke[Qe.Away_Minus_2_75] = Je.Handicap_Away_2_75, Ke[Qe.Home_Minus_3] = Je.Handicap_Home_3, Ke[Qe.Away_Plus_3] = Je.Handicap_Home_3, Ke[Qe.Home_Plus_3] = Je.Handicap_Away_3, Ke[Qe.Away_Minus_3] = Je.Handicap_Away_3, Ke[Qe.under_2_0] = Je.Over_Under_2, Ke[Qe.over_2_0] = Je.Over_Under_2, Ke[Qe.under_3_0] = Je.Over_Under_3, Ke[Qe.over_3_0] = Je.Over_Under_3, Ke[Qe.under_1_75] = Je.Over_Under_1_75, Ke[Qe.over_1_75] = Je.Over_Under_1_75, Ke[Qe.under_2_25] = Je.Over_Under_2_25, Ke[Qe.over_2_25] = Je.Over_Under_2_25, Ke[Qe.under_2_75] = Je.Over_Under_2_75, Ke[Qe.over_2_75] = Je.Over_Under_2_75, Ke[Qe.Home_1] = Je.FullTime_TotalGoals, Ke[Qe.Home_2] = Je.FullTime_TotalGoals, Ke[Qe.Home_3] = Je.FullTime_TotalGoals, Ke[Qe.Home_4] = Je.FullTime_TotalGoals, Ke[Qe.Home_5] = Je.FullTime_TotalGoals, Ke[Qe.Home_6] = Je.FullTime_TotalGoals, Ke[Qe.Draw_0] = Je.FullTime_TotalGoals, Ke[Qe.Draw_2] = Je.FullTime_TotalGoals, Ke[Qe.Draw_4] = Je.FullTime_TotalGoals, Ke[Qe.Draw_6] = Je.FullTime_TotalGoals, Ke[Qe.Away_1] = Je.FullTime_TotalGoals, Ke[Qe.Away_2] = Je.FullTime_TotalGoals, Ke[Qe.Away_3] = Je.FullTime_TotalGoals, Ke[Qe.Away_4] = Je.FullTime_TotalGoals, Ke[Qe.Away_5] = Je.FullTime_TotalGoals, Ke[Qe.Away_6] = Je.FullTime_TotalGoals, Ke[Qe.Home_Over_2_5_GG] = Je.FullTime_Under_Over_2_5_GoalGoal_NoGoal, Ke[Qe.Draw_Over_2_5_GG] = Je.FullTime_Under_Over_2_5_GoalGoal_NoGoal, Ke[Qe.Away_Over_2_5_GG] = Je.FullTime_Under_Over_2_5_GoalGoal_NoGoal, Ke[Qe.Home_Over_2_5_NG] = Je.FullTime_Under_Over_2_5_GoalGoal_NoGoal, Ke[Qe.Draw_Over_2_5_NG] = Je.FullTime_Under_Over_2_5_GoalGoal_NoGoal, Ke[Qe.Away_Over_2_5_NG] = Je.FullTime_Under_Over_2_5_GoalGoal_NoGoal, Ke[Qe.Home_Under_2_5_GG] = Je.FullTime_Under_Over_2_5_GoalGoal_NoGoal, Ke[Qe.Draw_Under_2_5_GG] = Je.FullTime_Under_Over_2_5_GoalGoal_NoGoal, Ke[Qe.Away_Under_2_5_GG] = Je.FullTime_Under_Over_2_5_GoalGoal_NoGoal, Ke[Qe.Home_Under_2_5_NG] = Je.FullTime_Under_Over_2_5_GoalGoal_NoGoal, Ke[Qe.Draw_Under_2_5_NG] = Je.FullTime_Under_Over_2_5_GoalGoal_NoGoal, Ke[Qe.Away_Under_2_5_NG] = Je.FullTime_Under_Over_2_5_GoalGoal_NoGoal, Ke[Qe.Euro_Home_Minus_1] = Je.Euro_Handicap_Home_1, Ke[Qe.Euro_Draw_Plus_1] = Je.Euro_Handicap_Home_1, Ke[Qe.Euro_Away_Plus_1] = Je.Euro_Handicap_Home_1, Ke[Qe.Euro_Home_Minus_2] = Je.Euro_Handicap_Home_2, Ke[Qe.Euro_Draw_Plus_2] = Je.Euro_Handicap_Home_2, Ke[Qe.Euro_Away_Plus_2] = Je.Euro_Handicap_Home_2, Ke[Qe.Euro_Home_Plus_1] = Je.Euro_Handicap_Away_1, Ke[Qe.Euro_Draw_Minus_1] = Je.Euro_Handicap_Away_1, Ke[Qe.Euro_Away_Minus_1] = Je.Euro_Handicap_Away_1, Ke[Qe.Euro_Home_Plus_2] = Je.Euro_Handicap_Away_2, Ke[Qe.Euro_Draw_Minus_2] = Je.Euro_Handicap_Away_2, Ke[Qe.Euro_Away_Minus_2] = Je.Euro_Handicap_Away_2, Ke[Qe._Home_0_0_Goals] = Je.HomeMultigoal_1_2, Ke[Qe._Home_1_2_Goals] = Je.HomeMultigoal_1_2, Ke[Qe._Home_3_More_Goals] = Je.HomeMultigoal_1_2, Ke[Qe._Away_0_0_Goals] = Je.AwayMultigoal_1_2, Ke[Qe._Away_1_2_Goals] = Je.AwayMultigoal_1_2, Ke[Qe._Away_3_More_Goals] = Je.AwayMultigoal_1_2, Ke[Qe._1H_0_0] = Je.Correct_Score_1H, Ke[Qe._1H_1_0] = Je.Correct_Score_1H, Ke[Qe._1H_2_0] = Je.Correct_Score_1H, Ke[Qe._1H_3_0] = Je.Correct_Score_1H, Ke[Qe._1H_0_1] = Je.Correct_Score_1H, Ke[Qe._1H_1_1] = Je.Correct_Score_1H, Ke[Qe._1H_2_1] = Je.Correct_Score_1H, Ke[Qe._1H_0_2] = Je.Correct_Score_1H, Ke[Qe._1H_1_2] = Je.Correct_Score_1H, Ke[Qe._1H_0_3] = Je.Correct_Score_1H, Ke[Qe._00_00] = Je.Correct_Score_HTFT, Ke[Qe._00_01] = Je.Correct_Score_HTFT, Ke[Qe._00_02] = Je.Correct_Score_HTFT, Ke[Qe._00_03] = Je.Correct_Score_HTFT, Ke[Qe._00_10] = Je.Correct_Score_HTFT, Ke[Qe._00_11] = Je.Correct_Score_HTFT, Ke[Qe._00_12] = Je.Correct_Score_HTFT, Ke[Qe._00_20] = Je.Correct_Score_HTFT, Ke[Qe._00_21] = Je.Correct_Score_HTFT, Ke[Qe._00_30] = Je.Correct_Score_HTFT, Ke[Qe._10_10] = Je.Correct_Score_HTFT, Ke[Qe._10_11] = Je.Correct_Score_HTFT, Ke[Qe._10_12] = Je.Correct_Score_HTFT, Ke[Qe._10_13] = Je.Correct_Score_HTFT, Ke[Qe._10_20] = Je.Correct_Score_HTFT, Ke[Qe._10_21] = Je.Correct_Score_HTFT, Ke[Qe._10_22] = Je.Correct_Score_HTFT, Ke[Qe._10_30] = Je.Correct_Score_HTFT, Ke[Qe._10_31] = Je.Correct_Score_HTFT, Ke[Qe._10_40] = Je.Correct_Score_HTFT, Ke[Qe._20_20] = Je.Correct_Score_HTFT, Ke[Qe._20_21] = Je.Correct_Score_HTFT, Ke[Qe._20_22] = Je.Correct_Score_HTFT, Ke[Qe._20_23] = Je.Correct_Score_HTFT, Ke[Qe._20_30] = Je.Correct_Score_HTFT, Ke[Qe._20_31] = Je.Correct_Score_HTFT, Ke[Qe._20_32] = Je.Correct_Score_HTFT, Ke[Qe._20_40] = Je.Correct_Score_HTFT, Ke[Qe._20_41] = Je.Correct_Score_HTFT, Ke[Qe._20_50] = Je.Correct_Score_HTFT, Ke[Qe._30_30] = Je.Correct_Score_HTFT, Ke[Qe._30_31] = Je.Correct_Score_HTFT, Ke[Qe._30_32] = Je.Correct_Score_HTFT, Ke[Qe._30_33] = Je.Correct_Score_HTFT, Ke[Qe._30_40] = Je.Correct_Score_HTFT, Ke[Qe._30_41] = Je.Correct_Score_HTFT, Ke[Qe._30_42] = Je.Correct_Score_HTFT, Ke[Qe._30_50] = Je.Correct_Score_HTFT, Ke[Qe._30_51] = Je.Correct_Score_HTFT, Ke[Qe._30_60] = Je.Correct_Score_HTFT, Ke[Qe._01_01] = Je.Correct_Score_HTFT, Ke[Qe._01_02] = Je.Correct_Score_HTFT, Ke[Qe._01_03] = Je.Correct_Score_HTFT, Ke[Qe._01_04] = Je.Correct_Score_HTFT, Ke[Qe._01_11] = Je.Correct_Score_HTFT, Ke[Qe._01_12] = Je.Correct_Score_HTFT, Ke[Qe._01_13] = Je.Correct_Score_HTFT, Ke[Qe._01_21] = Je.Correct_Score_HTFT, Ke[Qe._01_22] = Je.Correct_Score_HTFT, Ke[Qe._01_31] = Je.Correct_Score_HTFT, Ke[Qe._11_11] = Je.Correct_Score_HTFT, Ke[Qe._11_12] = Je.Correct_Score_HTFT, Ke[Qe._11_13] = Je.Correct_Score_HTFT, Ke[Qe._11_14] = Je.Correct_Score_HTFT, Ke[Qe._11_21] = Je.Correct_Score_HTFT, Ke[Qe._11_22] = Je.Correct_Score_HTFT, Ke[Qe._11_23] = Je.Correct_Score_HTFT, Ke[Qe._11_31] = Je.Correct_Score_HTFT, Ke[Qe._11_32] = Je.Correct_Score_HTFT, Ke[Qe._11_41] = Je.Correct_Score_HTFT, Ke[Qe._21_21] = Je.Correct_Score_HTFT, Ke[Qe._21_22] = Je.Correct_Score_HTFT, Ke[Qe._21_23] = Je.Correct_Score_HTFT, Ke[Qe._21_24] = Je.Correct_Score_HTFT, Ke[Qe._21_31] = Je.Correct_Score_HTFT, Ke[Qe._21_32] = Je.Correct_Score_HTFT, Ke[Qe._21_33] = Je.Correct_Score_HTFT, Ke[Qe._21_41] = Je.Correct_Score_HTFT, Ke[Qe._21_42] = Je.Correct_Score_HTFT, Ke[Qe._21_51] = Je.Correct_Score_HTFT, Ke[Qe._02_02] = Je.Correct_Score_HTFT, Ke[Qe._02_03] = Je.Correct_Score_HTFT, Ke[Qe._02_04] = Je.Correct_Score_HTFT, Ke[Qe._02_05] = Je.Correct_Score_HTFT, Ke[Qe._02_12] = Je.Correct_Score_HTFT, Ke[Qe._02_13] = Je.Correct_Score_HTFT, Ke[Qe._02_14] = Je.Correct_Score_HTFT, Ke[Qe._02_22] = Je.Correct_Score_HTFT, Ke[Qe._02_23] = Je.Correct_Score_HTFT, Ke[Qe._02_32] = Je.Correct_Score_HTFT, Ke[Qe._12_12] = Je.Correct_Score_HTFT, Ke[Qe._12_13] = Je.Correct_Score_HTFT, Ke[Qe._12_14] = Je.Correct_Score_HTFT, Ke[Qe._12_15] = Je.Correct_Score_HTFT, Ke[Qe._12_22] = Je.Correct_Score_HTFT, Ke[Qe._12_23] = Je.Correct_Score_HTFT, Ke[Qe._12_24] = Je.Correct_Score_HTFT, Ke[Qe._12_32] = Je.Correct_Score_HTFT, Ke[Qe._12_33] = Je.Correct_Score_HTFT, Ke[Qe._12_42] = Je.Correct_Score_HTFT, Ke[Qe._03_03] = Je.Correct_Score_HTFT, Ke[Qe._03_04] = Je.Correct_Score_HTFT, Ke[Qe._03_05] = Je.Correct_Score_HTFT, Ke[Qe._03_06] = Je.Correct_Score_HTFT, Ke[Qe._03_13] = Je.Correct_Score_HTFT, Ke[Qe._03_14] = Je.Correct_Score_HTFT, Ke[Qe._03_15] = Je.Correct_Score_HTFT, Ke[Qe._03_23] = Je.Correct_Score_HTFT, Ke[Qe._03_24] = Je.Correct_Score_HTFT, Ke[Qe._03_33] = Je.Correct_Score_HTFT, Ke[Qe.Home_GoalGoal] = Je.FullTime_GoalGoalNoGoal, Ke[Qe.Draw_GoalGoal] = Je.FullTime_GoalGoalNoGoal, Ke[Qe.Away_GoalGoal] = Je.FullTime_GoalGoalNoGoal, Ke[Qe.Home_NoGoal] = Je.FullTime_GoalGoalNoGoal, Ke[Qe.Draw_NoGoal] = Je.FullTime_GoalGoalNoGoal, Ke[Qe.Away_NoGoal] = Je.FullTime_GoalGoalNoGoal, Ke[Qe.HT_Draw_Away] = Je.HT_Double_Chance, Ke[Qe.HT_Home_Away] = Je.HT_Double_Chance, Ke[Qe.HT_Home_Draw] = Je.HT_Double_Chance, Ke[Qe.HT_nog] = Je.HT_GoalGoal_NoGoal, Ke[Qe.HT_gg] = Je.HT_GoalGoal_NoGoal, Ke[Qe.HT_Odd] = Je.HT_OddEven, Ke[Qe.HT_Even] = Je.HT_OddEven, Ke[Qe.HT_under05] = Je.HT_Over_Under_0_5, Ke[Qe.HT_over05] = Je.HT_Over_Under_0_5, Ke[Qe.HT_under15] = Je.HT_Over_Under_1_5, Ke[Qe.HT_over15] = Je.HT_Over_Under_1_5, Ke[Qe.HT_0_Goals] = Je.HT_Total_Goals, Ke[Qe.HT_1_Goals] = Je.HT_Total_Goals, Ke[Qe.HT_2_Goals] = Je.HT_Total_Goals, Ke[Qe.HT_3_Goals] = Je.HT_Total_Goals, Ke[Qe.HT_Home_0] = Je.HT_Handicap_0, Ke[Qe.HT_Away_0] = Je.HT_Handicap_0, Ke[Qe.HT_Home_Minus_0_25] = Je.HT_Handicap_Home_0_25, Ke[Qe.HT_Away_Plus_0_25] = Je.HT_Handicap_Home_0_25, Ke[Qe.HT_Home_Plus_0_25] = Je.HT_Handicap_Away_0_25, Ke[Qe.HT_Away_Minus_0_25] = Je.HT_Handicap_Away_0_25, Ke[Qe.HT_Home_Minus_0_5] = Je.HT_Handicap_Home_0_5, Ke[Qe.HT_Away_Plus_0_5] = Je.HT_Handicap_Home_0_5, Ke[Qe.HT_Home_Plus_0_5] = Je.HT_Handicap_Away_0_5, Ke[Qe.HT_Away_Minus_0_5] = Je.HT_Handicap_Away_0_5, Ke[Qe.HT_Home_Minus_0_75] = Je.HT_Handicap_Home_0_75, Ke[Qe.HT_Away_Plus_0_75] = Je.HT_Handicap_Home_0_75, Ke[Qe.HT_Home_Plus_0_75] = Je.HT_Handicap_Away_0_75, Ke[Qe.HT_Away_Minus_0_75] = Je.HT_Handicap_Away_0_75, Ke[Qe.HT_Home_Minus_1] = Je.HT_Handicap_Home_1, Ke[Qe.HT_Away_Plus_1] = Je.HT_Handicap_Home_1, Ke[Qe.HT_Home_Plus_1] = Je.HT_Handicap_Away_1, Ke[Qe.HT_Away_Minus_1] = Je.HT_Handicap_Away_1, Ke[Qe.HT_Home_Minus_1_25] = Je.HT_Handicap_Home_1_25, Ke[Qe.HT_Away_Plus_1_25] = Je.HT_Handicap_Home_1_25, Ke[Qe.HT_Home_Plus_1_25] = Je.HT_Handicap_Away_1_25, Ke[Qe.HT_Away_Minus_1_25] = Je.HT_Handicap_Away_1_25, Ke[Qe.HT_Home_Minus_1_5] = Je.HT_Handicap_Home_1_5, Ke[Qe.HT_Away_Plus_1_5] = Je.HT_Handicap_Home_1_5, Ke[Qe.HT_Home_Plus_1_5] = Je.HT_Handicap_Away_1_5, Ke[Qe.HT_Away_Minus_1_5] = Je.HT_Handicap_Away_1_5, Ke[Qe.HT_Home_Minus_1_75] = Je.HT_Handicap_Home_1_75, Ke[Qe.HT_Away_Plus_1_75] = Je.HT_Handicap_Home_1_75, Ke[Qe.HT_Home_Plus_1_75] = Je.HT_Handicap_Away_1_75, Ke[Qe.HT_Away_Minus_1_75] = Je.HT_Handicap_Away_1_75, Ke[Qe.FT_Odd] = Je.FT_OddEven, Ke[Qe.FT_Even] = Je.FT_OddEven, Ke[Qe.Home_0_Goals] = Je.Home_Total_Goals, Ke[Qe.Home_1_Goals] = Je.Home_Total_Goals, Ke[Qe.Home_2_Goals] = Je.Home_Total_Goals, Ke[Qe.Home_3_Goals] = Je.Home_Total_Goals, Ke[Qe.Home_4_Goals] = Je.Home_Total_Goals, Ke[Qe.Home_5_Goals] = Je.Home_Total_Goals, Ke[Qe.Home_6_Goals] = Je.Home_Total_Goals, Ke[Qe.Away_0_Goals] = Je.Away_Total_Goals, Ke[Qe.Away_1_Goals] = Je.Away_Total_Goals, Ke[Qe.Away_2_Goals] = Je.Away_Total_Goals, Ke[Qe.Away_3_Goals] = Je.Away_Total_Goals, Ke[Qe.Away_4_Goals] = Je.Away_Total_Goals, Ke[Qe.Away_5_Goals] = Je.Away_Total_Goals, Ke[Qe.Away_6_Goals] = Je.Away_Total_Goals, Ke[Qe.Home_Nil] = Je.Win_To_Nil, Ke[Qe.Away_Nil] = Je.Win_To_Nil, Ke[Qe.Home_By_1] = Je.Margin_Victory, Ke[Qe.Home_By_2] = Je.Margin_Victory, Ke[Qe.Home_By_3_More] = Je.Margin_Victory, Ke[Qe.Away_By_1] = Je.Margin_Victory, Ke[Qe.Away_By_2] = Je.Margin_Victory, Ke[Qe.Away_By_3_More] = Je.Margin_Victory, Ke[Qe.Draw_Goal_MV] = Je.Margin_Victory, Ke[Qe.Draw_No_Goal_MV] = Je.Margin_Victory, Ke[Qe.HT_under075] = Je.HT_Over_Under_0_75, Ke[Qe.HT_over075] = Je.HT_Over_Under_0_75, Ke[Qe.HT_under10] = Je.HT_Over_Under_1, Ke[Qe.HT_over10] = Je.HT_Over_Under_1, Ke[Qe.HT_under125] = Je.HT_Over_Under_1_25, Ke[Qe.HT_over125] = Je.HT_Over_Under_1_25, Ke[Qe.HT_under175] = Je.HT_Over_Under_1_75, Ke[Qe.HT_over175] = Je.HT_Over_Under_1_75, Ke[Qe.HT_under20] = Je.HT_Over_Under_2, Ke[Qe.HT_over20] = Je.HT_Over_Under_2, Ke)
        },
        AvU4: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.key = e.key, this.countdown = e.countdown, this.offset = e.offset)
            };
            t.PlaylistItemContent = a
        },
        BRRI: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "DogViewerProfileGameSettings", t && (_.trifectaLayout6paticipant = t.trifectaLayout6paticipant), _
                }
                return n(t, e), t
            }(_("PBHJ").ViewerProfileGameSettings);
            t.DogViewerProfileGameSettings = r,
                function(e) {
                    ! function(e) {
                        e.LEGACY = "LEGACY", e.COMPACT = "COMPACT"
                    }(e.TrifectaLayout6paticipantEnum || (e.TrifectaLayout6paticipantEnum = {}))
                }(r = t.DogViewerProfileGameSettings || (t.DogViewerProfileGameSettings = {})), t.DogViewerProfileGameSettings = r
        },
        BgMb: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "SnViewerProfileGameSettings", _
                }
                return n(t, e), t
            }(_("PBHJ").ViewerProfileGameSettings);
            t.SnViewerProfileGameSettings = r
        },
        ButT: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.time = e.time, this.event = e.event, this.team = e.team, this.playerId = e.playerId, this.points = e.points)
            };
            t.BasketVideoHappening = a,
                function(e) {
                    ! function(e) {
                        e.BEGIN = "BEGIN", e.END = "END", e.PLAY = "PLAY", e.PAUSE = "PAUSE", e.EXTRATIME = "EXTRATIME", e.POSSESSIONRED = "POSSESSIONRED", e.POSSESSIONBLUE = "POSSESSIONBLUE", e.ENDPOSSESION = "ENDPOSSESION", e.ANNOTATION = "ANNOTATION", e.STALLING = "STALLING", e.OUTRED = "OUTRED", e.OUTBLUE = "OUTBLUE", e.FREETHROW1 = "FREETHROW1", e.FREETHROW2 = "FREETHROW2", e.WIN21RED = "WIN21RED", e.WIN21BLUE = "WIN21BLUE", e.WINTIMERED = "WINTIMERED", e.WINTIMEBLUE = "WINTIMEBLUE", e.RESTIMEDRAW = "RESTIMEDRAW", e.WINEXTRATIMERED = "WINEXTRATIMERED", e.WINEXTRATIMEBLUE = "WINEXTRATIMEBLUE"
                    }(e.EventEnum || (e.EventEnum = {}))
                }(a = t.BasketVideoHappening || (t.BasketVideoHappening = {})), t.BasketVideoHappening = a,
                function(e) {
                    ! function(e) {
                        e.RED = "RED", e.BLUE = "BLUE"
                    }(e.TeamEnum || (e.TeamEnum = {}))
                }(a = t.BasketVideoHappening || (t.BasketVideoHappening = {})), t.BasketVideoHappening = a
        },
        "C/Tt": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.city = e.city, e.date ? this.date = new Date(e.date.toString()) : this.date = null, this.prize = e.prize)
            };
            t.Record = a
        },
        C30d: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "AccumulatedRound", _
                }
                return n(t, e), t
            }(_("IJP8").CurrencyPolicy);
            t.AccumulatedRound = r
        },
        CDyC: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.id = e.id, this.name = e.name, this.nation = e.nation, this.wins = e.wins, this.winsByKO = e.winsByKO, this.draws = e.draws, this.lost = e.lost)
            };
            t.FightClassificationEntry = a
        },
        CV3a: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function() {
                    function e(e, t) {
                        if (void 0 === t && (t = !0), e && (this.classType = e.classType, this.taxPercent = e.taxPercent, t && this.classType)) switch (this.classType) {
                            case "CustomThresholdTax":
                                return new a.CustomThresholdTax(e);
                            case "CustomTax":
                                return new a.CustomTax(e)
                        }
                    }
                    return e.prototype.isCustomThresholdTax = function() {
                        return "CustomThresholdTax" === this.classType
                    }, e.prototype.isCustomTax = function() {
                        return "CustomTax" === this.classType
                    }, e
                }();
            t.BasicTax = n
        },
        CWkR: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e) {
                    e.ENABLED = "ENABLED", e.TEST = "TEST", e.DISABLED = "DISABLED", e.DELETED = "DELETED"
                }(t.EntityStatus || (t.EntityStatus = {}))
        },
        CgkD: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function() {
                    function e(e, t) {
                        if (void 0 === t && (t = !0), e && (this.classType = e.classType, t && this.classType)) switch (this.classType) {
                            case "LottofiveEventBlockLiveStats":
                                return new a.LottofiveEventBlockLiveStats(e);
                            case "S7EventBlockLiveStats":
                                return new a.S7EventBlockLiveStats(e);
                            case "LlEventBlockLiveStats":
                                return new a.LlEventBlockLiveStats(e)
                        }
                    }
                    return e.prototype.isLottofiveEventBlockLiveStats = function() {
                        return "LottofiveEventBlockLiveStats" === this.classType
                    }, e.prototype.isS7EventBlockLiveStats = function() {
                        return "S7EventBlockLiveStats" === this.classType
                    }, e.prototype.isLlEventBlockLiveStats = function() {
                        return "LlEventBlockLiveStats" === this.classType
                    }, e
                }();
            t.EventBlockLiveStats = n
        },
        CtvJ: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.val = e.val)
            };
            t.GameType = a,
                function(e) {
                    ! function(e) {
                        e.CH = "CH", e.DIRTTRACK = "DIRTTRACK", e.DOG = "DOG", e.HORSE = "HORSE", e.KART = "KART", e.KN = "KN", e.LOTTOFIVE = "LOTTOFIVE", e.LL = "LL", e.MOTORBIKE = "MOTORBIKE", e.S7 = "S7", e.SN = "SN", e.SPEEDWAY = "SPEEDWAY", e.SX = "SX", e.S2W = "S2W", e.TROTTING = "TROTTING", e.BASKET = "BASKET", e.FIGHT = "FIGHT"
                    }(e.ValEnum || (e.ValEnum = {}))
                }(a = t.GameType || (t.GameType = {})), t.GameType = a
        },
        CvL3: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "DirttrackViewerProfileGameSettings", _
                }
                return n(t, e), t
            }(_("PBHJ").ViewerProfileGameSettings);
            t.DirttrackViewerProfileGameSettings = r
        },
        DCbq: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "PlaylistContent", t && (_.playlistId = t.playlistId, _.countdown = t.countdown, _.offset = t.offset), _
                }
                return n(t, e), t
            }(_("RKrn").Content);
            t.PlaylistContent = r
        },
        DFK9: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.ticketPromotionalText = e.ticketPromotionalText, this.ticketTopUrl = e.ticketTopUrl, this.headerTicketText01 = e.headerTicketText01, this.headerTicketText02 = e.headerTicketText02, this.headerTicketText03 = e.headerTicketText03, this.bottomTicketText01 = e.bottomTicketText01, this.bottomTicketText02 = e.bottomTicketText02, this.bottomTicketText03 = e.bottomTicketText03, this.legalText = e.legalText, this.printCompactPayout = e.printCompactPayout, this.printCompactBetTicket = e.printCompactBetTicket, this.showUnitName = e.showUnitName, this.ticketFormat = e.ticketFormat, this.checkTicketMode = e.checkTicketMode, this.showMaxPayout = e.showMaxPayout, this.printMaxWinPerTip = e.printMaxWinPerTip)
            };
            t.PrintProfileSettings = a,
                function(e) {
                    ! function(e) {
                        e.MM80 = "MM80", e.MM58 = "MM58", e.A6 = "A6"
                    }(e.TicketFormatEnum || (e.TicketFormatEnum = {}))
                }(a = t.PrintProfileSettings || (t.PrintProfileSettings = {})), t.PrintProfileSettings = a,
                function(e) {
                    ! function(e) {
                        e.BARCODE = "BARCODE"
                    }(e.CheckTicketModeEnum || (e.CheckTicketModeEnum = {}))
                }(a = t.PrintProfileSettings || (t.PrintProfileSettings = {})), t.PrintProfileSettings = a
        },
        Dhrw: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function() {
                    function e(e, t) {
                        if (void 0 === t && (t = !0), e && (this.classType = e.classType, t && this.classType)) switch (this.classType) {
                            case "ChTicketEventData":
                                return new a.ChTicketEventData(e);
                            case "SxTicketEventData":
                                return new a.SxTicketEventData(e);
                            case "BasketTicketEventData":
                                return new a.BasketTicketEventData(e);
                            case "LottofiveTicketEventData":
                                return new a.LottofiveTicketEventData(e)
                        }
                    }
                    return e.prototype.isChTicketEventData = function() {
                        return "ChTicketEventData" === this.classType
                    }, e.prototype.isSxTicketEventData = function() {
                        return "SxTicketEventData" === this.classType
                    }, e.prototype.isBasketTicketEventData = function() {
                        return "BasketTicketEventData" === this.classType
                    }, e.prototype.isLottofiveTicketEventData = function() {
                        return "LottofiveTicketEventData" === this.classType
                    }, e
                }();
            t.TicketEventData = n
        },
        E8xZ: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "KnViewerProfileGameSettings", _
                }
                return n(t, e), t
            }(_("PBHJ").ViewerProfileGameSettings);
            t.KnViewerProfileGameSettings = r
        },
        EBnV: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                var t = this;
                this.drawResult = [], this.drawMachine = [], e && (this.drawId = e.drawId, e.drawResult && e.drawResult.forEach((function(e) {
                    t.drawResult.push(e)
                })), e.drawMachine && e.drawMachine.forEach((function(e) {
                    t.drawMachine.push(e)
                })))
            };
            t.LottofiveDrawResult = a
        },
        EEXW: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.gameSettings = [], e && e.gameSettings && e.gameSettings.forEach((function(e) {
                        t.gameSettings.push(new a.WebProfileGameSettings(e))
                    }))
                };
            t.WebProfileSettings = n
        },
        EL6m: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "LottofiveEventBlockLiveStats", _.result = [], t && t.result && t.result.forEach((function(e) {
                            _.result.push(new r.LottofiveDrawResult(e))
                        })), _
                    }
                    return n(t, e), t
                }(_("CgkD").EventBlockLiveStats);
            t.LottofiveEventBlockLiveStats = o
        },
        "EQ+K": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.playlistId = e.playlistId, this.stake = e.stake, this.stakeCancelled = e.stakeCancelled, this.directCashIn = e.directCashIn, this.paidOut = e.paidOut, this.jackpotPaidOut = e.jackpotPaidOut, this.megaJackpotPaidOut = e.megaJackpotPaidOut, this.bonusPaidOut = e.bonusPaidOut, this.cappedPaidOut = e.cappedPaidOut, this.directCashOut = e.directCashOut, this.won = e.won, this.jackpotWon = e.jackpotWon, this.megaJackpotWon = e.megaJackpotWon, this.bonusWon = e.bonusWon, this.cappedWon = e.cappedWon, this.stakeTaxes = e.stakeTaxes, this.stakeCancelledTaxes = e.stakeCancelledTaxes, this.paidOutTaxes = e.paidOutTaxes, this.jackpotContribution = e.jackpotContribution, this.megaJackpotContribution = e.megaJackpotContribution)
            };
            t.SettlementReportLineData = a
        },
        ERXD: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.limitMaxPayout = e.limitMaxPayout, this.minWinning = e.minWinning, this.maxWinning = e.maxWinning, this.minBonus = e.minBonus, this.maxBonus = e.maxBonus, this.winningCount = e.winningCount)
            };
            t.WinningData = a
        },
        EgGy: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "KartGameOddSettings", _
                }
                return n(t, e), t
            }(_("aDCO").GameFixedOddSettings);
            t.KartGameOddSettings = r
        },
        EoUS: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "ChCashierProfileGameSettings", t && (_.teamNameTextType = t.teamNameTextType), _
                }
                return n(t, e), t
            }(_("nfOZ").CashierProfileGameSettings);
            t.ChCashierProfileGameSettings = r,
                function(e) {
                    ! function(e) {
                        e._3LETTERS = "_3LETTERS", e.FULLTEAMNAME = "FULLTEAMNAME"
                    }(e.TeamNameTextTypeEnum || (e.TeamNameTextTypeEnum = {}))
                }(r = t.ChCashierProfileGameSettings || (t.ChCashierProfileGameSettings = {})), t.ChCashierProfileGameSettings = r
        },
        Eyd3: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "NoTaxPolicy", _
                }
                return n(t, e), t
            }(_("PtXo").TaxPolicy);
            t.NoTaxPolicy = r
        },
        F6TW: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "LottofiveGameEventData", t && (_.extId = t.extId, _.name = t.name, _.croupierName = t.croupierName, _.videoUrl = t.videoUrl, _.backupVideoUrl = t.backupVideoUrl, _.numDraws = t.numDraws, _.minDrawValue = t.minDrawValue, _.maxDrawValue = t.maxDrawValue, _.minNumSelections = t.minNumSelections, _.maxNumSelections = t.maxNumSelections), _
                }
                return n(t, e), t
            }(_("VqjV").GameEventData);
            t.LottofiveGameEventData = r
        },
        F75B: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "SxViewerProfileGameSettings", t && (_.mode = t.mode), _
                }
                return n(t, e), t
            }(_("PBHJ").ViewerProfileGameSettings);
            t.SxViewerProfileGameSettings = r,
                function(e) {
                    ! function(e) {
                        e.DEFAULT = "DEFAULT"
                    }(e.ModeEnum || (e.ModeEnum = {}))
                }(r = t.SxViewerProfileGameSettings || (t.SxViewerProfileGameSettings = {})), t.SxViewerProfileGameSettings = r
        },
        FGXa: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "KnEventBlockStats", _.historic = [], t && t.historic && t.historic.forEach((function(e) {
                        _.historic.push(e)
                    })), _
                }
                return n(t, e), t
            }(_("HZPa").EventBlockStats);
            t.KnEventBlockStats = r
        },
        FP6H: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "LlEventStats", _.historic = [], t && t.historic && t.historic.forEach((function(e) {
                        _.historic.push(e)
                    })), _
                }
                return n(t, e), t
            }(_("NbOC").EventStats);
            t.LlEventStats = r
        },
        FRGB: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "FightParticipant", t && (_.name = t.name, _.nation = t.nation, _.age = t.age, _.height = t.height, _.weight = t.weight, _.rating = t.rating), _
                }
                return n(t, e), t
            }(_("Kb6+").Participant);
            t.FightParticipant = r
        },
        GVlk: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "BasketEventResultData", _.videoSlots = [], t && (_.resultPointsPregameRed = t.resultPointsPregameRed, _.resultPointsPregameBlue = t.resultPointsPregameBlue, _.resultPointsEndMatchRed = t.resultPointsEndMatchRed, _.resultPointsEndMatchBlue = t.resultPointsEndMatchBlue, _.hlsURL = t.hlsURL, t.videoSlots && t.videoSlots.forEach((function(e) {
                            _.videoSlots.push(new r.BasketVideoSlot(e))
                        }))), _
                    }
                    return n(t, e), t
                }(_("RUMs").EventResultData);
            t.BasketEventResultData = o
        },
        Ginh: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                var t = this;
                this.tags = [], e && (e.startDate ? this.startDate = new Date(e.startDate.toString()) : this.startDate = null, e.endDate ? this.endDate = new Date(e.endDate.toString()) : this.endDate = null, this.entityClientId = e.entityClientId, this.entityId = e.entityId, this.entityPlayed = e.entityPlayed, this.currency = e.currency, this.gameType = e.gameType, this.market = e.market, this.selection = e.selection, this.stake = e.stake, this.stakeCancelled = e.stakeCancelled, this.won = e.won, this.paid = e.paid, this.playlist = e.playlist, this.betCount = e.betCount, this.timezone = e.timezone, this.groupBy = e.groupBy, this.wonCount = e.wonCount, this.bonus = e.bonus, this.jackpot = e.jackpot, this.jackpotContribution = e.jackpotContribution, this.jackpotPaid = e.jackpotPaid, this.megajackpot = e.megajackpot, this.megajackpotContribution = e.megajackpotContribution, this.megajackpotPaid = e.megajackpotPaid, e.tags && e.tags.forEach((function(e) {
                    t.tags.push(e)
                })))
            };
            t.StatDetail = a
        },
        H1Ir: function(e, t, _) {
            "use strict";
            var a, n, r, o, i, s, c;
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e) {
                    e.numbers = "numbers", e.positions = "positions", e.colours = "colours"
                }(s = t.LottofiveMarkets || (t.LottofiveMarkets = {})),
                function(e) {
                    e.n1 = "n1", e.n2 = "n2", e.n3 = "n3", e.n4 = "n4", e.n5 = "n5", e.first_drawn = "first_drawn", e.green_4_plus = "green_4_plus", e.green_5 = "green_5", e.yellow_4_plus = "yellow_4_plus", e.yellow_5 = "yellow_5", e.red_4_plus = "red_4_plus", e.red_5 = "red_5"
                }(c = t.LottofiveOdds || (t.LottofiveOdds = {})), t.LottofiveMarketsTemplate = ((a = {})[s.numbers] = ((n = {})[c.n1] = c.n1, n[c.n2] = c.n2, n[c.n3] = c.n3, n[c.n4] = c.n4, n[c.n5] = c.n5, n), a[s.positions] = ((r = {})[c.first_drawn] = c.first_drawn, r), a[s.colours] = ((o = {})[c.green_4_plus] = c.green_4_plus, o[c.green_5] = c.green_5, o[c.yellow_4_plus] = c.yellow_4_plus, o[c.yellow_5] = c.yellow_5, o[c.red_4_plus] = c.red_4_plus, o[c.red_5] = c.red_5, o), a), t.LottofiveOddsTemplate = ((i = {})[c.n1] = s.numbers, i[c.n2] = s.numbers, i[c.n3] = s.numbers, i[c.n4] = s.numbers, i[c.n5] = s.numbers, i[c.first_drawn] = s.positions, i[c.green_4_plus] = s.colours, i[c.green_5] = s.colours, i[c.yellow_4_plus] = s.colours, i[c.yellow_5] = s.colours, i[c.red_4_plus] = s.colours, i[c.red_5] = s.colours, i)
        },
        "HCe/": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.gameSettings = [], e && (this.logoPosition = e.logoPosition, this.absolutTimeDisplay = e.absolutTimeDisplay, this.allowStreaming = e.allowStreaming, this.autoRestart = e.autoRestart, this.jackpotCelebrationType = e.jackpotCelebrationType, e.gameSettings && e.gameSettings.forEach((function(e) {
                        t.gameSettings.push(new a.ViewerProfileGameSettings(e))
                    })))
                };
            t.ViewerProfileSettings = n,
                function(e) {
                    ! function(e) {
                        e.RIGHT = "RIGHT"
                    }(e.LogoPositionEnum || (e.LogoPositionEnum = {}))
                }(n = t.ViewerProfileSettings || (t.ViewerProfileSettings = {})), t.ViewerProfileSettings = n,
                function(e) {
                    ! function(e) {
                        e.SHOW = "SHOW", e.HIDE = "HIDE"
                    }(e.AbsolutTimeDisplayEnum || (e.AbsolutTimeDisplayEnum = {}))
                }(n = t.ViewerProfileSettings || (t.ViewerProfileSettings = {})), t.ViewerProfileSettings = n,
                function(e) {
                    ! function(e) {
                        e.DEFAULT = "DEFAULT", e.COMPACT = "COMPACT"
                    }(e.JackpotCelebrationTypeEnum || (e.JackpotCelebrationTypeEnum = {}))
                }(n = t.ViewerProfileSettings || (t.ViewerProfileSettings = {})), t.ViewerProfileSettings = n
        },
        HVQ5: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.capabilities = [], this.marketTemplates = [], this.participantTemplates = [], this.schedulerConfiguration = [], e && (this.id = e.id, this.gameType = e.gameType ? new a.GameType(e.gameType) : null, this.mode = e.mode, this.filter = e.filter ? new a.Filter(e.filter) : null, this.assets = e.assets ? new a.Assets(e.assets) : null, e.capabilities && e.capabilities.forEach((function(e) {
                        t.capabilities.push(new a.Capability(e))
                    })), e.marketTemplates && e.marketTemplates.forEach((function(e) {
                        t.marketTemplates.push(new a.Market(e))
                    })), e.participantTemplates && e.participantTemplates.forEach((function(e) {
                        t.participantTemplates.push(new a.Participant(e))
                    })), this.description = e.description, this.descriptionTag = e.descriptionTag, e.schedulerConfiguration && e.schedulerConfiguration.forEach((function(e) {
                        t.schedulerConfiguration.push(new a.SchedulerConfiguration(e))
                    })))
                };
            t.Playlist = n,
                function(e) {
                    ! function(e) {
                        e.SCHEDULED = "SCHEDULED", e.ONDEMAND = "ONDEMAND", e.LIVE = "LIVE"
                    }(e.ModeEnum || (e.ModeEnum = {}))
                }(n = t.Playlist || (t.Playlist = {})), t.Playlist = n
        },
        HZPa: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function() {
                    function e(e, t) {
                        if (void 0 === t && (t = !0), e && (this.classType = e.classType, t && this.classType)) switch (this.classType) {
                            case "LottofiveEventBlockStats":
                                return new a.LottofiveEventBlockStats(e);
                            case "LlEventBlockStats":
                                return new a.LlEventBlockStats(e);
                            case "SnEventBlockStats":
                                return new a.SnEventBlockStats(e);
                            case "S2WEventBlockStats":
                                return new a.S2WEventBlockStats(e);
                            case "KnEventBlockStats":
                                return new a.KnEventBlockStats(e);
                            case "S7EventBlockStats":
                                return new a.S7EventBlockStats(e);
                            case "FootballEventBlockStats":
                                return new a.FootballEventBlockStats(e);
                            case "SxEventBlockStats":
                                return new a.SxEventBlockStats(e);
                            case "ChEventBlockStats":
                                return new a.ChEventBlockStats(e);
                            case "LkEventBlockStats":
                                return new a.LkEventBlockStats(e);
                            case "FightEventBlockStats":
                                return new a.FightEventBlockStats(e)
                        }
                    }
                    return e.prototype.isLottofiveEventBlockStats = function() {
                        return "LottofiveEventBlockStats" === this.classType
                    }, e.prototype.isLlEventBlockStats = function() {
                        return "LlEventBlockStats" === this.classType
                    }, e.prototype.isSnEventBlockStats = function() {
                        return "SnEventBlockStats" === this.classType
                    }, e.prototype.isS2WEventBlockStats = function() {
                        return "S2WEventBlockStats" === this.classType
                    }, e.prototype.isKnEventBlockStats = function() {
                        return "KnEventBlockStats" === this.classType
                    }, e.prototype.isS7EventBlockStats = function() {
                        return "S7EventBlockStats" === this.classType
                    }, e.prototype.isFootballEventBlockStats = function() {
                        return "FootballEventBlockStats" === this.classType
                    }, e.prototype.isSxEventBlockStats = function() {
                        return "SxEventBlockStats" === this.classType
                    }, e.prototype.isChEventBlockStats = function() {
                        return "ChEventBlockStats" === this.classType
                    }, e.prototype.isLkEventBlockStats = function() {
                        return "LkEventBlockStats" === this.classType
                    }, e.prototype.isFightEventBlockStats = function() {
                        return "FightEventBlockStats" === this.classType
                    }, e
                }();
            t.EventBlockStats = n
        },
        HbEo: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "BasketParticipant", t && (_.name = t.name), _
                }
                return n(t, e), t
            }(_("Kb6+").Participant);
            t.BasketParticipant = r
        },
        Helk: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "JackpotViewBonusInfo", t && (_.level = t.level, t.expirationDate ? _.expirationDate = new Date(t.expirationDate.toString()) : _.expirationDate = null, _.nextPrize = t.nextPrize), _
                }
                return n(t, e), t
            }(_("pwFx").JackpotViewTypeInfo);
            t.JackpotViewBonusInfo = r
        },
        Hh0I: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "LkEventBlockStats", _.historic = [], t && t.historic && t.historic.forEach((function(e) {
                        _.historic.push(e)
                    })), _
                }
                return n(t, e), t
            }(_("HZPa").EventBlockStats);
            t.LkEventBlockStats = r
        },
        HslF: function(e, t, _) {
            "use strict";
            var a, n, r, o, i, s, c, l, u, d, p;
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e) {
                    e.win = "win", e.exacta = "exacta", e.place = "place", e.quinella = "quinella", e.even_odd = "even_odd", e.over_under = "over_under", e.system_two = "system_two"
                }(d = t.SpeedwayMarkets || (t.SpeedwayMarkets = {})),
                function(e) {
                    e.win_1 = "win_1", e.win_2 = "win_2", e.win_3 = "win_3", e.win_4 = "win_4", e.exacta_1_2 = "exacta_1_2", e.exacta_1_3 = "exacta_1_3", e.exacta_1_4 = "exacta_1_4", e.exacta_2_1 = "exacta_2_1", e.exacta_2_3 = "exacta_2_3", e.exacta_2_4 = "exacta_2_4", e.exacta_3_1 = "exacta_3_1", e.exacta_3_2 = "exacta_3_2", e.exacta_3_4 = "exacta_3_4", e.exacta_4_1 = "exacta_4_1", e.exacta_4_2 = "exacta_4_2", e.exacta_4_3 = "exacta_4_3", e.place_1 = "place_1", e.place_2 = "place_2", e.place_3 = "place_3", e.place_4 = "place_4", e.quinella_1_2 = "quinella_1_2", e.quinella_1_3 = "quinella_1_3", e.quinella_1_4 = "quinella_1_4", e.quinella_2_3 = "quinella_2_3", e.quinella_2_4 = "quinella_2_4", e.quinella_3_4 = "quinella_3_4", e.even = "even", e.odd = "odd", e.over = "over", e.under = "under", e.system_two = "system_two"
                }(p = t.SpeedwayOdds || (t.SpeedwayOdds = {})), t.SpeedwayMarketsTemplate = ((a = {})[d.win] = ((n = {})[p.win_1] = p.win_1, n[p.win_2] = p.win_2, n[p.win_3] = p.win_3, n[p.win_4] = p.win_4, n), a[d.exacta] = ((r = {})[p.exacta_1_2] = p.exacta_1_2, r[p.exacta_1_3] = p.exacta_1_3, r[p.exacta_1_4] = p.exacta_1_4, r[p.exacta_2_1] = p.exacta_2_1, r[p.exacta_2_3] = p.exacta_2_3, r[p.exacta_2_4] = p.exacta_2_4, r[p.exacta_3_1] = p.exacta_3_1, r[p.exacta_3_2] = p.exacta_3_2, r[p.exacta_3_4] = p.exacta_3_4, r[p.exacta_4_1] = p.exacta_4_1, r[p.exacta_4_2] = p.exacta_4_2, r[p.exacta_4_3] = p.exacta_4_3, r), a[d.place] = ((o = {})[p.place_1] = p.place_1, o[p.place_2] = p.place_2, o[p.place_3] = p.place_3, o[p.place_4] = p.place_4, o), a[d.quinella] = ((i = {})[p.quinella_1_2] = p.quinella_1_2, i[p.quinella_1_3] = p.quinella_1_3, i[p.quinella_1_4] = p.quinella_1_4, i[p.quinella_2_3] = p.quinella_2_3, i[p.quinella_2_4] = p.quinella_2_4, i[p.quinella_3_4] = p.quinella_3_4, i), a[d.even_odd] = ((s = {})[p.even] = p.even, s[p.odd] = p.odd, s), a[d.over_under] = ((c = {})[p.over] = p.over, c[p.under] = p.under, c), a[d.system_two] = ((l = {})[p.system_two] = p.system_two, l), a), t.SpeedwayOddsTemplate = ((u = {})[p.win_1] = d.win, u[p.win_2] = d.win, u[p.win_3] = d.win, u[p.win_4] = d.win, u[p.exacta_1_2] = d.exacta, u[p.exacta_1_3] = d.exacta, u[p.exacta_1_4] = d.exacta, u[p.exacta_2_1] = d.exacta, u[p.exacta_2_3] = d.exacta, u[p.exacta_2_4] = d.exacta, u[p.exacta_3_1] = d.exacta, u[p.exacta_3_2] = d.exacta, u[p.exacta_3_4] = d.exacta, u[p.exacta_4_1] = d.exacta, u[p.exacta_4_2] = d.exacta, u[p.exacta_4_3] = d.exacta, u[p.place_1] = d.place, u[p.place_2] = d.place, u[p.place_3] = d.place, u[p.place_4] = d.place, u[p.quinella_1_2] = d.quinella, u[p.quinella_1_3] = d.quinella, u[p.quinella_1_4] = d.quinella, u[p.quinella_2_3] = d.quinella, u[p.quinella_2_4] = d.quinella, u[p.quinella_3_4] = d.quinella, u[p.even] = d.even_odd, u[p.odd] = d.even_odd, u[p.over] = d.over_under, u[p.under] = d.over_under, u[p.system_two] = d.system_two, u)
        },
        Ht2s: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "KartViewerProfileGameSettings", _
                }
                return n(t, e), t
            }(_("PBHJ").ViewerProfileGameSettings);
            t.KartViewerProfileGameSettings = r
        },
        I2xA: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "DirttrackGameOddSettings", _
                }
                return n(t, e), t
            }(_("aDCO").GameFixedOddSettings);
            t.DirttrackGameOddSettings = r
        },
        I3bV: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "DogAssets", _
                }
                return n(t, e), t
            }(_("vW0J").RacesAssets);
            t.DogAssets = r
        },
        ICUv: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function() {
                    function e(e, t) {
                        if (void 0 === t && (t = !0), e && (this.classType = e.classType, this.localizationContext = e.localizationContext ? new a.LocalizationContext(e.localizationContext) : null, this.sessionStatus = e.sessionStatus ? new a.SessionStatus(e.sessionStatus) : null, this.generalSettings = e.generalSettings ? new a.GeneralSettings(e.generalSettings) : null, this.calculationContext = e.calculationContext ? new a.CalculationContext(e.calculationContext) : null, this.gameContext = e.gameContext ? new a.GameContext(e.gameContext) : null, t && this.classType)) switch (this.classType) {
                            case "SessionSettings":
                                return new a.SessionSettings(e)
                        }
                    }
                    return e.prototype.isSessionSettings = function() {
                        return "SessionSettings" === this.classType
                    }, e
                }();
            t.UnitSettings = n
        },
        IJP8: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function() {
                    function e(e, t) {
                        if (void 0 === t && (t = !0), e && (this.classType = e.classType, t && this.classType)) switch (this.classType) {
                            case "NoAccumulatedTruncate":
                                return new a.NoAccumulatedTruncate(e);
                            case "AccumulatedRound":
                                return new a.AccumulatedRound(e)
                        }
                    }
                    return e.prototype.isNoAccumulatedTruncate = function() {
                        return "NoAccumulatedTruncate" === this.classType
                    }, e.prototype.isAccumulatedRound = function() {
                        return "AccumulatedRound" === this.classType
                    }, e
                }();
            t.CurrencyPolicy = n
        },
        IR12: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "RenderingStatus", _
                }
                return n(t, e), t
            }(_("JazB").ReportProcessStatus);
            t.RenderingStatus = r
        },
        Ibi2: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function() {
                    function e(e, t) {
                        if (void 0 === t && (t = !0), e && (this.classType = e.classType, this.cause = e.cause, this.data = e.data, t && this.classType)) switch (this.classType) {
                            case "ResetMessage":
                                return new a.ResetMessage(e)
                        }
                    }
                    return e.prototype.isResetMessage = function() {
                        return "ResetMessage" === this.classType
                    }, e
                }();
            t.EntityBodyMessage = n
        },
        JRr0: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    e && (this.data = e.data ? new a.EventData(e.data) : null, this.result = e.result ? new a.EventResult(e.result) : null, this.liveStats = e.liveStats ? new a.EventLiveStats(e.liveStats) : null, this.serverStatus = e.serverStatus, this.eventId = e.eventId, this.extId = e.extId, this.extData = e.extData, this.order = e.order)
                };
            t.Event = n,
                function(e) {
                    ! function(e) {
                        e.OPEN = "OPEN", e.SCHEDULED = "SCHEDULED", e.CANCELLED = "CANCELLED", e.RESOLVED = "RESOLVED", e.ERROR = "ERROR", e.LIVE = "LIVE"
                    }(e.ServerStatusEnum || (e.ServerStatusEnum = {}))
                }(n = t.Event || (t.Event = {})), t.Event = n
        },
        JRsZ: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                var t = this;
                this.tagSelect = [], e && (this.categoryId = e.categoryId, this.position = e.position, e.tagSelect && e.tagSelect.forEach((function(e) {
                    t.tagSelect.push(e)
                })), this.logo = e.logo)
            };
            t.MobileProfileCategory = a
        },
        JYIc: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.id = e.id, this.extId = e.extId, this.entityId = e.entityId, this.priority = e.priority, this.currency = e.currency, this.description = e.description, e.startDate ? this.startDate = new Date(e.startDate.toString()) : this.startDate = null, e.endDate ? this.endDate = new Date(e.endDate.toString()) : this.endDate = null, this.extData = e.extData, this.isPromotion = e.isPromotion, this.onCredit = e.onCredit)
            };
            t.Wallet = a
        },
        JZHs: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "TrottingFilter", t && (_.stadiumCode = t.stadiumCode, _.contextJockeys = t.contextJockeys, _.resourcePathNameJockeys = t.resourcePathNameJockeys, _.raceOddsLevel = t.raceOddsLevel), _
                }
                return n(t, e), t
            }(_("4Lmp").RacesFilter);
            t.TrottingFilter = r,
                function(e) {
                    ! function(e) {
                        e.ALL = "ALL", e.ONLYGOLDBET = "ONLYGOLDBET", e.LIGHT = "LIGHT", e.MEDIUM = "MEDIUM", e.HARD = "HARD"
                    }(e.RaceOddsLevelEnum || (e.RaceOddsLevelEnum = {}))
                }(r = t.TrottingFilter || (t.TrottingFilter = {})), t.TrottingFilter = r
        },
        JaeJ: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "DogGameOddSettings", _
                }
                return n(t, e), t
            }(_("aDCO").GameFixedOddSettings);
            t.DogGameOddSettings = r
        },
        JazB: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e, t) {
                void 0 === t && (t = !0), e && (this.classType = e.classType, this.success = e.success, this.description = e.description, t && this.classType)
            };
            t.ReportProcessStatus = a
        },
        JfpJ: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.apiVersion = e.apiVersion, this.serverVersion = e.serverVersion, this.proxyVersion = e.proxyVersion)
            };
            t.SystemVersion = a
        },
        Jr7m: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "SnGameOddSettings", t && (_.payTable = t.payTable ? new r.SnPayTable(t.payTable) : null), _
                    }
                    return n(t, e), t
                }(_("ZMgZ").GameOddSettings);
            t.SnGameOddSettings = o
        },
        "K/70": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "SettlementReportParams", t && (_.produces = t.produces, _.targetEntity = t.targetEntity), _
                }
                return n(t, e), t
            }(_("nzvJ").ReportParams);
            t.SettlementReportParams = r
        },
        K24N: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "ResetMessage", t && (_.entityId = t.entityId, _.executionDate = t.executionDate), _
                }
                return n(t, e), t
            }(_("Ibi2").EntityBodyMessage);
            t.ResetMessage = r
        },
        KF5S: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.n1 = e.n1, this.n2 = e.n2, this.n3 = e.n3, this.n4 = e.n4, this.n5 = e.n5, this.n1_machine_numbers = e.n1_machine_numbers, this.n2_machine_numbers = e.n2_machine_numbers, this.n3_machine_numbers = e.n3_machine_numbers, this.n4_machine_numbers = e.n4_machine_numbers, this.n5_machine_numbers = e.n5_machine_numbers, this.first_drawn = e.first_drawn, this.first_drawn_machine_numbers = e.first_drawn_machine_numbers, this.green_4_plus = e.green_4_plus, this.green_5 = e.green_5, this.red_4_plus = e.red_4_plus, this.red_5 = e.red_5, this.yellow_4_plus = e.yellow_4_plus, this.yellow_5 = e.yellow_5)
            };
            t.LottofivePayTable = a
        },
        KMb6: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "SxCashierProfileGameSettings", t && (_.mode = t.mode), _
                }
                return n(t, e), t
            }(_("nfOZ").CashierProfileGameSettings);
            t.SxCashierProfileGameSettings = r,
                function(e) {
                    ! function(e) {
                        e.DEFAULT = "DEFAULT"
                    }(e.ModeEnum || (e.ModeEnum = {}))
                }(r = t.SxCashierProfileGameSettings || (t.SxCashierProfileGameSettings = {})), t.SxCashierProfileGameSettings = r
        },
        "KY/t": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "LkFilter", t && (_.mode = t.mode), _
                }
                return n(t, e), t
            }(_("zE96").Filter);
            t.LkFilter = r,
                function(e) {
                    ! function(e) {
                        e.NORMAL = "NORMAL", e.DELUXE = "DELUXE"
                    }(e.ModeEnum || (e.ModeEnum = {}))
                }(r = t.LkFilter || (t.LkFilter = {})), t.LkFilter = r
        },
        "Kb6+": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function() {
                    function e(e, t) {
                        if (void 0 === t && (t = !0), e && (this.classType = e.classType, this.id = e.id, t && this.classType)) switch (this.classType) {
                            case "HorseParticipant":
                                return new a.HorseParticipant(e);
                            case "FootballParticipant":
                                return new a.FootballParticipant(e);
                            case "FightParticipant":
                                return new a.FightParticipant(e);
                            case "DogParticipant":
                                return new a.DogParticipant(e);
                            case "DirttrackParticipant":
                                return new a.DirttrackParticipant(e);
                            case "KartParticipant":
                                return new a.KartParticipant(e);
                            case "SpeedwayParticipant":
                                return new a.SpeedwayParticipant(e);
                            case "MotorbikeParticipant":
                                return new a.MotorbikeParticipant(e);
                            case "RaceParticipant":
                                return new a.RaceParticipant(e);
                            case "BasketParticipant":
                                return new a.BasketParticipant(e);
                            case "TrottingParticipant":
                                return new a.TrottingParticipant(e)
                        }
                    }
                    return e.prototype.isHorseParticipant = function() {
                        return "HorseParticipant" === this.classType
                    }, e.prototype.isFootballParticipant = function() {
                        return "FootballParticipant" === this.classType
                    }, e.prototype.isFightParticipant = function() {
                        return "FightParticipant" === this.classType
                    }, e.prototype.isDogParticipant = function() {
                        return "DogParticipant" === this.classType
                    }, e.prototype.isDirttrackParticipant = function() {
                        return "DirttrackParticipant" === this.classType
                    }, e.prototype.isKartParticipant = function() {
                        return "KartParticipant" === this.classType
                    }, e.prototype.isSpeedwayParticipant = function() {
                        return "SpeedwayParticipant" === this.classType
                    }, e.prototype.isMotorbikeParticipant = function() {
                        return "MotorbikeParticipant" === this.classType
                    }, e.prototype.isRaceParticipant = function() {
                        return "RaceParticipant" === this.classType
                    }, e.prototype.isBasketParticipant = function() {
                        return "BasketParticipant" === this.classType
                    }, e.prototype.isTrottingParticipant = function() {
                        return "TrottingParticipant" === this.classType
                    }, e
                }();
            t.Participant = n
        },
        Kjxo: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function() {
                    function e(e, t) {
                        if (void 0 === t && (t = !0), e && (this.classType = e.classType, t && this.classType)) switch (this.classType) {
                            case "GenericTicketPolicy":
                                return new a.GenericTicketPolicy(e)
                        }
                    }
                    return e.prototype.isGenericTicketPolicy = function() {
                        return "GenericTicketPolicy" === this.classType
                    }, e
                }();
            t.TicketPolicy = n
        },
        L00D: function(e, t, _) {
            "use strict";
            var a, n, r, o, i, s, c, l, u, d, p, h, f, y, m;
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e) {
                    e.win = "win", e.exacta = "exacta", e.trifecta = "trifecta", e.place = "place", e.show = "show", e.quinella = "quinella", e.even_odd = "even_odd", e.over_under = "over_under", e.sum_places = "sum_places", e.system_two = "system_two", e.system_three = "system_three"
                }(y = t.DogMarkets || (t.DogMarkets = {})),
                function(e) {
                    e.win_1 = "win_1", e.win_2 = "win_2", e.win_3 = "win_3", e.win_4 = "win_4", e.win_5 = "win_5", e.win_6 = "win_6", e.exacta_1_2 = "exacta_1_2", e.exacta_1_3 = "exacta_1_3", e.exacta_1_4 = "exacta_1_4", e.exacta_1_5 = "exacta_1_5", e.exacta_1_6 = "exacta_1_6", e.exacta_2_1 = "exacta_2_1", e.exacta_2_3 = "exacta_2_3", e.exacta_2_4 = "exacta_2_4", e.exacta_2_5 = "exacta_2_5", e.exacta_2_6 = "exacta_2_6", e.exacta_3_1 = "exacta_3_1", e.exacta_3_2 = "exacta_3_2", e.exacta_3_4 = "exacta_3_4", e.exacta_3_5 = "exacta_3_5", e.exacta_3_6 = "exacta_3_6", e.exacta_4_1 = "exacta_4_1", e.exacta_4_2 = "exacta_4_2", e.exacta_4_3 = "exacta_4_3", e.exacta_4_5 = "exacta_4_5", e.exacta_4_6 = "exacta_4_6", e.exacta_5_1 = "exacta_5_1", e.exacta_5_2 = "exacta_5_2", e.exacta_5_3 = "exacta_5_3", e.exacta_5_4 = "exacta_5_4", e.exacta_5_6 = "exacta_5_6", e.exacta_6_1 = "exacta_6_1", e.exacta_6_2 = "exacta_6_2", e.exacta_6_3 = "exacta_6_3", e.exacta_6_4 = "exacta_6_4", e.exacta_6_5 = "exacta_6_5", e.trifecta = "trifecta", e.place_1 = "place_1", e.place_2 = "place_2", e.place_3 = "place_3", e.place_4 = "place_4", e.place_5 = "place_5", e.place_6 = "place_6", e.show_1 = "show_1", e.show_2 = "show_2", e.show_3 = "show_3", e.show_4 = "show_4", e.show_5 = "show_5", e.show_6 = "show_6", e.quinella_1_2 = "quinella_1_2", e.quinella_1_3 = "quinella_1_3", e.quinella_1_4 = "quinella_1_4", e.quinella_1_5 = "quinella_1_5", e.quinella_1_6 = "quinella_1_6", e.quinella_2_3 = "quinella_2_3", e.quinella_2_4 = "quinella_2_4", e.quinella_2_5 = "quinella_2_5", e.quinella_2_6 = "quinella_2_6", e.quinella_3_4 = "quinella_3_4", e.quinella_3_5 = "quinella_3_5", e.quinella_3_6 = "quinella_3_6", e.quinella_4_5 = "quinella_4_5", e.quinella_4_6 = "quinella_4_6", e.quinella_5_6 = "quinella_5_6", e.even = "even", e.odd = "odd", e.over = "over", e.under = "under", e.sum_places_6 = "sum_places_6", e.sum_places_7 = "sum_places_7", e.sum_places_8 = "sum_places_8", e.sum_places_9 = "sum_places_9", e.sum_places_10 = "sum_places_10", e.sum_places_11 = "sum_places_11", e.sum_places_12 = "sum_places_12", e.sum_places_13 = "sum_places_13", e.sum_places_14 = "sum_places_14", e.sum_places_15 = "sum_places_15", e.system_two = "system_two", e.system_three = "system_three"
                }(m = t.DogOdds || (t.DogOdds = {})), t.DogMarketsTemplate = ((a = {})[y.win] = ((n = {})[m.win_1] = m.win_1, n[m.win_2] = m.win_2, n[m.win_3] = m.win_3, n[m.win_4] = m.win_4, n[m.win_5] = m.win_5, n[m.win_6] = m.win_6, n), a[y.exacta] = ((r = {})[m.exacta_1_2] = m.exacta_1_2, r[m.exacta_1_3] = m.exacta_1_3, r[m.exacta_1_4] = m.exacta_1_4, r[m.exacta_1_5] = m.exacta_1_5, r[m.exacta_1_6] = m.exacta_1_6, r[m.exacta_2_1] = m.exacta_2_1, r[m.exacta_2_3] = m.exacta_2_3, r[m.exacta_2_4] = m.exacta_2_4, r[m.exacta_2_5] = m.exacta_2_5, r[m.exacta_2_6] = m.exacta_2_6, r[m.exacta_3_1] = m.exacta_3_1, r[m.exacta_3_2] = m.exacta_3_2, r[m.exacta_3_4] = m.exacta_3_4, r[m.exacta_3_5] = m.exacta_3_5, r[m.exacta_3_6] = m.exacta_3_6, r[m.exacta_4_1] = m.exacta_4_1, r[m.exacta_4_2] = m.exacta_4_2, r[m.exacta_4_3] = m.exacta_4_3, r[m.exacta_4_5] = m.exacta_4_5, r[m.exacta_4_6] = m.exacta_4_6, r[m.exacta_5_1] = m.exacta_5_1, r[m.exacta_5_2] = m.exacta_5_2, r[m.exacta_5_3] = m.exacta_5_3, r[m.exacta_5_4] = m.exacta_5_4, r[m.exacta_5_6] = m.exacta_5_6, r[m.exacta_6_1] = m.exacta_6_1, r[m.exacta_6_2] = m.exacta_6_2, r[m.exacta_6_3] = m.exacta_6_3, r[m.exacta_6_4] = m.exacta_6_4, r[m.exacta_6_5] = m.exacta_6_5, r), a[y.trifecta] = ((o = {})[m.trifecta] = m.trifecta, o), a[y.place] = ((i = {})[m.place_1] = m.place_1, i[m.place_2] = m.place_2, i[m.place_3] = m.place_3, i[m.place_4] = m.place_4, i[m.place_5] = m.place_5, i[m.place_6] = m.place_6, i), a[y.show] = ((s = {})[m.show_1] = m.show_1, s[m.show_2] = m.show_2, s[m.show_3] = m.show_3, s[m.show_4] = m.show_4, s[m.show_5] = m.show_5, s[m.show_6] = m.show_6, s), a[y.quinella] = ((c = {})[m.quinella_1_2] = m.quinella_1_2, c[m.quinella_1_3] = m.quinella_1_3, c[m.quinella_1_4] = m.quinella_1_4, c[m.quinella_1_5] = m.quinella_1_5, c[m.quinella_1_6] = m.quinella_1_6, c[m.quinella_2_3] = m.quinella_2_3, c[m.quinella_2_4] = m.quinella_2_4, c[m.quinella_2_5] = m.quinella_2_5, c[m.quinella_2_6] = m.quinella_2_6, c[m.quinella_3_4] = m.quinella_3_4, c[m.quinella_3_5] = m.quinella_3_5, c[m.quinella_3_6] = m.quinella_3_6, c[m.quinella_4_5] = m.quinella_4_5, c[m.quinella_4_6] = m.quinella_4_6, c[m.quinella_5_6] = m.quinella_5_6, c), a[y.even_odd] = ((l = {})[m.even] = m.even, l[m.odd] = m.odd, l), a[y.over_under] = ((u = {})[m.over] = m.over, u[m.under] = m.under, u), a[y.sum_places] = ((d = {})[m.sum_places_6] = m.sum_places_6, d[m.sum_places_7] = m.sum_places_7, d[m.sum_places_8] = m.sum_places_8, d[m.sum_places_9] = m.sum_places_9, d[m.sum_places_10] = m.sum_places_10, d[m.sum_places_11] = m.sum_places_11, d[m.sum_places_12] = m.sum_places_12, d[m.sum_places_13] = m.sum_places_13, d[m.sum_places_14] = m.sum_places_14, d[m.sum_places_15] = m.sum_places_15, d), a[y.system_two] = ((p = {})[m.system_two] = m.system_two, p), a[y.system_three] = ((h = {})[m.system_three] = m.system_three, h), a), t.DogOddsTemplate = ((f = {})[m.win_1] = y.win, f[m.win_2] = y.win, f[m.win_3] = y.win, f[m.win_4] = y.win, f[m.win_5] = y.win, f[m.win_6] = y.win, f[m.exacta_1_2] = y.exacta, f[m.exacta_1_3] = y.exacta, f[m.exacta_1_4] = y.exacta, f[m.exacta_1_5] = y.exacta, f[m.exacta_1_6] = y.exacta, f[m.exacta_2_1] = y.exacta, f[m.exacta_2_3] = y.exacta, f[m.exacta_2_4] = y.exacta, f[m.exacta_2_5] = y.exacta, f[m.exacta_2_6] = y.exacta, f[m.exacta_3_1] = y.exacta, f[m.exacta_3_2] = y.exacta, f[m.exacta_3_4] = y.exacta, f[m.exacta_3_5] = y.exacta, f[m.exacta_3_6] = y.exacta, f[m.exacta_4_1] = y.exacta, f[m.exacta_4_2] = y.exacta, f[m.exacta_4_3] = y.exacta, f[m.exacta_4_5] = y.exacta, f[m.exacta_4_6] = y.exacta, f[m.exacta_5_1] = y.exacta, f[m.exacta_5_2] = y.exacta, f[m.exacta_5_3] = y.exacta, f[m.exacta_5_4] = y.exacta, f[m.exacta_5_6] = y.exacta, f[m.exacta_6_1] = y.exacta, f[m.exacta_6_2] = y.exacta, f[m.exacta_6_3] = y.exacta, f[m.exacta_6_4] = y.exacta, f[m.exacta_6_5] = y.exacta, f[m.trifecta] = y.trifecta, f[m.place_1] = y.place, f[m.place_2] = y.place, f[m.place_3] = y.place, f[m.place_4] = y.place, f[m.place_5] = y.place, f[m.place_6] = y.place, f[m.show_1] = y.show, f[m.show_2] = y.show, f[m.show_3] = y.show, f[m.show_4] = y.show, f[m.show_5] = y.show, f[m.show_6] = y.show, f[m.quinella_1_2] = y.quinella, f[m.quinella_1_3] = y.quinella, f[m.quinella_1_4] = y.quinella, f[m.quinella_1_5] = y.quinella, f[m.quinella_1_6] = y.quinella, f[m.quinella_2_3] = y.quinella, f[m.quinella_2_4] = y.quinella, f[m.quinella_2_5] = y.quinella, f[m.quinella_2_6] = y.quinella, f[m.quinella_3_4] = y.quinella, f[m.quinella_3_5] = y.quinella, f[m.quinella_3_6] = y.quinella, f[m.quinella_4_5] = y.quinella, f[m.quinella_4_6] = y.quinella, f[m.quinella_5_6] = y.quinella, f[m.even] = y.even_odd, f[m.odd] = y.even_odd, f[m.over] = y.over_under, f[m.under] = y.over_under, f[m.sum_places_6] = y.sum_places, f[m.sum_places_7] = y.sum_places, f[m.sum_places_8] = y.sum_places, f[m.sum_places_9] = y.sum_places, f[m.sum_places_10] = y.sum_places, f[m.sum_places_11] = y.sum_places, f[m.sum_places_12] = y.sum_places, f[m.sum_places_13] = y.sum_places, f[m.sum_places_14] = y.sum_places, f[m.sum_places_15] = y.sum_places, f[m.system_two] = y.system_two, f[m.system_three] = y.system_three, f)
        },
        LKRP: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "FightViewerProfileGameSettings", _
                }
                return n(t, e), t
            }(_("PBHJ").ViewerProfileGameSettings);
            t.FightViewerProfileGameSettings = r
        },
        LyQb: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.gameType = [], e && (this.ticketId = e.ticketId, this.extId = e.extId, this.extData = e.extData, this.serverHash = e.serverHash, this.ip = e.ip, this.unit = e.unit ? new a.Entity(e.unit) : null, this.payStaff = e.payStaff ? new a.Entity(e.payStaff) : null, this.sellStaff = e.sellStaff ? new a.Entity(e.sellStaff) : null, e.timeSend ? this.timeSend = new Date(e.timeSend.toString()) : this.timeSend = null, e.timeRegister ? this.timeRegister = new Date(e.timeRegister.toString()) : this.timeRegister = null, e.timeResolved ? this.timeResolved = new Date(e.timeResolved.toString()) : this.timeResolved = null, e.timeCancelled ? this.timeCancelled = new Date(e.timeCancelled.toString()) : this.timeCancelled = null, e.timePaid ? this.timePaid = new Date(e.timePaid.toString()) : this.timePaid = null, e.timePrint ? this.timePrint = new Date(e.timePrint.toString()) : this.timePrint = null, e.timeClosedMarket ? this.timeClosedMarket = new Date(e.timeClosedMarket.toString()) : this.timeClosedMarket = null, this.status = e.status, this.currency = e.currency ? new a.Currency(e.currency) : null, this.stake = e.stake, this.stakeTaxes = e.stakeTaxes, this.wonData = e.wonData ? new a.ServerTicketWonData(e.wonData) : null, this.winningData = e.winningData ? new a.ServerTicketWinningData(e.winningData) : null, this.calculationId = e.calculationId, e.gameType && e.gameType.forEach((function(e) {
                        t.gameType.push(e)
                    })), this.stakePromotional = e.stakePromotional, this.details = e.details ? new a.TicketDetail(e.details) : null, this.jackpotData = e.jackpotData ? new a.ServerTicketJackpotData(e.jackpotData) : null)
                };
            t.ServerTicket = n
        },
        M1dS: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "PosReport", _
                }
                return n(t, e), t
            }(_("fU0W").Report);
            t.PosReport = r
        },
        M5TN: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "S2WEventBlockStats", _.historic = [], t && t.historic && t.historic.forEach((function(e) {
                        _.historic.push(e)
                    })), _
                }
                return n(t, e), t
            }(_("HZPa").EventBlockStats);
            t.S2WEventBlockStats = r
        },
        MQ0g: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "DirttrackAssets", _
                }
                return n(t, e), t
            }(_("vW0J").RacesAssets);
            t.DirttrackAssets = r
        },
        MlsJ: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "LottofiveAssets", _
                }
                return n(t, e), t
            }(_("8xXt").Assets);
            t.LottofiveAssets = r
        },
        MsMn: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.barcodeInTicket = e.barcodeInTicket)
            };
            t.LogispinPrintProfileSettings = a
        },
        "N/uw": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.resource = e.resource)
            };
            t.Capability = a,
                function(e) {
                    ! function(e) {
                        e.AURORA = "AURORA", e.S6 = "S6", e.BROWSER = "BROWSER", e.OCVD6 = "OCVD6", e.OCVH6 = "OCVH6", e.OCVFG = "OCVFG", e.OCVSP = "OCVSP", e.OCVMT = "OCVMT", e.OCVKT = "OCVKT", e.OCVGG = "OCVGG"
                    }(e.ResourceEnum || (e.ResourceEnum = {}))
                }(a = t.Capability || (t.Capability = {})), t.Capability = a
        },
        NCoh: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                var t = this;
                this.odd = {}, e && e.odd && Object.keys(e.odd).forEach((function(_) {
                    t.odd[_] = e.odd[_]
                }))
            };
            t.S2WPayTable = a
        },
        NbOC: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function() {
                    function e(e, t) {
                        if (void 0 === t && (t = !0), e && (this.classType = e.classType, t && this.classType)) switch (this.classType) {
                            case "BasketEventStats":
                                return new a.BasketEventStats(e);
                            case "LottofiveEventStats":
                                return new a.LottofiveEventStats(e);
                            case "FootballEventStats":
                                return new a.FootballEventStats(e);
                            case "LlEventStats":
                                return new a.LlEventStats(e)
                        }
                    }
                    return e.prototype.isBasketEventStats = function() {
                        return "BasketEventStats" === this.classType
                    }, e.prototype.isLottofiveEventStats = function() {
                        return "LottofiveEventStats" === this.classType
                    }, e.prototype.isFootballEventStats = function() {
                        return "FootballEventStats" === this.classType
                    }, e.prototype.isLlEventStats = function() {
                        return "LlEventStats" === this.classType
                    }, e
                }();
            t.EventStats = n
        },
        "O4//": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "SessionSettings", _.rights = [], t && (_.systemVersion = t.systemVersion ? new r.SystemVersion(t.systemVersion) : null, _.clientId = t.clientId, _.tagsId = t.tagsId, _.calculationId = t.calculationId, _.auth = t.auth ? new r.AuthResult(t.auth) : null, t.rights && t.rights.forEach((function(e) {
                            _.rights.push(e)
                        })), _.sessionContext = t.sessionContext, _.extTransactionData = t.extTransactionData), _
                    }
                    return n(t, e), t
                }(_("ICUv").UnitSettings);
            t.SessionSettings = o
        },
        O4ZI: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function() {
                    function e(e, t) {
                        if (void 0 === t && (t = !0), e && (this.classType = e.classType, t && this.classType)) switch (this.classType) {
                            case "LottofiveEventLiveStats":
                                return new a.LottofiveEventLiveStats(e);
                            case "LkEventLiveStats":
                                return new a.LkEventLiveStats(e);
                            case "LlEventLiveStats":
                                return new a.LlEventLiveStats(e)
                        }
                    }
                    return e.prototype.isLottofiveEventLiveStats = function() {
                        return "LottofiveEventLiveStats" === this.classType
                    }, e.prototype.isLkEventLiveStats = function() {
                        return "LkEventLiveStats" === this.classType
                    }, e.prototype.isLlEventLiveStats = function() {
                        return "LlEventLiveStats" === this.classType
                    }, e
                }();
            t.EventLiveStats = n
        },
        ONQH: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "S7Filter", _
                }
                return n(t, e), t
            }(_("zE96").Filter);
            t.S7Filter = r
        },
        ORoH: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "ChAssets", t && (_.isTurbo = t.isTurbo, _.hasIntro = t.hasIntro, _.auroraGtpacksId = t.auroraGtpacksId, _.auroraId = t.auroraId, _.ocvVoiceoverLangSupported = t.ocvVoiceoverLangSupported), _
                }
                return n(t, e), t
            }(_("8xXt").Assets);
            t.ChAssets = r
        },
        OVBH: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "CustomThresholdTax", t && (_.threshold = t.threshold), _
                }
                return n(t, e), t
            }(_("CV3a").BasicTax);
            t.CustomThresholdTax = r
        },
        P4SD: function(e, t, _) {
            "use strict";
            var a, n, r, o, i, s, c, l, u, d, p, h, f, y, m, w, v, x, T, O, S;
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e) {
                    e.win = "win", e.exacta = "exacta", e.trifecta = "trifecta", e.place = "place", e.show = "show", e.quinella = "quinella", e.even_odd = "even_odd", e.over_under = "over_under", e.sum_places = "sum_places", e.second_place = "second_place", e.third_place = "third_place", e.fourth_place_worse = "fourth_place_worse", e.three_any_order = "three_any_order", e.four_any_order = "four_any_order", e.system_two = "system_two", e.system_three = "system_three", e.system_four_any_order = "system_four_any_order"
                }(O = t.HorseMarkets || (t.HorseMarkets = {})),
                function(e) {
                    e.win_1 = "win_1", e.win_2 = "win_2", e.win_3 = "win_3", e.win_4 = "win_4", e.win_5 = "win_5", e.win_6 = "win_6", e.win_7 = "win_7", e.win_8 = "win_8", e.win_9 = "win_9", e.win_10 = "win_10", e.win_11 = "win_11", e.win_12 = "win_12", e.exacta_1_2 = "exacta_1_2", e.exacta_1_3 = "exacta_1_3", e.exacta_1_4 = "exacta_1_4", e.exacta_1_5 = "exacta_1_5", e.exacta_1_6 = "exacta_1_6", e.exacta_1_7 = "exacta_1_7", e.exacta_1_8 = "exacta_1_8", e.exacta_1_9 = "exacta_1_9", e.exacta_1_10 = "exacta_1_10", e.exacta_1_11 = "exacta_1_11", e.exacta_1_12 = "exacta_1_12", e.exacta_2_1 = "exacta_2_1", e.exacta_2_3 = "exacta_2_3", e.exacta_2_4 = "exacta_2_4", e.exacta_2_5 = "exacta_2_5", e.exacta_2_6 = "exacta_2_6", e.exacta_2_7 = "exacta_2_7", e.exacta_2_8 = "exacta_2_8", e.exacta_2_9 = "exacta_2_9", e.exacta_2_10 = "exacta_2_10", e.exacta_2_11 = "exacta_2_11", e.exacta_2_12 = "exacta_2_12", e.exacta_3_1 = "exacta_3_1", e.exacta_3_2 = "exacta_3_2", e.exacta_3_4 = "exacta_3_4", e.exacta_3_5 = "exacta_3_5", e.exacta_3_6 = "exacta_3_6", e.exacta_3_7 = "exacta_3_7", e.exacta_3_8 = "exacta_3_8", e.exacta_3_9 = "exacta_3_9", e.exacta_3_10 = "exacta_3_10", e.exacta_3_11 = "exacta_3_11", e.exacta_3_12 = "exacta_3_12", e.exacta_4_1 = "exacta_4_1", e.exacta_4_2 = "exacta_4_2", e.exacta_4_3 = "exacta_4_3", e.exacta_4_5 = "exacta_4_5", e.exacta_4_6 = "exacta_4_6", e.exacta_4_7 = "exacta_4_7", e.exacta_4_8 = "exacta_4_8", e.exacta_4_9 = "exacta_4_9", e.exacta_4_10 = "exacta_4_10", e.exacta_4_11 = "exacta_4_11", e.exacta_4_12 = "exacta_4_12", e.exacta_5_1 = "exacta_5_1", e.exacta_5_2 = "exacta_5_2", e.exacta_5_3 = "exacta_5_3", e.exacta_5_4 = "exacta_5_4", e.exacta_5_6 = "exacta_5_6", e.exacta_5_7 = "exacta_5_7", e.exacta_5_8 = "exacta_5_8", e.exacta_5_9 = "exacta_5_9", e.exacta_5_10 = "exacta_5_10", e.exacta_5_11 = "exacta_5_11", e.exacta_5_12 = "exacta_5_12", e.exacta_6_1 = "exacta_6_1", e.exacta_6_2 = "exacta_6_2", e.exacta_6_3 = "exacta_6_3", e.exacta_6_4 = "exacta_6_4", e.exacta_6_5 = "exacta_6_5", e.exacta_6_7 = "exacta_6_7", e.exacta_6_8 = "exacta_6_8", e.exacta_6_9 = "exacta_6_9", e.exacta_6_10 = "exacta_6_10", e.exacta_6_11 = "exacta_6_11", e.exacta_6_12 = "exacta_6_12", e.exacta_7_1 = "exacta_7_1", e.exacta_7_2 = "exacta_7_2", e.exacta_7_3 = "exacta_7_3", e.exacta_7_4 = "exacta_7_4", e.exacta_7_5 = "exacta_7_5", e.exacta_7_6 = "exacta_7_6", e.exacta_7_8 = "exacta_7_8", e.exacta_7_9 = "exacta_7_9", e.exacta_7_10 = "exacta_7_10", e.exacta_7_11 = "exacta_7_11", e.exacta_7_12 = "exacta_7_12", e.exacta_8_1 = "exacta_8_1", e.exacta_8_2 = "exacta_8_2", e.exacta_8_3 = "exacta_8_3", e.exacta_8_4 = "exacta_8_4", e.exacta_8_5 = "exacta_8_5", e.exacta_8_6 = "exacta_8_6", e.exacta_8_7 = "exacta_8_7", e.exacta_8_9 = "exacta_8_9", e.exacta_8_10 = "exacta_8_10", e.exacta_8_11 = "exacta_8_11", e.exacta_8_12 = "exacta_8_12", e.exacta_9_1 = "exacta_9_1", e.exacta_9_2 = "exacta_9_2", e.exacta_9_3 = "exacta_9_3", e.exacta_9_4 = "exacta_9_4", e.exacta_9_5 = "exacta_9_5", e.exacta_9_6 = "exacta_9_6", e.exacta_9_7 = "exacta_9_7", e.exacta_9_8 = "exacta_9_8", e.exacta_9_10 = "exacta_9_10", e.exacta_9_11 = "exacta_9_11", e.exacta_9_12 = "exacta_9_12", e.exacta_10_1 = "exacta_10_1", e.exacta_10_2 = "exacta_10_2", e.exacta_10_3 = "exacta_10_3", e.exacta_10_4 = "exacta_10_4", e.exacta_10_5 = "exacta_10_5", e.exacta_10_6 = "exacta_10_6", e.exacta_10_7 = "exacta_10_7", e.exacta_10_8 = "exacta_10_8", e.exacta_10_9 = "exacta_10_9", e.exacta_10_11 = "exacta_10_11", e.exacta_10_12 = "exacta_10_12", e.exacta_11_1 = "exacta_11_1", e.exacta_11_2 = "exacta_11_2", e.exacta_11_3 = "exacta_11_3", e.exacta_11_4 = "exacta_11_4", e.exacta_11_5 = "exacta_11_5", e.exacta_11_6 = "exacta_11_6", e.exacta_11_7 = "exacta_11_7", e.exacta_11_8 = "exacta_11_8", e.exacta_11_9 = "exacta_11_9", e.exacta_11_10 = "exacta_11_10", e.exacta_11_12 = "exacta_11_12", e.exacta_12_1 = "exacta_12_1", e.exacta_12_2 = "exacta_12_2", e.exacta_12_3 = "exacta_12_3", e.exacta_12_4 = "exacta_12_4", e.exacta_12_5 = "exacta_12_5", e.exacta_12_6 = "exacta_12_6", e.exacta_12_7 = "exacta_12_7", e.exacta_12_8 = "exacta_12_8", e.exacta_12_9 = "exacta_12_9", e.exacta_12_10 = "exacta_12_10", e.exacta_12_11 = "exacta_12_11", e.trifecta = "trifecta", e.place_1 = "place_1", e.place_2 = "place_2", e.place_3 = "place_3", e.place_4 = "place_4", e.place_5 = "place_5", e.place_6 = "place_6", e.place_7 = "place_7", e.place_8 = "place_8", e.place_9 = "place_9", e.place_10 = "place_10", e.place_11 = "place_11", e.place_12 = "place_12", e.show_1 = "show_1", e.show_2 = "show_2", e.show_3 = "show_3", e.show_4 = "show_4", e.show_5 = "show_5", e.show_6 = "show_6", e.show_7 = "show_7", e.show_8 = "show_8", e.show_9 = "show_9", e.show_10 = "show_10", e.show_11 = "show_11", e.show_12 = "show_12", e.quinella_1_2 = "quinella_1_2", e.quinella_1_3 = "quinella_1_3", e.quinella_1_4 = "quinella_1_4", e.quinella_1_5 = "quinella_1_5", e.quinella_1_6 = "quinella_1_6", e.quinella_1_7 = "quinella_1_7", e.quinella_1_8 = "quinella_1_8", e.quinella_1_9 = "quinella_1_9", e.quinella_1_10 = "quinella_1_10", e.quinella_1_11 = "quinella_1_11", e.quinella_1_12 = "quinella_1_12", e.quinella_2_3 = "quinella_2_3", e.quinella_2_4 = "quinella_2_4", e.quinella_2_5 = "quinella_2_5", e.quinella_2_6 = "quinella_2_6", e.quinella_2_7 = "quinella_2_7", e.quinella_2_8 = "quinella_2_8", e.quinella_2_9 = "quinella_2_9", e.quinella_2_10 = "quinella_2_10", e.quinella_2_11 = "quinella_2_11", e.quinella_2_12 = "quinella_2_12", e.quinella_3_4 = "quinella_3_4", e.quinella_3_5 = "quinella_3_5", e.quinella_3_6 = "quinella_3_6", e.quinella_3_7 = "quinella_3_7", e.quinella_3_8 = "quinella_3_8", e.quinella_3_9 = "quinella_3_9", e.quinella_3_10 = "quinella_3_10", e.quinella_3_11 = "quinella_3_11", e.quinella_3_12 = "quinella_3_12", e.quinella_4_5 = "quinella_4_5", e.quinella_4_6 = "quinella_4_6", e.quinella_4_7 = "quinella_4_7", e.quinella_4_8 = "quinella_4_8", e.quinella_4_9 = "quinella_4_9", e.quinella_4_10 = "quinella_4_10", e.quinella_4_11 = "quinella_4_11", e.quinella_4_12 = "quinella_4_12", e.quinella_5_6 = "quinella_5_6", e.quinella_5_7 = "quinella_5_7", e.quinella_5_8 = "quinella_5_8", e.quinella_5_9 = "quinella_5_9", e.quinella_5_10 = "quinella_5_10", e.quinella_5_11 = "quinella_5_11", e.quinella_5_12 = "quinella_5_12", e.quinella_6_7 = "quinella_6_7", e.quinella_6_8 = "quinella_6_8", e.quinella_6_9 = "quinella_6_9", e.quinella_6_10 = "quinella_6_10", e.quinella_6_11 = "quinella_6_11", e.quinella_6_12 = "quinella_6_12", e.quinella_7_8 = "quinella_7_8", e.quinella_7_9 = "quinella_7_9", e.quinella_7_10 = "quinella_7_10", e.quinella_7_11 = "quinella_7_11", e.quinella_7_12 = "quinella_7_12", e.quinella_8_9 = "quinella_8_9", e.quinella_8_10 = "quinella_8_10", e.quinella_8_11 = "quinella_8_11", e.quinella_8_12 = "quinella_8_12", e.quinella_9_10 = "quinella_9_10", e.quinella_9_11 = "quinella_9_11", e.quinella_9_12 = "quinella_9_12", e.quinella_10_11 = "quinella_10_11", e.quinella_10_12 = "quinella_10_12", e.quinella_11_12 = "quinella_11_12", e.even = "even", e.odd = "odd", e.over = "over", e.under = "under", e.sum_places_6 = "sum_places_6", e.sum_places_7 = "sum_places_7", e.sum_places_8 = "sum_places_8", e.sum_places_9 = "sum_places_9", e.sum_places_10 = "sum_places_10", e.sum_places_11 = "sum_places_11", e.sum_places_12 = "sum_places_12", e.sum_places_13 = "sum_places_13", e.sum_places_14 = "sum_places_14", e.sum_places_15 = "sum_places_15", e.second_1 = "second_1", e.second_2 = "second_2", e.second_3 = "second_3", e.second_4 = "second_4", e.second_5 = "second_5", e.second_6 = "second_6", e.second_7 = "second_7", e.second_8 = "second_8", e.second_9 = "second_9", e.second_10 = "second_10", e.second_11 = "second_11", e.second_12 = "second_12", e.third_1 = "third_1", e.third_2 = "third_2", e.third_3 = "third_3", e.third_4 = "third_4", e.third_5 = "third_5", e.third_6 = "third_6", e.third_7 = "third_7", e.third_8 = "third_8", e.third_9 = "third_9", e.third_10 = "third_10", e.third_11 = "third_11", e.third_12 = "third_12", e.fourth_1 = "fourth_1", e.fourth_2 = "fourth_2", e.fourth_3 = "fourth_3", e.fourth_4 = "fourth_4", e.fourth_5 = "fourth_5", e.fourth_6 = "fourth_6", e.fourth_7 = "fourth_7", e.fourth_8 = "fourth_8", e.fourth_9 = "fourth_9", e.fourth_10 = "fourth_10", e.fourth_11 = "fourth_11", e.fourth_12 = "fourth_12", e.three_any = "three_any", e.four_any = "four_any", e.system_two = "system_two", e.system_three = "system_three", e.system_four_any = "system_four_any"
                }(S = t.HorseOdds || (t.HorseOdds = {})), t.HorseMarketsTemplate = ((a = {})[O.win] = ((n = {})[S.win_1] = S.win_1, n[S.win_2] = S.win_2, n[S.win_3] = S.win_3, n[S.win_4] = S.win_4, n[S.win_5] = S.win_5, n[S.win_6] = S.win_6, n[S.win_7] = S.win_7, n[S.win_8] = S.win_8, n[S.win_9] = S.win_9, n[S.win_10] = S.win_10, n[S.win_11] = S.win_11, n[S.win_12] = S.win_12, n), a[O.exacta] = ((r = {})[S.exacta_1_2] = S.exacta_1_2, r[S.exacta_1_3] = S.exacta_1_3, r[S.exacta_1_4] = S.exacta_1_4, r[S.exacta_1_5] = S.exacta_1_5, r[S.exacta_1_6] = S.exacta_1_6, r[S.exacta_1_7] = S.exacta_1_7, r[S.exacta_1_8] = S.exacta_1_8, r[S.exacta_1_9] = S.exacta_1_9, r[S.exacta_1_10] = S.exacta_1_10, r[S.exacta_1_11] = S.exacta_1_11, r[S.exacta_1_12] = S.exacta_1_12, r[S.exacta_2_1] = S.exacta_2_1, r[S.exacta_2_3] = S.exacta_2_3, r[S.exacta_2_4] = S.exacta_2_4, r[S.exacta_2_5] = S.exacta_2_5, r[S.exacta_2_6] = S.exacta_2_6, r[S.exacta_2_7] = S.exacta_2_7, r[S.exacta_2_8] = S.exacta_2_8, r[S.exacta_2_9] = S.exacta_2_9, r[S.exacta_2_10] = S.exacta_2_10, r[S.exacta_2_11] = S.exacta_2_11, r[S.exacta_2_12] = S.exacta_2_12, r[S.exacta_3_1] = S.exacta_3_1, r[S.exacta_3_2] = S.exacta_3_2, r[S.exacta_3_4] = S.exacta_3_4, r[S.exacta_3_5] = S.exacta_3_5, r[S.exacta_3_6] = S.exacta_3_6, r[S.exacta_3_7] = S.exacta_3_7, r[S.exacta_3_8] = S.exacta_3_8, r[S.exacta_3_9] = S.exacta_3_9, r[S.exacta_3_10] = S.exacta_3_10, r[S.exacta_3_11] = S.exacta_3_11, r[S.exacta_3_12] = S.exacta_3_12, r[S.exacta_4_1] = S.exacta_4_1, r[S.exacta_4_2] = S.exacta_4_2, r[S.exacta_4_3] = S.exacta_4_3, r[S.exacta_4_5] = S.exacta_4_5, r[S.exacta_4_6] = S.exacta_4_6, r[S.exacta_4_7] = S.exacta_4_7, r[S.exacta_4_8] = S.exacta_4_8, r[S.exacta_4_9] = S.exacta_4_9, r[S.exacta_4_10] = S.exacta_4_10, r[S.exacta_4_11] = S.exacta_4_11, r[S.exacta_4_12] = S.exacta_4_12, r[S.exacta_5_1] = S.exacta_5_1, r[S.exacta_5_2] = S.exacta_5_2, r[S.exacta_5_3] = S.exacta_5_3, r[S.exacta_5_4] = S.exacta_5_4, r[S.exacta_5_6] = S.exacta_5_6, r[S.exacta_5_7] = S.exacta_5_7, r[S.exacta_5_8] = S.exacta_5_8, r[S.exacta_5_9] = S.exacta_5_9, r[S.exacta_5_10] = S.exacta_5_10, r[S.exacta_5_11] = S.exacta_5_11, r[S.exacta_5_12] = S.exacta_5_12, r[S.exacta_6_1] = S.exacta_6_1, r[S.exacta_6_2] = S.exacta_6_2, r[S.exacta_6_3] = S.exacta_6_3, r[S.exacta_6_4] = S.exacta_6_4, r[S.exacta_6_5] = S.exacta_6_5, r[S.exacta_6_7] = S.exacta_6_7, r[S.exacta_6_8] = S.exacta_6_8, r[S.exacta_6_9] = S.exacta_6_9, r[S.exacta_6_10] = S.exacta_6_10, r[S.exacta_6_11] = S.exacta_6_11, r[S.exacta_6_12] = S.exacta_6_12, r[S.exacta_7_1] = S.exacta_7_1, r[S.exacta_7_2] = S.exacta_7_2, r[S.exacta_7_3] = S.exacta_7_3, r[S.exacta_7_4] = S.exacta_7_4, r[S.exacta_7_5] = S.exacta_7_5, r[S.exacta_7_6] = S.exacta_7_6, r[S.exacta_7_8] = S.exacta_7_8, r[S.exacta_7_9] = S.exacta_7_9, r[S.exacta_7_10] = S.exacta_7_10, r[S.exacta_7_11] = S.exacta_7_11, r[S.exacta_7_12] = S.exacta_7_12, r[S.exacta_8_1] = S.exacta_8_1, r[S.exacta_8_2] = S.exacta_8_2, r[S.exacta_8_3] = S.exacta_8_3, r[S.exacta_8_4] = S.exacta_8_4, r[S.exacta_8_5] = S.exacta_8_5, r[S.exacta_8_6] = S.exacta_8_6, r[S.exacta_8_7] = S.exacta_8_7, r[S.exacta_8_9] = S.exacta_8_9, r[S.exacta_8_10] = S.exacta_8_10, r[S.exacta_8_11] = S.exacta_8_11, r[S.exacta_8_12] = S.exacta_8_12, r[S.exacta_9_1] = S.exacta_9_1, r[S.exacta_9_2] = S.exacta_9_2, r[S.exacta_9_3] = S.exacta_9_3, r[S.exacta_9_4] = S.exacta_9_4, r[S.exacta_9_5] = S.exacta_9_5, r[S.exacta_9_6] = S.exacta_9_6, r[S.exacta_9_7] = S.exacta_9_7, r[S.exacta_9_8] = S.exacta_9_8, r[S.exacta_9_10] = S.exacta_9_10, r[S.exacta_9_11] = S.exacta_9_11, r[S.exacta_9_12] = S.exacta_9_12, r[S.exacta_10_1] = S.exacta_10_1, r[S.exacta_10_2] = S.exacta_10_2, r[S.exacta_10_3] = S.exacta_10_3, r[S.exacta_10_4] = S.exacta_10_4, r[S.exacta_10_5] = S.exacta_10_5, r[S.exacta_10_6] = S.exacta_10_6, r[S.exacta_10_7] = S.exacta_10_7, r[S.exacta_10_8] = S.exacta_10_8, r[S.exacta_10_9] = S.exacta_10_9, r[S.exacta_10_11] = S.exacta_10_11, r[S.exacta_10_12] = S.exacta_10_12, r[S.exacta_11_1] = S.exacta_11_1, r[S.exacta_11_2] = S.exacta_11_2, r[S.exacta_11_3] = S.exacta_11_3, r[S.exacta_11_4] = S.exacta_11_4, r[S.exacta_11_5] = S.exacta_11_5, r[S.exacta_11_6] = S.exacta_11_6, r[S.exacta_11_7] = S.exacta_11_7, r[S.exacta_11_8] = S.exacta_11_8, r[S.exacta_11_9] = S.exacta_11_9, r[S.exacta_11_10] = S.exacta_11_10, r[S.exacta_11_12] = S.exacta_11_12, r[S.exacta_12_1] = S.exacta_12_1, r[S.exacta_12_2] = S.exacta_12_2, r[S.exacta_12_3] = S.exacta_12_3, r[S.exacta_12_4] = S.exacta_12_4, r[S.exacta_12_5] = S.exacta_12_5, r[S.exacta_12_6] = S.exacta_12_6, r[S.exacta_12_7] = S.exacta_12_7, r[S.exacta_12_8] = S.exacta_12_8, r[S.exacta_12_9] = S.exacta_12_9, r[S.exacta_12_10] = S.exacta_12_10, r[S.exacta_12_11] = S.exacta_12_11, r), a[O.trifecta] = ((o = {})[S.trifecta] = S.trifecta, o), a[O.place] = ((i = {})[S.place_1] = S.place_1, i[S.place_2] = S.place_2, i[S.place_3] = S.place_3, i[S.place_4] = S.place_4, i[S.place_5] = S.place_5, i[S.place_6] = S.place_6, i[S.place_7] = S.place_7, i[S.place_8] = S.place_8, i[S.place_9] = S.place_9, i[S.place_10] = S.place_10, i[S.place_11] = S.place_11, i[S.place_12] = S.place_12, i), a[O.show] = ((s = {})[S.show_1] = S.show_1, s[S.show_2] = S.show_2, s[S.show_3] = S.show_3, s[S.show_4] = S.show_4, s[S.show_5] = S.show_5, s[S.show_6] = S.show_6, s[S.show_7] = S.show_7, s[S.show_8] = S.show_8, s[S.show_9] = S.show_9, s[S.show_10] = S.show_10, s[S.show_11] = S.show_11, s[S.show_12] = S.show_12, s), a[O.quinella] = ((c = {})[S.quinella_1_2] = S.quinella_1_2, c[S.quinella_1_3] = S.quinella_1_3, c[S.quinella_1_4] = S.quinella_1_4, c[S.quinella_1_5] = S.quinella_1_5, c[S.quinella_1_6] = S.quinella_1_6, c[S.quinella_1_7] = S.quinella_1_7, c[S.quinella_1_8] = S.quinella_1_8, c[S.quinella_1_9] = S.quinella_1_9, c[S.quinella_1_10] = S.quinella_1_10, c[S.quinella_1_11] = S.quinella_1_11, c[S.quinella_1_12] = S.quinella_1_12, c[S.quinella_2_3] = S.quinella_2_3, c[S.quinella_2_4] = S.quinella_2_4, c[S.quinella_2_5] = S.quinella_2_5, c[S.quinella_2_6] = S.quinella_2_6, c[S.quinella_2_7] = S.quinella_2_7, c[S.quinella_2_8] = S.quinella_2_8, c[S.quinella_2_9] = S.quinella_2_9, c[S.quinella_2_10] = S.quinella_2_10, c[S.quinella_2_11] = S.quinella_2_11, c[S.quinella_2_12] = S.quinella_2_12, c[S.quinella_3_4] = S.quinella_3_4, c[S.quinella_3_5] = S.quinella_3_5, c[S.quinella_3_6] = S.quinella_3_6, c[S.quinella_3_7] = S.quinella_3_7, c[S.quinella_3_8] = S.quinella_3_8, c[S.quinella_3_9] = S.quinella_3_9, c[S.quinella_3_10] = S.quinella_3_10, c[S.quinella_3_11] = S.quinella_3_11, c[S.quinella_3_12] = S.quinella_3_12, c[S.quinella_4_5] = S.quinella_4_5, c[S.quinella_4_6] = S.quinella_4_6, c[S.quinella_4_7] = S.quinella_4_7, c[S.quinella_4_8] = S.quinella_4_8, c[S.quinella_4_9] = S.quinella_4_9, c[S.quinella_4_10] = S.quinella_4_10, c[S.quinella_4_11] = S.quinella_4_11, c[S.quinella_4_12] = S.quinella_4_12, c[S.quinella_5_6] = S.quinella_5_6, c[S.quinella_5_7] = S.quinella_5_7, c[S.quinella_5_8] = S.quinella_5_8, c[S.quinella_5_9] = S.quinella_5_9, c[S.quinella_5_10] = S.quinella_5_10, c[S.quinella_5_11] = S.quinella_5_11, c[S.quinella_5_12] = S.quinella_5_12, c[S.quinella_6_7] = S.quinella_6_7, c[S.quinella_6_8] = S.quinella_6_8, c[S.quinella_6_9] = S.quinella_6_9, c[S.quinella_6_10] = S.quinella_6_10, c[S.quinella_6_11] = S.quinella_6_11, c[S.quinella_6_12] = S.quinella_6_12, c[S.quinella_7_8] = S.quinella_7_8, c[S.quinella_7_9] = S.quinella_7_9, c[S.quinella_7_10] = S.quinella_7_10, c[S.quinella_7_11] = S.quinella_7_11, c[S.quinella_7_12] = S.quinella_7_12, c[S.quinella_8_9] = S.quinella_8_9, c[S.quinella_8_10] = S.quinella_8_10, c[S.quinella_8_11] = S.quinella_8_11, c[S.quinella_8_12] = S.quinella_8_12, c[S.quinella_9_10] = S.quinella_9_10, c[S.quinella_9_11] = S.quinella_9_11, c[S.quinella_9_12] = S.quinella_9_12, c[S.quinella_10_11] = S.quinella_10_11, c[S.quinella_10_12] = S.quinella_10_12, c[S.quinella_11_12] = S.quinella_11_12, c), a[O.even_odd] = ((l = {})[S.even] = S.even, l[S.odd] = S.odd, l), a[O.over_under] = ((u = {})[S.over] = S.over, u[S.under] = S.under, u), a[O.sum_places] = ((d = {})[S.sum_places_6] = S.sum_places_6, d[S.sum_places_7] = S.sum_places_7, d[S.sum_places_8] = S.sum_places_8, d[S.sum_places_9] = S.sum_places_9, d[S.sum_places_10] = S.sum_places_10, d[S.sum_places_11] = S.sum_places_11, d[S.sum_places_12] = S.sum_places_12, d[S.sum_places_13] = S.sum_places_13, d[S.sum_places_14] = S.sum_places_14, d[S.sum_places_15] = S.sum_places_15, d), a[O.second_place] = ((p = {})[S.second_1] = S.second_1, p[S.second_2] = S.second_2, p[S.second_3] = S.second_3, p[S.second_4] = S.second_4, p[S.second_5] = S.second_5, p[S.second_6] = S.second_6, p[S.second_7] = S.second_7, p[S.second_8] = S.second_8, p[S.second_9] = S.second_9, p[S.second_10] = S.second_10, p[S.second_11] = S.second_11, p[S.second_12] = S.second_12, p), a[O.third_place] = ((h = {})[S.third_1] = S.third_1, h[S.third_2] = S.third_2, h[S.third_3] = S.third_3, h[S.third_4] = S.third_4, h[S.third_5] = S.third_5, h[S.third_6] = S.third_6, h[S.third_7] = S.third_7, h[S.third_8] = S.third_8, h[S.third_9] = S.third_9, h[S.third_10] = S.third_10, h[S.third_11] = S.third_11, h[S.third_12] = S.third_12, h), a[O.fourth_place_worse] = ((f = {})[S.fourth_1] = S.fourth_1, f[S.fourth_2] = S.fourth_2, f[S.fourth_3] = S.fourth_3, f[S.fourth_4] = S.fourth_4, f[S.fourth_5] = S.fourth_5, f[S.fourth_6] = S.fourth_6, f[S.fourth_7] = S.fourth_7, f[S.fourth_8] = S.fourth_8, f[S.fourth_9] = S.fourth_9, f[S.fourth_10] = S.fourth_10, f[S.fourth_11] = S.fourth_11, f[S.fourth_12] = S.fourth_12, f), a[O.three_any_order] = ((y = {})[S.three_any] = S.three_any, y), a[O.four_any_order] = ((m = {})[S.four_any] = S.four_any, m), a[O.system_two] = ((w = {})[S.system_two] = S.system_two, w), a[O.system_three] = ((v = {})[S.system_three] = S.system_three, v), a[O.system_four_any_order] = ((x = {})[S.system_four_any] = S.system_four_any, x), a), t.HorseOddsTemplate = ((T = {})[S.win_1] = O.win, T[S.win_2] = O.win, T[S.win_3] = O.win, T[S.win_4] = O.win, T[S.win_5] = O.win, T[S.win_6] = O.win, T[S.win_7] = O.win, T[S.win_8] = O.win, T[S.win_9] = O.win, T[S.win_10] = O.win, T[S.win_11] = O.win, T[S.win_12] = O.win, T[S.exacta_1_2] = O.exacta, T[S.exacta_1_3] = O.exacta, T[S.exacta_1_4] = O.exacta, T[S.exacta_1_5] = O.exacta, T[S.exacta_1_6] = O.exacta, T[S.exacta_1_7] = O.exacta, T[S.exacta_1_8] = O.exacta, T[S.exacta_1_9] = O.exacta, T[S.exacta_1_10] = O.exacta, T[S.exacta_1_11] = O.exacta, T[S.exacta_1_12] = O.exacta, T[S.exacta_2_1] = O.exacta, T[S.exacta_2_3] = O.exacta, T[S.exacta_2_4] = O.exacta, T[S.exacta_2_5] = O.exacta, T[S.exacta_2_6] = O.exacta, T[S.exacta_2_7] = O.exacta, T[S.exacta_2_8] = O.exacta, T[S.exacta_2_9] = O.exacta, T[S.exacta_2_10] = O.exacta, T[S.exacta_2_11] = O.exacta, T[S.exacta_2_12] = O.exacta, T[S.exacta_3_1] = O.exacta, T[S.exacta_3_2] = O.exacta, T[S.exacta_3_4] = O.exacta, T[S.exacta_3_5] = O.exacta, T[S.exacta_3_6] = O.exacta, T[S.exacta_3_7] = O.exacta, T[S.exacta_3_8] = O.exacta, T[S.exacta_3_9] = O.exacta, T[S.exacta_3_10] = O.exacta, T[S.exacta_3_11] = O.exacta, T[S.exacta_3_12] = O.exacta, T[S.exacta_4_1] = O.exacta, T[S.exacta_4_2] = O.exacta, T[S.exacta_4_3] = O.exacta, T[S.exacta_4_5] = O.exacta, T[S.exacta_4_6] = O.exacta, T[S.exacta_4_7] = O.exacta, T[S.exacta_4_8] = O.exacta, T[S.exacta_4_9] = O.exacta, T[S.exacta_4_10] = O.exacta, T[S.exacta_4_11] = O.exacta, T[S.exacta_4_12] = O.exacta, T[S.exacta_5_1] = O.exacta, T[S.exacta_5_2] = O.exacta, T[S.exacta_5_3] = O.exacta, T[S.exacta_5_4] = O.exacta, T[S.exacta_5_6] = O.exacta, T[S.exacta_5_7] = O.exacta, T[S.exacta_5_8] = O.exacta, T[S.exacta_5_9] = O.exacta, T[S.exacta_5_10] = O.exacta, T[S.exacta_5_11] = O.exacta, T[S.exacta_5_12] = O.exacta, T[S.exacta_6_1] = O.exacta, T[S.exacta_6_2] = O.exacta, T[S.exacta_6_3] = O.exacta, T[S.exacta_6_4] = O.exacta, T[S.exacta_6_5] = O.exacta, T[S.exacta_6_7] = O.exacta, T[S.exacta_6_8] = O.exacta, T[S.exacta_6_9] = O.exacta, T[S.exacta_6_10] = O.exacta, T[S.exacta_6_11] = O.exacta, T[S.exacta_6_12] = O.exacta, T[S.exacta_7_1] = O.exacta, T[S.exacta_7_2] = O.exacta, T[S.exacta_7_3] = O.exacta, T[S.exacta_7_4] = O.exacta, T[S.exacta_7_5] = O.exacta, T[S.exacta_7_6] = O.exacta, T[S.exacta_7_8] = O.exacta, T[S.exacta_7_9] = O.exacta, T[S.exacta_7_10] = O.exacta, T[S.exacta_7_11] = O.exacta, T[S.exacta_7_12] = O.exacta, T[S.exacta_8_1] = O.exacta, T[S.exacta_8_2] = O.exacta, T[S.exacta_8_3] = O.exacta, T[S.exacta_8_4] = O.exacta, T[S.exacta_8_5] = O.exacta, T[S.exacta_8_6] = O.exacta, T[S.exacta_8_7] = O.exacta, T[S.exacta_8_9] = O.exacta, T[S.exacta_8_10] = O.exacta, T[S.exacta_8_11] = O.exacta, T[S.exacta_8_12] = O.exacta, T[S.exacta_9_1] = O.exacta, T[S.exacta_9_2] = O.exacta, T[S.exacta_9_3] = O.exacta, T[S.exacta_9_4] = O.exacta, T[S.exacta_9_5] = O.exacta, T[S.exacta_9_6] = O.exacta, T[S.exacta_9_7] = O.exacta, T[S.exacta_9_8] = O.exacta, T[S.exacta_9_10] = O.exacta, T[S.exacta_9_11] = O.exacta, T[S.exacta_9_12] = O.exacta, T[S.exacta_10_1] = O.exacta, T[S.exacta_10_2] = O.exacta, T[S.exacta_10_3] = O.exacta, T[S.exacta_10_4] = O.exacta, T[S.exacta_10_5] = O.exacta, T[S.exacta_10_6] = O.exacta, T[S.exacta_10_7] = O.exacta, T[S.exacta_10_8] = O.exacta, T[S.exacta_10_9] = O.exacta, T[S.exacta_10_11] = O.exacta, T[S.exacta_10_12] = O.exacta, T[S.exacta_11_1] = O.exacta, T[S.exacta_11_2] = O.exacta, T[S.exacta_11_3] = O.exacta, T[S.exacta_11_4] = O.exacta, T[S.exacta_11_5] = O.exacta, T[S.exacta_11_6] = O.exacta, T[S.exacta_11_7] = O.exacta, T[S.exacta_11_8] = O.exacta, T[S.exacta_11_9] = O.exacta, T[S.exacta_11_10] = O.exacta, T[S.exacta_11_12] = O.exacta, T[S.exacta_12_1] = O.exacta, T[S.exacta_12_2] = O.exacta, T[S.exacta_12_3] = O.exacta, T[S.exacta_12_4] = O.exacta, T[S.exacta_12_5] = O.exacta, T[S.exacta_12_6] = O.exacta, T[S.exacta_12_7] = O.exacta, T[S.exacta_12_8] = O.exacta, T[S.exacta_12_9] = O.exacta, T[S.exacta_12_10] = O.exacta, T[S.exacta_12_11] = O.exacta, T[S.trifecta] = O.trifecta, T[S.place_1] = O.place, T[S.place_2] = O.place, T[S.place_3] = O.place, T[S.place_4] = O.place, T[S.place_5] = O.place, T[S.place_6] = O.place, T[S.place_7] = O.place, T[S.place_8] = O.place, T[S.place_9] = O.place, T[S.place_10] = O.place, T[S.place_11] = O.place, T[S.place_12] = O.place, T[S.show_1] = O.show, T[S.show_2] = O.show, T[S.show_3] = O.show, T[S.show_4] = O.show, T[S.show_5] = O.show, T[S.show_6] = O.show, T[S.show_7] = O.show, T[S.show_8] = O.show, T[S.show_9] = O.show, T[S.show_10] = O.show, T[S.show_11] = O.show, T[S.show_12] = O.show, T[S.quinella_1_2] = O.quinella, T[S.quinella_1_3] = O.quinella, T[S.quinella_1_4] = O.quinella, T[S.quinella_1_5] = O.quinella, T[S.quinella_1_6] = O.quinella, T[S.quinella_1_7] = O.quinella, T[S.quinella_1_8] = O.quinella, T[S.quinella_1_9] = O.quinella, T[S.quinella_1_10] = O.quinella, T[S.quinella_1_11] = O.quinella, T[S.quinella_1_12] = O.quinella, T[S.quinella_2_3] = O.quinella, T[S.quinella_2_4] = O.quinella, T[S.quinella_2_5] = O.quinella, T[S.quinella_2_6] = O.quinella, T[S.quinella_2_7] = O.quinella, T[S.quinella_2_8] = O.quinella, T[S.quinella_2_9] = O.quinella, T[S.quinella_2_10] = O.quinella, T[S.quinella_2_11] = O.quinella, T[S.quinella_2_12] = O.quinella, T[S.quinella_3_4] = O.quinella, T[S.quinella_3_5] = O.quinella, T[S.quinella_3_6] = O.quinella, T[S.quinella_3_7] = O.quinella, T[S.quinella_3_8] = O.quinella, T[S.quinella_3_9] = O.quinella, T[S.quinella_3_10] = O.quinella, T[S.quinella_3_11] = O.quinella, T[S.quinella_3_12] = O.quinella, T[S.quinella_4_5] = O.quinella, T[S.quinella_4_6] = O.quinella, T[S.quinella_4_7] = O.quinella, T[S.quinella_4_8] = O.quinella, T[S.quinella_4_9] = O.quinella, T[S.quinella_4_10] = O.quinella, T[S.quinella_4_11] = O.quinella, T[S.quinella_4_12] = O.quinella, T[S.quinella_5_6] = O.quinella, T[S.quinella_5_7] = O.quinella, T[S.quinella_5_8] = O.quinella, T[S.quinella_5_9] = O.quinella, T[S.quinella_5_10] = O.quinella, T[S.quinella_5_11] = O.quinella, T[S.quinella_5_12] = O.quinella, T[S.quinella_6_7] = O.quinella, T[S.quinella_6_8] = O.quinella, T[S.quinella_6_9] = O.quinella, T[S.quinella_6_10] = O.quinella, T[S.quinella_6_11] = O.quinella, T[S.quinella_6_12] = O.quinella, T[S.quinella_7_8] = O.quinella, T[S.quinella_7_9] = O.quinella, T[S.quinella_7_10] = O.quinella, T[S.quinella_7_11] = O.quinella, T[S.quinella_7_12] = O.quinella, T[S.quinella_8_9] = O.quinella, T[S.quinella_8_10] = O.quinella, T[S.quinella_8_11] = O.quinella, T[S.quinella_8_12] = O.quinella, T[S.quinella_9_10] = O.quinella, T[S.quinella_9_11] = O.quinella, T[S.quinella_9_12] = O.quinella, T[S.quinella_10_11] = O.quinella, T[S.quinella_10_12] = O.quinella, T[S.quinella_11_12] = O.quinella, T[S.even] = O.even_odd, T[S.odd] = O.even_odd, T[S.over] = O.over_under, T[S.under] = O.over_under, T[S.sum_places_6] = O.sum_places, T[S.sum_places_7] = O.sum_places, T[S.sum_places_8] = O.sum_places, T[S.sum_places_9] = O.sum_places, T[S.sum_places_10] = O.sum_places, T[S.sum_places_11] = O.sum_places, T[S.sum_places_12] = O.sum_places, T[S.sum_places_13] = O.sum_places, T[S.sum_places_14] = O.sum_places, T[S.sum_places_15] = O.sum_places, T[S.second_1] = O.second_place, T[S.second_2] = O.second_place, T[S.second_3] = O.second_place, T[S.second_4] = O.second_place, T[S.second_5] = O.second_place, T[S.second_6] = O.second_place, T[S.second_7] = O.second_place, T[S.second_8] = O.second_place, T[S.second_9] = O.second_place, T[S.second_10] = O.second_place, T[S.second_11] = O.second_place, T[S.second_12] = O.second_place, T[S.third_1] = O.third_place, T[S.third_2] = O.third_place, T[S.third_3] = O.third_place, T[S.third_4] = O.third_place, T[S.third_5] = O.third_place, T[S.third_6] = O.third_place, T[S.third_7] = O.third_place, T[S.third_8] = O.third_place, T[S.third_9] = O.third_place, T[S.third_10] = O.third_place, T[S.third_11] = O.third_place, T[S.third_12] = O.third_place, T[S.fourth_1] = O.fourth_place_worse, T[S.fourth_2] = O.fourth_place_worse, T[S.fourth_3] = O.fourth_place_worse, T[S.fourth_4] = O.fourth_place_worse, T[S.fourth_5] = O.fourth_place_worse, T[S.fourth_6] = O.fourth_place_worse, T[S.fourth_7] = O.fourth_place_worse, T[S.fourth_8] = O.fourth_place_worse, T[S.fourth_9] = O.fourth_place_worse, T[S.fourth_10] = O.fourth_place_worse, T[S.fourth_11] = O.fourth_place_worse, T[S.fourth_12] = O.fourth_place_worse, T[S.three_any] = O.three_any_order, T[S.four_any] = O.four_any_order, T[S.system_two] = O.system_two, T[S.system_three] = O.system_three, T[S.system_four_any] = O.system_four_any_order, T)
        },
        PBHJ: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function() {
                    function e(e, t) {
                        var _ = this;
                        if (void 0 === t && (t = !0), this.tickerSettings = [], e && (this.classType = e.classType, this.gameType = e.gameType, this.soundVolume = e.soundVolume, e.tickerSettings && e.tickerSettings.forEach((function(e) {
                                _.tickerSettings.push(new a.TickerGameSetting(e))
                            })), t && this.classType)) switch (this.classType) {
                            case "KartViewerProfileGameSettings":
                                return new a.KartViewerProfileGameSettings(e);
                            case "ChViewerProfileGameSettings":
                                return new a.ChViewerProfileGameSettings(e);
                            case "DirttrackViewerProfileGameSettings":
                                return new a.DirttrackViewerProfileGameSettings(e);
                            case "SnViewerProfileGameSettings":
                                return new a.SnViewerProfileGameSettings(e);
                            case "FightViewerProfileGameSettings":
                                return new a.FightViewerProfileGameSettings(e);
                            case "DogViewerProfileGameSettings":
                                return new a.DogViewerProfileGameSettings(e);
                            case "LlViewerProfileGameSettings":
                                return new a.LlViewerProfileGameSettings(e);
                            case "HorseViewerProfileGameSettings":
                                return new a.HorseViewerProfileGameSettings(e);
                            case "SxViewerProfileGameSettings":
                                return new a.SxViewerProfileGameSettings(e);
                            case "SpeedwayViewerProfileGameSettings":
                                return new a.SpeedwayViewerProfileGameSettings(e);
                            case "KnViewerProfileGameSettings":
                                return new a.KnViewerProfileGameSettings(e);
                            case "BasketViewerProfileGameSettings":
                                return new a.BasketViewerProfileGameSettings(e);
                            case "S7WViewerProfileGameSettings":
                                return new a.S7WViewerProfileGameSettings(e);
                            case "MotorbikeViewerProfileGameSettings":
                                return new a.MotorbikeViewerProfileGameSettings(e);
                            case "LkViewerProfileGameSettings":
                                return new a.LkViewerProfileGameSettings(e);
                            case "S2WViewerProfileGameSettings":
                                return new a.S2WViewerProfileGameSettings(e);
                            case "TrottingViewerProfileGameSettings":
                                return new a.TrottingViewerProfileGameSettings(e)
                        }
                    }
                    return e.prototype.isKartViewerProfileGameSettings = function() {
                        return "KartViewerProfileGameSettings" === this.classType
                    }, e.prototype.isChViewerProfileGameSettings = function() {
                        return "ChViewerProfileGameSettings" === this.classType
                    }, e.prototype.isDirttrackViewerProfileGameSettings = function() {
                        return "DirttrackViewerProfileGameSettings" === this.classType
                    }, e.prototype.isSnViewerProfileGameSettings = function() {
                        return "SnViewerProfileGameSettings" === this.classType
                    }, e.prototype.isFightViewerProfileGameSettings = function() {
                        return "FightViewerProfileGameSettings" === this.classType
                    }, e.prototype.isDogViewerProfileGameSettings = function() {
                        return "DogViewerProfileGameSettings" === this.classType
                    }, e.prototype.isLlViewerProfileGameSettings = function() {
                        return "LlViewerProfileGameSettings" === this.classType
                    }, e.prototype.isHorseViewerProfileGameSettings = function() {
                        return "HorseViewerProfileGameSettings" === this.classType
                    }, e.prototype.isSxViewerProfileGameSettings = function() {
                        return "SxViewerProfileGameSettings" === this.classType
                    }, e.prototype.isSpeedwayViewerProfileGameSettings = function() {
                        return "SpeedwayViewerProfileGameSettings" === this.classType
                    }, e.prototype.isKnViewerProfileGameSettings = function() {
                        return "KnViewerProfileGameSettings" === this.classType
                    }, e.prototype.isBasketViewerProfileGameSettings = function() {
                        return "BasketViewerProfileGameSettings" === this.classType
                    }, e.prototype.isS7WViewerProfileGameSettings = function() {
                        return "S7WViewerProfileGameSettings" === this.classType
                    }, e.prototype.isMotorbikeViewerProfileGameSettings = function() {
                        return "MotorbikeViewerProfileGameSettings" === this.classType
                    }, e.prototype.isLkViewerProfileGameSettings = function() {
                        return "LkViewerProfileGameSettings" === this.classType
                    }, e.prototype.isS2WViewerProfileGameSettings = function() {
                        return "S2WViewerProfileGameSettings" === this.classType
                    }, e.prototype.isTrottingViewerProfileGameSettings = function() {
                        return "TrottingViewerProfileGameSettings" === this.classType
                    }, e
                }();
            t.ViewerProfileGameSettings = n
        },
        PHIG: function(e, t, _) {
            "use strict";
            var a, n, r, o, i, s, c, l, u, d, p, h, f, y, m, w;
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e) {
                    e.Hit_Ball = "Hit_Ball", e.System_Hit_Ball = "System_Hit_Ball", e.Top_Color = "Top_Color", e.First_Color = "First_Color", e.Last_Color = "Last_Color", e.More_Odd_Even = "More_Odd_Even", e.Pre_Sum_Odd_Even = "Pre_Sum_Odd_Even", e.First_Odd_Even = "First_Odd_Even", e.Last_Odd_Even = "Last_Odd_Even", e.Pre_Sum_Over_Under_122_5 = "Pre_Sum_Over_Under_122_5", e.First_Over_Under_24_5 = "First_Over_Under_24_5", e.Last_Over_Under_24_5 = "Last_Over_Under_24_5"
                }(m = t.SxMarkets || (t.SxMarkets = {})),
                function(e) {
                    e.Hit_Ball_6 = "Hit_Ball_6", e.Hit_Ball_7 = "Hit_Ball_7", e.Hit_Ball_8 = "Hit_Ball_8", e.Hit_Ball_9 = "Hit_Ball_9", e.Hit_Ball_10 = "Hit_Ball_10", e.Hit_Ball_11 = "Hit_Ball_11", e.Hit_Ball_12 = "Hit_Ball_12", e.Hit_Ball_13 = "Hit_Ball_13", e.Hit_Ball_14 = "Hit_Ball_14", e.Hit_Ball_15 = "Hit_Ball_15", e.Hit_Ball_16 = "Hit_Ball_16", e.Hit_Ball_17 = "Hit_Ball_17", e.Hit_Ball_18 = "Hit_Ball_18", e.Hit_Ball_19 = "Hit_Ball_19", e.Hit_Ball_20 = "Hit_Ball_20", e.Hit_Ball_21 = "Hit_Ball_21", e.Hit_Ball_22 = "Hit_Ball_22", e.Hit_Ball_23 = "Hit_Ball_23", e.Hit_Ball_24 = "Hit_Ball_24", e.Hit_Ball_25 = "Hit_Ball_25", e.Hit_Ball_26 = "Hit_Ball_26", e.Hit_Ball_27 = "Hit_Ball_27", e.Hit_Ball_28 = "Hit_Ball_28", e.Hit_Ball_29 = "Hit_Ball_29", e.Hit_Ball_30 = "Hit_Ball_30", e.Hit_Ball_31 = "Hit_Ball_31", e.Hit_Ball_32 = "Hit_Ball_32", e.Hit_Ball_33 = "Hit_Ball_33", e.Hit_Ball_34 = "Hit_Ball_34", e.Hit_Ball_35 = "Hit_Ball_35", e.System_Hit_Ball_7 = "System_Hit_Ball_7", e.System_Hit_Ball_8 = "System_Hit_Ball_8", e.System_Hit_Ball_9 = "System_Hit_Ball_9", e.System_Hit_Ball_10 = "System_Hit_Ball_10", e.Top_C1 = "Top_C1", e.Top_C2 = "Top_C2", e.Top_C3 = "Top_C3", e.Top_C4 = "Top_C4", e.First_C1 = "First_C1", e.First_C2 = "First_C2", e.First_C3 = "First_C3", e.First_C4 = "First_C4", e.Last_C1 = "Last_C1", e.Last_C2 = "Last_C2", e.Last_C3 = "Last_C3", e.Last_C4 = "Last_C4", e.More_Odd = "More_Odd", e.More_Even = "More_Even", e.Pre_Sum_Odd = "Pre_Sum_Odd", e.Pre_Sum_Even = "Pre_Sum_Even", e.First_Odd = "First_Odd", e.First_Even = "First_Even", e.Last_Odd = "Last_Odd", e.Last_Even = "Last_Even", e.Pre_Sum_Over_122_5 = "Pre_Sum_Over_122_5", e.Pre_Sum_Under_122_5 = "Pre_Sum_Under_122_5", e.First_Over_24_5 = "First_Over_24_5", e.First_Under_24_5 = "First_Under_24_5", e.Last_Over_24_5 = "Last_Over_24_5", e.Last_Under_24_5 = "Last_Under_24_5"
                }(w = t.SxOdds || (t.SxOdds = {})), t.SxMarketsTemplate = ((a = {})[m.Hit_Ball] = ((n = {})[w.Hit_Ball_6] = w.Hit_Ball_6, n[w.Hit_Ball_7] = w.Hit_Ball_7, n[w.Hit_Ball_8] = w.Hit_Ball_8, n[w.Hit_Ball_9] = w.Hit_Ball_9, n[w.Hit_Ball_10] = w.Hit_Ball_10, n[w.Hit_Ball_11] = w.Hit_Ball_11, n[w.Hit_Ball_12] = w.Hit_Ball_12, n[w.Hit_Ball_13] = w.Hit_Ball_13, n[w.Hit_Ball_14] = w.Hit_Ball_14, n[w.Hit_Ball_15] = w.Hit_Ball_15, n[w.Hit_Ball_16] = w.Hit_Ball_16, n[w.Hit_Ball_17] = w.Hit_Ball_17, n[w.Hit_Ball_18] = w.Hit_Ball_18, n[w.Hit_Ball_19] = w.Hit_Ball_19, n[w.Hit_Ball_20] = w.Hit_Ball_20, n[w.Hit_Ball_21] = w.Hit_Ball_21, n[w.Hit_Ball_22] = w.Hit_Ball_22, n[w.Hit_Ball_23] = w.Hit_Ball_23, n[w.Hit_Ball_24] = w.Hit_Ball_24, n[w.Hit_Ball_25] = w.Hit_Ball_25, n[w.Hit_Ball_26] = w.Hit_Ball_26, n[w.Hit_Ball_27] = w.Hit_Ball_27, n[w.Hit_Ball_28] = w.Hit_Ball_28, n[w.Hit_Ball_29] = w.Hit_Ball_29, n[w.Hit_Ball_30] = w.Hit_Ball_30, n[w.Hit_Ball_31] = w.Hit_Ball_31, n[w.Hit_Ball_32] = w.Hit_Ball_32, n[w.Hit_Ball_33] = w.Hit_Ball_33, n[w.Hit_Ball_34] = w.Hit_Ball_34, n[w.Hit_Ball_35] = w.Hit_Ball_35, n), a[m.System_Hit_Ball] = ((r = {})[w.System_Hit_Ball_7] = w.System_Hit_Ball_7, r[w.System_Hit_Ball_8] = w.System_Hit_Ball_8, r[w.System_Hit_Ball_9] = w.System_Hit_Ball_9, r[w.System_Hit_Ball_10] = w.System_Hit_Ball_10, r), a[m.Top_Color] = ((o = {})[w.Top_C1] = w.Top_C1, o[w.Top_C2] = w.Top_C2, o[w.Top_C3] = w.Top_C3, o[w.Top_C4] = w.Top_C4, o), a[m.First_Color] = ((i = {})[w.First_C1] = w.First_C1, i[w.First_C2] = w.First_C2, i[w.First_C3] = w.First_C3, i[w.First_C4] = w.First_C4, i), a[m.Last_Color] = ((s = {})[w.Last_C1] = w.Last_C1, s[w.Last_C2] = w.Last_C2, s[w.Last_C3] = w.Last_C3, s[w.Last_C4] = w.Last_C4, s), a[m.More_Odd_Even] = ((c = {})[w.More_Odd] = w.More_Odd, c[w.More_Even] = w.More_Even, c), a[m.Pre_Sum_Odd_Even] = ((l = {})[w.Pre_Sum_Odd] = w.Pre_Sum_Odd, l[w.Pre_Sum_Even] = w.Pre_Sum_Even, l), a[m.First_Odd_Even] = ((u = {})[w.First_Odd] = w.First_Odd, u[w.First_Even] = w.First_Even, u), a[m.Last_Odd_Even] = ((d = {})[w.Last_Odd] = w.Last_Odd, d[w.Last_Even] = w.Last_Even, d), a[m.Pre_Sum_Over_Under_122_5] = ((p = {})[w.Pre_Sum_Over_122_5] = w.Pre_Sum_Over_122_5, p[w.Pre_Sum_Under_122_5] = w.Pre_Sum_Under_122_5, p), a[m.First_Over_Under_24_5] = ((h = {})[w.First_Over_24_5] = w.First_Over_24_5, h[w.First_Under_24_5] = w.First_Under_24_5, h), a[m.Last_Over_Under_24_5] = ((f = {})[w.Last_Over_24_5] = w.Last_Over_24_5, f[w.Last_Under_24_5] = w.Last_Under_24_5, f), a), t.SxOddsTemplate = ((y = {})[w.Hit_Ball_6] = m.Hit_Ball, y[w.Hit_Ball_7] = m.Hit_Ball, y[w.Hit_Ball_8] = m.Hit_Ball, y[w.Hit_Ball_9] = m.Hit_Ball, y[w.Hit_Ball_10] = m.Hit_Ball, y[w.Hit_Ball_11] = m.Hit_Ball, y[w.Hit_Ball_12] = m.Hit_Ball, y[w.Hit_Ball_13] = m.Hit_Ball, y[w.Hit_Ball_14] = m.Hit_Ball, y[w.Hit_Ball_15] = m.Hit_Ball, y[w.Hit_Ball_16] = m.Hit_Ball, y[w.Hit_Ball_17] = m.Hit_Ball, y[w.Hit_Ball_18] = m.Hit_Ball, y[w.Hit_Ball_19] = m.Hit_Ball, y[w.Hit_Ball_20] = m.Hit_Ball, y[w.Hit_Ball_21] = m.Hit_Ball, y[w.Hit_Ball_22] = m.Hit_Ball, y[w.Hit_Ball_23] = m.Hit_Ball, y[w.Hit_Ball_24] = m.Hit_Ball, y[w.Hit_Ball_25] = m.Hit_Ball, y[w.Hit_Ball_26] = m.Hit_Ball, y[w.Hit_Ball_27] = m.Hit_Ball, y[w.Hit_Ball_28] = m.Hit_Ball, y[w.Hit_Ball_29] = m.Hit_Ball, y[w.Hit_Ball_30] = m.Hit_Ball, y[w.Hit_Ball_31] = m.Hit_Ball, y[w.Hit_Ball_32] = m.Hit_Ball, y[w.Hit_Ball_33] = m.Hit_Ball, y[w.Hit_Ball_34] = m.Hit_Ball, y[w.Hit_Ball_35] = m.Hit_Ball, y[w.System_Hit_Ball_7] = m.System_Hit_Ball, y[w.System_Hit_Ball_8] = m.System_Hit_Ball, y[w.System_Hit_Ball_9] = m.System_Hit_Ball, y[w.System_Hit_Ball_10] = m.System_Hit_Ball, y[w.Top_C1] = m.Top_Color, y[w.Top_C2] = m.Top_Color, y[w.Top_C3] = m.Top_Color, y[w.Top_C4] = m.Top_Color, y[w.First_C1] = m.First_Color, y[w.First_C2] = m.First_Color, y[w.First_C3] = m.First_Color, y[w.First_C4] = m.First_Color, y[w.Last_C1] = m.Last_Color, y[w.Last_C2] = m.Last_Color, y[w.Last_C3] = m.Last_Color, y[w.Last_C4] = m.Last_Color, y[w.More_Odd] = m.More_Odd_Even, y[w.More_Even] = m.More_Odd_Even, y[w.Pre_Sum_Odd] = m.Pre_Sum_Odd_Even, y[w.Pre_Sum_Even] = m.Pre_Sum_Odd_Even, y[w.First_Odd] = m.First_Odd_Even, y[w.First_Even] = m.First_Odd_Even, y[w.Last_Odd] = m.Last_Odd_Even, y[w.Last_Even] = m.Last_Odd_Even, y[w.Pre_Sum_Over_122_5] = m.Pre_Sum_Over_Under_122_5, y[w.Pre_Sum_Under_122_5] = m.Pre_Sum_Over_Under_122_5, y[w.First_Over_24_5] = m.First_Over_Under_24_5, y[w.First_Under_24_5] = m.First_Over_Under_24_5, y[w.Last_Over_24_5] = m.Last_Over_Under_24_5, y[w.Last_Under_24_5] = m.Last_Over_Under_24_5, y)
        },
        PWJJ: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function() {
                function e() {}
                return e.APPNAME = "GoldenRace Client API", e.VERSION = "3.0.0", e.INPUTSPECT = "dist/client-api.yaml", e.GENERATEDDATA = "2020-08-17T10:17:12.233+02:00", e.BASEPATH = "/api/client/v0.1", e
            }();
            t.ApiInfo = a, t.createConnectionPromise = function(e, t) {
                return new Promise((function(_, a) {
                    e.request(t, (function(e) {
                        e.statusCode >= 200 && e.statusCode <= 299 ? e.body ? e.body.errorCode ? a({
                            response: e,
                            body: null,
                            error: e.body
                        }) : _({
                            response: e,
                            body: e.body,
                            error: null
                        }) : _({
                            response: e,
                            body: null,
                            error: null
                        }) : a({
                            response: e,
                            body: null,
                            error: e.body
                        })
                    }))
                }))
            }, t.extendObj = function(e, t) {
                for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_]);
                return e
            };
            var n = function() {
                function e(e, t) {
                    this.location = e, this.paramName = t
                }
                return e.prototype.applyToRequest = function(e) {
                    "query" === this.location ? e.query[this.paramName] = this.apiKey : "header" === this.location && (e.headers[this.paramName] = this.apiKey)
                }, e
            }();
            t.ApiKeyAuth = n;
            var r = function() {
                function e() {}
                return e.prototype.applyToRequest = function(e) {
                    e.headers.Authorization = "Bearer " + this.accessToken
                }, e
            }();
            t.OAuth = r;
            var o = function() {
                function e() {}
                return e.prototype.applyToRequest = function(e) {}, e
            }();
            t.VoidAuth = o,
                function(e) {
                    e[e.REQUEST = "REQUEST"] = "REQUEST", e[e.RESPONSE = "RESPONSE"] = "RESPONSE"
                }(t.MessageType || (t.MessageType = {}))
        },
        "PXk+": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    e && (this.drawId = e.drawId, this.totalStake = e.totalStake, this.prizeDay = e.prizeDay ? new a.LottofiveStatsTicketPrize(e.prizeDay) : null)
                };
            t.LottofiveStatsDrawDay = n
        },
        "Pa+v": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    e && (this.ticketContext = e.ticketContext ? new a.TicketContext(e.ticketContext) : null, this.taxContext = e.taxContext ? new a.TaxContext(e.taxContext) : null, this.oddContext = e.oddContext ? new a.OddContext(e.oddContext) : null)
                };
            t.CalculationContext = n
        },
        PtXo: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function() {
                    function e(e, t) {
                        if (void 0 === t && (t = !0), e && (this.classType = e.classType, t && this.classType)) switch (this.classType) {
                            case "GenericTaxPolicy":
                                return new a.GenericTaxPolicy(e);
                            case "KenyaTaxPolicy":
                                return new a.KenyaTaxPolicy(e);
                            case "PolandTaxPolicy":
                                return new a.PolandTaxPolicy(e);
                            case "NoTaxPolicy":
                                return new a.NoTaxPolicy(e);
                            case "BalkansTaxPolicy":
                                return new a.BalkansTaxPolicy(e);
                            case "GreekTaxPolicy":
                                return new a.GreekTaxPolicy(e)
                        }
                    }
                    return e.prototype.isGenericTaxPolicy = function() {
                        return "GenericTaxPolicy" === this.classType
                    }, e.prototype.isKenyaTaxPolicy = function() {
                        return "KenyaTaxPolicy" === this.classType
                    }, e.prototype.isPolandTaxPolicy = function() {
                        return "PolandTaxPolicy" === this.classType
                    }, e.prototype.isNoTaxPolicy = function() {
                        return "NoTaxPolicy" === this.classType
                    }, e.prototype.isBalkansTaxPolicy = function() {
                        return "BalkansTaxPolicy" === this.classType
                    }, e.prototype.isGreekTaxPolicy = function() {
                        return "GreekTaxPolicy" === this.classType
                    }, e
                }();
            t.TaxPolicy = n
        },
        PwwK: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "LottofiveGameOddSettings", t && (_.payTable = t.payTable ? new r.LottofivePayTable(t.payTable) : null), _
                    }
                    return n(t, e), t
                }(_("ZMgZ").GameOddSettings);
            t.LottofiveGameOddSettings = o
        },
        QCs7: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.code = e.code, this.decimals = e.decimals, this.symbol = e.symbol, this.step = e.step)
            };
            t.Currency = a
        },
        QJpE: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "SxEventResultData", _.cloverBalls = [], t && (t.cloverBalls && t.cloverBalls.forEach((function(e) {
                        _.cloverBalls.push(e)
                    })), _.isWinX2 = t.isWinX2, _.isSecondChance = t.isSecondChance, _.isExtra5balls = t.isExtra5balls), _
                }
                return n(t, e), t
            }(_("RUMs").EventResultData);
            t.SxEventResultData = r
        },
        Qf5O: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "S7GameEventData", t && (_.presenterImageUrl = t.presenterImageUrl, _.croupierName = t.croupierName), _
                }
                return n(t, e), t
            }(_("VqjV").GameEventData);
            t.S7GameEventData = r
        },
        Qp35: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "KnAssets", t && (_.isDeluxe = t.isDeluxe), _
                }
                return n(t, e), t
            }(_("8xXt").Assets);
            t.KnAssets = r
        },
        Qpr1: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "LlEventBlockStats", _.historic = [], t && t.historic && t.historic.forEach((function(e) {
                        _.historic.push(e)
                    })), _
                }
                return n(t, e), t
            }(_("HZPa").EventBlockStats);
            t.LlEventBlockStats = r
        },
        "R+8f": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "KenyaTaxPolicy", t && (_.payoutTax = t.payoutTax ? new r.CustomTax(t.payoutTax) : null), _
                    }
                    return n(t, e), t
                }(_("PtXo").TaxPolicy);
            t.KenyaTaxPolicy = o
        },
        "R/ZZ": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "S2WViewerProfileGameSettings", _
                }
                return n(t, e), t
            }(_("PBHJ").ViewerProfileGameSettings);
            t.S2WViewerProfileGameSettings = r
        },
        RChz: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e) {
                    e.RED = "RED", e.YELLOW = "YELLOW", e.GREEN = "GREEN"
                }(t.LottofiveColourType || (t.LottofiveColourType = {}))
        },
        RKrn: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function() {
                    function e(e, t) {
                        if (void 0 === t && (t = !0), e && (this.classType = e.classType, t && this.classType)) switch (this.classType) {
                            case "PlaylistContent":
                                return new a.PlaylistContent(e);
                            case "RotatingPlaylistContent":
                                return new a.RotatingPlaylistContent(e)
                        }
                    }
                    return e.prototype.isPlaylistContent = function() {
                        return "PlaylistContent" === this.classType
                    }, e.prototype.isRotatingPlaylistContent = function() {
                        return "RotatingPlaylistContent" === this.classType
                    }, e
                }();
            t.Content = n
        },
        RQvK: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "SettlementReportData", _.data = [], t && t.data && t.data.forEach((function(e) {
                            _.data.push(new r.SettlementReportCurrencyLinesData(e))
                        })), _
                    }
                    return n(t, e), t
                }(_("3xEZ").ReportData);
            t.SettlementReportData = o
        },
        RUMs: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function() {
                    function e(e, t) {
                        if (void 0 === t && (t = !0), e && (this.classType = e.classType, t && this.classType)) switch (this.classType) {
                            case "ChEventResultData":
                                return new a.ChEventResultData(e);
                            case "FightEventResultData":
                                return new a.FightEventResultData(e);
                            case "SxEventResultData":
                                return new a.SxEventResultData(e);
                            case "S7EventResultData":
                                return new a.S7EventResultData(e);
                            case "RaceEventResultData":
                                return new a.RaceEventResultData(e);
                            case "BasketEventResultData":
                                return new a.BasketEventResultData(e);
                            case "S2WEventResultData":
                                return new a.S2WEventResultData(e);
                            case "LlEventResultData":
                                return new a.LlEventResultData(e);
                            case "LottofiveEventResultData":
                                return new a.LottofiveEventResultData(e)
                        }
                    }
                    return e.prototype.isChEventResultData = function() {
                        return "ChEventResultData" === this.classType
                    }, e.prototype.isFightEventResultData = function() {
                        return "FightEventResultData" === this.classType
                    }, e.prototype.isSxEventResultData = function() {
                        return "SxEventResultData" === this.classType
                    }, e.prototype.isS7EventResultData = function() {
                        return "S7EventResultData" === this.classType
                    }, e.prototype.isRaceEventResultData = function() {
                        return "RaceEventResultData" === this.classType
                    }, e.prototype.isBasketEventResultData = function() {
                        return "BasketEventResultData" === this.classType
                    }, e.prototype.isS2WEventResultData = function() {
                        return "S2WEventResultData" === this.classType
                    }, e.prototype.isLlEventResultData = function() {
                        return "LlEventResultData" === this.classType
                    }, e.prototype.isLottofiveEventResultData = function() {
                        return "LottofiveEventResultData" === this.classType
                    }, e
                }();
            t.EventResultData = n
        },
        RW3B: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "FightFilter", t && (_.oddSet = t.oddSet, _.contextParticipants = t.contextParticipants, _.resourcePathNameParticipants = t.resourcePathNameParticipants, _.contextVideos = t.contextVideos, _.resourcePathNameVideos = t.resourcePathNameVideos, _.contextHistory = t.contextHistory, _.resourcePathNameHistory = t.resourcePathNameHistory), _
                }
                return n(t, e), t
            }(_("zE96").Filter);
            t.FightFilter = r
        },
        Rcts: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.playerId = e.playerId, this.points = e.points)
            };
            t.BasketPlayerScore = a
        },
        Rg1d: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.events = [], e && (e.eventTime ? this.eventTime = new Date(e.eventTime.toString()) : this.eventTime = null, this.data = e.data ? new a.ChEventBlockData(e.data) : null, e.events && e.events.forEach((function(e) {
                        t.events.push(new a.ChEventKnockoutClassificationEntry(e))
                    })))
                };
            t.ChKnockoutClassificationEntry = n
        },
        RpYQ: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "CheckReportParamsStatus", _
                }
                return n(t, e), t
            }(_("JazB").ReportProcessStatus);
            t.CheckReportParamsStatus = r
        },
        RzNE: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "SpeedwayViewerProfileGameSettings", _
                }
                return n(t, e), t
            }(_("PBHJ").ViewerProfileGameSettings);
            t.SpeedwayViewerProfileGameSettings = r
        },
        S6lY: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.playlists = [], e && (this.id = e.id, this.description = e.description, e.playlists && e.playlists.forEach((function(e) {
                        t.playlists.push(new a.Playlist(e))
                    })), this.gameNdx = e.gameNdx)
                };
            t.Channel = n
        },
        S790: function(e, t, _) {
            "use strict";
            var a, n, r, o, i, s, c, l, u, d, p, h, f, y, m, w, v, x, T, O;
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e) {
                    e.win = "win", e.outcome = "outcome", e.over_under_1_5 = "over_under_1_5", e.over_under_2_5 = "over_under_2_5", e.over_under_3_5 = "over_under_3_5", e.over_under_4_5 = "over_under_4_5", e.ko = "ko", e.round_group = "round_group", e.correct_score = "correct_score", e.round_1 = "round_1", e.round_2 = "round_2", e.round_3 = "round_3", e.round_4 = "round_4", e.round_5 = "round_5", e.ko_round = "ko_round", e.victory_combo = "victory_combo"
                }(T = t.FightMarkets || (t.FightMarkets = {})),
                function(e) {
                    e.black = "black", e.white = "white", e.draw = "draw", e.black_ko = "black_ko", e.black_points = "black_points", e.draw_o = "draw_o", e.white_ko = "white_ko", e.white_points = "white_points", e.over_1_5 = "over_1_5", e.under_1_5 = "under_1_5", e.over_2_5 = "over_2_5", e.under_2_5 = "under_2_5", e.over_3_5 = "over_3_5", e.under_3_5 = "under_3_5", e.over_4_5 = "over_4_5", e.under_4_5 = "under_4_5", e.yes = "yes", e.no = "no", e.black_123 = "black_123", e.black_45p = "black_45p", e.white_123 = "white_123", e.white_45p = "white_45p", e._0_0 = "_0_0", e._0_1 = "_0_1", e._0_2 = "_0_2", e._0_3 = "_0_3", e._0_4 = "_0_4", e._0_5 = "_0_5", e._1_0 = "_1_0", e._1_1 = "_1_1", e._1_2 = "_1_2", e._1_3 = "_1_3", e._1_4 = "_1_4", e._2_0 = "_2_0", e._2_1 = "_2_1", e._2_2 = "_2_2", e._2_3 = "_2_3", e._3_0 = "_3_0", e._3_1 = "_3_1", e._3_2 = "_3_2", e._4_0 = "_4_0", e._4_1 = "_4_1", e._5_0 = "_5_0", e.r1_black_points = "r1_black_points", e.r1_draw = "r1_draw", e.r1_white_points = "r1_white_points", e.r1_black_ko = "r1_black_ko", e.r1_white_ko = "r1_white_ko", e.r1_null = "r1_null", e.r2_black_points = "r2_black_points", e.r2_draw = "r2_draw", e.r2_white_points = "r2_white_points", e.r2_black_ko = "r2_black_ko", e.r2_white_ko = "r2_white_ko", e.r2_null = "r2_null", e.r3_black_points = "r3_black_points", e.r3_draw = "r3_draw", e.r3_white_points = "r3_white_points", e.r3_black_ko = "r3_black_ko", e.r3_white_ko = "r3_white_ko", e.r3_null = "r3_null", e.r4_black_points = "r4_black_points", e.r4_draw = "r4_draw", e.r4_white_points = "r4_white_points", e.r4_black_ko = "r4_black_ko", e.r4_white_ko = "r4_white_ko", e.r4_null = "r4_null", e.r5_black_points = "r5_black_points", e.r5_draw = "r5_draw", e.r5_white_points = "r5_white_points", e.r5_black_ko = "r5_black_ko", e.r5_white_ko = "r5_white_ko", e.r5_null = "r5_null", e.r1_ko = "r1_ko", e.r2_ko = "r2_ko", e.r3_ko = "r3_ko", e.r4_ko = "r4_ko", e.r5_ko = "r5_ko", e.combo = "combo"
                }(O = t.FightOdds || (t.FightOdds = {})), t.FightMarketsTemplate = ((a = {})[T.win] = ((n = {})[O.black] = O.black, n[O.white] = O.white, n[O.draw] = O.draw, n), a[T.outcome] = ((r = {})[O.black_ko] = O.black_ko, r[O.black_points] = O.black_points, r[O.draw_o] = O.draw_o, r[O.white_ko] = O.white_ko, r[O.white_points] = O.white_points, r), a[T.over_under_1_5] = ((o = {})[O.over_1_5] = O.over_1_5, o[O.under_1_5] = O.under_1_5, o), a[T.over_under_2_5] = ((i = {})[O.over_2_5] = O.over_2_5, i[O.under_2_5] = O.under_2_5, i), a[T.over_under_3_5] = ((s = {})[O.over_3_5] = O.over_3_5, s[O.under_3_5] = O.under_3_5, s), a[T.over_under_4_5] = ((c = {})[O.over_4_5] = O.over_4_5, c[O.under_4_5] = O.under_4_5, c), a[T.ko] = ((l = {})[O.yes] = O.yes, l[O.no] = O.no, l), a[T.round_group] = ((u = {})[O.black_123] = O.black_123, u[O.black_45p] = O.black_45p, u[O.white_123] = O.white_123, u[O.white_45p] = O.white_45p, u), a[T.correct_score] = ((d = {})[O._0_0] = O._0_0, d[O._0_1] = O._0_1, d[O._0_2] = O._0_2, d[O._0_3] = O._0_3, d[O._0_4] = O._0_4, d[O._0_5] = O._0_5, d[O._1_0] = O._1_0, d[O._1_1] = O._1_1, d[O._1_2] = O._1_2, d[O._1_3] = O._1_3, d[O._1_4] = O._1_4, d[O._2_0] = O._2_0, d[O._2_1] = O._2_1, d[O._2_2] = O._2_2, d[O._2_3] = O._2_3, d[O._3_0] = O._3_0, d[O._3_1] = O._3_1, d[O._3_2] = O._3_2, d[O._4_0] = O._4_0, d[O._4_1] = O._4_1, d[O._5_0] = O._5_0, d), a[T.round_1] = ((p = {})[O.r1_black_points] = O.r1_black_points, p[O.r1_draw] = O.r1_draw, p[O.r1_white_points] = O.r1_white_points, p[O.r1_black_ko] = O.r1_black_ko, p[O.r1_white_ko] = O.r1_white_ko, p[O.r1_null] = O.r1_null, p), a[T.round_2] = ((h = {})[O.r2_black_points] = O.r2_black_points, h[O.r2_draw] = O.r2_draw, h[O.r2_white_points] = O.r2_white_points, h[O.r2_black_ko] = O.r2_black_ko, h[O.r2_white_ko] = O.r2_white_ko, h[O.r2_null] = O.r2_null, h), a[T.round_3] = ((f = {})[O.r3_black_points] = O.r3_black_points, f[O.r3_draw] = O.r3_draw, f[O.r3_white_points] = O.r3_white_points, f[O.r3_black_ko] = O.r3_black_ko, f[O.r3_white_ko] = O.r3_white_ko, f[O.r3_null] = O.r3_null, f), a[T.round_4] = ((y = {})[O.r4_black_points] = O.r4_black_points, y[O.r4_draw] = O.r4_draw, y[O.r4_white_points] = O.r4_white_points, y[O.r4_black_ko] = O.r4_black_ko, y[O.r4_white_ko] = O.r4_white_ko, y[O.r4_null] = O.r4_null, y), a[T.round_5] = ((m = {})[O.r5_black_points] = O.r5_black_points, m[O.r5_draw] = O.r5_draw, m[O.r5_white_points] = O.r5_white_points, m[O.r5_black_ko] = O.r5_black_ko, m[O.r5_white_ko] = O.r5_white_ko, m[O.r5_null] = O.r5_null, m), a[T.ko_round] = ((w = {})[O.r1_ko] = O.r1_ko, w[O.r2_ko] = O.r2_ko, w[O.r3_ko] = O.r3_ko, w[O.r4_ko] = O.r4_ko, w[O.r5_ko] = O.r5_ko, w), a[T.victory_combo] = ((v = {})[O.combo] = O.combo, v), a), t.FightOddsTemplate = ((x = {})[O.black] = T.win, x[O.white] = T.win, x[O.draw] = T.win, x[O.black_ko] = T.outcome, x[O.black_points] = T.outcome, x[O.draw_o] = T.outcome, x[O.white_ko] = T.outcome, x[O.white_points] = T.outcome, x[O.over_1_5] = T.over_under_1_5, x[O.under_1_5] = T.over_under_1_5, x[O.over_2_5] = T.over_under_2_5, x[O.under_2_5] = T.over_under_2_5, x[O.over_3_5] = T.over_under_3_5, x[O.under_3_5] = T.over_under_3_5, x[O.over_4_5] = T.over_under_4_5, x[O.under_4_5] = T.over_under_4_5, x[O.yes] = T.ko, x[O.no] = T.ko, x[O.black_123] = T.round_group, x[O.black_45p] = T.round_group, x[O.white_123] = T.round_group, x[O.white_45p] = T.round_group, x[O._0_0] = T.correct_score, x[O._0_1] = T.correct_score, x[O._0_2] = T.correct_score, x[O._0_3] = T.correct_score, x[O._0_4] = T.correct_score, x[O._0_5] = T.correct_score, x[O._1_0] = T.correct_score, x[O._1_1] = T.correct_score, x[O._1_2] = T.correct_score, x[O._1_3] = T.correct_score, x[O._1_4] = T.correct_score, x[O._2_0] = T.correct_score, x[O._2_1] = T.correct_score, x[O._2_2] = T.correct_score, x[O._2_3] = T.correct_score, x[O._3_0] = T.correct_score, x[O._3_1] = T.correct_score, x[O._3_2] = T.correct_score, x[O._4_0] = T.correct_score, x[O._4_1] = T.correct_score, x[O._5_0] = T.correct_score, x[O.r1_black_points] = T.round_1, x[O.r1_draw] = T.round_1, x[O.r1_white_points] = T.round_1, x[O.r1_black_ko] = T.round_1, x[O.r1_white_ko] = T.round_1, x[O.r1_null] = T.round_1, x[O.r2_black_points] = T.round_2, x[O.r2_draw] = T.round_2, x[O.r2_white_points] = T.round_2, x[O.r2_black_ko] = T.round_2, x[O.r2_white_ko] = T.round_2, x[O.r2_null] = T.round_2, x[O.r3_black_points] = T.round_3, x[O.r3_draw] = T.round_3, x[O.r3_white_points] = T.round_3, x[O.r3_black_ko] = T.round_3, x[O.r3_white_ko] = T.round_3, x[O.r3_null] = T.round_3, x[O.r4_black_points] = T.round_4, x[O.r4_draw] = T.round_4, x[O.r4_white_points] = T.round_4, x[O.r4_black_ko] = T.round_4, x[O.r4_white_ko] = T.round_4, x[O.r4_null] = T.round_4, x[O.r5_black_points] = T.round_5, x[O.r5_draw] = T.round_5, x[O.r5_white_points] = T.round_5, x[O.r5_black_ko] = T.round_5, x[O.r5_white_ko] = T.round_5, x[O.r5_null] = T.round_5, x[O.r1_ko] = T.ko_round, x[O.r2_ko] = T.ko_round, x[O.r3_ko] = T.ko_round, x[O.r4_ko] = T.ko_round, x[O.r5_ko] = T.ko_round, x[O.combo] = T.victory_combo, x)
        },
        "SQ+8": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "TrottingEventBlockData", _
                }
                return n(t, e), t
            }(_("AjTw").EventBlockData);
            t.TrottingEventBlockData = r
        },
        Sjh9: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "SpeedwayParticipant", t && (_.speed = t.speed, _.stamina = t.stamina, _.wins = t.wins), _
                }
                return n(t, e), t
            }(_("xeXX").RaceParticipant);
            t.SpeedwayParticipant = r
        },
        SvvP: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.walletId = e.walletId, this.balance = e.balance)
            };
            t.SessionStatusWallets = a
        },
        T7A5: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.dailySchedule = [], e && (e.startTime ? this.startTime = new Date(e.startTime.toString()) : this.startTime = null, e.endTime ? this.endTime = new Date(e.endTime.toString()) : this.endTime = null, this.timezone = e.timezone, e.dailySchedule && e.dailySchedule.forEach((function(e) {
                        t.dailySchedule.push(new a.DailySchedule(e))
                    })))
                };
            t.SchedulerConfiguration = n
        },
        TDDE: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "LottoResultReportData", _.eventResultsByCity = {}, t && t.eventResultsByCity && Object.keys(t.eventResultsByCity).forEach((function(e) {
                        _.eventResultsByCity[e] = t.eventResultsByCity[e]
                    })), _
                }
                return n(t, e), t
            }(_("3xEZ").ReportData);
            t.LottoResultReportData = r
        },
        TWor: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "UnitSessionStatus", t && (_.entityId = t.entityId), _
                }
                return n(t, e), t
            }(_("ojBr").OddContext);
            t.UnitSessionStatus = r
        },
        "Tax+": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                var t = this;
                this.participants = [], this.finalOutcome = [], e && (this.eventId = e.eventId, e.participants && e.participants.forEach((function(e) {
                    t.participants.push(e)
                })), this.result = e.result, e.finalOutcome && e.finalOutcome.forEach((function(e) {
                    t.finalOutcome.push(e)
                })), this.penalty = e.penalty, this.classifiedTeam = e.classifiedTeam)
            };
            t.ChResultStat = a
        },
        TmWM: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.type = e.type, this.player = e.player, this.score = e.score, this.sec = e.sec)
            };
            t.FightVideoHappening = a,
                function(e) {
                    ! function(e) {
                        e.P = "P", e.K = "K", e.B = "B"
                    }(e.TypeEnum || (e.TypeEnum = {}))
                }(a = t.FightVideoHappening || (t.FightVideoHappening = {})), t.FightVideoHappening = a,
                function(e) {
                    ! function(e) {
                        e.B = "B", e.W = "W"
                    }(e.PlayerEnum || (e.PlayerEnum = {}))
                }(a = t.FightVideoHappening || (t.FightVideoHappening = {})), t.FightVideoHappening = a
        },
        Tqdb: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "DogParticipant", t && (_.age = t.age, _.sex = t.sex, _.timeSinceSeason = t.timeSinceSeason, _.art = t.art, _.aggressiveness = t.aggressiveness, _.bestTime = t.bestTime, _.currentWeight = t.currentWeight, _.idealWeight = t.idealWeight, _.racingLine = t.racingLine, _.ability = t.ability, _.star = t.star, _.pace = t.pace), _
                }
                return n(t, e), t
            }(_("xeXX").RaceParticipant);
            t.DogParticipant = r
        },
        UNbE: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                var t = this;
                this.tags = [], e && (e.startDate ? this.startDate = new Date(e.startDate.toString()) : this.startDate = null, e.endDate ? this.endDate = new Date(e.endDate.toString()) : this.endDate = null, this.entityClientId = e.entityClientId, this.entityId = e.entityId, this.timezone = e.timezone, this.entityPlayed = e.entityPlayed, this.currency = e.currency, this.stake = e.stake, this.won = e.won, this.taxes = e.taxes, this.taxesPaidOut = e.taxesPaidOut, this.jackpotContribution = e.jackpotContribution, this.jackpot = e.jackpot, this.megajackpot = e.megajackpot, this.megajackpotContribution = e.megajackpotContribution, this.stakeCancelled = e.stakeCancelled, this.paid = e.paid, this.lapsed = e.lapsed, this.playedTickets = e.playedTickets, this.cancelledtickets = e.cancelledtickets, this.wonTickets = e.wonTickets, this.playlist = e.playlist, this.gameType = e.gameType, this.jackpotPaid = e.jackpotPaid, this.megajackpotPaid = e.megajackpotPaid, e.tags && e.tags.forEach((function(e) {
                    t.tags.push(e)
                })))
            };
            t.Stat = a
        },
        "UO1+": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                var t = this;
                this.sharedBy = [], this.outsiderPosRunners = [], e && (this.serialNumber = e.serialNumber, this.imei1 = e.imei1, this.imei2 = e.imei2, this.allocation = e.allocation, this.agentCode = e.agentCode, this.userId = e.userId, e.sharedBy && e.sharedBy.forEach((function(e) {
                    t.sharedBy.push(e)
                })), e.outsiderPosRunners && e.outsiderPosRunners.forEach((function(e) {
                    t.outsiderPosRunners.push(e)
                })), this.totalNumberOfTickets = e.totalNumberOfTickets, this.totalWon = e.totalWon, this.totalStake = e.totalStake, this.totalSessionTime = e.totalSessionTime, this.numberOfCancelledTickets = e.numberOfCancelledTickets, this.totalCancelledAmount = e.totalCancelledAmount, e.dateOfLastLogin ? this.dateOfLastLogin = new Date(e.dateOfLastLogin.toString()) : this.dateOfLastLogin = null)
            };
            t.PosReportRow = a
        },
        UY3E: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "TrottingGameOddSettings", _
                }
                return n(t, e), t
            }(_("aDCO").GameFixedOddSettings);
            t.TrottingGameOddSettings = r
        },
        Unox: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e) {
                    e.LEAGUE = "LEAGUE", e.CHAMPION = "CHAMPION", e.CUP = "CUP", e.SOCCER = "SOCCER"
                }(t.ChCompetitionType || (t.ChCompetitionType = {}))
        },
        Uq3Y: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.cancellationEnabled = e.cancellationEnabled, this.sameDayCancel = e.sameDayCancel, this.maximumCancellationTime = e.maximumCancellationTime, this.maximumNumberTicketCancelled = e.maximumNumberTicketCancelled, this.cancellationMode = e.cancellationMode, this.days = e.days, this.hours = e.hours, this.minutes = e.minutes)
            };
            t.TicketCancellationSetting = a,
                function(e) {
                    ! function(e) {
                        e.NATURAL = "NATURAL", e.FROMNOWTOTHELAST = "FROMNOWTOTHELAST"
                    }(e.CancellationModeEnum || (e.CancellationModeEnum = {}))
                }(a = t.TicketCancellationSetting || (t.TicketCancellationSetting = {})), t.TicketCancellationSetting = a
        },
        VBna: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.ticketId = e.ticketId, this.prize = e.prize, this.city = e.city)
            };
            t.LottofiveStatsTicketPrize = a
        },
        VCcV: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "HorseFilter", t && (_.stadiumCode = t.stadiumCode, _.contextJockeys = t.contextJockeys, _.resourcePathNameJockeys = t.resourcePathNameJockeys, _.raceOddsLevel = t.raceOddsLevel), _
                }
                return n(t, e), t
            }(_("4Lmp").RacesFilter);
            t.HorseFilter = r,
                function(e) {
                    ! function(e) {
                        e.ALL = "ALL", e.ONLYGOLDBET = "ONLYGOLDBET", e.LIGHT = "LIGHT", e.MEDIUM = "MEDIUM", e.HARD = "HARD"
                    }(e.RaceOddsLevelEnum || (e.RaceOddsLevelEnum = {}))
                }(r = t.HorseFilter || (t.HorseFilter = {})), t.HorseFilter = r
        },
        VhTC: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "LlEventBlockLiveStats", _.result = [], t && t.result && t.result.forEach((function(e) {
                        _.result.push(e)
                    })), _
                }
                return n(t, e), t
            }(_("CgkD").EventBlockLiveStats);
            t.LlEventBlockLiveStats = r
        },
        VqjV: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function() {
                    function e(e, t) {
                        if (void 0 === t && (t = !0), e && (this.classType = e.classType, t && this.classType)) switch (this.classType) {
                            case "LottofiveGameEventData":
                                return new a.LottofiveGameEventData(e);
                            case "BasketGameEventData":
                                return new a.BasketGameEventData(e);
                            case "FightGameEventData":
                                return new a.FightGameEventData(e);
                            case "S7GameEventData":
                                return new a.S7GameEventData(e);
                            case "LkGameEventData":
                                return new a.LkGameEventData(e);
                            case "LlGameEventData":
                                return new a.LlGameEventData(e);
                            case "RaceGameEventData":
                                return new a.RaceGameEventData(e);
                            case "S2WGameEventData":
                                return new a.S2WGameEventData(e)
                        }
                    }
                    return e.prototype.isLottofiveGameEventData = function() {
                        return "LottofiveGameEventData" === this.classType
                    }, e.prototype.isBasketGameEventData = function() {
                        return "BasketGameEventData" === this.classType
                    }, e.prototype.isFightGameEventData = function() {
                        return "FightGameEventData" === this.classType
                    }, e.prototype.isS7GameEventData = function() {
                        return "S7GameEventData" === this.classType
                    }, e.prototype.isLkGameEventData = function() {
                        return "LkGameEventData" === this.classType
                    }, e.prototype.isLlGameEventData = function() {
                        return "LlGameEventData" === this.classType
                    }, e.prototype.isRaceGameEventData = function() {
                        return "RaceGameEventData" === this.classType
                    }, e.prototype.isS2WGameEventData = function() {
                        return "S2WGameEventData" === this.classType
                    }, e
                }();
            t.GameEventData = n
        },
        WCjm: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.wonCount = e.wonCount, this.wonAmount = e.wonAmount, this.wonBonus = e.wonBonus)
            };
            t.WonData = a
        },
        WIE0: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "StakeTax", t && (_.percentageMode = t.percentageMode), _
                }
                return n(t, e), t
            }(_("uo+l").GenericTax);
            t.StakeTax = r,
                function(e) {
                    ! function(e) {
                        e.INDIRECT = "INDIRECT", e.DIRECT = "DIRECT"
                    }(e.PercentageModeEnum || (e.PercentageModeEnum = {}))
                }(r = t.StakeTax || (t.StakeTax = {})), t.StakeTax = r
        },
        WKvU: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.playersRedId = [], this.playersBlueId = [], this.pointsStats = [], this.timeIntervals = [], this.happenings = [], e && (this.mediaId = e.mediaId, this.enabled = e.enabled, e.playersRedId && e.playersRedId.forEach((function(e) {
                        t.playersRedId.push(e)
                    })), e.playersBlueId && e.playersBlueId.forEach((function(e) {
                        t.playersBlueId.push(e)
                    })), this.scoreMatchRed = e.scoreMatchRed ? new a.BasketTeamScore(e.scoreMatchRed) : null, this.scoreMatchBlue = e.scoreMatchBlue ? new a.BasketTeamScore(e.scoreMatchBlue) : null, e.pointsStats && e.pointsStats.forEach((function(e) {
                        t.pointsStats.push(e)
                    })), this.scoreExtraTimeRed = e.scoreExtraTimeRed ? new a.BasketTeamScore(e.scoreExtraTimeRed) : null, this.scoreExtraTimeBlue = e.scoreExtraTimeBlue ? new a.BasketTeamScore(e.scoreExtraTimeBlue) : null, this.timeDuration = e.timeDuration, this.timePlayed = e.timePlayed, e.timeIntervals && e.timeIntervals.forEach((function(e) {
                        t.timeIntervals.push(new a.BasketTimeInterval(e))
                    })), e.happenings && e.happenings.forEach((function(e) {
                        t.happenings.push(new a.BasketVideoHappening(e))
                    })))
                };
            t.BasketVideoSlot = n
        },
        WeJq: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.odds = [], e && (this.id = e.id, this.name = e.name, e.odds && e.odds.forEach((function(e) {
                        t.odds.push(new a.Odd(e))
                    })))
                };
            t.Market = n
        },
        WiHH: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "GreekTaxPolicy", t && (_.columnValue = t.columnValue), _
                }
                return n(t, e), t
            }(_("PtXo").TaxPolicy);
            t.GreekTaxPolicy = r
        },
        X0TO: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function() {
                    function e(e, t) {
                        if (void 0 === t && (t = !0), e && (this.classType = e.classType, this.gameType = e.gameType, t && this.classType)) switch (this.classType) {
                            case "ChMobileProfileGameSettings":
                                return new a.ChMobileProfileGameSettings(e)
                        }
                    }
                    return e.prototype.isChMobileProfileGameSettings = function() {
                        return "ChMobileProfileGameSettings" === this.classType
                    }, e
                }();
            t.MobileProfileGameSettings = n
        },
        X30y: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "BasketTicketEventData", _.participants = [], t && (t.participants && t.participants.forEach((function(e) {
                            _.participants.push(new r.BasketParticipant(e))
                        })), _.data = t.data ? new r.BasketEventBlockData(t.data) : null, _.matchOrder = t.matchOrder), _
                    }
                    return n(t, e), t
                }(_("Dhrw").TicketEventData);
            t.BasketTicketEventData = o
        },
        X6L1: function(e, t, _) {
            "use strict";
            var a, n, r, o, i, s, c, l, u, d, p, h, f, y;
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e) {
                    e.win = "win", e.exacta = "exacta", e.trifecta = "trifecta", e.place = "place", e.show = "show", e.quinella = "quinella", e.even_odd = "even_odd", e.over_under = "over_under", e.system_two = "system_two", e.system_three = "system_three"
                }(f = t.MotorbikeMarkets || (t.MotorbikeMarkets = {})),
                function(e) {
                    e.win_1 = "win_1", e.win_2 = "win_2", e.win_3 = "win_3", e.win_4 = "win_4", e.win_5 = "win_5", e.win_6 = "win_6", e.exacta_1_2 = "exacta_1_2", e.exacta_1_3 = "exacta_1_3", e.exacta_1_4 = "exacta_1_4", e.exacta_1_5 = "exacta_1_5", e.exacta_1_6 = "exacta_1_6", e.exacta_2_1 = "exacta_2_1", e.exacta_2_3 = "exacta_2_3", e.exacta_2_4 = "exacta_2_4", e.exacta_2_5 = "exacta_2_5", e.exacta_2_6 = "exacta_2_6", e.exacta_3_1 = "exacta_3_1", e.exacta_3_2 = "exacta_3_2", e.exacta_3_4 = "exacta_3_4", e.exacta_3_5 = "exacta_3_5", e.exacta_3_6 = "exacta_3_6", e.exacta_4_1 = "exacta_4_1", e.exacta_4_2 = "exacta_4_2", e.exacta_4_3 = "exacta_4_3", e.exacta_4_5 = "exacta_4_5", e.exacta_4_6 = "exacta_4_6", e.exacta_5_1 = "exacta_5_1", e.exacta_5_2 = "exacta_5_2", e.exacta_5_3 = "exacta_5_3", e.exacta_5_4 = "exacta_5_4", e.exacta_5_6 = "exacta_5_6", e.exacta_6_1 = "exacta_6_1", e.exacta_6_2 = "exacta_6_2", e.exacta_6_3 = "exacta_6_3", e.exacta_6_4 = "exacta_6_4", e.exacta_6_5 = "exacta_6_5", e.trifecta = "trifecta", e.place_1 = "place_1", e.place_2 = "place_2", e.place_3 = "place_3", e.place_4 = "place_4", e.place_5 = "place_5", e.place_6 = "place_6", e.show_1 = "show_1", e.show_2 = "show_2", e.show_3 = "show_3", e.show_4 = "show_4", e.show_5 = "show_5", e.show_6 = "show_6", e.quinella_1_2 = "quinella_1_2", e.quinella_1_3 = "quinella_1_3", e.quinella_1_4 = "quinella_1_4", e.quinella_1_5 = "quinella_1_5", e.quinella_1_6 = "quinella_1_6", e.quinella_2_3 = "quinella_2_3", e.quinella_2_4 = "quinella_2_4", e.quinella_2_5 = "quinella_2_5", e.quinella_2_6 = "quinella_2_6", e.quinella_3_4 = "quinella_3_4", e.quinella_3_5 = "quinella_3_5", e.quinella_3_6 = "quinella_3_6", e.quinella_4_5 = "quinella_4_5", e.quinella_4_6 = "quinella_4_6", e.quinella_5_6 = "quinella_5_6", e.even = "even", e.odd = "odd", e.over = "over", e.under = "under", e.system_two = "system_two", e.system_three = "system_three"
                }(y = t.MotorbikeOdds || (t.MotorbikeOdds = {})), t.MotorbikeMarketsTemplate = ((a = {})[f.win] = ((n = {})[y.win_1] = y.win_1, n[y.win_2] = y.win_2, n[y.win_3] = y.win_3, n[y.win_4] = y.win_4, n[y.win_5] = y.win_5, n[y.win_6] = y.win_6, n), a[f.exacta] = ((r = {})[y.exacta_1_2] = y.exacta_1_2, r[y.exacta_1_3] = y.exacta_1_3, r[y.exacta_1_4] = y.exacta_1_4, r[y.exacta_1_5] = y.exacta_1_5, r[y.exacta_1_6] = y.exacta_1_6, r[y.exacta_2_1] = y.exacta_2_1, r[y.exacta_2_3] = y.exacta_2_3, r[y.exacta_2_4] = y.exacta_2_4, r[y.exacta_2_5] = y.exacta_2_5, r[y.exacta_2_6] = y.exacta_2_6, r[y.exacta_3_1] = y.exacta_3_1, r[y.exacta_3_2] = y.exacta_3_2, r[y.exacta_3_4] = y.exacta_3_4, r[y.exacta_3_5] = y.exacta_3_5, r[y.exacta_3_6] = y.exacta_3_6, r[y.exacta_4_1] = y.exacta_4_1, r[y.exacta_4_2] = y.exacta_4_2, r[y.exacta_4_3] = y.exacta_4_3, r[y.exacta_4_5] = y.exacta_4_5, r[y.exacta_4_6] = y.exacta_4_6, r[y.exacta_5_1] = y.exacta_5_1, r[y.exacta_5_2] = y.exacta_5_2, r[y.exacta_5_3] = y.exacta_5_3, r[y.exacta_5_4] = y.exacta_5_4, r[y.exacta_5_6] = y.exacta_5_6, r[y.exacta_6_1] = y.exacta_6_1, r[y.exacta_6_2] = y.exacta_6_2, r[y.exacta_6_3] = y.exacta_6_3, r[y.exacta_6_4] = y.exacta_6_4, r[y.exacta_6_5] = y.exacta_6_5, r), a[f.trifecta] = ((o = {})[y.trifecta] = y.trifecta, o), a[f.place] = ((i = {})[y.place_1] = y.place_1, i[y.place_2] = y.place_2, i[y.place_3] = y.place_3, i[y.place_4] = y.place_4, i[y.place_5] = y.place_5, i[y.place_6] = y.place_6, i), a[f.show] = ((s = {})[y.show_1] = y.show_1, s[y.show_2] = y.show_2, s[y.show_3] = y.show_3, s[y.show_4] = y.show_4, s[y.show_5] = y.show_5, s[y.show_6] = y.show_6, s), a[f.quinella] = ((c = {})[y.quinella_1_2] = y.quinella_1_2, c[y.quinella_1_3] = y.quinella_1_3, c[y.quinella_1_4] = y.quinella_1_4, c[y.quinella_1_5] = y.quinella_1_5, c[y.quinella_1_6] = y.quinella_1_6, c[y.quinella_2_3] = y.quinella_2_3, c[y.quinella_2_4] = y.quinella_2_4, c[y.quinella_2_5] = y.quinella_2_5, c[y.quinella_2_6] = y.quinella_2_6, c[y.quinella_3_4] = y.quinella_3_4, c[y.quinella_3_5] = y.quinella_3_5, c[y.quinella_3_6] = y.quinella_3_6, c[y.quinella_4_5] = y.quinella_4_5, c[y.quinella_4_6] = y.quinella_4_6, c[y.quinella_5_6] = y.quinella_5_6, c), a[f.even_odd] = ((l = {})[y.even] = y.even, l[y.odd] = y.odd, l), a[f.over_under] = ((u = {})[y.over] = y.over, u[y.under] = y.under, u), a[f.system_two] = ((d = {})[y.system_two] = y.system_two, d), a[f.system_three] = ((p = {})[y.system_three] = y.system_three, p), a), t.MotorbikeOddsTemplate = ((h = {})[y.win_1] = f.win, h[y.win_2] = f.win, h[y.win_3] = f.win, h[y.win_4] = f.win, h[y.win_5] = f.win, h[y.win_6] = f.win, h[y.exacta_1_2] = f.exacta, h[y.exacta_1_3] = f.exacta, h[y.exacta_1_4] = f.exacta, h[y.exacta_1_5] = f.exacta, h[y.exacta_1_6] = f.exacta, h[y.exacta_2_1] = f.exacta, h[y.exacta_2_3] = f.exacta, h[y.exacta_2_4] = f.exacta, h[y.exacta_2_5] = f.exacta, h[y.exacta_2_6] = f.exacta, h[y.exacta_3_1] = f.exacta, h[y.exacta_3_2] = f.exacta, h[y.exacta_3_4] = f.exacta, h[y.exacta_3_5] = f.exacta, h[y.exacta_3_6] = f.exacta, h[y.exacta_4_1] = f.exacta, h[y.exacta_4_2] = f.exacta, h[y.exacta_4_3] = f.exacta, h[y.exacta_4_5] = f.exacta, h[y.exacta_4_6] = f.exacta, h[y.exacta_5_1] = f.exacta, h[y.exacta_5_2] = f.exacta, h[y.exacta_5_3] = f.exacta, h[y.exacta_5_4] = f.exacta, h[y.exacta_5_6] = f.exacta, h[y.exacta_6_1] = f.exacta, h[y.exacta_6_2] = f.exacta, h[y.exacta_6_3] = f.exacta, h[y.exacta_6_4] = f.exacta, h[y.exacta_6_5] = f.exacta, h[y.trifecta] = f.trifecta, h[y.place_1] = f.place, h[y.place_2] = f.place, h[y.place_3] = f.place, h[y.place_4] = f.place, h[y.place_5] = f.place, h[y.place_6] = f.place, h[y.show_1] = f.show, h[y.show_2] = f.show, h[y.show_3] = f.show, h[y.show_4] = f.show, h[y.show_5] = f.show, h[y.show_6] = f.show, h[y.quinella_1_2] = f.quinella, h[y.quinella_1_3] = f.quinella, h[y.quinella_1_4] = f.quinella, h[y.quinella_1_5] = f.quinella, h[y.quinella_1_6] = f.quinella, h[y.quinella_2_3] = f.quinella, h[y.quinella_2_4] = f.quinella, h[y.quinella_2_5] = f.quinella, h[y.quinella_2_6] = f.quinella, h[y.quinella_3_4] = f.quinella, h[y.quinella_3_5] = f.quinella, h[y.quinella_3_6] = f.quinella, h[y.quinella_4_5] = f.quinella, h[y.quinella_4_6] = f.quinella, h[y.quinella_5_6] = f.quinella, h[y.even] = f.even_odd, h[y.odd] = f.even_odd, h[y.over] = f.over_under, h[y.under] = f.over_under, h[y.system_two] = f.system_two, h[y.system_three] = f.system_three, h)
        },
        XGEp: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.bottomBannerPlaylist = [], this.gameSettings = [], this.categories = [], e && (this.landingStyle = e.landingStyle, this.hideUsernameAccount = e.hideUsernameAccount, this.hideCredit = e.hideCredit, this.leftButton = e.leftButton, this.hideBetHistoryTop = e.hideBetHistoryTop, this.hideCreditTop = e.hideCreditTop, this.favouritePlaylist = e.favouritePlaylist, this.favouriteHeader = e.favouriteHeader, this.hideRules = e.hideRules, this.marketSelectorStyle = e.marketSelectorStyle, this.allMarketsSelectionsDisplayed = e.allMarketsSelectionsDisplayed, this.hideBottomBanner = e.hideBottomBanner, e.bottomBannerPlaylist && e.bottomBannerPlaylist.forEach((function(e) {
                        t.bottomBannerPlaylist.push(e)
                    })), this.hideCategoriesSelectorBar = e.hideCategoriesSelectorBar, e.gameSettings && e.gameSettings.forEach((function(e) {
                        t.gameSettings.push(new a.MobileProfileGameSettings(e))
                    })), e.categories && e.categories.forEach((function(e) {
                        t.categories.push(new a.MobileProfileCategory(e))
                    })))
                };
            t.MobileProfileSettings = n,
                function(e) {
                    ! function(e) {
                        e.CLASSIC = "CLASSIC", e.ICONMENU = "ICONMENU"
                    }(e.LandingStyleEnum || (e.LandingStyleEnum = {}))
                }(n = t.MobileProfileSettings || (t.MobileProfileSettings = {})), t.MobileProfileSettings = n,
                function(e) {
                    ! function(e) {
                        e.NAVIGATIONDRAWER = "NAVIGATIONDRAWER", e.CUSTOMERHOME = "CUSTOMERHOME"
                    }(e.LeftButtonEnum || (e.LeftButtonEnum = {}))
                }(n = t.MobileProfileSettings || (t.MobileProfileSettings = {})), t.MobileProfileSettings = n,
                function(e) {
                    ! function(e) {
                        e.DROPDOWN = "DROPDOWN", e.TABS = "TABS"
                    }(e.MarketSelectorStyleEnum || (e.MarketSelectorStyleEnum = {}))
                }(n = t.MobileProfileSettings || (t.MobileProfileSettings = {})), t.MobileProfileSettings = n
        },
        XaAp: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.finalOutcome = [], this.bets = [], e && (this.eventId = e.eventId, this.extId = e.extId, this.extData = e.extData, this.playlistId = e.playlistId, this.playlistDescription = e.playlistDescription, this.gameType = e.gameType ? new a.GameType(e.gameType) : null, e.eventTime ? this.eventTime = new Date(e.eventTime.toString()) : this.eventTime = null, this.serverStatus = e.serverStatus, e.finalOutcome && e.finalOutcome.forEach((function(e) {
                        t.finalOutcome.push(e)
                    })), this.data = e.data ? new a.TicketEventData(e.data) : null, this.isBanker = e.isBanker, e.bets && e.bets.forEach((function(e) {
                        t.bets.push(new a.TicketBet(e))
                    })))
                };
            t.TicketEvent = n,
                function(e) {
                    ! function(e) {
                        e.OPEN = "OPEN", e.SCHEDULED = "SCHEDULED", e.CANCELLED = "CANCELLED", e.RESOLVED = "RESOLVED", e.ERROR = "ERROR"
                    }(e.ServerStatusEnum || (e.ServerStatusEnum = {}))
                }(n = t.TicketEvent || (t.TicketEvent = {})), t.TicketEvent = n
        },
        "Y+nQ": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "HorseAssets", t && (_.is3D = t.is3D, _.auroraGtpacksId = t.auroraGtpacksId), _
                }
                return n(t, e), t
            }(_("vW0J").RacesAssets);
            t.HorseAssets = r
        },
        Y5UR: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.finalOutcome = [], this.wonMarkets = [], e && (this.data = e.data ? new a.EventResultData(e.data) : null, e.finalOutcome && e.finalOutcome.forEach((function(e) {
                        t.finalOutcome.push(e)
                    })), e.wonMarkets && e.wonMarkets.forEach((function(e) {
                        t.wonMarkets.push(e)
                    })), this.contentDuration = e.contentDuration)
                };
            t.EventResult = n
        },
        YMWy: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "TrottingAssets", t && (_.is3D = t.is3D, _.auroraGtpacksId = t.auroraGtpacksId), _
                }
                return n(t, e), t
            }(_("vW0J").RacesAssets);
            t.TrottingAssets = r
        },
        YMyr: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "S7GameOddSettings", t && (_.payTable = t.payTable ? new r.S7PayTable(t.payTable) : null), _
                    }
                    return n(t, e), t
                }(_("ZMgZ").GameOddSettings);
            t.S7GameOddSettings = o
        },
        YnJZ: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "LkCashierProfileGameSettings", t && (_.multiplier = t.multiplier, _.repeatBet = t.repeatBet), _
                }
                return n(t, e), t
            }(_("nfOZ").CashierProfileGameSettings);
            t.LkCashierProfileGameSettings = r
        },
        Z1tO: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "BasketGameEventData", t && (_.resultPointsPregameRed = t.resultPointsPregameRed, _.resultPointsPregameBlue = t.resultPointsPregameBlue), _
                }
                return n(t, e), t
            }(_("VqjV").GameEventData);
            t.BasketGameEventData = r
        },
        ZLzr: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "BasketFilter", t && (_.resourcePathRanking = t.resourcePathRanking, _.resourcePathVideo = t.resourcePathVideo, _.resourcePathCoverage = t.resourcePathCoverage, _.contextVideo = t.contextVideo), _
                }
                return n(t, e), t
            }(_("zE96").Filter);
            t.BasketFilter = r
        },
        ZMgZ: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function() {
                    function e(e, t) {
                        if (void 0 === t && (t = !0), e && (this.classType = e.classType, this.playlistId = e.playlistId, t && this.classType)) switch (this.classType) {
                            case "LkGameOddSettings":
                                return new a.LkGameOddSettings(e);
                            case "S2WGameOddSettings":
                                return new a.S2WGameOddSettings(e);
                            case "MotorbikeGameOddSettings":
                                return new a.MotorbikeGameOddSettings(e);
                            case "TrottingGameOddSettings":
                                return new a.TrottingGameOddSettings(e);
                            case "LlGameOddSettings":
                                return new a.LlGameOddSettings(e);
                            case "KnGameOddSettings":
                                return new a.KnGameOddSettings(e);
                            case "DirttrackGameOddSettings":
                                return new a.DirttrackGameOddSettings(e);
                            case "S7GameOddSettings":
                                return new a.S7GameOddSettings(e);
                            case "KartGameOddSettings":
                                return new a.KartGameOddSettings(e);
                            case "BasketGameOddSettings":
                                return new a.BasketGameOddSettings(e);
                            case "HorseGameOddSettings":
                                return new a.HorseGameOddSettings(e);
                            case "ChGameOddSettings":
                                return new a.ChGameOddSettings(e);
                            case "SpeedwayGameOddSettings":
                                return new a.SpeedwayGameOddSettings(e);
                            case "FightGameOddSettings":
                                return new a.FightGameOddSettings(e);
                            case "SxGameOddSettings":
                                return new a.SxGameOddSettings(e);
                            case "GameFixedOddSettings":
                                return new a.GameFixedOddSettings(e);
                            case "DogGameOddSettings":
                                return new a.DogGameOddSettings(e);
                            case "LottofiveGameOddSettings":
                                return new a.LottofiveGameOddSettings(e);
                            case "SnGameOddSettings":
                                return new a.SnGameOddSettings(e)
                        }
                    }
                    return e.prototype.isLkGameOddSettings = function() {
                        return "LkGameOddSettings" === this.classType
                    }, e.prototype.isS2WGameOddSettings = function() {
                        return "S2WGameOddSettings" === this.classType
                    }, e.prototype.isMotorbikeGameOddSettings = function() {
                        return "MotorbikeGameOddSettings" === this.classType
                    }, e.prototype.isTrottingGameOddSettings = function() {
                        return "TrottingGameOddSettings" === this.classType
                    }, e.prototype.isLlGameOddSettings = function() {
                        return "LlGameOddSettings" === this.classType
                    }, e.prototype.isKnGameOddSettings = function() {
                        return "KnGameOddSettings" === this.classType
                    }, e.prototype.isDirttrackGameOddSettings = function() {
                        return "DirttrackGameOddSettings" === this.classType
                    }, e.prototype.isS7GameOddSettings = function() {
                        return "S7GameOddSettings" === this.classType
                    }, e.prototype.isKartGameOddSettings = function() {
                        return "KartGameOddSettings" === this.classType
                    }, e.prototype.isBasketGameOddSettings = function() {
                        return "BasketGameOddSettings" === this.classType
                    }, e.prototype.isHorseGameOddSettings = function() {
                        return "HorseGameOddSettings" === this.classType
                    }, e.prototype.isChGameOddSettings = function() {
                        return "ChGameOddSettings" === this.classType
                    }, e.prototype.isSpeedwayGameOddSettings = function() {
                        return "SpeedwayGameOddSettings" === this.classType
                    }, e.prototype.isFightGameOddSettings = function() {
                        return "FightGameOddSettings" === this.classType
                    }, e.prototype.isSxGameOddSettings = function() {
                        return "SxGameOddSettings" === this.classType
                    }, e.prototype.isGameFixedOddSettings = function() {
                        return "GameFixedOddSettings" === this.classType
                    }, e.prototype.isDogGameOddSettings = function() {
                        return "DogGameOddSettings" === this.classType
                    }, e.prototype.isLottofiveGameOddSettings = function() {
                        return "LottofiveGameOddSettings" === this.classType
                    }, e.prototype.isSnGameOddSettings = function() {
                        return "SnGameOddSettings" === this.classType
                    }, e
                }();
            t.GameOddSettings = n
        },
        ZNC3: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "KartAssets", _
                }
                return n(t, e), t
            }(_("vW0J").RacesAssets);
            t.KartAssets = r
        },
        ZOt0: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.protocol = e.protocol, this.isImplicit = e.isImplicit, this.prot = e.prot, this.useClientMode = e.useClientMode, this.sessionCreation = e.sessionCreation, this.needClientAuth = e.needClientAuth, this.wantsClientAuth = e.wantsClientAuth)
            };
            t.FtpsReportTarget = a,
                function(e) {
                    ! function(e) {
                        e.TLS = "TLS", e.SSL = "SSL"
                    }(e.ProtocolEnum || (e.ProtocolEnum = {}))
                }(a = t.FtpsReportTarget || (t.FtpsReportTarget = {})), t.FtpsReportTarget = a,
                function(e) {
                    ! function(e) {
                        e.CLEAR = "CLEAR", e.SAFE = "SAFE", e.CONFIDENTIAL = "CONFIDENTIAL", e.PRIVATE = "PRIVATE"
                    }(e.ProtEnum || (e.ProtEnum = {}))
                }(a = t.FtpsReportTarget || (t.FtpsReportTarget = {})), t.FtpsReportTarget = a
        },
        ZUsh: function(e, t, _) {
            "use strict";
            var a, n, r, o, i, s, c, l, u, d, p, h, f, y, m, w, v, x, T, O, S, b, P, H, A, E, g, k, q, M, C;
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e) {
                    e.N1O1 = "N1O1", e.N2O2 = "N2O2", e.N3O3 = "N3O3", e.N4O4 = "N4O4", e.N1O2 = "N1O2", e.N1O3 = "N1O3", e.N1O4 = "N1O4", e.FirstOverUnder15 = "FirstOverUnder15", e.FirstOverUnder25 = "FirstOverUnder25", e.FirstOverUnder35 = "FirstOverUnder35", e.FirstSecondOverUnder25 = "FirstSecondOverUnder25", e.SumOddEven = "SumOddEven", e.SumOverUnder120 = "SumOverUnder120", e.SumOverUnder135 = "SumOverUnder135", e.SumOverUnder150 = "SumOverUnder150", e.SumOverUnder155 = "SumOverUnder155", e.SumOverUnder170 = "SumOverUnder170", e.SumOverUnder185 = "SumOverUnder185", e.SumWhiteUnder65 = "SumWhiteUnder65", e.SumPinkUnder65 = "SumPinkUnder65", e.SumWhiteOver100 = "SumWhiteOver100", e.SumPinkOver100 = "SumPinkOver100", e.ColorAll = "ColorAll", e.ColorMore = "ColorMore", e.ColorFirst = "ColorFirst", e.ColorEQFirstSecond = "ColorEQFirstSecond", e.ColorNEQFirstSecond = "ColorNEQFirstSecond"
                }(M = t.LlMarkets || (t.LlMarkets = {})),
                function(e) {
                    e.N1O1 = "N1O1", e.N2O2 = "N2O2", e.N3O3 = "N3O3", e.N4O4 = "N4O4", e.N1O2 = "N1O2", e.N1O3 = "N1O3", e.N1O4 = "N1O4", e.FO15 = "FO15", e.FU15 = "FU15", e.FO25 = "FO25", e.FU25 = "FU25", e.FO35 = "FO35", e.FU35 = "FU35", e.FOSU25 = "FOSU25", e.FUSO25 = "FUSO25", e.FOSO25 = "FOSO25", e.FUSU25 = "FUSU25", e.SUMO = "SUMO", e.SUME = "SUME", e.SUMO120 = "SUMO120", e.SUMU120 = "SUMU120", e.SUMO135 = "SUMO135", e.SUMU135 = "SUMU135", e.SUMO150 = "SUMO150", e.SUMU150 = "SUMU150", e.SUMO155 = "SUMO155", e.SUMU155 = "SUMU155", e.SUMO170 = "SUMO170", e.SUMU170 = "SUMU170", e.SUMO185 = "SUMO185", e.SUMU185 = "SUMU185", e.SUMWO65 = "SUMWO65", e.SUMWU65 = "SUMWU65", e.SUMPO65 = "SUMPO65", e.SUMPU65 = "SUMPU65", e.SUMWO100 = "SUMWO100", e.SUMWU100 = "SUMWU100", e.SUMPO100 = "SUMPO100", e.SUMPU100 = "SUMPU100", e.ALLW = "ALLW", e.ALLP = "ALLP", e.MOREW = "MOREW", e.MOREP = "MOREP", e.FIRSTW = "FIRSTW", e.FIRSTP = "FIRSTP", e.FWSW = "FWSW", e.FPSP = "FPSP", e.FWSP = "FWSP", e.FPSW = "FPSW"
                }(C = t.LlOdds || (t.LlOdds = {})), t.LlMarketsTemplate = ((a = {})[M.N1O1] = ((n = {})[C.N1O1] = C.N1O1, n), a[M.N2O2] = ((r = {})[C.N2O2] = C.N2O2, r), a[M.N3O3] = ((o = {})[C.N3O3] = C.N3O3, o), a[M.N4O4] = ((i = {})[C.N4O4] = C.N4O4, i), a[M.N1O2] = ((s = {})[C.N1O2] = C.N1O2, s), a[M.N1O3] = ((c = {})[C.N1O3] = C.N1O3, c), a[M.N1O4] = ((l = {})[C.N1O4] = C.N1O4, l), a[M.FirstOverUnder15] = ((u = {})[C.FO15] = C.FO15, u[C.FU15] = C.FU15, u), a[M.FirstOverUnder25] = ((d = {})[C.FO25] = C.FO25, d[C.FU25] = C.FU25, d), a[M.FirstOverUnder35] = ((p = {})[C.FO35] = C.FO35, p[C.FU35] = C.FU35, p), a[M.FirstSecondOverUnder25] = ((h = {})[C.FOSU25] = C.FOSU25, h[C.FUSO25] = C.FUSO25, h[C.FOSO25] = C.FOSO25, h[C.FUSU25] = C.FUSU25, h), a[M.SumOddEven] = ((f = {})[C.SUMO] = C.SUMO, f[C.SUME] = C.SUME, f), a[M.SumOverUnder120] = ((y = {})[C.SUMO120] = C.SUMO120, y[C.SUMU120] = C.SUMU120, y), a[M.SumOverUnder135] = ((m = {})[C.SUMO135] = C.SUMO135, m[C.SUMU135] = C.SUMU135, m), a[M.SumOverUnder150] = ((w = {})[C.SUMO150] = C.SUMO150, w[C.SUMU150] = C.SUMU150, w), a[M.SumOverUnder155] = ((v = {})[C.SUMO155] = C.SUMO155, v[C.SUMU155] = C.SUMU155, v), a[M.SumOverUnder170] = ((x = {})[C.SUMO170] = C.SUMO170, x[C.SUMU170] = C.SUMU170, x), a[M.SumOverUnder185] = ((T = {})[C.SUMO185] = C.SUMO185, T[C.SUMU185] = C.SUMU185, T), a[M.SumWhiteUnder65] = ((O = {})[C.SUMWO65] = C.SUMWO65, O[C.SUMWU65] = C.SUMWU65, O), a[M.SumPinkUnder65] = ((S = {})[C.SUMPO65] = C.SUMPO65, S[C.SUMPU65] = C.SUMPU65, S), a[M.SumWhiteOver100] = ((b = {})[C.SUMWO100] = C.SUMWO100, b[C.SUMWU100] = C.SUMWU100, b), a[M.SumPinkOver100] = ((P = {})[C.SUMPO100] = C.SUMPO100, P[C.SUMPU100] = C.SUMPU100, P), a[M.ColorAll] = ((H = {})[C.ALLW] = C.ALLW, H[C.ALLP] = C.ALLP, H), a[M.ColorMore] = ((A = {})[C.MOREW] = C.MOREW, A[C.MOREP] = C.MOREP, A), a[M.ColorFirst] = ((E = {})[C.FIRSTW] = C.FIRSTW, E[C.FIRSTP] = C.FIRSTP, E), a[M.ColorEQFirstSecond] = ((g = {})[C.FWSW] = C.FWSW, g[C.FPSP] = C.FPSP, g), a[M.ColorNEQFirstSecond] = ((k = {})[C.FWSP] = C.FWSP, k[C.FPSW] = C.FPSW, k), a), t.LlOddsTemplate = ((q = {})[C.N1O1] = M.N1O1, q[C.N2O2] = M.N2O2, q[C.N3O3] = M.N3O3, q[C.N4O4] = M.N4O4, q[C.N1O2] = M.N1O2, q[C.N1O3] = M.N1O3, q[C.N1O4] = M.N1O4, q[C.FO15] = M.FirstOverUnder15, q[C.FU15] = M.FirstOverUnder15, q[C.FO25] = M.FirstOverUnder25, q[C.FU25] = M.FirstOverUnder25, q[C.FO35] = M.FirstOverUnder35, q[C.FU35] = M.FirstOverUnder35, q[C.FOSU25] = M.FirstSecondOverUnder25, q[C.FUSO25] = M.FirstSecondOverUnder25, q[C.FOSO25] = M.FirstSecondOverUnder25, q[C.FUSU25] = M.FirstSecondOverUnder25, q[C.SUMO] = M.SumOddEven, q[C.SUME] = M.SumOddEven, q[C.SUMO120] = M.SumOverUnder120, q[C.SUMU120] = M.SumOverUnder120, q[C.SUMO135] = M.SumOverUnder135, q[C.SUMU135] = M.SumOverUnder135, q[C.SUMO150] = M.SumOverUnder150, q[C.SUMU150] = M.SumOverUnder150, q[C.SUMO155] = M.SumOverUnder155, q[C.SUMU155] = M.SumOverUnder155, q[C.SUMO170] = M.SumOverUnder170, q[C.SUMU170] = M.SumOverUnder170, q[C.SUMO185] = M.SumOverUnder185, q[C.SUMU185] = M.SumOverUnder185, q[C.SUMWO65] = M.SumWhiteUnder65, q[C.SUMWU65] = M.SumWhiteUnder65, q[C.SUMPO65] = M.SumPinkUnder65, q[C.SUMPU65] = M.SumPinkUnder65, q[C.SUMWO100] = M.SumWhiteOver100, q[C.SUMWU100] = M.SumWhiteOver100, q[C.SUMPO100] = M.SumPinkOver100, q[C.SUMPU100] = M.SumPinkOver100, q[C.ALLW] = M.ColorAll, q[C.ALLP] = M.ColorAll, q[C.MOREW] = M.ColorMore, q[C.MOREP] = M.ColorMore, q[C.FIRSTW] = M.ColorFirst, q[C.FIRSTP] = M.ColorFirst, q[C.FWSW] = M.ColorEQFirstSecond, q[C.FPSP] = M.ColorEQFirstSecond, q[C.FWSP] = M.ColorNEQFirstSecond, q[C.FPSW] = M.ColorNEQFirstSecond, q)
        },
        Za19: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "KnFilter", t && (_.mode = t.mode), _
                }
                return n(t, e), t
            }(_("zE96").Filter);
            t.KnFilter = r,
                function(e) {
                    ! function(e) {
                        e.CLASSIC = "CLASSIC", e.DELUXE = "DELUXE"
                    }(e.ModeEnum || (e.ModeEnum = {}))
                }(r = t.KnFilter || (t.KnFilter = {})), t.KnFilter = r
        },
        ZuXt: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e) {
                    e.WON = "WON", e.LOST = "LOST", e.DRAW = "DRAW"
                }(t.ChMatchStatus || (t.ChMatchStatus = {}))
        },
        aDCO: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t, _) {
                        void 0 === _ && (_ = !0);
                        var a = e.call(this, t, !1) || this;
                        return a.classType = "GameFixedOddSettings", a.fixedOddSettings = [], t && (a.defaultMaxOdd = t.defaultMaxOdd, a.defaultOverround = t.defaultOverround, t.fixedOddSettings && t.fixedOddSettings.forEach((function(e) {
                            a.fixedOddSettings.push(new r.OddSettings(e))
                        }))), a
                    }
                    return n(t, e), t
                }(_("ZMgZ").GameOddSettings);
            t.GameFixedOddSettings = o
        },
        aLXJ: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "SxFilter", t && (_.riskManagement = t.riskManagement, _.winX2 = t.winX2, _.secondChanceBonus = t.secondChanceBonus, _.extraBallsBonus = t.extraBallsBonus, _.winX2FrequencyPer = t.winX2FrequencyPer), _
                }
                return n(t, e), t
            }(_("zE96").Filter);
            t.SxFilter = r
        },
        aPIh: function(e, t, _) {
            "use strict";
            var a, n, r, o, i, s, c, l, u, d, p;
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e) {
                    e.win = "win", e.exacta = "exacta", e.place = "place", e.quinella = "quinella", e.even_odd = "even_odd", e.over_under = "over_under", e.system_two = "system_two"
                }(d = t.DirttrackMarkets || (t.DirttrackMarkets = {})),
                function(e) {
                    e.win_1 = "win_1", e.win_2 = "win_2", e.win_3 = "win_3", e.win_4 = "win_4", e.exacta_1_2 = "exacta_1_2", e.exacta_1_3 = "exacta_1_3", e.exacta_1_4 = "exacta_1_4", e.exacta_2_1 = "exacta_2_1", e.exacta_2_3 = "exacta_2_3", e.exacta_2_4 = "exacta_2_4", e.exacta_3_1 = "exacta_3_1", e.exacta_3_2 = "exacta_3_2", e.exacta_3_4 = "exacta_3_4", e.exacta_4_1 = "exacta_4_1", e.exacta_4_2 = "exacta_4_2", e.exacta_4_3 = "exacta_4_3", e.place_1 = "place_1", e.place_2 = "place_2", e.place_3 = "place_3", e.place_4 = "place_4", e.quinella_1_2 = "quinella_1_2", e.quinella_1_3 = "quinella_1_3", e.quinella_1_4 = "quinella_1_4", e.quinella_2_3 = "quinella_2_3", e.quinella_2_4 = "quinella_2_4", e.quinella_3_4 = "quinella_3_4", e.even = "even", e.odd = "odd", e.over = "over", e.under = "under", e.system_two = "system_two"
                }(p = t.DirttrackOdds || (t.DirttrackOdds = {})), t.DirttrackMarketsTemplate = ((a = {})[d.win] = ((n = {})[p.win_1] = p.win_1, n[p.win_2] = p.win_2, n[p.win_3] = p.win_3, n[p.win_4] = p.win_4, n), a[d.exacta] = ((r = {})[p.exacta_1_2] = p.exacta_1_2, r[p.exacta_1_3] = p.exacta_1_3, r[p.exacta_1_4] = p.exacta_1_4, r[p.exacta_2_1] = p.exacta_2_1, r[p.exacta_2_3] = p.exacta_2_3, r[p.exacta_2_4] = p.exacta_2_4, r[p.exacta_3_1] = p.exacta_3_1, r[p.exacta_3_2] = p.exacta_3_2, r[p.exacta_3_4] = p.exacta_3_4, r[p.exacta_4_1] = p.exacta_4_1, r[p.exacta_4_2] = p.exacta_4_2, r[p.exacta_4_3] = p.exacta_4_3, r), a[d.place] = ((o = {})[p.place_1] = p.place_1, o[p.place_2] = p.place_2, o[p.place_3] = p.place_3, o[p.place_4] = p.place_4, o), a[d.quinella] = ((i = {})[p.quinella_1_2] = p.quinella_1_2, i[p.quinella_1_3] = p.quinella_1_3, i[p.quinella_1_4] = p.quinella_1_4, i[p.quinella_2_3] = p.quinella_2_3, i[p.quinella_2_4] = p.quinella_2_4, i[p.quinella_3_4] = p.quinella_3_4, i), a[d.even_odd] = ((s = {})[p.even] = p.even, s[p.odd] = p.odd, s), a[d.over_under] = ((c = {})[p.over] = p.over, c[p.under] = p.under, c), a[d.system_two] = ((l = {})[p.system_two] = p.system_two, l), a), t.DirttrackOddsTemplate = ((u = {})[p.win_1] = d.win, u[p.win_2] = d.win, u[p.win_3] = d.win, u[p.win_4] = d.win, u[p.exacta_1_2] = d.exacta, u[p.exacta_1_3] = d.exacta, u[p.exacta_1_4] = d.exacta, u[p.exacta_2_1] = d.exacta, u[p.exacta_2_3] = d.exacta, u[p.exacta_2_4] = d.exacta, u[p.exacta_3_1] = d.exacta, u[p.exacta_3_2] = d.exacta, u[p.exacta_3_4] = d.exacta, u[p.exacta_4_1] = d.exacta, u[p.exacta_4_2] = d.exacta, u[p.exacta_4_3] = d.exacta, u[p.place_1] = d.place, u[p.place_2] = d.place, u[p.place_3] = d.place, u[p.place_4] = d.place, u[p.quinella_1_2] = d.quinella, u[p.quinella_1_3] = d.quinella, u[p.quinella_1_4] = d.quinella, u[p.quinella_2_3] = d.quinella, u[p.quinella_2_4] = d.quinella, u[p.quinella_3_4] = d.quinella, u[p.even] = d.even_odd, u[p.odd] = d.even_odd, u[p.over] = d.over_under, u[p.under] = d.over_under, u[p.system_two] = d.system_two, u)
        },
        aj8u: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "ProfilesContext", t && (_.cashier = t.cashier ? new r.CashierProfileSettings(t.cashier) : null, _.viewer = t.viewer ? new r.ViewerProfileSettings(t.viewer) : null, _.print = t.print ? new r.PrintProfileSettings(t.print) : null, _.shopadmin = t.shopadmin ? new r.ShopadminProfileSettings(t.shopadmin) : null, _.mobile = t.mobile ? new r.MobileProfileSettings(t.mobile) : null, _.web = t.web ? new r.WebProfileSettings(t.web) : null, _.betslip = t.betslip ? new r.BetslipProfileSettings(t.betslip) : null), _
                    }
                    return n(t, e), t
                }(_("eSR3").Context);
            t.ProfilesContext = o
        },
        bAm8: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.wallets = [], this.jackpots = [], e && (e.wallets && e.wallets.forEach((function(e) {
                        t.wallets.push(new a.SessionStatusWallets(e))
                    })), e.jackpots && e.jackpots.forEach((function(e) {
                        t.jackpots.push(new a.JackpotView(e))
                    })), e.unitTimestamp ? this.unitTimestamp = new Date(e.unitTimestamp.toString()) : this.unitTimestamp = null)
                };
            t.SessionStatus = n
        },
        bEZe: function(e, t, _) {
            "use strict";
            var a, n, r, o, i, s, c, l, u, d, p, h, f, y;
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e) {
                    e.Numbers = "Numbers", e.Dozens = "Dozens", e.Colors = "Colors", e.Even_Odd = "Even_Odd", e.Low_High = "Low_High", e.Sectors = "Sectors", e.Twins = "Twins", e.Finals = "Finals", e.Mirror = "Mirror", e.Low_High_Color = "Low_High_Color"
                }(f = t.SnMarkets || (t.SnMarkets = {})),
                function(e) {
                    e.Number_1 = "Number_1", e.Number_2 = "Number_2", e.Number_3 = "Number_3", e.Number_4 = "Number_4", e.Number_5 = "Number_5", e.Number_6 = "Number_6", e.Number_7 = "Number_7", e.Number_8 = "Number_8", e.Number_9 = "Number_9", e.Number_10 = "Number_10", e.Number_11 = "Number_11", e.Number_12 = "Number_12", e.Number_13 = "Number_13", e.Number_14 = "Number_14", e.Number_15 = "Number_15", e.Number_16 = "Number_16", e.Number_17 = "Number_17", e.Number_18 = "Number_18", e.Number_19 = "Number_19", e.Number_20 = "Number_20", e.Number_21 = "Number_21", e.Number_22 = "Number_22", e.Number_23 = "Number_23", e.Number_24 = "Number_24", e.Number_25 = "Number_25", e.Number_26 = "Number_26", e.Number_27 = "Number_27", e.Number_28 = "Number_28", e.Number_29 = "Number_29", e.Number_30 = "Number_30", e.Number_31 = "Number_31", e.Number_32 = "Number_32", e.Number_33 = "Number_33", e.Number_34 = "Number_34", e.Number_35 = "Number_35", e.Number_36 = "Number_36", e.Number_0 = "Number_0", e.Number_00 = "Number_00", e.Dozen_1_12 = "Dozen_1_12", e.Dozen_13_24 = "Dozen_13_24", e.Dozen_25_36 = "Dozen_25_36", e.Black = "Black", e.Red = "Red", e.Green = "Green", e.Even = "Even", e.Odd = "Odd", e.Low = "Low", e.High = "High", e.Sector_A = "Sector_A", e.Sector_B = "Sector_B", e.Sector_C = "Sector_C", e.Sector_D = "Sector_D", e.Sector_E = "Sector_E", e.Sector_F = "Sector_F", e.Twins = "Twins", e.Finals_0 = "Finals_0", e.Finals_1 = "Finals_1", e.Finals_2 = "Finals_2", e.Finals_3 = "Finals_3", e.Finals_4 = "Finals_4", e.Finals_5 = "Finals_5", e.Finals_6 = "Finals_6", e.Mirror_12_21 = "Mirror_12_21", e.Mirror_13_31 = "Mirror_13_31", e.Mirror_23_32 = "Mirror_23_32", e.Low_Red = "Low_Red", e.High_Red = "High_Red", e.Low_Black = "Low_Black", e.High_Black = "High_Black"
                }(y = t.SnOdds || (t.SnOdds = {})), t.SnMarketsTemplate = ((a = {})[f.Numbers] = ((n = {})[y.Number_1] = y.Number_1, n[y.Number_2] = y.Number_2, n[y.Number_3] = y.Number_3, n[y.Number_4] = y.Number_4, n[y.Number_5] = y.Number_5, n[y.Number_6] = y.Number_6, n[y.Number_7] = y.Number_7, n[y.Number_8] = y.Number_8, n[y.Number_9] = y.Number_9, n[y.Number_10] = y.Number_10, n[y.Number_11] = y.Number_11, n[y.Number_12] = y.Number_12, n[y.Number_13] = y.Number_13, n[y.Number_14] = y.Number_14, n[y.Number_15] = y.Number_15, n[y.Number_16] = y.Number_16, n[y.Number_17] = y.Number_17, n[y.Number_18] = y.Number_18, n[y.Number_19] = y.Number_19, n[y.Number_20] = y.Number_20, n[y.Number_21] = y.Number_21, n[y.Number_22] = y.Number_22, n[y.Number_23] = y.Number_23, n[y.Number_24] = y.Number_24, n[y.Number_25] = y.Number_25, n[y.Number_26] = y.Number_26, n[y.Number_27] = y.Number_27, n[y.Number_28] = y.Number_28, n[y.Number_29] = y.Number_29, n[y.Number_30] = y.Number_30, n[y.Number_31] = y.Number_31, n[y.Number_32] = y.Number_32, n[y.Number_33] = y.Number_33, n[y.Number_34] = y.Number_34, n[y.Number_35] = y.Number_35, n[y.Number_36] = y.Number_36, n[y.Number_0] = y.Number_0, n[y.Number_00] = y.Number_00, n), a[f.Dozens] = ((r = {})[y.Dozen_1_12] = y.Dozen_1_12, r[y.Dozen_13_24] = y.Dozen_13_24, r[y.Dozen_25_36] = y.Dozen_25_36, r), a[f.Colors] = ((o = {})[y.Black] = y.Black, o[y.Red] = y.Red, o[y.Green] = y.Green, o), a[f.Even_Odd] = ((i = {})[y.Even] = y.Even, i[y.Odd] = y.Odd, i), a[f.Low_High] = ((s = {})[y.Low] = y.Low, s[y.High] = y.High, s), a[f.Sectors] = ((c = {})[y.Sector_A] = y.Sector_A, c[y.Sector_B] = y.Sector_B, c[y.Sector_C] = y.Sector_C, c[y.Sector_D] = y.Sector_D, c[y.Sector_E] = y.Sector_E, c[y.Sector_F] = y.Sector_F, c), a[f.Twins] = ((l = {})[y.Twins] = y.Twins, l), a[f.Finals] = ((u = {})[y.Finals_0] = y.Finals_0, u[y.Finals_1] = y.Finals_1, u[y.Finals_2] = y.Finals_2, u[y.Finals_3] = y.Finals_3, u[y.Finals_4] = y.Finals_4, u[y.Finals_5] = y.Finals_5, u[y.Finals_6] = y.Finals_6, u), a[f.Mirror] = ((d = {})[y.Mirror_12_21] = y.Mirror_12_21, d[y.Mirror_13_31] = y.Mirror_13_31, d[y.Mirror_23_32] = y.Mirror_23_32, d), a[f.Low_High_Color] = ((p = {})[y.Low_Red] = y.Low_Red, p[y.High_Red] = y.High_Red, p[y.Low_Black] = y.Low_Black, p[y.High_Black] = y.High_Black, p), a), t.SnOddsTemplate = ((h = {})[y.Number_1] = f.Numbers, h[y.Number_2] = f.Numbers, h[y.Number_3] = f.Numbers, h[y.Number_4] = f.Numbers, h[y.Number_5] = f.Numbers, h[y.Number_6] = f.Numbers, h[y.Number_7] = f.Numbers, h[y.Number_8] = f.Numbers, h[y.Number_9] = f.Numbers, h[y.Number_10] = f.Numbers, h[y.Number_11] = f.Numbers, h[y.Number_12] = f.Numbers, h[y.Number_13] = f.Numbers, h[y.Number_14] = f.Numbers, h[y.Number_15] = f.Numbers, h[y.Number_16] = f.Numbers, h[y.Number_17] = f.Numbers, h[y.Number_18] = f.Numbers, h[y.Number_19] = f.Numbers, h[y.Number_20] = f.Numbers, h[y.Number_21] = f.Numbers, h[y.Number_22] = f.Numbers, h[y.Number_23] = f.Numbers, h[y.Number_24] = f.Numbers, h[y.Number_25] = f.Numbers, h[y.Number_26] = f.Numbers, h[y.Number_27] = f.Numbers, h[y.Number_28] = f.Numbers, h[y.Number_29] = f.Numbers, h[y.Number_30] = f.Numbers, h[y.Number_31] = f.Numbers, h[y.Number_32] = f.Numbers, h[y.Number_33] = f.Numbers, h[y.Number_34] = f.Numbers, h[y.Number_35] = f.Numbers, h[y.Number_36] = f.Numbers, h[y.Number_0] = f.Numbers, h[y.Number_00] = f.Numbers, h[y.Dozen_1_12] = f.Dozens, h[y.Dozen_13_24] = f.Dozens, h[y.Dozen_25_36] = f.Dozens, h[y.Black] = f.Colors, h[y.Red] = f.Colors, h[y.Green] = f.Colors, h[y.Even] = f.Even_Odd, h[y.Odd] = f.Even_Odd, h[y.Low] = f.Low_High, h[y.High] = f.Low_High, h[y.Sector_A] = f.Sectors, h[y.Sector_B] = f.Sectors, h[y.Sector_C] = f.Sectors, h[y.Sector_D] = f.Sectors, h[y.Sector_E] = f.Sectors, h[y.Sector_F] = f.Sectors, h[y.Twins] = f.Twins, h[y.Finals_0] = f.Finals, h[y.Finals_1] = f.Finals, h[y.Finals_2] = f.Finals, h[y.Finals_3] = f.Finals, h[y.Finals_4] = f.Finals, h[y.Finals_5] = f.Finals, h[y.Finals_6] = f.Finals, h[y.Mirror_12_21] = f.Mirror, h[y.Mirror_13_31] = f.Mirror, h[y.Mirror_23_32] = f.Mirror, h[y.Low_Red] = f.Low_High_Color, h[y.High_Red] = f.Low_High_Color, h[y.Low_Black] = f.Low_High_Color, h[y.High_Black] = f.Low_High_Color, h)
        },
        bHOv: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "ChWebProfileGameSettings", t && (_.teamNameTextType = t.teamNameTextType), _
                }
                return n(t, e), t
            }(_("fMy4").WebProfileGameSettings);
            t.ChWebProfileGameSettings = r,
                function(e) {
                    ! function(e) {
                        e._3LETTERS = "_3LETTERS", e.FULLTEAMNAME = "FULLTEAMNAME"
                    }(e.TeamNameTextTypeEnum || (e.TeamNameTextTypeEnum = {}))
                }(r = t.ChWebProfileGameSettings || (t.ChWebProfileGameSettings = {})), t.ChWebProfileGameSettings = r
        },
        bOaR: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    e && (this.reportData = e.reportData ? new a.ReportData(e.reportData) : null, this.generatingStatus = e.generatingStatus ? new a.GeneratingStatus(e.generatingStatus) : null)
                };
            t.GeneratingResult = n
        },
        bXsM: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.hit_ball_6 = e.hit_ball_6, this.hit_ball_7 = e.hit_ball_7, this.hit_ball_8 = e.hit_ball_8, this.hit_ball_9 = e.hit_ball_9, this.hit_ball_10 = e.hit_ball_10, this.hit_ball_11 = e.hit_ball_11, this.hit_ball_12 = e.hit_ball_12, this.hit_ball_13 = e.hit_ball_13, this.hit_ball_14 = e.hit_ball_14, this.hit_ball_15 = e.hit_ball_15, this.hit_ball_16 = e.hit_ball_16, this.hit_ball_17 = e.hit_ball_17, this.hit_ball_18 = e.hit_ball_18, this.hit_ball_19 = e.hit_ball_19, this.hit_ball_20 = e.hit_ball_20, this.hit_ball_21 = e.hit_ball_21, this.hit_ball_22 = e.hit_ball_22, this.hit_ball_23 = e.hit_ball_23, this.hit_ball_24 = e.hit_ball_24, this.hit_ball_25 = e.hit_ball_25, this.hit_ball_26 = e.hit_ball_26, this.hit_ball_27 = e.hit_ball_27, this.hit_ball_28 = e.hit_ball_28, this.hit_ball_29 = e.hit_ball_29, this.hit_ball_30 = e.hit_ball_30, this.hit_ball_31 = e.hit_ball_31, this.hit_ball_32 = e.hit_ball_32, this.hit_ball_33 = e.hit_ball_33, this.hit_ball_34 = e.hit_ball_34, this.hit_ball_35 = e.hit_ball_35, this.system_hit_ball_7 = e.system_hit_ball_7, this.system_hit_ball_8 = e.system_hit_ball_8, this.system_hit_ball_9 = e.system_hit_ball_9, this.system_hit_ball_10 = e.system_hit_ball_10, this.top_c1 = e.top_c1, this.top_c2 = e.top_c2, this.top_c3 = e.top_c3, this.top_c4 = e.top_c4, this.first_c1 = e.first_c1, this.first_c2 = e.first_c2, this.first_c3 = e.first_c3, this.first_c4 = e.first_c4, this.last_c1 = e.last_c1, this.last_c2 = e.last_c2, this.last_c3 = e.last_c3, this.last_c4 = e.last_c4, this.more_odd = e.more_odd, this.more_even = e.more_even, this.pre_sum_odd = e.pre_sum_odd, this.pre_sum_even = e.pre_sum_even, this.first_odd = e.first_odd, this.first_even = e.first_even, this.last_odd = e.last_odd, this.last_even = e.last_even, this.pre_sum_over_122_5 = e.pre_sum_over_122_5, this.pre_sum_under_122_5 = e.pre_sum_under_122_5, this.first_over_24_5 = e.first_over_24_5, this.first_under_24_5 = e.first_under_24_5, this.last_over_24_5 = e.last_over_24_5, this.last_under_24_5 = e.last_under_24_5)
            };
            t.SxPayTable = a
        },
        bbmB: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "MoveEntityReportParams", t && (_.produces = t.produces, _.destinationParentId = t.destinationParentId), _
                }
                return n(t, e), t
            }(_("nzvJ").ReportParams);
            t.MoveEntityReportParams = r
        },
        blRA: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "TicketContext", _.currencySetting = [], t && (t.currencySetting && t.currencySetting.forEach((function(e) {
                            _.currencySetting.push(new r.TicketCurrencySetting(e))
                        })), _.ticketPolicy = t.ticketPolicy ? new r.TicketPolicy(t.ticketPolicy) : null, _.ticketCancellationSetting = t.ticketCancellationSetting ? new r.TicketCancellationSetting(t.ticketCancellationSetting) : null, _.parentCanCheck = t.parentCanCheck, _.siblingCanCheck = t.siblingCanCheck, _.childCanCheck = t.childCanCheck, _.onSolve = t.onSolve, _.testStatus = t.testStatus, _.hashCodeLenght = t.hashCodeLenght), _
                    }
                    return n(t, e), t
                }(_("eSR3").Context);
            t.TicketContext = o,
                function(e) {
                    ! function(e) {
                        e.NONE = "NONE", e.CREDIT = "CREDIT", e.PAY = "PAY"
                    }(e.OnSolveEnum || (e.OnSolveEnum = {}))
                }(o = t.TicketContext || (t.TicketContext = {})), t.TicketContext = o
        },
        bry7: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "LlGameEventData", t && (_.presenterImageUrl = t.presenterImageUrl, _.croupierName = t.croupierName), _
                }
                return n(t, e), t
            }(_("VqjV").GameEventData);
            t.LlGameEventData = r
        },
        cOmk: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "SnAssets", t && (_.isDeluxe = t.isDeluxe), _
                }
                return n(t, e), t
            }(_("8xXt").Assets);
            t.SnAssets = r
        },
        cWJq: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.allIn1 = e.allIn1, this.allIn2 = e.allIn2, this.allIn3 = e.allIn3, this.allIn4 = e.allIn4, this.allIn5 = e.allIn5, this.allIn6 = e.allIn6, this.allIn7 = e.allIn7, this.oneOutOf7 = e.oneOutOf7, this.twoOutOf7 = e.twoOutOf7, this.threeOutOf7 = e.threeOutOf7, this.fourOutOf7 = e.fourOutOf7, this.fiveOutOf7 = e.fiveOutOf7, this.sixOutOf7 = e.sixOutOf7, this.sevenOutOf7 = e.sevenOutOf7, this.noDraw1 = e.noDraw1, this.noDraw2 = e.noDraw2, this.noDraw3 = e.noDraw3, this.noDraw4 = e.noDraw4, this.noDraw5 = e.noDraw5, this.noDraw6 = e.noDraw6, this.noDraw7 = e.noDraw7, this.firstBallWhite = e.firstBallWhite, this.firstBallRed = e.firstBallRed, this.lastBallWhite = e.lastBallWhite, this.lastBallRed = e.lastBallRed, this.firstAndSecondSameColor = e.firstAndSecondSameColor, this.firstAndSecondDifferentColor = e.firstAndSecondDifferentColor, this.sevenWhiteBalls = e.sevenWhiteBalls, this.sixWhiteBalls = e.sixWhiteBalls, this.fiveWhiteBalls = e.fiveWhiteBalls, this.fourWhiteBalls = e.fourWhiteBalls, this.threeWhiteBalls = e.threeWhiteBalls, this.twoWhiteBalls = e.twoWhiteBalls, this.oneWhiteBalls = e.oneWhiteBalls, this.sevenRedBalls = e.sevenRedBalls, this.sixRedBalls = e.sixRedBalls, this.fiveRedBalls = e.fiveRedBalls, this.fourRedBalls = e.fourRedBalls, this.threeRedBalls = e.threeRedBalls, this.twoRedBalls = e.twoRedBalls, this.oneRedBalls = e.oneRedBalls, this.sumUnder100 = e.sumUnder100, this.sumUnder125 = e.sumUnder125, this.sumOver125 = e.sumOver125, this.sumUnder150 = e.sumUnder150, this.sumOver150 = e.sumOver150, this.sumUnder175 = e.sumUnder175, this.sumOver175 = e.sumOver175, this.sumOver200 = e.sumOver200, this.sumWhiteUnder73 = e.sumWhiteUnder73, this.sumWhiteOver73 = e.sumWhiteOver73, this.sumRedUnder73 = e.sumRedUnder73, this.sumRedOver73 = e.sumRedOver73, this.countWhiteUnder3 = e.countWhiteUnder3, this.countWhiteOver3 = e.countWhiteOver3, this.countWhiteUnder2 = e.countWhiteUnder2, this.countWhiteOver2 = e.countWhiteOver2, this.countWhiteUnder1 = e.countWhiteUnder1, this.countWhiteOver1 = e.countWhiteOver1, this.countRedUnder3 = e.countRedUnder3, this.countRedOver3 = e.countRedOver3, this.countRedUnder2 = e.countRedUnder2, this.countRedOver2 = e.countRedOver2, this.countRedUnder1 = e.countRedUnder1, this.countRedOver1 = e.countRedOver1, this.moreOdd = e.moreOdd, this.moreEven = e.moreEven, this.sumOdd = e.sumOdd, this.sumEven = e.sumEven, this.firstBallOdd = e.firstBallOdd, this.firstBallEven = e.firstBallEven, this.lastBallOdd = e.lastBallOdd, this.lastBallEven = e.lastBallEven, this.firstTwoBallsOdd = e.firstTwoBallsOdd, this.firstTwoBallsEven = e.firstTwoBallsEven, this.firstOddAndSecondEven = e.firstOddAndSecondEven, this.firstEvenAndSecondOdd = e.firstEvenAndSecondOdd, this.firstOddAndLastEven = e.firstOddAndLastEven, this.firstEvenAndLastOdd = e.firstEvenAndLastOdd)
            };
            t.S7PayTable = a
        },
        cwqg: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.transaction = [], e && (this.ticket = e.ticket ? new a.ServerTicket(e.ticket) : null, e.transaction && e.transaction.forEach((function(e) {
                        t.transaction.push(new a.Transaction(e))
                    })))
                };
            t.TicketTransaction = n
        },
        d4Eu: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "S7WViewerProfileGameSettings", _
                }
                return n(t, e), t
            }(_("PBHJ").ViewerProfileGameSettings);
            t.S7WViewerProfileGameSettings = r
        },
        dEUd: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.maxStake = e.maxStake, this.minStake = e.minStake, this.maxPayout = e.maxPayout, this.combiBonus = e.combiBonus)
            };
            t.LimitsBonusSetting = a
        },
        dMdk: function(e, t, _) {
            "use strict";
            var a, n, r, o, i, s, c, l, u, d, p, h, f, y, m, w, v, x;
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e) {
                    e.W36Numbers = "W36Numbers", e.W36Color = "W36Color", e.W36Range = "W36Range", e.W36LowHigh = "W36LowHigh", e.W36EvenOdd = "W36EvenOdd", e.W36EvenOddColor = "W36EvenOddColor", e.W18Numbers = "W18Numbers", e.W18Color = "W18Color", e.W18Range = "W18Range", e.W18LowHigh = "W18LowHigh", e.W18EvenOdd = "W18EvenOdd", e.W18EvenOddColor = "W18EvenOddColor", e.Multiplier = "Multiplier", e.DoubleChance = "DoubleChance"
                }(v = t.S2wMarkets || (t.S2wMarkets = {})),
                function(e) {
                    e.W36Numbers = "W36Numbers", e.W36Green = "W36Green", e.W36Yellow = "W36Yellow", e.W36Blue = "W36Blue", e.W36Red = "W36Red", e.W36Range1_12 = "W36Range1_12", e.W36Range13_24 = "W36Range13_24", e.W36Range25_36 = "W36Range25_36", e.W36Low = "W36Low", e.W36High = "W36High", e.W36Even = "W36Even", e.W36Odd = "W36Odd", e.W36EvenYellow = "W36EvenYellow", e.W36OddYellow = "W36OddYellow", e.W36EvenGreen = "W36EvenGreen", e.W36OddGreen = "W36OddGreen", e.W36EvenBlue = "W36EvenBlue", e.W36OddBlue = "W36OddBlue", e.W36EvenRed = "W36EvenRed", e.W36OddRed = "W36OddRed", e.W18Numbers = "W18Numbers", e.W18Green = "W18Green", e.W18Yellow = "W18Yellow", e.W18Blue = "W18Blue", e.W18Range1_6 = "W18Range1_6", e.W18Range7_12 = "W18Range7_12", e.W18Range13_18 = "W18Range13_18", e.W18Low = "W18Low", e.W18High = "W18High", e.W18Even = "W18Even", e.W18Odd = "W18Odd", e.W18EvenYellow = "W18EvenYellow", e.W18OddYellow = "W18OddYellow", e.W18EvenGreen = "W18EvenGreen", e.W18OddGreen = "W18OddGreen", e.W18EvenBlue = "W18EvenBlue", e.W18OddBlue = "W18OddBlue", e.Multiplier = "Multiplier", e.DoubleChance = "DoubleChance"
                }(x = t.S2wOdds || (t.S2wOdds = {})), t.S2wMarketsTemplate = ((a = {})[v.W36Numbers] = ((n = {})[x.W36Numbers] = x.W36Numbers, n), a[v.W36Color] = ((r = {})[x.W36Green] = x.W36Green, r[x.W36Yellow] = x.W36Yellow, r[x.W36Blue] = x.W36Blue, r[x.W36Red] = x.W36Red, r), a[v.W36Range] = ((o = {})[x.W36Range1_12] = x.W36Range1_12, o[x.W36Range13_24] = x.W36Range13_24, o[x.W36Range25_36] = x.W36Range25_36, o), a[v.W36LowHigh] = ((i = {})[x.W36Low] = x.W36Low, i[x.W36High] = x.W36High, i), a[v.W36EvenOdd] = ((s = {})[x.W36Even] = x.W36Even, s[x.W36Odd] = x.W36Odd, s), a[v.W36EvenOddColor] = ((c = {})[x.W36EvenYellow] = x.W36EvenYellow, c[x.W36OddYellow] = x.W36OddYellow, c[x.W36EvenGreen] = x.W36EvenGreen, c[x.W36OddGreen] = x.W36OddGreen, c[x.W36EvenBlue] = x.W36EvenBlue, c[x.W36OddBlue] = x.W36OddBlue, c[x.W36EvenRed] = x.W36EvenRed, c[x.W36OddRed] = x.W36OddRed, c), a[v.W18Numbers] = ((l = {})[x.W18Numbers] = x.W18Numbers, l), a[v.W18Color] = ((u = {})[x.W18Green] = x.W18Green, u[x.W18Yellow] = x.W18Yellow, u[x.W18Blue] = x.W18Blue, u), a[v.W18Range] = ((d = {})[x.W18Range1_6] = x.W18Range1_6, d[x.W18Range7_12] = x.W18Range7_12, d[x.W18Range13_18] = x.W18Range13_18, d), a[v.W18LowHigh] = ((p = {})[x.W18Low] = x.W18Low, p[x.W18High] = x.W18High, p), a[v.W18EvenOdd] = ((h = {})[x.W18Even] = x.W18Even, h[x.W18Odd] = x.W18Odd, h), a[v.W18EvenOddColor] = ((f = {})[x.W18EvenYellow] = x.W18EvenYellow, f[x.W18OddYellow] = x.W18OddYellow, f[x.W18EvenGreen] = x.W18EvenGreen, f[x.W18OddGreen] = x.W18OddGreen, f[x.W18EvenBlue] = x.W18EvenBlue, f[x.W18OddBlue] = x.W18OddBlue, f), a[v.Multiplier] = ((y = {})[x.Multiplier] = x.Multiplier, y), a[v.DoubleChance] = ((m = {})[x.DoubleChance] = x.DoubleChance, m), a), t.S2wOddsTemplate = ((w = {})[x.W36Numbers] = v.W36Numbers, w[x.W36Green] = v.W36Color, w[x.W36Yellow] = v.W36Color, w[x.W36Blue] = v.W36Color, w[x.W36Red] = v.W36Color, w[x.W36Range1_12] = v.W36Range, w[x.W36Range13_24] = v.W36Range, w[x.W36Range25_36] = v.W36Range, w[x.W36Low] = v.W36LowHigh, w[x.W36High] = v.W36LowHigh, w[x.W36Even] = v.W36EvenOdd, w[x.W36Odd] = v.W36EvenOdd, w[x.W36EvenYellow] = v.W36EvenOddColor, w[x.W36OddYellow] = v.W36EvenOddColor, w[x.W36EvenGreen] = v.W36EvenOddColor, w[x.W36OddGreen] = v.W36EvenOddColor, w[x.W36EvenBlue] = v.W36EvenOddColor, w[x.W36OddBlue] = v.W36EvenOddColor, w[x.W36EvenRed] = v.W36EvenOddColor, w[x.W36OddRed] = v.W36EvenOddColor, w[x.W18Numbers] = v.W18Numbers, w[x.W18Green] = v.W18Color, w[x.W18Yellow] = v.W18Color, w[x.W18Blue] = v.W18Color, w[x.W18Range1_6] = v.W18Range, w[x.W18Range7_12] = v.W18Range, w[x.W18Range13_18] = v.W18Range, w[x.W18Low] = v.W18LowHigh, w[x.W18High] = v.W18LowHigh, w[x.W18Even] = v.W18EvenOdd, w[x.W18Odd] = v.W18EvenOdd, w[x.W18EvenYellow] = v.W18EvenOddColor, w[x.W18OddYellow] = v.W18EvenOddColor, w[x.W18EvenGreen] = v.W18EvenOddColor, w[x.W18OddGreen] = v.W18EvenOddColor, w[x.W18EvenBlue] = v.W18EvenOddColor, w[x.W18OddBlue] = v.W18EvenOddColor, w[x.Multiplier] = v.Multiplier, w[x.DoubleChance] = v.DoubleChance, w)
        },
        dOTm: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.events = [], this.systemBets = [], e && (e.events && e.events.forEach((function(e) {
                        t.events.push(new a.TicketEvent(e))
                    })), e.systemBets && e.systemBets.forEach((function(e) {
                        t.systemBets.push(new a.SystemBet(e))
                    })))
                };
            t.TicketDetail = n
        },
        dU9G: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this._1_out_of_1 = e._1_out_of_1, this._2_out_of_2 = e._2_out_of_2, this._3_out_of_3 = e._3_out_of_3, this._4_out_of_4 = e._4_out_of_4, this._1_out_of_2 = e._1_out_of_2, this._1_out_of_3 = e._1_out_of_3, this._1_out_of_4 = e._1_out_of_4, this.first_over_15 = e.first_over_15, this.first_under_15 = e.first_under_15, this.first_over_25 = e.first_over_25, this.first_under_25 = e.first_under_25, this.first_over_35 = e.first_over_35, this.first_under_35 = e.first_under_35, this.first_over_25_second_under_25 = e.first_over_25_second_under_25, this.first_under_25_second_over_25 = e.first_under_25_second_over_25, this.first_over_25_second_over_25 = e.first_over_25_second_over_25, this.first_under_25_second_under_25 = e.first_under_25_second_under_25, this.sum_is_odd = e.sum_is_odd, this.sum_is_even = e.sum_is_even, this.sum_over_120 = e.sum_over_120, this.sum_under_120 = e.sum_under_120, this.sum_over_135 = e.sum_over_135, this.sum_under_135 = e.sum_under_135, this.sum_over_150 = e.sum_over_150, this.sum_under_150 = e.sum_under_150, this.sum_over_155 = e.sum_over_155, this.sum_under_155 = e.sum_under_155, this.sum_over_170 = e.sum_over_170, this.sum_under_170 = e.sum_under_170, this.sum_over_185 = e.sum_over_185, this.sum_under_185 = e.sum_under_185, this.sum_white_over_65 = e.sum_white_over_65, this.sum_white_under_65 = e.sum_white_under_65, this.sum_pink_over_65 = e.sum_pink_over_65, this.sum_pink_under_65 = e.sum_pink_under_65, this.sum_white_over_100 = e.sum_white_over_100, this.sum_white_under_100 = e.sum_white_under_100, this.sum_pink_over_100 = e.sum_pink_over_100, this.sum_pink_under_100 = e.sum_pink_under_100, this.all_white = e.all_white, this.all_pink = e.all_pink, this.more_white = e.more_white, this.more_pink = e.more_pink, this.first_white = e.first_white, this.first_pink = e.first_pink, this.first_white_second_white = e.first_white_second_white, this.first_pink_second_pink = e.first_pink_second_pink, this.first_white_second_pink = e.first_white_second_pink, this.first_pink_second_white = e.first_pink_second_white)
            };
            t.LlPayTable = a
        },
        dZyX: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.contributions = [], e && e.contributions && e.contributions.forEach((function(e) {
                        t.contributions.push(new a.JackpotContribution(e))
                    }))
                };
            t.ServerTicketJackpotData = n
        },
        dcyg: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.transactionId = e.transactionId, this.extTransactionId = e.extTransactionId, this.entityId = e.entityId, this.extId = e.extId, this.extData = e.extData, this.ticketId = e.ticketId, this.walletId = e.walletId, e.date ? this.date = new Date(e.date.toString()) : this.date = null, this.previousCredit = e.previousCredit, this.newCredit = e.newCredit, this.changeCredit = e.changeCredit, this.currency = e.currency, this.description = e.description, this.operatorId = e.operatorId, this.operatorAPI = e.operatorAPI, this.method = e.method, this.params = e.params)
            };
            t.Transaction = a,
                function(e) {
                    ! function(e) {
                        e.MANAGER = "MANAGER", e.CLIENT = "CLIENT", e.EXTERNAL = "EXTERNAL", e.SYSTEM = "SYSTEM"
                    }(e.OperatorAPIEnum || (e.OperatorAPIEnum = {}))
                }(a = t.Transaction || (t.Transaction = {})), t.Transaction = a
        },
        dhxj: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "BalkansTaxPolicy", t && (_.stakeTax = t.stakeTax ? new r.StakeTax(t.stakeTax) : null, _.payoutTax = t.payoutTax ? new r.ScaledPayoutTax(t.payoutTax) : null), _
                    }
                    return n(t, e), t
                }(_("PtXo").TaxPolicy);
            t.BalkansTaxPolicy = o
        },
        dvF7: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e) {
                    e.LOCKED = "LOCKED", e.REJECTED = "REJECTED", e.OPEN = "OPEN", e.PENDING = "PENDING", e.CANCELLING = "CANCELLING", e.CANCELLED = "CANCELLED", e.WON = "WON", e.LOST = "LOST", e.PAIDOUT = "PAIDOUT", e.EXPIRED = "EXPIRED"
                }(t.TicketStatus || (t.TicketStatus = {}))
        },
        dvO6: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "KartParticipant", t && (_.speed = t.speed, _.stamina = t.stamina, _.wins = t.wins), _
                }
                return n(t, e), t
            }(_("xeXX").RaceParticipant);
            t.KartParticipant = r
        },
        dyP4: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "LkGameEventData", t && (_.minBet = t.minBet, _.maxBet = t.maxBet, _.croupierName = t.croupierName, _.videoUrl = t.videoUrl, _.presenterVideoUrl = t.presenterVideoUrl, _.presenterImageUrl = t.presenterImageUrl, _.placeBetsIdentUrl = t.placeBetsIdentUrl, _.betsClosedIdentsUrl = t.betsClosedIdentsUrl, _.gameIdentUrl = t.gameIdentUrl, t.drawDate ? _.drawDate = new Date(t.drawDate.toString()) : _.drawDate = null, t.updateDate ? _.updateDate = new Date(t.updateDate.toString()) : _.updateDate = null), _
                }
                return n(t, e), t
            }(_("VqjV").GameEventData);
            t.LkGameEventData = r
        },
        "eGI/": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "ChFilter", _.groups = [], _.pairingConfig = [], _.incompatibleTeams = [], _.initialRanking = [], t && (_.id = t.id, _.competitionTypeStrategy = t.competitionTypeStrategy, _.champCode = t.champCode, _.assetsId = t.assetsId, _.yellowProb = t.yellowProb, t.groups && t.groups.forEach((function(e) {
                        _.groups.push(e)
                    })), _.numParticipants = t.numParticipants, _.competitionType = t.competitionType, _.competitionSubType = t.competitionSubType, _.weekDaysInGroupPhase = t.weekDaysInGroupPhase, _.isTwoLegsGroup = t.isTwoLegsGroup, _.isTwoLegsKnockout = t.isTwoLegsKnockout, _.isTwoLegsFinal = t.isTwoLegsFinal, t.pairingConfig && t.pairingConfig.forEach((function(e) {
                        _.pairingConfig.push(e)
                    })), t.incompatibleTeams && t.incompatibleTeams.forEach((function(e) {
                        _.incompatibleTeams.push(e)
                    })), t.initialRanking && t.initialRanking.forEach((function(e) {
                        _.initialRanking.push(e)
                    })), _.libraryId = t.libraryId, _.contentLibrary = t.contentLibrary), _
                }
                return n(t, e), t
            }(_("zE96").Filter);
            t.ChFilter = r,
                function(e) {
                    ! function(e) {
                        e.RANKED = "RANKED", e.TABLEODDS = "TABLEODDS", e.STATS = "STATS"
                    }(e.CompetitionTypeStrategyEnum || (e.CompetitionTypeStrategyEnum = {}))
                }(r = t.ChFilter || (t.ChFilter = {})), t.ChFilter = r
        },
        eSR3: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function() {
                    function e(e, t) {
                        if (void 0 === t && (t = !0), e && (this.classType = e.classType, t && this.classType)) switch (this.classType) {
                            case "TicketContext":
                                return new a.TicketContext(e);
                            case "TaxContext":
                                return new a.TaxContext(e);
                            case "ProfilesContext":
                                return new a.ProfilesContext(e);
                            case "OddContext":
                                return new a.OddContext(e);
                            case "GameContext":
                                return new a.GameContext(e);
                            case "UnitSessionStatus":
                                return new a.UnitSessionStatus(e);
                            case "LocalizationContext":
                                return new a.LocalizationContext(e);
                            case "LogispinProfilesContext":
                                return new a.LogispinProfilesContext(e)
                        }
                    }
                    return e.prototype.isTicketContext = function() {
                        return "TicketContext" === this.classType
                    }, e.prototype.isTaxContext = function() {
                        return "TaxContext" === this.classType
                    }, e.prototype.isProfilesContext = function() {
                        return "ProfilesContext" === this.classType
                    }, e.prototype.isOddContext = function() {
                        return "OddContext" === this.classType
                    }, e.prototype.isGameContext = function() {
                        return "GameContext" === this.classType
                    }, e.prototype.isUnitSessionStatus = function() {
                        return "UnitSessionStatus" === this.classType
                    }, e.prototype.isLocalizationContext = function() {
                        return "LocalizationContext" === this.classType
                    }, e.prototype.isLogispinProfilesContext = function() {
                        return "LogispinProfilesContext" === this.classType
                    }, e
                }();
            t.Context = n
        },
        ej0j: function(e, t, _) {
            "use strict";
            var a, n, r, o, i, s, c, l, u, d, p, h, f, y, m;
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e) {
                    e.numbers = "numbers", e.all_in = "all_in", e.no_draw = "no_draw", e.first_even_odd = "first_even_odd", e.first_single_notsingle = "first_single_notsingle", e.first_over_under_40_5 = "first_over_under_40_5", e.last_even_odd = "last_even_odd", e.last_single_notsingle = "last_single_notsingle", e.last_over_under_40_5 = "last_over_under_40_5", e.sum_first_5_over_under_202_5 = "sum_first_5_over_under_202_5", e.sum_over_under_810_5 = "sum_over_under_810_5"
                }(y = t.KnMarkets || (t.KnMarkets = {})),
                function(e) {
                    e.numbers_1 = "numbers_1", e.numbers_2 = "numbers_2", e.numbers_3 = "numbers_3", e.numbers_4 = "numbers_4", e.numbers_5 = "numbers_5", e.numbers_6 = "numbers_6", e.numbers_7 = "numbers_7", e.numbers_8 = "numbers_8", e.numbers_9 = "numbers_9", e.numbers_10 = "numbers_10", e.all_in_1 = "all_in_1", e.all_in_2 = "all_in_2", e.all_in_3 = "all_in_3", e.all_in_4 = "all_in_4", e.all_in_5 = "all_in_5", e.all_in_6 = "all_in_6", e.all_in_7 = "all_in_7", e.all_in_8 = "all_in_8", e.all_in_9 = "all_in_9", e.all_in_10 = "all_in_10", e.no_draw_1 = "no_draw_1", e.no_draw_2 = "no_draw_2", e.no_draw_3 = "no_draw_3", e.no_draw_4 = "no_draw_4", e.no_draw_5 = "no_draw_5", e.no_draw_6 = "no_draw_6", e.no_draw_7 = "no_draw_7", e.no_draw_8 = "no_draw_8", e.no_draw_9 = "no_draw_9", e.no_draw_10 = "no_draw_10", e.first_even = "first_even", e.first_odd = "first_odd", e.first_single = "first_single", e.first_notsingle = "first_notsingle", e.first_over_40_5 = "first_over_40_5", e.first_under_40_5 = "first_under_40_5", e.last_even = "last_even", e.last_odd = "last_odd", e.last_single = "last_single", e.last_notsingle = "last_notsingle", e.last_over_40_5 = "last_over_40_5", e.last_under_40_5 = "last_under_40_5", e.sum_first_5_over_202_5 = "sum_first_5_over_202_5", e.sum_first_5_under_202_5 = "sum_first_5_under_202_5", e.sum_over_810_5 = "sum_over_810_5", e.sum_under_810_5 = "sum_under_810_5"
                }(m = t.KnOdds || (t.KnOdds = {})), t.KnMarketsTemplate = ((a = {})[y.numbers] = ((n = {})[m.numbers_1] = m.numbers_1, n[m.numbers_2] = m.numbers_2, n[m.numbers_3] = m.numbers_3, n[m.numbers_4] = m.numbers_4, n[m.numbers_5] = m.numbers_5, n[m.numbers_6] = m.numbers_6, n[m.numbers_7] = m.numbers_7, n[m.numbers_8] = m.numbers_8, n[m.numbers_9] = m.numbers_9, n[m.numbers_10] = m.numbers_10, n), a[y.all_in] = ((r = {})[m.all_in_1] = m.all_in_1, r[m.all_in_2] = m.all_in_2, r[m.all_in_3] = m.all_in_3, r[m.all_in_4] = m.all_in_4, r[m.all_in_5] = m.all_in_5, r[m.all_in_6] = m.all_in_6, r[m.all_in_7] = m.all_in_7, r[m.all_in_8] = m.all_in_8, r[m.all_in_9] = m.all_in_9, r[m.all_in_10] = m.all_in_10, r), a[y.no_draw] = ((o = {})[m.no_draw_1] = m.no_draw_1, o[m.no_draw_2] = m.no_draw_2, o[m.no_draw_3] = m.no_draw_3, o[m.no_draw_4] = m.no_draw_4, o[m.no_draw_5] = m.no_draw_5, o[m.no_draw_6] = m.no_draw_6, o[m.no_draw_7] = m.no_draw_7, o[m.no_draw_8] = m.no_draw_8, o[m.no_draw_9] = m.no_draw_9, o[m.no_draw_10] = m.no_draw_10, o), a[y.first_even_odd] = ((i = {})[m.first_even] = m.first_even, i[m.first_odd] = m.first_odd, i), a[y.first_single_notsingle] = ((s = {})[m.first_single] = m.first_single, s[m.first_notsingle] = m.first_notsingle, s), a[y.first_over_under_40_5] = ((c = {})[m.first_over_40_5] = m.first_over_40_5, c[m.first_under_40_5] = m.first_under_40_5, c), a[y.last_even_odd] = ((l = {})[m.last_even] = m.last_even, l[m.last_odd] = m.last_odd, l), a[y.last_single_notsingle] = ((u = {})[m.last_single] = m.last_single, u[m.last_notsingle] = m.last_notsingle, u), a[y.last_over_under_40_5] = ((d = {})[m.last_over_40_5] = m.last_over_40_5, d[m.last_under_40_5] = m.last_under_40_5, d), a[y.sum_first_5_over_under_202_5] = ((p = {})[m.sum_first_5_over_202_5] = m.sum_first_5_over_202_5, p[m.sum_first_5_under_202_5] = m.sum_first_5_under_202_5, p), a[y.sum_over_under_810_5] = ((h = {})[m.sum_over_810_5] = m.sum_over_810_5, h[m.sum_under_810_5] = m.sum_under_810_5, h), a), t.KnOddsTemplate = ((f = {})[m.numbers_1] = y.numbers, f[m.numbers_2] = y.numbers, f[m.numbers_3] = y.numbers, f[m.numbers_4] = y.numbers, f[m.numbers_5] = y.numbers, f[m.numbers_6] = y.numbers, f[m.numbers_7] = y.numbers, f[m.numbers_8] = y.numbers, f[m.numbers_9] = y.numbers, f[m.numbers_10] = y.numbers, f[m.all_in_1] = y.all_in, f[m.all_in_2] = y.all_in, f[m.all_in_3] = y.all_in, f[m.all_in_4] = y.all_in, f[m.all_in_5] = y.all_in, f[m.all_in_6] = y.all_in, f[m.all_in_7] = y.all_in, f[m.all_in_8] = y.all_in, f[m.all_in_9] = y.all_in, f[m.all_in_10] = y.all_in, f[m.no_draw_1] = y.no_draw, f[m.no_draw_2] = y.no_draw, f[m.no_draw_3] = y.no_draw, f[m.no_draw_4] = y.no_draw, f[m.no_draw_5] = y.no_draw, f[m.no_draw_6] = y.no_draw, f[m.no_draw_7] = y.no_draw, f[m.no_draw_8] = y.no_draw, f[m.no_draw_9] = y.no_draw, f[m.no_draw_10] = y.no_draw, f[m.first_even] = y.first_even_odd, f[m.first_odd] = y.first_even_odd, f[m.first_single] = y.first_single_notsingle, f[m.first_notsingle] = y.first_single_notsingle, f[m.first_over_40_5] = y.first_over_under_40_5, f[m.first_under_40_5] = y.first_over_under_40_5, f[m.last_even] = y.last_even_odd, f[m.last_odd] = y.last_even_odd, f[m.last_single] = y.last_single_notsingle, f[m.last_notsingle] = y.last_single_notsingle, f[m.last_over_40_5] = y.last_over_under_40_5, f[m.last_under_40_5] = y.last_over_under_40_5, f[m.sum_first_5_over_202_5] = y.sum_first_5_over_under_202_5, f[m.sum_first_5_under_202_5] = y.sum_first_5_over_under_202_5, f[m.sum_over_810_5] = y.sum_over_under_810_5, f[m.sum_under_810_5] = y.sum_over_under_810_5, f)
        },
        eoOp: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    e && (this.messageId = e.messageId, this.targetId = e.targetId, this.sourceId = e.sourceId, e.timeRegistered ? this.timeRegistered = new Date(e.timeRegistered.toString()) : this.timeRegistered = null, this.body = e.body ? new a.EntityBodyMessage(e.body) : null)
                };
            t.EntityMessage = n
        },
        fMy4: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function() {
                    function e(e, t) {
                        if (void 0 === t && (t = !0), e && (this.classType = e.classType, this.gameType = e.gameType, t && this.classType)) switch (this.classType) {
                            case "ChWebProfileGameSettings":
                                return new a.ChWebProfileGameSettings(e)
                        }
                    }
                    return e.prototype.isChWebProfileGameSettings = function() {
                        return "ChWebProfileGameSettings" === this.classType
                    }, e
                }();
            t.WebProfileGameSettings = n
        },
        fU0W: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function() {
                    function e(e, t) {
                        if (void 0 === t && (t = !0), e && (this.classType = e.classType, this.reportId = e.reportId, this.jobId = e.jobId, this.extId = e.extId, this.extGroupId = e.extGroupId, this.creatorId = e.creatorId, this.description = e.description, this.params = e.params ? new a.ReportParams(e.params) : null, e.startTime ? this.startTime = new Date(e.startTime.toString()) : this.startTime = null, e.endTime ? this.endTime = new Date(e.endTime.toString()) : this.endTime = null, e.deprecationTime ? this.deprecationTime = new Date(e.deprecationTime.toString()) : this.deprecationTime = null, this.entityId = e.entityId, this.fileName = e.fileName, this.fileSize = e.fileSize, this.status = e.status, this.generatingStatus = e.generatingStatus ? new a.GeneratingStatus(e.generatingStatus) : null, this.renderingStatus = e.renderingStatus ? new a.RenderingStatus(e.renderingStatus) : null, this.deliveringStatus = e.deliveringStatus ? new a.DeliveringStatus(e.deliveringStatus) : null, e.generationTime ? this.generationTime = new Date(e.generationTime.toString()) : this.generationTime = null, e.deliveredTime ? this.deliveredTime = new Date(e.deliveredTime.toString()) : this.deliveredTime = null, e.creationTime ? this.creationTime = new Date(e.creationTime.toString()) : this.creationTime = null, e.renderTime ? this.renderTime = new Date(e.renderTime.toString()) : this.renderTime = null, e.pausedTime ? this.pausedTime = new Date(e.pausedTime.toString()) : this.pausedTime = null, this.contentType = e.contentType, this.data = e.data ? new a.ReportData(e.data) : null, this.sequentialReport = e.sequentialReport, t && this.classType)) switch (this.classType) {
                            case "SettlementReport":
                                return new a.SettlementReport(e);
                            case "MoveEntityReport":
                                return new a.MoveEntityReport(e);
                            case "LottoResultReport":
                                return new a.LottoResultReport(e);
                            case "PosReport":
                                return new a.PosReport(e)
                        }
                    }
                    return e.prototype.isSettlementReport = function() {
                        return "SettlementReport" === this.classType
                    }, e.prototype.isMoveEntityReport = function() {
                        return "MoveEntityReport" === this.classType
                    }, e.prototype.isLottoResultReport = function() {
                        return "LottoResultReport" === this.classType
                    }, e.prototype.isPosReport = function() {
                        return "PosReport" === this.classType
                    }, e
                }();
            t.Report = n
        },
        ffvd: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function() {
                function e() {
                    var e = this;
                    this.ofuscationHash = [], this.attributes = [], this.ofuscationHash = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "W", "Y", "Z", "_", "ab", "ac", "ad", "ae", "af", "ag", "ah", "ai", "aj", "ak", "al", "am", "an", "ao", "ap", "aq", "ar", "as", "at", "au", "av", "aw", "ax", "ay", "az", "aA", "aB", "aC", "aD", "aE", "aF", "aG", "aH", "aI", "aJ", "aK", "aL", "aM", "aN", "aO", "aP", "aQ", "aR", "aS", "aT", "aW", "aY", "aZ", "a_", "bc", "bd", "be", "bf", "bg", "bh", "bi", "bj", "bk", "bl", "bm", "bn", "bo", "bp", "bq", "br", "bs", "bt", "bu", "bv", "bw", "bx", "by", "bz", "bA", "bB", "bC", "bD", "bE", "bF", "bG", "bH", "bI", "bJ", "bK", "bL", "bM", "bN", "bO", "bP", "bQ", "bR", "bS", "bT", "bW", "bY", "bZ", "b_", "cd", "ce", "cf", "cg", "ch", "ci", "cj", "ck", "cl", "cm", "cn", "co", "cp", "cq", "cr", "cs", "ct", "cu", "cv", "cw", "cx", "cy", "cz", "cA", "cB", "cC", "cD", "cE", "cF", "cG", "cH", "cI", "cJ", "cK", "cL", "cM", "cN", "cO", "cP", "cQ", "cR", "cS", "cT", "cW", "cY", "cZ", "c_", "de", "df", "dg", "dh", "di", "dj", "dk", "dl", "dm", "dn", "do", "dp", "dq", "dr", "ds", "dt", "du", "dv", "dw", "dx", "dy", "dz", "dA", "dB", "dC", "dD", "dE", "dF", "dG", "dH", "dI", "dJ", "dK", "dL", "dM", "dN", "dO", "dP", "dQ", "dR", "dS", "dT", "dW", "dY", "dZ", "d_", "ee", "ef", "eg", "eh", "ei", "ej", "ek", "el", "em", "en", "eo", "ep", "eq", "er", "es", "et", "eu", "ev", "ew", "ex", "ey", "ez", "eA", "eB", "eC", "eD", "eE", "eF", "eG", "eH", "eI", "eJ", "eK", "eL", "eM", "eN", "eO", "eP", "eQ", "eR", "eS", "eT", "eW", "eY", "eZ", "e_", "ef", "eg", "eh", "ei", "ej", "ek", "el", "em", "en", "eo", "ep", "eq", "er", "es", "et", "eu", "ev", "ew", "ex", "ey", "ez", "eA", "eB", "eC", "eD", "eE", "eF", "eG", "eH", "eI", "eJ", "eK", "eL", "eM", "eN", "eO", "eP", "eQ", "eR", "eS", "eT", "eW", "eY", "eZ", "e_", "fg", "fh", "fi", "fj", "fk", "fl", "fm", "fn", "fo", "fp", "fq", "fr", "fs", "ft", "fu", "fv", "fw", "fx", "fy", "fz", "fA", "fB", "fC", "fD", "fE", "fF", "fG", "fH", "fI", "fJ", "fK", "fL", "fM", "fN", "fO", "fP", "fQ", "fR", "fS", "fT", "fW", "fY", "fZ", "f_", "gh", "gi", "gj", "gk", "gl", "gm", "gn", "go", "gp", "gq", "gr", "gs", "gt", "gu", "gv", "gw", "gx", "gy", "gz", "gA", "gB", "gC", "gD", "gE", "gF", "gG", "gH", "gI", "gJ", "gK", "gL", "gM", "gN", "gO", "gP", "gQ", "gR", "gS", "gT", "gW", "gY", "gZ", "g_", "hi", "hj", "hk", "hl", "hm", "hn", "ho", "hp", "hq", "hr", "hs", "ht", "hu", "hv", "hw", "hx", "hy", "hz", "hA", "hB", "hC", "hD", "hE", "hF", "hG", "hH", "hI", "hJ", "hK", "hL", "hM", "hN", "hO", "hP", "hQ", "hR", "hS", "hT", "hW", "hY", "hZ", "h_", "ij", "ik", "il", "im", "in", "io", "ip", "iq", "ir", "is", "it", "iu", "iv", "iw", "ix", "iy", "iz", "iA", "iB", "iC", "iD", "iE", "iF", "iG", "iH", "iI", "iJ", "iK", "iL", "iM", "iN", "iO", "iP", "iQ", "iR", "iS", "iT", "iW", "iY", "iZ", "i_", "jk", "jl", "jm", "jn", "jo", "jp", "jq", "jr", "js", "jt", "ju", "jv", "jw", "jx", "jy", "jz", "jA", "jB", "jC", "jD", "jE", "jF", "jG", "jH", "jI", "jJ", "jK", "jL", "jM", "jN", "jO", "jP", "jQ", "jR", "jS", "jT", "jW", "jY", "jZ", "j_", "kl", "km", "kn", "ko", "kp", "kq", "kr", "ks", "kt", "ku", "kv", "kw", "kx", "ky", "kz", "kA", "kB", "kC", "kD", "kE", "kF", "kG", "kH", "kI", "kJ", "kK", "kL", "kM", "kN", "kO", "kP", "kQ", "kR", "kS", "kT", "kW", "kY", "kZ", "k_", "lm", "ln", "lo", "lp", "lq", "lr", "ls", "lt", "lu", "lv", "lw", "lx", "ly", "lz", "lA", "lB", "lC", "lD", "lE", "lF", "lG", "lH", "lI", "lJ", "lK", "lL", "lM", "lN", "lO", "lP", "lQ", "lR", "lS", "lT", "lW", "lY", "lZ", "l_", "mn", "mo", "mp", "mq", "mr", "ms", "mt", "mu", "mv", "mw", "mx", "my", "mz", "mA", "mB", "mC", "mD", "mE", "mF", "mG", "mH", "mI", "mJ", "mK", "mL", "mM", "mN", "mO", "mP", "mQ", "mR", "mS", "mT", "mW", "mY", "mZ", "m_", "no", "np", "nq", "nr", "ns", "nt", "nu", "nv", "nw", "nx", "ny", "nz", "nA", "nB", "nC", "nD", "nE", "nF", "nG", "nH", "nI", "nJ", "nK", "nL", "nM", "nN", "nO", "nP", "nQ", "nR", "nS", "nT", "nW", "nY", "nZ", "n_", "op", "oq", "or", "os", "ot", "ou", "ov", "ow", "ox", "oy", "oz", "oA", "oB", "oC", "oD", "oE", "oF", "oG", "oH", "oI", "oJ", "oK", "oL", "oM", "oN", "oO", "oP", "oQ", "oR", "oS", "oT", "oW", "oY", "oZ", "o_", "pq", "pr", "ps", "pt", "pu", "pv", "pw", "px", "py", "pz", "pA", "pB", "pC", "pD", "pE", "pF", "pG", "pH", "pI", "pJ", "pK", "pL", "pM", "pN", "pO", "pP", "pQ", "pR", "pS", "pT", "pW", "pY", "pZ", "p_", "qr", "qs", "qt", "qu", "qv", "qw", "qx", "qy", "qz", "qA", "qB", "qC", "qD", "qE", "qF", "qG", "qH", "qI", "qJ", "qK", "qL", "qM", "qN", "qO", "qP", "qQ", "qR", "qS", "qT", "qW", "qY", "qZ", "q_", "rs", "rt", "ru", "rv", "rw", "rx", "ry", "rz", "rA", "rB", "rC", "rD", "rE", "rF", "rG", "rH", "rI", "rJ", "rK", "rL", "rM", "rN", "rO", "rP", "rQ", "rR", "rS", "rT", "rW", "rY", "rZ", "r_", "st", "su", "sv", "sw", "sx", "sy", "sz", "sA", "sB", "sC", "sD", "sE", "sF", "sG", "sH", "sI", "sJ", "sK", "sL", "sM", "sN", "sO", "sP", "sQ", "sR", "sS", "sT", "sW", "sY", "sZ", "s_", "tu", "tv", "tw", "tx", "ty", "tz", "tA", "tB", "tC", "tD", "tE", "tF", "tG", "tH", "tI", "tJ", "tK", "tL", "tM", "tN", "tO", "tP", "tQ", "tR", "tS", "tT", "tW", "tY", "tZ", "t_", "uv", "uw", "ux", "uy", "uz", "uA", "uB", "uC", "uD", "uE", "uF", "uG", "uH", "uI", "uJ", "uK", "uL", "uM", "uN", "uO", "uP", "uQ", "uR", "uS", "uT", "uW", "uY", "uZ", "u_", "vw", "vx", "vy", "vz", "vA", "vB", "vC", "vD", "vE", "vF", "vG", "vH", "vI", "vJ", "vK", "vL", "vM", "vN", "vO", "vP", "vQ", "vR", "vS", "vT", "vW", "vY", "vZ", "v_", "wx", "wy", "wz", "wA", "wB", "wC", "wD", "wE", "wF", "wG", "wH", "wI", "wJ", "wK", "wL", "wM", "wN", "wO", "wP", "wQ", "wR", "wS", "wT", "wW", "wY", "wZ", "w_", "xy", "xz", "xA", "xB", "xC", "xD", "xE", "xF", "xG", "xH", "xI", "xJ", "xK", "xL", "xM", "xN", "xO", "xP", "xQ", "xR", "xS", "xT", "xW", "xY", "xZ", "x_", "yz", "yA", "yB", "yC", "yD", "yE", "yF", "yG", "yH", "yI", "yJ", "yK", "yL", "yM", "yN", "yO", "yP", "yQ", "yR", "yS", "yT", "yW", "yY", "yZ", "y_", "zA", "zB", "zC", "zD", "zE", "zF", "zG", "zH", "zI", "zJ", "zK", "zL", "zM", "zN", "zO", "zP", "zQ", "zR", "zS", "zT", "zW", "zY", "zZ", "z_", "AB", "AC", "AD", "AE", "AF", "AG", "AH", "AI", "AJ", "AK", "AL", "AM", "AN", "AO", "AP", "AQ", "AR", "AS", "AT", "AW", "AY", "AZ", "A_", "BC", "BD", "BE", "BF", "BG", "BH", "BI", "BJ", "BK", "BL", "BM", "BN", "BO", "BP", "BQ", "BR", "BS", "BT", "BW", "BY", "BZ", "B_", "CD", "CE", "CF", "CG", "CH", "CI", "CJ", "CK", "CL", "CM", "CN", "CO", "CP", "CQ", "CR", "CS", "CT", "CW", "CY", "CZ", "C_", "DE", "DF", "DG", "DH", "DI", "DJ", "DK", "DL", "DM", "DN", "DO", "DP", "DQ", "DR", "DS", "DT", "DW", "DY", "DZ", "D_", "EF", "EG", "EH", "EI", "EJ", "EK", "EL", "EM", "EN", "EO", "EP", "EQ", "ER", "ES", "ET", "EW", "EY", "EZ", "E_", "FG", "FH", "FI", "FJ", "FK", "FL", "FM", "FN", "FO", "FP", "FQ", "FR", "FS", "FT", "FW", "FY", "FZ", "F_", "GH", "GI", "GJ", "GK", "GL", "GM", "GN", "GO", "GP", "GQ", "GR", "GS", "GT", "GW", "GY", "GZ", "G_", "HI", "HJ", "HK", "HL", "HM", "HN", "HO", "HP", "HQ", "HR", "HS", "HT", "HW", "HY", "HZ", "H_", "IJ", "IK", "IL", "IM", "IN", "IO", "IP", "IQ", "IR", "IS", "IT", "IW", "IY", "IZ", "I_", "JK", "JL", "JM", "JN", "JO", "JP", "JQ", "JR", "JS", "JT", "JW", "JY", "JZ", "J_", "KL", "KM", "KN", "KO", "KP", "KQ", "KR", "KS", "KT", "KW", "KY", "KZ", "K_", "LM", "LN", "LO", "LP", "LQ", "LR", "LS", "LT", "LW", "LY", "LZ", "L_", "MN", "MO", "MP", "MQ", "MR", "MS", "MT", "MW", "MY", "MZ", "M_", "NO", "NP", "NQ", "NR", "NS", "NT", "NW", "NY", "NZ", "N_", "OP", "OQ", "OR", "OS", "OT", "OW", "OY", "OZ", "O_", "PQ", "PR", "PS", "PT", "PW", "PY", "PZ", "P_", "QR", "QS", "QT", "QW", "QY", "QZ", "Q_", "RS", "RT", "RW", "RY", "RZ", "R_", "ST", "SW", "SY", "SZ", "S_", "TW", "TY", "TZ", "T_", "WY", "WZ", "W_", "YZ", "Y_", "Z_"], this.attributes = this.removeDuplicates(["classType", "iconId", "clientConfiguration", "unit", "staff", "stakeTax", "payoutTax", "classType", "taxPercent", "matchesGroupId", "phase", "resultPointsPregameRed", "resultPointsPregameBlue", "resultPointsEndMatchRed", "resultPointsEndMatchBlue", "hlsURL", "videoSlots", "pointsRed", "pointsBlue", "rankingRed", "rankingBlue", "starsRed", "starsBlue", "fieldGoalRed", "fieldGoalBlue", "twoPointsRed", "twoPointsBlue", "winsRed", "winsBlue", "over37_5", "under37_5", "resourcePathRanking", "resourcePathVideo", "resourcePathCoverage", "contextVideo", "resultPointsPregameRed", "resultPointsPregameBlue", "name", "playerId", "points", "total", "players", "participants", "data", "matchOrder", "start", "end", "duration", "time", "event", "team", "playerId", "points", "mediaId", "enabled", "playersRedId", "playersBlueId", "scoreMatchRed", "scoreMatchBlue", "pointsStats", "scoreExtraTimeRed", "scoreExtraTimeBlue", "timeDuration", "timePlayed", "timeIntervals", "happenings", "betId", "oddValue", "stakeInput", "betslipMode", "standardViewBetMode", "tabViewSystemMode", "serverTimeStamp", "entityPaths", "entityMessages", "sessionStatus", "serverTimeStamp", "unitSessionStatus", "ticketContext", "taxContext", "oddContext", "resource", "classType", "gameType", "disablePrintingBetTickets", "reprint", "canPrintPayout", "printPayoutConfirm", "printTicketAndCopy", "blockMaxPayoutTicket", "cancelConfirm", "canPrintCancel", "printCancelConfirm", "splitStake", "showJackpot", "startFullScreen", "hideNotificationTopBar", "hideCreditArea", "hideUsernameArea", "hideOptionMenuButton", "hideRules", "inactivityTimeout", "duplicateTips", "gameSettings", "isTurbo", "hasIntro", "auroraGtpacksId", "auroraId", "ocvVoiceoverLangSupported", "teamNameTextType", "champId", "weekDay", "legOrder", "phase", "matchDay", "groupClassification", "knockoutClassification", "eventId", "participants", "finalOutcome", "penalty", "classifiedTeam", "halfWonMarkets", "refundMarkets", "halfLostMarkets", "hlsURL", "videoSlots", "yellowCard", "penalty", "classifiedTeam", "id", "competitionTypeStrategy", "champCode", "assetsId", "yellowProb", "groups", "numParticipants", "competitionType", "competitionSubType", "weekDaysInGroupPhase", "isTwoLegsGroup", "isTwoLegsKnockout", "isTwoLegsFinal", "pairingConfig", "incompatibleTeams", "initialRanking", "libraryId", "contentLibrary", "group", "entries", "eventTime", "data", "events", "teamNameTextType", "eventId", "participants", "result", "finalOutcome", "penalty", "classifiedTeam", "historyMatches", "homeMatches", "awayMatches", "wonHome", "wonAway", "drawHome", "drawAway", "lostHome", "lostAway", "wonPerc", "wonHomePerc", "wonAwayPerc", "drawPerc", "drawHomePerc", "drawAwayPerc", "lostPerc", "lostHomePerc", "lostAwayPerc", "goalsForHome", "goalsForAway", "goalsForPerMatch", "goalsForPerMatchHome", "goalsForPerMatchAway", "goalsAgainstHome", "goalsAgainstAway", "goalsAgainstPerMatch", "goalsAgainstPerMatchHome", "goalsAgainstPerMatchAway", "lastResults", "participants", "competitionType", "data", "eventNdx", "competitionSubType", "ingameLivescoreMode", "emblemType", "teamNameTextType", "teamNameTextType", "id", "description", "playlists", "gameNdx", "eventTime", "drawResult", "drawMachine", "classType", "classType", "code", "decimals", "symbol", "step", "classType", "threshold", "fromTime", "toTime", "countdown", "offset", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday", "deliveringStatus", "num_retries", "speed", "stamina", "wins", "classType", "displayId", "enabled", "priority", "stadiumCode", "raceOddsLevel", "age", "sex", "timeSinceSeason", "art", "aggressiveness", "bestTime", "currentWeight", "idealWeight", "racingLine", "ability", "star", "pace", "trifectaLayout6paticipant", "destinationEmailList", "entityType", "id", "name", "extId", "extData", "status", "classType", "cause", "data", "messageId", "targetId", "sourceId", "timeRegistered", "body", "scope", "resource", "errorCode", "message", "param", "extData", "expiredTime", "data", "result", "liveStats", "serverStatus", "eventId", "extId", "extData", "order", "blockType", "contentBlockType", "serverStatus", "eBlockId", "channelId", "playlistId", "displayOption", "events", "eventTime", "expireTime", "duration", "data", "extData", "stats", "classType", "classType", "classType", "participants", "probabilityValues", "kValues", "oddValues", "liveUrl", "stats", "gameData", "classType", "data", "finalOutcome", "wonMarkets", "contentDuration", "classType", "classType", "id", "name", "nation", "wins", "winsByKO", "draws", "lost", "classification", "result", "hlsURL", "oddSet", "contextParticipants", "resourcePathNameParticipants", "contextVideos", "resourcePathNameVideos", "contextHistory", "resourcePathNameHistory", "victoryProb", "name", "nation", "age", "height", "weight", "rating", "mediaId", "playerBId", "playerWId", "type", "id", "duration", "scoreB", "scoreW", "videoHappening", "type", "player", "score", "sec", "classType", "teamId", "fifaCode", "ranking", "points", "history", "win", "lost", "draw", "goalsScored", "goalsConceded", "yellowCards", "classification", "teamToTeam", "name", "shortDesc", "longDesc", "fifaCode", "stars", "mediaId", "mediaSignature", "mediaExpireTime", "happenings", "serverHost", "port", "username", "password", "account", "path", "createPath", "clientMode", "bufferSize", "connectTimeout", "defaultTimeout", "dataTimeout", "controlEncoding", "isSecure", "ftpsParams", "protocol", "isImplicit", "prot", "useClientMode", "sessionCreation", "needClientAuth", "wantsClientAuth", "displays", "classType", "defaultMaxOdd", "defaultOverround", "fixedOddSettings", "classType", "playlistId", "val", "serverCloseMarketTime", "jackpotSettings", "profilesContext", "wallets", "reportData", "generatingStatus", "classType", "taxPercent", "roundingMode", "stakeTax", "payoutTax", "oneBetPerEvent", "refuseIfExceedMaxPayout", "oneTicketPerEvent", "oneEventPerTicket", "columnValue", "is3D", "auroraGtpacksId", "stadiumCode", "contextJockeys", "resourcePathNameJockeys", "raceOddsLevel", "jockeySilkAssetId", "jockey", "jockeyForecast", "sex", "color", "owner", "speed", "stamina", "wins", "place", "timeOff", "art", "ability", "star", "handicap", "handicapPrev", "pace", "trifectaLayout6paticipant", "preambleLayoutHorse12", "showCurrency", "jackpotId", "jackpotName", "jackpotDesc", "targetId", "targetType", "playlistFilter", "playlistBlocked", "jackpotId", "targetId", "jackpotContribution", "amount", "date", "ticketId", "entity", "jackpotId", "entityId", "amount", "currency", "lastTicket", "additionalInfo", "level", "expirationDate", "nextPrize", "classType", "speed", "stamina", "wins", "payoutTax", "isDeluxe", "historic", "mode", "oddset", "payTable", "numbers_10_0", "numbers_10_1", "numbers_10_2", "numbers_10_3", "numbers_10_4", "numbers_10_5", "numbers_10_6", "numbers_10_7", "numbers_10_8", "numbers_10_9", "numbers_10_10", "numbers_9_0", "numbers_9_1", "numbers_9_2", "numbers_9_3", "numbers_9_4", "numbers_9_5", "numbers_9_6", "numbers_9_7", "numbers_9_8", "numbers_9_9", "numbers_8_0", "numbers_8_1", "numbers_8_2", "numbers_8_3", "numbers_8_4", "numbers_8_5", "numbers_8_6", "numbers_8_7", "numbers_8_8", "numbers_7_0", "numbers_7_1", "numbers_7_2", "numbers_7_3", "numbers_7_4", "numbers_7_5", "numbers_7_6", "numbers_7_7", "numbers_6_0", "numbers_6_1", "numbers_6_2", "numbers_6_3", "numbers_6_4", "numbers_6_5", "numbers_6_6", "numbers_5_0", "numbers_5_1", "numbers_5_2", "numbers_5_3", "numbers_5_4", "numbers_5_5", "numbers_4_0", "numbers_4_1", "numbers_4_2", "numbers_4_3", "numbers_4_4", "numbers_3_0", "numbers_3_1", "numbers_3_2", "numbers_3_3", "numbers_2_0", "numbers_2_1", "numbers_2_2", "numbers_1_0", "numbers_1_1", "all_in_1", "all_in_2", "all_in_3", "all_in_4", "all_in_5", "all_in_6", "all_in_7", "all_in_8", "all_in_9", "all_in_10", "no_draw_1", "no_draw_2", "no_draw_3", "no_draw_4", "no_draw_5", "no_draw_6", "no_draw_7", "no_draw_8", "no_draw_9", "no_draw_10", "first_even", "first_odd", "first_single", "first_notsingle", "first_over_40_5", "first_under_40_5", "last_even", "last_odd", "last_single", "last_notsingle", "last_over_40_5", "last_under_40_5", "sum_first_5_over_202_5", "sum_first_5_under_202_5", "sum_over_810_5", "sum_under_810_5", "levelId", "threshold", "taxPercent", "maxStake", "minStake", "maxPayout", "maxStake", "minStake", "maxPayout", "minStakePerSystemBet", "maxStake", "minStake", "maxPayout", "combiBonus", "ticket", "single", "combi2", "combi3", "combi4", "combi5", "combi6", "combi7", "combi8", "combi9", "combi10", "playlistSingle", "key", "limits", "multiplier", "repeatBet", "historic", "result", "mode", "minBet", "maxBet", "croupierName", "videoUrl", "presenterVideoUrl", "presenterImageUrl", "placeBetsIdentUrl", "betsClosedIdentsUrl", "gameIdentUrl", "drawDate", "updateDate", "payTable", "streaming", "panels", "identifier", "minBet", "maxBet", "croupierName", "videoUrl", "presenterVideoUrl", "presenterImageUrl", "placeBetsIdentUrl", "betsClosedIdentsUrl", "gameIdentUrl", "drawDate", "updateDate", "result", "historic", "result", "result", "historic", "presenterImageUrl", "croupierName", "payTable", "_1_out_of_1", "_2_out_of_2", "_3_out_of_3", "_4_out_of_4", "_1_out_of_2", "_1_out_of_3", "_1_out_of_4", "first_over_15", "first_under_15", "first_over_25", "first_under_25", "first_over_35", "first_under_35", "first_over_25_second_under_25", "first_under_25_second_over_25", "first_over_25_second_over_25", "first_under_25_second_under_25", "sum_is_odd", "sum_is_even", "sum_over_120", "sum_under_120", "sum_over_135", "sum_under_135", "sum_over_150", "sum_under_150", "sum_over_155", "sum_under_155", "sum_over_170", "sum_under_170", "sum_over_185", "sum_under_185", "sum_white_over_65", "sum_white_under_65", "sum_pink_over_65", "sum_pink_under_65", "sum_white_over_100", "sum_white_under_100", "sum_pink_over_100", "sum_pink_under_100", "all_white", "all_pink", "more_white", "more_pink", "first_white", "first_pink", "first_white_second_white", "first_pink_second_pink", "first_white_second_pink", "first_pink_second_white", "panels", "identifier", "language", "skin", "timezone", "utcOffset", "currencies", "defaultCurrency", "tags", "key", "value", "symbol", "decimals", "step", "barcodeInTicket", "print", "eventResultsByCity", "produces", "playlistId", "colourType", "balls", "drawId", "drawResult", "drawMachine", "result", "draws", "record", "week", "percentage", "history", "result", "drawResult", "drawMachine", "resultVideoURL", "day", "historic", "colourConfigurations", "extId", "name", "croupierName", "videoUrl", "backupVideoUrl", "numDraws", "minDrawValue", "maxDrawValue", "minNumSelections", "maxNumSelections", "payTable", "n1", "n2", "n3", "n4", "n5", "n1_machine_numbers", "n2_machine_numbers", "n3_machine_numbers", "n4_machine_numbers", "n5_machine_numbers", "first_drawn", "first_drawn_machine_numbers", "green_4_plus", "green_5", "red_4_plus", "red_5", "yellow_4_plus", "yellow_5", "historic", "draws", "date", "stats", "drawId", "totalStake", "prizeDay", "ticketId", "prize", "city", "name", "drawResult", "drawMachine", "resultVideoURL", "id", "name", "odds", "marketId", "bets", "displays", "categoryId", "position", "tagSelect", "logo", "classType", "gameType", "landingStyle", "hideUsernameAccount", "hideCredit", "leftButton", "hideBetHistoryTop", "hideCreditTop", "favouritePlaylist", "favouriteHeader", "hideRules", "marketSelectorStyle", "allMarketsSelectionsDisplayed", "hideBottomBanner", "bottomBannerPlaylist", "hideCategoriesSelectorBar", "gameSettings", "categories", "speed", "stamina", "wins", "trifectaLayout6paticipant", "moveEntityReportRowList", "produces", "destinationParentId", "originEntityId", "destinationEntityId", "issues", "id", "name", "probability", "k", "value", "gameOddSettings", "key", "overround", "classType", "id", "excludeStake", "threshold", "calcMode", "includeJackpot", "id", "gameType", "mode", "filter", "assets", "capabilities", "marketTemplates", "participantTemplates", "description", "descriptionTag", "schedulerConfiguration", "playlistId", "countdown", "offset", "key", "countdown", "offset", "stakeTax", "payoutTax", "posReportRowList", "produces", "templatePath", "serialNumber", "imei1", "imei2", "allocation", "agentCode", "userId", "sharedBy", "outsiderPosRunners", "totalNumberOfTickets", "totalWon", "totalStake", "totalSessionTime", "numberOfCancelledTickets", "totalCancelledAmount", "dateOfLastLogin", "ticketPromotionalText", "ticketTopUrl", "headerTicketText01", "headerTicketText02", "headerTicketText03", "bottomTicketText01", "bottomTicketText02", "bottomTicketText03", "legalText", "printCompactPayout", "printCompactBetTicket", "showUnitName", "ticketFormat", "checkTicketMode", "showMaxPayout", "printMaxWinPerTip", "val", "cashier", "viewer", "print", "shopadmin", "mobile", "web", "betslip", "hlsURL", "mediaId", "mediaSignature", "mediaExpireTime", "happenings", "finalOrder", "trackCondition", "name", "forecast", "group", "prob", "risk", "form", "isSimpleView", "ocvVideoSupported", "ocvVoiceoverLangSupported", "maxProb", "minProb", "risk", "raceType", "contextParticipants", "resourcePathNameParticipants", "contextVideo", "resourcePathNameVideo", "numParticipants", "numPodium", "libraryId", "inGameContentType", "city", "date", "prize", "content", "renderingStatus", "classType", "reportId", "jobId", "extId", "extGroupId", "creatorId", "description", "params", "startTime", "endTime", "deprecationTime", "entityId", "fileName", "fileSize", "status", "generatingStatus", "renderingStatus", "deliveringStatus", "generationTime", "deliveredTime", "creationTime", "renderTime", "pausedTime", "contentType", "data", "sequentialReport", "classType", "classType", "produces", "target", "classType", "success", "description", "classType", "entityId", "executionDate", "contents", "croupierName", "videoUrl", "presenterVideoUrl", "presenterImageUrl", "placeBetsIdentUrl", "betsClosedIdentsUrl", "gameIdentUrl", "drawDate", "updateDate", "historic", "result", "presenterImageUrl", "croupierName", "payTable", "odd", "croupierName", "videoUrl", "presenterVideoUrl", "presenterImageUrl", "placeBetsIdentUrl", "betsClosedIdentsUrl", "gameIdentUrl", "drawDate", "updateDate", "result", "historic", "result", "presenterImageUrl", "croupierName", "payTable", "allIn1", "allIn2", "allIn3", "allIn4", "allIn5", "allIn6", "allIn7", "oneOutOf7", "twoOutOf7", "threeOutOf7", "fourOutOf7", "fiveOutOf7", "sixOutOf7", "sevenOutOf7", "noDraw1", "noDraw2", "noDraw3", "noDraw4", "noDraw5", "noDraw6", "noDraw7", "firstBallWhite", "firstBallRed", "lastBallWhite", "lastBallRed", "firstAndSecondSameColor", "firstAndSecondDifferentColor", "sevenWhiteBalls", "sixWhiteBalls", "fiveWhiteBalls", "fourWhiteBalls", "threeWhiteBalls", "twoWhiteBalls", "oneWhiteBalls", "sevenRedBalls", "sixRedBalls", "fiveRedBalls", "fourRedBalls", "threeRedBalls", "twoRedBalls", "oneRedBalls", "sumUnder100", "sumUnder125", "sumOver125", "sumUnder150", "sumOver150", "sumUnder175", "sumOver175", "sumOver200", "sumWhiteUnder73", "sumWhiteOver73", "sumRedUnder73", "sumRedOver73", "countWhiteUnder3", "countWhiteOver3", "countWhiteUnder2", "countWhiteOver2", "countWhiteUnder1", "countWhiteOver1", "countRedUnder3", "countRedOver3", "countRedUnder2", "countRedOver2", "countRedUnder1", "countRedOver1", "moreOdd", "moreEven", "sumOdd", "sumEven", "firstBallOdd", "firstBallEven", "lastBallOdd", "lastBallEven", "firstTwoBallsOdd", "firstTwoBallsEven", "firstOddAndSecondEven", "firstEvenAndSecondOdd", "firstOddAndLastEven", "firstEvenAndLastOdd", "levels", "startTime", "endTime", "timezone", "dailySchedule", "timeSend", "sellStaff", "calculationId", "walletId", "tagsId", "details", "ticketId", "extId", "extData", "serverHash", "ip", "unit", "payStaff", "sellStaff", "timeSend", "timeRegister", "timeResolved", "timeCancelled", "timePaid", "timePrint", "timeClosedMarket", "status", "currency", "stake", "stakeTaxes", "wonData", "winningData", "calculationId", "gameType", "stakePromotional", "details", "jackpotData", "contributions", "limitMaxPayout", "minWinning", "maxWinning", "minBonus", "maxBonus", "wonAmount", "wonCount", "wonJackpot", "wonBonus", "wonTaxes", "systemVersion", "clientId", "tagsId", "calculationId", "auth", "rights", "sessionContext", "extTransactionData", "wallets", "jackpots", "unitTimestamp", "walletId", "balance", "currency", "accounts", "total", "data", "playlistId", "stake", "stakeCancelled", "directCashIn", "paidOut", "jackpotPaidOut", "megaJackpotPaidOut", "bonusPaidOut", "cappedPaidOut", "directCashOut", "won", "jackpotWon", "megaJackpotWon", "bonusWon", "cappedWon", "stakeTaxes", "stakeCancelledTaxes", "paidOutTaxes", "jackpotContribution", "megaJackpotContribution", "produces", "targetEntity", "showTurnover", "showTurnoverStaffName", "showOpenTickets", "showTickets", "showCredit", "showResults", "showReleaseNotes", "hideTicketId", "canCancel", "monitor", "content", "isDeluxe", "historic", "spinType", "mode", "generate", "payTable", "number_1", "number_2", "number_3", "number_4", "number_5", "number_6", "number_7", "number_8", "number_9", "number_10", "number_11", "number_12", "number_13", "number_14", "number_15", "number_16", "number_17", "number_18", "number_19", "number_20", "number_21", "number_22", "number_23", "number_24", "number_25", "number_26", "number_27", "number_28", "number_29", "number_30", "number_31", "number_32", "number_33", "number_34", "number_35", "number_36", "number_0", "number_00", "dozen_1_12", "dozen_13_24", "dozen_25_36", "black", "red", "green", "even", "odd", "low", "high", "sector_a", "sector_b", "sector_c", "sector_d", "sector_e", "sector_f", "twins", "finals_0", "finals_1", "finals_2", "finals_3", "finals_4", "finals_5", "finals_6", "mirror_12_21", "mirror_13_31", "mirror_23_32", "low_red", "high_red", "low_black", "high_black", "speed", "stamina", "wins", "percentageMode", "startDate", "endDate", "entityClientId", "entityId", "timezone", "entityPlayed", "currency", "stake", "won", "taxes", "taxesPaidOut", "jackpotContribution", "jackpot", "megajackpot", "megajackpotContribution", "stakeCancelled", "paid", "lapsed", "playedTickets", "cancelledtickets", "wonTickets", "playlist", "gameType", "jackpotPaid", "megajackpotPaid", "tags", "startDate", "endDate", "entityClientId", "entityId", "entityPlayed", "currency", "gameType", "market", "selection", "stake", "stakeCancelled", "won", "paid", "playlist", "betCount", "timezone", "groupBy", "wonCount", "bonus", "jackpot", "jackpotContribution", "jackpotPaid", "megajackpot", "megajackpotContribution", "megajackpotPaid", "tags", "mode", "historic", "cloverBalls", "isWinX2", "isSecondChance", "isExtra5balls", "riskManagement", "winX2", "secondChanceBonus", "extraBallsBonus", "winX2FrequencyPer", "payTable", "hit_ball_6", "hit_ball_7", "hit_ball_8", "hit_ball_9", "hit_ball_10", "hit_ball_11", "hit_ball_12", "hit_ball_13", "hit_ball_14", "hit_ball_15", "hit_ball_16", "hit_ball_17", "hit_ball_18", "hit_ball_19", "hit_ball_20", "hit_ball_21", "hit_ball_22", "hit_ball_23", "hit_ball_24", "hit_ball_25", "hit_ball_26", "hit_ball_27", "hit_ball_28", "hit_ball_29", "hit_ball_30", "hit_ball_31", "hit_ball_32", "hit_ball_33", "hit_ball_34", "hit_ball_35", "system_hit_ball_7", "system_hit_ball_8", "system_hit_ball_9", "system_hit_ball_10", "top_c1", "top_c2", "top_c3", "top_c4", "first_c1", "first_c2", "first_c3", "first_c4", "last_c1", "last_c2", "last_c3", "last_c4", "more_odd", "more_even", "pre_sum_odd", "pre_sum_even", "first_odd", "first_even", "last_odd", "last_even", "pre_sum_over_122_5", "pre_sum_under_122_5", "first_over_24_5", "first_under_24_5", "last_over_24_5", "last_under_24_5", "evResultData", "mode", "serverTimeStamp", "entityId", "entityPath", "entityMessages", "sessionStatus", "grouping", "systemCount", "stake", "cancelledStake", "winningData", "wonData", "apiVersion", "serverVersion", "proxyVersion", "currencies", "key", "taxPolicy", "classType", "g", "d", "vh", "gh", "va", "ga", "headToHead", "performance", "lastResult", "key", "content", "speed", "ticketTexts", "ticketTopUrl", "legalText", "marketId", "oddId", "oddValue", "stake", "cancelledStake", "betParam", "status", "profitType", "timeSolved", "cancellationEnabled", "sameDayCancel", "maximumCancellationTime", "maximumNumberTicketCancelled", "cancellationMode", "days", "hours", "minutes", "currencySetting", "ticketPolicy", "ticketCancellationSetting", "parentCanCheck", "siblingCanCheck", "childCanCheck", "onSolve", "testStatus", "hashCodeLenght", "key", "policy", "limits", "events", "systemBets", "eventId", "extId", "extData", "playlistId", "playlistDescription", "gameType", "eventTime", "serverStatus", "finalOutcome", "data", "isBanker", "bets", "classType", "val", "classType", "ticket", "transaction", "transactionId", "extTransactionId", "entityId", "extId", "extData", "ticketId", "walletId", "date", "previousCredit", "newCredit", "changeCredit", "currency", "description", "operatorId", "operatorAPI", "method", "params", "is3D", "auroraGtpacksId", "stadiumCode", "contextJockeys", "resourcePathNameJockeys", "raceOddsLevel", "jockeySilkAssetId", "jockey", "jockeyForecast", "sex", "color", "owner", "speed", "stamina", "wins", "place", "timeOff", "art", "ability", "star", "handicap", "handicapPrev", "pace", "entityId", "classType", "localizationContext", "sessionStatus", "generalSettings", "calculationContext", "gameContext", "classType", "gameType", "soundVolume", "tickerSettings", "logoPosition", "absolutTimeDisplay", "allowStreaming", "autoRestart", "jackpotCelebrationType", "gameSettings", "id", "extId", "entityId", "priority", "currency", "description", "startDate", "endDate", "extData", "isPromotion", "onCredit", "classType", "gameType", "gameSettings", "limitMaxPayout", "minWinning", "maxWinning", "minBonus", "maxBonus", "winningCount", "wonCount", "wonAmount", "wonBonus"]), this.ofuscationToAttributes = {}, this.attributesToOfuscation = {}, this.attributes.forEach((function(t, _) {
                        e.ofuscationToAttributes[e.ofuscationHash[_]] = t, e.attributesToOfuscation[t] = e.ofuscationHash[_]
                    }))
                }
                return e.prototype.ofuscateJson = function(e) {
                    var t = JSON.stringify(e);
                    for (var _ in this.attributesToOfuscation) {
                        var a = new RegExp('"' + _ + '":', "g");
                        t = t.replace(a, '"' + this.attributesToOfuscation[_] + '":')
                    }
                    return t
                }, e.prototype.desofuscateString = function(e) {
                    var t = e;
                    for (var _ in this.ofuscationToAttributes) {
                        var a = new RegExp('"' + _ + '":', "g");
                        t = t.replace(a, '"' + this.ofuscationToAttributes[_] + '":')
                    }
                    return JSON.parse(t)
                }, e.prototype.removeDuplicates = function(e) {
                    var t = new Set(e).values();
                    return Array.from(t)
                }, e
            }();
            t.OfuscationManager = a
        },
        g0Eb: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "BasketViewerProfileGameSettings", _
                }
                return n(t, e), t
            }(_("PBHJ").ViewerProfileGameSettings);
            t.BasketViewerProfileGameSettings = r
        },
        gAyu: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e) {
                    e.PENDING = "PENDING", e.GENERATING = "GENERATING", e.GENERATED = "GENERATED", e.RENDERING = "RENDERING", e.RENDERED = "RENDERED", e.DELIVERING = "DELIVERING", e.DELIVERED = "DELIVERED", e.PAUSED = "PAUSED"
                }(t.ReportStatus || (t.ReportStatus = {}))
        },
        gHV8: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.key = e.key, this.overround = e.overround)
            };
            t.OddSettings = a
        },
        gVXq: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "S2WFilter", _
                }
                return n(t, e), t
            }(_("zE96").Filter);
            t.S2WFilter = r
        },
        gWkP: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.week = e.week, this.percentage = e.percentage, this.history = e.history)
            };
            t.LottofiveEventBlockStatsData = a
        },
        hQ5S: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.levels = [], e && e.levels && e.levels.forEach((function(e) {
                        t.levels.push(new a.LevelTax(e))
                    }))
                };
            t.ScaledPayoutTax = n
        },
        iexR: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.playlistSingle = [], e && (this.ticket = e.ticket ? new a.LimitSettings(e.ticket) : null, this.single = e.single ? new a.LimitSingleSettings(e.single) : null, this.combi2 = e.combi2 ? new a.LimitsBonusSetting(e.combi2) : null, this.combi3 = e.combi3 ? new a.LimitsBonusSetting(e.combi3) : null, this.combi4 = e.combi4 ? new a.LimitsBonusSetting(e.combi4) : null, this.combi5 = e.combi5 ? new a.LimitsBonusSetting(e.combi5) : null, this.combi6 = e.combi6 ? new a.LimitsBonusSetting(e.combi6) : null, this.combi7 = e.combi7 ? new a.LimitsBonusSetting(e.combi7) : null, this.combi8 = e.combi8 ? new a.LimitsBonusSetting(e.combi8) : null, this.combi9 = e.combi9 ? new a.LimitsBonusSetting(e.combi9) : null, this.combi10 = e.combi10 ? new a.LimitsBonusSetting(e.combi10) : null, e.playlistSingle && e.playlistSingle.forEach((function(e) {
                        t.playlistSingle.push(new a.LimitsPlaylistSetting(e))
                    })))
                };
            t.LimitsCurrencySetting = n
        },
        j99y: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "SxAssets", _
                }
                return n(t, e), t
            }(_("8xXt").Assets);
            t.SxAssets = r
        },
        jCKK: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "DogFilter", t && (_.stadiumCode = t.stadiumCode, _.raceOddsLevel = t.raceOddsLevel), _
                }
                return n(t, e), t
            }(_("4Lmp").RacesFilter);
            t.DogFilter = r,
                function(e) {
                    ! function(e) {
                        e.ALL = "ALL", e.ONLYGOLDBET = "ONLYGOLDBET", e.LIGHT = "LIGHT", e.MEDIUM = "MEDIUM", e.HARD = "HARD"
                    }(e.RaceOddsLevelEnum || (e.RaceOddsLevelEnum = {}))
                }(r = t.DogFilter || (t.DogFilter = {})), t.DogFilter = r
        },
        jMQt: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    e && (this.grouping = e.grouping, this.systemCount = e.systemCount, this.stake = e.stake, this.cancelledStake = e.cancelledStake, this.winningData = e.winningData ? new a.WinningData(e.winningData) : null, this.wonData = e.wonData ? new a.WonData(e.wonData) : null)
                };
            t.SystemBet = n
        },
        k1rV: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "FightEventBlockStats", _.classification = [], t && t.classification && t.classification.forEach((function(e) {
                            _.classification.push(new r.FightClassificationEntry(e))
                        })), _
                    }
                    return n(t, e), t
                }(_("HZPa").EventBlockStats);
            t.FightEventBlockStats = o
        },
        k9p6: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    e && (this.jackpotId = e.jackpotId, this.entityId = e.entityId, this.amount = e.amount, this.currency = e.currency, this.lastTicket = e.lastTicket ? new a.JackpotTicket(e.lastTicket) : null, this.additionalInfo = e.additionalInfo ? new a.JackpotViewTypeInfo(e.additionalInfo) : null)
                };
            t.JackpotView = n
        },
        kM80: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "GeneratingStatus", _
                }
                return n(t, e), t
            }(_("JazB").ReportProcessStatus);
            t.GeneratingStatus = r
        },
        kbO0: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "HorseParticipant", _.jockeyForecast = [], t && (_.jockeySilkAssetId = t.jockeySilkAssetId, _.jockey = t.jockey, t.jockeyForecast && t.jockeyForecast.forEach((function(e) {
                        _.jockeyForecast.push(e)
                    })), _.sex = t.sex, _.color = t.color, _.owner = t.owner, _.speed = t.speed, _.stamina = t.stamina, _.wins = t.wins, _.place = t.place, _.timeOff = t.timeOff, _.art = t.art, _.ability = t.ability, _.star = t.star, _.handicap = t.handicap, _.handicapPrev = t.handicapPrev, _.pace = t.pace), _
                }
                return n(t, e), t
            }(_("xeXX").RaceParticipant);
            t.HorseParticipant = r
        },
        kf29: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.scope = e.scope, this.resource = e.resource, this.errorCode = e.errorCode, this.message = e.message, this.param = e.param, this.extData = e.extData, this.expiredTime = e.expiredTime)
            };
            t.ErrorInfo = a,
                function(e) {
                    ! function(e) {
                        e.CONNECTION = "CONNECTION", e.PROXY = "PROXY", e.SERVER = "SERVER", e.CLIENT = "CLIENT"
                    }(e.ScopeEnum || (e.ScopeEnum = {}))
                }(a = t.ErrorInfo || (t.ErrorInfo = {})), t.ErrorInfo = a
        },
        kux3: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    e && (this.content = e.content, this.renderingStatus = e.renderingStatus ? new a.RenderingStatus(e.renderingStatus) : null)
                };
            t.RenderingResult = n
        },
        kyaP: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "LlEventBlockData", t && (_.minBet = t.minBet, _.maxBet = t.maxBet, _.croupierName = t.croupierName, _.videoUrl = t.videoUrl, _.presenterVideoUrl = t.presenterVideoUrl, _.presenterImageUrl = t.presenterImageUrl, _.placeBetsIdentUrl = t.placeBetsIdentUrl, _.betsClosedIdentsUrl = t.betsClosedIdentsUrl, _.gameIdentUrl = t.gameIdentUrl, t.drawDate ? _.drawDate = new Date(t.drawDate.toString()) : _.drawDate = null, t.updateDate ? _.updateDate = new Date(t.updateDate.toString()) : _.updateDate = null), _
                }
                return n(t, e), t
            }(_("AjTw").EventBlockData);
            t.LlEventBlockData = r
        },
        lIV4: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.entityPaths = {}, this.entityMessages = {}, this.sessionStatus = {}, e && (e.serverTimeStamp ? this.serverTimeStamp = new Date(e.serverTimeStamp.toString()) : this.serverTimeStamp = null, e.entityPaths && Object.keys(e.entityPaths).forEach((function(_) {
                        t.entityPaths[_] = e.entityPaths[_]
                    })), e.entityMessages && Object.keys(e.entityMessages).forEach((function(_) {
                        t.entityMessages[_] = e.entityMessages[_]
                    })), e.sessionStatus && Object.keys(e.sessionStatus).forEach((function(_) {
                        t.sessionStatus[_] = new a.SessionStatus(e.sessionStatus[_])
                    })))
                };
            t.BulkSyncData = n
        },
        ljvT: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "GenericTicketPolicy", t && (_.oneBetPerEvent = t.oneBetPerEvent, _.refuseIfExceedMaxPayout = t.refuseIfExceedMaxPayout, _.oneTicketPerEvent = t.oneTicketPerEvent, _.oneEventPerTicket = t.oneEventPerTicket), _
                }
                return n(t, e), t
            }(_("Kjxo").TicketPolicy);
            t.GenericTicketPolicy = r
        },
        mEeu: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "MotorbikeFilter", _
                }
                return n(t, e), t
            }(_("4Lmp").RacesFilter);
            t.MotorbikeFilter = r
        },
        mmv6: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "MotorbikeParticipant", t && (_.speed = t.speed, _.stamina = t.stamina, _.wins = t.wins), _
                }
                return n(t, e), t
            }(_("xeXX").RaceParticipant);
            t.MotorbikeParticipant = r
        },
        mpRG: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "BasketEventBlockData", t && (_.matchesGroupId = t.matchesGroupId, _.phase = t.phase), _
                }
                return n(t, e), t
            }(_("AjTw").EventBlockData);
            t.BasketEventBlockData = r,
                function(e) {
                    ! function(e) {
                        e.PREGAME = "PREGAME", e.INGAME = "INGAME"
                    }(e.PhaseEnum || (e.PhaseEnum = {}))
                }(r = t.BasketEventBlockData || (t.BasketEventBlockData = {})), t.BasketEventBlockData = r
        },
        mpiV: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.videoHappening = [], e && (this.mediaId = e.mediaId, this.playerBId = e.playerBId, this.playerWId = e.playerWId, this.type = e.type, this.id = e.id, this.duration = e.duration, this.scoreB = e.scoreB, this.scoreW = e.scoreW, e.videoHappening && e.videoHappening.forEach((function(e) {
                        t.videoHappening.push(new a.FightVideoHappening(e))
                    })))
                };
            t.FightVideo = n,
                function(e) {
                    ! function(e) {
                        e.HS = "HS", e.WB = "WB", e.WW = "WW", e.WD = "WD", e.KB = "KB", e.KW = "KW", e.SB = "SB", e.SW = "SW"
                    }(e.TypeEnum || (e.TypeEnum = {}))
                }(n = t.FightVideo || (t.FightVideo = {})), t.FightVideo = n
        },
        nDVM: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                var t = this;
                this.balls = [], e && (this.colourType = e.colourType, e.balls && e.balls.forEach((function(e) {
                    t.balls.push(e)
                })))
            };
            t.LottofiveColourConfiguration = a
        },
        nP5Z: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.participants = [], this.probabilityValues = [], this.kValues = [], this.oddValues = [], e && (e.participants && e.participants.forEach((function(e) {
                        t.participants.push(new a.Participant(e))
                    })), e.probabilityValues && e.probabilityValues.forEach((function(e) {
                        t.probabilityValues.push(e)
                    })), e.kValues && e.kValues.forEach((function(e) {
                        t.kValues.push(e)
                    })), e.oddValues && e.oddValues.forEach((function(e) {
                        t.oddValues.push(e)
                    })), this.liveUrl = e.liveUrl, this.stats = e.stats ? new a.EventStats(e.stats) : null, this.gameData = e.gameData ? new a.GameEventData(e.gameData) : null)
                };
            t.EventData = n
        },
        nQFw: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "LottoResultReportParams", t && (_.produces = t.produces, _.playlistId = t.playlistId), _
                }
                return n(t, e), t
            }(_("nzvJ").ReportParams);
            t.LottoResultReportParams = r
        },
        nfOZ: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function() {
                    function e(e, t) {
                        if (void 0 === t && (t = !0), e && (this.classType = e.classType, this.gameType = e.gameType, t && this.classType)) switch (this.classType) {
                            case "ChCashierProfileGameSettings":
                                return new a.ChCashierProfileGameSettings(e);
                            case "LkCashierProfileGameSettings":
                                return new a.LkCashierProfileGameSettings(e);
                            case "SxCashierProfileGameSettings":
                                return new a.SxCashierProfileGameSettings(e)
                        }
                    }
                    return e.prototype.isChCashierProfileGameSettings = function() {
                        return "ChCashierProfileGameSettings" === this.classType
                    }, e.prototype.isLkCashierProfileGameSettings = function() {
                        return "LkCashierProfileGameSettings" === this.classType
                    }, e.prototype.isSxCashierProfileGameSettings = function() {
                        return "SxCashierProfileGameSettings" === this.classType
                    }, e
                }();
            t.CashierProfileGameSettings = n
        },
        "nlQ/": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.bets = [], e && (this.marketId = e.marketId, e.bets && e.bets.forEach((function(e) {
                        t.bets.push(new a.Bet(e))
                    })))
                };
            t.MarketValues = n
        },
        nwBH: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "S2WEventResultData", _.result = [], t && t.result && t.result.forEach((function(e) {
                        _.result.push(e)
                    })), _
                }
                return n(t, e), t
            }(_("RUMs").EventResultData);
            t.S2WEventResultData = r
        },
        nzIM: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "ChEventBlockStats", _.groupClassification = [], _.knockoutClassification = [], t && (t.groupClassification && t.groupClassification.forEach((function(e) {
                            _.groupClassification.push(new r.ChGroupClassificationEntry(e))
                        })), t.knockoutClassification && t.knockoutClassification.forEach((function(e) {
                            _.knockoutClassification.push(new r.ChKnockoutClassificationEntry(e))
                        }))), _
                    }
                    return n(t, e), t
                }(_("HZPa").EventBlockStats);
            t.ChEventBlockStats = o
        },
        nzvJ: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function() {
                    function e(e, t) {
                        if (void 0 === t && (t = !0), e && (this.classType = e.classType, this.produces = e.produces, this.target = e.target ? new a.ReportTarget(e.target) : null, t && this.classType)) switch (this.classType) {
                            case "PosReportParams":
                                return new a.PosReportParams(e);
                            case "SettlementReportParams":
                                return new a.SettlementReportParams(e);
                            case "LottoResultReportParams":
                                return new a.LottoResultReportParams(e);
                            case "MoveEntityReportParams":
                                return new a.MoveEntityReportParams(e)
                        }
                    }
                    return e.prototype.isPosReportParams = function() {
                        return "PosReportParams" === this.classType
                    }, e.prototype.isSettlementReportParams = function() {
                        return "SettlementReportParams" === this.classType
                    }, e.prototype.isLottoResultReportParams = function() {
                        return "LottoResultReportParams" === this.classType
                    }, e.prototype.isMoveEntityReportParams = function() {
                        return "MoveEntityReportParams" === this.classType
                    }, e
                }();
            t.ReportParams = n
        },
        o4iV: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a, n = _("PWJJ");
            ! function(e) {
                e[e.apiHash = 0] = "apiHash", e[e.apiKey = 1] = "apiKey", e[e.clientIdAuth = 2] = "clientIdAuth"
            }(a = t.ChannelApiApiKeys || (t.ChannelApiApiKeys = {}));
            var r, o = function() {
                function e(e, t, _, a, r) {
                    this.basePath = "", this.host = "", this.defaultHeaders = {}, this.connection = null, this.authentications = {
                        default: new n.VoidAuth,
                        apiHash: new n.ApiKeyAuth("header", "apiHash"),
                        apiKey: new n.ApiKeyAuth("header", "apiId"),
                        clientIdAuth: new n.ApiKeyAuth("header", "clientId")
                    }, this.connection = e, this.basePath = _, this.host = t, r ? _ && (this.basePath = _) : a && (this.basePath = a)
                }
                return e.prototype.setApiKey = function(e, t) {
                    this.authentications[a[e]].apiKey = t
                }, e.prototype.channelGetByIds = function(e) {
                    var t = {},
                        _ = n.extendObj({}, this.defaultHeaders);
                    if (null == e) throw new Error("Required parameter ids was null or undefined when calling channelGetByIds.");
                    null != e && (Array.isArray(e) ? t.ids = e.join(",") : t.ids = e), _["Content-Type"] = "application/json";
                    var a = {
                        method: "GET",
                        query: t,
                        headers: _,
                        resource: "/channels/",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(a), this.authentications.default.applyToRequest(a), n.createConnectionPromise(this.connection, a)
                }, e
            }();
            t.ChannelApiService = o,
                function(e) {
                    e[e.apiHash = 0] = "apiHash", e[e.apiKey = 1] = "apiKey", e[e.clientIdAuth = 2] = "clientIdAuth"
                }(r = t.CreditApiApiKeys || (t.CreditApiApiKeys = {}));
            var i, s = function() {
                function e(e, t, _, a, r) {
                    this.basePath = "", this.host = "", this.defaultHeaders = {}, this.connection = null, this.authentications = {
                        default: new n.VoidAuth,
                        apiHash: new n.ApiKeyAuth("header", "apiHash"),
                        apiKey: new n.ApiKeyAuth("header", "apiId"),
                        clientIdAuth: new n.ApiKeyAuth("header", "clientId")
                    }, this.connection = e, this.basePath = _, this.host = t, r ? _ && (this.basePath = _) : a && (this.basePath = a)
                }
                return e.prototype.setApiKey = function(e, t) {
                    this.authentications[r[e]].apiKey = t
                }, e.prototype.creditHistory = function(e, t, _, a, r) {
                    var o = {},
                        i = n.extendObj({}, this.defaultHeaders);
                    null != e && (Array.isArray(e) ? o.startTime = e.join(",") : o.startTime = e), null != t && (Array.isArray(t) ? o.endTime = t.join(",") : o.endTime = t), null != _ && (Array.isArray(_) ? o.n = _.join(",") : o.n = _), null != a && (Array.isArray(a) ? o.first = a.join(",") : o.first = a), null != r && (Array.isArray(r) ? o.walletIds = r.join(",") : o.walletIds = r), i["Content-Type"] = "application/json";
                    var s = {
                        method: "GET",
                        query: o,
                        headers: i,
                        resource: "/credit/history",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(s), this.authentications.default.applyToRequest(s), n.createConnectionPromise(this.connection, s)
                }, e.prototype.creditHistoryByTicketId = function(e) {
                    var t = {},
                        _ = n.extendObj({}, this.defaultHeaders);
                    null != e && (Array.isArray(e) ? t.ticketIds = e.join(",") : t.ticketIds = e), _["Content-Type"] = "application/json";
                    var a = {
                        method: "GET",
                        query: t,
                        headers: _,
                        resource: "/credit/historyByTicketId",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(a), this.authentications.default.applyToRequest(a), n.createConnectionPromise(this.connection, a)
                }, e
            }();
            t.CreditApiService = s,
                function(e) {
                    e[e.apiHash = 0] = "apiHash", e[e.apiKey = 1] = "apiKey", e[e.clientIdAuth = 2] = "clientIdAuth"
                }(i = t.EventBlockApiApiKeys || (t.EventBlockApiApiKeys = {}));
            var c, l = function() {
                function e(e, t, _, a, r) {
                    this.basePath = "", this.host = "", this.defaultHeaders = {}, this.connection = null, this.authentications = {
                        default: new n.VoidAuth,
                        apiHash: new n.ApiKeyAuth("header", "apiHash"),
                        apiKey: new n.ApiKeyAuth("header", "apiId"),
                        clientIdAuth: new n.ApiKeyAuth("header", "clientId")
                    }, this.connection = e, this.basePath = _, this.host = t, r ? _ && (this.basePath = _) : a && (this.basePath = a)
                }
                return e.prototype.setApiKey = function(e, t) {
                    this.authentications[i[e]].apiKey = t
                }, e.prototype.eventBlockData = function(e, t, _, a, r, o, i, s, c) {
                    var l = {},
                        u = n.extendObj({}, this.defaultHeaders);
                    if (null == e) throw new Error("Required parameter contentType was null or undefined when calling eventBlockData.");
                    if (null == t) throw new Error("Required parameter contentId was null or undefined when calling eventBlockData.");
                    if (null == _) throw new Error("Required parameter profile was null or undefined when calling eventBlockData.");
                    null != e && (Array.isArray(e) ? l.contentType = e.join(",") : l.contentType = e), null != t && (Array.isArray(t) ? l.contentId = t.join(",") : l.contentId = t), null != a && (Array.isArray(a) ? l.countDown = a.join(",") : l.countDown = a), null != r && (Array.isArray(r) ? l.offset = r.join(",") : l.offset = r), null != o && (Array.isArray(o) ? l.eventTime = o.join(",") : l.eventTime = o), null != i && (Array.isArray(i) ? l.n = i.join(",") : l.n = i), null != _ && (Array.isArray(_) ? l.profile = _.join(",") : l.profile = _), null != s && (Array.isArray(s) ? l.calculationId = s.join(",") : l.calculationId = s), null != c && (Array.isArray(c) ? l.unitId = c.join(",") : l.unitId = c), u["Content-Type"] = "application/json";
                    var d = {
                        method: "GET",
                        query: l,
                        headers: u,
                        resource: "/eventBlocks/event/data",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(d), this.authentications.default.applyToRequest(d), n.createConnectionPromise(this.connection, d)
                }, e.prototype.eventBlockFind = function(e, t, _, a, r, o, i, s, c, l, u, d, p, h) {
                    var f = {},
                        y = n.extendObj({}, this.defaultHeaders);
                    if (null == e) throw new Error("Required parameter startTime was null or undefined when calling eventBlockFind.");
                    if (null == t) throw new Error("Required parameter contentType was null or undefined when calling eventBlockFind.");
                    if (null == _) throw new Error("Required parameter contentId was null or undefined when calling eventBlockFind.");
                    if (null == a) throw new Error("Required parameter profile was null or undefined when calling eventBlockFind.");
                    null != e && (Array.isArray(e) ? f.startTime = e.join(",") : f.startTime = e), null != r && (Array.isArray(r) ? f.endTime = r.join(",") : f.endTime = r), null != o && (Array.isArray(o) ? f.order = o.join(",") : f.order = o), null != i && (Array.isArray(i) ? f.status = i.join(",") : f.status = i), null != t && (Array.isArray(t) ? f.contentType = t.join(",") : f.contentType = t), null != _ && (Array.isArray(_) ? f.contentId = _.join(",") : f.contentId = _), null != s && (Array.isArray(s) ? f.countDown = s.join(",") : f.countDown = s), null != c && (Array.isArray(c) ? f.offset = c.join(",") : f.offset = c), null != l && (Array.isArray(l) ? f.n = l.join(",") : f.n = l), null != u && (Array.isArray(u) ? f.first = u.join(",") : f.first = u), null != a && (Array.isArray(a) ? f.profile = a.join(",") : f.profile = a), null != d && (Array.isArray(d) ? f.calculationId = d.join(",") : f.calculationId = d), null != p && (Array.isArray(p) ? f.eBlockId = p.join(",") : f.eBlockId = p), null != h && (Array.isArray(h) ? f.unitId = h.join(",") : f.unitId = h), y["Content-Type"] = "application/json";
                    var m = {
                        method: "GET",
                        query: f,
                        headers: y,
                        resource: "/eventBlocks/find",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(m), this.authentications.default.applyToRequest(m), n.createConnectionPromise(this.connection, m)
                }, e.prototype.eventBlockHistory = function(e, t, _, a, r, o, i, s, c, l, u) {
                    var d = {},
                        p = n.extendObj({}, this.defaultHeaders);
                    if (null == e) throw new Error("Required parameter contentType was null or undefined when calling eventBlockHistory.");
                    if (null == t) throw new Error("Required parameter contentId was null or undefined when calling eventBlockHistory.");
                    if (null == _) throw new Error("Required parameter profile was null or undefined when calling eventBlockHistory.");
                    null != e && (Array.isArray(e) ? d.contentType = e.join(",") : d.contentType = e), null != t && (Array.isArray(t) ? d.contentId = t.join(",") : d.contentId = t), null != a && (Array.isArray(a) ? d.countDown = a.join(",") : d.countDown = a), null != r && (Array.isArray(r) ? d.offset = r.join(",") : d.offset = r), null != o && (Array.isArray(o) ? d.startTime = o.join(",") : d.startTime = o), null != i && (Array.isArray(i) ? d.endTime = i.join(",") : d.endTime = i), null != s && (Array.isArray(s) ? d.n = s.join(",") : d.n = s), null != _ && (Array.isArray(_) ? d.profile = _.join(",") : d.profile = _), null != c && (Array.isArray(c) ? d.calculationId = c.join(",") : d.calculationId = c), null != l && (Array.isArray(l) ? d.eBlockId = l.join(",") : d.eBlockId = l), null != u && (Array.isArray(u) ? d.unitId = u.join(",") : d.unitId = u), p["Content-Type"] = "application/json";
                    var h = {
                        method: "GET",
                        query: d,
                        headers: p,
                        resource: "/eventBlocks/history",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(h), this.authentications.default.applyToRequest(h), n.createConnectionPromise(this.connection, h)
                }, e.prototype.eventBlockResult = function(e, t, _, a, r, o, i, s, c, l) {
                    var u = {},
                        d = n.extendObj({}, this.defaultHeaders);
                    if (null == e) throw new Error("Required parameter contentType was null or undefined when calling eventBlockResult.");
                    if (null == t) throw new Error("Required parameter contentId was null or undefined when calling eventBlockResult.");
                    if (null == _) throw new Error("Required parameter profile was null or undefined when calling eventBlockResult.");
                    null != e && (Array.isArray(e) ? u.contentType = e.join(",") : u.contentType = e), null != t && (Array.isArray(t) ? u.contentId = t.join(",") : u.contentId = t), null != a && (Array.isArray(a) ? u.countDown = a.join(",") : u.countDown = a), null != r && (Array.isArray(r) ? u.offset = r.join(",") : u.offset = r), null != o && (Array.isArray(o) ? u.eventTime = o.join(",") : u.eventTime = o), null != i && (Array.isArray(i) ? u.n = i.join(",") : u.n = i), null != _ && (Array.isArray(_) ? u.profile = _.join(",") : u.profile = _), null != s && (Array.isArray(s) ? u.calculationId = s.join(",") : u.calculationId = s), null != c && (Array.isArray(c) ? u.eBlockId = c.join(",") : u.eBlockId = c), null != l && (Array.isArray(l) ? u.unitId = l.join(",") : u.unitId = l), d["Content-Type"] = "application/json";
                    var p = {
                        method: "GET",
                        query: u,
                        headers: d,
                        resource: "/eventBlocks/event/result",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(p), this.authentications.default.applyToRequest(p), n.createConnectionPromise(this.connection, p)
                }, e.prototype.eventBlockStats = function(e, t, _, a, r, o, i, s, c, l) {
                    var u = {},
                        d = n.extendObj({}, this.defaultHeaders);
                    if (null == e) throw new Error("Required parameter contentType was null or undefined when calling eventBlockStats.");
                    if (null == t) throw new Error("Required parameter contentId was null or undefined when calling eventBlockStats.");
                    if (null == _) throw new Error("Required parameter profile was null or undefined when calling eventBlockStats.");
                    null != e && (Array.isArray(e) ? u.contentType = e.join(",") : u.contentType = e), null != t && (Array.isArray(t) ? u.contentId = t.join(",") : u.contentId = t), null != a && (Array.isArray(a) ? u.countDown = a.join(",") : u.countDown = a), null != r && (Array.isArray(r) ? u.offset = r.join(",") : u.offset = r), null != o && (Array.isArray(o) ? u.eventTime = o.join(",") : u.eventTime = o), null != i && (Array.isArray(i) ? u.n = i.join(",") : u.n = i), null != _ && (Array.isArray(_) ? u.profile = _.join(",") : u.profile = _), null != s && (Array.isArray(s) ? u.calculationId = s.join(",") : u.calculationId = s), null != c && (Array.isArray(c) ? u.eBlockId = c.join(",") : u.eBlockId = c), null != l && (Array.isArray(l) ? u.unitId = l.join(",") : u.unitId = l), d["Content-Type"] = "application/json";
                    var p = {
                        method: "GET",
                        query: u,
                        headers: d,
                        resource: "/eventBlocks/stats",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(p), this.authentications.default.applyToRequest(p), n.createConnectionPromise(this.connection, p)
                }, e.prototype.eventLiveStats = function(e, t, _, a, r, o, i, s, c, l) {
                    var u = {},
                        d = n.extendObj({}, this.defaultHeaders);
                    if (null == e) throw new Error("Required parameter contentType was null or undefined when calling eventLiveStats.");
                    if (null == t) throw new Error("Required parameter contentId was null or undefined when calling eventLiveStats.");
                    if (null == _) throw new Error("Required parameter profile was null or undefined when calling eventLiveStats.");
                    null != e && (Array.isArray(e) ? u.contentType = e.join(",") : u.contentType = e), null != t && (Array.isArray(t) ? u.contentId = t.join(",") : u.contentId = t), null != a && (Array.isArray(a) ? u.countDown = a.join(",") : u.countDown = a), null != r && (Array.isArray(r) ? u.offset = r.join(",") : u.offset = r), null != o && (Array.isArray(o) ? u.eventTime = o.join(",") : u.eventTime = o), null != i && (Array.isArray(i) ? u.n = i.join(",") : u.n = i), null != _ && (Array.isArray(_) ? u.profile = _.join(",") : u.profile = _), null != s && (Array.isArray(s) ? u.calculationId = s.join(",") : u.calculationId = s), null != c && (Array.isArray(c) ? u.eBlockId = c.join(",") : u.eBlockId = c), null != l && (Array.isArray(l) ? u.unitId = l.join(",") : u.unitId = l), d["Content-Type"] = "application/json";
                    var p = {
                        method: "GET",
                        query: u,
                        headers: d,
                        resource: "/eventBlocks/event/liveStats",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(p), this.authentications.default.applyToRequest(p), n.createConnectionPromise(this.connection, p)
                }, e.prototype.eventStats = function(e, t, _, a, r, o, i, s, c, l) {
                    var u = {},
                        d = n.extendObj({}, this.defaultHeaders);
                    if (null == e) throw new Error("Required parameter contentType was null or undefined when calling eventStats.");
                    if (null == t) throw new Error("Required parameter contentId was null or undefined when calling eventStats.");
                    if (null == _) throw new Error("Required parameter profile was null or undefined when calling eventStats.");
                    null != e && (Array.isArray(e) ? u.contentType = e.join(",") : u.contentType = e), null != t && (Array.isArray(t) ? u.contentId = t.join(",") : u.contentId = t), null != a && (Array.isArray(a) ? u.countDown = a.join(",") : u.countDown = a), null != r && (Array.isArray(r) ? u.offset = r.join(",") : u.offset = r), null != o && (Array.isArray(o) ? u.eventTime = o.join(",") : u.eventTime = o), null != i && (Array.isArray(i) ? u.n = i.join(",") : u.n = i), null != _ && (Array.isArray(_) ? u.profile = _.join(",") : u.profile = _), null != s && (Array.isArray(s) ? u.calculationId = s.join(",") : u.calculationId = s), null != c && (Array.isArray(c) ? u.eBlockId = c.join(",") : u.eBlockId = c), null != l && (Array.isArray(l) ? u.unitId = l.join(",") : u.unitId = l), d["Content-Type"] = "application/json";
                    var p = {
                        method: "GET",
                        query: u,
                        headers: d,
                        resource: "/eventBlocks/event/stats",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(p), this.authentications.default.applyToRequest(p), n.createConnectionPromise(this.connection, p)
                }, e.prototype.findOpenMarketsByEventId = function(e, t, _) {
                    var a = {},
                        r = n.extendObj({}, this.defaultHeaders);
                    if (null == e) throw new Error("Required parameter eventId was null or undefined when calling findOpenMarketsByEventId.");
                    if (null == t) throw new Error("Required parameter playlistId was null or undefined when calling findOpenMarketsByEventId.");
                    if (null == _) throw new Error("Required parameter calculationId was null or undefined when calling findOpenMarketsByEventId.");
                    null != e && (Array.isArray(e) ? a.eventId = e.join(",") : a.eventId = e), null != t && (Array.isArray(t) ? a.playlistId = t.join(",") : a.playlistId = t), null != _ && (Array.isArray(_) ? a.calculationId = _.join(",") : a.calculationId = _), r["Content-Type"] = "application/json";
                    var o = {
                        method: "GET",
                        query: a,
                        headers: r,
                        resource: "/eventBlocks/findOpenMarketsByEventId",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(o), this.authentications.default.applyToRequest(o), n.createConnectionPromise(this.connection, o)
                }, e
            }();
            t.EventBlockApiService = l,
                function(e) {
                    e[e.apiHash = 0] = "apiHash", e[e.apiKey = 1] = "apiKey", e[e.clientIdAuth = 2] = "clientIdAuth"
                }(c = t.PlaylistApiApiKeys || (t.PlaylistApiApiKeys = {}));
            var u, d = function() {
                function e(e, t, _, a, r) {
                    this.basePath = "", this.host = "", this.defaultHeaders = {}, this.connection = null, this.authentications = {
                        default: new n.VoidAuth,
                        apiHash: new n.ApiKeyAuth("header", "apiHash"),
                        apiKey: new n.ApiKeyAuth("header", "apiId"),
                        clientIdAuth: new n.ApiKeyAuth("header", "clientId")
                    }, this.connection = e, this.basePath = _, this.host = t, r ? _ && (this.basePath = _) : a && (this.basePath = a)
                }
                return e.prototype.setApiKey = function(e, t) {
                    this.authentications[c[e]].apiKey = t
                }, e.prototype.playlistGetByIds = function(e) {
                    var t = {},
                        _ = n.extendObj({}, this.defaultHeaders);
                    if (null == e) throw new Error("Required parameter ids was null or undefined when calling playlistGetByIds.");
                    null != e && (Array.isArray(e) ? t.ids = e.join(",") : t.ids = e), _["Content-Type"] = "application/json";
                    var a = {
                        method: "GET",
                        query: t,
                        headers: _,
                        resource: "/playlists/",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(a), this.authentications.default.applyToRequest(a), n.createConnectionPromise(this.connection, a)
                }, e
            }();
            t.PlaylistApiService = d,
                function(e) {
                    e[e.apiHash = 0] = "apiHash", e[e.apiKey = 1] = "apiKey", e[e.clientIdAuth = 2] = "clientIdAuth"
                }(u = t.ReportApiApiKeys || (t.ReportApiApiKeys = {}));
            var p, h = function() {
                function e(e, t, _, a, r) {
                    this.basePath = "", this.host = "", this.defaultHeaders = {}, this.connection = null, this.authentications = {
                        default: new n.VoidAuth,
                        apiHash: new n.ApiKeyAuth("header", "apiHash"),
                        apiKey: new n.ApiKeyAuth("header", "apiId"),
                        clientIdAuth: new n.ApiKeyAuth("header", "clientId")
                    }, this.connection = e, this.basePath = _, this.host = t, r ? _ && (this.basePath = _) : a && (this.basePath = a)
                }
                return e.prototype.setApiKey = function(e, t) {
                    this.authentications[u[e]].apiKey = t
                }, e.prototype.reportFind = function(e, t, _, a, r, o, i, s) {
                    var c = {},
                        l = n.extendObj({}, this.defaultHeaders);
                    if (null == e) throw new Error("Required parameter entityId was null or undefined when calling reportFind.");
                    if (null == t) throw new Error("Required parameter startTime was null or undefined when calling reportFind.");
                    null != _ && (Array.isArray(_) ? c.creatorId = _.join(",") : c.creatorId = _), null != e && (Array.isArray(e) ? c.entityId = e.join(",") : c.entityId = e), null != a && (Array.isArray(a) ? c.classType = a.join(",") : c.classType = a), null != t && (Array.isArray(t) ? c.startTime = t.join(",") : c.startTime = t), null != r && (Array.isArray(r) ? c.endTime = r.join(",") : c.endTime = r), null != o && (Array.isArray(o) ? c.includeData = o.join(",") : c.includeData = o), null != i && (Array.isArray(i) ? c.n = i.join(",") : c.n = i), null != s && (Array.isArray(s) ? c.orderBy = s.join(",") : c.orderBy = s), l["Content-Type"] = "application/json";
                    var u = {
                        method: "GET",
                        query: c,
                        headers: l,
                        resource: "/reports/find",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(u), this.authentications.default.applyToRequest(u), n.createConnectionPromise(this.connection, u)
                }, e.prototype.reportFindById = function(e, t, _) {
                    var a = {},
                        r = n.extendObj({}, this.defaultHeaders);
                    if (null == e) throw new Error("Required parameter reportId was null or undefined when calling reportFindById.");
                    if (null == t) throw new Error("Required parameter entityId was null or undefined when calling reportFindById.");
                    null != e && (Array.isArray(e) ? a.reportId = e.join(",") : a.reportId = e), null != t && (Array.isArray(t) ? a.entityId = t.join(",") : a.entityId = t), null != _ && (Array.isArray(_) ? a.includeData = _.join(",") : a.includeData = _), r["Content-Type"] = "application/json";
                    var o = {
                        method: "GET",
                        query: a,
                        headers: r,
                        resource: "/reports/findById",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(o), this.authentications.default.applyToRequest(o), n.createConnectionPromise(this.connection, o)
                }, e.prototype.reportRegister = function(e, t, _, a, r, o, i, s) {
                    var c = {},
                        l = n.extendObj({}, this.defaultHeaders);
                    if (null == e) throw new Error("Required parameter entityId was null or undefined when calling reportRegister.");
                    if (null == t) throw new Error("Required parameter startTime was null or undefined when calling reportRegister.");
                    if (null == _) throw new Error("Required parameter description was null or undefined when calling reportRegister.");
                    if (null == a) throw new Error("Required parameter classType was null or undefined when calling reportRegister.");
                    null != e && (Array.isArray(e) ? c.entityId = e.join(",") : c.entityId = e), null != t && (Array.isArray(t) ? c.startTime = t.join(",") : c.startTime = t), null != r && (Array.isArray(r) ? c.endTime = r.join(",") : c.endTime = r), null != o && (Array.isArray(o) ? c.deprecationTime = o.join(",") : c.deprecationTime = o), null != _ && (Array.isArray(_) ? c.description = _.join(",") : c.description = _), null != a && (Array.isArray(a) ? c.classType = a.join(",") : c.classType = a), null != i && (Array.isArray(i) ? c.fileName = i.join(",") : c.fileName = i), l["Content-Type"] = "application/json";
                    var u = {
                        method: "POST",
                        query: c,
                        headers: l,
                        body: s,
                        resource: "/reports/register",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(u), this.authentications.default.applyToRequest(u), n.createConnectionPromise(this.connection, u)
                }, e
            }();
            t.ReportApiService = h,
                function(e) {
                    e[e.apiHash = 0] = "apiHash", e[e.apiKey = 1] = "apiKey", e[e.clientIdAuth = 2] = "clientIdAuth"
                }(p = t.SessionApiApiKeys || (t.SessionApiApiKeys = {}));
            var f, y = function() {
                function e(e, t, _, a, r) {
                    this.basePath = "", this.host = "", this.defaultHeaders = {}, this.connection = null, this.authentications = {
                        default: new n.VoidAuth,
                        apiHash: new n.ApiKeyAuth("header", "apiHash"),
                        apiKey: new n.ApiKeyAuth("header", "apiId"),
                        clientIdAuth: new n.ApiKeyAuth("header", "clientId")
                    }, this.connection = e, this.basePath = _, this.host = t, r ? _ && (this.basePath = _) : a && (this.basePath = a)
                }
                return e.prototype.setApiKey = function(e, t) {
                    this.authentications[p[e]].apiKey = t
                }, e.prototype.calculationContextGetById = function(e) {
                    var t = {},
                        _ = n.extendObj({}, this.defaultHeaders);
                    if (null == e) throw new Error("Required parameter ids was null or undefined when calling calculationContextGetById.");
                    null != e && (Array.isArray(e) ? t.ids = e.join(",") : t.ids = e), _["Content-Type"] = "application/json";
                    var a = {
                        method: "GET",
                        query: t,
                        headers: _,
                        resource: "/session/calculationContext",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(a), this.authentications.default.applyToRequest(a), n.createConnectionPromise(this.connection, a)
                }, e.prototype.currencyGetById = function(e) {
                    var t = {},
                        _ = n.extendObj({}, this.defaultHeaders);
                    null != e && (Array.isArray(e) ? t.ids = e.join(",") : t.ids = e), _["Content-Type"] = "application/json";
                    var a = {
                        method: "GET",
                        query: t,
                        headers: _,
                        resource: "/session/currency",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(a), this.authentications.default.applyToRequest(a), n.createConnectionPromise(this.connection, a)
                }, e.prototype.sessionBulkKeepAlive = function(e) {
                    var t = n.extendObj({}, this.defaultHeaders);
                    if (null == e) throw new Error("Required parameter clientIds was null or undefined when calling sessionBulkKeepAlive.");
                    t["Content-Type"] = "application/json";
                    var _ = {
                        method: "POST",
                        query: {},
                        headers: t,
                        body: e,
                        resource: "/session/bulkKeepAlive",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(_), this.authentications.default.applyToRequest(_), n.createConnectionPromise(this.connection, _)
                }, e.prototype.sessionBulkSync = function(e) {
                    var t = {},
                        _ = n.extendObj({}, this.defaultHeaders);
                    if (null == e) throw new Error("Required parameter lastSyncTime was null or undefined when calling sessionBulkSync.");
                    null != e && (Array.isArray(e) ? t.lastSyncTime = e.join(",") : t.lastSyncTime = e), _["Content-Type"] = "application/json";
                    var a = {
                        method: "GET",
                        query: t,
                        headers: _,
                        resource: "/session/bulkSync",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.apiKey.applyToRequest(a), this.authentications.apiHash.applyToRequest(a), this.authentications.default.applyToRequest(a), n.createConnectionPromise(this.connection, a)
                }, e.prototype.sessionLoginHwId = function(e, t, _) {
                    var a = {},
                        r = n.extendObj({}, this.defaultHeaders);
                    if (null == e) throw new Error("Required parameter hwId was null or undefined when calling sessionLoginHwId.");
                    if (null == t) throw new Error("Required parameter profiles was null or undefined when calling sessionLoginHwId.");
                    null != e && (Array.isArray(e) ? a.hwId = e.join(",") : a.hwId = e), null != t && (Array.isArray(t) ? a.profiles = t.join(",") : a.profiles = t), null != _ && (Array.isArray(_) ? a.tags = _.join(",") : a.tags = _), r["Content-Type"] = "application/json";
                    var o = {
                        method: "GET",
                        query: a,
                        headers: r,
                        resource: "/session/loginHwId",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(o), this.authentications.default.applyToRequest(o), n.createConnectionPromise(this.connection, o)
                }, e.prototype.sessionLoginOnlineHash = function(e, t, _) {
                    var a = {},
                        r = n.extendObj({}, this.defaultHeaders);
                    if (null == e) throw new Error("Required parameter onlineHash was null or undefined when calling sessionLoginOnlineHash.");
                    if (null == t) throw new Error("Required parameter profiles was null or undefined when calling sessionLoginOnlineHash.");
                    null != e && (Array.isArray(e) ? a.onlineHash = e.join(",") : a.onlineHash = e), null != t && (Array.isArray(t) ? a.profiles = t.join(",") : a.profiles = t), null != _ && (Array.isArray(_) ? a.tags = _.join(",") : a.tags = _), r["Content-Type"] = "application/json";
                    var o = {
                        method: "GET",
                        query: a,
                        headers: r,
                        resource: "/session/loginOnlineHash",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(o), this.authentications.default.applyToRequest(o), n.createConnectionPromise(this.connection, o)
                }, e.prototype.sessionLoginUserPass = function(e, t, _, a, r, o) {
                    var i = {},
                        s = n.extendObj({}, this.defaultHeaders);
                    if (null == e) throw new Error("Required parameter domain was null or undefined when calling sessionLoginUserPass.");
                    if (null == t) throw new Error("Required parameter username was null or undefined when calling sessionLoginUserPass.");
                    if (null == _) throw new Error("Required parameter password was null or undefined when calling sessionLoginUserPass.");
                    if (null == a) throw new Error("Required parameter profiles was null or undefined when calling sessionLoginUserPass.");
                    null != e && (Array.isArray(e) ? i.domain = e.join(",") : i.domain = e), null != t && (Array.isArray(t) ? i.username = t.join(",") : i.username = t), null != _ && (Array.isArray(_) ? i.password = _.join(",") : i.password = _), null != r && (Array.isArray(r) ? i.hardwareId = r.join(",") : i.hardwareId = r), null != a && (Array.isArray(a) ? i.profiles = a.join(",") : i.profiles = a), null != o && (Array.isArray(o) ? i.tags = o.join(",") : i.tags = o), s["Content-Type"] = "application/json";
                    var c = {
                        method: "GET",
                        query: i,
                        headers: s,
                        resource: "/session/loginUserPass",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(c), this.authentications.default.applyToRequest(c), n.createConnectionPromise(this.connection, c)
                }, e.prototype.sessionSync = function() {
                    var e = n.extendObj({}, this.defaultHeaders);
                    e["Content-Type"] = "application/json";
                    var t = {
                        method: "GET",
                        query: {},
                        headers: e,
                        resource: "/session/sync",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(t), this.authentications.default.applyToRequest(t), n.createConnectionPromise(this.connection, t)
                }, e.prototype.sessionSystemVersion = function() {
                    var e = n.extendObj({}, this.defaultHeaders);
                    e["Content-Type"] = "application/json";
                    var t = {
                        method: "GET",
                        query: {},
                        headers: e,
                        resource: "/session/systemVersion",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(t), this.authentications.default.applyToRequest(t), n.createConnectionPromise(this.connection, t)
                }, e
            }();
            t.SessionApiService = y,
                function(e) {
                    e[e.apiHash = 0] = "apiHash", e[e.apiKey = 1] = "apiKey", e[e.clientIdAuth = 2] = "clientIdAuth"
                }(f = t.StatsApiApiKeys || (t.StatsApiApiKeys = {}));
            var m, w = function() {
                function e(e, t, _, a, r) {
                    this.basePath = "", this.host = "", this.defaultHeaders = {}, this.connection = null, this.authentications = {
                        default: new n.VoidAuth,
                        apiHash: new n.ApiKeyAuth("header", "apiHash"),
                        apiKey: new n.ApiKeyAuth("header", "apiId"),
                        clientIdAuth: new n.ApiKeyAuth("header", "clientId")
                    }, this.connection = e, this.basePath = _, this.host = t, r ? _ && (this.basePath = _) : a && (this.basePath = a)
                }
                return e.prototype.setApiKey = function(e, t) {
                    this.authentications[f[e]].apiKey = t
                }, e.prototype.statsEarning = function(e, t, _, a, r, o, i, s) {
                    var c = {},
                        l = n.extendObj({}, this.defaultHeaders);
                    if (null == e) throw new Error("Required parameter entityId was null or undefined when calling statsEarning.");
                    if (null == t) throw new Error("Required parameter startTime was null or undefined when calling statsEarning.");
                    if (null == _) throw new Error("Required parameter timeLevel was null or undefined when calling statsEarning.");
                    null != e && (Array.isArray(e) ? c.entityId = e.join(",") : c.entityId = e), null != a && (Array.isArray(a) ? c.userPlayedId = a.join(",") : c.userPlayedId = a), null != t && (Array.isArray(t) ? c.startTime = t.join(",") : c.startTime = t), null != r && (Array.isArray(r) ? c.endTime = r.join(",") : c.endTime = r), null != _ && (Array.isArray(_) ? c.timeLevel = _.join(",") : c.timeLevel = _), null != o && (Array.isArray(o) ? c.entityLevel = o.join(",") : c.entityLevel = o), null != i && (Array.isArray(i) ? c.groupByDate = i.join(",") : c.groupByDate = i), null != s && (Array.isArray(s) ? c.tags = s.join(",") : c.tags = s), l["Content-Type"] = "application/json";
                    var u = {
                        method: "GET",
                        query: c,
                        headers: l,
                        resource: "/stats/getEarning",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(u), this.authentications.default.applyToRequest(u), n.createConnectionPromise(this.connection, u)
                }, e.prototype.statsEarningDetails = function(e, t, _, a, r, o, i, s, c, l, u) {
                    var d = {},
                        p = n.extendObj({}, this.defaultHeaders);
                    if (null == e) throw new Error("Required parameter entityId was null or undefined when calling statsEarningDetails.");
                    if (null == t) throw new Error("Required parameter startTime was null or undefined when calling statsEarningDetails.");
                    if (null == _) throw new Error("Required parameter timeLevel was null or undefined when calling statsEarningDetails.");
                    null != e && (Array.isArray(e) ? d.entityId = e.join(",") : d.entityId = e), null != a && (Array.isArray(a) ? d.userPlayedId = a.join(",") : d.userPlayedId = a), null != t && (Array.isArray(t) ? d.startTime = t.join(",") : d.startTime = t), null != r && (Array.isArray(r) ? d.endTime = r.join(",") : d.endTime = r), null != _ && (Array.isArray(_) ? d.timeLevel = _.join(",") : d.timeLevel = _), null != o && (Array.isArray(o) ? d.marketLevel = o.join(",") : d.marketLevel = o), null != i && (Array.isArray(i) ? d.entityLevel = i.join(",") : d.entityLevel = i), null != s && (Array.isArray(s) ? d.groupByDate = s.join(",") : d.groupByDate = s), null != c && (Array.isArray(c) ? d.gameFilter = c.join(",") : d.gameFilter = c), null != l && (Array.isArray(l) ? d.playlistFilter = l.join(",") : d.playlistFilter = l), null != u && (Array.isArray(u) ? d.tags = u.join(",") : d.tags = u), p["Content-Type"] = "application/json";
                    var h = {
                        method: "GET",
                        query: d,
                        headers: p,
                        resource: "/stats/getEarningDetail",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(h), this.authentications.default.applyToRequest(h), n.createConnectionPromise(this.connection, h)
                }, e.prototype.statsPlaylists = function(e, t, _) {
                    var a = {},
                        r = n.extendObj({}, this.defaultHeaders);
                    if (null == e) throw new Error("Required parameter entityId was null or undefined when calling statsPlaylists.");
                    if (null == t) throw new Error("Required parameter startTime was null or undefined when calling statsPlaylists.");
                    null != e && (Array.isArray(e) ? a.entityId = e.join(",") : a.entityId = e), null != t && (Array.isArray(t) ? a.startTime = t.join(",") : a.startTime = t), null != _ && (Array.isArray(_) ? a.endTime = _.join(",") : a.endTime = _), r["Content-Type"] = "application/json";
                    var o = {
                        method: "GET",
                        query: a,
                        headers: r,
                        resource: "/stats/playlists",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(o), this.authentications.default.applyToRequest(o), n.createConnectionPromise(this.connection, o)
                }, e
            }();
            t.StatsApiService = w,
                function(e) {
                    e[e.apiHash = 0] = "apiHash", e[e.apiKey = 1] = "apiKey", e[e.clientIdAuth = 2] = "clientIdAuth"
                }(m = t.TicketApiApiKeys || (t.TicketApiApiKeys = {}));
            var v = function() {
                function e(e, t, _, a, r) {
                    this.basePath = "", this.host = "", this.defaultHeaders = {}, this.connection = null, this.authentications = {
                        default: new n.VoidAuth,
                        apiHash: new n.ApiKeyAuth("header", "apiHash"),
                        apiKey: new n.ApiKeyAuth("header", "apiId"),
                        clientIdAuth: new n.ApiKeyAuth("header", "clientId")
                    }, this.connection = e, this.basePath = _, this.host = t, r ? _ && (this.basePath = _) : a && (this.basePath = a)
                }
                return e.prototype.setApiKey = function(e, t) {
                    this.authentications[m[e]].apiKey = t
                }, e.prototype.requestSolveTicket = function(e) {
                    var t = {},
                        _ = n.extendObj({}, this.defaultHeaders);
                    if (null == e) throw new Error("Required parameter ticketId was null or undefined when calling requestSolveTicket.");
                    null != e && (Array.isArray(e) ? t.ticketId = e.join(",") : t.ticketId = e), _["Content-Type"] = "application/json";
                    var a = {
                        method: "GET",
                        query: t,
                        headers: _,
                        resource: "/tickets/requestSolveTicket",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(a), this.authentications.default.applyToRequest(a), n.createConnectionPromise(this.connection, a)
                }, e.prototype.ticketCancel = function(e, t, _) {
                    var a = {},
                        r = n.extendObj({}, this.defaultHeaders);
                    null != e && (Array.isArray(e) ? a.ticketIds = e.join(",") : a.ticketIds = e), null != t && (Array.isArray(t) ? a.ticketId = t.join(",") : a.ticketId = t), null != _ && (Array.isArray(_) ? a.ticketHash = _.join(",") : a.ticketHash = _), r["Content-Type"] = "application/json";
                    var o = {
                        method: "GET",
                        query: a,
                        headers: r,
                        resource: "/tickets/cancel",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(o), this.authentications.default.applyToRequest(o), n.createConnectionPromise(this.connection, o)
                }, e.prototype.ticketFind = function(e, t, _, a, r, o, i, s, c, l) {
                    var u = {},
                        d = n.extendObj({}, this.defaultHeaders);
                    if (null == e) throw new Error("Required parameter startTime was null or undefined when calling ticketFind.");
                    if (null == t) throw new Error("Required parameter n was null or undefined when calling ticketFind.");
                    if (null == _) throw new Error("Required parameter levelDetails was null or undefined when calling ticketFind.");
                    if (null == a) throw new Error("Required parameter orderBy was null or undefined when calling ticketFind.");
                    null != r && (Array.isArray(r) ? u.extTicketId = r.join(",") : u.extTicketId = r), null != e && (Array.isArray(e) ? u.startTime = e.join(",") : u.startTime = e), null != o && (Array.isArray(o) ? u.endTime = o.join(",") : u.endTime = o), null != t && (Array.isArray(t) ? u.n = t.join(",") : u.n = t), null != _ && (Array.isArray(_) ? u.levelDetails = _.join(",") : u.levelDetails = _), null != a && (Array.isArray(a) ? u.orderBy = a.join(",") : u.orderBy = a), null != i && (Array.isArray(i) ? u.status = i.join(",") : u.status = i), null != s && (Array.isArray(s) ? u.printed = s.join(",") : u.printed = s), null != c && (Array.isArray(c) ? u.isJackpotWin = c.join(",") : u.isJackpotWin = c), null != l && (Array.isArray(l) ? u.tags = l.join(",") : u.tags = l), d["Content-Type"] = "application/json";
                    var p = {
                        method: "GET",
                        query: u,
                        headers: d,
                        resource: "/tickets/find",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(p), this.authentications.default.applyToRequest(p), n.createConnectionPromise(this.connection, p)
                }, e.prototype.ticketFindByEntityId = function(e, t, _, a, r, o, i) {
                    var s = {},
                        c = n.extendObj({}, this.defaultHeaders);
                    if (null == e) throw new Error("Required parameter n was null or undefined when calling ticketFindByEntityId.");
                    null != e && (Array.isArray(e) ? s.n = e.join(",") : s.n = e), null != t && (Array.isArray(t) ? s.offset = t.join(",") : s.offset = t), null != _ && (Array.isArray(_) ? s.filter = _.join(",") : s.filter = _), null != a && (Array.isArray(a) ? s.details = a.join(",") : s.details = a), null != r && (Array.isArray(r) ? s.startTime = r.join(",") : s.startTime = r), null != o && (Array.isArray(o) ? s.endTime = o.join(",") : s.endTime = o), null != i && (Array.isArray(i) ? s.order = i.join(",") : s.order = i), c["Content-Type"] = "application/json";
                    var l = {
                        method: "GET",
                        query: s,
                        headers: c,
                        resource: "/tickets/findByEntityId",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(l), this.authentications.default.applyToRequest(l), n.createConnectionPromise(this.connection, l)
                }, e.prototype.ticketFindById = function(e, t, _, a) {
                    var r = {},
                        o = n.extendObj({}, this.defaultHeaders);
                    if (null == e) throw new Error("Required parameter n was null or undefined when calling ticketFindById.");
                    null != e && (Array.isArray(e) ? r.n = e.join(",") : r.n = e), null != t && (Array.isArray(t) ? r.ticketId = t.join(",") : r.ticketId = t), null != _ && (Array.isArray(_) ? r.filter = _.join(",") : r.filter = _), null != a && (Array.isArray(a) ? r.details = a.join(",") : r.details = a), o["Content-Type"] = "application/json";
                    var i = {
                        method: "GET",
                        query: r,
                        headers: o,
                        resource: "/tickets/findById",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(i), this.authentications.default.applyToRequest(i), n.createConnectionPromise(this.connection, i)
                }, e.prototype.ticketFindByTime = function(e, t, _, a, r) {
                    var o = {},
                        i = n.extendObj({}, this.defaultHeaders);
                    if (null == e) throw new Error("Required parameter startTime was null or undefined when calling ticketFindByTime.");
                    null != e && (Array.isArray(e) ? o.startTime = e.join(",") : o.startTime = e), null != t && (Array.isArray(t) ? o.endTime = t.join(",") : o.endTime = t), null != _ && (Array.isArray(_) ? o.n = _.join(",") : o.n = _), null != a && (Array.isArray(a) ? o.filter = a.join(",") : o.filter = a), null != r && (Array.isArray(r) ? o.details = r.join(",") : o.details = r), i["Content-Type"] = "application/json";
                    var s = {
                        method: "GET",
                        query: o,
                        headers: i,
                        resource: "/tickets/findByTime",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(s), this.authentications.default.applyToRequest(s), n.createConnectionPromise(this.connection, s)
                }, e.prototype.ticketPay = function(e, t, _) {
                    var a = {},
                        r = n.extendObj({}, this.defaultHeaders);
                    null != e && (Array.isArray(e) ? a.ticketIds = e.join(",") : a.ticketIds = e), null != t && (Array.isArray(t) ? a.ticketId = t.join(",") : a.ticketId = t), null != _ && (Array.isArray(_) ? a.ticketHash = _.join(",") : a.ticketHash = _), r["Content-Type"] = "application/json";
                    var o = {
                        method: "GET",
                        query: a,
                        headers: r,
                        resource: "/tickets/pay",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(o), this.authentications.default.applyToRequest(o), n.createConnectionPromise(this.connection, o)
                }, e.prototype.ticketPrintConfirm = function(e, t) {
                    var _ = {},
                        a = n.extendObj({}, this.defaultHeaders);
                    if (null == e) throw new Error("Required parameter ticketId was null or undefined when calling ticketPrintConfirm.");
                    null != e && (Array.isArray(e) ? _.ticketId = e.join(",") : _.ticketId = e), null != t && (Array.isArray(t) ? _.ticketStatus = t.join(",") : _.ticketStatus = t), a["Content-Type"] = "application/json";
                    var r = {
                        method: "GET",
                        query: _,
                        headers: a,
                        resource: "/tickets/printConfirm",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(r), this.authentications.default.applyToRequest(r), n.createConnectionPromise(this.connection, r)
                }, e.prototype.ticketResolve = function(e, t) {
                    var _ = {},
                        a = n.extendObj({}, this.defaultHeaders);
                    if (null == e) throw new Error("Required parameter ticketId was null or undefined when calling ticketResolve.");
                    null != e && (Array.isArray(e) ? _.ticketId = e.join(",") : _.ticketId = e), null != t && (Array.isArray(t) ? _.ticketHash = t.join(",") : _.ticketHash = t), a["Content-Type"] = "application/json";
                    var r = {
                        method: "GET",
                        query: _,
                        headers: a,
                        resource: "/tickets/resolve",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(r), this.authentications.default.applyToRequest(r), n.createConnectionPromise(this.connection, r)
                }, e.prototype.ticketSend = function(e) {
                    var t = n.extendObj({}, this.defaultHeaders);
                    if (null == e) throw new Error("Required parameter ticket was null or undefined when calling ticketSend.");
                    t["Content-Type"] = "application/json";
                    var _ = {
                        method: "POST",
                        query: {},
                        headers: t,
                        body: e,
                        resource: "/tickets/send",
                        basePath: this.basePath,
                        host: this.host
                    };
                    return this.authentications.clientIdAuth.applyToRequest(_), this.authentications.default.applyToRequest(_), n.createConnectionPromise(this.connection, _)
                }, e
            }();
            t.TicketApiService = v
        },
        o7w5: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.entries = [], e && (this.group = e.group, e.entries && e.entries.forEach((function(e) {
                        t.entries.push(new a.FootballClassificationEntry(e))
                    })))
                };
            t.ChGroupClassificationEntry = n
        },
        oEdy: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.levelId = e.levelId, this.threshold = e.threshold, this.taxPercent = e.taxPercent)
            };
            t.LevelTax = a
        },
        oGG0: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.id = e.id, this.name = e.name, this.probability = e.probability, this.k = e.k, this.value = e.value)
            };
            t.Odd = a
        },
        oHtJ: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "LlViewerProfileGameSettings", t && (_.panels = t.panels, _.identifier = t.identifier), _
                }
                return n(t, e), t
            }(_("PBHJ").ViewerProfileGameSettings);
            t.LlViewerProfileGameSettings = r,
                function(e) {
                    ! function(e) {
                        e.MARKETANDSTATS = "MARKETANDSTATS", e.MARKETS = "MARKETS", e.STATS = "STATS"
                    }(e.PanelsEnum || (e.PanelsEnum = {}))
                }(r = t.LlViewerProfileGameSettings || (t.LlViewerProfileGameSettings = {})), t.LlViewerProfileGameSettings = r,
                function(e) {
                    ! function(e) {
                        e.INTERNAL = "INTERNAL", e.LEGACY = "LEGACY"
                    }(e.IdentifierEnum || (e.IdentifierEnum = {}))
                }(r = t.LlViewerProfileGameSettings || (t.LlViewerProfileGameSettings = {})), t.LlViewerProfileGameSettings = r
        },
        oRQZ: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "SnFilter", _.generate = [], t && (_.spinType = t.spinType, _.mode = t.mode, t.generate && t.generate.forEach((function(e) {
                        _.generate.push(e)
                    }))), _
                }
                return n(t, e), t
            }(_("zE96").Filter);
            t.SnFilter = r,
                function(e) {
                    ! function(e) {
                        e.EUROPEAN = "EUROPEAN", e.AMERICAN = "AMERICAN"
                    }(e.SpinTypeEnum || (e.SpinTypeEnum = {}))
                }(r = t.SnFilter || (t.SnFilter = {})), t.SnFilter = r,
                function(e) {
                    ! function(e) {
                        e.CLASSIC = "CLASSIC", e.DELUXE = "DELUXE"
                    }(e.ModeEnum || (e.ModeEnum = {}))
                }(r = t.SnFilter || (t.SnFilter = {})), t.SnFilter = r
        },
        oe67: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.wonAmount = e.wonAmount, this.wonCount = e.wonCount, this.wonJackpot = e.wonJackpot, this.wonBonus = e.wonBonus, this.wonTaxes = e.wonTaxes)
            };
            t.ServerTicketWonData = a
        },
        ojBr: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t, _) {
                        void 0 === _ && (_ = !0);
                        var a = e.call(this, t, !1) || this;
                        return a.classType = "OddContext", a.gameOddSettings = [], t && t.gameOddSettings && t.gameOddSettings.forEach((function(e) {
                            a.gameOddSettings.push(new r.GameOddSettings(e))
                        })), a
                    }
                    return n(t, e), t
                }(_("eSR3").Context);
            t.OddContext = o
        },
        pCe8: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "EmailReportTarget", _.destinationEmailList = [], t && t.destinationEmailList && t.destinationEmailList.forEach((function(e) {
                        _.destinationEmailList.push(e)
                    })), _
                }
                return n(t, e), t
            }(_("yvpY").ReportTarget);
            t.EmailReportTarget = r
        },
        pIF0: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "DirttrackEventBlockData", _
                }
                return n(t, e), t
            }(_("AjTw").EventBlockData);
            t.DirttrackEventBlockData = r
        },
        pJiK: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "BasketEventStats", _.pointsRed = [], _.pointsBlue = [], t && (t.pointsRed && t.pointsRed.forEach((function(e) {
                        _.pointsRed.push(e)
                    })), t.pointsBlue && t.pointsBlue.forEach((function(e) {
                        _.pointsBlue.push(e)
                    })), _.rankingRed = t.rankingRed, _.rankingBlue = t.rankingBlue, _.starsRed = t.starsRed, _.starsBlue = t.starsBlue, _.fieldGoalRed = t.fieldGoalRed, _.fieldGoalBlue = t.fieldGoalBlue, _.twoPointsRed = t.twoPointsRed, _.twoPointsBlue = t.twoPointsBlue, _.winsRed = t.winsRed, _.winsBlue = t.winsBlue, _.over37_5 = t.over37_5, _.under37_5 = t.under37_5), _
                }
                return n(t, e), t
            }(_("NbOC").EventStats);
            t.BasketEventStats = r
        },
        pfDD: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "LlGameOddSettings", t && (_.payTable = t.payTable ? new r.LlPayTable(t.payTable) : null), _
                    }
                    return n(t, e), t
                }(_("ZMgZ").GameOddSettings);
            t.LlGameOddSettings = o
        },
        piXJ: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "MoveEntityReportData", _.moveEntityReportRowList = [], t && t.moveEntityReportRowList && t.moveEntityReportRowList.forEach((function(e) {
                            _.moveEntityReportRowList.push(new r.MoveEntityReportRow(e))
                        })), _
                    }
                    return n(t, e), t
                }(_("3xEZ").ReportData);
            t.MoveEntityReportData = o
        },
        pwFx: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function() {
                    function e(e, t) {
                        if (void 0 === t && (t = !0), e && (this.classType = e.classType, t && this.classType)) switch (this.classType) {
                            case "JackpotViewBonusInfo":
                                return new a.JackpotViewBonusInfo(e)
                        }
                    }
                    return e.prototype.isJackpotViewBonusInfo = function() {
                        return "JackpotViewBonusInfo" === this.classType
                    }, e
                }();
            t.JackpotViewTypeInfo = n
        },
        pxbC: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.accounts = [], e && (this.currency = e.currency, e.accounts && e.accounts.forEach((function(e) {
                        t.accounts.push(new a.SettlementReportLineData(e))
                    })), this.total = e.total ? new a.SettlementReportLineData(e.total) : null)
                };
            t.SettlementReportCurrencyLinesData = n
        },
        qISx: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "TrottingParticipant", _.jockeyForecast = [], t && (_.jockeySilkAssetId = t.jockeySilkAssetId, _.jockey = t.jockey, t.jockeyForecast && t.jockeyForecast.forEach((function(e) {
                        _.jockeyForecast.push(e)
                    })), _.sex = t.sex, _.color = t.color, _.owner = t.owner, _.speed = t.speed, _.stamina = t.stamina, _.wins = t.wins, _.place = t.place, _.timeOff = t.timeOff, _.art = t.art, _.ability = t.ability, _.star = t.star, _.handicap = t.handicap, _.handicapPrev = t.handicapPrev, _.pace = t.pace), _
                }
                return n(t, e), t
            }(_("xeXX").RaceParticipant);
            t.TrottingParticipant = r
        },
        qvpQ: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "SingleDisplay", t && (_.monitor = t.monitor, _.content = t.content ? new r.Content(t.content) : null), _
                    }
                    return n(t, e), t
                }(_("7fgt").Display);
            t.SingleDisplay = o
        },
        r7ef: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "KnGameOddSettings", t && (_.oddset = t.oddset, _.payTable = t.payTable ? new r.KnPayTable(t.payTable) : null), _
                    }
                    return n(t, e), t
                }(_("ZMgZ").GameOddSettings);
            t.KnGameOddSettings = o
        },
        r8HF: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    e && (this.unit = e.unit ? new a.Entity(e.unit) : null, this.staff = e.staff ? new a.Entity(e.staff) : null)
                };
            t.AuthResult = n
        },
        roeo: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.fromTime = e.fromTime, this.toTime = e.toTime, this.countdown = e.countdown, this.offset = e.offset, this.monday = e.monday, this.tuesday = e.tuesday, this.wednesday = e.wednesday, this.thursday = e.thursday, this.friday = e.friday, this.saturday = e.saturday, this.sunday = e.sunday)
            };
            t.DailySchedule = a
        },
        sBXh: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "KartEventBlockData", _
                }
                return n(t, e), t
            }(_("AjTw").EventBlockData);
            t.KartEventBlockData = r
        },
        sJcX: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.stats = [], e && (e.date ? this.date = new Date(e.date.toString()) : this.date = null, e.stats && e.stats.forEach((function(e) {
                        t.stats.push(new a.LottofiveStatsDrawDay(e))
                    })))
                };
            t.LottofiveStatsDay = n
        },
        sK6p: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.headToHead = [], this.lastResult = [], e && (e.headToHead && e.headToHead.forEach((function(e) {
                        t.headToHead.push(e)
                    })), this.performance = e.performance ? new a.TeamToTeamPerformance(e.performance) : null, e.lastResult && e.lastResult.forEach((function(e) {
                        t.lastResult.push(e)
                    })))
                };
            t.TeamToTeamStats = n
        },
        sZNy: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "S7EventBlockStats", _.historic = [], t && t.historic && t.historic.forEach((function(e) {
                        _.historic.push(e)
                    })), _
                }
                return n(t, e), t
            }(_("HZPa").EventBlockStats);
            t.S7EventBlockStats = r
        },
        "snP/": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "GenericTaxPolicy", t && (_.stakeTax = t.stakeTax ? new r.StakeTax(t.stakeTax) : null, _.payoutTax = t.payoutTax ? new r.PayoutTax(t.payoutTax) : null), _
                    }
                    return n(t, e), t
                }(_("PtXo").TaxPolicy);
            t.GenericTaxPolicy = o
        },
        spiY: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.draws = [], e && (this.historic = e.historic ? new a.LottofiveStatsTicketPrize(e.historic) : null, e.draws && e.draws.forEach((function(e) {
                        t.draws.push(new a.LottofiveStatsDrawDay(e))
                    })))
                };
            t.LottofiveStatEver = n
        },
        szEW: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "LkViewerProfileGameSettings", t && (_.streaming = t.streaming, _.panels = t.panels, _.identifier = t.identifier), _
                }
                return n(t, e), t
            }(_("PBHJ").ViewerProfileGameSettings);
            t.LkViewerProfileGameSettings = r,
                function(e) {
                    ! function(e) {
                        e.MARKETANDSTATS = "MARKETANDSTATS", e.MARKETS = "MARKETS", e.STATS = "STATS"
                    }(e.PanelsEnum || (e.PanelsEnum = {}))
                }(r = t.LkViewerProfileGameSettings || (t.LkViewerProfileGameSettings = {})), t.LkViewerProfileGameSettings = r,
                function(e) {
                    ! function(e) {
                        e.INTERNAL = "INTERNAL", e.LEGACY = "LEGACY"
                    }(e.IdentifierEnum || (e.IdentifierEnum = {}))
                }(r = t.LkViewerProfileGameSettings || (t.LkViewerProfileGameSettings = {})), t.LkViewerProfileGameSettings = r
        },
        "t+QT": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "MoveEntityReport", _
                }
                return n(t, e), t
            }(_("fU0W").Report);
            t.MoveEntityReport = r
        },
        t32Y: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "ChGameOddSettings", _
                }
                return n(t, e), t
            }(_("aDCO").GameFixedOddSettings);
            t.ChGameOddSettings = r
        },
        t5Jw: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "FightAssets", _
                }
                return n(t, e), t
            }(_("8xXt").Assets);
            t.FightAssets = r
        },
        tFdG: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "S7EventBlockLiveStats", _.result = [], t && t.result && t.result.forEach((function(e) {
                        _.result.push(e)
                    })), _
                }
                return n(t, e), t
            }(_("CgkD").EventBlockLiveStats);
            t.S7EventBlockLiveStats = r
        },
        tGUV: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.val = e.val)
            };
            t.TicketFindFilter = a,
                function(e) {
                    ! function(e) {
                        e.OPEN = "OPEN", e.RESOLVED = "RESOLVED", e.NOTPRINTED = "NOTPRINTED"
                    }(e.ValEnum || (e.ValEnum = {}))
                }(a = t.TicketFindFilter || (t.TicketFindFilter = {})), t.TicketFindFilter = a
        },
        tK4V: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "MotorbikeViewerProfileGameSettings", t && (_.trifectaLayout6paticipant = t.trifectaLayout6paticipant), _
                }
                return n(t, e), t
            }(_("PBHJ").ViewerProfileGameSettings);
            t.MotorbikeViewerProfileGameSettings = r,
                function(e) {
                    ! function(e) {
                        e.LEGACY = "LEGACY", e.COMPACT = "COMPACT"
                    }(e.TrifectaLayout6paticipantEnum || (e.TrifectaLayout6paticipantEnum = {}))
                }(r = t.MotorbikeViewerProfileGameSettings || (t.MotorbikeViewerProfileGameSettings = {})), t.MotorbikeViewerProfileGameSettings = r
        },
        tMmi: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "S2WAssets", _
                }
                return n(t, e), t
            }(_("8xXt").Assets);
            t.S2WAssets = r
        },
        tVmB: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    e && (this.deliveringStatus = e.deliveringStatus ? new a.DeliveringStatus(e.deliveringStatus) : null)
                };
            t.DeliveringResult = n
        },
        tb2k: function(e, t, _) {
            "use strict";

            function a(e) {
                for (var _ in e) t.hasOwnProperty(_) || (t[_] = e[_])
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), a(_("C30d")), a(_("8xXt")), a(_("r8HF")), a(_("dhxj")), a(_("CV3a")), a(_("0B+E")), a(_("mpRG")), a(_("GVlk")), a(_("pJiK")), a(_("ZLzr")), a(_("Z1tO")), a(_("55+H")), a(_("HbEo")), a(_("Rcts")), a(_("5EKT")), a(_("X30y")), a(_("4CtW")), a(_("ButT")), a(_("WKvU")), a(_("g0Eb")), a(_("7O4k")), a(_("2xuN")), a(_("lIV4")), a(_("1SOG")), a(_("Pa+v")), a(_("N/uw")), a(_("nfOZ")), a(_("zL9b")), a(_("ORoH")), a(_("EoUS")), a(_("Unox")), a(_("02bP")), a(_("nzIM")), a(_("04Qv")), a(_("wrHD")), a(_("eGI/")), a(_("t32Y")), a(_("o7w5")), a(_("Rg1d")), a(_("ZuXt")), a(_("xr+p")), a(_("Tax+")), a(_("0jIh")), a(_("23Rb")), a(_("w0+s")), a(_("6xfI")), a(_("bHOv")), a(_("S6lY")), a(_("RpYQ")), a(_("3LWi")), a(_("RKrn")), a(_("eSR3")), a(_("QCs7")), a(_("IJP8")), a(_("yj6i")), a(_("OVBH")), a(_("roeo")), a(_("tVmB")), a(_("u/tI")), a(_("MQ0g")), a(_("pIF0")), a(_("AFIj")), a(_("I2xA")), a(_("5qDJ")), a(_("CvL3")), a(_("7fgt")), a(_("I3bV")), a(_("9A4h")), a(_("jCKK")), a(_("JaeJ")), a(_("Tqdb")), a(_("BRRI")), a(_("pCe8")), a(_("1kxM")), a(_("Ibi2")), a(_("eoOp")), a(_("CWkR")), a(_("9+/D")), a(_("kf29")), a(_("JRr0")), a(_("vGN+")), a(_("AjTw")), a(_("CgkD")), a(_("HZPa")), a(_("nP5Z")), a(_("O4ZI")), a(_("Y5UR")), a(_("RUMs")), a(_("NbOC")), a(_("t5Jw")), a(_("CDyC")), a(_("k1rV")), a(_("wkcz")), a(_("RW3B")), a(_("5vCD")), a(_("8QvV")), a(_("FRGB")), a(_("mpiV")), a(_("TmWM")), a(_("LKRP")), a(_("zE96")), a(_("vint")), a(_("+DwJ")), a(_("ylfI")), a(_("yx0y")), a(_("A071")), a(_("yhki")), a(_("ZOt0")), a(_("4kNH")), a(_("VqjV")), a(_("aDCO")), a(_("ZMgZ")), a(_("CtvJ")), a(_("uU5t")), a(_("bOaR")), a(_("kM80")), a(_("uo+l")), a(_("snP/")), a(_("ljvT")), a(_("WiHH")), a(_("Y+nQ")), a(_("8jdZ")), a(_("VCcV")), a(_("8QgB")), a(_("kbO0")), a(_("9s30")), a(_("45Qj")), a(_("9B1m")), a(_("7dea")), a(_("k9p6")), a(_("Helk")), a(_("pwFx")), a(_("ZNC3")), a(_("sBXh")), a(_("zjpT")), a(_("EgGy")), a(_("dvO6")), a(_("Ht2s")), a(_("R+8f")), a(_("Qp35")), a(_("FGXa")), a(_("Za19")), a(_("r7ef")), a(_("z5qp")), a(_("E8xZ")), a(_("oEdy")), a(_("wLbp")), a(_("uGLh")), a(_("dEUd")), a(_("iexR")), a(_("w5S8")), a(_("YnJZ")), a(_("Hh0I")), a(_("y/o1")), a(_("KY/t")), a(_("dyP4")), a(_("2TKF")), a(_("szEW")), a(_("yjyU")), a(_("kyaP")), a(_("VhTC")), a(_("Qpr1")), a(_("1jO/")), a(_("5uTo")), a(_("FP6H")), a(_("1KSo")), a(_("bry7")), a(_("pfDD")), a(_("dU9G")), a(_("oHtJ")), a(_("4jhI")), a(_("6pIh")), a(_("MsMn")), a(_("55WR")), a(_("/VPC")), a(_("TDDE")), a(_("nQFw")), a(_("MlsJ")), a(_("nDVM")), a(_("RChz")), a(_("EBnV")), a(_("EL6m")), a(_("71nI")), a(_("gWkP")), a(_("thXt")), a(_("1y+E")), a(_("7fw6")), a(_("xj9q")), a(_("F6TW")), a(_("PwwK")), a(_("KF5S")), a(_("spiY")), a(_("sJcX")), a(_("PXk+")), a(_("VBna")), a(_("633v")), a(_("WeJq")), a(_("nlQ/")), a(_("uWex")), a(_("JRsZ")), a(_("X0TO")), a(_("XGEp")), a(_("9AYr")), a(_("yZwa")), a(_("mEeu")), a(_("yTnv")), a(_("mmv6")), a(_("tK4V")), a(_("t+QT")), a(_("piXJ")), a(_("bbmB")), a(_("xO3F")), a(_("+1aa")), a(_("Eyd3")), a(_("oGG0")), a(_("ojBr")), a(_("gHV8")), a(_("Kb6+")), a(_("y470")), a(_("HVQ5")), a(_("DCbq")), a(_("AvU4")), a(_("AYF8")), a(_("M1dS")), a(_("vUMd")), a(_("zro/")), a(_("UO1+")), a(_("DFK9")), a(_("zZd6")), a(_("aj8u")), a(_("tc+7")), a(_("1t07")), a(_("xeXX")), a(_("vW0J")), a(_("4Lmp")), a(_("C/Tt")), a(_("kux3")), a(_("IR12")), a(_("fU0W")), a(_("3xEZ")), a(_("nzvJ")), a(_("JazB")), a(_("gAyu")), a(_("yvpY")), a(_("K24N")), a(_("5f68")), a(_("tMmi")), a(_("AWg6")), a(_("M5TN")), a(_("nwBH")), a(_("gVXq")), a(_("8D/f")), a(_("+p5m")), a(_("NCoh")), a(_("R/ZZ")), a(_("7rHc")), a(_("+Lil")), a(_("tFdG")), a(_("sZNy")), a(_("0LOy")), a(_("ONQH")), a(_("Qf5O")), a(_("YMyr")), a(_("cWJq")), a(_("d4Eu")), a(_("hQ5S")), a(_("T7A5")), a(_("vnxy")), a(_("LyQb")), a(_("dZyX")), a(_("3piG")), a(_("oe67")), a(_("O4//")), a(_("bAm8")), a(_("SvvP")), a(_("wdWz")), a(_("pxbC")), a(_("RQvK")), a(_("EQ+K")), a(_("K/70")), a(_("6f63")), a(_("qvpQ")), a(_("cOmk")), a(_("7we5")), a(_("oRQZ")), a(_("Jr7m")), a(_("v/dR")), a(_("BgMb")), a(_("5sQN")), a(_("uocy")), a(_("7D+D")), a(_("2WT7")), a(_("Sjh9")), a(_("RzNE")), a(_("WIE0")), a(_("UNbE")), a(_("Ginh")), a(_("j99y")), a(_("KMb6")), a(_("v/Xi")), a(_("QJpE")), a(_("aLXJ")), a(_("8/Xl")), a(_("bXsM")), a(_("9Tc1")), a(_("F75B")), a(_("6Vd1")), a(_("jMQt")), a(_("JfpJ")), a(_("0nN5")), a(_("7Lqh")), a(_("PtXo")), a(_("AD6I")), a(_("sK6p")), a(_("1+xn")), a(_("3G+M")), a(_("/VyY")), a(_("Uq3Y")), a(_("blRA")), a(_("/qIM")), a(_("dOTm")), a(_("XaAp")), a(_("Dhrw")), a(_("tGUV")), a(_("Kjxo")), a(_("dvF7")), a(_("cwqg")), a(_("dcyg")), a(_("YMWy")), a(_("SQ+8")), a(_("JZHs")), a(_("UY3E")), a(_("qISx")), a(_("3Uo4")), a(_("TWor")), a(_("ICUv")), a(_("PBHJ")), a(_("HCe/")), a(_("JYIc")), a(_("fMy4")), a(_("EEXW")), a(_("ERXD")), a(_("WCjm"))
        },
        "tc+7": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "RaceEventResultData", _.finalOrder = [], t && (_.hlsURL = t.hlsURL, _.mediaId = t.mediaId, _.mediaSignature = t.mediaSignature, _.mediaExpireTime = t.mediaExpireTime, _.happenings = t.happenings, t.finalOrder && t.finalOrder.forEach((function(e) {
                        _.finalOrder.push(e)
                    }))), _
                }
                return n(t, e), t
            }(_("RUMs").EventResultData);
            t.RaceEventResultData = r
        },
        thXt: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "LottofiveEventLiveStats", _.result = [], t && t.result && t.result.forEach((function(e) {
                            _.result.push(new r.LottofiveDrawResult(e))
                        })), _
                    }
                    return n(t, e), t
                }(_("O4ZI").EventLiveStats);
            t.LottofiveEventLiveStats = o
        },
        "u/tI": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "DeliveringStatus", t && (_.num_retries = t.num_retries), _
                }
                return n(t, e), t
            }(_("JazB").ReportProcessStatus);
            t.DeliveringStatus = r
        },
        uGLh: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.maxStake = e.maxStake, this.minStake = e.minStake, this.maxPayout = e.maxPayout, this.minStakePerSystemBet = e.minStakePerSystemBet)
            };
            t.LimitSingleSettings = a
        },
        uU5t: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.jackpotSettings = [], this.wallets = [], e && (this.serverCloseMarketTime = e.serverCloseMarketTime, e.jackpotSettings && e.jackpotSettings.forEach((function(e) {
                        t.jackpotSettings.push(new a.JackpotConfigurationView(e))
                    })), this.profilesContext = e.profilesContext ? new a.Context(e.profilesContext) : null, e.wallets && e.wallets.forEach((function(e) {
                        t.wallets.push(new a.Wallet(e))
                    })))
                };
            t.GeneralSettings = n
        },
        uWex: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "MatrixDisplay", _.displays = [], t && t.displays && t.displays.forEach((function(e) {
                            _.displays.push(new r.Display(e))
                        })), _
                    }
                    return n(t, e), t
                }(_("7fgt").Display);
            t.MatrixDisplay = o
        },
        "uo+l": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function() {
                    function e(e, t) {
                        if (void 0 === t && (t = !0), e && (this.classType = e.classType, this.taxPercent = e.taxPercent, this.roundingMode = e.roundingMode, t && this.classType)) switch (this.classType) {
                            case "StakeTax":
                                return new a.StakeTax(e);
                            case "PayoutTax":
                                return new a.PayoutTax(e)
                        }
                    }
                    return e.prototype.isStakeTax = function() {
                        return "StakeTax" === this.classType
                    }, e.prototype.isPayoutTax = function() {
                        return "PayoutTax" === this.classType
                    }, e
                }();
            t.GenericTax = n,
                function(e) {
                    ! function(e) {
                        e.LOW = "LOW", e.HIGH = "HIGH", e.NEAREST = "NEAREST"
                    }(e.RoundingModeEnum || (e.RoundingModeEnum = {}))
                }(n = t.GenericTax || (t.GenericTax = {})), t.GenericTax = n
        },
        uocy: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "SpeedwayEventBlockData", _
                }
                return n(t, e), t
            }(_("AjTw").EventBlockData);
            t.SpeedwayEventBlockData = r
        },
        "v/Xi": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "SxEventBlockStats", _.historic = [], t && t.historic && t.historic.forEach((function(e) {
                        _.historic.push(e)
                    })), _
                }
                return n(t, e), t
            }(_("HZPa").EventBlockStats);
            t.SxEventBlockStats = r
        },
        "v/dR": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.number_1 = e.number_1, this.number_2 = e.number_2, this.number_3 = e.number_3, this.number_4 = e.number_4, this.number_5 = e.number_5, this.number_6 = e.number_6, this.number_7 = e.number_7, this.number_8 = e.number_8, this.number_9 = e.number_9, this.number_10 = e.number_10, this.number_11 = e.number_11, this.number_12 = e.number_12, this.number_13 = e.number_13, this.number_14 = e.number_14, this.number_15 = e.number_15, this.number_16 = e.number_16, this.number_17 = e.number_17, this.number_18 = e.number_18, this.number_19 = e.number_19, this.number_20 = e.number_20, this.number_21 = e.number_21, this.number_22 = e.number_22, this.number_23 = e.number_23, this.number_24 = e.number_24, this.number_25 = e.number_25, this.number_26 = e.number_26, this.number_27 = e.number_27, this.number_28 = e.number_28, this.number_29 = e.number_29, this.number_30 = e.number_30, this.number_31 = e.number_31, this.number_32 = e.number_32, this.number_33 = e.number_33, this.number_34 = e.number_34, this.number_35 = e.number_35, this.number_36 = e.number_36, this.number_0 = e.number_0, this.number_00 = e.number_00, this.dozen_1_12 = e.dozen_1_12, this.dozen_13_24 = e.dozen_13_24, this.dozen_25_36 = e.dozen_25_36, this.black = e.black, this.red = e.red, this.green = e.green, this.even = e.even, this.odd = e.odd, this.low = e.low, this.high = e.high, this.sector_a = e.sector_a, this.sector_b = e.sector_b, this.sector_c = e.sector_c, this.sector_d = e.sector_d, this.sector_e = e.sector_e, this.sector_f = e.sector_f, this.twins = e.twins, this.finals_0 = e.finals_0, this.finals_1 = e.finals_1, this.finals_2 = e.finals_2, this.finals_3 = e.finals_3, this.finals_4 = e.finals_4, this.finals_5 = e.finals_5, this.finals_6 = e.finals_6, this.mirror_12_21 = e.mirror_12_21, this.mirror_13_31 = e.mirror_13_31, this.mirror_23_32 = e.mirror_23_32, this.low_red = e.low_red, this.high_red = e.high_red, this.low_black = e.low_black, this.high_black = e.high_black)
            };
            t.SnPayTable = a
        },
        "vGN+": function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.events = [], e && (this.blockType = e.blockType, this.contentBlockType = e.contentBlockType, this.serverStatus = e.serverStatus, this.eBlockId = e.eBlockId, this.channelId = e.channelId, this.playlistId = e.playlistId, this.displayOption = e.displayOption, e.events && e.events.forEach((function(e) {
                        t.events.push(new a.Event(e))
                    })), e.eventTime ? this.eventTime = new Date(e.eventTime.toString()) : this.eventTime = null, e.expireTime ? this.expireTime = new Date(e.expireTime.toString()) : this.expireTime = null, this.duration = e.duration, this.data = e.data ? new a.EventBlockData(e.data) : null, this.extData = e.extData, this.stats = e.stats ? new a.EventBlockStats(e.stats) : null)
                };
            t.EventBlock = n,
                function(e) {
                    ! function(e) {
                        e.SIMPLE = "SIMPLE", e.MULTI = "MULTI"
                    }(e.BlockTypeEnum || (e.BlockTypeEnum = {}))
                }(n = t.EventBlock || (t.EventBlock = {})), t.EventBlock = n,
                function(e) {
                    ! function(e) {
                        e.PLAYLIST = "PLAYLIST", e.CHANNEL = "CHANNEL"
                    }(e.ContentBlockTypeEnum || (e.ContentBlockTypeEnum = {}))
                }(n = t.EventBlock || (t.EventBlock = {})), t.EventBlock = n,
                function(e) {
                    ! function(e) {
                        e.OPEN = "OPEN", e.SCHEDULED = "SCHEDULED", e.CANCELLED = "CANCELLED", e.RESOLVED = "RESOLVED", e.ERROR = "ERROR", e.LIVE = "LIVE"
                    }(e.ServerStatusEnum || (e.ServerStatusEnum = {}))
                }(n = t.EventBlock || (t.EventBlock = {})), t.EventBlock = n
        },
        vUMd: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "PosReportData", _.posReportRowList = [], t && t.posReportRowList && t.posReportRowList.forEach((function(e) {
                            _.posReportRowList.push(new r.PosReportRow(e))
                        })), _
                    }
                    return n(t, e), t
                }(_("3xEZ").ReportData);
            t.PosReportData = o
        },
        vW0J: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t, _) {
                    void 0 === _ && (_ = !0);
                    var a = e.call(this, t, !1) || this;
                    return a.classType = "RacesAssets", t && (a.isSimpleView = t.isSimpleView, a.ocvVideoSupported = t.ocvVideoSupported, a.ocvVoiceoverLangSupported = t.ocvVoiceoverLangSupported), a
                }
                return n(t, e), t
            }(_("8xXt").Assets);
            t.RacesAssets = r
        },
        vint: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                var t = this;
                this.history = [], e && (this.teamId = e.teamId, this.fifaCode = e.fifaCode, this.ranking = e.ranking, this.points = e.points, e.history && e.history.forEach((function(e) {
                    t.history.push(e)
                })), this.win = e.win, this.lost = e.lost, this.draw = e.draw, this.goalsScored = e.goalsScored, this.goalsConceded = e.goalsConceded, this.yellowCards = e.yellowCards)
            };
            t.FootballClassificationEntry = a
        },
        vnxy: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    e && (e.timeSend ? this.timeSend = new Date(e.timeSend.toString()) : this.timeSend = null, this.sellStaff = e.sellStaff ? new a.Entity(e.sellStaff) : null, this.calculationId = e.calculationId, this.walletId = e.walletId, this.tagsId = e.tagsId, this.details = e.details ? new a.TicketDetail(e.details) : null)
                };
            t.SellTicket = n
        },
        "w0+s": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "ChTicketEventData", _.participants = [], t && (t.participants && t.participants.forEach((function(e) {
                            _.participants.push(new r.FootballParticipant(e))
                        })), _.competitionType = t.competitionType, _.data = t.data ? new r.ChEventBlockData(t.data) : null, _.eventNdx = t.eventNdx, _.competitionSubType = t.competitionSubType), _
                    }
                    return n(t, e), t
                }(_("Dhrw").TicketEventData);
            t.ChTicketEventData = o
        },
        w5S8: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    e && (this.key = e.key, this.limits = e.limits ? new a.LimitSingleSettings(e.limits) : null)
                };
            t.LimitsPlaylistSetting = n
        },
        wLbp: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.maxStake = e.maxStake, this.minStake = e.minStake, this.maxPayout = e.maxPayout)
            };
            t.LimitSettings = a
        },
        wbEv: function(e, t, _) {
            "use strict";
            var a, n, r, o, i, s, c, l, u, d, p, h, f, y, m, w, v, x, T, O, S;
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e) {
                    e.win = "win", e.exacta = "exacta", e.trifecta = "trifecta", e.place = "place", e.show = "show", e.quinella = "quinella", e.even_odd = "even_odd", e.over_under = "over_under", e.sum_places = "sum_places", e.second_place = "second_place", e.third_place = "third_place", e.fourth_place_worse = "fourth_place_worse", e.three_any_order = "three_any_order", e.four_any_order = "four_any_order", e.system_two = "system_two", e.system_three = "system_three", e.system_four_any_order = "system_four_any_order"
                }(O = t.TrottingMarkets || (t.TrottingMarkets = {})),
                function(e) {
                    e.win_1 = "win_1", e.win_2 = "win_2", e.win_3 = "win_3", e.win_4 = "win_4", e.win_5 = "win_5", e.win_6 = "win_6", e.win_7 = "win_7", e.win_8 = "win_8", e.win_9 = "win_9", e.win_10 = "win_10", e.win_11 = "win_11", e.win_12 = "win_12", e.exacta_1_2 = "exacta_1_2", e.exacta_1_3 = "exacta_1_3", e.exacta_1_4 = "exacta_1_4", e.exacta_1_5 = "exacta_1_5", e.exacta_1_6 = "exacta_1_6", e.exacta_1_7 = "exacta_1_7", e.exacta_1_8 = "exacta_1_8", e.exacta_1_9 = "exacta_1_9", e.exacta_1_10 = "exacta_1_10", e.exacta_1_11 = "exacta_1_11", e.exacta_1_12 = "exacta_1_12", e.exacta_2_1 = "exacta_2_1", e.exacta_2_3 = "exacta_2_3", e.exacta_2_4 = "exacta_2_4", e.exacta_2_5 = "exacta_2_5", e.exacta_2_6 = "exacta_2_6", e.exacta_2_7 = "exacta_2_7", e.exacta_2_8 = "exacta_2_8", e.exacta_2_9 = "exacta_2_9", e.exacta_2_10 = "exacta_2_10", e.exacta_2_11 = "exacta_2_11", e.exacta_2_12 = "exacta_2_12", e.exacta_3_1 = "exacta_3_1", e.exacta_3_2 = "exacta_3_2", e.exacta_3_4 = "exacta_3_4", e.exacta_3_5 = "exacta_3_5", e.exacta_3_6 = "exacta_3_6", e.exacta_3_7 = "exacta_3_7", e.exacta_3_8 = "exacta_3_8", e.exacta_3_9 = "exacta_3_9", e.exacta_3_10 = "exacta_3_10", e.exacta_3_11 = "exacta_3_11", e.exacta_3_12 = "exacta_3_12", e.exacta_4_1 = "exacta_4_1", e.exacta_4_2 = "exacta_4_2", e.exacta_4_3 = "exacta_4_3", e.exacta_4_5 = "exacta_4_5", e.exacta_4_6 = "exacta_4_6", e.exacta_4_7 = "exacta_4_7", e.exacta_4_8 = "exacta_4_8", e.exacta_4_9 = "exacta_4_9", e.exacta_4_10 = "exacta_4_10", e.exacta_4_11 = "exacta_4_11", e.exacta_4_12 = "exacta_4_12", e.exacta_5_1 = "exacta_5_1", e.exacta_5_2 = "exacta_5_2", e.exacta_5_3 = "exacta_5_3", e.exacta_5_4 = "exacta_5_4", e.exacta_5_6 = "exacta_5_6", e.exacta_5_7 = "exacta_5_7", e.exacta_5_8 = "exacta_5_8", e.exacta_5_9 = "exacta_5_9", e.exacta_5_10 = "exacta_5_10", e.exacta_5_11 = "exacta_5_11", e.exacta_5_12 = "exacta_5_12", e.exacta_6_1 = "exacta_6_1", e.exacta_6_2 = "exacta_6_2", e.exacta_6_3 = "exacta_6_3", e.exacta_6_4 = "exacta_6_4", e.exacta_6_5 = "exacta_6_5", e.exacta_6_7 = "exacta_6_7", e.exacta_6_8 = "exacta_6_8", e.exacta_6_9 = "exacta_6_9", e.exacta_6_10 = "exacta_6_10", e.exacta_6_11 = "exacta_6_11", e.exacta_6_12 = "exacta_6_12", e.exacta_7_1 = "exacta_7_1", e.exacta_7_2 = "exacta_7_2", e.exacta_7_3 = "exacta_7_3", e.exacta_7_4 = "exacta_7_4", e.exacta_7_5 = "exacta_7_5", e.exacta_7_6 = "exacta_7_6", e.exacta_7_8 = "exacta_7_8", e.exacta_7_9 = "exacta_7_9", e.exacta_7_10 = "exacta_7_10", e.exacta_7_11 = "exacta_7_11", e.exacta_7_12 = "exacta_7_12", e.exacta_8_1 = "exacta_8_1", e.exacta_8_2 = "exacta_8_2", e.exacta_8_3 = "exacta_8_3", e.exacta_8_4 = "exacta_8_4", e.exacta_8_5 = "exacta_8_5", e.exacta_8_6 = "exacta_8_6", e.exacta_8_7 = "exacta_8_7", e.exacta_8_9 = "exacta_8_9", e.exacta_8_10 = "exacta_8_10", e.exacta_8_11 = "exacta_8_11", e.exacta_8_12 = "exacta_8_12", e.exacta_9_1 = "exacta_9_1", e.exacta_9_2 = "exacta_9_2", e.exacta_9_3 = "exacta_9_3", e.exacta_9_4 = "exacta_9_4", e.exacta_9_5 = "exacta_9_5", e.exacta_9_6 = "exacta_9_6", e.exacta_9_7 = "exacta_9_7", e.exacta_9_8 = "exacta_9_8", e.exacta_9_10 = "exacta_9_10", e.exacta_9_11 = "exacta_9_11", e.exacta_9_12 = "exacta_9_12", e.exacta_10_1 = "exacta_10_1", e.exacta_10_2 = "exacta_10_2", e.exacta_10_3 = "exacta_10_3", e.exacta_10_4 = "exacta_10_4", e.exacta_10_5 = "exacta_10_5", e.exacta_10_6 = "exacta_10_6", e.exacta_10_7 = "exacta_10_7", e.exacta_10_8 = "exacta_10_8", e.exacta_10_9 = "exacta_10_9", e.exacta_10_11 = "exacta_10_11", e.exacta_10_12 = "exacta_10_12", e.exacta_11_1 = "exacta_11_1", e.exacta_11_2 = "exacta_11_2", e.exacta_11_3 = "exacta_11_3", e.exacta_11_4 = "exacta_11_4", e.exacta_11_5 = "exacta_11_5", e.exacta_11_6 = "exacta_11_6", e.exacta_11_7 = "exacta_11_7", e.exacta_11_8 = "exacta_11_8", e.exacta_11_9 = "exacta_11_9", e.exacta_11_10 = "exacta_11_10", e.exacta_11_12 = "exacta_11_12", e.exacta_12_1 = "exacta_12_1", e.exacta_12_2 = "exacta_12_2", e.exacta_12_3 = "exacta_12_3", e.exacta_12_4 = "exacta_12_4", e.exacta_12_5 = "exacta_12_5", e.exacta_12_6 = "exacta_12_6", e.exacta_12_7 = "exacta_12_7", e.exacta_12_8 = "exacta_12_8", e.exacta_12_9 = "exacta_12_9", e.exacta_12_10 = "exacta_12_10", e.exacta_12_11 = "exacta_12_11", e.trifecta = "trifecta", e.place_1 = "place_1", e.place_2 = "place_2", e.place_3 = "place_3", e.place_4 = "place_4", e.place_5 = "place_5", e.place_6 = "place_6", e.place_7 = "place_7", e.place_8 = "place_8", e.place_9 = "place_9", e.place_10 = "place_10", e.place_11 = "place_11", e.place_12 = "place_12", e.show_1 = "show_1", e.show_2 = "show_2", e.show_3 = "show_3", e.show_4 = "show_4", e.show_5 = "show_5", e.show_6 = "show_6", e.show_7 = "show_7", e.show_8 = "show_8", e.show_9 = "show_9", e.show_10 = "show_10", e.show_11 = "show_11", e.show_12 = "show_12", e.quinella_1_2 = "quinella_1_2", e.quinella_1_3 = "quinella_1_3", e.quinella_1_4 = "quinella_1_4", e.quinella_1_5 = "quinella_1_5", e.quinella_1_6 = "quinella_1_6", e.quinella_1_7 = "quinella_1_7", e.quinella_1_8 = "quinella_1_8", e.quinella_1_9 = "quinella_1_9", e.quinella_1_10 = "quinella_1_10", e.quinella_1_11 = "quinella_1_11", e.quinella_1_12 = "quinella_1_12", e.quinella_2_3 = "quinella_2_3", e.quinella_2_4 = "quinella_2_4", e.quinella_2_5 = "quinella_2_5", e.quinella_2_6 = "quinella_2_6", e.quinella_2_7 = "quinella_2_7", e.quinella_2_8 = "quinella_2_8", e.quinella_2_9 = "quinella_2_9", e.quinella_2_10 = "quinella_2_10", e.quinella_2_11 = "quinella_2_11", e.quinella_2_12 = "quinella_2_12", e.quinella_3_4 = "quinella_3_4", e.quinella_3_5 = "quinella_3_5", e.quinella_3_6 = "quinella_3_6", e.quinella_3_7 = "quinella_3_7", e.quinella_3_8 = "quinella_3_8", e.quinella_3_9 = "quinella_3_9", e.quinella_3_10 = "quinella_3_10", e.quinella_3_11 = "quinella_3_11", e.quinella_3_12 = "quinella_3_12", e.quinella_4_5 = "quinella_4_5", e.quinella_4_6 = "quinella_4_6", e.quinella_4_7 = "quinella_4_7", e.quinella_4_8 = "quinella_4_8", e.quinella_4_9 = "quinella_4_9", e.quinella_4_10 = "quinella_4_10", e.quinella_4_11 = "quinella_4_11", e.quinella_4_12 = "quinella_4_12", e.quinella_5_6 = "quinella_5_6", e.quinella_5_7 = "quinella_5_7", e.quinella_5_8 = "quinella_5_8", e.quinella_5_9 = "quinella_5_9", e.quinella_5_10 = "quinella_5_10", e.quinella_5_11 = "quinella_5_11", e.quinella_5_12 = "quinella_5_12", e.quinella_6_7 = "quinella_6_7", e.quinella_6_8 = "quinella_6_8", e.quinella_6_9 = "quinella_6_9", e.quinella_6_10 = "quinella_6_10", e.quinella_6_11 = "quinella_6_11", e.quinella_6_12 = "quinella_6_12", e.quinella_7_8 = "quinella_7_8", e.quinella_7_9 = "quinella_7_9", e.quinella_7_10 = "quinella_7_10", e.quinella_7_11 = "quinella_7_11", e.quinella_7_12 = "quinella_7_12", e.quinella_8_9 = "quinella_8_9", e.quinella_8_10 = "quinella_8_10", e.quinella_8_11 = "quinella_8_11", e.quinella_8_12 = "quinella_8_12", e.quinella_9_10 = "quinella_9_10", e.quinella_9_11 = "quinella_9_11", e.quinella_9_12 = "quinella_9_12", e.quinella_10_11 = "quinella_10_11", e.quinella_10_12 = "quinella_10_12", e.quinella_11_12 = "quinella_11_12", e.even = "even", e.odd = "odd", e.over = "over", e.under = "under", e.sum_places_6 = "sum_places_6", e.sum_places_7 = "sum_places_7", e.sum_places_8 = "sum_places_8", e.sum_places_9 = "sum_places_9", e.sum_places_10 = "sum_places_10", e.sum_places_11 = "sum_places_11", e.sum_places_12 = "sum_places_12", e.sum_places_13 = "sum_places_13", e.sum_places_14 = "sum_places_14", e.sum_places_15 = "sum_places_15", e.second_1 = "second_1", e.second_2 = "second_2", e.second_3 = "second_3", e.second_4 = "second_4", e.second_5 = "second_5", e.second_6 = "second_6", e.second_7 = "second_7", e.second_8 = "second_8", e.second_9 = "second_9", e.second_10 = "second_10", e.second_11 = "second_11", e.second_12 = "second_12", e.third_1 = "third_1", e.third_2 = "third_2", e.third_3 = "third_3", e.third_4 = "third_4", e.third_5 = "third_5", e.third_6 = "third_6", e.third_7 = "third_7", e.third_8 = "third_8", e.third_9 = "third_9", e.third_10 = "third_10", e.third_11 = "third_11", e.third_12 = "third_12", e.fourth_1 = "fourth_1", e.fourth_2 = "fourth_2", e.fourth_3 = "fourth_3", e.fourth_4 = "fourth_4", e.fourth_5 = "fourth_5", e.fourth_6 = "fourth_6", e.fourth_7 = "fourth_7", e.fourth_8 = "fourth_8", e.fourth_9 = "fourth_9", e.fourth_10 = "fourth_10", e.fourth_11 = "fourth_11", e.fourth_12 = "fourth_12", e.three_any = "three_any", e.four_any = "four_any", e.system_two = "system_two", e.system_three = "system_three", e.system_four_any = "system_four_any"
                }(S = t.TrottingOdds || (t.TrottingOdds = {})), t.TrottingMarketsTemplate = ((a = {})[O.win] = ((n = {})[S.win_1] = S.win_1, n[S.win_2] = S.win_2, n[S.win_3] = S.win_3, n[S.win_4] = S.win_4, n[S.win_5] = S.win_5, n[S.win_6] = S.win_6, n[S.win_7] = S.win_7, n[S.win_8] = S.win_8, n[S.win_9] = S.win_9, n[S.win_10] = S.win_10, n[S.win_11] = S.win_11, n[S.win_12] = S.win_12, n), a[O.exacta] = ((r = {})[S.exacta_1_2] = S.exacta_1_2, r[S.exacta_1_3] = S.exacta_1_3, r[S.exacta_1_4] = S.exacta_1_4, r[S.exacta_1_5] = S.exacta_1_5, r[S.exacta_1_6] = S.exacta_1_6, r[S.exacta_1_7] = S.exacta_1_7, r[S.exacta_1_8] = S.exacta_1_8, r[S.exacta_1_9] = S.exacta_1_9, r[S.exacta_1_10] = S.exacta_1_10, r[S.exacta_1_11] = S.exacta_1_11, r[S.exacta_1_12] = S.exacta_1_12, r[S.exacta_2_1] = S.exacta_2_1, r[S.exacta_2_3] = S.exacta_2_3, r[S.exacta_2_4] = S.exacta_2_4, r[S.exacta_2_5] = S.exacta_2_5, r[S.exacta_2_6] = S.exacta_2_6, r[S.exacta_2_7] = S.exacta_2_7, r[S.exacta_2_8] = S.exacta_2_8, r[S.exacta_2_9] = S.exacta_2_9, r[S.exacta_2_10] = S.exacta_2_10, r[S.exacta_2_11] = S.exacta_2_11, r[S.exacta_2_12] = S.exacta_2_12, r[S.exacta_3_1] = S.exacta_3_1, r[S.exacta_3_2] = S.exacta_3_2, r[S.exacta_3_4] = S.exacta_3_4, r[S.exacta_3_5] = S.exacta_3_5, r[S.exacta_3_6] = S.exacta_3_6, r[S.exacta_3_7] = S.exacta_3_7, r[S.exacta_3_8] = S.exacta_3_8, r[S.exacta_3_9] = S.exacta_3_9, r[S.exacta_3_10] = S.exacta_3_10, r[S.exacta_3_11] = S.exacta_3_11, r[S.exacta_3_12] = S.exacta_3_12, r[S.exacta_4_1] = S.exacta_4_1, r[S.exacta_4_2] = S.exacta_4_2, r[S.exacta_4_3] = S.exacta_4_3, r[S.exacta_4_5] = S.exacta_4_5, r[S.exacta_4_6] = S.exacta_4_6, r[S.exacta_4_7] = S.exacta_4_7, r[S.exacta_4_8] = S.exacta_4_8, r[S.exacta_4_9] = S.exacta_4_9, r[S.exacta_4_10] = S.exacta_4_10, r[S.exacta_4_11] = S.exacta_4_11, r[S.exacta_4_12] = S.exacta_4_12, r[S.exacta_5_1] = S.exacta_5_1, r[S.exacta_5_2] = S.exacta_5_2, r[S.exacta_5_3] = S.exacta_5_3, r[S.exacta_5_4] = S.exacta_5_4, r[S.exacta_5_6] = S.exacta_5_6, r[S.exacta_5_7] = S.exacta_5_7, r[S.exacta_5_8] = S.exacta_5_8, r[S.exacta_5_9] = S.exacta_5_9, r[S.exacta_5_10] = S.exacta_5_10, r[S.exacta_5_11] = S.exacta_5_11, r[S.exacta_5_12] = S.exacta_5_12, r[S.exacta_6_1] = S.exacta_6_1, r[S.exacta_6_2] = S.exacta_6_2, r[S.exacta_6_3] = S.exacta_6_3, r[S.exacta_6_4] = S.exacta_6_4, r[S.exacta_6_5] = S.exacta_6_5, r[S.exacta_6_7] = S.exacta_6_7, r[S.exacta_6_8] = S.exacta_6_8, r[S.exacta_6_9] = S.exacta_6_9, r[S.exacta_6_10] = S.exacta_6_10, r[S.exacta_6_11] = S.exacta_6_11, r[S.exacta_6_12] = S.exacta_6_12, r[S.exacta_7_1] = S.exacta_7_1, r[S.exacta_7_2] = S.exacta_7_2, r[S.exacta_7_3] = S.exacta_7_3, r[S.exacta_7_4] = S.exacta_7_4, r[S.exacta_7_5] = S.exacta_7_5, r[S.exacta_7_6] = S.exacta_7_6, r[S.exacta_7_8] = S.exacta_7_8, r[S.exacta_7_9] = S.exacta_7_9, r[S.exacta_7_10] = S.exacta_7_10, r[S.exacta_7_11] = S.exacta_7_11, r[S.exacta_7_12] = S.exacta_7_12, r[S.exacta_8_1] = S.exacta_8_1, r[S.exacta_8_2] = S.exacta_8_2, r[S.exacta_8_3] = S.exacta_8_3, r[S.exacta_8_4] = S.exacta_8_4, r[S.exacta_8_5] = S.exacta_8_5, r[S.exacta_8_6] = S.exacta_8_6, r[S.exacta_8_7] = S.exacta_8_7, r[S.exacta_8_9] = S.exacta_8_9, r[S.exacta_8_10] = S.exacta_8_10, r[S.exacta_8_11] = S.exacta_8_11, r[S.exacta_8_12] = S.exacta_8_12, r[S.exacta_9_1] = S.exacta_9_1, r[S.exacta_9_2] = S.exacta_9_2, r[S.exacta_9_3] = S.exacta_9_3, r[S.exacta_9_4] = S.exacta_9_4, r[S.exacta_9_5] = S.exacta_9_5, r[S.exacta_9_6] = S.exacta_9_6, r[S.exacta_9_7] = S.exacta_9_7, r[S.exacta_9_8] = S.exacta_9_8, r[S.exacta_9_10] = S.exacta_9_10, r[S.exacta_9_11] = S.exacta_9_11, r[S.exacta_9_12] = S.exacta_9_12, r[S.exacta_10_1] = S.exacta_10_1, r[S.exacta_10_2] = S.exacta_10_2, r[S.exacta_10_3] = S.exacta_10_3, r[S.exacta_10_4] = S.exacta_10_4, r[S.exacta_10_5] = S.exacta_10_5, r[S.exacta_10_6] = S.exacta_10_6, r[S.exacta_10_7] = S.exacta_10_7, r[S.exacta_10_8] = S.exacta_10_8, r[S.exacta_10_9] = S.exacta_10_9, r[S.exacta_10_11] = S.exacta_10_11, r[S.exacta_10_12] = S.exacta_10_12, r[S.exacta_11_1] = S.exacta_11_1, r[S.exacta_11_2] = S.exacta_11_2, r[S.exacta_11_3] = S.exacta_11_3, r[S.exacta_11_4] = S.exacta_11_4, r[S.exacta_11_5] = S.exacta_11_5, r[S.exacta_11_6] = S.exacta_11_6, r[S.exacta_11_7] = S.exacta_11_7, r[S.exacta_11_8] = S.exacta_11_8, r[S.exacta_11_9] = S.exacta_11_9, r[S.exacta_11_10] = S.exacta_11_10, r[S.exacta_11_12] = S.exacta_11_12, r[S.exacta_12_1] = S.exacta_12_1, r[S.exacta_12_2] = S.exacta_12_2, r[S.exacta_12_3] = S.exacta_12_3, r[S.exacta_12_4] = S.exacta_12_4, r[S.exacta_12_5] = S.exacta_12_5, r[S.exacta_12_6] = S.exacta_12_6, r[S.exacta_12_7] = S.exacta_12_7, r[S.exacta_12_8] = S.exacta_12_8, r[S.exacta_12_9] = S.exacta_12_9, r[S.exacta_12_10] = S.exacta_12_10, r[S.exacta_12_11] = S.exacta_12_11, r), a[O.trifecta] = ((o = {})[S.trifecta] = S.trifecta, o), a[O.place] = ((i = {})[S.place_1] = S.place_1, i[S.place_2] = S.place_2, i[S.place_3] = S.place_3, i[S.place_4] = S.place_4, i[S.place_5] = S.place_5, i[S.place_6] = S.place_6, i[S.place_7] = S.place_7, i[S.place_8] = S.place_8, i[S.place_9] = S.place_9, i[S.place_10] = S.place_10, i[S.place_11] = S.place_11, i[S.place_12] = S.place_12, i), a[O.show] = ((s = {})[S.show_1] = S.show_1, s[S.show_2] = S.show_2, s[S.show_3] = S.show_3, s[S.show_4] = S.show_4, s[S.show_5] = S.show_5, s[S.show_6] = S.show_6, s[S.show_7] = S.show_7, s[S.show_8] = S.show_8, s[S.show_9] = S.show_9, s[S.show_10] = S.show_10, s[S.show_11] = S.show_11, s[S.show_12] = S.show_12, s), a[O.quinella] = ((c = {})[S.quinella_1_2] = S.quinella_1_2, c[S.quinella_1_3] = S.quinella_1_3, c[S.quinella_1_4] = S.quinella_1_4, c[S.quinella_1_5] = S.quinella_1_5, c[S.quinella_1_6] = S.quinella_1_6, c[S.quinella_1_7] = S.quinella_1_7, c[S.quinella_1_8] = S.quinella_1_8, c[S.quinella_1_9] = S.quinella_1_9, c[S.quinella_1_10] = S.quinella_1_10, c[S.quinella_1_11] = S.quinella_1_11, c[S.quinella_1_12] = S.quinella_1_12, c[S.quinella_2_3] = S.quinella_2_3, c[S.quinella_2_4] = S.quinella_2_4, c[S.quinella_2_5] = S.quinella_2_5, c[S.quinella_2_6] = S.quinella_2_6, c[S.quinella_2_7] = S.quinella_2_7, c[S.quinella_2_8] = S.quinella_2_8, c[S.quinella_2_9] = S.quinella_2_9, c[S.quinella_2_10] = S.quinella_2_10, c[S.quinella_2_11] = S.quinella_2_11, c[S.quinella_2_12] = S.quinella_2_12, c[S.quinella_3_4] = S.quinella_3_4, c[S.quinella_3_5] = S.quinella_3_5, c[S.quinella_3_6] = S.quinella_3_6, c[S.quinella_3_7] = S.quinella_3_7, c[S.quinella_3_8] = S.quinella_3_8, c[S.quinella_3_9] = S.quinella_3_9, c[S.quinella_3_10] = S.quinella_3_10, c[S.quinella_3_11] = S.quinella_3_11, c[S.quinella_3_12] = S.quinella_3_12, c[S.quinella_4_5] = S.quinella_4_5, c[S.quinella_4_6] = S.quinella_4_6, c[S.quinella_4_7] = S.quinella_4_7, c[S.quinella_4_8] = S.quinella_4_8, c[S.quinella_4_9] = S.quinella_4_9, c[S.quinella_4_10] = S.quinella_4_10, c[S.quinella_4_11] = S.quinella_4_11, c[S.quinella_4_12] = S.quinella_4_12, c[S.quinella_5_6] = S.quinella_5_6, c[S.quinella_5_7] = S.quinella_5_7, c[S.quinella_5_8] = S.quinella_5_8, c[S.quinella_5_9] = S.quinella_5_9, c[S.quinella_5_10] = S.quinella_5_10, c[S.quinella_5_11] = S.quinella_5_11, c[S.quinella_5_12] = S.quinella_5_12, c[S.quinella_6_7] = S.quinella_6_7, c[S.quinella_6_8] = S.quinella_6_8, c[S.quinella_6_9] = S.quinella_6_9, c[S.quinella_6_10] = S.quinella_6_10, c[S.quinella_6_11] = S.quinella_6_11, c[S.quinella_6_12] = S.quinella_6_12, c[S.quinella_7_8] = S.quinella_7_8, c[S.quinella_7_9] = S.quinella_7_9, c[S.quinella_7_10] = S.quinella_7_10, c[S.quinella_7_11] = S.quinella_7_11, c[S.quinella_7_12] = S.quinella_7_12, c[S.quinella_8_9] = S.quinella_8_9, c[S.quinella_8_10] = S.quinella_8_10, c[S.quinella_8_11] = S.quinella_8_11, c[S.quinella_8_12] = S.quinella_8_12, c[S.quinella_9_10] = S.quinella_9_10, c[S.quinella_9_11] = S.quinella_9_11, c[S.quinella_9_12] = S.quinella_9_12, c[S.quinella_10_11] = S.quinella_10_11, c[S.quinella_10_12] = S.quinella_10_12, c[S.quinella_11_12] = S.quinella_11_12, c), a[O.even_odd] = ((l = {})[S.even] = S.even, l[S.odd] = S.odd, l), a[O.over_under] = ((u = {})[S.over] = S.over, u[S.under] = S.under, u), a[O.sum_places] = ((d = {})[S.sum_places_6] = S.sum_places_6, d[S.sum_places_7] = S.sum_places_7, d[S.sum_places_8] = S.sum_places_8, d[S.sum_places_9] = S.sum_places_9, d[S.sum_places_10] = S.sum_places_10, d[S.sum_places_11] = S.sum_places_11, d[S.sum_places_12] = S.sum_places_12, d[S.sum_places_13] = S.sum_places_13, d[S.sum_places_14] = S.sum_places_14, d[S.sum_places_15] = S.sum_places_15, d), a[O.second_place] = ((p = {})[S.second_1] = S.second_1, p[S.second_2] = S.second_2, p[S.second_3] = S.second_3, p[S.second_4] = S.second_4, p[S.second_5] = S.second_5, p[S.second_6] = S.second_6, p[S.second_7] = S.second_7, p[S.second_8] = S.second_8, p[S.second_9] = S.second_9, p[S.second_10] = S.second_10, p[S.second_11] = S.second_11, p[S.second_12] = S.second_12, p), a[O.third_place] = ((h = {})[S.third_1] = S.third_1, h[S.third_2] = S.third_2, h[S.third_3] = S.third_3, h[S.third_4] = S.third_4, h[S.third_5] = S.third_5, h[S.third_6] = S.third_6, h[S.third_7] = S.third_7, h[S.third_8] = S.third_8, h[S.third_9] = S.third_9, h[S.third_10] = S.third_10, h[S.third_11] = S.third_11, h[S.third_12] = S.third_12, h), a[O.fourth_place_worse] = ((f = {})[S.fourth_1] = S.fourth_1, f[S.fourth_2] = S.fourth_2, f[S.fourth_3] = S.fourth_3, f[S.fourth_4] = S.fourth_4, f[S.fourth_5] = S.fourth_5, f[S.fourth_6] = S.fourth_6, f[S.fourth_7] = S.fourth_7, f[S.fourth_8] = S.fourth_8, f[S.fourth_9] = S.fourth_9, f[S.fourth_10] = S.fourth_10, f[S.fourth_11] = S.fourth_11, f[S.fourth_12] = S.fourth_12, f), a[O.three_any_order] = ((y = {})[S.three_any] = S.three_any, y), a[O.four_any_order] = ((m = {})[S.four_any] = S.four_any, m), a[O.system_two] = ((w = {})[S.system_two] = S.system_two, w), a[O.system_three] = ((v = {})[S.system_three] = S.system_three, v), a[O.system_four_any_order] = ((x = {})[S.system_four_any] = S.system_four_any, x), a), t.TrottingOddsTemplate = ((T = {})[S.win_1] = O.win, T[S.win_2] = O.win, T[S.win_3] = O.win, T[S.win_4] = O.win, T[S.win_5] = O.win, T[S.win_6] = O.win, T[S.win_7] = O.win, T[S.win_8] = O.win, T[S.win_9] = O.win, T[S.win_10] = O.win, T[S.win_11] = O.win, T[S.win_12] = O.win, T[S.exacta_1_2] = O.exacta, T[S.exacta_1_3] = O.exacta, T[S.exacta_1_4] = O.exacta, T[S.exacta_1_5] = O.exacta, T[S.exacta_1_6] = O.exacta, T[S.exacta_1_7] = O.exacta, T[S.exacta_1_8] = O.exacta, T[S.exacta_1_9] = O.exacta, T[S.exacta_1_10] = O.exacta, T[S.exacta_1_11] = O.exacta, T[S.exacta_1_12] = O.exacta, T[S.exacta_2_1] = O.exacta, T[S.exacta_2_3] = O.exacta, T[S.exacta_2_4] = O.exacta, T[S.exacta_2_5] = O.exacta, T[S.exacta_2_6] = O.exacta, T[S.exacta_2_7] = O.exacta, T[S.exacta_2_8] = O.exacta, T[S.exacta_2_9] = O.exacta, T[S.exacta_2_10] = O.exacta, T[S.exacta_2_11] = O.exacta, T[S.exacta_2_12] = O.exacta, T[S.exacta_3_1] = O.exacta, T[S.exacta_3_2] = O.exacta, T[S.exacta_3_4] = O.exacta, T[S.exacta_3_5] = O.exacta, T[S.exacta_3_6] = O.exacta, T[S.exacta_3_7] = O.exacta, T[S.exacta_3_8] = O.exacta, T[S.exacta_3_9] = O.exacta, T[S.exacta_3_10] = O.exacta, T[S.exacta_3_11] = O.exacta, T[S.exacta_3_12] = O.exacta, T[S.exacta_4_1] = O.exacta, T[S.exacta_4_2] = O.exacta, T[S.exacta_4_3] = O.exacta, T[S.exacta_4_5] = O.exacta, T[S.exacta_4_6] = O.exacta, T[S.exacta_4_7] = O.exacta, T[S.exacta_4_8] = O.exacta, T[S.exacta_4_9] = O.exacta, T[S.exacta_4_10] = O.exacta, T[S.exacta_4_11] = O.exacta, T[S.exacta_4_12] = O.exacta, T[S.exacta_5_1] = O.exacta, T[S.exacta_5_2] = O.exacta, T[S.exacta_5_3] = O.exacta, T[S.exacta_5_4] = O.exacta, T[S.exacta_5_6] = O.exacta, T[S.exacta_5_7] = O.exacta, T[S.exacta_5_8] = O.exacta, T[S.exacta_5_9] = O.exacta, T[S.exacta_5_10] = O.exacta, T[S.exacta_5_11] = O.exacta, T[S.exacta_5_12] = O.exacta, T[S.exacta_6_1] = O.exacta, T[S.exacta_6_2] = O.exacta, T[S.exacta_6_3] = O.exacta, T[S.exacta_6_4] = O.exacta, T[S.exacta_6_5] = O.exacta, T[S.exacta_6_7] = O.exacta, T[S.exacta_6_8] = O.exacta, T[S.exacta_6_9] = O.exacta, T[S.exacta_6_10] = O.exacta, T[S.exacta_6_11] = O.exacta, T[S.exacta_6_12] = O.exacta, T[S.exacta_7_1] = O.exacta, T[S.exacta_7_2] = O.exacta, T[S.exacta_7_3] = O.exacta, T[S.exacta_7_4] = O.exacta, T[S.exacta_7_5] = O.exacta, T[S.exacta_7_6] = O.exacta, T[S.exacta_7_8] = O.exacta, T[S.exacta_7_9] = O.exacta, T[S.exacta_7_10] = O.exacta, T[S.exacta_7_11] = O.exacta, T[S.exacta_7_12] = O.exacta, T[S.exacta_8_1] = O.exacta, T[S.exacta_8_2] = O.exacta, T[S.exacta_8_3] = O.exacta, T[S.exacta_8_4] = O.exacta, T[S.exacta_8_5] = O.exacta, T[S.exacta_8_6] = O.exacta, T[S.exacta_8_7] = O.exacta, T[S.exacta_8_9] = O.exacta, T[S.exacta_8_10] = O.exacta, T[S.exacta_8_11] = O.exacta, T[S.exacta_8_12] = O.exacta, T[S.exacta_9_1] = O.exacta, T[S.exacta_9_2] = O.exacta, T[S.exacta_9_3] = O.exacta, T[S.exacta_9_4] = O.exacta, T[S.exacta_9_5] = O.exacta, T[S.exacta_9_6] = O.exacta, T[S.exacta_9_7] = O.exacta, T[S.exacta_9_8] = O.exacta, T[S.exacta_9_10] = O.exacta, T[S.exacta_9_11] = O.exacta, T[S.exacta_9_12] = O.exacta, T[S.exacta_10_1] = O.exacta, T[S.exacta_10_2] = O.exacta, T[S.exacta_10_3] = O.exacta, T[S.exacta_10_4] = O.exacta, T[S.exacta_10_5] = O.exacta, T[S.exacta_10_6] = O.exacta, T[S.exacta_10_7] = O.exacta, T[S.exacta_10_8] = O.exacta, T[S.exacta_10_9] = O.exacta, T[S.exacta_10_11] = O.exacta, T[S.exacta_10_12] = O.exacta, T[S.exacta_11_1] = O.exacta, T[S.exacta_11_2] = O.exacta, T[S.exacta_11_3] = O.exacta, T[S.exacta_11_4] = O.exacta, T[S.exacta_11_5] = O.exacta, T[S.exacta_11_6] = O.exacta, T[S.exacta_11_7] = O.exacta, T[S.exacta_11_8] = O.exacta, T[S.exacta_11_9] = O.exacta, T[S.exacta_11_10] = O.exacta, T[S.exacta_11_12] = O.exacta, T[S.exacta_12_1] = O.exacta, T[S.exacta_12_2] = O.exacta, T[S.exacta_12_3] = O.exacta, T[S.exacta_12_4] = O.exacta, T[S.exacta_12_5] = O.exacta, T[S.exacta_12_6] = O.exacta, T[S.exacta_12_7] = O.exacta, T[S.exacta_12_8] = O.exacta, T[S.exacta_12_9] = O.exacta, T[S.exacta_12_10] = O.exacta, T[S.exacta_12_11] = O.exacta, T[S.trifecta] = O.trifecta, T[S.place_1] = O.place, T[S.place_2] = O.place, T[S.place_3] = O.place, T[S.place_4] = O.place, T[S.place_5] = O.place, T[S.place_6] = O.place, T[S.place_7] = O.place, T[S.place_8] = O.place, T[S.place_9] = O.place, T[S.place_10] = O.place, T[S.place_11] = O.place, T[S.place_12] = O.place, T[S.show_1] = O.show, T[S.show_2] = O.show, T[S.show_3] = O.show, T[S.show_4] = O.show, T[S.show_5] = O.show, T[S.show_6] = O.show, T[S.show_7] = O.show, T[S.show_8] = O.show, T[S.show_9] = O.show, T[S.show_10] = O.show, T[S.show_11] = O.show, T[S.show_12] = O.show, T[S.quinella_1_2] = O.quinella, T[S.quinella_1_3] = O.quinella, T[S.quinella_1_4] = O.quinella, T[S.quinella_1_5] = O.quinella, T[S.quinella_1_6] = O.quinella, T[S.quinella_1_7] = O.quinella, T[S.quinella_1_8] = O.quinella, T[S.quinella_1_9] = O.quinella, T[S.quinella_1_10] = O.quinella, T[S.quinella_1_11] = O.quinella, T[S.quinella_1_12] = O.quinella, T[S.quinella_2_3] = O.quinella, T[S.quinella_2_4] = O.quinella, T[S.quinella_2_5] = O.quinella, T[S.quinella_2_6] = O.quinella, T[S.quinella_2_7] = O.quinella, T[S.quinella_2_8] = O.quinella, T[S.quinella_2_9] = O.quinella, T[S.quinella_2_10] = O.quinella, T[S.quinella_2_11] = O.quinella, T[S.quinella_2_12] = O.quinella, T[S.quinella_3_4] = O.quinella, T[S.quinella_3_5] = O.quinella, T[S.quinella_3_6] = O.quinella, T[S.quinella_3_7] = O.quinella, T[S.quinella_3_8] = O.quinella, T[S.quinella_3_9] = O.quinella, T[S.quinella_3_10] = O.quinella, T[S.quinella_3_11] = O.quinella, T[S.quinella_3_12] = O.quinella, T[S.quinella_4_5] = O.quinella, T[S.quinella_4_6] = O.quinella, T[S.quinella_4_7] = O.quinella, T[S.quinella_4_8] = O.quinella, T[S.quinella_4_9] = O.quinella, T[S.quinella_4_10] = O.quinella, T[S.quinella_4_11] = O.quinella, T[S.quinella_4_12] = O.quinella, T[S.quinella_5_6] = O.quinella, T[S.quinella_5_7] = O.quinella, T[S.quinella_5_8] = O.quinella, T[S.quinella_5_9] = O.quinella, T[S.quinella_5_10] = O.quinella, T[S.quinella_5_11] = O.quinella, T[S.quinella_5_12] = O.quinella, T[S.quinella_6_7] = O.quinella, T[S.quinella_6_8] = O.quinella, T[S.quinella_6_9] = O.quinella, T[S.quinella_6_10] = O.quinella, T[S.quinella_6_11] = O.quinella, T[S.quinella_6_12] = O.quinella, T[S.quinella_7_8] = O.quinella, T[S.quinella_7_9] = O.quinella, T[S.quinella_7_10] = O.quinella, T[S.quinella_7_11] = O.quinella, T[S.quinella_7_12] = O.quinella, T[S.quinella_8_9] = O.quinella, T[S.quinella_8_10] = O.quinella, T[S.quinella_8_11] = O.quinella, T[S.quinella_8_12] = O.quinella, T[S.quinella_9_10] = O.quinella, T[S.quinella_9_11] = O.quinella, T[S.quinella_9_12] = O.quinella, T[S.quinella_10_11] = O.quinella, T[S.quinella_10_12] = O.quinella, T[S.quinella_11_12] = O.quinella, T[S.even] = O.even_odd, T[S.odd] = O.even_odd, T[S.over] = O.over_under, T[S.under] = O.over_under, T[S.sum_places_6] = O.sum_places, T[S.sum_places_7] = O.sum_places, T[S.sum_places_8] = O.sum_places, T[S.sum_places_9] = O.sum_places, T[S.sum_places_10] = O.sum_places, T[S.sum_places_11] = O.sum_places, T[S.sum_places_12] = O.sum_places, T[S.sum_places_13] = O.sum_places, T[S.sum_places_14] = O.sum_places, T[S.sum_places_15] = O.sum_places, T[S.second_1] = O.second_place, T[S.second_2] = O.second_place, T[S.second_3] = O.second_place, T[S.second_4] = O.second_place, T[S.second_5] = O.second_place, T[S.second_6] = O.second_place, T[S.second_7] = O.second_place, T[S.second_8] = O.second_place, T[S.second_9] = O.second_place, T[S.second_10] = O.second_place, T[S.second_11] = O.second_place, T[S.second_12] = O.second_place, T[S.third_1] = O.third_place, T[S.third_2] = O.third_place, T[S.third_3] = O.third_place, T[S.third_4] = O.third_place, T[S.third_5] = O.third_place, T[S.third_6] = O.third_place, T[S.third_7] = O.third_place, T[S.third_8] = O.third_place, T[S.third_9] = O.third_place, T[S.third_10] = O.third_place, T[S.third_11] = O.third_place, T[S.third_12] = O.third_place, T[S.fourth_1] = O.fourth_place_worse, T[S.fourth_2] = O.fourth_place_worse, T[S.fourth_3] = O.fourth_place_worse, T[S.fourth_4] = O.fourth_place_worse, T[S.fourth_5] = O.fourth_place_worse, T[S.fourth_6] = O.fourth_place_worse, T[S.fourth_7] = O.fourth_place_worse, T[S.fourth_8] = O.fourth_place_worse, T[S.fourth_9] = O.fourth_place_worse, T[S.fourth_10] = O.fourth_place_worse, T[S.fourth_11] = O.fourth_place_worse, T[S.fourth_12] = O.fourth_place_worse, T[S.three_any] = O.three_any_order, T[S.four_any] = O.four_any_order, T[S.system_two] = O.system_two, T[S.system_three] = O.system_three, T[S.system_four_any] = O.system_four_any_order, T)
        },
        wdWz: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "SettlementReport", _
                }
                return n(t, e), t
            }(_("fU0W").Report);
            t.SettlementReport = r
        },
        wkcz: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "FightEventResultData", _.result = [], t && (t.result && t.result.forEach((function(e) {
                            _.result.push(new r.FightVideo(e))
                        })), _.hlsURL = t.hlsURL), _
                    }
                    return n(t, e), t
                }(_("RUMs").EventResultData);
            t.FightEventResultData = o
        },
        wrHD: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "ChEventResultData", _.halfWonMarkets = [], _.refundMarkets = [], _.halfLostMarkets = [], _.videoSlots = [], t && (t.halfWonMarkets && t.halfWonMarkets.forEach((function(e) {
                            _.halfWonMarkets.push(e)
                        })), t.refundMarkets && t.refundMarkets.forEach((function(e) {
                            _.refundMarkets.push(e)
                        })), t.halfLostMarkets && t.halfLostMarkets.forEach((function(e) {
                            _.halfLostMarkets.push(e)
                        })), _.hlsURL = t.hlsURL, t.videoSlots && t.videoSlots.forEach((function(e) {
                            _.videoSlots.push(new r.FootballVideoSlot(e))
                        })), _.yellowCard = t.yellowCard, _.penalty = t.penalty, _.classifiedTeam = t.classifiedTeam), _
                    }
                    return n(t, e), t
                }(_("RUMs").EventResultData);
            t.ChEventResultData = o
        },
        xO3F: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                var t = this;
                this.issues = [], e && (this.originEntityId = e.originEntityId, this.destinationEntityId = e.destinationEntityId, e.issues && e.issues.forEach((function(e) {
                    t.issues.push(e)
                })))
            };
            t.MoveEntityReportRow = a
        },
        xeXX: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t, _) {
                    void 0 === _ && (_ = !0);
                    var a = e.call(this, t, !1) || this;
                    return a.classType = "RaceParticipant", a.forecast = [], t && (a.name = t.name, t.forecast && t.forecast.forEach((function(e) {
                        a.forecast.push(e)
                    })), a.group = t.group, a.prob = t.prob, a.risk = t.risk, a.form = t.form), a
                }
                return n(t, e), t
            }(_("Kb6+").Participant);
            t.RaceParticipant = r,
                function(e) {
                    ! function(e) {
                        e.NORMAL = "NORMAL", e.SLOW = "SLOW"
                    }(e.GroupEnum || (e.GroupEnum = {}))
                }(r = t.RaceParticipant || (t.RaceParticipant = {})), t.RaceParticipant = r
        },
        xj9q: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "LottofiveFilter", _.colourConfigurations = [], t && t.colourConfigurations && t.colourConfigurations.forEach((function(e) {
                            _.colourConfigurations.push(new r.LottofiveColourConfiguration(e))
                        })), _
                    }
                    return n(t, e), t
                }(_("zE96").Filter);
            t.LottofiveFilter = o
        },
        "xr+p": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "ChMobileProfileGameSettings", t && (_.teamNameTextType = t.teamNameTextType), _
                }
                return n(t, e), t
            }(_("X0TO").MobileProfileGameSettings);
            t.ChMobileProfileGameSettings = r,
                function(e) {
                    ! function(e) {
                        e._3LETTERS = "_3LETTERS", e.FULLTEAMNAME = "FULLTEAMNAME"
                    }(e.TeamNameTextTypeEnum || (e.TeamNameTextTypeEnum = {}))
                }(r = t.ChMobileProfileGameSettings || (t.ChMobileProfileGameSettings = {})), t.ChMobileProfileGameSettings = r
        },
        "y/o1": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "LkEventLiveStats", _.result = [], t && t.result && t.result.forEach((function(e) {
                        _.result.push(e)
                    })), _
                }
                return n(t, e), t
            }(_("O4ZI").EventLiveStats);
            t.LkEventLiveStats = r
        },
        y470: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "PayoutTax", t && (_.excludeStake = t.excludeStake, _.threshold = t.threshold, _.calcMode = t.calcMode, _.includeJackpot = t.includeJackpot), _
                }
                return n(t, e), t
            }(_("uo+l").GenericTax);
            t.PayoutTax = r,
                function(e) {
                    ! function(e) {
                        e.PROGRESSIVE = "PROGRESSIVE", e.ABSOLUTE = "ABSOLUTE"
                    }(e.CalcModeEnum || (e.CalcModeEnum = {}))
                }(r = t.PayoutTax || (t.PayoutTax = {})), t.PayoutTax = r
        },
        yTnv: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "MotorbikeGameOddSettings", _
                }
                return n(t, e), t
            }(_("aDCO").GameFixedOddSettings);
            t.MotorbikeGameOddSettings = r
        },
        yZwa: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "MotorbikeEventBlockData", _
                }
                return n(t, e), t
            }(_("AjTw").EventBlockData);
            t.MotorbikeEventBlockData = r
        },
        yhki: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "FtpReportTarget", t && (_.serverHost = t.serverHost, _.port = t.port, _.username = t.username, _.password = t.password, _.account = t.account, _.path = t.path, _.createPath = t.createPath, _.clientMode = t.clientMode, _.bufferSize = t.bufferSize, _.connectTimeout = t.connectTimeout, _.defaultTimeout = t.defaultTimeout, _.dataTimeout = t.dataTimeout, _.controlEncoding = t.controlEncoding, _.isSecure = t.isSecure, _.ftpsParams = t.ftpsParams ? new r.FtpsReportTarget(t.ftpsParams) : null), _
                    }
                    return n(t, e), t
                }(_("yvpY").ReportTarget);
            t.FtpReportTarget = o,
                function(e) {
                    ! function(e) {
                        e.ACTIVE = "ACTIVE", e.PASSIVE = "PASSIVE"
                    }(e.ClientModeEnum || (e.ClientModeEnum = {}))
                }(o = t.FtpReportTarget || (t.FtpReportTarget = {})), t.FtpReportTarget = o
        },
        yj6i: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "CustomTax", _
                }
                return n(t, e), t
            }(_("CV3a").BasicTax);
            t.CustomTax = r
        },
        yjyU: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "LlAssets", _
                }
                return n(t, e), t
            }(_("8xXt").Assets);
            t.LlAssets = r
        },
        ylfI: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = _("tb2k"),
                o = function(e) {
                    function t(t) {
                        var _ = e.call(this, t, !1) || this;
                        return _.classType = "FootballEventStats", t && (_.teamToTeam = t.teamToTeam ? new r.TeamToTeamStats(t.teamToTeam) : null), _
                    }
                    return n(t, e), t
                }(_("NbOC").EventStats);
            t.FootballEventStats = o
        },
        yvpY: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function() {
                    function e(e, t) {
                        if (void 0 === t && (t = !0), e && (this.classType = e.classType, t && this.classType)) switch (this.classType) {
                            case "FtpReportTarget":
                                return new a.FtpReportTarget(e);
                            case "EmailReportTarget":
                                return new a.EmailReportTarget(e)
                        }
                    }
                    return e.prototype.isFtpReportTarget = function() {
                        return "FtpReportTarget" === this.classType
                    }, e.prototype.isEmailReportTarget = function() {
                        return "EmailReportTarget" === this.classType
                    }, e
                }();
            t.ReportTarget = n
        },
        yx0y: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "FootballParticipant", t && (_.name = t.name, _.shortDesc = t.shortDesc, _.longDesc = t.longDesc, _.fifaCode = t.fifaCode, _.stars = t.stars), _
                }
                return n(t, e), t
            }(_("Kb6+").Participant);
            t.FootballParticipant = r
        },
        z5qp: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.numbers_10_0 = e.numbers_10_0, this.numbers_10_1 = e.numbers_10_1, this.numbers_10_2 = e.numbers_10_2, this.numbers_10_3 = e.numbers_10_3, this.numbers_10_4 = e.numbers_10_4, this.numbers_10_5 = e.numbers_10_5, this.numbers_10_6 = e.numbers_10_6, this.numbers_10_7 = e.numbers_10_7, this.numbers_10_8 = e.numbers_10_8, this.numbers_10_9 = e.numbers_10_9, this.numbers_10_10 = e.numbers_10_10, this.numbers_9_0 = e.numbers_9_0, this.numbers_9_1 = e.numbers_9_1, this.numbers_9_2 = e.numbers_9_2, this.numbers_9_3 = e.numbers_9_3, this.numbers_9_4 = e.numbers_9_4, this.numbers_9_5 = e.numbers_9_5, this.numbers_9_6 = e.numbers_9_6, this.numbers_9_7 = e.numbers_9_7, this.numbers_9_8 = e.numbers_9_8, this.numbers_9_9 = e.numbers_9_9, this.numbers_8_0 = e.numbers_8_0, this.numbers_8_1 = e.numbers_8_1, this.numbers_8_2 = e.numbers_8_2, this.numbers_8_3 = e.numbers_8_3, this.numbers_8_4 = e.numbers_8_4, this.numbers_8_5 = e.numbers_8_5, this.numbers_8_6 = e.numbers_8_6, this.numbers_8_7 = e.numbers_8_7, this.numbers_8_8 = e.numbers_8_8, this.numbers_7_0 = e.numbers_7_0, this.numbers_7_1 = e.numbers_7_1, this.numbers_7_2 = e.numbers_7_2, this.numbers_7_3 = e.numbers_7_3, this.numbers_7_4 = e.numbers_7_4, this.numbers_7_5 = e.numbers_7_5, this.numbers_7_6 = e.numbers_7_6, this.numbers_7_7 = e.numbers_7_7, this.numbers_6_0 = e.numbers_6_0, this.numbers_6_1 = e.numbers_6_1, this.numbers_6_2 = e.numbers_6_2, this.numbers_6_3 = e.numbers_6_3, this.numbers_6_4 = e.numbers_6_4, this.numbers_6_5 = e.numbers_6_5, this.numbers_6_6 = e.numbers_6_6, this.numbers_5_0 = e.numbers_5_0, this.numbers_5_1 = e.numbers_5_1, this.numbers_5_2 = e.numbers_5_2, this.numbers_5_3 = e.numbers_5_3, this.numbers_5_4 = e.numbers_5_4, this.numbers_5_5 = e.numbers_5_5, this.numbers_4_0 = e.numbers_4_0, this.numbers_4_1 = e.numbers_4_1, this.numbers_4_2 = e.numbers_4_2, this.numbers_4_3 = e.numbers_4_3, this.numbers_4_4 = e.numbers_4_4, this.numbers_3_0 = e.numbers_3_0, this.numbers_3_1 = e.numbers_3_1, this.numbers_3_2 = e.numbers_3_2, this.numbers_3_3 = e.numbers_3_3, this.numbers_2_0 = e.numbers_2_0, this.numbers_2_1 = e.numbers_2_1, this.numbers_2_2 = e.numbers_2_2, this.numbers_1_0 = e.numbers_1_0, this.numbers_1_1 = e.numbers_1_1, this.all_in_1 = e.all_in_1, this.all_in_2 = e.all_in_2, this.all_in_3 = e.all_in_3, this.all_in_4 = e.all_in_4, this.all_in_5 = e.all_in_5, this.all_in_6 = e.all_in_6, this.all_in_7 = e.all_in_7, this.all_in_8 = e.all_in_8, this.all_in_9 = e.all_in_9, this.all_in_10 = e.all_in_10, this.no_draw_1 = e.no_draw_1, this.no_draw_2 = e.no_draw_2, this.no_draw_3 = e.no_draw_3, this.no_draw_4 = e.no_draw_4, this.no_draw_5 = e.no_draw_5, this.no_draw_6 = e.no_draw_6, this.no_draw_7 = e.no_draw_7, this.no_draw_8 = e.no_draw_8, this.no_draw_9 = e.no_draw_9, this.no_draw_10 = e.no_draw_10, this.first_even = e.first_even, this.first_odd = e.first_odd, this.first_single = e.first_single, this.first_notsingle = e.first_notsingle, this.first_over_40_5 = e.first_over_40_5, this.first_under_40_5 = e.first_under_40_5, this.last_even = e.last_even, this.last_odd = e.last_odd, this.last_single = e.last_single, this.last_notsingle = e.last_notsingle, this.last_over_40_5 = e.last_over_40_5, this.last_under_40_5 = e.last_under_40_5, this.sum_first_5_over_202_5 = e.sum_first_5_over_202_5, this.sum_first_5_under_202_5 = e.sum_first_5_under_202_5, this.sum_over_810_5 = e.sum_over_810_5, this.sum_under_810_5 = e.sum_under_810_5)
            };
            t.KnPayTable = a
        },
        zE96: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function() {
                    function e(e, t) {
                        if (void 0 === t && (t = !0), e && (this.classType = e.classType, t && this.classType)) switch (this.classType) {
                            case "MotorbikeFilter":
                                return new a.MotorbikeFilter(e);
                            case "S7Filter":
                                return new a.S7Filter(e);
                            case "S2WFilter":
                                return new a.S2WFilter(e);
                            case "LlFilter":
                                return new a.LlFilter(e);
                            case "HorseFilter":
                                return new a.HorseFilter(e);
                            case "KartFilter":
                                return new a.KartFilter(e);
                            case "ChFilter":
                                return new a.ChFilter(e);
                            case "FightFilter":
                                return new a.FightFilter(e);
                            case "SxFilter":
                                return new a.SxFilter(e);
                            case "BasketFilter":
                                return new a.BasketFilter(e);
                            case "DogFilter":
                                return new a.DogFilter(e);
                            case "LkFilter":
                                return new a.LkFilter(e);
                            case "LottofiveFilter":
                                return new a.LottofiveFilter(e);
                            case "DirttrackFilter":
                                return new a.DirttrackFilter(e);
                            case "RacesFilter":
                                return new a.RacesFilter(e);
                            case "KnFilter":
                                return new a.KnFilter(e);
                            case "SnFilter":
                                return new a.SnFilter(e);
                            case "SpeedwayFilter":
                                return new a.SpeedwayFilter(e);
                            case "TrottingFilter":
                                return new a.TrottingFilter(e)
                        }
                    }
                    return e.prototype.isMotorbikeFilter = function() {
                        return "MotorbikeFilter" === this.classType
                    }, e.prototype.isS7Filter = function() {
                        return "S7Filter" === this.classType
                    }, e.prototype.isS2WFilter = function() {
                        return "S2WFilter" === this.classType
                    }, e.prototype.isLlFilter = function() {
                        return "LlFilter" === this.classType
                    }, e.prototype.isHorseFilter = function() {
                        return "HorseFilter" === this.classType
                    }, e.prototype.isKartFilter = function() {
                        return "KartFilter" === this.classType
                    }, e.prototype.isChFilter = function() {
                        return "ChFilter" === this.classType
                    }, e.prototype.isFightFilter = function() {
                        return "FightFilter" === this.classType
                    }, e.prototype.isSxFilter = function() {
                        return "SxFilter" === this.classType
                    }, e.prototype.isBasketFilter = function() {
                        return "BasketFilter" === this.classType
                    }, e.prototype.isDogFilter = function() {
                        return "DogFilter" === this.classType
                    }, e.prototype.isLkFilter = function() {
                        return "LkFilter" === this.classType
                    }, e.prototype.isLottofiveFilter = function() {
                        return "LottofiveFilter" === this.classType
                    }, e.prototype.isDirttrackFilter = function() {
                        return "DirttrackFilter" === this.classType
                    }, e.prototype.isRacesFilter = function() {
                        return "RacesFilter" === this.classType
                    }, e.prototype.isKnFilter = function() {
                        return "KnFilter" === this.classType
                    }, e.prototype.isSnFilter = function() {
                        return "SnFilter" === this.classType
                    }, e.prototype.isSpeedwayFilter = function() {
                        return "SpeedwayFilter" === this.classType
                    }, e.prototype.isTrottingFilter = function() {
                        return "TrottingFilter" === this.classType
                    }, e
                }();
            t.Filter = n
        },
        zL9b: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = _("tb2k"),
                n = function(e) {
                    var t = this;
                    this.gameSettings = [], e && (this.disablePrintingBetTickets = e.disablePrintingBetTickets, this.reprint = e.reprint, this.canPrintPayout = e.canPrintPayout, this.printPayoutConfirm = e.printPayoutConfirm, this.printTicketAndCopy = e.printTicketAndCopy, this.blockMaxPayoutTicket = e.blockMaxPayoutTicket, this.cancelConfirm = e.cancelConfirm, this.canPrintCancel = e.canPrintCancel, this.printCancelConfirm = e.printCancelConfirm, this.splitStake = e.splitStake, this.showJackpot = e.showJackpot, this.startFullScreen = e.startFullScreen, this.hideNotificationTopBar = e.hideNotificationTopBar, this.hideCreditArea = e.hideCreditArea, this.hideUsernameArea = e.hideUsernameArea, this.hideOptionMenuButton = e.hideOptionMenuButton, this.hideRules = e.hideRules, this.inactivityTimeout = e.inactivityTimeout, this.duplicateTips = e.duplicateTips, e.gameSettings && e.gameSettings.forEach((function(e) {
                        t.gameSettings.push(new a.CashierProfileGameSettings(e))
                    })))
                };
            t.CashierProfileSettings = n
        },
        zZd6: function(e, t, _) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var a = function(e) {
                e && (this.val = e.val)
            };
            t.ProfileType = a,
                function(e) {
                    ! function(e) {
                        e.VIEWER = "VIEWER", e.CASHIER = "CASHIER", e.WEB = "WEB", e.MOBILE = "MOBILE", e.SHOPADMIN = "SHOPADMIN", e.PRINTING = "PRINTING", e.MOBIPOS = "MOBIPOS"
                    }(e.ValEnum || (e.ValEnum = {}))
                }(a = t.ProfileType || (t.ProfileType = {})), t.ProfileType = a
        },
        zjpT: function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "KartFilter", _
                }
                return n(t, e), t
            }(_("4Lmp").RacesFilter);
            t.KartFilter = r
        },
        "zro/": function(e, t, _) {
            "use strict";
            var a, n = this && this.__extends || (a = function(e, t) {
                return (a = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var _ in t) t.hasOwnProperty(_) && (e[_] = t[_])
                    })(e, t)
            }, function(e, t) {
                function _() {
                    this.constructor = e
                }
                a(e, t), e.prototype = null === t ? Object.create(t) : (_.prototype = t.prototype, new _)
            });
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function(e) {
                function t(t) {
                    var _ = e.call(this, t, !1) || this;
                    return _.classType = "PosReportParams", t && (_.produces = t.produces, _.templatePath = t.templatePath), _
                }
                return n(t, e), t
            }(_("nzvJ").ReportParams);
            t.PosReportParams = r
        }
    }
]);