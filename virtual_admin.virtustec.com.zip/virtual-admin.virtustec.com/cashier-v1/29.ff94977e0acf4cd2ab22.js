(window.webpackJsonp = window.webpackJsonp || []).push([
    [29], {
        "Vhf+": function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, "Spin2WinModuleNgFactory", (function() {
                return Ue
            }));
            var l = n("CcnG"),
                i = function() {},
                s = n("pMnS"),
                o = n("qIYQ"),
                r = n("2z2z"),
                u = n("mYlp"),
                a = n("E6sH"),
                c = n("1UiX"),
                d = n("cS+c"),
                p = n("Md+g"),
                b = n("eZM8"),
                h = n("fHz3"),
                g = n("iGSx"),
                m = n("l+fh"),
                f = n("XAsR"),
                S = n("M3um"),
                k = n("5EE+"),
                _ = n("Ip0R"),
                y = n("CrY/"),
                v = function() {
                    function e() {
                        this.isSelected = !1, this.isBetTable = !1, this.SnOdds = y.SnOdds, this.isInteger = !1
                    }
                    return e.prototype.ngOnInit = function() {
                        this.isInteger = Number.isInteger(+this.title), this.isBetTable && Number.isInteger(+this.title) && (this.color = y.SessionController.gameManager.getSnGame().colors[this.title].toLowerCase())
                    }, e
                }(),
                M = [
                    [".spin2win-odd[_ngcontent-%COMP%]{position:relative;display:flex;height:100%;padding:21px 0;align-items:center;justify-content:center;font-size:22px;font-weight:700;cursor:pointer;border-radius:2px}.spin2win-odd__bet-table[_ngcontent-%COMP%]{padding:0;font-size:36px}.spin2win-odd__colours-market[_ngcontent-%COMP%]{text-transform:capitalize}"]
                ],
                O = l.Gb({
                    encapsulation: 0,
                    styles: M,
                    data: {}
                });

            function C(e) {
                return l.ec(0, [(e()(), l.Ib(0, 0, null, null, 1, null, null, null, null, null, null, null)), (e()(), l.cc(1, null, ["", " "]))], null, (function(e, t) {
                    e(t, 1, 0, t.component.title)
                }))
            }

            function x(e) {
                return l.ec(0, [(e()(), l.Ib(0, 0, null, null, 2, null, null, null, null, null, null, null)), (e()(), l.cc(1, null, ["", " "])), l.Wb(131072, k.r, [k.k, l.i])], null, (function(e, t) {
                    var n = t.component;
                    e(t, 1, 0, l.dc(t, 1, 0, l.Ub(t, 2).transform(n.title, "SN")))
                }))
            }

            function I(e) {
                return l.ec(2, [(e()(), l.Ib(0, 0, null, null, 7, "div", [
                    ["class", "spin2win-odd"]
                ], null, null, null, null, null)), l.Zb(512, null, _.x, _.y, [l.A, l.B, l.o, l.P]), l.Hb(2, 278528, null, 0, _.k, [_.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), l.Xb(3, {
                    "spin2win-odd__market spin2win-odd__colours-market": 0,
                    "spin2win-odd__market--selected": 1,
                    "spin2win-odd__bet-table": 2,
                    "spin2win-odd--red": 3,
                    "spin2win-odd--black": 4,
                    "spin2win-odd--green": 5,
                    "spin2win-odd--red--selected": 6,
                    "spin2win-odd--black--selected": 7,
                    "spin2win-odd--green--selected": 8
                }), (e()(), l.xb(16777216, null, null, 1, null, C)), l.Hb(5, 16384, null, 0, _.m, [l.eb, l.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (e()(), l.xb(16777216, null, null, 1, null, x)), l.Hb(7, 16384, null, 0, _.m, [l.eb, l.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(e, t) {
                    var n = t.component,
                        l = e(t, 3, 0, !n.isBetTable, n.isSelected && !n.isBetTable, n.isBetTable, n.title === n.SnOdds.Red && !n.isBetTable, n.title === n.SnOdds.Black && !n.isBetTable, n.title === n.SnOdds.Green && !n.isBetTable, n.title === n.SnOdds.Red && n.isSelected || n.isBetTable && n.color === n.SnOdds.Red.toLowerCase(), n.title === n.SnOdds.Black && n.isSelected || n.isBetTable && n.color === n.SnOdds.Black.toLowerCase(), n.title === n.SnOdds.Green && n.isSelected);
                    e(t, 2, 0, "spin2win-odd", l), e(t, 5, 0, n.isInteger), e(t, 7, 0, !n.isInteger)
                }), null)
            }
            l.Eb("grc-spin2win-odd", v, (function(e) {
                return l.ec(0, [(e()(), l.Ib(0, 0, null, null, 1, "grc-spin2win-odd", [], null, null, null, I, O)), l.Hb(1, 114688, null, 0, v, [], null, null)], (function(e, t) {
                    e(t, 1, 0)
                }), null)
            }), {
                title: "title",
                isSelected: "isSelected",
                isBetTable: "isBetTable"
            }, {}, []);
            var w = function() {
                    function e() {
                        this.marketsGroupsOdds = [], this.selectedOddsIds = [], this.selectedOddsIdsChange = new l.q, this.marketGroup = [], this.SnMarkets = y.SnMarkets
                    }
                    return e.prototype.ngOnInit = function() {}, e.prototype.onSelected = function(e) {
                        if (this.isSelected(e)) {
                            var t = this.selectedOddsIds.indexOf(e);
                            this.selectedOddsIds.splice(t, 1)
                        } else this.selectedOddsIds.push(e);
                        this.selectedOddsIdsChange.emit(this.selectedOddsIds)
                    }, e.prototype.isSelected = function(e) {
                        return this.selectedOddsIds.includes(e)
                    }, e
                }(),
                H = [
                    ["[_nghost-%COMP%] > .grid[_ngcontent-%COMP%]{padding:30px 48px 0}.markets-group[_ngcontent-%COMP%]{font-size:26px;font-weight:700;text-transform:capitalize}.markets-group__title[_ngcontent-%COMP%]{margin-bottom:19px}.markets-group__odds[_ngcontent-%COMP%]{margin:0 -10px}.markets-group__odds[_ngcontent-%COMP%] > .col[_ngcontent-%COMP%]{padding:0 10px}.markets-group--bottom-separation[_ngcontent-%COMP%]{margin-bottom:40px}.markets-group--low-high-separation[_ngcontent-%COMP%]{margin-bottom:20px}"]
                ],
                T = l.Gb({
                    encapsulation: 0,
                    styles: H,
                    data: {}
                });

            function B(e) {
                return l.ec(0, [(e()(), l.Ib(0, 0, null, null, 4, "grc-spin2win-odd", [
                    ["class", "col"]
                ], [
                    [8, "id", 0]
                ], [
                    [null, "click"]
                ], (function(e, t, n) {
                    var l = !0,
                        i = e.component;
                    "click" === t && (l = !1 !== i.onSelected(e.context.$implicit.id) && l);
                    return l
                }), I, O)), l.Zb(512, null, _.x, _.y, [l.A, l.B, l.o, l.P]), l.Hb(2, 278528, null, 0, _.k, [_.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), l.Xb(3, {
                    "markets-group--low-high-separation": 0
                }), l.Hb(4, 114688, null, 0, v, [], {
                    title: [0, "title"],
                    isSelected: [1, "isSelected"],
                    isBetTable: [2, "isBetTable"]
                }, null)], (function(e, t) {
                    var n = t.component,
                        i = e(t, 3, 0, n.title === n.SnMarkets.Low_High_Color && (0 === t.context.index || 1 === t.context.index));
                    e(t, 2, 0, "col", i);
                    e(t, 4, 0, l.Mb(1, "", t.context.$implicit.id, ""), n.isSelected(t.context.$implicit.id), !1)
                }), (function(e, t) {
                    e(t, 0, 0, l.Mb(1, "", t.context.$implicit.id, ""))
                }))
            }

            function P(e) {
                return l.ec(2, [(e()(), l.Ib(0, 0, null, null, 8, "div", [
                    ["class", "grid grid-column markets-group"]
                ], null, null, null, null, null)), (e()(), l.Ib(1, 0, null, null, 2, "div", [
                    ["class", "markets-group__title"]
                ], null, null, null, null, null)), (e()(), l.cc(2, null, ["", ""])), l.Wb(131072, k.q, [k.k, l.i]), (e()(), l.Ib(4, 0, null, null, 4, "div", [
                    ["class", "grid markets-group__odds markets-group--bottom-separation"]
                ], null, null, null, null, null)), l.Zb(512, null, _.x, _.y, [l.A, l.B, l.o, l.P]), l.Hb(6, 278528, null, 0, _.k, [_.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), (e()(), l.xb(16777216, null, null, 1, null, B)), l.Hb(8, 278528, null, 0, _.l, [l.eb, l.Z, l.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(e, t) {
                    var n = t.component;
                    e(t, 6, 0, "grid markets-group__odds markets-group--bottom-separation", n.title === n.SnMarkets.Low_High_Color ? "grid-2" : "grid-" + n.marketsGroupsOdds.length), e(t, 8, 0, n.marketsGroupsOdds)
                }), (function(e, t) {
                    var n = t.component;
                    e(t, 2, 0, l.dc(t, 2, 0, l.Ub(t, 3).transform(n.title)))
                }))
            }
            l.Eb("grc-markets-group", w, (function(e) {
                return l.ec(0, [(e()(), l.Ib(0, 0, null, null, 1, "grc-markets-group", [], null, null, null, P, T)), l.Hb(1, 114688, null, 0, w, [], null, null)], (function(e, t) {
                    e(t, 1, 0)
                }), null)
            }), {
                event: "event",
                title: "title",
                marketsGroupsOdds: "marketsGroupsOdds",
                selectedOddsIds: "selectedOddsIds"
            }, {
                selectedOddsIdsChange: "selectedOddsIdsChange"
            }, []);
            var N = n("1A4t"),
                D = function() {
                    function e(e, t, n) {
                        this.elementRef = e, this.cd = t, this.scaleService = n, this.selectedNumbers = [], this.selectedNumbersChange = new l.q, this.numbers = [];
                        for (var i = 1; i <= 36; i += 1) this.numbers.push(i)
                    }
                    return e.prototype.onResize = function() {
                        this.recalcCircleDiameter()
                    }, e.prototype.ngOnInit = function() {}, e.prototype.ngAfterViewInit = function() {
                        this.recalcCircleDiameter()
                    }, e.prototype.ngOnDestroy = function() {
                        clearTimeout(this.calcSetTimeout)
                    }, e.prototype.onSelectNumber = function(e) {
                        if (this.isNumberSelected(e)) {
                            var t = this.selectedNumbers.indexOf(e);
                            this.selectedNumbers.splice(t, 1)
                        } else this.selectedNumbers.push(e);
                        this.selectedNumbersChange.emit(this.selectedNumbers)
                    }, e.prototype.isNumberSelected = function(e) {
                        return this.selectedNumbers.includes(e)
                    }, e.prototype.recalcCircleDiameter = function() {
                        var e = this;
                        this.calcSetTimeout = setTimeout((function() {
                            var t = e.elementRef.nativeElement.querySelector(".bet-table-spin2win__number").getBoundingClientRect();
                            e.circleDiameter = Math.min(e.scaleService.getUnscaledHeight(t.height), e.scaleService.getUnscaledWidth(t.width)) - 10, e.cd.detectChanges()
                        }), 0)
                    }, e
                }(),
                R = [
                    ["[_nghost-%COMP%] > .grid[_ngcontent-%COMP%]{height:100%}[_nghost-%COMP%] > .grid[_ngcontent-%COMP%] > .col[_ngcontent-%COMP%]{margin:-2px}[_nghost-%COMP%] > .grid[_ngcontent-%COMP%] > .col[_ngcontent-%COMP%] > .col[_ngcontent-%COMP%]{padding:2px}.bet-table-spin2win[_ngcontent-%COMP%]{font-size:36px;font-weight:700;text-transform:capitalize}.bet-table-spin2win__title[_ngcontent-%COMP%]{margin-bottom:25px}.bet-table-spin2win__number[_ngcontent-%COMP%]{position:relative}.bet-table-spin2win__selector[_ngcontent-%COMP%]{position:absolute;top:50%;left:50%;z-index:1;cursor:pointer;border-radius:100%;transform:translateX(-50%) translateY(-50%)}"]
                ],
                E = l.Gb({
                    encapsulation: 0,
                    styles: R,
                    data: {}
                });

            function G(e) {
                return l.ec(0, [(e()(), l.Ib(0, 0, null, null, 0, "div", [
                    ["class", "bet-table-spin2win__selector"]
                ], [
                    [4, "height", "px"],
                    [4, "width", "px"]
                ], [
                    [null, "click"]
                ], (function(e, t, n) {
                    var l = !0,
                        i = e.component;
                    "click" === t && (l = !1 !== i.onSelectNumber(e.parent.context.$implicit) && l);
                    return l
                }), null, null))], null, (function(e, t) {
                    var n = t.component;
                    e(t, 0, 0, n.circleDiameter, n.circleDiameter)
                }))
            }

            function F(e) {
                return l.ec(0, [(e()(), l.Ib(0, 0, null, null, 4, "div", [
                    ["class", "col bet-table-spin2win__number"]
                ], null, null, null, null, null)), (e()(), l.Ib(1, 0, null, null, 1, "grc-spin2win-odd", [], null, [
                    [null, "click"]
                ], (function(e, t, n) {
                    var l = !0,
                        i = e.component;
                    "click" === t && (l = !1 !== i.onSelectNumber(e.context.$implicit) && l);
                    return l
                }), I, O)), l.Hb(2, 114688, [
                    ["betTableOdd", 4]
                ], 0, v, [], {
                    title: [0, "title"],
                    isBetTable: [1, "isBetTable"]
                }, null), (e()(), l.xb(16777216, null, null, 1, null, G)), l.Hb(4, 16384, null, 0, _.m, [l.eb, l.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(e, t) {
                    var n = t.component;
                    e(t, 2, 0, t.context.$implicit, !0), e(t, 4, 0, n.isNumberSelected(t.context.$implicit))
                }), null)
            }

            function z(e) {
                return l.ec(2, [(e()(), l.Ib(0, 0, null, null, 6, "div", [
                    ["class", "grid grid-column bet-table-spin2win"]
                ], null, null, null, null, null)), (e()(), l.Ib(1, 0, null, null, 2, "div", [
                    ["class", "bet-table-spin2win__title"]
                ], null, null, null, null, null)), (e()(), l.cc(2, null, ["", ""])), l.Wb(131072, k.q, [k.k, l.i]), (e()(), l.Ib(4, 0, null, null, 2, "div", [
                    ["class", "col grid grid-6"]
                ], null, null, null, null, null)), (e()(), l.xb(16777216, null, null, 1, null, F)), l.Hb(6, 278528, null, 0, _.l, [l.eb, l.Z, l.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(e, t) {
                    e(t, 6, 0, t.component.numbers)
                }), (function(e, t) {
                    e(t, 2, 0, l.dc(t, 2, 0, l.Ub(t, 3).transform("exact_number")))
                }))
            }
            l.Eb("grc-spin2win-bet-table", D, (function(e) {
                return l.ec(0, [(e()(), l.Ib(0, 0, null, null, 1, "grc-spin2win-bet-table", [], null, [
                    ["window", "resize"]
                ], (function(e, t, n) {
                    var i = !0;
                    "window:resize" === t && (i = !1 !== l.Ub(e, 1).onResize() && i);
                    return i
                }), z, E)), l.Hb(1, 4440064, null, 0, D, [l.o, l.i, N.a], null, null)], (function(e, t) {
                    e(t, 1, 0)
                }), null)
            }), {
                selectedNumbers: "selectedNumbers"
            }, {
                selectedNumbersChange: "selectedNumbersChange"
            }, []);
            var A, L = n("mv7g"),
                U = n("+69r"),
                W = n("GhKF"),
                q = n("3cbp"),
                $ = n("VYBt"),
                j = n("5y7H"),
                V = n("Poww"),
                Z = n("D3N7"),
                X = n("n3kJ"),
                K = n("K9Ia"),
                Y = n("0/uQ"),
                Q = n("67Y/"),
                J = n("ijKR"),
                ee = n("31BE"),
                te = n("ftDe"),
                ne = (A = function(e, t) {
                    return (A = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(e, t) {
                            e.__proto__ = t
                        } || function(e, t) {
                            for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                        })(e, t)
                }, function(e, t) {
                    function n() {
                        this.constructor = e
                    }
                    A(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                }),
                le = function(e) {
                    function t() {
                        var t = null !== e && e.apply(this, arguments) || this;
                        return t.isDeluxe = !1, t.selected = 0, t.spin2winMarketsTitles = ["main", "sectors_final", "extra"], t.spin2winOdds = [
                            [{
                                odd: y.SnOdds.Number_1,
                                oddNameToDisplay: "exact_number"
                            }, {
                                odd: y.SnOdds.Red,
                                oddNameToDisplay: "redblack"
                            }, {
                                odd: y.SnOdds.Green
                            }, {
                                odd: y.SnOdds.Dozen_1_12,
                                oddNameToDisplay: y.SnMarkets.Dozens
                            }, {
                                odd: y.SnOdds.Even,
                                oddNameToDisplay: y.SnMarkets.Even_Odd
                            }],
                            [{
                                odd: y.SnOdds.Sector_A,
                                oddNameToDisplay: y.SnMarkets.Sectors
                            }, {
                                odd: y.SnOdds.Finals_0,
                                oddNameToDisplay: "final_0"
                            }, {
                                odd: y.SnOdds.Finals_6,
                                oddNameToDisplay: "finals_1-6"
                            }],
                            [{
                                odd: y.SnOdds.Mirror_12_21,
                                oddNameToDisplay: y.SnMarkets.Mirror
                            }, {
                                odd: y.SnOdds.Twins,
                                oddNameToDisplay: y.SnMarkets.Twins
                            }, {
                                odd: y.SnOdds.Low_Red,
                                oddNameToDisplay: y.SnMarkets.Low_High_Color
                            }]
                        ], t.columnsPerRow = [0], t
                    }
                    return ne(t, e), t.prototype.ngOnInit = function() {
                        this.isDeluxe && this.spin2winOdds[0].push({
                            odd: y.SnOdds.Low,
                            oddNameToDisplay: y.SnMarkets.Low_High
                        }), this.columnsPerRow = [this.isDeluxe ? this.spin2winOdds.length : 1], this.setPaytableInfo(this.spin2winMarketsTitles, this.getSpin2WinOdds())
                    }, t.prototype.getSpin2WinOdds = function() {
                        return this.isDeluxe ? this.spin2winOdds : this.spin2winOdds.slice(0, 1)
                    }, t
                }(te.a),
                ie = function() {
                    var e = function(t, n) {
                        return (e = Object.setPrototypeOf || {
                                __proto__: []
                            }
                            instanceof Array && function(e, t) {
                                e.__proto__ = t
                            } || function(e, t) {
                                for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                            })(t, n)
                    };
                    return function(t, n) {
                        function l() {
                            this.constructor = t
                        }
                        e(t, n), t.prototype = null === n ? Object.create(n) : (l.prototype = n.prototype, new l)
                    }
                }(),
                se = function(e) {
                    function t(t, n) {
                        var l = e.call(this, t) || this;
                        return l.shopAdminService = n, l.numbersSelected = [], l.isDeluxe = !1, l.selectedOddsIds = [], l.SnOdds = y.SnOdds, l.marketsName = [{
                            id: "MAIN",
                            value: l.i18NService.getMarketGroupTag("main")
                        }, {
                            id: "SECTORS/FINAL",
                            value: l.i18NService.getMarketGroupTag("sectors_final")
                        }, {
                            id: "EXTRA",
                            value: l.i18NService.getMarketGroupTag("extra")
                        }], l.selectedOdds = [], l.tabSelected = l.marketsName[0].id, l.quickMultiplierTabSelected = "quick-pick", l.multiplier = new K.a, l.maxMultiplier = 0, l.deluxeMarketsGroups = [
                            [y.SnMarkets.Colors, y.SnMarkets.Dozens, y.SnMarkets.Even_Odd, y.SnMarkets.Low_High],
                            [y.SnMarkets.Sectors, y.SnMarkets.Finals],
                            [y.SnMarkets.Mirror, y.SnMarkets.Twins, y.SnMarkets.Low_High_Color]
                        ], l.mainMarketsGroups = [
                            [y.SnMarkets.Colors, y.SnMarkets.Dozens, y.SnMarkets.Even_Odd]
                        ], l.odds = [], l
                    }
                    return ie(t, e), t.prototype.onTabChange = function(e) {
                        this.tabSelected = e, this.selectedOdds = this.isDeluxe ? this.odds[this.marketsName.findIndex((function(t) {
                            return t.id === e
                        }))] : this.odds[0], this.cd.markForCheck()
                    }, t.prototype.createRandomArray = function(e) {
                        var t = this,
                            n = [];
                        (n = Array.from({
                            length: e
                        }, (function() {
                            return t.generateRandomValue()
                        }))).forEach((function(e, l) {
                            n.filter((function(t) {
                                return t === e
                            })).length >= 2 && (n[l] = t.getRandomValue(n))
                        })), this.numbersSelected = n, this.updateBetslipConfiguration()
                    }, t.prototype.onSelectedNumbers = function(e) {
                        this.numbersSelected = e, this.updateBetslipConfiguration()
                    }, t.prototype.onSelectedOddsIds = function(e) {
                        this.selectedOddsIds = e, this.updateBetslipConfiguration()
                    }, t.prototype.getLastHistory = function() {
                        var e = this;
                        this.historySubscription && this.historySubscription.unsubscribe(), this.historySubscription = Object(Y.a)(this.coreService.getEventControllerByPlaylistId(this.playlist.id, y.coreModel.Playlist.ModeEnum.SCHEDULED).historyManager.getLastHistory(12)).subscribe((function(t) {
                            void 0 === t && (t = []), e.eventBlocksHistory = t, e.cd.detectChanges()
                        }))
                    }, t.prototype.onTabQuickMultiplierChange = function(e) {
                        this.quickMultiplierTabSelected = e, this.cd.markForCheck()
                    }, t.prototype.onMultiplierSelected = function(e) {
                        this.multiplier.next(e), "multiplier" === this.quickMultiplierTabSelected && document.getElementsByClassName("tab-header--multiplier")[0].click(), this.betslipService.setMultiplier(e), this.cd.markForCheck()
                    }, t.prototype.onMultiplierValidation = function(e) {
                        e && this.notificationsService.warning("" + this.i18NService.get("ch_lower_multiplier"))
                    }, t.prototype.getMaxMultiplier = function() {
                        return this.betslipService.getMaxMultiplier()
                    }, t.prototype.onBeforeInit = function() {
                        var t = this;
                        return e.prototype.onBeforeInit.call(this).pipe(Object(Q.a)((function() {
                            t.event = t.eventBlock.events[0], t.baseService.activateGame(!0), t.onClearBetslipUserSelections(), t.setModeAndSpinType(), t.setDefaultTab(), t.init()
                        })))
                    }, t.prototype.getEBControllerConfigItem = function() {
                        return {
                            windowOpenSize: 19
                        }
                    }, t.prototype.configureBetslip = function() {
                        var e = this;
                        this.betslipService.setConfiguration({
                            hasMultiplier: !0,
                            betMode: y.BetModeEnum.SINGLEBETMODE,
                            preStake: function() {
                                return e.createBets()
                            },
                            prefixMarket: function(t) {
                                return e.getBetslipTitle(t)
                            }
                        })
                    }, t.prototype.configureHeader = function() {
                        var e = this;
                        this.baseService.setHeaderState({
                            gameName: this.playlist.descriptionTag,
                            eventName: "#" + this.getEventId(),
                            countdownEventBlockController: this.eventBlockController,
                            playList: this.playlist,
                            buttons: [{
                                title: "ch_pay_table",
                                callback: function() {
                                    return e.openPaytableComponent()
                                },
                                shortcuts: [X.a.PayTable]
                            }, {
                                title: "ch_results_history",
                                callback: function() {
                                    return e.shopAdminService.openResultHistory(e.playlist)
                                },
                                shortcuts: [X.a.ResultHistory],
                                disabled: !this.isResultsHistoryButtonVisible()
                            }]
                        })
                    }, t.prototype.onEventBlockControllerReadyToStart = function(e) {
                        this.event = e.events[0], this.getLastHistory()
                    }, t.prototype.onEventBlockControllerClosedMarkets = function(e) {
                        this.onClearBetslipUserSelections(), this.setDefaultTab()
                    }, t.prototype.configureShortcuts = function() {
                        var e = this;
                        this.subscriptions.add(this.coreService.onShortcut(X.a.PreviousMarket).subscribe((function() {
                            e.previousMarket()
                        }))), this.subscriptions.add(this.coreService.onShortcut(X.a.NextMarket).subscribe((function() {
                            e.nextMarket()
                        })))
                    }, t.prototype.onClearBetslipUserSelections = function() {
                        this.selectedOddsIds = [], this.numbersSelected = [], this.updateBetslipConfiguration()
                    }, t.prototype.resetMultiplier = function() {
                        this.betslipMultiplier && this.betslipMultiplier.resetMultiplier()
                    }, t.prototype.isResultsHistoryButtonVisible = function() {
                        return this.betslipService.getShopadminProfileSettings().showResults
                    }, t.prototype.previousMarket = function() {
                        var e = this.getTabIndex(this.tabSelected) - 1;
                        e < 0 && (e = this.tabSet.tabs.length - 1), this.tabSet.select(e)
                    }, t.prototype.nextMarket = function() {
                        var e = (this.getTabIndex(this.tabSelected) + 1) % this.tabSet.tabs.length;
                        this.tabSet.select(e)
                    }, t.prototype.getTabIndex = function(e) {
                        return this.tabSet.tabs.toArray().findIndex((function(t) {
                            return t.id === e
                        }))
                    }, t.prototype.init = function() {
                        var e = this;
                        this.getOdds(), this.subscriptions.add(this.betslipService.onClear.subscribe((function() {
                            e.resetMultiplier(), e.cd.markForCheck()
                        }))), this.subscriptions.add(this.betslipService.onStake.subscribe((function() {
                            e.resetMultiplier(), setTimeout((function() {
                                return e.cd.detectChanges()
                            }), 0)
                        }))), this.multiplier.next(1), this.onTabChange(this.tabSelected), this.getLastHistory()
                    }, t.prototype.getBetslipTitle = function(e) {
                        var t = this.i18NService.getMarketGroupTag(e.marketId) + " - ";
                        switch (e.marketId) {
                            case y.SnMarkets.Low_High:
                            case y.SnMarkets.Low_High_Color:
                            case y.SnMarkets.Even_Odd:
                                t = ""
                        }
                        return t
                    }, t.prototype.openPaytableComponent = function() {
                        var e = this;
                        this.modalService.open("base-information", le, {
                            inputs: {
                                playlist: this.playlist,
                                isDeluxe: this.isDeluxe,
                                currentPayTable: this.getCurrentPayTable()
                            },
                            outputs: {
                                close: function() {
                                    e.modalService.close("base-information")
                                }
                            }
                        })
                    }, t.prototype.getEventId = function() {
                        return this.eventBlock.events[0].eventId
                    }, t.prototype.setDefaultTab = function() {
                        this.tabSelected = this.marketsName[0].id, this.onTabChange(this.tabSelected)
                    }, t.prototype.getOdds = function() {
                        var e = this,
                            t = this.isDeluxe ? this.deluxeMarketsGroups : this.mainMarketsGroups;
                        this.odds = [], t.forEach((function(t, n) {
                            e.odds.push([]), t.forEach((function(t) {
                                var l = e.event.data._clData.marketMap.get(t).odds;
                                l = t === y.SnMarkets.Colors ? [l[1], l[0], l[2]] : l, l = t === y.SnMarkets.Low_High ? [l[1], l[0]] : l, e.odds[n].push({
                                    title: t,
                                    oddsMarket: l
                                })
                            }))
                        }))
                    }, t.prototype.createBets = function() {
                        var e = this,
                            t = [];
                        this.numbersSelected.forEach((function(n) {
                            t.push({
                                playlist: e.playlist,
                                eventBlock: e.eventBlock,
                                event: e.event,
                                odd: e.event.data._clData.oddMap.get("Number_" + n)
                            })
                        })), this.selectedOddsIds && this.selectedOddsIds.length > 0 && this.selectedOddsIds.forEach((function(n) {
                            t.push({
                                playlist: e.playlist,
                                eventBlock: e.eventBlock,
                                event: e.event,
                                odd: e.event.data._clData.oddMap.get(n)
                            })
                        })), this.onClearBetslipUserSelections(), t.length > 0 && this.betslipService.addBets(t), this.cd.detectChanges()
                    }, t.prototype.isIncluded = function(e, t) {
                        return e.includes(t)
                    }, t.prototype.getRandomValue = function(e) {
                        for (var t = this.generateRandomValue(); this.isIncluded(e, t);) t = this.generateRandomValue();
                        return t
                    }, t.prototype.generateRandomValue = function() {
                        return Math.floor(36 * Math.random() + 1)
                    }, t.prototype.getSpin2WinMode = function() {
                        return this.playlist.filter.isSnFilter() && this.playlist.filter.mode
                    }, t.prototype.setModeAndSpinType = function() {
                        this.isDeluxe = this.getSpin2WinMode() === y.coreModel.SnFilter.ModeEnum.DELUXE
                    }, t.prototype.updateBetslipConfiguration = function() {
                        this.betslipService.updateConfiguration({
                            hasOptionsSelected: this.numbersSelected.length > 0 || this.selectedOddsIds.length > 0
                        })
                    }, t
                }(ee.a),
                oe = [
                    ["[_nghost-%COMP%] > .grid[_ngcontent-%COMP%]{height:100%;padding:15px 20px}[_nghost-%COMP%] > .grid[_ngcontent-%COMP%] > .col[_ngcontent-%COMP%]{padding:10px 20px}[_nghost-%COMP%] > .grid[_ngcontent-%COMP%] > .col[_ngcontent-%COMP%] > .col[_ngcontent-%COMP%]{margin-bottom:30px}.tabs[_ngcontent-%COMP%]     .tab-header{font-weight:400;text-transform:uppercase}.resultHistory[_ngcontent-%COMP%]{padding:30px 48px 0}.resultHistory__title[_ngcontent-%COMP%]{margin-bottom:19px;font-size:26px;font-weight:700;text-transform:capitalize}.resultHistory__element[_ngcontent-%COMP%]{float:left;height:35px;width:33%;margin-bottom:5px;margin-right:2px}.resultHistory__eventId[_ngcontent-%COMP%]{float:left;width:70%;font-weight:700;font-size:22px;text-align:left;margin-left:10px;margin-top:3px;padding-top:1%}.resultHistory__number[_ngcontent-%COMP%]{float:left;width:35px;height:80%;margin-top:4px;border:1px solid #fff;font-size:14px;font-weight:700;text-align:center;padding-top:5px;margin-left:10px}.resultHistory__number--black[_ngcontent-%COMP%]{background-color:#080808;color:#fefefe}.resultHistory__number--red[_ngcontent-%COMP%]{background-color:#bf1514;color:#fefefe}.resultHistory__number--green[_ngcontent-%COMP%]{background-color:#538e0f;color:#fefefe}.resultList[_ngcontent-%COMP%]{width:100%;float:left}"]
                ],
                re = l.Gb({
                    encapsulation: 0,
                    styles: oe,
                    data: {}
                });

            function ue(e) {
                return l.ec(0, [(e()(), l.Ib(0, 0, null, null, 1, "grc-tab", [], null, null, null, f.b, f.a)), l.Hb(1, 114688, [
                    [5, 4]
                ], 0, S.a, [], {
                    header: [0, "header"],
                    id: [1, "id"]
                }, null)], (function(e, t) {
                    e(t, 1, 0, t.context.$implicit.value, t.context.$implicit.id)
                }), null)
            }

            function ae(e) {
                return l.ec(0, [(e()(), l.Ib(0, 0, null, null, 1, "grc-markets-group", [], null, [
                    [null, "selectedOddsIdsChange"]
                ], (function(e, t, n) {
                    var l = !0,
                        i = e.component;
                    "selectedOddsIdsChange" === t && (l = !1 !== i.onSelectedOddsIds(n) && l);
                    return l
                }), P, T)), l.Hb(1, 114688, null, 0, w, [], {
                    event: [0, "event"],
                    title: [1, "title"],
                    marketsGroupsOdds: [2, "marketsGroupsOdds"],
                    selectedOddsIds: [3, "selectedOddsIds"]
                }, {
                    selectedOddsIdsChange: "selectedOddsIdsChange"
                })], (function(e, t) {
                    var n = t.component;
                    e(t, 1, 0, n.event, t.context.$implicit.title, t.context.$implicit.oddsMarket, n.selectedOddsIds)
                }), null)
            }

            function ce(e) {
                return l.ec(0, [(e()(), l.Ib(0, 0, null, null, 8, "div", [], null, null, null, null, null)), (e()(), l.Ib(1, 0, null, null, 7, "div", [
                    ["class", "resultHistory__element"]
                ], null, null, null, null, null)), (e()(), l.Ib(2, 0, null, null, 1, "div", [
                    ["class", "resultHistory__eventId"]
                ], null, null, null, null, null)), (e()(), l.cc(3, null, [" #", " "])), (e()(), l.Ib(4, 0, null, null, 4, "div", [
                    ["class", "resultHistory__number"]
                ], null, null, null, null, null)), l.Zb(512, null, _.x, _.y, [l.A, l.B, l.o, l.P]), l.Hb(6, 278528, null, 0, _.k, [_.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), l.Xb(7, {
                    "resultHistory__number--red": 0,
                    "resultHistory__number--black": 1,
                    "resultHistory__number--green": 2
                }), (e()(), l.cc(8, null, [" ", " "]))], (function(e, t) {
                    var n = t.component,
                        l = e(t, 7, 0, t.context.$implicit.events[0].result.wonMarkets[2] === n.SnOdds.Red, t.context.$implicit.events[0].result.wonMarkets[2] === n.SnOdds.Black, t.context.$implicit.events[0].result.wonMarkets[2] != n.SnOdds.Red && t.context.$implicit.events[0].result.wonMarkets[2] != n.SnOdds.Black);
                    e(t, 6, 0, "resultHistory__number", l)
                }), (function(e, t) {
                    e(t, 3, 0, t.context.$implicit.eBlockId), e(t, 8, 0, t.context.$implicit.events[0].result.finalOutcome)
                }))
            }

            function de(e) {
                return l.ec(0, [(e()(), l.Ib(0, 0, null, null, 7, null, null, null, null, null, null, null)), (e()(), l.Ib(1, 0, null, null, 6, "div", [
                    ["class", "resultHistory"]
                ], null, null, null, null, null)), (e()(), l.Ib(2, 0, null, null, 2, "div", [
                    ["class", "resultHistory__title"]
                ], null, null, null, null, null)), (e()(), l.cc(3, null, ["", ""])), l.Wb(131072, k.j, [k.k, l.i]), (e()(), l.Ib(5, 0, null, null, 2, "div", [
                    ["class", "resultList"]
                ], null, null, null, null, null)), (e()(), l.xb(16777216, null, null, 1, null, ce)), l.Hb(7, 278528, null, 0, _.l, [l.eb, l.Z, l.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(e, t) {
                    e(t, 7, 0, t.component.eventBlocksHistory)
                }), (function(e, t) {
                    e(t, 3, 0, l.dc(t, 3, 0, l.Ub(t, 4).transform("ch_results_history")))
                }))
            }

            function pe(e) {
                return l.ec(0, [(e()(), l.Ib(0, 0, null, null, 36, "div", [
                    ["class", "grid spin2win"]
                ], null, null, null, null, null)), (e()(), l.Ib(1, 0, null, null, 23, "div", [
                    ["class", "col grid grid-column"]
                ], null, null, null, null, null)), (e()(), l.Ib(2, 0, null, null, 1, "grc-spin2win-bet-table", [
                    ["class", "col"]
                ], null, [
                    [null, "selectedNumbersChange"],
                    ["window", "resize"]
                ], (function(e, t, n) {
                    var i = !0,
                        s = e.component;
                    "window:resize" === t && (i = !1 !== l.Ub(e, 3).onResize() && i);
                    "selectedNumbersChange" === t && (i = !1 !== s.onSelectedNumbers(n) && i);
                    return i
                }), z, E)), l.Hb(3, 4440064, null, 0, D, [l.o, l.i, N.a], {
                    selectedNumbers: [0, "selectedNumbers"]
                }, {
                    selectedNumbersChange: "selectedNumbersChange"
                }), (e()(), l.Ib(4, 0, null, null, 20, "grc-tab-set", [
                    ["tabSetClass", ""]
                ], [
                    [8, "className", 0]
                ], [
                    [null, "selectedChange"]
                ], (function(e, t, n) {
                    var l = !0,
                        i = e.component;
                    "selectedChange" === t && (l = !1 !== i.onTabQuickMultiplierChange(n) && l);
                    return l
                }), L.b, L.a)), l.Hb(5, 4308992, [
                    [2, 4]
                ], 2, U.a, [l.i], {
                    sameContent: [0, "sameContent"],
                    hasBorder: [1, "hasBorder"],
                    hiddenTabs: [2, "hiddenTabs"],
                    selected: [3, "selected"],
                    ghost: [4, "ghost"],
                    tabSetClass: [5, "tabSetClass"]
                }, {
                    selectedChange: "selectedChange"
                }), l.ac(603979776, 3, {
                    tabsContent: 1
                }), l.ac(603979776, 4, {
                    tabsFixedContent: 1
                }), (e()(), l.Ib(8, 0, null, null, 2, "grc-tab", [], null, null, null, f.b, f.a)), l.Hb(9, 114688, [
                    [3, 4]
                ], 0, S.a, [], {
                    header: [0, "header"],
                    id: [1, "id"]
                }, null), l.Wb(131072, k.j, [k.k, l.i]), (e()(), l.Ib(11, 0, null, null, 3, "grc-tab", [], null, null, null, f.b, f.a)), l.Hb(12, 114688, [
                    [3, 4]
                ], 0, S.a, [], {
                    header: [0, "header"],
                    id: [1, "id"]
                }, null), l.Wb(131072, k.j, [k.k, l.i]), l.Wb(131072, _.b, [l.i]), (e()(), l.Ib(15, 0, null, null, 9, "grc-tab-fixed", [
                    ["side", "content"]
                ], null, null, null, W.b, W.a)), l.Hb(16, 114688, [
                    [4, 4]
                ], 0, q.a, [], {
                    side: [0, "side"]
                }, null), (e()(), l.Ib(17, 0, null, 0, 3, "div", [], [
                    [8, "hidden", 0]
                ], null, null, null, null)), (e()(), l.Ib(18, 0, null, null, 2, "gr-quick-pick", [
                    ["class", "quick-pick-container"]
                ], null, [
                    [null, "numberSelected"]
                ], (function(e, t, n) {
                    var l = !0,
                        i = e.component;
                    "numberSelected" === t && (l = !1 !== i.createRandomArray(n) && l);
                    return l
                }), $.b, $.a)), l.Hb(19, 49152, null, 0, j.a, [], {
                    numbers: [0, "numbers"]
                }, {
                    numberSelected: "numberSelected"
                }), l.Vb(20, 6), (e()(), l.Ib(21, 0, null, 0, 3, "div", [], [
                    [8, "hidden", 0]
                ], null, null, null, null)), (e()(), l.Ib(22, 0, null, null, 2, "grc-betslip-multiplier", [], null, [
                    [null, "multiplier"],
                    [null, "isMultiplierInvalid"]
                ], (function(e, t, n) {
                    var l = !0,
                        i = e.component;
                    "multiplier" === t && (l = !1 !== i.onMultiplierSelected(n) && l);
                    "isMultiplierInvalid" === t && (l = !1 !== i.onMultiplierValidation(n) && l);
                    return l
                }), V.b, V.a)), l.Hb(23, 114688, [
                    [1, 4]
                ], 0, Z.a, [], {
                    multipliers: [0, "multipliers"],
                    maxMultiplier: [1, "maxMultiplier"]
                }, {
                    multiplier: "multiplier",
                    isMultiplierInvalid: "isMultiplierInvalid"
                }), l.Vb(24, 5), (e()(), l.Ib(25, 0, null, null, 11, "grc-tab-set", [
                    ["tabSetClass", "col tabs"]
                ], [
                    [8, "className", 0]
                ], [
                    [null, "selectedChange"]
                ], (function(e, t, n) {
                    var l = !0,
                        i = e.component;
                    "selectedChange" === t && (l = !1 !== i.onTabChange(n) && l);
                    return l
                }), L.b, L.a)), l.Hb(26, 4308992, [
                    [2, 4]
                ], 2, U.a, [l.i], {
                    sameContent: [0, "sameContent"],
                    hasBorder: [1, "hasBorder"],
                    hiddenTabs: [2, "hiddenTabs"],
                    selected: [3, "selected"],
                    ghost: [4, "ghost"],
                    tabSetClass: [5, "tabSetClass"]
                }, {
                    selectedChange: "selectedChange"
                }), l.ac(603979776, 5, {
                    tabsContent: 1
                }), l.ac(603979776, 6, {
                    tabsFixedContent: 1
                }), (e()(), l.xb(16777216, null, null, 1, null, ue)), l.Hb(30, 278528, null, 0, _.l, [l.eb, l.Z, l.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), (e()(), l.Ib(31, 0, null, null, 5, "grc-tab-fixed", [
                    ["side", "content"]
                ], null, null, null, W.b, W.a)), l.Hb(32, 114688, [
                    [6, 4]
                ], 0, q.a, [], {
                    side: [0, "side"]
                }, null), (e()(), l.xb(16777216, null, 0, 1, null, ae)), l.Hb(34, 278528, null, 0, _.l, [l.eb, l.Z, l.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), (e()(), l.xb(16777216, null, 0, 1, null, de)), l.Hb(36, 16384, null, 0, _.m, [l.eb, l.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(e, t) {
                    var n = t.component;
                    e(t, 3, 0, n.numbersSelected);
                    e(t, 5, 0, !0, !0, !1, "quick-pick", !1, "");
                    e(t, 9, 0, l.dc(t, 9, 0, l.Ub(t, 10).transform("ch_quick_picks")), "quick-pick");
                    e(t, 12, 0, l.dc(t, 12, 0, l.Ub(t, 13).transform("ch_multiplier")) + " x" + l.dc(t, 12, 0, l.Ub(t, 14).transform(n.multiplier)), "multiplier");
                    e(t, 16, 0, "content");
                    var i = e(t, 20, 0, 1, 2, 3, 5, 7, 10);
                    e(t, 19, 0, i);
                    var s = e(t, 24, 0, 1, 2, 4, 5, 10);
                    e(t, 23, 0, s, n.getMaxMultiplier());
                    e(t, 26, 0, !0, n.isDeluxe, !n.isDeluxe, n.tabSelected, !n.isDeluxe, "col tabs"), e(t, 30, 0, n.marketsName);
                    e(t, 32, 0, "content"), e(t, 34, 0, n.selectedOdds), e(t, 36, 0, !n.isDeluxe)
                }), (function(e, t) {
                    var n = t.component;
                    e(t, 4, 0, l.Ub(t, 5).tabSetClass), e(t, 17, 0, "multiplier" === n.quickMultiplierTabSelected), e(t, 21, 0, "quick-pick" === n.quickMultiplierTabSelected), e(t, 25, 0, l.Ub(t, 26).tabSetClass)
                }))
            }

            function be(e) {
                return l.ec(2, [l.ac(671088640, 1, {
                    betslipMultiplier: 0
                }), l.ac(671088640, 2, {
                    tabSet: 0
                }), (e()(), l.xb(16777216, null, null, 1, null, pe)), l.Hb(3, 16384, null, 0, _.m, [l.eb, l.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(e, t) {
                    e(t, 3, 0, t.component.event)
                }), null)
            }
            var he = l.Eb("grc-page-spin2win", se, (function(e) {
                    return l.ec(0, [(e()(), l.Ib(0, 0, null, null, 1, "grc-page-spin2win", [], null, null, null, be, re)), l.Hb(1, 245760, null, 0, se, [l.y, J.a], null, null)], (function(e, t) {
                        e(t, 1, 0)
                    }), null)
                }), {}, {}, []),
                ge = n("Wh5D"),
                me = n("3oWU"),
                fe = n("hkR0"),
                Se = n("pQ2l"),
                ke = n("ghVy"),
                _e = n("goQo"),
                ye = n("UhMo"),
                ve = [ge.a],
                Me = l.Gb({
                    encapsulation: 0,
                    styles: ve,
                    data: {}
                });

            function Oe(e) {
                return l.ec(2, [(e()(), l.Ib(0, 0, null, null, 11, "div", [
                    ["class", "grid grid-column paytable"]
                ], null, null, null, null, null)), (e()(), l.Ib(1, 0, null, null, 0, "div", [
                    ["class", "paytable__cross-close icon icon-cancel"]
                ], null, [
                    [null, "click"]
                ], (function(e, t, n) {
                    var l = !0,
                        i = e.component;
                    "click" === t && (l = !1 !== i.close.emit() && l);
                    return l
                }), null, null)), (e()(), l.Ib(2, 0, null, null, 1, "grc-header-paytable", [], null, null, null, me.b, me.a)), l.Hb(3, 114688, null, 0, fe.a, [], {
                    playlist: [0, "playlist"]
                }, null), (e()(), l.Ib(4, 0, null, null, 2, "div", [
                    ["class", "paytable__tab-buttons grid grid-center"]
                ], null, null, null, null, null)), (e()(), l.Ib(5, 0, null, null, 1, "grc-tab-buttons", [], null, [
                    [null, "selectedChange"]
                ], (function(e, t, n) {
                    var l = !0,
                        i = e.component;
                    "selectedChange" === t && (l = !1 !== i.onButtonActiveChange(n) && l);
                    return l
                }), Se.b, Se.a)), l.Hb(6, 4308992, null, 0, ke.a, [l.i], {
                    buttons: [0, "buttons"]
                }, {
                    selectedChange: "selectedChange"
                }), (e()(), l.Ib(7, 0, null, null, 1, "grc-body-paytable", [
                    ["class", "paytable--body-margin col"]
                ], null, null, null, _e.b, _e.a)), l.Hb(8, 49152, null, 0, ye.a, [], {
                    paytableGame: [0, "paytableGame"],
                    playlist: [1, "playlist"],
                    isS2Wheels: [2, "isS2Wheels"],
                    isRainbow: [3, "isRainbow"],
                    isKinel8: [4, "isKinel8"],
                    hasX: [5, "hasX"],
                    buttons: [6, "buttons"],
                    columnsPerRow: [7, "columnsPerRow"],
                    buttonSelected: [8, "buttonSelected"]
                }, null), (e()(), l.Ib(9, 0, null, null, 2, "div", [
                    ["class", "paytable__button-close"]
                ], null, [
                    [null, "click"]
                ], (function(e, t, n) {
                    var l = !0,
                        i = e.component;
                    "click" === t && (l = !1 !== i.close.emit() && l);
                    return l
                }), null, null)), (e()(), l.cc(10, null, ["", ""])), l.Wb(131072, k.j, [k.k, l.i])], (function(e, t) {
                    var n = t.component;
                    e(t, 3, 0, n.playlist), e(t, 6, 0, n.buttons), e(t, 8, 0, n.paytableGame, n.playlist, n.isS2Wheels, n.isRainbow, n.isKinel8, n.hasX, n.buttons, n.columnsPerRow, n.buttonSelected)
                }), (function(e, t) {
                    e(t, 10, 0, l.dc(t, 10, 0, l.Ub(t, 11).transform("ch_close")))
                }))
            }
            var Ce = l.Eb("ng-component", le, (function(e) {
                    return l.ec(0, [(e()(), l.Ib(0, 0, null, null, 1, "ng-component", [], null, null, null, Oe, Me)), l.Hb(1, 114688, null, 0, le, [k.k], null, null)], (function(e, t) {
                        e(t, 1, 0)
                    }), null)
                }), {
                    currentPayTable: "currentPayTable",
                    isS2Wheels: "isS2Wheels",
                    isRainbow: "isRainbow",
                    isKinel8: "isKinel8",
                    playlist: "playlist",
                    isDeluxe: "isDeluxe"
                }, {
                    close: "close",
                    selectedChange: "selectedChange"
                }, []),
                xe = n("gIcY"),
                Ie = n("M3iF"),
                we = n("tfG9"),
                He = n("t/Na"),
                Te = n("7oEI"),
                Be = n("ojct"),
                Pe = n("hIlf"),
                Ne = n("ssOW"),
                De = n("96LH"),
                Re = n("t01L"),
                Ee = n("ZYCi"),
                Ge = n("4hpQ"),
                Fe = n("7x4Y"),
                ze = n("QFAn"),
                Ae = n("iz+u"),
                Le = n("sJrH"),
                Ue = l.Fb(i, [], (function(e) {
                    return l.Rb([l.Sb(512, l.l, l.qb, [
                        [8, [s.a, o.a, r.a, u.c, a.a, c.a, d.a, p.a, b.a, h.a, g.a, m.a, he, Ce]],
                        [3, l.l], l.G
                    ]), l.Sb(4608, _.o, _.n, [l.C, [2, _.C]]), l.Sb(4608, xe.r, xe.r, []), l.Sb(4608, Ie.c, Ie.c, []), l.Sb(4608, we.a, we.a, [_.d]), l.Sb(4608, He.h, He.n, [_.d, l.L, He.l]), l.Sb(4608, He.o, He.o, [He.h, He.m]), l.Sb(5120, He.a, (function(e) {
                        return [e]
                    }), [He.o]), l.Sb(4608, He.k, He.k, []), l.Sb(6144, He.i, null, [He.k]), l.Sb(4608, He.g, He.g, [He.i]), l.Sb(6144, He.b, null, [He.g]), l.Sb(4608, He.f, He.j, [He.b, l.y]), l.Sb(4608, He.c, He.c, [He.f]), l.Sb(4608, Te.a, Te.a, [l.l, Be.a]), l.Sb(4608, Pe.a, Pe.a, [He.c, Ne.a]), l.Sb(4608, De.a, De.a, [Re.a, Pe.a]), l.Sb(1073742336, _.c, _.c, []), l.Sb(1073742336, Ee.p, Ee.p, [
                        [2, Ee.u],
                        [2, Ee.l]
                    ]), l.Sb(1073742336, k.h, k.h, []), l.Sb(1073742336, Ge.a, Ge.a, []), l.Sb(1073742336, xe.q, xe.q, []), l.Sb(1073742336, xe.e, xe.e, []), l.Sb(1073742336, Fe.a, Fe.a, []), l.Sb(1073742336, Ie.b, Ie.b, []), l.Sb(1073742336, ze.a, ze.a, []), l.Sb(1073742336, Ae.a, Ae.a, []), l.Sb(1073742336, He.e, He.e, []), l.Sb(1073742336, He.d, He.d, []), l.Sb(1073742336, Le.a, Le.a, []), l.Sb(1073742336, i, i, []), l.Sb(256, He.l, "XSRF-TOKEN", []), l.Sb(256, He.m, "X-XSRF-TOKEN", []), l.Sb(1024, Ee.j, (function() {
                        return [
                            [{
                                path: "",
                                component: se,
                                resolve: {
                                    ThemeResolver: De.a
                                }
                            }]
                        ]
                    }), []), l.Sb(256, Ne.a, "clients/{{name}}/sn.skin.css", [])])
                }))
        }
    }
]);