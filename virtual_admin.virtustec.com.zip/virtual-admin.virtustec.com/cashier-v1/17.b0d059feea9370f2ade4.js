(window.webpackJsonp = window.webpackJsonp || []).push([
    [17], {
        "1pIY": function(l, n, t) {
            "use strict";
            Object.defineProperty(n, "__esModule", {
                value: !0
            });
            var e = t("2tF/"),
                u = t("NTcF");
            n.async = new u.AsyncScheduler(e.AsyncAction)
        },
        "2tF/": function(l, n, t) {
            "use strict";
            var e, u = this && this.__extends || (e = function(l, n) {
                return (e = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(l, n) {
                        l.__proto__ = n
                    } || function(l, n) {
                        for (var t in n) n.hasOwnProperty(t) && (l[t] = n[t])
                    })(l, n)
            }, function(l, n) {
                function t() {
                    this.constructor = l
                }
                e(l, n), l.prototype = null === n ? Object.create(n) : (t.prototype = n.prototype, new t)
            });
            Object.defineProperty(n, "__esModule", {
                value: !0
            });
            var r = function(l) {
                function n(n, t) {
                    var e = l.call(this, n, t) || this;
                    return e.scheduler = n, e.work = t, e.pending = !1, e
                }
                return u(n, l), n.prototype.schedule = function(l, n) {
                    if (void 0 === n && (n = 0), this.closed) return this;
                    this.state = l;
                    var t = this.id,
                        e = this.scheduler;
                    return null != t && (this.id = this.recycleAsyncId(e, t, n)), this.pending = !0, this.delay = n, this.id = this.id || this.requestAsyncId(e, this.id, n), this
                }, n.prototype.requestAsyncId = function(l, n, t) {
                    return void 0 === t && (t = 0), setInterval(l.flush.bind(l, this), t)
                }, n.prototype.recycleAsyncId = function(l, n, t) {
                    if (void 0 === t && (t = 0), null !== t && this.delay === t && !1 === this.pending) return n;
                    clearInterval(n)
                }, n.prototype.execute = function(l, n) {
                    if (this.closed) return new Error("executing a cancelled action");
                    this.pending = !1;
                    var t = this._execute(l, n);
                    if (t) return t;
                    !1 === this.pending && null != this.id && (this.id = this.recycleAsyncId(this.scheduler, this.id, null))
                }, n.prototype._execute = function(l, n) {
                    var t = !1,
                        e = void 0;
                    try {
                        this.work(l)
                    } catch (u) {
                        t = !0, e = !!u && u || new Error(u)
                    }
                    if (t) return this.unsubscribe(), e
                }, n.prototype._unsubscribe = function() {
                    var l = this.id,
                        n = this.scheduler,
                        t = n.actions,
                        e = t.indexOf(this);
                    this.work = null, this.state = null, this.pending = !1, this.scheduler = null, -1 !== e && t.splice(e, 1), null != l && (this.id = this.recycleAsyncId(n, l, null)), this.delay = null
                }, n
            }(t("Dz+M").Action);
            n.AsyncAction = r
        },
        "45v1": function(l, n, t) {
            "use strict";
            t.r(n), t.d(n, "LeagueModuleNgFactory", (function() {
                return Fn
            }));
            var e = t("CcnG"),
                u = function() {},
                r = t("pMnS"),
                o = t("eZM8"),
                i = t("fHz3"),
                c = t("iGSx"),
                a = t("l+fh"),
                s = t("qIYQ"),
                b = t("2z2z"),
                d = t("mYlp"),
                f = t("E6sH"),
                h = t("1UiX"),
                _ = t("cS+c"),
                p = t("Md+g"),
                m = t("XAsR"),
                g = t("M3um"),
                v = t("5EE+"),
                k = t("Ip0R"),
                y = t("CrY/"),
                I = function() {
                    function l() {
                        this.flexGrow = 1
                    }
                    return l.prototype.ngOnInit = function() {
                        this.odds = this.getOdds(), this.flexGrow = this.odds.length
                    }, l.prototype.getOdds = function() {
                        var l = this.getMarket().odds;
                        if (this.marketNameTest) {
                            var n = new RegExp(this.marketNameTest, "i");
                            l = l.filter((function(l) {
                                return n.test(l.id)
                            }))
                        }
                        return l
                    }, l.prototype.getMarket = function() {
                        return this.eventBlock && this.eventBlock.events[0].data._clData.marketMap.get(this.marketName)
                    }, l
                }(),
                x = [
                    [".market-header[_ngcontent-%COMP%]{height:70px;font-weight:400;text-align:center}.market-header__name[_ngcontent-%COMP%]{display:flex;align-items:center;align-self:center;font-size:18px;text-transform:uppercase}.market-header__odd-container[_ngcontent-%COMP%]{padding:0 20px}.market-header__odd-name[_ngcontent-%COMP%]{display:flex;justify-content:center;align-items:center;height:100%;margin:0 5px;font-size:16px;font-weight:700;text-transform:uppercase}"]
                ],
                w = e.Gb({
                    encapsulation: 0,
                    styles: x,
                    data: {}
                });

            function O(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 3, "div", [
                    ["class", "col market-header__odd-name"]
                ], null, null, null, null, null)), (l()(), e.cc(1, null, ["", ""])), e.Xb(2, {
                    suffix: 0
                }), e.Wb(131072, v.r, [v.k, e.i])], null, (function(l, n) {
                    var t = e.dc(n, 1, 0, e.Ub(n, 3).transform(n.context.$implicit.id, "CH", l(n, 2, 0, "s")));
                    l(n, 1, 0, t)
                }))
            }

            function C(l) {
                return e.ec(2, [(l()(), e.Ib(0, 0, null, null, 6, "div", [
                    ["class", "grid grid-column market-header"]
                ], null, null, null, null, null)), (l()(), e.Ib(1, 0, null, null, 2, "div", [
                    ["class", "col market-header__name"]
                ], null, null, null, null, null)), (l()(), e.cc(2, null, ["", ""])), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(4, 0, null, null, 2, "div", [
                    ["class", "col grid grid-bottom market-header__odd-container"]
                ], null, null, null, null, null)), (l()(), e.xb(16777216, null, null, 1, null, O)), e.Hb(6, 278528, null, 0, k.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(l, n) {
                    l(n, 6, 0, n.component.odds)
                }), (function(l, n) {
                    var t = n.component;
                    l(n, 2, 0, e.dc(n, 2, 0, e.Ub(n, 3).transform(t.title || t.marketName)))
                }))
            }
            e.Eb("grc-market-header", I, (function(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 1, "grc-market-header", [], [
                    [4, "flexGrow", null]
                ], null, null, C, w)), e.Hb(1, 114688, null, 0, I, [], null, null)], (function(l, n) {
                    l(n, 1, 0)
                }), (function(l, n) {
                    l(n, 0, 0, e.Ub(n, 1).flexGrow)
                }))
            }), {
                eventBlock: "eventBlock",
                marketName: "marketName",
                title: "title",
                marketNameTest: "marketNameTest"
            }, {}, []);
            var U = t("MakA"),
                S = t("2Iqj"),
                M = function() {
                    function l() {
                        this.showName = !1, this.flexGrow = 1
                    }
                    return l.prototype.ngOnInit = function() {
                        this.onInit()
                    }, l.prototype.ngOnChanges = function(l) {
                        l.event && !l.event.isFirstChange() && this.onInit()
                    }, l.prototype.onInit = function() {
                        this.odds = this.getOdds(), this.flexGrow = this.odds.length
                    }, l.prototype.getOdds = function() {
                        var l = this.getMarket().odds;
                        if (this.oddNameTest) {
                            var n = new RegExp(this.oddNameTest, "i");
                            l = l.filter((function(l) {
                                return n.test(l.id)
                            }))
                        }
                        return l
                    }, l.prototype.getMarket = function() {
                        return this.event.data._clData.marketMap.get(this.marketName)
                    }, l
                }(),
                W = [
                    ["[_nghost-%COMP%]  grc-odd{height:100%;margin:0 5px}.grid[_ngcontent-%COMP%]{max-height:100%}.grid[_ngcontent-%COMP%]   grc-odd[_ngcontent-%COMP%]:last-child{margin-right:5px}"]
                ],
                P = e.Gb({
                    encapsulation: 0,
                    styles: W,
                    data: {}
                });

            function j(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 2, null, null, null, null, null, null, null)), (l()(), e.cc(1, null, [" ", " "])), e.Wb(131072, v.r, [v.k, e.i])], null, (function(l, n) {
                    l(n, 1, 0, e.dc(n, 1, 0, e.Ub(n, 2).transform(n.parent.context.$implicit.id, "CH")))
                }))
            }

            function E(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 3, "grc-odd", [
                    ["class", "col"]
                ], null, null, null, U.b, U.a)), e.Hb(1, 114688, null, 0, S.a, [], {
                    odd: [0, "odd"],
                    event: [1, "event"],
                    showName: [2, "showName"]
                }, null), (l()(), e.xb(16777216, null, 0, 1, null, j)), e.Hb(3, 16384, null, 0, k.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(l, n) {
                    var t = n.component;
                    l(n, 1, 0, n.context.$implicit, t.event, t.showName), l(n, 3, 0, t.showName)
                }), null)
            }

            function H(l) {
                return e.ec(2, [(l()(), e.Ib(0, 0, null, null, 2, "div", [
                    ["class", "col grid grid-middle"]
                ], null, null, null, null, null)), (l()(), e.xb(16777216, null, null, 1, null, E)), e.Hb(2, 278528, null, 0, k.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(l, n) {
                    l(n, 2, 0, n.component.odds)
                }), null)
            }
            e.Eb("grc-market-inline", M, (function(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 1, "grc-market-inline", [], [
                    [4, "flexGrow", null]
                ], null, null, H, P)), e.Hb(1, 638976, null, 0, M, [], null, null)], (function(l, n) {
                    l(n, 1, 0)
                }), (function(l, n) {
                    l(n, 0, 0, e.Ub(n, 1).flexGrow)
                }))
            }), {
                event: "event",
                marketName: "marketName",
                oddNameTest: "oddNameTest",
                showName: "showName"
            }, {}, []);
            var D = t("mv7g"),
                B = t("+69r"),
                G = t("GhKF"),
                A = t("3cbp"),
                T = t("t01L"),
                F = t("IPGB"),
                N = function() {
                    function l(l) {
                        this.coreService = l
                    }
                    return l.prototype.transform = function(l) {
                        for (var n = [], t = 1; t < arguments.length; t++) n[t - 1] = arguments[t];
                        var e, u = n[0]._clData.playlist;
                        return u.filter.isChFilter() && (e = this.coreService.getAssetsController().getChGameAssetsManager().getBadge(u.filter.isChFilter() && u.filter.assetsId, F.BADGESIZE.SIZE30, l.fifaCode)), e
                    }, l
                }(),
                X = t("pugT"),
                z = t("eJ3O"),
                R = function() {
                    function l(l, n) {
                        this.coreService = l, this.cd = n, this.more = !1, this.moreChange = new e.q, this.clazz = !0, this.classification = [], this.classificationData = {}, this.showScoreBoard = !1, this.subscription = new X.a
                    }
                    return l.prototype.ngOnInit = function() {
                        var l = this;
                        this.getParticipants(), this.coreService.getCashierProfileSettings().gameSettings.find((function(n) {
                            return n.gameType === l.coreService.currentGameType
                        })).hideTeamsClassification || this.setTimerForScoreBoard()
                    }, l.prototype.ngOnChanges = function(l) {
                        l.event && !l.event.isFirstChange() && this.getParticipants(), l.stats && l.stats.currentValue && this.parseClassification()
                    }, l.prototype.toggleMoreModal = function(l) {
                        this.more = !this.more, this.moreChange.next(l)
                    }, l.prototype.classificationUp = function(l) {
                        return this.classification[l]._clData.classificationDifference > 0
                    }, l.prototype.classificationDown = function(l) {
                        return this.classification[l]._clData.classificationDifference < 0
                    }, l.prototype.classificationSame = function(l) {
                        return 0 === this.classification[l]._clData.classificationDifference
                    }, l.prototype.getGoalsDifference = function(l) {
                        return l.goalsScored - l.goalsConceded
                    }, l.prototype.ngOnDestroy = function() {
                        this.subscription.unsubscribe()
                    }, l.prototype.setTimerForScoreBoard = function() {
                        var l = this;
                        this.timer = Object(z.timer)(1e4, 1e4), this.subscription = this.timer.subscribe((function() {
                            l.showScoreBoard = !l.showScoreBoard, l.cd.detectChanges()
                        }))
                    }, l.prototype.getParticipants = function() {
                        var l;
                        l = this.event.data.participants, this.homeParticipant = l[0], this.awayParticipant = l[1]
                    }, l.prototype.parseClassification = function() {
                        var l = this;
                        this.classification = this.stats.groupClassification[0].entries.filter((function(n) {
                            return n.teamId === l.homeParticipant.id || n.teamId === l.awayParticipant.id
                        })), this.classification.forEach((function(n, t) {
                            l.classificationData[n.teamId] = {
                                classificationUp: l.classificationUp(t),
                                classificationDown: l.classificationDown(t),
                                classificationSame: l.classificationSame(t),
                                rankingPosition: n.ranking,
                                goalsDifference: l.getGoalsDifference(n)
                            }
                        }))
                    }, l
                }(),
                Z = [
                    ['[_nghost-%COMP%]{display:flex;padding:8px 20px;flex-grow:1;justify-content:space-between;align-items:center}.match-info__index[_ngcontent-%COMP%]{font-size:22px;font-weight:700}.match-info__teams[_ngcontent-%COMP%]{width:100%;padding:0 10px}.match-info__separator[_ngcontent-%COMP%]{padding:0 5px;font-size:20px}.match-info__team-name[_ngcontent-%COMP%]{font-size:20px;text-align:center}.match-info__team-badge[_ngcontent-%COMP%]{-webkit-filter:drop-shadow(0 1px 2px rgba(0, 0, 0, .25));filter:drop-shadow(0 1px 2px rgba(0, 0, 0, .25))}.match-info__team-badge[_ngcontent-%COMP%]:first-child{margin-right:5px}.match-info__team-badge[_ngcontent-%COMP%]:last-child{margin-left:5px}.match-info__more-button[_ngcontent-%COMP%]{display:flex;justify-content:center;align-items:center;width:56px;height:42px;font-size:24px;font-weight:500;cursor:pointer;border-radius:2px}.match-info__more-button[_ngcontent-%COMP%]::after{content:"+"}.match-info__more-button--active[_ngcontent-%COMP%]{z-index:9999;border:0;box-shadow:0 0}.match-info__more-button--active[_ngcontent-%COMP%]::after{content:"-"}.match-info__position[_ngcontent-%COMP%]{font-size:20px;text-align:center}.match-info__icon[_ngcontent-%COMP%]{display:flex;overflow:hidden;align-items:center;justify-content:center}.match-info__icon[_ngcontent-%COMP%]::after{content:""}.match-info__icon--down[_ngcontent-%COMP%]::after, .match-info__icon--up[_ngcontent-%COMP%]::after{border-right:10px solid transparent;border-left:10px solid transparent}.match-info__icon--up[_ngcontent-%COMP%]::after{border-bottom-style:solid;border-bottom-width:20px}.match-info__icon--down[_ngcontent-%COMP%]::after{border-top-style:solid;border-top-width:20px}.match-info__icon--same[_ngcontent-%COMP%]::after{width:12px;height:12px;border-radius:100%}']
                ],
                $ = e.Gb({
                    encapsulation: 0,
                    styles: Z,
                    data: {}
                });

            function Y(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 1, "span", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["0"]))], null, null)
            }

            function L(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 0, "span", [
                    ["class", "col match-info__icon"]
                ], [
                    [2, "match-info__icon--up", null],
                    [2, "match-info__icon--down", null],
                    [2, "match-info__icon--same", null]
                ], null, null, null, null))], null, (function(l, n) {
                    var t = n.component;
                    l(n, 0, 0, t.classificationData[t.homeParticipant.id] && t.classificationData[t.homeParticipant.id].classificationUp, t.classificationData[t.homeParticipant.id] && t.classificationData[t.homeParticipant.id].classificationDown, t.classificationData[t.homeParticipant.id] && t.classificationData[t.homeParticipant.id].classificationSame)
                }))
            }

            function q(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 4, "span", [
                    ["class", "grid col match-info__team-name"]
                ], null, null, null, null, null)), (l()(), e.xb(16777216, null, null, 1, null, L)), e.Hb(2, 16384, null, 0, k.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.Ib(3, 0, null, null, 1, "span", [
                    ["class", "col match-info__position"]
                ], null, null, null, null, null)), (l()(), e.cc(4, null, [" ", " "]))], (function(l, n) {
                    var t = n.component;
                    l(n, 2, 0, (null == t.classificationData[t.homeParticipant.id] ? null : t.classificationData[t.homeParticipant.id].classificationUp) || (null == t.classificationData[t.homeParticipant.id] ? null : t.classificationData[t.homeParticipant.id].classificationDown) || (null == t.classificationData[t.homeParticipant.id] ? null : t.classificationData[t.homeParticipant.id].classificationSame))
                }), (function(l, n) {
                    var t = n.component;
                    l(n, 4, 0, null == t.classificationData[t.homeParticipant.id] ? null : t.classificationData[t.homeParticipant.id].rankingPosition)
                }))
            }

            function V(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 1, "span", [
                    ["class", "col match-info__team-name"]
                ], null, null, null, null, null)), (l()(), e.cc(1, null, [" ", ""]))], null, (function(l, n) {
                    l(n, 1, 0, n.component.homeParticipant.fifaCode)
                }))
            }

            function J(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 1, "span", [
                    ["class", "col match-info__team-name"]
                ], null, null, null, null, null)), (l()(), e.cc(1, null, ["", ""]))], null, (function(l, n) {
                    l(n, 1, 0, n.component.awayParticipant.fifaCode)
                }))
            }

            function Q(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 0, "div", [
                    ["class", "col match-info__icon"]
                ], [
                    [2, "match-info__icon--up", null],
                    [2, "match-info__icon--down", null],
                    [2, "match-info__icon--same", null]
                ], null, null, null, null))], null, (function(l, n) {
                    var t = n.component;
                    l(n, 0, 0, t.classificationData[t.homeParticipant.id] && t.classificationData[t.awayParticipant.id].classificationUp, t.classificationData[t.homeParticipant.id] && t.classificationData[t.awayParticipant.id].classificationDown, t.classificationData[t.homeParticipant.id] && t.classificationData[t.awayParticipant.id].classificationSame)
                }))
            }

            function K(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 4, "span", [
                    ["class", "grid col match-info__team-name"]
                ], null, null, null, null, null)), (l()(), e.Ib(1, 0, null, null, 1, "span", [
                    ["class", "col match-info__position"]
                ], null, null, null, null, null)), (l()(), e.cc(2, null, [" ", " "])), (l()(), e.xb(16777216, null, null, 1, null, Q)), e.Hb(4, 16384, null, 0, k.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(l, n) {
                    var t = n.component;
                    l(n, 4, 0, (null == t.classificationData[t.awayParticipant.id] ? null : t.classificationData[t.awayParticipant.id].classificationUp) || (null == t.classificationData[t.awayParticipant.id] ? null : t.classificationData[t.awayParticipant.id].classificationDown) || (null == t.classificationData[t.awayParticipant.id] ? null : t.classificationData[t.awayParticipant.id].classificationSame))
                }), (function(l, n) {
                    var t = n.component;
                    l(n, 2, 0, null == t.classificationData[t.awayParticipant.id] ? null : t.classificationData[t.awayParticipant.id].rankingPosition)
                }))
            }

            function ll(l) {
                return e.ec(2, [e.Wb(0, N, [T.a]), (l()(), e.Ib(1, 0, null, null, 3, "div", [
                    ["class", "match-info__index"]
                ], null, null, null, null, null)), (l()(), e.xb(16777216, null, null, 1, null, Y)), e.Hb(3, 16384, null, 0, k.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.cc(4, null, ["", ""])), (l()(), e.Ib(5, 0, null, null, 14, "div", [
                    ["class", "grid grid-space-between grid-middle match-info__teams"]
                ], null, null, null, null, null)), (l()(), e.Ib(6, 0, null, null, 1, "img", [
                    ["alt", ""],
                    ["class", "match-info__team-badge"]
                ], [
                    [8, "src", 4]
                ], null, null, null, null)), e.Yb(7, 2), (l()(), e.xb(16777216, null, null, 1, null, q)), e.Hb(9, 16384, null, 0, k.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.xb(16777216, null, null, 1, null, V)), e.Hb(11, 16384, null, 0, k.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.Ib(12, 0, null, null, 1, "span", [
                    ["class", "match-info__separator"]
                ], null, null, null, null, null)), (l()(), e.cc(-1, null, ["-"])), (l()(), e.xb(16777216, null, null, 1, null, J)), e.Hb(15, 16384, null, 0, k.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.xb(16777216, null, null, 1, null, K)), e.Hb(17, 16384, null, 0, k.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.Ib(18, 0, null, null, 1, "img", [
                    ["alt", ""],
                    ["class", "match-info__team-badge"]
                ], [
                    [8, "src", 4]
                ], null, null, null, null)), e.Yb(19, 2), (l()(), e.Ib(20, 0, [
                    ["moreLessButton", 1]
                ], null, 0, "div", [
                    ["class", "match-info__more-button"]
                ], [
                    [2, "match-info__more-button--active", null]
                ], [
                    [null, "click"]
                ], (function(l, n, t) {
                    var u = !0,
                        r = l.component;
                    "click" === n && (u = !1 !== r.toggleMoreModal(e.Ub(l, 20)) && u);
                    return u
                }), null, null))], (function(l, n) {
                    var t = n.component;
                    l(n, 3, 0, t.event._clData.index <= 8), l(n, 9, 0, t.classificationData && t.showScoreBoard), l(n, 11, 0, !t.showScoreBoard), l(n, 15, 0, !t.showScoreBoard), l(n, 17, 0, t.classificationData && t.showScoreBoard)
                }), (function(l, n) {
                    var t = n.component;
                    l(n, 4, 0, t.event._clData.index + 1);
                    var u = e.Mb(1, "", e.dc(n, 6, 0, l(n, 7, 0, e.Ub(n, 0), t.homeParticipant, t.event)), "");
                    l(n, 6, 0, u);
                    var r = e.Mb(1, "", e.dc(n, 18, 0, l(n, 19, 0, e.Ub(n, 0), t.awayParticipant, t.event)), "");
                    l(n, 18, 0, r), l(n, 20, 0, t.more)
                }))
            }
            e.Eb("grc-match-info", R, (function(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 1, "grc-match-info", [], [
                    [2, "match-info", null]
                ], null, null, ll, $)), e.Hb(1, 770048, null, 0, R, [T.a, e.i], null, null)], (function(l, n) {
                    l(n, 1, 0)
                }), (function(l, n) {
                    l(n, 0, 0, e.Ub(n, 1).clazz)
                }))
            }), {
                event: "event",
                more: "more",
                stats: "stats"
            }, {
                moreChange: "moreChange"
            }, []);
            var nl = function() {
                    function l() {
                        this.moreSelectedChange = new e.q, this.flexGrow = 1
                    }
                    return l.prototype.ngOnInit = function() {
                        this.flexGrow = this.eventBlock.events.length
                    }, l.prototype.onMore = function(l, n) {
                        this.moreSelected === l ? this.moreSelected = void 0 : this.moreSelected = l, this.moreSelectedChange.next({
                            index: this.moreSelected,
                            moreButtonElement: n
                        })
                    }, l
                }(),
                tl = [
                    ["[_nghost-%COMP%]{display:flex;flex-direction:column}"]
                ],
                el = e.Gb({
                    encapsulation: 0,
                    styles: tl,
                    data: {}
                });

            function ul(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 1, "grc-match-info", [], [
                    [2, "match-info--alternative", null],
                    [2, "match-info", null]
                ], [
                    [null, "moreChange"]
                ], (function(l, n, t) {
                    var e = !0,
                        u = l.component;
                    "moreChange" === n && (e = !1 !== u.onMore(l.context.index, t) && e);
                    return e
                }), ll, $)), e.Hb(1, 770048, null, 0, R, [T.a, e.i], {
                    event: [0, "event"],
                    more: [1, "more"],
                    stats: [2, "stats"]
                }, {
                    moreChange: "moreChange"
                })], (function(l, n) {
                    var t = n.component;
                    l(n, 1, 0, n.context.$implicit, t.moreSelected === n.context.index, t.stats)
                }), (function(l, n) {
                    l(n, 0, 0, n.context.index % 2 != 0, e.Ub(n, 1).clazz)
                }))
            }

            function rl(l) {
                return e.ec(2, [(l()(), e.xb(16777216, null, null, 1, null, ul)), e.Hb(1, 278528, null, 0, k.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(l, n) {
                    l(n, 1, 0, n.component.eventBlock.events)
                }), null)
            }
            e.Eb("grc-match-info-list", nl, (function(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 1, "grc-match-info-list", [], [
                    [4, "flexGrow", null]
                ], null, null, rl, el)), e.Hb(1, 114688, null, 0, nl, [], null, null)], (function(l, n) {
                    l(n, 1, 0)
                }), (function(l, n) {
                    l(n, 0, 0, e.Ub(n, 1).flexGrow)
                }))
            }), {
                eventBlock: "eventBlock",
                moreSelected: "moreSelected",
                stats: "stats"
            }, {
                moreSelectedChange: "moreSelectedChange"
            }, []);
            var ol = function() {
                    function l() {
                        this.odds = []
                    }
                    return l.prototype.ngOnInit = function() {
                        this.onInit()
                    }, l.prototype.ngOnChanges = function(l) {
                        l.event && !l.event.isFirstChange() && this.onInit()
                    }, l.prototype.onInit = function() {
                        this.sort()
                    }, l.prototype.sort = function() {
                        var l = this,
                            n = this.event.data._clData.marketMap.get(y.ChMarkets.Correct_Score).odds;
                        n = n.sort((function(l, n) {
                            var t = l.id.split("_").slice(1).map((function(l) {
                                    return +l
                                })),
                                e = n.id.split("_").slice(1).map((function(l) {
                                    return +l
                                })),
                                u = t[0] - e[0],
                                r = t[1] - e[1];
                            return u ? Math.sign(u) : r ? Math.sign(r) : r
                        })), this.odds = [], n.forEach((function(n) {
                            var t = n.id.split("_").slice(1).map((function(l) {
                                return +l
                            }));
                            void 0 === l.odds[t[1]] && l.odds.push([]), l.odds[t[1]].push(n)
                        }))
                    }, l
                }(),
                il = [
                    [".grid[_ngcontent-%COMP%]{margin:0 -5px 10px}.col[_ngcontent-%COMP%]{padding:0 5px}.odd[_ngcontent-%COMP%]{font-size:24px}"]
                ],
                cl = e.Gb({
                    encapsulation: 0,
                    styles: il,
                    data: {}
                });

            function al(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 4, "div", [
                    ["class", "col"]
                ], null, null, null, null, null)), (l()(), e.Ib(1, 0, null, null, 3, "grc-odd", [], null, null, null, U.b, U.a)), e.Hb(2, 114688, null, 0, S.a, [], {
                    odd: [0, "odd"],
                    event: [1, "event"],
                    showName: [2, "showName"]
                }, null), (l()(), e.cc(3, 0, [" ", " "])), e.Wb(131072, v.r, [v.k, e.i])], (function(l, n) {
                    var t = n.component;
                    l(n, 2, 0, n.context.$implicit, t.event, !0)
                }), (function(l, n) {
                    l(n, 3, 0, e.dc(n, 3, 0, e.Ub(n, 4).transform(n.context.$implicit.id, "CH")))
                }))
            }

            function sl(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 2, "div", [], [
                    [8, "className", 0]
                ], null, null, null, null)), (l()(), e.xb(16777216, null, null, 1, null, al)), e.Hb(2, 278528, null, 0, k.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(l, n) {
                    l(n, 2, 0, n.context.$implicit)
                }), (function(l, n) {
                    var t = n.component;
                    l(n, 0, 0, e.Mb(1, "grid grid-", t.odds[0].length, ""))
                }))
            }

            function bl(l) {
                return e.ec(2, [(l()(), e.xb(16777216, null, null, 1, null, sl)), e.Hb(1, 278528, null, 0, k.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(l, n) {
                    l(n, 1, 0, n.component.odds)
                }), null)
            }
            e.Eb("grc-correct-score-market", ol, (function(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 1, "grc-correct-score-market", [], null, null, null, bl, cl)), e.Hb(1, 638976, null, 0, ol, [], null, null)], (function(l, n) {
                    l(n, 1, 0)
                }), null)
            }), {
                event: "event"
            }, {}, []);
            var dl = function() {
                    function l() {
                        this.order = [
                            [y.ChOdds._0_0_Goals, y.ChOdds._1_1_Goals, y.ChOdds._2_2_Goals],
                            [y.ChOdds._0_1_Goals, y.ChOdds._1_2_Goals, y.ChOdds._2_3_Goals],
                            [y.ChOdds._0_2_Goals, y.ChOdds._1_3_Goals, y.ChOdds._2_4_Goals],
                            [y.ChOdds._0_3_Goals, y.ChOdds._1_4_Goals, y.ChOdds._2_5_Goals],
                            [y.ChOdds._0_4_Goals, y.ChOdds._1_5_Goals, y.ChOdds._2_6_Goals],
                            [y.ChOdds._0_5_Goals, y.ChOdds._1_6_Goals, y.ChOdds._3_3_Goals],
                            [y.ChOdds._5_5_Goals, y.ChOdds._4_4_Goals, y.ChOdds._3_4_Goals],
                            [y.ChOdds._5_6_Goals, y.ChOdds._4_5_Goals, y.ChOdds._3_5_Goals],
                            [y.ChOdds._6_6_Goals, y.ChOdds._4_6_Goals, y.ChOdds._3_6_Goals]
                        ]
                    }
                    return l.prototype.ngOnInit = function() {
                        this.onInit()
                    }, l.prototype.ngOnChanges = function(l) {
                        l.event && !l.event.isFirstChange() && this.onInit()
                    }, l.prototype.onInit = function() {
                        this.getOdds()
                    }, l.prototype.getOdds = function() {
                        var l = this;
                        this.odds = [];
                        var n = this.event.data._clData.marketMap.get(y.ChMarkets.Multigoal).odds;
                        this.order.forEach((function(t, e) {
                            l.odds.push([]), t.forEach((function(t) {
                                l.odds[e].push(n.find((function(l) {
                                    return l.id === t
                                })))
                            }))
                        }))
                    }, l
                }(),
                fl = [
                    [".grid[_ngcontent-%COMP%]{margin:0 -5px 10px}.col[_ngcontent-%COMP%]{padding:0 5px}"]
                ],
                hl = e.Gb({
                    encapsulation: 0,
                    styles: fl,
                    data: {}
                });

            function _l(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 4, "div", [
                    ["class", "col"]
                ], null, null, null, null, null)), (l()(), e.Ib(1, 0, null, null, 3, "grc-odd", [], null, null, null, U.b, U.a)), e.Hb(2, 114688, null, 0, S.a, [], {
                    odd: [0, "odd"],
                    event: [1, "event"],
                    showName: [2, "showName"]
                }, null), (l()(), e.cc(3, 0, [" ", " "])), e.Wb(131072, v.r, [v.k, e.i])], (function(l, n) {
                    var t = n.component;
                    l(n, 2, 0, n.context.$implicit, t.event, !0)
                }), (function(l, n) {
                    l(n, 3, 0, e.dc(n, 3, 0, e.Ub(n, 4).transform(n.context.$implicit.id, "CH")))
                }))
            }

            function pl(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 2, "div", [
                    ["class", "grid grid-3"]
                ], null, null, null, null, null)), (l()(), e.xb(16777216, null, null, 1, null, _l)), e.Hb(2, 278528, null, 0, k.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(l, n) {
                    l(n, 2, 0, n.context.$implicit)
                }), null)
            }

            function ml(l) {
                return e.ec(2, [(l()(), e.xb(16777216, null, null, 1, null, pl)), e.Hb(1, 278528, null, 0, k.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(l, n) {
                    l(n, 1, 0, n.component.odds)
                }), null)
            }
            e.Eb("grc-multigoal-market", dl, (function(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 1, "grc-multigoal-market", [], null, null, null, ml, hl)), e.Hb(1, 638976, null, 0, dl, [], null, null)], (function(l, n) {
                    l(n, 1, 0)
                }), null)
            }), {
                event: "event"
            }, {}, []);
            var gl = t("1A4t"),
                vl = function() {
                    function l(l, n, t) {
                        this.elementRef = l, this.sanitizer = n, this.scaleService = t, this.offsetTop = 0, this.close = new e.q, this.ChMarkets = y.ChMarkets
                    }
                    return l.prototype.ngOnInit = function() {
                        this.offsetTop = +this.offsetTop, this.updateDimension()
                    }, l.prototype.ngOnChanges = function(l) {
                        (l.dimensionElement && !l.dimensionElement.isFirstChange() || l.moreButtonElement && !l.moreButtonElement.isFirstChange()) && this.updateDimension()
                    }, l.prototype.updateDimension = function() {
                        if (this.dimensionElement) {
                            var l = this.elementRef.nativeElement.parentElement.getBoundingClientRect(),
                                n = this.moreButtonElement.getBoundingClientRect(),
                                t = this.dimensionElement.nativeElement.getBoundingClientRect();
                            this.left = this.sanitizer.bypassSecurityTrustStyle("" + this.scaleService.getUnscaledWidth(n.left + n.width)), this.top = this.sanitizer.bypassSecurityTrustStyle("" + this.scaleService.getUnscaledHeight(t.top - l.top + this.offsetTop)), this.height = this.sanitizer.bypassSecurityTrustStyle(this.scaleService.getUnscaledHeight(t.height).toString()), this.width = this.sanitizer.bypassSecurityTrustStyle(this.scaleService.getUnscaledWidth(t.width).toString())
                        }
                    }, l
                }(),
                kl = t("ZYjt"),
                yl = [
                    ["[_nghost-%COMP%]{position:absolute;z-index:8;padding:10px 10px 10px 0}.more-markets[_ngcontent-%COMP%]{width:100%;height:100%;padding:5px;font-weight:700;text-transform:capitalize}.more-markets__close[_ngcontent-%COMP%]{padding:10px;margin-bottom:15px;text-align:right;cursor:pointer}.more-markets__left[_ngcontent-%COMP%]{flex-grow:7}.more-markets__right[_ngcontent-%COMP%]{flex-grow:3}.more-markets__section[_ngcontent-%COMP%]{margin:0 55px 44px}.more-markets__title[_ngcontent-%COMP%]{margin-bottom:15px;font-size:22px}"]
                ],
                Il = e.Gb({
                    encapsulation: 0,
                    styles: yl,
                    data: {}
                });

            function xl(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 1, "grc-market-inline", [
                    ["marketName", "Total_Goals"]
                ], [
                    [4, "flexGrow", null]
                ], null, null, H, P)), e.Hb(1, 638976, null, 0, M, [], {
                    event: [0, "event"],
                    marketName: [1, "marketName"],
                    showName: [2, "showName"]
                }, null)], (function(l, n) {
                    l(n, 1, 0, n.component.event, "Total_Goals", !0)
                }), (function(l, n) {
                    l(n, 0, 0, e.Ub(n, 1).flexGrow)
                }))
            }

            function wl(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 1, "grc-correct-score-market", [], null, null, null, bl, cl)), e.Hb(1, 638976, null, 0, ol, [], {
                    event: [0, "event"]
                }, null)], (function(l, n) {
                    l(n, 1, 0, n.component.event)
                }), null)
            }

            function Ol(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 1, "grc-multigoal-market", [], null, null, null, ml, hl)), e.Hb(1, 638976, null, 0, dl, [], {
                    event: [0, "event"]
                }, null)], (function(l, n) {
                    l(n, 1, 0, n.component.event)
                }), null)
            }

            function Cl(l) {
                return e.ec(2, [(l()(), e.Ib(0, 0, null, null, 23, "div", [
                    ["class", "more-markets"]
                ], null, null, null, null, null)), (l()(), e.Ib(1, 0, null, null, 1, "div", [
                    ["class", "more-markets__close"]
                ], null, null, null, null, null)), (l()(), e.Ib(2, 0, null, null, 0, "span", [
                    ["class", "icon icon-cancel"]
                ], null, [
                    [null, "click"]
                ], (function(l, n, t) {
                    var e = !0,
                        u = l.component;
                    "click" === n && (e = !1 !== u.close.next() && e);
                    return e
                }), null, null)), (l()(), e.Ib(3, 0, null, null, 20, "div", [
                    ["class", "grid"]
                ], null, null, null, null, null)), (l()(), e.Ib(4, 0, null, null, 12, "div", [
                    ["class", "col grid grid-column more-markets__left"]
                ], null, null, null, null, null)), (l()(), e.Ib(5, 0, null, null, 5, "div", [
                    ["class", "more-markets__section"]
                ], null, null, null, null, null)), (l()(), e.Ib(6, 0, null, null, 2, "div", [
                    ["class", "more-markets__title"]
                ], null, null, null, null, null)), (l()(), e.cc(7, null, ["", ""])), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.xb(16777216, null, null, 1, null, xl)), e.Hb(10, 16384, null, 0, k.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.Ib(11, 0, null, null, 5, "div", [
                    ["class", "more-markets__section"]
                ], null, null, null, null, null)), (l()(), e.Ib(12, 0, null, null, 2, "div", [
                    ["class", "more-markets__title"]
                ], null, null, null, null, null)), (l()(), e.cc(13, null, ["", ""])), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.xb(16777216, null, null, 1, null, wl)), e.Hb(16, 16384, null, 0, k.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.Ib(17, 0, null, null, 6, "div", [
                    ["class", "col more-markets__right more-markets__section"]
                ], null, null, null, null, null)), (l()(), e.Ib(18, 0, null, null, 5, "div", [], null, null, null, null, null)), (l()(), e.Ib(19, 0, null, null, 2, "div", [
                    ["class", "more-markets__title"]
                ], null, null, null, null, null)), (l()(), e.cc(20, null, ["", ""])), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.xb(16777216, null, null, 1, null, Ol)), e.Hb(23, 16384, null, 0, k.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(l, n) {
                    var t = n.component;
                    l(n, 10, 0, t.event), l(n, 16, 0, t.event), l(n, 23, 0, t.event)
                }), (function(l, n) {
                    var t = n.component;
                    l(n, 7, 0, e.dc(n, 7, 0, e.Ub(n, 8).transform(t.ChMarkets.Total_Goals))), l(n, 13, 0, e.dc(n, 13, 0, e.Ub(n, 14).transform(t.ChMarkets.Correct_Score))), l(n, 20, 0, e.dc(n, 20, 0, e.Ub(n, 21).transform(t.ChMarkets.Multigoal)))
                }))
            }
            e.Eb("grc-more-markets", vl, (function(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 1, "grc-more-markets", [], [
                    [4, "left", "px"],
                    [4, "top", "px"],
                    [4, "height", "px"],
                    [4, "width", "px"]
                ], null, null, Cl, Il)), e.Hb(1, 638976, null, 0, vl, [e.o, kl.b, gl.a], null, null)], (function(l, n) {
                    l(n, 1, 0)
                }), (function(l, n) {
                    l(n, 0, 0, e.Ub(n, 1).left, e.Ub(n, 1).top, e.Ub(n, 1).height, e.Ub(n, 1).width)
                }))
            }), {
                dimensionElement: "dimensionElement",
                moreButtonElement: "moreButtonElement",
                offsetTop: "offsetTop",
                event: "event"
            }, {
                close: "close"
            }, []);
            var Ul, Sl = t("n3kJ"),
                Ml = t("0/uQ"),
                Wl = t("F/XL"),
                Pl = t("xMyE"),
                jl = t("psW0"),
                El = t("67Y/"),
                Hl = t("9Z1F"),
                Dl = t("t9fZ"),
                Bl = t("ijKR"),
                Gl = t("D1+H"),
                Al = t("Z/Mk"),
                Tl = (Ul = function(l, n) {
                    return (Ul = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(l, n) {
                            l.__proto__ = n
                        } || function(l, n) {
                            for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (l[t] = n[t])
                        })(l, n)
                }, function(l, n) {
                    function t() {
                        this.constructor = l
                    }
                    Ul(l, n), l.prototype = null === n ? Object.create(n) : (t.prototype = n.prototype, new t)
                }),
                Fl = function(l) {
                    function n(n) {
                        var t = l.call(this) || this;
                        return t.i18NService = n, t.hasEnterSystemSection = !0, t.ChMarkets = y.ChMarkets, t.ChOdds = y.ChOdds, t.close = new e.q, t
                    }
                    return Tl(n, l), n.prototype.ngOnInit = function() {
                        this.title = "" + this.i18NService.get("ch_league")
                    }, n
                }(Al.a),
                Nl = t("sB3t"),
                Xl = function() {
                    function l(l) {
                        this.cd = l, this.close = new e.q, this.subscriptions = new X.a
                    }
                    return l.prototype.ngOnInit = function() {
                        var l = this;
                        this.eventBlockStats && this.eventBlockStats.groupClassification && (this.classification = this.eventBlockStats.groupClassification[0].entries), this.subscriptions.add(Object(Nl.a)(this.eventBlockController.onClosedMarkets).subscribe((function() {
                            l.close.emit(), l.cd.detectChanges()
                        })))
                    }, l.prototype.ngOnDestroy = function() {
                        this.subscriptions.unsubscribe()
                    }, l
                }(),
                zl = function() {
                    var l = function(n, t) {
                        return (l = Object.setPrototypeOf || {
                                __proto__: []
                            }
                            instanceof Array && function(l, n) {
                                l.__proto__ = n
                            } || function(l, n) {
                                for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (l[t] = n[t])
                            })(n, t)
                    };
                    return function(n, t) {
                        function e() {
                            this.constructor = n
                        }
                        l(n, t), n.prototype = null === t ? Object.create(t) : (e.prototype = t.prototype, new e)
                    }
                }(),
                Rl = function(l, n, t, e) {
                    return new(t || (t = Promise))((function(u, r) {
                        function o(l) {
                            try {
                                c(e.next(l))
                            } catch (n) {
                                r(n)
                            }
                        }

                        function i(l) {
                            try {
                                c(e.throw(l))
                            } catch (n) {
                                r(n)
                            }
                        }

                        function c(l) {
                            var n;
                            l.done ? u(l.value) : (n = l.value, n instanceof t ? n : new t((function(l) {
                                l(n)
                            }))).then(o, i)
                        }
                        c((e = e.apply(l, n || [])).next())
                    }))
                },
                Zl = function(l, n) {
                    var t, e, u, r, o = {
                        label: 0,
                        sent: function() {
                            if (1 & u[0]) throw u[1];
                            return u[1]
                        },
                        trys: [],
                        ops: []
                    };
                    return r = {
                        next: i(0),
                        throw: i(1),
                        return: i(2)
                    }, "function" == typeof Symbol && (r[Symbol.iterator] = function() {
                        return this
                    }), r;

                    function i(r) {
                        return function(i) {
                            return function(r) {
                                if (t) throw new TypeError("Generator is already executing.");
                                for (; o;) try {
                                    if (t = 1, e && (u = 2 & r[0] ? e.return : r[0] ? e.throw || ((u = e.return) && u.call(e), 0) : e.next) && !(u = u.call(e, r[1])).done) return u;
                                    switch (e = 0, u && (r = [2 & r[0], u.value]), r[0]) {
                                        case 0:
                                        case 1:
                                            u = r;
                                            break;
                                        case 4:
                                            return o.label++, {
                                                value: r[1],
                                                done: !1
                                            };
                                        case 5:
                                            o.label++, e = r[1], r = [0];
                                            continue;
                                        case 7:
                                            r = o.ops.pop(), o.trys.pop();
                                            continue;
                                        default:
                                            if (!(u = o.trys, (u = u.length > 0 && u[u.length - 1]) || 6 !== r[0] && 2 !== r[0])) {
                                                o = 0;
                                                continue
                                            }
                                            if (3 === r[0] && (!u || r[1] > u[0] && r[1] < u[3])) {
                                                o.label = r[1];
                                                break
                                            }
                                            if (6 === r[0] && o.label < u[1]) {
                                                o.label = u[1], u = r;
                                                break
                                            }
                                            if (u && o.label < u[2]) {
                                                o.label = u[2], o.ops.push(r);
                                                break
                                            }
                                            u[2] && o.ops.pop(), o.trys.pop();
                                            continue
                                    }
                                    r = n.call(l, o)
                                } catch (i) {
                                    r = [6, i], e = 0
                                } finally {
                                    t = u = 0
                                }
                                if (5 & r[0]) throw r[1];
                                return {
                                    value: r[0] ? r[1] : void 0,
                                    done: !0
                                }
                            }([r, i])
                        }
                    }
                },
                $l = function(l) {
                    function n(n, t, e) {
                        var u = l.call(this, n) || this;
                        return u.shopAdminService = t, u.i18nService = e, u.ChMarkets = y.ChMarkets, u.tabs = [{
                            id: "MAIN",
                            value: "main",
                            children: [{
                                market: y.ChMarkets.Match_Result
                            }, {
                                market: y.ChMarkets.Double_Chance
                            }, {
                                market: y.ChMarkets.Over_Under_2_5
                            }, {
                                market: y.ChMarkets.GoalGoal_NoGoal
                            }]
                        }, {
                            id: "OVERUNDER",
                            value: "over_under",
                            children: [{
                                market: y.ChMarkets.Over_Under_0_5
                            }, {
                                market: y.ChMarkets.Over_Under_1_5
                            }, {
                                market: y.ChMarkets.Over_Under_3_5
                            }, {
                                market: y.ChMarkets.Over_Under_4_5
                            }]
                        }, {
                            id: "HTFTFT",
                            value: "ht_ft_ft",
                            children: [{
                                market: y.ChMarkets.First_Half
                            }, {
                                market: y.ChMarkets.Double_Result
                            }]
                        }, {
                            id: "OVER1X2",
                            value: "over1x2",
                            children: [{
                                title: "1x2scores_over_1_5",
                                market: y.ChMarkets._1x2_Scores_Over_Under_1_5,
                                test: "over_1_5"
                            }, {
                                title: "1x2scores_over_2_5",
                                market: y.ChMarkets._1x2_Scores_Over_Under_2_5,
                                test: "over_2_5"
                            }, {
                                title: "1x2scores_over_3_5",
                                market: y.ChMarkets._1x2_Scores_Over_Under_3_5,
                                test: "over_3_5"
                            }]
                        }, {
                            id: "UNDER1X2",
                            value: "under1x2",
                            children: [{
                                title: "1x2scores_under_1_5",
                                market: y.ChMarkets._1x2_Scores_Over_Under_1_5,
                                test: "under_1_5"
                            }, {
                                title: "1x2scores_under_2_5",
                                market: y.ChMarkets._1x2_Scores_Over_Under_2_5,
                                test: "under_2_5"
                            }, {
                                title: "1x2scores_under_3_5",
                                market: y.ChMarkets._1x2_Scores_Over_Under_3_5,
                                test: "under_3_5"
                            }]
                        }, {
                            id: "HOMEOVERUNDER",
                            value: "home_over_under",
                            children: [{
                                title: "home_scores_over_under_0_5",
                                market: y.ChMarkets.HomeAwayScores_Over_Under_0_5,
                                test: "home"
                            }, {
                                title: "home_scores_over_under_1_5",
                                market: y.ChMarkets.HomeAwayScores_Over_Under_1_5,
                                test: "home"
                            }, {
                                title: "home_scores_over_under_2_5",
                                market: y.ChMarkets.HomeAwayScores_Over_Under_2_5,
                                test: "home"
                            }, {
                                title: "home_scores_over_under_3_5",
                                market: y.ChMarkets.HomeAwayScores_Over_Under_3_5,
                                test: "home"
                            }]
                        }, {
                            id: "AWAYOVERUNDER",
                            value: "away_over_under",
                            children: [{
                                title: "away_scores_over_under_0_5",
                                market: y.ChMarkets.HomeAwayScores_Over_Under_0_5,
                                test: "away"
                            }, {
                                title: "away_scores_over_under_1_5",
                                market: y.ChMarkets.HomeAwayScores_Over_Under_1_5,
                                test: "away"
                            }, {
                                title: "away_scores_over_under_2_5",
                                market: y.ChMarkets.HomeAwayScores_Over_Under_2_5,
                                test: "away"
                            }, {
                                title: "away_scores_over_under_3_5",
                                market: y.ChMarkets.HomeAwayScores_Over_Under_3_5,
                                test: "away"
                            }]
                        }], u.tabSelected = u.tabs[0], u
                    }
                    return zl(n, l), n.prototype.getWeekDay = function() {
                        var l = 0;
                        return this.eventBlock.data.isChEventBlockData() && (l = this.eventBlock.data.matchDay), l
                    }, n.prototype.getMatchDay = function() {
                        var l = 0;
                        return this.eventBlock && this.eventBlock.data.isChEventBlockData() && (l = this.eventBlock.data.matchDay), l < 10 ? "0" + l : l
                    }, n.prototype.getLeagueId = function() {
                        var l = 0;
                        return this.eventBlock.data.isChEventBlockData() && (l = this.eventBlock.data.champId), l
                    }, n.prototype.onMoreMarkets = function(l) {
                        this.moreMarketsIndex = l.index, void 0 !== this.moreMarketsIndex && (this.moreMarketsDimesionElement = this.tabContents.toArray()[0], this.moreButtonElement = l.moreButtonElement)
                    }, n.prototype.closeMoreMarkets = function() {
                        this.moreMarketsIndex = void 0
                    }, n.prototype.onTabChange = function(l) {
                        this.moreMarketsIndex = void 0, this.tabSelected = this.tabs.find((function(n) {
                            return n.id === l
                        }))
                    }, n.prototype.onBeforeInit = function() {
                        var n = this;
                        return l.prototype.onBeforeInit.call(this).pipe(Object(Pl.a)((function() {
                            n.eventBlockStats = null
                        })), Object(jl.a)((function() {
                            return Object(Ml.a)(n.getStats())
                        })), Object(El.a)((function(l) {
                            n.eventBlockStats = l, n.tabSelected = n.tabs.find((function(l) {
                                return "MAIN" === l.id
                            })), n.moreMarketsIndex = void 0, n.baseService.activateGame(!0)
                        })), Object(Hl.a)((function(l) {
                            return console.error(l), Object(Wl.a)(l)
                        })))
                    }, n.prototype.configureFastbet = function() {
                        var l = this;
                        this.betslipService.getFastbetParser(this.playlist.id, "football").subscribe((function(n) {
                            n.setCompetitionType(y.coreModel.ChCompetitionType.LEAGUE), n.setParticipantsLength(l.eventBlock.events.length)
                        }))
                    }, n.prototype.configureBetslip = function() {
                        var l = this;
                        this.betslipService.setConfiguration({
                            tabsMode: [y.BetModeEnum.SINGLEBETMODE, y.BetModeEnum.SYSTEMBETMODE],
                            betMode: y.BetModeEnum.SYSTEMBETMODE,
                            ticketEventTitle: function(n) {
                                var t = l.coreService.getEventByEventId(n.playlistId, n.eventId, l.getGameMode()),
                                    e = t.data.participants.map((function(l) {
                                        return l.isFootballParticipant() && l
                                    }));
                                return {
                                    order: "" + (t._clData.index + 1),
                                    title: e[0].fifaCode + " - " + e[1].fifaCode
                                }
                            },
                            fastbetHelp: function() {
                                return l.openFastBetHelpPage()
                            },
                            prefixMarket: function(n) {
                                return l.getBetslipTitle(n)
                            }
                        })
                    }, n.prototype.configureHeader = function() {
                        var l = this;
                        this.baseService.setHeaderState({
                            gameName: this.playlist.descriptionTag,
                            eventName: this.getEventName(),
                            countdownEventBlockController: this.eventBlockController,
                            iconUrl: this.playlist.filter && this.playlist.filter.isChFilter() && this.coreService.getAssetsController().getChGameAssetsManager().getCompetitionBadge(this.playlist.filter.assetsId),
                            playList: this.playlist,
                            buttons: [{
                                title: "ch_league_table",
                                callback: function() {
                                    return l.showLeagueTable()
                                }
                            }, {
                                title: "ch_results_history",
                                callback: function() {
                                    return l.shopAdminService.openResultHistory(l.playlist)
                                },
                                shortcuts: [Sl.a.ResultHistory],
                                disabled: !this.isResultsHistoryButtonVisible()
                            }]
                        })
                    }, n.prototype.onEventBlockControllerClosedMarkets = function(l) {
                        this.closeMoreMarkets(), this.onTabChange("MAIN")
                    }, n.prototype.onEventBlockControllerReadyToStart = function(l) {
                        var n = this;
                        this.eventBlockStats = null, Object(Ml.a)(this.getStats()).pipe(Object(Pl.a)((function(l) {
                            return n.eventBlockStats = l, n.cd.detectChanges()
                        })), Object(Dl.a)(1), Object(Hl.a)((function(l) {
                            return console.error(l), Object(Wl.a)(l)
                        }))).subscribe()
                    }, n.prototype.configureShortcuts = function() {
                        var l = this;
                        this.subscriptions.add(this.coreService.onShortcut(Sl.a.PreviousMarket).subscribe((function() {
                            l.previousMarket()
                        }))), this.subscriptions.add(this.coreService.onShortcut(Sl.a.NextMarket).subscribe((function() {
                            l.nextMarket()
                        })))
                    }, n.prototype.isResultsHistoryButtonVisible = function() {
                        return !!this.betslipService.getShopadminProfileSettings() && this.betslipService.getShopadminProfileSettings().showResults
                    }, n.prototype.openFastBetHelpPage = function() {
                        var l = this;
                        this.modalService.open("base-front", Fl, {
                            outputs: {
                                close: function() {
                                    l.modalService.close("base-front")
                                }
                            }
                        })
                    }, n.prototype.previousMarket = function() {
                        var l = this.getTabIndex(this.tabSelected.id) - 1;
                        l < 0 && (l = this.tabSet.tabs.length - 1), this.tabSet.select(l)
                    }, n.prototype.nextMarket = function() {
                        var l = (this.getTabIndex(this.tabSelected.id) + 1) % this.tabSet.tabs.length;
                        this.tabSet.select(l)
                    }, n.prototype.getTabIndex = function(l) {
                        return this.tabSet.tabs.toArray().findIndex((function(n) {
                            return n.id === l
                        }))
                    }, n.prototype.getBetslipTitle = function(l) {
                        var n = "";
                        switch (l.marketId) {
                            case y.ChMarkets.Total_Goals:
                            case y.ChMarkets.Correct_Score:
                            case y.ChMarkets.Multigoal:
                            case y.ChMarkets.Double_Chance:
                                n = this.i18NService.getMarketTag(l.marketId, "s") + " "
                        }
                        return n
                    }, n.prototype.showLeagueTable = function() {
                        return Rl(this, void 0, void 0, (function() {
                            var l, n, t = this;
                            return Zl(this, (function(e) {
                                switch (e.label) {
                                    case 0:
                                        return e.trys.push([0, 2, , 3]), [4, this.getStats()];
                                    case 1:
                                        return (l = e.sent()) ? this.modalService.open("base-information", Xl, {
                                            inputs: {
                                                playlist: this.playlist,
                                                event: this.eventBlock && this.eventBlock.events[0],
                                                eventBlockController: this.eventBlockController,
                                                eventBlockStats: l
                                            },
                                            outputs: {
                                                close: function() {
                                                    t.modalService.close("base-information")
                                                }
                                            }
                                        }) : this.showErrorMessage(), [3, 3];
                                    case 2:
                                        return n = e.sent(), console.error(n), [3, 3];
                                    case 3:
                                        return [2]
                                }
                            }))
                        }))
                    }, n.prototype.showErrorMessage = function() {
                        var l = "" + this.i18nService.get("ch_statistics_not_available");
                        this.notificationsService.danger(l)
                    }, n.prototype.getEventName = function() {
                        var l = this.getLeagueId(),
                            n = this.getMatchDay();
                        return l && n ? "#" + l + "/" + n : void 0
                    }, n
                }(Gl.a),
                Yl = [
                    ["[_nghost-%COMP%]  .league-tab-set__fixed{flex:none;flex-basis:20%}[_nghost-%COMP%]  .league-tab-set__fixed .tab-body{display:flex;height:100%;flex-direction:column;justify-content:space-around}.league-tab-set__headlines[_ngcontent-%COMP%]{display:flex;height:70px;max-height:70px;flex-grow:1;align-items:flex-end;justify-content:center;font-size:16px;font-weight:700}.league-tab-set__headlines-element[_ngcontent-%COMP%]{width:100%;height:50%}.league-tab-set__headlines-element--last[_ngcontent-%COMP%]{display:flex;justify-content:center;align-items:center}.league-tab-set__markets[_ngcontent-%COMP%]{height:100%}.league-tab-set__market-inline[_ngcontent-%COMP%]{flex-grow:1}.market-inline[_ngcontent-%COMP%]{padding:8px 18px}.flex-col[_ngcontent-%COMP%]{flex:1 1 3%}.league-container[_ngcontent-%COMP%]{position:relative;width:100%;height:100%;padding-top:30px}.league-container[_ngcontent-%COMP%]  .tab-set__headers{left:20%;width:80%}.league-week[_ngcontent-%COMP%]{position:absolute;left:20px;font-size:22px;text-transform:uppercase}"]
                ],
                Ll = e.Gb({
                    encapsulation: 0,
                    styles: Yl,
                    data: {}
                });

            function ql(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 2, "grc-tab", [], null, null, null, m.b, m.a)), e.Hb(1, 114688, [
                    [3, 4]
                ], 0, g.a, [], {
                    header: [0, "header"],
                    id: [1, "id"]
                }, null), e.Wb(131072, v.q, [v.k, e.i])], (function(l, n) {
                    l(n, 1, 0, e.dc(n, 1, 0, e.Ub(n, 2).transform(n.context.$implicit.value)), n.context.$implicit.id)
                }), null)
            }

            function Vl(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 1, "grc-market-header", [
                    ["class", "col flex-col"]
                ], [
                    [4, "flexGrow", null]
                ], null, null, C, w)), e.Hb(1, 114688, null, 0, I, [], {
                    eventBlock: [0, "eventBlock"],
                    marketName: [1, "marketName"],
                    title: [2, "title"],
                    marketNameTest: [3, "marketNameTest"]
                }, null)], (function(l, n) {
                    l(n, 1, 0, n.component.eventBlock, n.context.$implicit.market, n.context.$implicit.title, n.context.$implicit.test)
                }), (function(l, n) {
                    l(n, 0, 0, e.Ub(n, 1).flexGrow)
                }))
            }

            function Jl(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 1, "grc-market-inline", [
                    ["class", "col grid market-inline"]
                ], [
                    [2, "market-inline--alternative", null],
                    [4, "flexGrow", null]
                ], null, null, H, P)), e.Hb(1, 638976, null, 0, M, [], {
                    event: [0, "event"],
                    marketName: [1, "marketName"],
                    oddNameTest: [2, "oddNameTest"]
                }, null)], (function(l, n) {
                    l(n, 1, 0, n.parent.context.$implicit, n.context.$implicit.market, n.context.$implicit.test)
                }), (function(l, n) {
                    l(n, 0, 0, n.parent.context.index % 2 != 0, e.Ub(n, 1).flexGrow)
                }))
            }

            function Ql(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 2, "div", [
                    ["class", "col grid league-tab-set__market-inline"]
                ], null, null, null, null, null)), (l()(), e.xb(16777216, null, null, 1, null, Jl)), e.Hb(2, 278528, null, 0, k.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(l, n) {
                    l(n, 2, 0, n.component.tabSelected.children)
                }), null)
            }

            function Kl(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 30, null, null, null, null, null, null, null)), (l()(), e.Ib(1, 0, null, null, 29, "div", [
                    ["class", "league-container"]
                ], null, null, null, null, null)), (l()(), e.Ib(2, 0, null, null, 4, "div", [
                    ["class", "league-week"]
                ], null, null, null, null, null)), (l()(), e.cc(3, null, ["", ""])), e.Yb(4, 2), e.Xb(5, {
                    weekDay: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(7, 0, null, null, 21, "grc-tab-set", [
                    ["tabSetClass", "ch-tab-set"]
                ], [
                    [8, "className", 0]
                ], [
                    [null, "selectedChange"]
                ], (function(l, n, t) {
                    var e = !0,
                        u = l.component;
                    "selectedChange" === n && (e = !1 !== u.onTabChange(t) && e);
                    return e
                }), D.b, D.a)), e.Hb(8, 4308992, [
                    [1, 4]
                ], 2, B.a, [e.i], {
                    sameContent: [0, "sameContent"],
                    selected: [1, "selected"],
                    tabSetClass: [2, "tabSetClass"]
                }, {
                    selectedChange: "selectedChange"
                }), e.ac(603979776, 3, {
                    tabsContent: 1
                }), e.ac(603979776, 4, {
                    tabsFixedContent: 1
                }), (l()(), e.Ib(11, 0, null, null, 7, "grc-tab-fixed", [
                    ["class", "league-tab-set__fixed"]
                ], null, null, null, G.b, G.a)), e.Hb(12, 114688, [
                    [4, 4]
                ], 0, A.a, [], {
                    class: [0, "class"]
                }, null), (l()(), e.Ib(13, 0, null, 0, 3, "div", [
                    ["class", "league-tab-set__headlines"]
                ], null, null, null, null, null)), (l()(), e.Ib(14, 0, null, null, 2, "div", [
                    ["class", "league-tab-set__headlines-element league-tab-set__headlines-element--last"]
                ], null, null, null, null, null)), (l()(), e.cc(15, null, [" ", " "])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(17, 0, null, 0, 1, "grc-match-info-list", [], [
                    [4, "flexGrow", null]
                ], [
                    [null, "moreSelectedChange"]
                ], (function(l, n, t) {
                    var e = !0,
                        u = l.component;
                    "moreSelectedChange" === n && (e = !1 !== u.onMoreMarkets(t) && e);
                    return e
                }), rl, el)), e.Hb(18, 114688, null, 0, nl, [], {
                    eventBlock: [0, "eventBlock"],
                    moreSelected: [1, "moreSelected"],
                    stats: [2, "stats"]
                }, {
                    moreSelectedChange: "moreSelectedChange"
                }), (l()(), e.xb(16777216, null, null, 1, null, ql)), e.Hb(20, 278528, null, 0, k.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), (l()(), e.Ib(21, 0, null, null, 7, "grc-tab-fixed", [
                    ["side", "content"]
                ], null, null, null, G.b, G.a)), e.Hb(22, 114688, [
                    [4, 4]
                ], 0, A.a, [], {
                    side: [0, "side"]
                }, null), (l()(), e.Ib(23, 0, [
                    [2, 0],
                    ["tabContent", 1]
                ], 0, 5, "div", [
                    ["class", "grid grid-column league-tab-set__markets"]
                ], null, null, null, null, null)), (l()(), e.Ib(24, 0, null, null, 2, "div", [
                    ["class", "grid"]
                ], null, null, null, null, null)), (l()(), e.xb(16777216, null, null, 1, null, Vl)), e.Hb(26, 278528, null, 0, k.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), (l()(), e.xb(16777216, null, null, 1, null, Ql)), e.Hb(28, 278528, null, 0, k.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), (l()(), e.Ib(29, 0, null, null, 1, "grc-more-markets", [
                    ["offsetTop", "10"]
                ], [
                    [8, "hidden", 0],
                    [4, "left", "px"],
                    [4, "top", "px"],
                    [4, "height", "px"],
                    [4, "width", "px"]
                ], [
                    [null, "close"]
                ], (function(l, n, t) {
                    var e = !0,
                        u = l.component;
                    "close" === n && (e = !1 !== u.closeMoreMarkets() && e);
                    return e
                }), Cl, Il)), e.Hb(30, 638976, null, 0, vl, [e.o, kl.b, gl.a], {
                    dimensionElement: [0, "dimensionElement"],
                    moreButtonElement: [1, "moreButtonElement"],
                    offsetTop: [2, "offsetTop"],
                    event: [3, "event"]
                }, {
                    close: "close"
                })], (function(l, n) {
                    var t = n.component;
                    l(n, 8, 0, !0, t.tabSelected.id, "ch-tab-set");
                    l(n, 12, 0, "league-tab-set__fixed"), l(n, 18, 0, t.eventBlock, t.moreMarketsIndex, t.eventBlockStats), l(n, 20, 0, t.tabs);
                    l(n, 22, 0, "content"), l(n, 26, 0, t.tabSelected.children), l(n, 28, 0, t.eventBlock.events);
                    l(n, 30, 0, t.moreMarketsDimesionElement, t.moreButtonElement, "10", t.eventBlock.events[t.moreMarketsIndex])
                }), (function(l, n) {
                    var t = n.component,
                        u = e.dc(n, 3, 0, e.Ub(n, 6).transform("ch_week", l(n, 5, 0, e.dc(n, 3, 0, l(n, 4, 0, e.Ub(n.parent, 0), t.getWeekDay(), "2.0-2")))));
                    l(n, 3, 0, u), l(n, 7, 0, e.Ub(n, 8).tabSetClass), l(n, 15, 0, e.dc(n, 15, 0, e.Ub(n, 16).transform("ch_matches"))), l(n, 17, 0, e.Ub(n, 18).flexGrow), l(n, 29, 0, void 0 === t.moreMarketsIndex, e.Ub(n, 30).left, e.Ub(n, 30).top, e.Ub(n, 30).height, e.Ub(n, 30).width)
                }))
            }

            function ln(l) {
                return e.ec(2, [e.Wb(0, k.e, [e.C]), e.ac(671088640, 1, {
                    tabSet: 0
                }), e.ac(671088640, 2, {
                    tabContents: 1
                }), (l()(), e.xb(16777216, null, null, 1, null, Kl)), e.Hb(4, 16384, null, 0, k.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(l, n) {
                    l(n, 4, 0, n.component.eventBlock)
                }), null)
            }
            var nn = e.Eb("grc-page-league", $l, (function(l) {
                    return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 1, "grc-page-league", [], null, null, null, ln, Ll)), e.Hb(1, 245760, null, 0, $l, [e.y, Bl.a, v.k], null, null)], (function(l, n) {
                        l(n, 1, 0)
                    }), null)
                }), {}, {}, []),
                tn = function() {
                    function l() {
                        this.gameType = "", this.gameTypeName = ""
                    }
                    return l.prototype.ngOnInit = function() {
                        this.gameType = this.playlist.gameType.val.toLocaleLowerCase(), this.gameTypeName = this.playlist.descriptionTag
                    }, l
                }(),
                en = [
                    [".league-table-header[_ngcontent-%COMP%]{width:940px;padding:25px 30px 25px 20px;font-weight:700;text-transform:uppercase}.league-table-header__icon[_ngcontent-%COMP%]{padding-right:15px;font-size:50px}.league-table-header__title[_ngcontent-%COMP%]{font-size:26px}.league-table-header__subtitle[_ngcontent-%COMP%]{margin-bottom:5px;font-size:16px;font-weight:400}"]
                ],
                un = e.Gb({
                    encapsulation: 0,
                    styles: en,
                    data: {}
                });

            function rn(l) {
                return e.ec(2, [(l()(), e.Ib(0, 0, null, null, 9, "div", [
                    ["class", "grid grid-no-wrap league-table-header"]
                ], null, null, null, null, null)), (l()(), e.Ib(1, 0, null, null, 1, "div", [
                    ["class", "col-middle"]
                ], null, null, null, null, null)), (l()(), e.Ib(2, 0, null, null, 0, "span", [], [
                    [8, "className", 0]
                ], null, null, null, null)), (l()(), e.Ib(3, 0, null, null, 6, "div", [
                    ["class", "grid grid-no-wrap grid-column grid-center"]
                ], null, null, null, null, null)), (l()(), e.Ib(4, 0, null, null, 2, "div", [
                    ["class", "league-table-header__subtitle"]
                ], null, null, null, null, null)), (l()(), e.cc(5, null, ["", ""])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(7, 0, null, null, 2, "div", [
                    ["class", "league-table-header__title"]
                ], null, null, null, null, null)), (l()(), e.cc(8, null, ["", ""])), e.Wb(131072, v.j, [v.k, e.i])], null, (function(l, n) {
                    var t = n.component;
                    l(n, 2, 0, e.Mb(1, "game-icon game-icon-", t.gameType, "-o league-table-header__icon")), l(n, 5, 0, e.dc(n, 5, 0, e.Ub(n, 6).transform(t.gameTypeName))), l(n, 8, 0, e.dc(n, 8, 0, e.Ub(n, 9).transform("ch_league_table")))
                }))
            }
            e.Eb("grc-header-league-table", tn, (function(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 1, "grc-header-league-table", [], null, null, null, rn, un)), e.Hb(1, 114688, null, 0, tn, [], null, null)], (function(l, n) {
                    l(n, 1, 0)
                }), null)
            }), {
                playlist: "playlist"
            }, {}, []);
            var on = function() {
                    function l() {
                        this.columnsHeader = ["", "", "ch_played_s", "ch_win_s", "ch_draw_s", "ch_lost_s", "ch_goal_difference_s", "ch_points_s"], this.columnsBody = ["position", "fifaCode", "played", "win", "draw", "lost", "goalDifference", "points"], this.participants = [], this.teams = []
                    }
                    return l.prototype.ngOnInit = function() {
                        var l = this;
                        this.classification && this.classification.forEach((function(n, t) {
                            var e = n._clData.teamData;
                            l.teams.push({
                                participant: e,
                                position: t + 1,
                                fifaCode: e.fifaCode,
                                played: n.win + n.draw + n.lost,
                                win: n.win,
                                draw: n.draw,
                                lost: n.lost,
                                goalDifference: n.goalsScored - n.goalsConceded,
                                points: n.points
                            })
                        }))
                    }, l
                }(),
                cn = [
                    ['.league-table-body[_ngcontent-%COMP%]{padding:10px 20px 20px;max-height:920px;overflow-y:scroll}.league-table-body__header[_ngcontent-%COMP%]{position:relative;width:100%;height:29px;font-size:22px;text-transform:uppercase}.league-table-body__header[_ngcontent-%COMP%]:before{content:"";display:block;height:10px;position:absolute;top:-10px;width:100%}.league-table-body__row[_ngcontent-%COMP%]{width:100%;height:35px;margin-bottom:1px;font-size:22px}.bold[_ngcontent-%COMP%]{font-weight:700}.badge[_ngcontent-%COMP%]{margin-right:30px}.first[_ngcontent-%COMP%]{margin-top:6px}']
                ],
                an = e.Gb({
                    encapsulation: 0,
                    styles: cn,
                    data: {}
                });

            function sn(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 5, "div", [
                    ["class", "col grid grid-center grid-middle"]
                ], null, null, null, null, null)), e.Zb(512, null, k.x, k.y, [e.A, e.B, e.o, e.P]), e.Hb(2, 278528, null, 0, k.k, [k.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), e.Xb(3, {
                    "col-2": 0,
                    "col-3": 1
                }), (l()(), e.cc(4, null, [" ", " "])), e.Wb(131072, v.j, [v.k, e.i])], (function(l, n) {
                    var t = l(n, 3, 0, 0 === n.context.index || 7 === n.context.index, 1 === n.context.index);
                    l(n, 2, 0, "col grid grid-center grid-middle", t)
                }), (function(l, n) {
                    l(n, 4, 0, e.dc(n, 4, 0, e.Ub(n, 5).transform(n.context.$implicit)))
                }))
            }

            function bn(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 2, "div", [
                    ["class", "col col-1 grid grid-center grid-middle badge"]
                ], null, null, null, null, null)), (l()(), e.Ib(1, 0, null, null, 1, "img", [
                    ["alt", ""]
                ], [
                    [8, "src", 4]
                ], null, null, null, null)), e.Yb(2, 2)], null, (function(l, n) {
                    var t = n.component,
                        u = e.Mb(1, "", e.dc(n, 1, 0, l(n, 2, 0, e.Ub(n.parent.parent.parent, 0), n.parent.parent.context.$implicit.participant, t.event)), "");
                    l(n, 1, 0, u)
                }))
            }

            function dn(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 10, "div", [
                    ["class", "col grid grid-center grid-middle"]
                ], null, null, null, null, null)), e.Zb(512, null, k.x, k.y, [e.A, e.B, e.o, e.P]), e.Hb(2, 278528, null, 0, k.k, [k.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), e.Xb(3, {
                    "col-2": 0,
                    "col-3 team-column": 1,
                    "points-column": 2,
                    bold: 3
                }), (l()(), e.xb(16777216, null, null, 1, null, bn)), e.Hb(5, 16384, null, 0, k.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.Ib(6, 0, null, null, 4, "div", [
                    ["class", "col grid grid-middle"]
                ], null, null, null, null, null)), e.Zb(512, null, k.x, k.y, [e.A, e.B, e.o, e.P]), e.Hb(8, 278528, null, 0, k.k, [k.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), e.Xb(9, {
                    "grid-center": 0
                }), (l()(), e.cc(10, null, ["", ""]))], (function(l, n) {
                    var t = l(n, 3, 0, 0 === n.context.index || 7 === n.context.index, 1 === n.context.index, 7 === n.context.index, 0 === n.context.index || 1 === n.context.index || 7 === n.context.index);
                    l(n, 2, 0, "col grid grid-center grid-middle", t), l(n, 5, 0, 1 === n.context.index);
                    var e = l(n, 9, 0, 1 !== n.context.index);
                    l(n, 8, 0, "col grid grid-middle", e)
                }), (function(l, n) {
                    l(n, 10, 0, n.parent.context.$implicit[n.context.$implicit])
                }))
            }

            function fn(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 5, "div", [
                    ["class", "grid league-table-body__row"]
                ], null, null, null, null, null)), e.Zb(512, null, k.x, k.y, [e.A, e.B, e.o, e.P]), e.Hb(2, 278528, null, 0, k.k, [k.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), e.Xb(3, {
                    first: 0,
                    seconds: 1,
                    descent: 2
                }), (l()(), e.xb(16777216, null, null, 1, null, dn)), e.Hb(5, 278528, null, 0, k.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(l, n) {
                    var t = n.component,
                        e = l(n, 3, 0, 0 === n.context.index, n.context.index > 0 && n.context.index < 5, n.context.index > 16 && n.context.index < 20);
                    l(n, 2, 0, "grid league-table-body__row", e), l(n, 5, 0, t.columnsBody)
                }), null)
            }

            function hn(l) {
                return e.ec(2, [e.Wb(0, N, [T.a]), (l()(), e.Ib(1, 0, null, null, 5, "div", [
                    ["class", "grid league-table-body"]
                ], null, null, null, null, null)), (l()(), e.Ib(2, 0, null, null, 2, "div", [
                    ["class", "grid league-table-body__header"]
                ], null, null, null, null, null)), (l()(), e.xb(16777216, null, null, 1, null, sn)), e.Hb(4, 278528, null, 0, k.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), (l()(), e.xb(16777216, null, null, 1, null, fn)), e.Hb(6, 278528, null, 0, k.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(l, n) {
                    var t = n.component;
                    l(n, 4, 0, t.columnsHeader), l(n, 6, 0, t.teams)
                }), null)
            }
            e.Eb("grc-body-league-table", on, (function(l) {
                return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 1, "grc-body-league-table", [], null, null, null, hn, an)), e.Hb(1, 114688, null, 0, on, [], null, null)], (function(l, n) {
                    l(n, 1, 0)
                }), null)
            }), {
                event: "event",
                classification: "classification"
            }, {}, []);
            var _n = [
                    [".league-table[_ngcontent-%COMP%]{max-width:940px}.league-table__cross-close[_ngcontent-%COMP%]{position:absolute;top:36px;right:36px;z-index:99999;font-size:24px;cursor:pointer}"]
                ],
                pn = e.Gb({
                    encapsulation: 0,
                    styles: _n,
                    data: {}
                });

            function mn(l) {
                return e.ec(2, [(l()(), e.Ib(0, 0, null, null, 5, "div", [
                    ["class", "grid grid-column league-table"]
                ], null, null, null, null, null)), (l()(), e.Ib(1, 0, null, null, 0, "div", [
                    ["class", "league-table__cross-close icon icon-cancel"]
                ], null, [
                    [null, "click"]
                ], (function(l, n, t) {
                    var e = !0,
                        u = l.component;
                    "click" === n && (e = !1 !== u.close.emit() && e);
                    return e
                }), null, null)), (l()(), e.Ib(2, 0, null, null, 1, "grc-header-league-table", [], null, null, null, rn, un)), e.Hb(3, 114688, null, 0, tn, [], {
                    playlist: [0, "playlist"]
                }, null), (l()(), e.Ib(4, 0, null, null, 1, "grc-body-league-table", [], null, null, null, hn, an)), e.Hb(5, 114688, null, 0, on, [], {
                    event: [0, "event"],
                    classification: [1, "classification"]
                }, null)], (function(l, n) {
                    var t = n.component;
                    l(n, 3, 0, t.playlist), l(n, 5, 0, t.event, t.classification)
                }), null)
            }
            var gn = e.Eb("grc-league-table", Xl, (function(l) {
                    return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 1, "grc-league-table", [], null, null, null, mn, pn)), e.Hb(1, 245760, null, 0, Xl, [e.i], null, null)], (function(l, n) {
                        l(n, 1, 0)
                    }), null)
                }), {
                    title: "title",
                    playlist: "playlist",
                    event: "event",
                    eventBlockController: "eventBlockController",
                    eventBlockStats: "eventBlockStats"
                }, {
                    close: "close"
                }, []),
                vn = t("6nHF"),
                kn = t("0ZGX"),
                yn = [
                    [".fastbet-help-league[_ngcontent-%COMP%]{max-width:1500px;max-height:985px;padding:30px;overflow-y:scroll;font-family:OpenSans;font-size:16px}.fastbet-help-league__row[_ngcontent-%COMP%]{line-height:20px}.fastbet-help-league__row[_ngcontent-%COMP%]:not(:first-child)   td[_ngcontent-%COMP%]:not(:last-child){text-transform:uppercase}.fastbet-help-league__row[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]{padding:16px 0 16px 18px}.fastbet-help-league__row[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:first-child{width:20%;font-weight:700}.fastbet-help-league__row[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:nth-child(2), .fastbet-help-league__row[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:nth-child(3){width:20%}.fastbet-help-league__row[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:last-child{width:30%;padding-right:16px}.fastbet-help-league__title[_ngcontent-%COMP%]{font-size:28px;font-weight:700;text-transform:capitalize}.fastbet-help-league__codes[_ngcontent-%COMP%]{width:100%;margin-top:10px;margin-bottom:21px;font-size:16px}.fastbet-help-league__close[_ngcontent-%COMP%]{position:absolute;top:30px;right:55px;z-index:99999;font-size:24px;cursor:pointer}"]
                ],
                In = e.Gb({
                    encapsulation: 0,
                    styles: yn,
                    data: {}
                });

            function xn(l) {
                return e.ec(2, [(l()(), e.Ib(0, 0, null, null, 614, "div", [
                    ["class", "fastbet-help-league"]
                ], null, null, null, null, null)), (l()(), e.Ib(1, 0, null, null, 0, "div", [
                    ["class", "fastbet-help-league__close icon icon-cancel"]
                ], null, [
                    [null, "click"]
                ], (function(l, n, t) {
                    var e = !0,
                        u = l.component;
                    "click" === n && (e = !1 !== u.close.emit() && e);
                    return e
                }), null, null)), (l()(), e.Ib(2, 0, null, null, 1, "gr-fastbet-help-header", [], null, null, null, vn.b, vn.a)), e.Hb(3, 114688, null, 0, kn.a, [], {
                    title: [0, "title"],
                    hasEnterSystemSection: [1, "hasEnterSystemSection"]
                }, null), (l()(), e.Ib(4, 0, null, null, 2, "h1", [
                    ["class", "fastbet-help-league__title"]
                ], null, null, null, null, null)), (l()(), e.cc(5, null, ["", ""])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(7, 0, null, null, 303, "table", [
                    ["class", "fastbet-help-league__codes"]
                ], null, null, null, null, null)), (l()(), e.Ib(8, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(9, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(10, null, ["", ""])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(12, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(13, null, ["", ""])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(15, 0, null, null, 3, "td", [], null, null, null, null, null)), (l()(), e.cc(16, null, ["", " (", " 1)"])), e.Wb(131072, v.j, [v.k, e.i]), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(19, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(20, null, ["", ""])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(22, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(23, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(24, null, ["", ""])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(26, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["1 / 0 / 2"])), (l()(), e.Ib(28, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(29, null, ["1-0+1 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(31, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(32, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(34, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(36, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(37, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(38, null, ["", ""])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(40, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["3 [1 / 0 / 2]"])), (l()(), e.Ib(42, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(43, null, ["1-32+3 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(45, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(46, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(48, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(50, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(51, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(52, null, ["", ""])), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(54, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["10 / 02 / 12"])), (l()(), e.Ib(56, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(57, null, ["1-02+2 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(59, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(60, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(62, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(64, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(65, 0, null, null, 3, "td", [], null, null, null, null, null)), (l()(), e.cc(66, null, ["", "/", ""])), e.Wb(131072, v.p, [v.k, e.i]), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(69, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["9 [4 / 5]"])), (l()(), e.Ib(71, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(72, null, ["1-95+3 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(74, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(75, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(77, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(79, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(80, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(81, null, ["", ""])), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(83, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["[O / U] 0"])), (l()(), e.Ib(85, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(86, null, ["1-U0+14 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(88, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(89, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(91, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(93, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(94, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(95, null, ["", ""])), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(97, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["[O / U] 1"])), (l()(), e.Ib(99, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(100, null, ["1-U1+4 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(102, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(103, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(105, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(107, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(108, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(109, null, ["", ""])), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(111, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["[O / U] 2"])), (l()(), e.Ib(113, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(114, null, ["1-O2+5 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(116, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(117, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(119, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(121, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(122, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(123, null, ["", ""])), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(125, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["[O / U] 3"])), (l()(), e.Ib(127, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(128, null, ["1-O3+5 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(130, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(131, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(133, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(135, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(136, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(137, null, ["", ""])), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(139, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["[O / U] 4"])), (l()(), e.Ib(141, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(142, null, ["1-O4+5 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(144, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(145, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(147, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(149, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(150, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(151, null, ["", ""])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(153, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(154, null, ["G[", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(156, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(157, null, ["1-G5+6 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(159, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(160, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(162, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(164, 0, null, null, 15, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(165, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(166, null, ["", ""])), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(168, 0, null, null, 3, "td", [], null, null, null, null, null)), (l()(), e.cc(169, null, ["G [", "][", "]"])), e.Wb(131072, v.j, [v.k, e.i]), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(172, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(173, null, ["1-G24+3 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(175, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(176, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(178, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(180, 0, null, null, 15, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(181, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(182, null, ["", ""])), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(184, 0, null, null, 3, "td", [], null, null, null, null, null)), (l()(), e.cc(185, null, ["2 [", "][", "]"])), e.Wb(131072, v.j, [v.k, e.i]), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(188, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(189, null, ["1-241+7 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(191, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(192, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(194, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(196, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(197, 0, null, null, 3, "td", [], null, null, null, null, null)), (l()(), e.cc(198, null, ["", ""])), e.Xb(199, {
                    suffix: 0
                }), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(201, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["C [1 / 0 / 2] [O / U] 1"])), (l()(), e.Ib(203, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(204, null, ["1-C0O1+3 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(206, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(207, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(209, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(211, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(212, 0, null, null, 3, "td", [], null, null, null, null, null)), (l()(), e.cc(213, null, ["", ""])), e.Xb(214, {
                    suffix: 0
                }), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(216, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["C [1 / 0 / 2] [O / U] 2"])), (l()(), e.Ib(218, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(219, null, ["1-C1U2+3 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(221, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(222, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(224, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(226, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(227, 0, null, null, 3, "td", [], null, null, null, null, null)), (l()(), e.cc(228, null, ["", ""])), e.Xb(229, {
                    suffix: 0
                }), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(231, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["C [1 / 0 / 2] [O / U] 3"])), (l()(), e.Ib(233, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(234, null, ["1-C2U3+3 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(236, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(237, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(239, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(241, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(242, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(243, null, ["", ""])), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(245, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["1 [1 / 0 / 2] [1 / 0 / 2]"])), (l()(), e.Ib(247, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(248, null, ["1-121+8 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(250, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(251, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(253, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(255, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(256, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(257, null, ["", ""])), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(259, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["C [H / A] [O / U] 0"])), (l()(), e.Ib(261, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(262, null, ["5-CHU0+3 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(264, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(265, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(267, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(269, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(270, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(271, null, ["", ""])), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(273, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["C [H / A] [O / U] 1"])), (l()(), e.Ib(275, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(276, null, ["5-CAU1+4 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(278, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(279, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(281, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(283, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(284, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(285, null, ["", ""])), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(287, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["C [H / A] [O / U] 2"])), (l()(), e.Ib(289, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(290, null, ["6-CHO2+3 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(292, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(293, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(295, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(297, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(298, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(299, null, ["", ""])), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(301, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["C [H / A] [O / U] 3"])), (l()(), e.Ib(303, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(304, null, ["5-CAU0+3 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(306, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(307, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(309, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(311, 0, null, null, 0, "br", [], null, null, null, null, null)), (l()(), e.Ib(312, 0, null, null, 3, "h1", [
                    ["class", "fastbet-help-league__title"]
                ], null, null, null, null, null)), (l()(), e.cc(313, null, ["", " (", ")"])), e.Wb(131072, v.j, [v.k, e.i]), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(316, 0, null, null, 298, "table", [
                    ["class", "fastbet-help-league__codes"]
                ], null, null, null, null, null)), (l()(), e.Ib(317, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(318, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(319, null, ["", ""])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(321, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(322, null, ["", ""])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(324, 0, null, null, 3, "td", [], null, null, null, null, null)), (l()(), e.cc(325, null, ["", " (", " 1)"])), e.Wb(131072, v.j, [v.k, e.i]), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(328, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(329, null, ["", ""])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(331, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(332, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(333, null, ["", ""])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(335, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["W%"])), (l()(), e.Ib(337, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(338, null, ["1-W%+1 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(340, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(341, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(343, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(345, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(346, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(347, null, ["", ""])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(349, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["H%"])), (l()(), e.Ib(351, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(352, null, ["1-H%+3 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(354, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(355, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(357, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(359, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(360, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(361, null, ["", ""])), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(363, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["D%"])), (l()(), e.Ib(365, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(366, null, ["1-D%+2 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(368, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(369, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(371, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(373, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(374, 0, null, null, 3, "td", [], null, null, null, null, null)), (l()(), e.cc(375, null, ["", "/", ""])), e.Wb(131072, v.p, [v.k, e.i]), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(378, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["GGNG%"])), (l()(), e.Ib(380, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(381, null, ["1-GGNG%+3 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(383, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(384, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(386, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(388, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(389, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(390, null, ["", ""])), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(392, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["OU%0"])), (l()(), e.Ib(394, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(395, null, ["1-OU%0+14 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(397, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(398, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(400, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(402, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(403, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(404, null, ["", ""])), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(406, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["OU%1"])), (l()(), e.Ib(408, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(409, null, ["1-OU%1+4 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(411, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(412, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(414, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(416, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(417, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(418, null, ["", ""])), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(420, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["OU%2"])), (l()(), e.Ib(422, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(423, null, ["1-OU%2+5 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(425, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(426, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(428, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(430, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(431, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(432, null, ["", ""])), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(434, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["OU%3"])), (l()(), e.Ib(436, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(437, null, ["1-OU%3+5 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(439, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(440, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(442, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(444, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(445, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(446, null, ["", ""])), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(448, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["OU%4"])), (l()(), e.Ib(450, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(451, null, ["1-OU%4+5 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(453, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(454, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(456, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(458, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(459, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(460, null, ["", ""])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(462, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["G%"])), (l()(), e.Ib(464, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(465, null, ["1-G%+6 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(467, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(468, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(470, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(472, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(473, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(474, null, ["", ""])), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(476, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["MG%"])), (l()(), e.Ib(478, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(479, null, ["1-MG%+3 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(481, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(482, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(484, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(486, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(487, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(488, null, ["", ""])), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(490, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["S%"])), (l()(), e.Ib(492, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(493, null, ["1-S%+7 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(495, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(496, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(498, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(500, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(501, 0, null, null, 3, "td", [], null, null, null, null, null)), (l()(), e.cc(502, null, ["", ""])), e.Xb(503, {
                    suffix: 0
                }), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(505, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["C%1"])), (l()(), e.Ib(507, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(508, null, ["1-C%1+3 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(510, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(511, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(513, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(515, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(516, 0, null, null, 3, "td", [], null, null, null, null, null)), (l()(), e.cc(517, null, ["", ""])), e.Xb(518, {
                    suffix: 0
                }), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(520, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["C%2"])), (l()(), e.Ib(522, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(523, null, ["1-C%2+3 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(525, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(526, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(528, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(530, 0, null, null, 14, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(531, 0, null, null, 3, "td", [], null, null, null, null, null)), (l()(), e.cc(532, null, ["", ""])), e.Xb(533, {
                    suffix: 0
                }), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(535, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["C%3"])), (l()(), e.Ib(537, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(538, null, ["1-C%3+3 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(540, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(541, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(543, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(545, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(546, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(547, null, ["", ""])), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(549, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["HF%"])), (l()(), e.Ib(551, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(552, null, ["1-HF%+3 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(554, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(555, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(557, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(559, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(560, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(561, null, ["", ""])), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(563, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["HA%OU%0"])), (l()(), e.Ib(565, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(566, null, ["5-HA%OU0%+3 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(568, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(569, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(571, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(573, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(574, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(575, null, ["", ""])), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(577, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["HA%OU%1"])), (l()(), e.Ib(579, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(580, null, ["5-HA%OU%1+3 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(582, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(583, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(585, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(587, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(588, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(589, null, ["", ""])), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(591, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["HA%OU%2"])), (l()(), e.Ib(593, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(594, null, ["6-HA%OU%2+4 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(596, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(597, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(599, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(601, 0, null, null, 13, "tr", [
                    ["class", "fastbet-help-league__row"]
                ], null, null, null, null, null)), (l()(), e.Ib(602, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(603, null, ["", ""])), e.Wb(131072, v.p, [v.k, e.i]), (l()(), e.Ib(605, 0, null, null, 1, "td", [], null, null, null, null, null)), (l()(), e.cc(-1, null, ["HA%OU%3"])), (l()(), e.Ib(607, 0, null, null, 2, "td", [], null, null, null, null, null)), (l()(), e.cc(608, null, ["5-HA%OU%3+3 [", "]"])), e.Wb(131072, v.j, [v.k, e.i]), (l()(), e.Ib(610, 0, null, null, 4, "td", [], null, null, null, null, null)), (l()(), e.cc(611, null, ["", ""])), e.Wb(131072, v.b, [v.k, e.i]), e.Xb(613, {
                    stake: 0
                }), e.Wb(131072, v.j, [v.k, e.i])], (function(l, n) {
                    var t = n.component;
                    l(n, 3, 0, t.title, t.hasEnterSystemSection)
                }), (function(l, n) {
                    var t = n.component;
                    l(n, 5, 0, e.dc(n, 5, 0, e.Ub(n, 6).transform("ch_codes"))), l(n, 10, 0, e.dc(n, 10, 0, e.Ub(n, 11).transform("ch_market"))), l(n, 13, 0, e.dc(n, 13, 0, e.Ub(n, 14).transform("ch_code"))), l(n, 16, 0, e.dc(n, 16, 0, e.Ub(n, 17).transform("ch_examples")), e.dc(n, 16, 1, e.Ub(n, 18).transform("ch_match_number"))), l(n, 20, 0, e.dc(n, 20, 0, e.Ub(n, 21).transform("ch_description"))), l(n, 24, 0, e.dc(n, 24, 0, e.Ub(n, 25).transform("ch_full_time_result"))), l(n, 29, 0, e.dc(n, 29, 0, e.Ub(n, 30).transform("ch_return")));
                    var u = e.dc(n, 32, 0, e.Ub(n, 35).transform("ch_match_draw", l(n, 34, 0, e.dc(n, 32, 0, e.Ub(n, 33).transform(1)))));
                    l(n, 32, 0, u), l(n, 38, 0, e.dc(n, 38, 0, e.Ub(n, 39).transform("ch_half_time_result"))), l(n, 43, 0, e.dc(n, 43, 0, e.Ub(n, 44).transform("ch_return")));
                    var r = e.dc(n, 46, 0, e.Ub(n, 49).transform("ch_win_half_time", l(n, 48, 0, e.dc(n, 46, 0, e.Ub(n, 47).transform(3)))));
                    l(n, 46, 0, r), l(n, 52, 0, e.dc(n, 52, 0, e.Ub(n, 53).transform(t.ChMarkets.Double_Chance))), l(n, 57, 0, e.dc(n, 57, 0, e.Ub(n, 58).transform("ch_return")));
                    var o = e.dc(n, 60, 0, e.Ub(n, 63).transform("ch_draw_away", l(n, 62, 0, e.dc(n, 60, 0, e.Ub(n, 61).transform(2)))));
                    l(n, 60, 0, o), l(n, 66, 0, e.dc(n, 66, 0, e.Ub(n, 67).transform(t.ChOdds.gg)), e.dc(n, 66, 1, e.Ub(n, 68).transform(t.ChOdds.nog))), l(n, 72, 0, e.dc(n, 72, 0, e.Ub(n, 73).transform("ch_return")));
                    var i = e.dc(n, 75, 0, e.Ub(n, 78).transform("ch_not_scoring", l(n, 77, 0, e.dc(n, 75, 0, e.Ub(n, 76).transform(3)))));
                    l(n, 75, 0, i), l(n, 81, 0, e.dc(n, 81, 0, e.Ub(n, 82).transform(t.ChMarkets.Over_Under_0_5))), l(n, 86, 0, e.dc(n, 86, 0, e.Ub(n, 87).transform("ch_return")));
                    var c = e.dc(n, 89, 0, e.Ub(n, 92).transform("ch_fewer_0_5", l(n, 91, 0, e.dc(n, 89, 0, e.Ub(n, 90).transform(14)))));
                    l(n, 89, 0, c), l(n, 95, 0, e.dc(n, 95, 0, e.Ub(n, 96).transform(t.ChMarkets.Over_Under_1_5))), l(n, 100, 0, e.dc(n, 100, 0, e.Ub(n, 101).transform("ch_return")));
                    var a = e.dc(n, 103, 0, e.Ub(n, 106).transform("ch_fewer_1_5", l(n, 105, 0, e.dc(n, 103, 0, e.Ub(n, 104).transform(4)))));
                    l(n, 103, 0, a), l(n, 109, 0, e.dc(n, 109, 0, e.Ub(n, 110).transform(t.ChMarkets.Over_Under_2_5))), l(n, 114, 0, e.dc(n, 114, 0, e.Ub(n, 115).transform("ch_return")));
                    var s = e.dc(n, 117, 0, e.Ub(n, 120).transform("ch_more_2_5", l(n, 119, 0, e.dc(n, 117, 0, e.Ub(n, 118).transform(5)))));
                    l(n, 117, 0, s), l(n, 123, 0, e.dc(n, 123, 0, e.Ub(n, 124).transform(t.ChMarkets.Over_Under_3_5))), l(n, 128, 0, e.dc(n, 128, 0, e.Ub(n, 129).transform("ch_return")));
                    var b = e.dc(n, 131, 0, e.Ub(n, 134).transform("ch_more_3_5", l(n, 133, 0, e.dc(n, 131, 0, e.Ub(n, 132).transform(5)))));
                    l(n, 131, 0, b), l(n, 137, 0, e.dc(n, 137, 0, e.Ub(n, 138).transform(t.ChMarkets.Over_Under_4_5))), l(n, 142, 0, e.dc(n, 142, 0, e.Ub(n, 143).transform("ch_return")));
                    var d = e.dc(n, 145, 0, e.Ub(n, 148).transform("ch_more_4_5", l(n, 147, 0, e.dc(n, 145, 0, e.Ub(n, 146).transform(5)))));
                    l(n, 145, 0, d), l(n, 151, 0, e.dc(n, 151, 0, e.Ub(n, 152).transform("ch_goals_number"))), l(n, 154, 0, e.dc(n, 154, 0, e.Ub(n, 155).transform("ch_selection"))), l(n, 157, 0, e.dc(n, 157, 0, e.Ub(n, 158).transform("ch_return")));
                    var f = e.dc(n, 160, 0, e.Ub(n, 163).transform("ch_two_goals", l(n, 162, 0, e.dc(n, 160, 0, e.Ub(n, 161).transform(6)))));
                    l(n, 160, 0, f), l(n, 166, 0, e.dc(n, 166, 0, e.Ub(n, 167).transform(t.ChMarkets.Multigoal))), l(n, 169, 0, e.dc(n, 169, 0, e.Ub(n, 170).transform("ch_min_goals")), e.dc(n, 169, 1, e.Ub(n, 171).transform("ch_max_goals"))), l(n, 173, 0, e.dc(n, 173, 0, e.Ub(n, 174).transform("ch_return")));
                    var h = e.dc(n, 176, 0, e.Ub(n, 179).transform("ch_2_4_goals", l(n, 178, 0, e.dc(n, 176, 0, e.Ub(n, 177).transform(3)))));
                    l(n, 176, 0, h), l(n, 182, 0, e.dc(n, 182, 0, e.Ub(n, 183).transform(t.ChMarkets.Correct_Score))), l(n, 185, 0, e.dc(n, 185, 0, e.Ub(n, 186).transform("ch_home_sc")), e.dc(n, 185, 1, e.Ub(n, 187).transform("ch_away_sc"))), l(n, 189, 0, e.dc(n, 189, 0, e.Ub(n, 190).transform("ch_return")));
                    var _ = e.dc(n, 192, 0, e.Ub(n, 195).transform("ch_score_4_1", l(n, 194, 0, e.dc(n, 192, 0, e.Ub(n, 193).transform(7)))));
                    l(n, 192, 0, _);
                    var p = e.dc(n, 198, 0, e.Ub(n, 200).transform(t.ChMarkets._1x2_Scores_Over_Under_1_5, l(n, 199, 0, "s")));
                    l(n, 198, 0, p), l(n, 204, 0, e.dc(n, 204, 0, e.Ub(n, 205).transform("ch_return")));
                    var m = e.dc(n, 207, 0, e.Ub(n, 210).transform("ch_draw_more_1_5", l(n, 209, 0, e.dc(n, 207, 0, e.Ub(n, 208).transform(3)))));
                    l(n, 207, 0, m);
                    var g = e.dc(n, 213, 0, e.Ub(n, 215).transform(t.ChMarkets._1x2_Scores_Over_Under_2_5, l(n, 214, 0, "s")));
                    l(n, 213, 0, g), l(n, 219, 0, e.dc(n, 219, 0, e.Ub(n, 220).transform("ch_return")));
                    var v = e.dc(n, 222, 0, e.Ub(n, 225).transform("ch_home_win_fewer_2_5", l(n, 224, 0, e.dc(n, 222, 0, e.Ub(n, 223).transform(3)))));
                    l(n, 222, 0, v);
                    var k = e.dc(n, 228, 0, e.Ub(n, 230).transform(t.ChMarkets._1x2_Scores_Over_Under_3_5, l(n, 229, 0, "s")));
                    l(n, 228, 0, k), l(n, 234, 0, e.dc(n, 234, 0, e.Ub(n, 235).transform("ch_return")));
                    var y = e.dc(n, 237, 0, e.Ub(n, 240).transform("ch_away_win_fewer_3_5", l(n, 239, 0, e.dc(n, 237, 0, e.Ub(n, 238).transform(3)))));
                    l(n, 237, 0, y), l(n, 243, 0, e.dc(n, 243, 0, e.Ub(n, 244).transform(t.ChMarkets.Double_Result))), l(n, 248, 0, e.dc(n, 248, 0, e.Ub(n, 249).transform("ch_return")));
                    var I = e.dc(n, 251, 0, e.Ub(n, 254).transform("ch_home_win_match", l(n, 253, 0, e.dc(n, 251, 0, e.Ub(n, 252).transform(8)))));
                    l(n, 251, 0, I), l(n, 257, 0, e.dc(n, 257, 0, e.Ub(n, 258).transform(t.ChMarkets.HomeAwayScores_Over_Under_0_5))), l(n, 262, 0, e.dc(n, 262, 0, e.Ub(n, 263).transform("ch_return")));
                    var x = e.dc(n, 265, 0, e.Ub(n, 268).transform("ch_home_scores_fewer_0_5", l(n, 267, 0, e.dc(n, 265, 0, e.Ub(n, 266).transform(3)))));
                    l(n, 265, 0, x), l(n, 271, 0, e.dc(n, 271, 0, e.Ub(n, 272).transform(t.ChMarkets.HomeAwayScores_Over_Under_1_5))), l(n, 276, 0, e.dc(n, 276, 0, e.Ub(n, 277).transform("ch_return")));
                    var w = e.dc(n, 279, 0, e.Ub(n, 282).transform("ch_away_scores_fewer_1_5", l(n, 281, 0, e.dc(n, 279, 0, e.Ub(n, 280).transform(4)))));
                    l(n, 279, 0, w), l(n, 285, 0, e.dc(n, 285, 0, e.Ub(n, 286).transform(t.ChMarkets.HomeAwayScores_Over_Under_2_5))), l(n, 290, 0, e.dc(n, 290, 0, e.Ub(n, 291).transform("ch_return")));
                    var O = e.dc(n, 293, 0, e.Ub(n, 296).transform("ch_home_scores_more_2_5", l(n, 295, 0, e.dc(n, 293, 0, e.Ub(n, 294).transform(3)))));
                    l(n, 293, 0, O), l(n, 299, 0, e.dc(n, 299, 0, e.Ub(n, 300).transform(t.ChMarkets.HomeAwayScores_Over_Under_3_5))), l(n, 304, 0, e.dc(n, 304, 0, e.Ub(n, 305).transform("ch_return")));
                    var C = e.dc(n, 307, 0, e.Ub(n, 310).transform("ch_away_scores_fewer_3_5", l(n, 309, 0, e.dc(n, 307, 0, e.Ub(n, 308).transform(3)))));
                    l(n, 307, 0, C), l(n, 313, 0, e.dc(n, 313, 0, e.Ub(n, 314).transform("ch_codes")), e.dc(n, 313, 1, e.Ub(n, 315).transform("ch_random"))), l(n, 319, 0, e.dc(n, 319, 0, e.Ub(n, 320).transform("ch_market"))), l(n, 322, 0, e.dc(n, 322, 0, e.Ub(n, 323).transform("ch_code"))), l(n, 325, 0, e.dc(n, 325, 0, e.Ub(n, 326).transform("ch_examples")), e.dc(n, 325, 1, e.Ub(n, 327).transform("ch_match_number"))), l(n, 329, 0, e.dc(n, 329, 0, e.Ub(n, 330).transform("ch_description"))), l(n, 333, 0, e.dc(n, 333, 0, e.Ub(n, 334).transform("ch_full_time_result"))), l(n, 338, 0, e.dc(n, 338, 0, e.Ub(n, 339).transform("ch_return")));
                    var U = e.dc(n, 341, 0, e.Ub(n, 344).transform("ch_end_random_result", l(n, 343, 0, e.dc(n, 341, 0, e.Ub(n, 342).transform(1)))));
                    l(n, 341, 0, U), l(n, 347, 0, e.dc(n, 347, 0, e.Ub(n, 348).transform("ch_half_time_result"))), l(n, 352, 0, e.dc(n, 352, 0, e.Ub(n, 353).transform("ch_return")));
                    var S = e.dc(n, 355, 0, e.Ub(n, 358).transform("ch_halftime_random_result", l(n, 357, 0, e.dc(n, 355, 0, e.Ub(n, 356).transform(3)))));
                    l(n, 355, 0, S), l(n, 361, 0, e.dc(n, 361, 0, e.Ub(n, 362).transform(t.ChMarkets.Double_Chance))), l(n, 366, 0, e.dc(n, 366, 0, e.Ub(n, 367).transform("ch_return")));
                    var M = e.dc(n, 369, 0, e.Ub(n, 372).transform("ch_random_selection", l(n, 371, 0, e.dc(n, 369, 0, e.Ub(n, 370).transform(2)))));
                    l(n, 369, 0, M), l(n, 375, 0, e.dc(n, 375, 0, e.Ub(n, 376).transform(t.ChOdds.gg)), e.dc(n, 375, 1, e.Ub(n, 377).transform(t.ChOdds.nog))), l(n, 381, 0, e.dc(n, 381, 0, e.Ub(n, 382).transform("ch_return")));
                    var W = e.dc(n, 384, 0, e.Ub(n, 387).transform("ch_one_teams_not_scoring", l(n, 386, 0, e.dc(n, 384, 0, e.Ub(n, 385).transform(3)))));
                    l(n, 384, 0, W), l(n, 390, 0, e.dc(n, 390, 0, e.Ub(n, 391).transform(t.ChMarkets.Over_Under_0_5))), l(n, 395, 0, e.dc(n, 395, 0, e.Ub(n, 396).transform("ch_return")));
                    var P = e.dc(n, 398, 0, e.Ub(n, 401).transform("ch_fewer_higher_0_5", l(n, 400, 0, e.dc(n, 398, 0, e.Ub(n, 399).transform(14)))));
                    l(n, 398, 0, P), l(n, 404, 0, e.dc(n, 404, 0, e.Ub(n, 405).transform(t.ChMarkets.Over_Under_1_5))), l(n, 409, 0, e.dc(n, 409, 0, e.Ub(n, 410).transform("ch_return")));
                    var j = e.dc(n, 412, 0, e.Ub(n, 415).transform("ch_fewer_higher_1_5", l(n, 414, 0, e.dc(n, 412, 0, e.Ub(n, 413).transform(4)))));
                    l(n, 412, 0, j), l(n, 418, 0, e.dc(n, 418, 0, e.Ub(n, 419).transform(t.ChMarkets.Over_Under_2_5))), l(n, 423, 0, e.dc(n, 423, 0, e.Ub(n, 424).transform("ch_return")));
                    var E = e.dc(n, 426, 0, e.Ub(n, 429).transform("ch_fewer_higher_2_5", l(n, 428, 0, e.dc(n, 426, 0, e.Ub(n, 427).transform(5)))));
                    l(n, 426, 0, E), l(n, 432, 0, e.dc(n, 432, 0, e.Ub(n, 433).transform(t.ChMarkets.Over_Under_3_5))), l(n, 437, 0, e.dc(n, 437, 0, e.Ub(n, 438).transform("ch_return")));
                    var H = e.dc(n, 440, 0, e.Ub(n, 443).transform("ch_fewer_higher_3_5", l(n, 442, 0, e.dc(n, 440, 0, e.Ub(n, 441).transform(5)))));
                    l(n, 440, 0, H), l(n, 446, 0, e.dc(n, 446, 0, e.Ub(n, 447).transform(t.ChMarkets.Over_Under_4_5))), l(n, 451, 0, e.dc(n, 451, 0, e.Ub(n, 452).transform("ch_return")));
                    var D = e.dc(n, 454, 0, e.Ub(n, 457).transform("ch_fewer_higher_4_5", l(n, 456, 0, e.dc(n, 454, 0, e.Ub(n, 455).transform(5)))));
                    l(n, 454, 0, D), l(n, 460, 0, e.dc(n, 460, 0, e.Ub(n, 461).transform("ch_goals_number"))), l(n, 465, 0, e.dc(n, 465, 0, e.Ub(n, 466).transform("ch_return")));
                    var B = e.dc(n, 468, 0, e.Ub(n, 471).transform("ch_random_goals", l(n, 470, 0, e.dc(n, 468, 0, e.Ub(n, 469).transform(6)))));
                    l(n, 468, 0, B), l(n, 474, 0, e.dc(n, 474, 0, e.Ub(n, 475).transform(t.ChMarkets.Multigoal))), l(n, 479, 0, e.dc(n, 479, 0, e.Ub(n, 480).transform("ch_return")));
                    var G = e.dc(n, 482, 0, e.Ub(n, 485).transform("ch_random_range_goals", l(n, 484, 0, e.dc(n, 482, 0, e.Ub(n, 483).transform(3)))));
                    l(n, 482, 0, G), l(n, 488, 0, e.dc(n, 488, 0, e.Ub(n, 489).transform(t.ChMarkets.Correct_Score))), l(n, 493, 0, e.dc(n, 493, 0, e.Ub(n, 494).transform("ch_return")));
                    var A = e.dc(n, 496, 0, e.Ub(n, 499).transform("ch_random_final_score", l(n, 498, 0, e.dc(n, 496, 0, e.Ub(n, 497).transform(7)))));
                    l(n, 496, 0, A);
                    var T = e.dc(n, 502, 0, e.Ub(n, 504).transform(t.ChMarkets._1x2_Scores_Over_Under_1_5, l(n, 503, 0, "s")));
                    l(n, 502, 0, T), l(n, 508, 0, e.dc(n, 508, 0, e.Ub(n, 509).transform("ch_return")));
                    var F = e.dc(n, 511, 0, e.Ub(n, 514).transform("ch_random result_1_5", l(n, 513, 0, e.dc(n, 511, 0, e.Ub(n, 512).transform(3)))));
                    l(n, 511, 0, F);
                    var N = e.dc(n, 517, 0, e.Ub(n, 519).transform(t.ChMarkets._1x2_Scores_Over_Under_2_5, l(n, 518, 0, "s")));
                    l(n, 517, 0, N), l(n, 523, 0, e.dc(n, 523, 0, e.Ub(n, 524).transform("ch_return")));
                    var X = e.dc(n, 526, 0, e.Ub(n, 529).transform("ch_random result_2_5", l(n, 528, 0, e.dc(n, 526, 0, e.Ub(n, 527).transform(3)))));
                    l(n, 526, 0, X);
                    var z = e.dc(n, 532, 0, e.Ub(n, 534).transform(t.ChMarkets._1x2_Scores_Over_Under_3_5, l(n, 533, 0, "s")));
                    l(n, 532, 0, z), l(n, 538, 0, e.dc(n, 538, 0, e.Ub(n, 539).transform("ch_return")));
                    var R = e.dc(n, 541, 0, e.Ub(n, 544).transform("ch_random result_3_5", l(n, 543, 0, e.dc(n, 541, 0, e.Ub(n, 542).transform(3)))));
                    l(n, 541, 0, R), l(n, 547, 0, e.dc(n, 547, 0, e.Ub(n, 548).transform(t.ChMarkets.Double_Result))), l(n, 552, 0, e.dc(n, 552, 0, e.Ub(n, 553).transform("ch_return")));
                    var Z = e.dc(n, 555, 0, e.Ub(n, 558).transform("ch_random_result", l(n, 557, 0, e.dc(n, 555, 0, e.Ub(n, 556).transform(3)))));
                    l(n, 555, 0, Z), l(n, 561, 0, e.dc(n, 561, 0, e.Ub(n, 562).transform(t.ChMarkets.HomeAwayScores_Over_Under_0_5))), l(n, 566, 0, e.dc(n, 566, 0, e.Ub(n, 567).transform("ch_return")));
                    var $ = e.dc(n, 569, 0, e.Ub(n, 572).transform("ch_random_homeaway_scores_overunder_0_result", l(n, 571, 0, e.dc(n, 569, 0, e.Ub(n, 570).transform(3)))));
                    l(n, 569, 0, $), l(n, 575, 0, e.dc(n, 575, 0, e.Ub(n, 576).transform(t.ChMarkets.HomeAwayScores_Over_Under_1_5))), l(n, 580, 0, e.dc(n, 580, 0, e.Ub(n, 581).transform("ch_return")));
                    var Y = e.dc(n, 583, 0, e.Ub(n, 586).transform("ch_random_homeaway_scores_overunder_1_result", l(n, 585, 0, e.dc(n, 583, 0, e.Ub(n, 584).transform(3)))));
                    l(n, 583, 0, Y), l(n, 589, 0, e.dc(n, 589, 0, e.Ub(n, 590).transform(t.ChMarkets.HomeAwayScores_Over_Under_2_5))), l(n, 594, 0, e.dc(n, 594, 0, e.Ub(n, 595).transform("ch_return")));
                    var L = e.dc(n, 597, 0, e.Ub(n, 600).transform("ch_random_homeaway_scores_overunder_2_result", l(n, 599, 0, e.dc(n, 597, 0, e.Ub(n, 598).transform(4)))));
                    l(n, 597, 0, L), l(n, 603, 0, e.dc(n, 603, 0, e.Ub(n, 604).transform(t.ChMarkets.HomeAwayScores_Over_Under_3_5))), l(n, 608, 0, e.dc(n, 608, 0, e.Ub(n, 609).transform("ch_return")));
                    var q = e.dc(n, 611, 0, e.Ub(n, 614).transform("ch_random_homeaway_scores_overunder_3_result", l(n, 613, 0, e.dc(n, 611, 0, e.Ub(n, 612).transform(3)))));
                    l(n, 611, 0, q)
                }))
            }
            var wn = e.Eb("gr-fastbet-help-league", Fl, (function(l) {
                    return e.ec(0, [(l()(), e.Ib(0, 0, null, null, 1, "gr-fastbet-help-league", [], null, null, null, xn, In)), e.Hb(1, 114688, null, 0, Fl, [v.k], null, null)], (function(l, n) {
                        l(n, 1, 0)
                    }), null)
                }), {
                    participants: "participants"
                }, {
                    close: "close"
                }, []),
                On = t("gIcY"),
                Cn = t("M3iF"),
                Un = t("tfG9"),
                Sn = t("t/Na"),
                Mn = t("7oEI"),
                Wn = t("ojct"),
                Pn = t("hIlf"),
                jn = t("ssOW"),
                En = t("96LH"),
                Hn = t("ZYCi"),
                Dn = t("QFAn"),
                Bn = t("iz+u"),
                Gn = t("4hpQ"),
                An = t("7x4Y"),
                Tn = t("sJrH"),
                Fn = e.Fb(u, [], (function(l) {
                    return e.Rb([e.Sb(512, e.l, e.qb, [
                        [8, [r.a, o.a, i.a, c.a, a.a, s.a, b.a, d.c, f.a, h.a, _.a, p.a, nn, gn, wn]],
                        [3, e.l], e.G
                    ]), e.Sb(4608, k.o, k.n, [e.C, [2, k.C]]), e.Sb(4608, On.r, On.r, []), e.Sb(4608, Cn.c, Cn.c, []), e.Sb(4608, Un.a, Un.a, [k.d]), e.Sb(4608, Sn.h, Sn.n, [k.d, e.L, Sn.l]), e.Sb(4608, Sn.o, Sn.o, [Sn.h, Sn.m]), e.Sb(5120, Sn.a, (function(l) {
                        return [l]
                    }), [Sn.o]), e.Sb(4608, Sn.k, Sn.k, []), e.Sb(6144, Sn.i, null, [Sn.k]), e.Sb(4608, Sn.g, Sn.g, [Sn.i]), e.Sb(6144, Sn.b, null, [Sn.g]), e.Sb(4608, Sn.f, Sn.j, [Sn.b, e.y]), e.Sb(4608, Sn.c, Sn.c, [Sn.f]), e.Sb(4608, Mn.a, Mn.a, [e.l, Wn.a]), e.Sb(4608, Pn.a, Pn.a, [Sn.c, jn.a]), e.Sb(4608, En.a, En.a, [T.a, Pn.a]), e.Sb(1073742336, k.c, k.c, []), e.Sb(1073742336, Hn.p, Hn.p, [
                        [2, Hn.u],
                        [2, Hn.l]
                    ]), e.Sb(1073742336, v.h, v.h, []), e.Sb(1073742336, On.q, On.q, []), e.Sb(1073742336, On.e, On.e, []), e.Sb(1073742336, Cn.b, Cn.b, []), e.Sb(1073742336, Dn.a, Dn.a, []), e.Sb(1073742336, Bn.a, Bn.a, []), e.Sb(1073742336, Gn.a, Gn.a, []), e.Sb(1073742336, An.a, An.a, []), e.Sb(1073742336, Sn.e, Sn.e, []), e.Sb(1073742336, Sn.d, Sn.d, []), e.Sb(1073742336, Tn.a, Tn.a, []), e.Sb(1073742336, u, u, []), e.Sb(256, Sn.l, "XSRF-TOKEN", []), e.Sb(256, Sn.m, "X-XSRF-TOKEN", []), e.Sb(1024, Hn.j, (function() {
                        return [
                            [{
                                path: "",
                                component: $l,
                                resolve: {
                                    ThemeResolver: En.a
                                }
                            }]
                        ]
                    }), []), e.Sb(256, jn.a, "clients/{{name}}/league.skin.css", [])])
                }))
        },
        "9AGB": function(l, n, t) {
            "use strict";
            Object.defineProperty(n, "__esModule", {
                value: !0
            });
            var e = t("w5QO");

            function u(l) {
                return l ? 1 === l.length ? l[0] : function(n) {
                    return l.reduce((function(l, n) {
                        return n(l)
                    }), n)
                } : e.noop
            }
            n.pipe = function() {
                for (var l = [], n = 0; n < arguments.length; n++) l[n] = arguments[n];
                return u(l)
            }, n.pipeFromArray = u
        },
        "Dz+M": function(l, n, t) {
            "use strict";
            var e, u = this && this.__extends || (e = function(l, n) {
                return (e = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(l, n) {
                        l.__proto__ = n
                    } || function(l, n) {
                        for (var t in n) n.hasOwnProperty(t) && (l[t] = n[t])
                    })(l, n)
            }, function(l, n) {
                function t() {
                    this.constructor = l
                }
                e(l, n), l.prototype = null === n ? Object.create(n) : (t.prototype = n.prototype, new t)
            });
            Object.defineProperty(n, "__esModule", {
                value: !0
            });
            var r = function(l) {
                function n(n, t) {
                    return l.call(this) || this
                }
                return u(n, l), n.prototype.schedule = function(l, n) {
                    return void 0 === n && (n = 0), this
                }, n
            }(t("zB/H").Subscription);
            n.Action = r
        },
        FWf1: function(l, n, t) {
            "use strict";
            var e, u = this && this.__extends || (e = function(l, n) {
                return (e = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(l, n) {
                        l.__proto__ = n
                    } || function(l, n) {
                        for (var t in n) n.hasOwnProperty(t) && (l[t] = n[t])
                    })(l, n)
            }, function(l, n) {
                function t() {
                    this.constructor = l
                }
                e(l, n), l.prototype = null === n ? Object.create(n) : (t.prototype = n.prototype, new t)
            });
            Object.defineProperty(n, "__esModule", {
                value: !0
            });
            var r = t("pshJ"),
                o = t("GiSu"),
                i = t("zB/H"),
                c = t("p//D"),
                a = t("n3uD"),
                s = t("MkmW"),
                b = function(l) {
                    function n(t, e, u) {
                        var r = l.call(this) || this;
                        switch (r.syncErrorValue = null, r.syncErrorThrown = !1, r.syncErrorThrowable = !1, r.isStopped = !1, arguments.length) {
                            case 0:
                                r.destination = o.empty;
                                break;
                            case 1:
                                if (!t) {
                                    r.destination = o.empty;
                                    break
                                }
                                if ("object" == typeof t) {
                                    t instanceof n ? (r.syncErrorThrowable = t.syncErrorThrowable, r.destination = t, t.add(r)) : (r.syncErrorThrowable = !0, r.destination = new d(r, t));
                                    break
                                }
                            default:
                                r.syncErrorThrowable = !0, r.destination = new d(r, t, e, u)
                        }
                        return r
                    }
                    return u(n, l), n.prototype[c.rxSubscriber] = function() {
                        return this
                    }, n.create = function(l, t, e) {
                        var u = new n(l, t, e);
                        return u.syncErrorThrowable = !1, u
                    }, n.prototype.next = function(l) {
                        this.isStopped || this._next(l)
                    }, n.prototype.error = function(l) {
                        this.isStopped || (this.isStopped = !0, this._error(l))
                    }, n.prototype.complete = function() {
                        this.isStopped || (this.isStopped = !0, this._complete())
                    }, n.prototype.unsubscribe = function() {
                        this.closed || (this.isStopped = !0, l.prototype.unsubscribe.call(this))
                    }, n.prototype._next = function(l) {
                        this.destination.next(l)
                    }, n.prototype._error = function(l) {
                        this.destination.error(l), this.unsubscribe()
                    }, n.prototype._complete = function() {
                        this.destination.complete(), this.unsubscribe()
                    }, n.prototype._unsubscribeAndRecycle = function() {
                        var l = this._parentOrParents;
                        return this._parentOrParents = null, this.unsubscribe(), this.closed = !1, this.isStopped = !1, this._parentOrParents = l, this
                    }, n
                }(i.Subscription);
            n.Subscriber = b;
            var d = function(l) {
                function n(n, t, e, u) {
                    var i, c = l.call(this) || this;
                    c._parentSubscriber = n;
                    var a = c;
                    return r.isFunction(t) ? i = t : t && (i = t.next, e = t.error, u = t.complete, t !== o.empty && (a = Object.create(t), r.isFunction(a.unsubscribe) && c.add(a.unsubscribe.bind(a)), a.unsubscribe = c.unsubscribe.bind(c))), c._context = a, c._next = i, c._error = e, c._complete = u, c
                }
                return u(n, l), n.prototype.next = function(l) {
                    if (!this.isStopped && this._next) {
                        var n = this._parentSubscriber;
                        a.config.useDeprecatedSynchronousErrorHandling && n.syncErrorThrowable ? this.__tryOrSetError(n, this._next, l) && this.unsubscribe() : this.__tryOrUnsub(this._next, l)
                    }
                }, n.prototype.error = function(l) {
                    if (!this.isStopped) {
                        var n = this._parentSubscriber,
                            t = a.config.useDeprecatedSynchronousErrorHandling;
                        if (this._error) t && n.syncErrorThrowable ? (this.__tryOrSetError(n, this._error, l), this.unsubscribe()) : (this.__tryOrUnsub(this._error, l), this.unsubscribe());
                        else if (n.syncErrorThrowable) t ? (n.syncErrorValue = l, n.syncErrorThrown = !0) : s.hostReportError(l), this.unsubscribe();
                        else {
                            if (this.unsubscribe(), t) throw l;
                            s.hostReportError(l)
                        }
                    }
                }, n.prototype.complete = function() {
                    var l = this;
                    if (!this.isStopped) {
                        var n = this._parentSubscriber;
                        if (this._complete) {
                            var t = function() {
                                return l._complete.call(l._context)
                            };
                            a.config.useDeprecatedSynchronousErrorHandling && n.syncErrorThrowable ? (this.__tryOrSetError(n, t), this.unsubscribe()) : (this.__tryOrUnsub(t), this.unsubscribe())
                        } else this.unsubscribe()
                    }
                }, n.prototype.__tryOrUnsub = function(l, n) {
                    try {
                        l.call(this._context, n)
                    } catch (t) {
                        if (this.unsubscribe(), a.config.useDeprecatedSynchronousErrorHandling) throw t;
                        s.hostReportError(t)
                    }
                }, n.prototype.__tryOrSetError = function(l, n, t) {
                    if (!a.config.useDeprecatedSynchronousErrorHandling) throw new Error("bad call");
                    try {
                        n.call(this._context, t)
                    } catch (e) {
                        return a.config.useDeprecatedSynchronousErrorHandling ? (l.syncErrorValue = e, l.syncErrorThrown = !0, !0) : (s.hostReportError(e), !0)
                    }
                    return !1
                }, n.prototype._unsubscribe = function() {
                    var l = this._parentSubscriber;
                    this._context = null, this._parentSubscriber = null, l.unsubscribe()
                }, n
            }(b);
            n.SafeSubscriber = d
        },
        GMZp: function(l, n, t) {
            "use strict";
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.isObject = function(l) {
                return null !== l && "object" == typeof l
            }
        },
        GiSu: function(l, n, t) {
            "use strict";
            Object.defineProperty(n, "__esModule", {
                value: !0
            });
            var e = t("n3uD"),
                u = t("MkmW");
            n.empty = {
                closed: !0,
                next: function(l) {},
                error: function(l) {
                    if (e.config.useDeprecatedSynchronousErrorHandling) throw l;
                    u.hostReportError(l)
                },
                complete: function() {}
            }
        },
        LBXl: function(l, n, t) {
            "use strict";
            Object.defineProperty(n, "__esModule", {
                value: !0
            });
            var e = function() {
                function l(l) {
                    return Error.call(this), this.message = l ? l.length + " errors occurred during unsubscription:\n" + l.map((function(l, n) {
                        return n + 1 + ") " + l.toString()
                    })).join("\n  ") : "", this.name = "UnsubscriptionError", this.errors = l, this
                }
                return l.prototype = Object.create(Error.prototype), l
            }();
            n.UnsubscriptionError = e
        },
        MkmW: function(l, n, t) {
            "use strict";
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.hostReportError = function(l) {
                setTimeout((function() {
                    throw l
                }), 0)
            }
        },
        NTcF: function(l, n, t) {
            "use strict";
            var e, u = this && this.__extends || (e = function(l, n) {
                return (e = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(l, n) {
                        l.__proto__ = n
                    } || function(l, n) {
                        for (var t in n) n.hasOwnProperty(t) && (l[t] = n[t])
                    })(l, n)
            }, function(l, n) {
                function t() {
                    this.constructor = l
                }
                e(l, n), l.prototype = null === n ? Object.create(n) : (t.prototype = n.prototype, new t)
            });
            Object.defineProperty(n, "__esModule", {
                value: !0
            });
            var r = t("ffpz"),
                o = function(l) {
                    function n(t, e) {
                        void 0 === e && (e = r.Scheduler.now);
                        var u = l.call(this, t, (function() {
                            return n.delegate && n.delegate !== u ? n.delegate.now() : e()
                        })) || this;
                        return u.actions = [], u.active = !1, u.scheduled = void 0, u
                    }
                    return u(n, l), n.prototype.schedule = function(t, e, u) {
                        return void 0 === e && (e = 0), n.delegate && n.delegate !== this ? n.delegate.schedule(t, e, u) : l.prototype.schedule.call(this, t, e, u)
                    }, n.prototype.flush = function(l) {
                        var n = this.actions;
                        if (this.active) n.push(l);
                        else {
                            var t;
                            this.active = !0;
                            do {
                                if (t = l.execute(l.state, l.delay)) break
                            } while (l = n.shift());
                            if (this.active = !1, t) {
                                for (; l = n.shift();) l.unsubscribe();
                                throw t
                            }
                        }
                    }, n
                }(r.Scheduler);
            n.AsyncScheduler = o
        },
        Q1FS: function(l, n, t) {
            "use strict";
            Object.defineProperty(n, "__esModule", {
                value: !0
            });
            var e = t("yx2s"),
                u = t("Xwq/"),
                r = t("zfKp"),
                o = t("9AGB"),
                i = t("n3uD"),
                c = function() {
                    function l(l) {
                        this._isScalar = !1, l && (this._subscribe = l)
                    }
                    return l.prototype.lift = function(n) {
                        var t = new l;
                        return t.source = this, t.operator = n, t
                    }, l.prototype.subscribe = function(l, n, t) {
                        var e = this.operator,
                            r = u.toSubscriber(l, n, t);
                        if (e ? r.add(e.call(r, this.source)) : r.add(this.source || i.config.useDeprecatedSynchronousErrorHandling && !r.syncErrorThrowable ? this._subscribe(r) : this._trySubscribe(r)), i.config.useDeprecatedSynchronousErrorHandling && r.syncErrorThrowable && (r.syncErrorThrowable = !1, r.syncErrorThrown)) throw r.syncErrorValue;
                        return r
                    }, l.prototype._trySubscribe = function(l) {
                        try {
                            return this._subscribe(l)
                        } catch (n) {
                            i.config.useDeprecatedSynchronousErrorHandling && (l.syncErrorThrown = !0, l.syncErrorValue = n), e.canReportError(l) ? l.error(n) : console.warn(n)
                        }
                    }, l.prototype.forEach = function(l, n) {
                        var t = this;
                        return new(n = a(n))((function(n, e) {
                            var u;
                            u = t.subscribe((function(n) {
                                try {
                                    l(n)
                                } catch (t) {
                                    e(t), u && u.unsubscribe()
                                }
                            }), e, n)
                        }))
                    }, l.prototype._subscribe = function(l) {
                        var n = this.source;
                        return n && n.subscribe(l)
                    }, l.prototype[r.observable] = function() {
                        return this
                    }, l.prototype.pipe = function() {
                        for (var l = [], n = 0; n < arguments.length; n++) l[n] = arguments[n];
                        return 0 === l.length ? this : o.pipeFromArray(l)(this)
                    }, l.prototype.toPromise = function(l) {
                        var n = this;
                        return new(l = a(l))((function(l, t) {
                            var e;
                            n.subscribe((function(l) {
                                return e = l
                            }), (function(l) {
                                return t(l)
                            }), (function() {
                                return l(e)
                            }))
                        }))
                    }, l.create = function(n) {
                        return new l(n)
                    }, l
                }();

            function a(l) {
                if (l || (l = i.config.Promise || Promise), !l) throw new Error("no Promise impl found");
                return l
            }
            n.Observable = c
        },
        "Xwq/": function(l, n, t) {
            "use strict";
            Object.defineProperty(n, "__esModule", {
                value: !0
            });
            var e = t("FWf1"),
                u = t("p//D"),
                r = t("GiSu");
            n.toSubscriber = function(l, n, t) {
                if (l) {
                    if (l instanceof e.Subscriber) return l;
                    if (l[u.rxSubscriber]) return l[u.rxSubscriber]()
                }
                return l || n || t ? new e.Subscriber(l, n, t) : new e.Subscriber(r.empty)
            }
        },
        eJ3O: function(l, n, t) {
            "use strict";
            Object.defineProperty(n, "__esModule", {
                value: !0
            });
            var e = t("Q1FS"),
                u = t("1pIY"),
                r = t("p0+S"),
                o = t("nzqU");

            function i(l) {
                var n = l.index,
                    t = l.period,
                    e = l.subscriber;
                if (e.next(n), !e.closed) {
                    if (-1 === t) return e.complete();
                    l.index = n + 1, this.schedule(l, t)
                }
            }
            n.timer = function(l, n, t) {
                void 0 === l && (l = 0);
                var c = -1;
                return r.isNumeric(n) ? c = Number(n) < 1 ? 1 : Number(n) : o.isScheduler(n) && (t = n), o.isScheduler(t) || (t = u.async), new e.Observable((function(n) {
                    var e = r.isNumeric(l) ? l : +l - t.now();
                    return t.schedule(i, e, {
                        index: 0,
                        period: c,
                        subscriber: n
                    })
                }))
            }
        },
        ffpz: function(l, n, t) {
            "use strict";
            Object.defineProperty(n, "__esModule", {
                value: !0
            });
            var e = function() {
                function l(n, t) {
                    void 0 === t && (t = l.now), this.SchedulerAction = n, this.now = t
                }
                return l.prototype.schedule = function(l, n, t) {
                    return void 0 === n && (n = 0), new this.SchedulerAction(this, l).schedule(t, n)
                }, l.now = function() {
                    return Date.now()
                }, l
            }();
            n.Scheduler = e
        },
        mbIT: function(l, n, t) {
            "use strict";
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.isArray = Array.isArray || function(l) {
                return l && "number" == typeof l.length
            }
        },
        n3uD: function(l, n, t) {
            "use strict";
            Object.defineProperty(n, "__esModule", {
                value: !0
            });
            var e = !1;
            n.config = {
                Promise: void 0,
                set useDeprecatedSynchronousErrorHandling(l) {
                    if (l) {
                        var n = new Error;
                        console.warn("DEPRECATED! RxJS was set to use deprecated synchronous error handling behavior by code at: \n" + n.stack)
                    } else e && console.log("RxJS: Back to a better error behavior. Thank you. <3");
                    e = l
                },
                get useDeprecatedSynchronousErrorHandling() {
                    return e
                }
            }
        },
        nzqU: function(l, n, t) {
            "use strict";
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.isScheduler = function(l) {
                return l && "function" == typeof l.schedule
            }
        },
        "p//D": function(l, n, t) {
            "use strict";
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.rxSubscriber = "function" == typeof Symbol ? Symbol("rxSubscriber") : "@@rxSubscriber_" + Math.random(), n.$$rxSubscriber = n.rxSubscriber
        },
        "p0+S": function(l, n, t) {
            "use strict";
            Object.defineProperty(n, "__esModule", {
                value: !0
            });
            var e = t("mbIT");
            n.isNumeric = function(l) {
                return !e.isArray(l) && l - parseFloat(l) + 1 >= 0
            }
        },
        pshJ: function(l, n, t) {
            "use strict";
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.isFunction = function(l) {
                return "function" == typeof l
            }
        },
        w5QO: function(l, n, t) {
            "use strict";
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.noop = function() {}
        },
        yx2s: function(l, n, t) {
            "use strict";
            Object.defineProperty(n, "__esModule", {
                value: !0
            });
            var e = t("FWf1");
            n.canReportError = function(l) {
                for (; l;) {
                    var n = l,
                        t = n.closed,
                        u = n.destination,
                        r = n.isStopped;
                    if (t || r) return !1;
                    l = u && u instanceof e.Subscriber ? u : null
                }
                return !0
            }
        },
        "zB/H": function(l, n, t) {
            "use strict";
            Object.defineProperty(n, "__esModule", {
                value: !0
            });
            var e = t("mbIT"),
                u = t("GMZp"),
                r = t("pshJ"),
                o = t("LBXl"),
                i = function() {
                    function l(l) {
                        this.closed = !1, this._parentOrParents = null, this._subscriptions = null, l && (this._unsubscribe = l)
                    }
                    var n;
                    return l.prototype.unsubscribe = function() {
                        var n;
                        if (!this.closed) {
                            var t = this._parentOrParents,
                                i = this._unsubscribe,
                                a = this._subscriptions;
                            if (this.closed = !0, this._parentOrParents = null, this._subscriptions = null, t instanceof l) t.remove(this);
                            else if (null !== t)
                                for (var s = 0; s < t.length; ++s) {
                                    t[s].remove(this)
                                }
                            if (r.isFunction(i)) try {
                                i.call(this)
                            } catch (f) {
                                n = f instanceof o.UnsubscriptionError ? c(f.errors) : [f]
                            }
                            if (e.isArray(a)) {
                                s = -1;
                                for (var b = a.length; ++s < b;) {
                                    var d = a[s];
                                    if (u.isObject(d)) try {
                                        d.unsubscribe()
                                    } catch (f) {
                                        n = n || [], f instanceof o.UnsubscriptionError ? n = n.concat(c(f.errors)) : n.push(f)
                                    }
                                }
                            }
                            if (n) throw new o.UnsubscriptionError(n)
                        }
                    }, l.prototype.add = function(n) {
                        var t = n;
                        if (!n) return l.EMPTY;
                        switch (typeof n) {
                            case "function":
                                t = new l(n);
                            case "object":
                                if (t === this || t.closed || "function" != typeof t.unsubscribe) return t;
                                if (this.closed) return t.unsubscribe(), t;
                                if (!(t instanceof l)) {
                                    var e = t;
                                    (t = new l)._subscriptions = [e]
                                }
                                break;
                            default:
                                throw new Error("unrecognized teardown " + n + " added to Subscription.")
                        }
                        var u = t._parentOrParents;
                        if (null === u) t._parentOrParents = this;
                        else if (u instanceof l) {
                            if (u === this) return t;
                            t._parentOrParents = [u, this]
                        } else {
                            if (-1 !== u.indexOf(this)) return t;
                            u.push(this)
                        }
                        var r = this._subscriptions;
                        return null === r ? this._subscriptions = [t] : r.push(t), t
                    }, l.prototype.remove = function(l) {
                        var n = this._subscriptions;
                        if (n) {
                            var t = n.indexOf(l); - 1 !== t && n.splice(t, 1)
                        }
                    }, l.EMPTY = ((n = new l).closed = !0, n), l
                }();

            function c(l) {
                return l.reduce((function(l, n) {
                    return l.concat(n instanceof o.UnsubscriptionError ? n.errors : n)
                }), [])
            }
            n.Subscription = i
        },
        zfKp: function(l, n, t) {
            "use strict";
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.observable = "function" == typeof Symbol && Symbol.observable || "@@observable"
        }
    }
]);