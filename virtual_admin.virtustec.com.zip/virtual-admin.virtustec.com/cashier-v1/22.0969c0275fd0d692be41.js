(window.webpackJsonp = window.webpackJsonp || []).push([
    [22], {
        AZBE: function(e, n, t) {
            "use strict";
            t.r(n), t.d(n, "KenoModuleNgFactory", (function() {
                return Ge
            }));
            var l = t("CcnG"),
                o = function() {},
                s = t("pMnS"),
                i = t("qIYQ"),
                u = t("2z2z"),
                d = t("mYlp"),
                r = t("E6sH"),
                c = t("1UiX"),
                a = t("cS+c"),
                b = t("Md+g"),
                m = t("eZM8"),
                p = t("fHz3"),
                _ = t("iGSx"),
                h = t("l+fh"),
                g = t("Ip0R"),
                f = t("5EE+"),
                k = t("CrY/"),
                y = function() {
                    function e() {
                        this.oddSelectedOddsIds = [], this.oddSelectedOddsIdsChange = new l.q, this.odds = [
                            [k.KnOdds.first_single, k.KnOdds.first_notsingle, k.KnOdds.last_single, k.KnOdds.last_notsingle, k.KnOdds.first_even, k.KnOdds.first_odd, k.KnOdds.last_even, k.KnOdds.last_odd, k.KnOdds.first_under_40_5, k.KnOdds.first_over_40_5, k.KnOdds.last_under_40_5, k.KnOdds.last_over_40_5],
                            [k.KnOdds.sum_under_810_5, k.KnOdds.sum_over_810_5, k.KnOdds.sum_first_5_under_202_5, k.KnOdds.sum_first_5_over_202_5]
                        ]
                    }
                    return e.prototype.ngOnInit = function() {}, e.prototype.isSelected = function(e) {
                        return this.oddSelectedOddsIds.includes(e)
                    }, e.prototype.onSelect = function(e) {
                        this.isSelected(e) ? this.oddSelectedOddsIds = this.oddSelectedOddsIds.filter((function(n) {
                            return n !== e
                        })) : this.oddSelectedOddsIds.push(e), this.oddSelectedOddsIdsChange.emit(this.oddSelectedOddsIds)
                    }, e
                }(),
                S = [
                    [".keno-markets[_ngcontent-%COMP%]{width:100%;height:100%;font-weight:700}.keno-markets__title[_ngcontent-%COMP%]{margin-bottom:30px;font-size:26px}.keno-markets__odds-container[_ngcontent-%COMP%]:nth-child(even){padding-left:10px}.keno-markets__odds-container[_ngcontent-%COMP%]:nth-child(odd){padding-right:10px}.keno-markets__odd[_ngcontent-%COMP%]{padding:16px 0;margin-bottom:20px;font-size:22px;border-radius:2px}"]
                ],
                O = l.Gb({
                    encapsulation: 0,
                    styles: S,
                    data: {}
                });

            function v(e) {
                return l.ec(0, [(e()(), l.Ib(0, 0, null, null, 6, "div", [
                    ["class", "col grid keno-markets__odds-container"]
                ], null, null, null, null, null)), (e()(), l.Ib(1, 0, null, null, 5, "div", [
                    ["class", "col grid grid-center grid-middle keno-markets__odd"]
                ], null, [
                    [null, "click"]
                ], (function(e, n, t) {
                    var l = !0,
                        o = e.component;
                    "click" === n && (l = !1 !== o.onSelect(e.context.$implicit) && l);
                    return l
                }), null, null)), l.Zb(512, null, g.x, g.y, [l.A, l.B, l.o, l.P]), l.Hb(3, 278528, null, 0, g.k, [g.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), l.Xb(4, {
                    "keno-markets__odd--selected": 0
                }), (e()(), l.cc(5, null, [" ", " "])), l.Wb(131072, f.r, [f.k, l.i])], (function(e, n) {
                    var t = e(n, 4, 0, n.component.isSelected(n.context.$implicit));
                    e(n, 3, 0, "col grid grid-center grid-middle keno-markets__odd", t)
                }), (function(e, n) {
                    e(n, 5, 0, l.dc(n, 5, 0, l.Ub(n, 6).transform(n.context.$implicit, "KN")))
                }))
            }

            function C(e) {
                return l.ec(2, [(e()(), l.Ib(0, 0, null, null, 6, "div", [
                    ["class", "grid grid-column keno-markets"]
                ], null, null, null, null, null)), (e()(), l.Ib(1, 0, null, null, 2, "div", [
                    ["class", "keno-markets__title"]
                ], null, null, null, null, null)), (e()(), l.cc(2, null, ["", ""])), l.Wb(131072, f.q, [f.k, l.i]), (e()(), l.Ib(4, 0, null, null, 2, "div", [
                    ["class", "col grid grid-2"]
                ], null, null, null, null, null)), (e()(), l.xb(16777216, null, null, 1, null, v)), l.Hb(6, 278528, null, 0, g.l, [l.eb, l.Z, l.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(e, n) {
                    var t = n.component;
                    e(n, 6, 0, t.odds[t.marketsGroup])
                }), (function(e, n) {
                    var t = n.component;
                    e(n, 2, 0, l.dc(n, 2, 0, l.Ub(n, 3).transform(0 === t.marketsGroup ? "number_bets" : "sum_bets")))
                }))
            }
            l.Eb("grc-keno-markets", y, (function(e) {
                return l.ec(0, [(e()(), l.Ib(0, 0, null, null, 1, "grc-keno-markets", [], null, null, null, C, O)), l.Hb(1, 114688, null, 0, y, [], null, null)], (function(e, n) {
                    e(n, 1, 0)
                }), null)
            }), {
                marketsGroup: "marketsGroup",
                oddSelectedOddsIds: "oddSelectedOddsIds"
            }, {
                oddSelectedOddsIdsChange: "oddSelectedOddsIdsChange"
            }, []);
            var M = function() {
                    function e() {}
                    return e.prototype.ngOnInit = function() {}, e
                }(),
                N = [
                    [".keno-odd[_ngcontent-%COMP%]{display:flex;justify-content:center;align-items:center;height:100%;font-size:26px;letter-spacing:.5px;cursor:pointer;border-radius:5px}.keno-odd--rotate[_ngcontent-%COMP%]::before{font-size:21px;transform:rotate(90deg)}"]
                ],
                I = l.Gb({
                    encapsulation: 0,
                    styles: N,
                    data: {}
                });

            function x(e) {
                return l.ec(0, [(e()(), l.Ib(0, 0, null, null, 2, null, null, null, null, null, null, null)), (e()(), l.Ib(1, 0, null, null, 1, "div", [
                    ["class", "keno-odd"]
                ], null, null, null, null, null)), (e()(), l.cc(2, null, ["", ""]))], null, (function(e, n) {
                    e(n, 2, 0, n.component.title)
                }))
            }

            function E(e) {
                return l.ec(0, [(e()(), l.Ib(0, 0, null, null, 1, null, null, null, null, null, null, null)), (e()(), l.Ib(1, 0, null, null, 0, "div", [
                    ["class", "keno-odd keno-odd--icon icon icon-up"]
                ], [
                    [2, "keno-odd--rotate", null]
                ], null, null, null, null))], null, (function(e, n) {
                    e(n, 1, 0, n.component.isVerticalColumn)
                }))
            }

            function D(e) {
                return l.ec(2, [(e()(), l.xb(16777216, null, null, 1, null, x)), l.Hb(1, 16384, null, 0, g.m, [l.eb, l.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (e()(), l.xb(16777216, null, null, 1, null, E)), l.Hb(3, 16384, null, 0, g.m, [l.eb, l.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(e, n) {
                    var t = n.component;
                    e(n, 1, 0, t.title), e(n, 3, 0, !t.title)
                }), null)
            }
            l.Eb("grc-keno-odd", M, (function(e) {
                return l.ec(0, [(e()(), l.Ib(0, 0, null, null, 1, "grc-keno-odd", [], null, null, null, D, I)), l.Hb(1, 114688, null, 0, M, [], null, null)], (function(e, n) {
                    e(n, 1, 0)
                }), null)
            }), {
                title: "title",
                isVerticalColumn: "isVerticalColumn"
            }, {}, []);
            var T = function() {
                    function e() {
                        this.selectedNumbers = [], this.selectedButton = k.KN_NUMBER_ODD_MODE.NUMBER, this.isDeluxe = !1, this.selectedNumbersChange = new l.q, this.selectedButtonChange = new l.q, this.KN_NUMBER_ODD_MODE = k.KN_NUMBER_ODD_MODE, this.numbersOddsModes = [{
                            title: "ch_numbers",
                            mode: k.KN_NUMBER_ODD_MODE.NUMBER
                        }, {
                            title: "ch_all_in",
                            mode: k.KN_NUMBER_ODD_MODE.ALL
                        }, {
                            title: "ch_no_draw",
                            mode: k.KN_NUMBER_ODD_MODE.NODRAW
                        }], this.selectedState = [!1, !1, !1, !1, !1, !1, !1, !1], this.odds = [];
                        for (var e = 1; e <= 80; e += 1) this.odds.push({
                            number: e
                        })
                    }
                    return e.prototype.ngOnInit = function() {}, e.prototype.onSelectNumber = function(e) {
                        !this.isNumberSelected(e) && this.selectedNumbers.length <= this.maxPickNumbersLength - 1 ? this.selectedNumbers.push(e) : this.selectedNumbers = this.selectedNumbers.filter((function(n) {
                            return n !== e
                        })), this.selectedNumbersChange.emit(this.selectedNumbers)
                    }, e.prototype.isNumberSelected = function(e) {
                        return this.selectedNumbers && this.selectedNumbers.includes(e)
                    }, e.prototype.selectAllColumnOrRow = function(e, n) {
                        this.selectedState[e] = !this.isAllColumnOrRowSelected(e), "column" === n ? this.selectedState[e] ? (this.selectedNumbers = [], this.includeAllColumnNumbers(e)) : this.deleteAllColumnNumbers(e) : this.includeAllRowNumbers(e)
                    }, e.prototype.setSelectedButton = function(e) {
                        this.selectedButton = e, this.selectedButtonChange.emit(this.selectedButton)
                    }, e.prototype.isAllColumnOrRowSelected = function(e) {
                        var n = !1;
                        return this.getElementsSelected(e) === this.maxPickNumbersLength && (n = !0), n
                    }, e.prototype.getElementsSelected = function(e) {
                        var n = 0;
                        return this.selectedNumbers.forEach((function(t) {
                            t % 10 === e && (n += 1)
                        })), n
                    }, e.prototype.includeAllColumnNumbers = function(e) {
                        var n = this;
                        this.odds.forEach((function(t) {
                            t.number % 10 !== e || n.isNumberSelected(t.number) || n.selectedNumbers.push(t.number)
                        })), this.selectedNumbersChange.emit(this.selectedNumbers)
                    }, e.prototype.deleteAllColumnNumbers = function(e) {
                        var n = this;
                        this.selectedNumbers = this.selectedNumbers.filter((function(t) {
                            return t % 10 === e && !n.isNumberSelected(t)
                        })), this.selectedNumbersChange.emit(this.selectedNumbers)
                    }, e.prototype.includeAllRowNumbers = function(e) {
                        this.createRandomArray(e), this.selectedNumbersChange.emit(this.selectedNumbers)
                    }, e.prototype.createRandomArray = function(e) {
                        var n = this,
                            t = [];
                        (t = Array.from({
                            length: this.maxPickNumbersLength
                        }, (function() {
                            return n.generateRandomValue(e)
                        }))).forEach((function(l, o) {
                            t.filter((function(e) {
                                return e === l
                            })).length >= 2 && (t[o] = n.getRandomValue(t, e))
                        })), this.selectedNumbers = t
                    }, e.prototype.generateRandomValue = function(e) {
                        var n = Math.ceil(10 * e - 10 + 1),
                            t = Math.floor(10 * e + 1);
                        return Math.floor(Math.random() * (t - n) + n)
                    }, e.prototype.getRandomValue = function(e, n) {
                        void 0 === e && (e = []);
                        for (var t = this.generateRandomValue(n); this.isIncluded(e, t);) t = this.generateRandomValue(n);
                        return t
                    }, e.prototype.isIncluded = function(e, n) {
                        return void 0 === e && (e = []), e.includes(n)
                    }, e
                }(),
                P = [
                    ["[_nghost-%COMP%] > .grid[_ngcontent-%COMP%]{height:100%}[_nghost-%COMP%] > .grid[_ngcontent-%COMP%] > .col[_ngcontent-%COMP%]{margin:-2px}[_nghost-%COMP%] > .grid[_ngcontent-%COMP%] > .col[_ngcontent-%COMP%] > .col[_ngcontent-%COMP%]{padding:2px}.bet-table-odd[_ngcontent-%COMP%]{font-size:36px;font-weight:700;text-transform:capitalize}.bet-table-odd__title[_ngcontent-%COMP%]{margin-bottom:25px}.bet-table-odd__buttons[_ngcontent-%COMP%]{margin-bottom:18px;font-size:16px;text-transform:uppercase;border-radius:1px}.bet-table-odd__button[_ngcontent-%COMP%]{padding:12px 11px;margin-bottom:18px}.bet-table-odd__vertical-column[_ngcontent-%COMP%]{height:calc(100% - 67px);margin:0}.bet-table-odd__vertical-column[_ngcontent-%COMP%] > *[_ngcontent-%COMP%]{padding:0 0 4px}.bet-table-odd__horizontal-column[_ngcontent-%COMP%]{margin:0 -2px}.bet-table-odd__horizontal-column[_ngcontent-%COMP%] > *[_ngcontent-%COMP%]{padding:0 2px 4px}"]
                ],
                B = l.Gb({
                    encapsulation: 0,
                    styles: P,
                    data: {}
                });

            function w(e) {
                return l.ec(0, [(e()(), l.Ib(0, 0, null, null, 5, "div", [
                    ["class", "bet-table-odd__button"]
                ], null, [
                    [null, "click"]
                ], (function(e, n, t) {
                    var l = !0,
                        o = e.component;
                    "click" === n && (l = !1 !== o.setSelectedButton(e.context.$implicit.mode) && l);
                    return l
                }), null, null)), l.Zb(512, null, g.x, g.y, [l.A, l.B, l.o, l.P]), l.Hb(2, 278528, null, 0, g.k, [g.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), l.Xb(3, {
                    "bet-table-odd__button--selected": 0
                }), (e()(), l.cc(4, null, [" ", " "])), l.Wb(131072, f.j, [f.k, l.i])], (function(e, n) {
                    var t = e(n, 3, 0, n.component.selectedButton === n.context.$implicit.mode);
                    e(n, 2, 0, "bet-table-odd__button", t)
                }), (function(e, n) {
                    e(n, 4, 0, l.dc(n, 4, 0, l.Ub(n, 5).transform(n.context.$implicit.title)))
                }))
            }

            function R(e) {
                return l.ec(0, [(e()(), l.Ib(0, 0, null, null, 2, "div", [
                    ["class", "grid grid-3 grid-space-around bet-table-odd__buttons"]
                ], null, null, null, null, null)), (e()(), l.xb(16777216, null, null, 1, null, w)), l.Hb(2, 278528, null, 0, g.l, [l.eb, l.Z, l.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(e, n) {
                    e(n, 2, 0, n.component.numbersOddsModes)
                }), null)
            }

            function K(e) {
                return l.ec(0, [(e()(), l.Ib(0, 0, null, null, 1, "grc-keno-odd", [
                    ["class", "col"]
                ], null, [
                    [null, "click"]
                ], (function(e, n, t) {
                    var l = !0,
                        o = e.component;
                    "click" === n && (l = !1 !== o.selectAllColumnOrRow(e.context.$implicit, "row") && l);
                    return l
                }), D, I)), l.Hb(1, 114688, null, 0, M, [], {
                    isVerticalColumn: [0, "isVerticalColumn"]
                }, null)], (function(e, n) {
                    e(n, 1, 0, !0)
                }), null)
            }

            function H(e) {
                return l.ec(0, [(e()(), l.Ib(0, 0, null, null, 1, "grc-keno-odd", [
                    ["class", "col"]
                ], [
                    [2, "bet-table-odd--selected", null]
                ], [
                    [null, "click"]
                ], (function(e, n, t) {
                    var l = !0,
                        o = e.component;
                    "click" === n && (l = !1 !== o.onSelectNumber(e.context.$implicit.number) && l);
                    return l
                }), D, I)), l.Hb(1, 114688, null, 0, M, [], {
                    title: [0, "title"]
                }, null)], (function(e, n) {
                    e(n, 1, 0, n.context.$implicit.number)
                }), (function(e, n) {
                    e(n, 0, 0, n.component.isNumberSelected(n.context.$implicit.number))
                }))
            }

            function L(e) {
                return l.ec(0, [(e()(), l.Ib(0, 0, null, null, 1, "grc-keno-odd", [
                    ["class", "col"]
                ], null, [
                    [null, "click"]
                ], (function(e, n, t) {
                    var l = !0,
                        o = e.component;
                    "click" === n && (l = !1 !== o.selectAllColumnOrRow(e.context.$implicit, "column") && l);
                    return l
                }), D, I)), l.Hb(1, 114688, null, 0, M, [], null, null)], (function(e, n) {
                    e(n, 1, 0)
                }), null)
            }

            function U(e) {
                return l.ec(2, [(e()(), l.Ib(0, 0, null, null, 17, "div", [
                    ["class", "grid grid-column bet-table-odd"]
                ], null, null, null, null, null)), (e()(), l.Ib(1, 0, null, null, 5, "div", [
                    ["class", "grid grid-space-between"]
                ], null, null, null, null, null)), (e()(), l.Ib(2, 0, null, null, 2, "div", [
                    ["class", "bet-table-odd__title"]
                ], null, null, null, null, null)), (e()(), l.cc(3, null, ["", ""])), l.Wb(131072, f.q, [f.k, l.i]), (e()(), l.xb(16777216, null, null, 1, null, R)), l.Hb(6, 16384, null, 0, g.m, [l.eb, l.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (e()(), l.Ib(7, 0, null, null, 10, "div", [
                    ["class", "col grid"]
                ], null, null, null, null, null)), (e()(), l.Ib(8, 0, null, null, 3, "div", [
                    ["class", "col col-1 grid grid-column bet-table-odd__vertical-column"]
                ], null, null, null, null, null)), (e()(), l.xb(16777216, null, null, 2, null, K)), l.Hb(10, 278528, null, 0, g.l, [l.eb, l.Z, l.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), l.Vb(11, 8), (e()(), l.Ib(12, 0, null, null, 5, "div", [
                    ["class", "col grid grid-10 bet-table-odd__horizontal-column"]
                ], null, null, null, null, null)), (e()(), l.xb(16777216, null, null, 1, null, H)), l.Hb(14, 278528, null, 0, g.l, [l.eb, l.Z, l.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), (e()(), l.xb(16777216, null, null, 2, null, L)), l.Hb(16, 278528, null, 0, g.l, [l.eb, l.Z, l.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), l.Vb(17, 10)], (function(e, n) {
                    var t = n.component;
                    e(n, 6, 0, t.isDeluxe);
                    var l = e(n, 11, 0, 1, 2, 3, 4, 5, 6, 7, 8);
                    e(n, 10, 0, l), e(n, 14, 0, t.odds);
                    var o = e(n, 17, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0);
                    e(n, 16, 0, o)
                }), (function(e, n) {
                    e(n, 3, 0, l.dc(n, 3, 0, l.Ub(n, 4).transform("pick_numbers")))
                }))
            }
            l.Eb("grc-keno-bet-table", T, (function(e) {
                return l.ec(0, [(e()(), l.Ib(0, 0, null, null, 1, "grc-keno-bet-table", [], null, null, null, U, B)), l.Hb(1, 114688, null, 0, T, [], null, null)], (function(e, n) {
                    e(n, 1, 0)
                }), null)
            }), {
                selectedNumbers: "selectedNumbers",
                maxPickNumbersLength: "maxPickNumbersLength",
                selectedButton: "selectedButton",
                isDeluxe: "isDeluxe"
            }, {
                selectedNumbersChange: "selectedNumbersChange",
                selectedButtonChange: "selectedButtonChange"
            }, []);
            var A, V, F = t("mv7g"),
                G = t("+69r"),
                q = t("XAsR"),
                X = t("M3um"),
                W = t("GhKF"),
                j = t("3cbp"),
                z = t("VYBt"),
                Z = t("5y7H"),
                $ = t("Poww"),
                Q = t("D3N7"),
                Y = t("WGel"),
                J = t("n3kJ"),
                ee = t("K9Ia"),
                ne = t("67Y/"),
                te = t("ijKR"),
                le = t("31BE"),
                oe = t("ftDe"),
                se = t("pugT"),
                ie = (A = function(e, n) {
                    return (A = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(e, n) {
                            e.__proto__ = n
                        } || function(e, n) {
                            for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (e[t] = n[t])
                        })(e, n)
                }, function(e, n) {
                    function t() {
                        this.constructor = e
                    }
                    A(e, n), e.prototype = null === n ? Object.create(n) : (t.prototype = n.prototype, new t)
                }),
                ue = function(e) {
                    function n() {
                        var n = null !== e && e.apply(this, arguments) || this;
                        return n.buttons = [{
                            title: "gr_mk_ch_number_bets"
                        }, {
                            title: "gr_mk_ch_allin_nodraw"
                        }, {
                            title: "gr_mk_ch_extra_markets"
                        }], n.selected = 0, n.kenoMarketsTitles = [
                            ["ten_picks", "nine_picks", "eight_picks", "seven_picks", "six_picks", "five_picks", "four_picks", "three_picks", "two_picks", "one_picks"],
                            ["all_in", "no_draw"],
                            ["number_bets", "sum_bets"]
                        ], n.kenoOdds = [
                            [
                                [{
                                    odd: "numbers_10_10",
                                    oddNameToDisplay: "numbers_10"
                                }, {
                                    odd: "numbers_10_9",
                                    oddNameToDisplay: "numbers_9"
                                }, {
                                    odd: "numbers_10_8",
                                    oddNameToDisplay: "numbers_8"
                                }, {
                                    odd: "numbers_10_7",
                                    oddNameToDisplay: "numbers_7"
                                }, {
                                    odd: "numbers_10_6",
                                    oddNameToDisplay: "numbers_6"
                                }, {
                                    odd: "numbers_10_5",
                                    oddNameToDisplay: "numbers_5"
                                }],
                                [{
                                    odd: "numbers_9_9",
                                    oddNameToDisplay: "numbers_9"
                                }, {
                                    odd: "numbers_9_8",
                                    oddNameToDisplay: "numbers_8"
                                }, {
                                    odd: "numbers_9_7",
                                    oddNameToDisplay: "numbers_7"
                                }, {
                                    odd: "numbers_9_6",
                                    oddNameToDisplay: "numbers_6"
                                }, {
                                    odd: "numbers_9_5",
                                    oddNameToDisplay: "numbers_5"
                                }, {
                                    odd: "numbers_9_4",
                                    oddNameToDisplay: "numbers_4"
                                }],
                                [{
                                    odd: "numbers_8_8",
                                    oddNameToDisplay: "numbers_8"
                                }, {
                                    odd: "numbers_8_7",
                                    oddNameToDisplay: "numbers_7"
                                }, {
                                    odd: "numbers_8_6",
                                    oddNameToDisplay: "numbers_6"
                                }, {
                                    odd: "numbers_8_5",
                                    oddNameToDisplay: "numbers_5"
                                }, {
                                    odd: "numbers_8_4",
                                    oddNameToDisplay: "numbers_4"
                                }],
                                [{
                                    odd: "numbers_7_7",
                                    oddNameToDisplay: "numbers_7"
                                }, {
                                    odd: "numbers_7_6",
                                    oddNameToDisplay: "numbers_6"
                                }, {
                                    odd: "numbers_7_5",
                                    oddNameToDisplay: "numbers_5"
                                }, {
                                    odd: "numbers_7_4",
                                    oddNameToDisplay: "numbers_4"
                                }, {
                                    odd: "numbers_7_3",
                                    oddNameToDisplay: "numbers_3"
                                }],
                                [{
                                    odd: "numbers_6_6",
                                    oddNameToDisplay: "numbers_6"
                                }, {
                                    odd: "numbers_6_5",
                                    oddNameToDisplay: "numbers_5"
                                }, {
                                    odd: "numbers_6_4",
                                    oddNameToDisplay: "numbers_4"
                                }, {
                                    odd: "numbers_6_3",
                                    oddNameToDisplay: "numbers_3"
                                }],
                                [{
                                    odd: "numbers_5_5",
                                    oddNameToDisplay: "numbers_5"
                                }, {
                                    odd: "numbers_5_4",
                                    oddNameToDisplay: "numbers_4"
                                }, {
                                    odd: "numbers_5_3",
                                    oddNameToDisplay: "numbers_3"
                                }, {
                                    odd: "numbers_5_2",
                                    oddNameToDisplay: "numbers_2"
                                }],
                                [{
                                    odd: "numbers_4_4",
                                    oddNameToDisplay: "numbers_4"
                                }, {
                                    odd: "numbers_4_3",
                                    oddNameToDisplay: "numbers_3"
                                }, {
                                    odd: "numbers_4_2",
                                    oddNameToDisplay: "numbers_2"
                                }],
                                [{
                                    odd: "numbers_3_3",
                                    oddNameToDisplay: "numbers_3"
                                }, {
                                    odd: "numbers_3_2",
                                    oddNameToDisplay: "numbers_2"
                                }],
                                [{
                                    odd: "numbers_2_2",
                                    oddNameToDisplay: "numbers_2"
                                }, {
                                    odd: "numbers_2_1",
                                    oddNameToDisplay: "numbers_1"
                                }],
                                [{
                                    odd: "numbers_1_1",
                                    oddNameToDisplay: "numbers_1"
                                }]
                            ],
                            [
                                [{
                                    odd: "all_in_10"
                                }, {
                                    odd: "all_in_9"
                                }, {
                                    odd: "all_in_8"
                                }, {
                                    odd: "all_in_7"
                                }, {
                                    odd: "all_in_6"
                                }, {
                                    odd: "all_in_5"
                                }, {
                                    odd: "all_in_4"
                                }, {
                                    odd: "all_in_3"
                                }, {
                                    odd: "all_in_2"
                                }, {
                                    odd: "all_in_1"
                                }],
                                [{
                                    odd: "no_draw_10"
                                }, {
                                    odd: "no_draw_9"
                                }, {
                                    odd: "no_draw_8"
                                }, {
                                    odd: "no_draw_7"
                                }, {
                                    odd: "no_draw_6"
                                }, {
                                    odd: "no_draw_5"
                                }, {
                                    odd: "no_draw_4"
                                }, {
                                    odd: "no_draw_3"
                                }, {
                                    odd: "no_draw_2"
                                }, {
                                    odd: "no_draw_1"
                                }]
                            ],
                            [
                                [{
                                    odd: "first_single"
                                }, {
                                    odd: "first_notsingle"
                                }, {
                                    odd: "last_single"
                                }, {
                                    odd: "last_notsingle"
                                }, {
                                    odd: "first_even"
                                }, {
                                    odd: "first_odd"
                                }, {
                                    odd: "last_even"
                                }, {
                                    odd: "last_odd"
                                }],
                                [{
                                    odd: "sum_under_810_5"
                                }, {
                                    odd: "sum_over_810_5"
                                }, {
                                    odd: "first_under_40_5"
                                }, {
                                    odd: "first_over_40_5"
                                }, {
                                    odd: "sum_first_5_under_202_5"
                                }, {
                                    odd: "sum_first_5_over_202_5"
                                }, {
                                    odd: "last_under_40_5"
                                }, {
                                    odd: "last_over_40_5"
                                }]
                            ]
                        ], n.columnsPerRow = [0, 0, 0], n.hasX = !0, n.isKinel8 = !1, n.subscription = new se.a, n
                    }
                    return ie(n, e), n.prototype.ngOnInit = function() {
                        this.isDeluxe() || (this.buttons = [], this.kenoMarketsTitles = [this.kenoMarketsTitles.slice(0, 1)[0].slice(2, 10)], this.kenoOdds = [this.kenoOdds.slice(0, 1)[0].slice(2, 10)]), this.calculateColumnsPerRow(), this.setPaytableInfo(this.kenoMarketsTitles[this.selected], this.kenoOdds[this.selected]), this.isKinel8 = this.playlist && this.playlist.assets && "kinel8" === this.playlist.assets.iconId, this.subscribeSelectedChange()
                    }, n.prototype.ngOnDestroy = function() {
                        this.subscription.unsubscribe()
                    }, n.prototype.subscribeSelectedChange = function() {
                        var e = this;
                        this.subscription.add(this.selectedChange.subscribe((function(n) {
                            e.selected = n, e.calculateColumnsPerRow(), e.setPaytableInfo(e.kenoMarketsTitles[e.selected], e.kenoOdds[e.selected])
                        })))
                    }, n.prototype.calculateColumnsPerRow = function() {
                        var e = Math.floor(this.kenoMarketsTitles[this.selected].length / 2);
                        this.columnsPerRow[this.selected] = 0 === this.selected ? e : e + 1
                    }, n.prototype.isDeluxe = function() {
                        return this.playlist.filter && this.playlist.filter.isKnFilter() && this.playlist.filter.mode === k.coreModel.KnFilter.ModeEnum.DELUXE
                    }, n
                }(oe.a),
                de = function() {
                    var e = function(n, t) {
                        return (e = Object.setPrototypeOf || {
                                __proto__: []
                            }
                            instanceof Array && function(e, n) {
                                e.__proto__ = n
                            } || function(e, n) {
                                for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (e[t] = n[t])
                            })(n, t)
                    };
                    return function(n, t) {
                        function l() {
                            this.constructor = n
                        }
                        e(n, t), n.prototype = null === t ? Object.create(t) : (l.prototype = t.prototype, new l)
                    }
                }();
            ! function(e) {
                e.CLASSIC = "CLASSIC", e.DELUXE = "DELUXE", e.KINEL8 = "KINEL8", e.LIVE = "LIVE"
            }(V || (V = {}));
            var re = function(e) {
                    function n(n, t) {
                        var l = e.call(this, n) || this;
                        return l.shopAdminService = t, l.isDeluxe = !1, l.kenoTypeEnum = V, l.quickNumbers = [], l.oddSelectedOddsIds = [], l.selectedButton = k.KN_NUMBER_ODD_MODE.NUMBER, l.quickMultiplierTabSelected = "quick-pick", l.multiplier = new ee.a, l.maxMultiplier = 0, l.odds = [], l
                    }
                    return de(n, e), n.prototype.createRandomArray = function(e) {
                        var n = this,
                            t = [];
                        (t = Array.from({
                            length: e
                        }, (function() {
                            return n.generateRandomValue()
                        }))).forEach((function(e, l) {
                            t.filter((function(n) {
                                return n === e
                            })).length >= 2 && (t[l] = n.getRandomValue(t))
                        })), this.numbersSelected = t, this.updateBetslipConfiguration()
                    }, n.prototype.maxPickNumbersLength = function() {
                        return this.getKenoMode() === k.coreModel.KnFilter.ModeEnum.DELUXE ? 10 : 8
                    }, n.prototype.onSelectedNumbers = function(e) {
                        this.numbersSelected = e, this.updateBetslipConfiguration()
                    }, n.prototype.onOddSelectedOddsIds = function(e) {
                        this.oddSelectedOddsIds = e, this.updateBetslipConfiguration()
                    }, n.prototype.onTabQuickMultiplierChange = function(e) {
                        this.quickMultiplierTabSelected = e, this.cd.markForCheck()
                    }, n.prototype.onMultiplierSelected = function(e) {
                        this.multiplier.next(e), "multiplier" === this.quickMultiplierTabSelected && document.getElementsByClassName("tab-header--multiplier")[0].click(), this.betslipService.setMultiplier(e), this.cd.markForCheck()
                    }, n.prototype.onMultiplierValidation = function(e) {
                        e && this.notificationsService.warning("" + this.i18NService.get("ch_lower_multiplier"))
                    }, n.prototype.getMaxMultiplier = function() {
                        return this.betslipService.getMaxMultiplier()
                    }, n.prototype.onBeforeInit = function() {
                        var n = this;
                        return this.subscriptions.add(this.betslipService.onClear.subscribe((function() {
                            n.resetMultiplier(), n.cd.markForCheck()
                        }))), this.subscriptions.add(this.betslipService.onStake.subscribe((function() {
                            n.resetMultiplier(), setTimeout((function() {
                                return n.cd.detectChanges()
                            }), 0)
                        }))), this.multiplier.next(1), e.prototype.onBeforeInit.call(this).pipe(Object(ne.a)((function() {
                            n.event = n.eventBlock && n.eventBlock.events[0], n.onClearBetslipUserSelections(), n.baseService.activateGame(!0), n.quickNumbers = n.getQuickPickNumbers()
                        })))
                    }, n.prototype.getEBControllerConfigItem = function() {
                        return {
                            windowOpenSize: 19
                        }
                    }, n.prototype.configureBetslip = function() {
                        var e = this;
                        this.kenoType = this.setModeType(), this.betslipService.setConfiguration({
                            hasMultiplier: this.kenoType !== V.LIVE,
                            betMode: k.BetModeEnum.SINGLEBETMODE,
                            preStake: function() {
                                return e.createBets()
                            },
                            prefixMarket: function(n) {
                                return e.getBetslipTitle(n)
                            },
                            oddName: function(n) {
                                return e.getOddName(n)
                            }
                        })
                    }, n.prototype.configureHeader = function() {
                        var e = this;
                        this.baseService.setHeaderState({
                            gameName: this.playlist.descriptionTag,
                            eventName: "#" + this.getEventId(),
                            countdownEventBlockController: this.eventBlockController,
                            playList: this.playlist,
                            buttons: [{
                                title: "ch_pay_table",
                                callback: function() {
                                    return e.openPaytableComponent()
                                },
                                shortcuts: [J.a.PayTable]
                            }, {
                                title: "ch_results_history",
                                callback: function() {
                                    return e.shopAdminService.openResultHistory(e.playlist)
                                },
                                shortcuts: [J.a.ResultHistory],
                                disabled: !this.isResultsHistoryButtonVisible()
                            }]
                        })
                    }, n.prototype.onEventBlockControllerReadyToStart = function(e) {
                        this.event = e.events[0]
                    }, n.prototype.onEventBlockControllerClosedMarkets = function(e) {
                        this.onClearBetslipUserSelections()
                    }, n.prototype.onClearBetslipUserSelections = function() {
                        this.selectedButton = k.KN_NUMBER_ODD_MODE.NUMBER, this.numbersSelected = [], this.odds = [], this.oddSelectedOddsIds = [], this.updateBetslipConfiguration()
                    }, n.prototype.resetMultiplier = function() {
                        this.betslipMultiplier && this.betslipMultiplier.resetMultiplier()
                    }, n.prototype.isResultsHistoryButtonVisible = function() {
                        return this.betslipService.getShopadminProfileSettings().showResults
                    }, n.prototype.getOddName = function(e) {
                        var n = "" + this.i18NService.getMarketTag(e.oddId);
                        switch (e.marketId) {
                            case k.KnMarkets.numbers:
                            case k.KnMarkets.all_in:
                            case k.KnMarkets.no_draw:
                                n = "" + this.i18NService.getMarketOptionTag(Y.I18NGameType.KN, e.oddId, void 0, e.betParam)
                        }
                        return n
                    }, n.prototype.getBetslipTitle = function(e) {
                        var n = "";
                        switch (e.marketId) {
                            case k.KnMarkets.numbers:
                            case k.KnMarkets.all_in:
                            case k.KnMarkets.no_draw:
                                n = this.i18NService.getMarketGroupTag(e.marketId, "s") + ": "
                        }
                        return n
                    }, n.prototype.openPaytableComponent = function() {
                        var e = this;
                        this.modalService.open("base-information", ue, {
                            inputs: {
                                playlist: this.playlist,
                                currentPayTable: this.getCurrentPayTable()
                            },
                            outputs: {
                                close: function() {
                                    e.modalService.close("base-information")
                                }
                            }
                        })
                    }, n.prototype.getEventId = function() {
                        return this.eventBlock && this.eventBlock.events[0].eventId
                    }, n.prototype.generateRandomValue = function() {
                        return Math.floor(80 * Math.random() + 1)
                    }, n.prototype.getRandomValue = function(e) {
                        void 0 === e && (e = []);
                        for (var n = this.generateRandomValue(); this.isIncluded(e, n);) n = this.generateRandomValue();
                        return n
                    }, n.prototype.isIncluded = function(e, n) {
                        return void 0 === e && (e = []), e.includes(n)
                    }, n.prototype.createBets = function() {
                        this.createOddsForSelectedNumbers(), this.createOdds(), this.odds.length > 0 && this.betslipService.addBets(this.odds), this.onClearBetslipUserSelections(), this.cd.detectChanges()
                    }, n.prototype.createOddsForSelectedNumbers = function() {
                        if (this.numbersSelected.length >= 1 && this.numbersSelected.length <= this.maxPickNumbersLength()) {
                            var e = k.SessionController.gameManager.getKnGame().createOddIdForNumers(this.numbersSelected.map((function(e) {
                                    return e.toString()
                                })), this.selectedButton),
                                n = this.event.data._clData.oddMap.get(e.oddId);
                            this.odds.push({
                                playlist: this.playlist,
                                eventBlock: this.eventBlock,
                                event: this.event,
                                odd: {
                                    id: e.oddId,
                                    name: n.name,
                                    probability: n.probability,
                                    k: n.k,
                                    value: n.value,
                                    _clData: n._clData
                                },
                                betParam: e.betParam
                            })
                        }
                    }, n.prototype.createOdds = function() {
                        var e = this;
                        this.oddSelectedOddsIds.length > 0 && this.oddSelectedOddsIds.forEach((function(n) {
                            e.odds.push({
                                playlist: e.playlist,
                                eventBlock: e.eventBlock,
                                event: e.event,
                                odd: e.event.data._clData.oddMap.get(n)
                            })
                        }))
                    }, n.prototype.getQuickPickNumbers = function() {
                        return [1, 2, 3, 4, 5, 6, 7, 8, 9, 10].slice(0, this.maxPickNumbersLength())
                    }, n.prototype.getKenoMode = function() {
                        return this.playlist.filter.isKnFilter() && this.playlist.filter.mode
                    }, n.prototype.setModeType = function() {
                        var e = this.playlist && this.playlist.assets && "kinel8" === this.playlist.assets.iconId,
                            n = this.playlist.mode === k.coreModel.Playlist.ModeEnum.LIVE;
                        return this.isDeluxe = this.getKenoMode() === k.coreModel.KnFilter.ModeEnum.DELUXE, n ? V.LIVE : this.isDeluxe ? V.DELUXE : e ? V.KINEL8 : V.CLASSIC
                    }, n.prototype.updateBetslipConfiguration = function() {
                        this.betslipService.updateConfiguration({
                            hasOptionsSelected: this.numbersSelected.length > 0 || this.oddSelectedOddsIds.length > 0
                        })
                    }, n
                }(le.a),
                ce = [
                    ["[_nghost-%COMP%] > .grid[_ngcontent-%COMP%]{height:100%;padding:15px 20px}[_nghost-%COMP%] > .grid[_ngcontent-%COMP%] > .col[_ngcontent-%COMP%]{padding:15px 20px}[_nghost-%COMP%] > .grid[_ngcontent-%COMP%] > .col[_ngcontent-%COMP%]:first-child{padding-right:340px}[_nghost-%COMP%] > .grid[_ngcontent-%COMP%] > .col[_ngcontent-%COMP%]:last-child{padding-left:340px}[_nghost-%COMP%] > .grid[_ngcontent-%COMP%] > .col[_ngcontent-%COMP%]:first-child.deluxe{padding-right:40px}[_nghost-%COMP%] > .grid[_ngcontent-%COMP%] > .col[_ngcontent-%COMP%]:last-child.deluxe{padding-left:40px}.keno__bet-table[_ngcontent-%COMP%]{margin-bottom:30px}.keno__markets[_ngcontent-%COMP%]{height:65%;margin-bottom:30px}.keno__more-markets[_ngcontent-%COMP%]{height:35%;margin-bottom:30px}"]
                ],
                ae = l.Gb({
                    encapsulation: 0,
                    styles: ce,
                    data: {}
                });

            function be(e) {
                return l.ec(0, [(e()(), l.Ib(0, 0, null, null, 4, "div", [
                    ["class", "col grid grid-column"]
                ], [
                    [2, "deluxe", null]
                ], null, null, null, null)), (e()(), l.Ib(1, 0, null, null, 1, "grc-keno-markets", [
                    ["class", "keno__markets"]
                ], null, [
                    [null, "oddSelectedOddsIdsChange"]
                ], (function(e, n, t) {
                    var l = !0,
                        o = e.component;
                    "oddSelectedOddsIdsChange" === n && (l = !1 !== o.onOddSelectedOddsIds(t) && l);
                    return l
                }), C, O)), l.Hb(2, 114688, null, 0, y, [], {
                    marketsGroup: [0, "marketsGroup"],
                    oddSelectedOddsIds: [1, "oddSelectedOddsIds"]
                }, {
                    oddSelectedOddsIdsChange: "oddSelectedOddsIdsChange"
                }), (e()(), l.Ib(3, 0, null, null, 1, "grc-keno-markets", [
                    ["class", "keno__more-markets"]
                ], null, [
                    [null, "oddSelectedOddsIdsChange"]
                ], (function(e, n, t) {
                    var l = !0,
                        o = e.component;
                    "oddSelectedOddsIdsChange" === n && (l = !1 !== o.onOddSelectedOddsIds(t) && l);
                    return l
                }), C, O)), l.Hb(4, 114688, null, 0, y, [], {
                    marketsGroup: [0, "marketsGroup"],
                    oddSelectedOddsIds: [1, "oddSelectedOddsIds"]
                }, {
                    oddSelectedOddsIdsChange: "oddSelectedOddsIdsChange"
                })], (function(e, n) {
                    var t = n.component;
                    e(n, 2, 0, 0, t.oddSelectedOddsIds);
                    e(n, 4, 0, 1, t.oddSelectedOddsIds)
                }), (function(e, n) {
                    var t = n.component;
                    e(n, 0, 0, t.kenoType === t.kenoTypeEnum.DELUXE || t.kenoType === t.kenoTypeEnum.LIVE)
                }))
            }

            function me(e) {
                return l.ec(0, [(e()(), l.Ib(0, 0, null, null, 25, "div", [
                    ["class", "grid keno"]
                ], null, null, null, null, null)), (e()(), l.Ib(1, 0, null, null, 22, "div", [
                    ["class", "col grid grid-column"]
                ], [
                    [2, "deluxe", null]
                ], null, null, null, null)), (e()(), l.Ib(2, 0, null, null, 1, "grc-keno-bet-table", [
                    ["class", "col keno__bet-table"]
                ], null, [
                    [null, "selectedNumbersChange"],
                    [null, "selectedButtonChange"]
                ], (function(e, n, t) {
                    var l = !0,
                        o = e.component;
                    "selectedNumbersChange" === n && (l = !1 !== o.onSelectedNumbers(t) && l);
                    "selectedButtonChange" === n && (l = !1 !== (o.selectedButton = t) && l);
                    return l
                }), U, B)), l.Hb(3, 114688, null, 0, T, [], {
                    selectedNumbers: [0, "selectedNumbers"],
                    maxPickNumbersLength: [1, "maxPickNumbersLength"],
                    selectedButton: [2, "selectedButton"],
                    isDeluxe: [3, "isDeluxe"]
                }, {
                    selectedNumbersChange: "selectedNumbersChange",
                    selectedButtonChange: "selectedButtonChange"
                }), (e()(), l.Ib(4, 0, null, null, 19, "grc-tab-set", [
                    ["tabSetClass", ""]
                ], [
                    [8, "className", 0]
                ], [
                    [null, "selectedChange"]
                ], (function(e, n, t) {
                    var l = !0,
                        o = e.component;
                    "selectedChange" === n && (l = !1 !== o.onTabQuickMultiplierChange(t) && l);
                    return l
                }), F.b, F.a)), l.Hb(5, 4308992, null, 2, G.a, [l.i], {
                    sameContent: [0, "sameContent"],
                    hasBorder: [1, "hasBorder"],
                    hiddenTabs: [2, "hiddenTabs"],
                    selected: [3, "selected"],
                    ghost: [4, "ghost"],
                    tabSetClass: [5, "tabSetClass"]
                }, {
                    selectedChange: "selectedChange"
                }), l.ac(603979776, 2, {
                    tabsContent: 1
                }), l.ac(603979776, 3, {
                    tabsFixedContent: 1
                }), (e()(), l.Ib(8, 0, null, null, 2, "grc-tab", [], null, null, null, q.b, q.a)), l.Hb(9, 114688, [
                    [2, 4]
                ], 0, X.a, [], {
                    header: [0, "header"],
                    id: [1, "id"]
                }, null), l.Wb(131072, f.j, [f.k, l.i]), (e()(), l.Ib(11, 0, null, null, 3, "grc-tab", [], null, null, null, q.b, q.a)), l.Hb(12, 114688, [
                    [2, 4]
                ], 0, X.a, [], {
                    header: [0, "header"],
                    id: [1, "id"]
                }, null), l.Wb(131072, f.j, [f.k, l.i]), l.Wb(131072, g.b, [l.i]), (e()(), l.Ib(15, 0, null, null, 8, "grc-tab-fixed", [
                    ["side", "content"]
                ], null, null, null, W.b, W.a)), l.Hb(16, 114688, [
                    [3, 4]
                ], 0, j.a, [], {
                    side: [0, "side"]
                }, null), (e()(), l.Ib(17, 0, null, 0, 2, "div", [], [
                    [8, "hidden", 0]
                ], null, null, null, null)), (e()(), l.Ib(18, 0, null, null, 1, "gr-quick-pick", [
                    ["class", "quick-pick-container"]
                ], null, [
                    [null, "numberSelected"]
                ], (function(e, n, t) {
                    var l = !0,
                        o = e.component;
                    "numberSelected" === n && (l = !1 !== o.createRandomArray(t) && l);
                    return l
                }), z.b, z.a)), l.Hb(19, 49152, null, 0, Z.a, [], {
                    numbers: [0, "numbers"]
                }, {
                    numberSelected: "numberSelected"
                }), (e()(), l.Ib(20, 0, null, 0, 3, "div", [], [
                    [8, "hidden", 0]
                ], null, null, null, null)), (e()(), l.Ib(21, 0, null, null, 2, "grc-betslip-multiplier", [], null, [
                    [null, "multiplier"],
                    [null, "isMultiplierInvalid"]
                ], (function(e, n, t) {
                    var l = !0,
                        o = e.component;
                    "multiplier" === n && (l = !1 !== o.onMultiplierSelected(t) && l);
                    "isMultiplierInvalid" === n && (l = !1 !== o.onMultiplierValidation(t) && l);
                    return l
                }), $.b, $.a)), l.Hb(22, 114688, [
                    [1, 4]
                ], 0, Q.a, [], {
                    multipliers: [0, "multipliers"],
                    maxMultiplier: [1, "maxMultiplier"]
                }, {
                    multiplier: "multiplier",
                    isMultiplierInvalid: "isMultiplierInvalid"
                }), l.Vb(23, 5), (e()(), l.xb(16777216, null, null, 1, null, be)), l.Hb(25, 16384, null, 0, g.m, [l.eb, l.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(e, n) {
                    var t = n.component;
                    e(n, 3, 0, t.numbersSelected, t.maxPickNumbersLength(), t.selectedButton, t.kenoType === t.kenoTypeEnum.DELUXE || t.kenoType === t.kenoTypeEnum.LIVE);
                    e(n, 5, 0, !0, !0, !1, "quick-pick", !1, "");
                    e(n, 9, 0, l.dc(n, 9, 0, l.Ub(n, 10).transform("ch_quick_picks")), "quick-pick");
                    e(n, 12, 0, l.dc(n, 12, 0, l.Ub(n, 13).transform("ch_multiplier")) + " x" + l.dc(n, 12, 0, l.Ub(n, 14).transform(t.multiplier)), "multiplier");
                    e(n, 16, 0, "content"), e(n, 19, 0, t.quickNumbers);
                    var o = e(n, 23, 0, 1, 2, 4, 5, 10);
                    e(n, 22, 0, o, t.getMaxMultiplier()), e(n, 25, 0, t.kenoType === t.kenoTypeEnum.DELUXE || t.kenoType === t.kenoTypeEnum.LIVE)
                }), (function(e, n) {
                    var t = n.component;
                    e(n, 1, 0, t.kenoType === t.kenoTypeEnum.DELUXE || t.kenoType === t.kenoTypeEnum.LIVE), e(n, 4, 0, l.Ub(n, 5).tabSetClass), e(n, 17, 0, "multiplier" === t.quickMultiplierTabSelected), e(n, 20, 0, "quick-pick" === t.quickMultiplierTabSelected)
                }))
            }

            function pe(e) {
                return l.ec(2, [l.ac(671088640, 1, {
                    betslipMultiplier: 0
                }), (e()(), l.xb(16777216, null, null, 1, null, me)), l.Hb(2, 16384, null, 0, g.m, [l.eb, l.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(e, n) {
                    e(n, 2, 0, n.component.event)
                }), null)
            }
            var _e = l.Eb("grc-page-keno", re, (function(e) {
                    return l.ec(0, [(e()(), l.Ib(0, 0, null, null, 1, "grc-page-keno", [], null, null, null, pe, ae)), l.Hb(1, 245760, null, 0, re, [l.y, te.a], null, null)], (function(e, n) {
                        e(n, 1, 0)
                    }), null)
                }), {}, {}, []),
                he = t("Wh5D"),
                ge = t("3oWU"),
                fe = t("hkR0"),
                ke = t("pQ2l"),
                ye = t("ghVy"),
                Se = t("goQo"),
                Oe = t("UhMo"),
                ve = [he.a],
                Ce = l.Gb({
                    encapsulation: 0,
                    styles: ve,
                    data: {}
                });

            function Me(e) {
                return l.ec(2, [(e()(), l.Ib(0, 0, null, null, 11, "div", [
                    ["class", "grid grid-column paytable"]
                ], null, null, null, null, null)), (e()(), l.Ib(1, 0, null, null, 0, "div", [
                    ["class", "paytable__cross-close icon icon-cancel"]
                ], null, [
                    [null, "click"]
                ], (function(e, n, t) {
                    var l = !0,
                        o = e.component;
                    "click" === n && (l = !1 !== o.close.emit() && l);
                    return l
                }), null, null)), (e()(), l.Ib(2, 0, null, null, 1, "grc-header-paytable", [], null, null, null, ge.b, ge.a)), l.Hb(3, 114688, null, 0, fe.a, [], {
                    playlist: [0, "playlist"]
                }, null), (e()(), l.Ib(4, 0, null, null, 2, "div", [
                    ["class", "paytable__tab-buttons grid grid-center"]
                ], null, null, null, null, null)), (e()(), l.Ib(5, 0, null, null, 1, "grc-tab-buttons", [], null, [
                    [null, "selectedChange"]
                ], (function(e, n, t) {
                    var l = !0,
                        o = e.component;
                    "selectedChange" === n && (l = !1 !== o.onButtonActiveChange(t) && l);
                    return l
                }), ke.b, ke.a)), l.Hb(6, 4308992, null, 0, ye.a, [l.i], {
                    buttons: [0, "buttons"]
                }, {
                    selectedChange: "selectedChange"
                }), (e()(), l.Ib(7, 0, null, null, 1, "grc-body-paytable", [
                    ["class", "paytable--body-margin col"]
                ], null, null, null, Se.b, Se.a)), l.Hb(8, 49152, null, 0, Oe.a, [], {
                    paytableGame: [0, "paytableGame"],
                    playlist: [1, "playlist"],
                    isS2Wheels: [2, "isS2Wheels"],
                    isRainbow: [3, "isRainbow"],
                    isKinel8: [4, "isKinel8"],
                    hasX: [5, "hasX"],
                    buttons: [6, "buttons"],
                    columnsPerRow: [7, "columnsPerRow"],
                    buttonSelected: [8, "buttonSelected"]
                }, null), (e()(), l.Ib(9, 0, null, null, 2, "div", [
                    ["class", "paytable__button-close"]
                ], null, [
                    [null, "click"]
                ], (function(e, n, t) {
                    var l = !0,
                        o = e.component;
                    "click" === n && (l = !1 !== o.close.emit() && l);
                    return l
                }), null, null)), (e()(), l.cc(10, null, ["", ""])), l.Wb(131072, f.j, [f.k, l.i])], (function(e, n) {
                    var t = n.component;
                    e(n, 3, 0, t.playlist), e(n, 6, 0, t.buttons), e(n, 8, 0, t.paytableGame, t.playlist, t.isS2Wheels, t.isRainbow, t.isKinel8, t.hasX, t.buttons, t.columnsPerRow, t.buttonSelected)
                }), (function(e, n) {
                    e(n, 10, 0, l.dc(n, 10, 0, l.Ub(n, 11).transform("ch_close")))
                }))
            }
            var Ne = l.Eb("ng-component", ue, (function(e) {
                    return l.ec(0, [(e()(), l.Ib(0, 0, null, null, 1, "ng-component", [], null, null, null, Me, Ce)), l.Hb(1, 245760, null, 0, ue, [f.k], null, null)], (function(e, n) {
                        e(n, 1, 0)
                    }), null)
                }), {
                    currentPayTable: "currentPayTable",
                    isS2Wheels: "isS2Wheels",
                    isRainbow: "isRainbow",
                    isKinel8: "isKinel8",
                    playlist: "playlist"
                }, {
                    close: "close",
                    selectedChange: "selectedChange"
                }, []),
                Ie = t("gIcY"),
                xe = t("M3iF"),
                Ee = t("tfG9"),
                De = t("t/Na"),
                Te = t("7oEI"),
                Pe = t("ojct"),
                Be = t("hIlf"),
                we = t("ssOW"),
                Re = t("96LH"),
                Ke = t("t01L"),
                He = t("ZYCi"),
                Le = t("4hpQ"),
                Ue = t("7x4Y"),
                Ae = t("QFAn"),
                Ve = t("iz+u"),
                Fe = t("sJrH"),
                Ge = l.Fb(o, [], (function(e) {
                    return l.Rb([l.Sb(512, l.l, l.qb, [
                        [8, [s.a, i.a, u.a, d.c, r.a, c.a, a.a, b.a, m.a, p.a, _.a, h.a, _e, Ne]],
                        [3, l.l], l.G
                    ]), l.Sb(4608, g.o, g.n, [l.C, [2, g.C]]), l.Sb(4608, Ie.r, Ie.r, []), l.Sb(4608, xe.c, xe.c, []), l.Sb(4608, Ee.a, Ee.a, [g.d]), l.Sb(4608, De.h, De.n, [g.d, l.L, De.l]), l.Sb(4608, De.o, De.o, [De.h, De.m]), l.Sb(5120, De.a, (function(e) {
                        return [e]
                    }), [De.o]), l.Sb(4608, De.k, De.k, []), l.Sb(6144, De.i, null, [De.k]), l.Sb(4608, De.g, De.g, [De.i]), l.Sb(6144, De.b, null, [De.g]), l.Sb(4608, De.f, De.j, [De.b, l.y]), l.Sb(4608, De.c, De.c, [De.f]), l.Sb(4608, Te.a, Te.a, [l.l, Pe.a]), l.Sb(4608, Be.a, Be.a, [De.c, we.a]), l.Sb(4608, Re.a, Re.a, [Ke.a, Be.a]), l.Sb(1073742336, g.c, g.c, []), l.Sb(1073742336, He.p, He.p, [
                        [2, He.u],
                        [2, He.l]
                    ]), l.Sb(1073742336, f.h, f.h, []), l.Sb(1073742336, Le.a, Le.a, []), l.Sb(1073742336, Ie.q, Ie.q, []), l.Sb(1073742336, Ie.e, Ie.e, []), l.Sb(1073742336, Ue.a, Ue.a, []), l.Sb(1073742336, xe.b, xe.b, []), l.Sb(1073742336, Ae.a, Ae.a, []), l.Sb(1073742336, Ve.a, Ve.a, []), l.Sb(1073742336, De.e, De.e, []), l.Sb(1073742336, De.d, De.d, []), l.Sb(1073742336, Fe.a, Fe.a, []), l.Sb(1073742336, o, o, []), l.Sb(256, De.l, "XSRF-TOKEN", []), l.Sb(256, De.m, "X-XSRF-TOKEN", []), l.Sb(1024, He.j, (function() {
                        return [
                            [{
                                path: "",
                                component: re,
                                resolve: {
                                    ThemeResolver: Re.a
                                }
                            }]
                        ]
                    }), []), l.Sb(256, we.a, "clients/{{name}}/kn.skin.css", [])])
                }))
        }
    }
]);