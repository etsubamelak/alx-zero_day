(window.webpackJsonp = window.webpackJsonp || []).push([
    [20], {
        "oXa/": function(t, n, r) {
            "use strict";
            r.r(n), r.d(n, "setMaxStake", (function() {
                return l
            })), r.d(n, "getRandomFromArray", (function() {
                return p
            })), r.d(n, "setGameType", (function() {
                return g
            })), r.d(n, "setParticipants", (function() {
                return h
            })), r.d(n, "setPodium", (function() {
                return y
            })), r.d(n, "enableSumOfPlaces", (function() {
                return A
            })), r.d(n, "disableSumOfPlaces", (function() {
                return D
            })), r.d(n, "enableThrottingMarkets", (function() {
                return K
            })), r.d(n, "disableThrottingMarkets", (function() {
                return F
            })), r.d(n, "parser", (function() {
                return B
            }));
            var e = {};
            r.r(e), r.d(e, "doPermute", (function() {
                return o
            })), r.d(e, "getPermutations", (function() {
                return u
            })), r.d(e, "pairwise", (function() {
                return i
            }));
            var a = r("1hBs");

            function o(t, n, r, e, a, u) {
                if (void 0 === u && (u = []), e === a) {
                    var i = n.join("_");
                    return u.push(i), u
                }
                a++;
                for (var s = 0; s < t.length; s++) !0 !== r[s] && (r[s] = !0, n.push(t[s]), u = u.concat(o(t, n, r, e, a)), r[s] = !1, n.pop());
                return u
            }

            function u(t, n) {
                return o(t.split("_"), [], [], n, 0)
            }

            function i(t) {
                if (t.length < 2) return [];
                var n = t[0],
                    r = t.slice(1);
                return r.map((function(t) {
                    return [n, t]
                })).concat(i(r))
            }
            var s, d, c, f = r("mv+f"),
                m = r("CAXR"),
                l = f.setMaxStake,
                p = f.getRandomFromArray,
                k = ((s = {})[a.model.GameType.ValEnum.DOG] = {
                    markets: a.DogMarkets,
                    odds: a.DogOdds
                }, s[a.model.GameType.ValEnum.HORSE] = {
                    markets: a.HorseMarkets,
                    odds: a.HorseOdds
                }, s[a.model.GameType.ValEnum.TROTTING] = {
                    markets: a.TrottingMarkets,
                    odds: a.TrottingOdds
                }, s[a.model.GameType.ValEnum.DIRTTRACK] = {
                    markets: a.DirttrackMarkets,
                    odds: a.DirttrackOdds
                }, s[a.model.GameType.ValEnum.KART] = {
                    markets: a.KartMarkets,
                    odds: a.KartOdds
                }, s[a.model.GameType.ValEnum.MOTORBIKE] = {
                    markets: a.MotorbikeMarkets,
                    odds: a.MotorbikeOdds
                }, s[a.model.GameType.ValEnum.SPEEDWAY] = {
                    markets: a.SpeedwayMarkets,
                    odds: a.SpeedwayOdds
                }, s);

            function g(t) {
                var n = k[t.val];
                d = n.markets, c = n.odds
            }

            function M() {
                return d
            }

            function v() {
                return c
            }
            var T = 0,
                h = function(t) {
                    T = t
                },
                O = 0,
                y = function(t) {
                    O = t
                },
                E = function() {
                    return O
                };

            function S(t) {
                return t > 0 && t <= T
            }

            function P(t, n, r) {
                void 0 === n && (n = 0), void 0 === r && (r = 0);
                var e = t.toString().split("_"),
                    a = !e.some((function(t) {
                        return !S(t)
                    })),
                    o = !0,
                    u = !b(t);
                return n > 0 && (o = r > 0 ? e.length >= n && e.length <= r : e.length === n), a && o && u
            }

            function b(t) {
                var n = t.toString().split("_");
                return n.filter((function(t, n, r) {
                    return !r.slice(0, n).includes(t)
                })).length !== n.length
            }

            function G(t) {
                for (var n = 0, r = 0, e = T; e > T - 3; e--) n += e;
                for (e = 1; e < 4; e++) r += e;
                return [r <= t, t <= n]
            }

            function R(t) {
                void 0 === t && (t = 1), t = Math.min(t, T);
                for (var n = [], r = 0; r < t;) {
                    var e = Math.floor(Math.random() * T + 1); - 1 === n.indexOf(e) && (n.push(e), r++)
                }
                return n
            }
            var w = !1;

            function A() {
                w = !0
            }

            function D() {
                w = !1
            }

            function V() {
                return w
            }
            var x = !1;

            function K() {
                x = !0
            }

            function F() {
                x = !1
            }

            function _() {
                return x
            }

            function H() {
                return T > 4
            }

            function I() {
                return 12 === T
            }
            var B = {
                parse: function(t) {
                    return m.parse(t, {
                        combinatorial: e,
                        isParticipant: S,
                        allAreParticipants: P,
                        hasDuplicatedParticipant: b,
                        sumOfPlacesValidator: G,
                        randomParticipants: R,
                        getRandomFromArray: p,
                        isSumOfPlacesEnabled: V,
                        getMarkets: M,
                        getOdds: v,
                        getPodium: E,
                        isThrottingMarketsEnabled: _,
                        isSystemThreeMarketEnabled: H,
                        isSystemFourMarketEnabled: I,
                        getMaxStake: f.getMaxStake
                    })
                }
            }
        }
    }
]);