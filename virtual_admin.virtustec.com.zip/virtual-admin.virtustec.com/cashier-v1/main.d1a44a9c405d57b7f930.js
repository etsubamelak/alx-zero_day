(window.webpackJsonp = window.webpackJsonp || []).push([
    [13], {
        "+69r": function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return o
            }));
            var e = l("CcnG"),
                i = l("3cbp"),
                o = (l("M3um"), function() {
                    function n(n) {
                        this.cd = n, this.stretch = !1, this.sameContent = !1, this.hasBorder = !1, this.hiddenTabs = !1, this.disabled = !1, this.ghost = !1, this.isCashManagement = !1, this.selectedChange = new e.q, this.hasPreviousNavigation = !1, this.hasNextNavigation = !1
                    }
                    return Object.defineProperty(n.prototype, "tabsContent", {
                        set: function(n) {
                            var t = this;
                            this.tabs = n, this.areHiddenModeTabs = 0 === this.tabs.length, setTimeout((function() {
                                return t.setNavigationHeaders()
                            }), 0), this.cd.markForCheck()
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(n.prototype, "tabsFixedContent", {
                        set: function(n) {
                            this.tabsFixed = n, this.cd.markForCheck()
                        },
                        enumerable: !1,
                        configurable: !0
                    }), n.prototype.ngOnInit = function() {}, n.prototype.ngAfterViewInit = function() {
                        this.selected || (this.select(0), this.cd.detectChanges()), this.setNavigationHeaders()
                    }, n.prototype.select = function(n) {
                        var t = this.tabs.toArray()[n];
                        t && this.selected !== n && !this.disabled && (this.selected = t.id, this.selectedChange.emit(this.selected))
                    }, n.prototype.nextTabNavigation = function() {
                        var n = this;
                        this.clearIntervalSmooth(), this.intervalSmooth = setInterval((function() {
                            n.tabHeaders.nativeElement.scrollLeft + n.tabHeaders.nativeElement.clientWidth < n.tabHeaders.nativeElement.scrollWidth ? n.tabHeaders.nativeElement.scrollLeft = n.tabHeaders.nativeElement.scrollLeft + 10 : n.clearIntervalSmooth()
                        }), 1)
                    }, n.prototype.previousTabNavigation = function() {
                        var n = this;
                        this.clearIntervalSmooth(), this.intervalSmooth = setInterval((function() {
                            n.tabHeaders.nativeElement.scrollLeft > 0 ? n.tabHeaders.nativeElement.scrollLeft = n.tabHeaders.nativeElement.scrollLeft - 10 : n.clearIntervalSmooth()
                        }), 1)
                    }, n.prototype.getContentFixedLeft = function() {
                        return this.tabsFixed.find((function(n) {
                            return n.side === i.b.LEFT
                        }))
                    }, n.prototype.getUniqueContent = function() {
                        return this.tabsFixed.find((function(n) {
                            return n.side === i.b.CONTENT
                        }))
                    }, n.prototype.setNavigationHeaders = function() {
                        if (this.tabHeaders) {
                            var n = this.tabHeaders.nativeElement.offsetWidth;
                            this.hasPreviousNavigation = this.tabHeaders.nativeElement.scrollLeft > 0, n === this.tabHeaders.nativeElement.scrollWidth ? this.hasNextNavigation = n !== this.tabHeaders.nativeElement.scrollWidth - this.tabHeaders.nativeElement.scrollLeft : this.hasNextNavigation = n !== 1 + this.tabHeaders.nativeElement.scrollWidth - this.tabHeaders.nativeElement.scrollLeft, this.cd.markForCheck()
                        }
                    }, n.prototype.onTabScroll = function() {
                        this.setNavigationHeaders()
                    }, n.prototype.clearIntervalSmooth = function() {
                        this.intervalSmooth && clearInterval(this.intervalSmooth)
                    }, n
                }())
        },
        "+iOv": function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return e
            }));
            var e = function() {
                function n() {
                    this.message = "", this.isProcessing = !1
                }
                return n.prototype.ngOnInit = function() {}, n
            }()
        },
        "/4m3": function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return r
            }));
            var e, i = l("NPGq"),
                o = (e = function(n, t) {
                    return (e = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(n, t) {
                            n.__proto__ = t
                        } || function(n, t) {
                            for (var l in t) Object.prototype.hasOwnProperty.call(t, l) && (n[l] = t[l])
                        })(n, t)
                }, function(n, t) {
                    function l() {
                        this.constructor = n
                    }
                    e(n, t), n.prototype = null === t ? Object.create(t) : (l.prototype = t.prototype, new l)
                }),
                r = function(n) {
                    function t() {
                        return null !== n && n.apply(this, arguments) || this
                    }
                    return o(t, n), t.prototype.ngOnInit = function() {}, t
                }(i.a)
        },
        "/6R9": function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return p
            }));
            var e = l("VnD/"),
                i = l("7oEI"),
                o = l("SLOH"),
                r = l("/4m3"),
                u = l("lBSr"),
                s = l("zAiC"),
                c = l("lwRT"),
                a = l("CcnG"),
                d = function() {
                    return (d = Object.assign || function(n) {
                        for (var t, l = 1, e = arguments.length; l < e; l++)
                            for (var i in t = arguments[l]) Object.prototype.hasOwnProperty.call(t, i) && (n[i] = t[i]);
                        return n
                    }).apply(this, arguments)
                },
                p = function() {
                    function n(n) {
                        this.modalService = n
                    }
                    return n.prototype.cancelTicket = function(n, t, l) {
                        var i = {
                            confirmed: l.confirmOnClose || null
                        };
                        return this.modalService.open(n, o.a, {
                            inputs: d(d({}, l), {
                                serverTicket: t,
                                modalId: n,
                                confirmed: i
                            })
                        }).afterClosed.pipe(Object(e.a)((function() {
                            return i.confirmed
                        })))
                    }, n.prototype.showTicketInfo = function(n, t, l) {
                        var i = {
                            confirmed: null
                        };
                        return this.modalService.open(n, u.a, {
                            inputs: d(d({}, l), {
                                serverTicket: t,
                                modalId: n,
                                confirmed: i
                            })
                        }).afterClosed.pipe(Object(e.a)((function() {
                            return i.confirmed
                        })))
                    }, n.prototype.rebetTicket = function(n, t) {
                        var l = {
                            confirmed: null
                        };
                        return this.modalService.open(n, r.a, {
                            inputs: {
                                serverTicket: t,
                                modalId: n,
                                confirmed: l,
                                hasConfirm: !0
                            }
                        }).afterClosed.pipe(Object(e.a)((function() {
                            return l.confirmed
                        })))
                    }, n.prototype.cashTicket = function(n, t) {
                        var l = {
                            confirmed: null
                        };
                        return this.modalService.open(n, c.a, {
                            inputs: {
                                serverTicket: t,
                                modalId: n,
                                confirmed: l
                            }
                        }).afterClosed.pipe(Object(e.a)((function() {
                            return l.confirmed
                        })))
                    }, n.prototype.preTicket = function(n, t, l) {
                        var i = {
                            confirmed: null
                        };
                        return this.modalService.open(n, s.a, {
                            inputs: d(d({}, l), {
                                serverTicket: t,
                                modalId: n,
                                confirmed: i
                            })
                        }).afterClosed.pipe(Object(e.a)((function() {
                            return i.confirmed
                        })))
                    }, n.ngInjectableDef = a.ic({
                        factory: function() {
                            return new n(a.jc(i.a))
                        },
                        token: n,
                        providedIn: "root"
                    }), n
                }()
        },
        0: function(n, t, l) {
            n.exports = l("zUnb")
        },
        "0ZGX": function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return e
            }));
            var e = function() {
                function n() {
                    this.hasEnterSystemSection = !1
                }
                return n.prototype.ngOnInit = function() {}, n
            }()
        },
        "0sFr": function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return c
            })), l.d(t, "b", (function() {
                return p
            }));
            var e = l("CcnG"),
                i = l("gIcY"),
                o = l("5EE+"),
                r = l("Ip0R"),
                u = l("V4K8"),
                s = [
                    [".selectprinter__select[_ngcontent-%COMP%]{position:relative;display:inline-block;padding:12px 36px 12px 16px;font-size:18px;font-weight:700;color:#000;cursor:pointer;border:1px solid #909090;max-width:400px}"]
                ],
                c = e.Gb({
                    encapsulation: 0,
                    styles: s,
                    data: {}
                });

            function a(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 4, "option", [], null, null, null, null, null)), e.Hb(1, 147456, null, 0, i.n, [e.o, e.P, [2, i.p]], {
                    ngValue: [0, "ngValue"]
                }, null), e.Hb(2, 147456, null, 0, i.s, [e.o, e.P, [8, null]], {
                    ngValue: [0, "ngValue"]
                }, null), (n()(), e.cc(3, null, ["", ""])), e.Wb(131072, o.j, [o.k, e.i])], (function(n, t) {
                    n(t, 1, 0, void 0);
                    n(t, 2, 0, void 0)
                }), (function(n, t) {
                    n(t, 3, 0, e.dc(t, 3, 0, e.Ub(t, 4).transform("ch_select_printer")))
                }))
            }

            function d(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 3, "option", [], null, null, null, null, null)), e.Hb(1, 147456, null, 0, i.n, [e.o, e.P, [2, i.p]], {
                    ngValue: [0, "ngValue"]
                }, null), e.Hb(2, 147456, null, 0, i.s, [e.o, e.P, [8, null]], {
                    ngValue: [0, "ngValue"]
                }, null), (n()(), e.cc(3, null, ["", ""]))], (function(n, t) {
                    n(t, 1, 0, t.context.$implicit), n(t, 2, 0, t.context.$implicit)
                }), (function(n, t) {
                    n(t, 3, 0, t.context.$implicit.info.name)
                }))
            }

            function p(n) {
                return e.ec(2, [(n()(), e.Ib(0, 0, null, null, 13, "div", [
                    ["class", "selectprinter"]
                ], null, null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 12, "select", [
                    ["class", "selectprinter__select"]
                ], [
                    [2, "ng-untouched", null],
                    [2, "ng-touched", null],
                    [2, "ng-pristine", null],
                    [2, "ng-dirty", null],
                    [2, "ng-valid", null],
                    [2, "ng-invalid", null],
                    [2, "ng-pending", null]
                ], [
                    [null, "ngModelChange"],
                    [null, "change"],
                    [null, "blur"]
                ], (function(n, t, l) {
                    var i = !0,
                        o = n.component;
                    "change" === t && (i = !1 !== e.Ub(n, 5).onChange(l.target.value) && i);
                    "blur" === t && (i = !1 !== e.Ub(n, 5).onTouched() && i);
                    "ngModelChange" === t && (i = !1 !== (o.selectedPrinter = l) && i);
                    "ngModelChange" === t && (i = !1 !== o.selectPrinter(l) && i);
                    return i
                }), null, null)), e.Zb(512, null, r.z, r.A, [e.o, e.B, e.P]), e.Hb(3, 278528, null, 0, r.p, [r.z], {
                    ngStyle: [0, "ngStyle"]
                }, null), e.Xb(4, {
                    "height.px": 0,
                    "min-width.px": 1
                }), e.Hb(5, 16384, null, 0, i.p, [e.P, e.o], null, null), e.Zb(1024, null, i.h, (function(n) {
                    return [n]
                }), [i.p]), e.Hb(7, 671744, null, 0, i.m, [
                    [8, null],
                    [8, null],
                    [8, null],
                    [6, i.h]
                ], {
                    model: [0, "model"]
                }, {
                    update: "ngModelChange"
                }), e.Zb(2048, null, i.i, null, [i.m]), e.Hb(9, 16384, null, 0, i.j, [
                    [4, i.i]
                ], null, null), (n()(), e.xb(16777216, null, null, 1, null, a)), e.Hb(11, 16384, null, 0, r.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.xb(16777216, null, null, 1, null, d)), e.Hb(13, 278528, null, 0, r.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(n, t) {
                    var l = t.component,
                        e = n(t, 4, 0, l.height, l.width);
                    n(t, 3, 0, e), n(t, 7, 0, l.selectedPrinter), n(t, 11, 0, !l.selectedPrinter), n(t, 13, 0, l.printers)
                }), (function(n, t) {
                    n(t, 1, 0, e.Ub(t, 9).ngClassUntouched, e.Ub(t, 9).ngClassTouched, e.Ub(t, 9).ngClassPristine, e.Ub(t, 9).ngClassDirty, e.Ub(t, 9).ngClassValid, e.Ub(t, 9).ngClassInvalid, e.Ub(t, 9).ngClassPending)
                }))
            }
            e.Eb("grc-select-printer", u.a, (function(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "grc-select-printer", [], null, null, null, p, c)), e.Hb(1, 114688, null, 0, u.a, [e.i], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                printers: "printers",
                width: "width",
                height: "height"
            }, {
                switchPrinter: "switchPrinter"
            }, [])
        },
        "1A4t": function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return o
            }));
            var e = l("bne5"),
                i = l("xMyE"),
                o = function() {
                    function n(n) {
                        this.renderer = n.createRenderer(null, null), this.init()
                    }
                    return n.prototype.setSize = function(n, t) {
                        this.size = {
                            width: n,
                            height: t
                        }, this.scale()
                    }, n.prototype.setElement = function(n) {
                        this.element = n, this.elementBoundingClientRect = this.element.getBoundingClientRect(), this.renderer.setStyle(this.element, "transform-origin", "left top"), this.scale()
                    }, n.prototype.getUnscaledHeight = function(n) {
                        return n / this.scaleFactor.height
                    }, n.prototype.getUnscaledWidth = function(n) {
                        return n / this.scaleFactor.width
                    }, n.prototype.init = function() {
                        var n = this;
                        Object(e.a)(window, "resize").pipe(Object(i.a)((function() {
                            n.scale()
                        }))).subscribe()
                    }, n.prototype.scale = function() {
                        this.element && this.size && (this.scaleFactor = {
                            width: window.innerWidth / this.size.width,
                            height: window.innerHeight / this.size.height
                        }, this.renderer.setStyle(this.element, "transform", "scale3d(" + this.scaleFactor.width + ", " + this.scaleFactor.height + ", 1)"))
                    }, n
                }()
        },
        "1UiX": function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return E
            }));
            var e = l("CcnG"),
                i = l("5EE+"),
                o = l("Ip0R"),
                r = l("hZz1"),
                u = [
                    [".printer[_ngcontent-%COMP%]{width:100%;margin-bottom:10px;border:2px solid #ddd}.printer__header__title[_ngcontent-%COMP%]{padding:20px;display:inline;font-size:18px;cursor:pointer}.printer__header__title__toggle[_ngcontent-%COMP%]{color:rgba(107,107,107,.87)}.printer__header__title__icon[_ngcontent-%COMP%]{padding-left:10px}.printer__header__title__icon--selected[_ngcontent-%COMP%]{color:#4c9201}.printer__header__title__icon--not-selected[_ngcontent-%COMP%]{color:#000}.printer__header__title__id[_ngcontent-%COMP%]{padding-left:5px;font-weight:700}.printer__header__title__id--selected[_ngcontent-%COMP%]{color:#4c9201}.printer__header__title__id--not-selected[_ngcontent-%COMP%]{color:rgba(0,0,0,.87)}.printer__header__title__code[_ngcontent-%COMP%]{padding-left:10px}.printer__header__title__code--selected[_ngcontent-%COMP%]{color:#4c9201}.printer__header__title__code--not-selected[_ngcontent-%COMP%]{color:rgba(107,107,107,.87)}.printer__header__title__localhost[_ngcontent-%COMP%]{padding:3px;color:rgba(0,0,0,.87);background-color:#d8d8d8;border-radius:5px;font-size:12px}.printer__header__buttons[_ngcontent-%COMP%]{padding:10px}.printer__header__buttons[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{width:129px;height:48px;padding:15px 20px 20px;text-align:center;text-transform:uppercase}.printer__header__buttons__displays[_ngcontent-%COMP%]{float:left;color:rgba(0,0,0,.87);cursor:pointer;background-color:#ddd}.printer__header__buttons__displays__icon[_ngcontent-%COMP%]{position:relative;bottom:28px;left:52px;color:#3a3a39}.printer__header__buttons__switch[_ngcontent-%COMP%]{float:right;color:rgba(255,255,255,.87)}.printer__header__buttons__switch--enabled[_ngcontent-%COMP%]{cursor:pointer;background-color:#1194f6}.printer__header__buttons__switch--disabled[_ngcontent-%COMP%]{cursor:default;background-color:rgba(17,148,246,.5)}.printer__body[_ngcontent-%COMP%]{padding:25px;margin-top:15px;font-size:16px}.printer__body__label[_ngcontent-%COMP%]{font-weight:700;line-height:25px;color:#000;text-align:left}.printer__body__text[_ngcontent-%COMP%]{line-height:25px;color:rgba(107,107,107,.87);text-align:right}"]
                ],
                s = e.Gb({
                    encapsulation: 0,
                    styles: u,
                    data: {}
                });

            function c(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 55, "div", [
                    ["class", "printer__body grid grid-12"]
                ], null, null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 15, "div", [
                    ["class", "col col-2"]
                ], null, null, null, null, null)), (n()(), e.Ib(2, 0, null, null, 2, "p", [
                    ["class", "printer__body__label"]
                ], null, null, null, null, null)), (n()(), e.cc(3, null, ["", ":"])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(5, 0, null, null, 2, "p", [
                    ["class", "printer__body__label"]
                ], null, null, null, null, null)), (n()(), e.cc(6, null, ["", ":"])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(8, 0, null, null, 2, "p", [
                    ["class", "printer__body__label"]
                ], null, null, null, null, null)), (n()(), e.cc(9, null, ["", ":"])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(11, 0, null, null, 2, "p", [
                    ["class", "printer__body__label"]
                ], null, null, null, null, null)), (n()(), e.cc(12, null, ["", ":"])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(14, 0, null, null, 2, "p", [
                    ["class", "printer__body__label"]
                ], null, null, null, null, null)), (n()(), e.cc(15, null, ["", ":"])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(17, 0, null, null, 10, "div", [
                    ["class", "col col-4"]
                ], null, null, null, null, null)), (n()(), e.Ib(18, 0, null, null, 1, "p", [
                    ["class", "printer__body__text"]
                ], null, null, null, null, null)), (n()(), e.cc(19, null, ["", " \xa0"])), (n()(), e.Ib(20, 0, null, null, 1, "p", [
                    ["class", "printer__body__text"]
                ], null, null, null, null, null)), (n()(), e.cc(21, null, ["", " \xa0"])), (n()(), e.Ib(22, 0, null, null, 1, "p", [
                    ["class", "printer__body__text"]
                ], null, null, null, null, null)), (n()(), e.cc(23, null, ["", " \xa0"])), (n()(), e.Ib(24, 0, null, null, 1, "p", [
                    ["class", "printer__body__text"]
                ], null, null, null, null, null)), (n()(), e.cc(25, null, ["", " \xa0"])), (n()(), e.Ib(26, 0, null, null, 1, "p", [
                    ["class", "printer__body__text"]
                ], null, null, null, null, null)), (n()(), e.cc(27, null, ["", " \xa0"])), (n()(), e.Ib(28, 0, null, null, 0, "div", [
                    ["class", "col col-1"]
                ], null, null, null, null, null)), (n()(), e.Ib(29, 0, null, null, 15, "div", [
                    ["class", "col col-2"]
                ], null, null, null, null, null)), (n()(), e.Ib(30, 0, null, null, 2, "p", [
                    ["class", "printer__body__label"]
                ], null, null, null, null, null)), (n()(), e.cc(31, null, ["", ":"])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(33, 0, null, null, 2, "p", [
                    ["class", "printer__body__label"]
                ], null, null, null, null, null)), (n()(), e.cc(34, null, ["", ":"])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(36, 0, null, null, 2, "p", [
                    ["class", "printer__body__label"]
                ], null, null, null, null, null)), (n()(), e.cc(37, null, ["", ":"])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(39, 0, null, null, 2, "p", [
                    ["class", "printer__body__label"]
                ], null, null, null, null, null)), (n()(), e.cc(40, null, ["", ":"])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(42, 0, null, null, 2, "p", [
                    ["class", "printer__body__label"]
                ], null, null, null, null, null)), (n()(), e.cc(43, null, ["", ":"])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(45, 0, null, null, 10, "div", [
                    ["class", "col col-3"]
                ], null, null, null, null, null)), (n()(), e.Ib(46, 0, null, null, 1, "p", [
                    ["class", "printer__body__text"]
                ], null, null, null, null, null)), (n()(), e.cc(47, null, ["", " \xa0"])), (n()(), e.Ib(48, 0, null, null, 1, "p", [
                    ["class", "printer__body__text"]
                ], null, null, null, null, null)), (n()(), e.cc(49, null, ["", " \xa0"])), (n()(), e.Ib(50, 0, null, null, 1, "p", [
                    ["class", "printer__body__text"]
                ], null, null, null, null, null)), (n()(), e.cc(51, null, ["", " \xa0"])), (n()(), e.Ib(52, 0, null, null, 1, "p", [
                    ["class", "printer__body__text"]
                ], null, null, null, null, null)), (n()(), e.cc(53, null, ["", "-", " \xa0"])), (n()(), e.Ib(54, 0, null, null, 1, "p", [
                    ["class", "printer__body__text"]
                ], null, null, null, null, null)), (n()(), e.cc(55, null, ["", "\xa0"]))], null, (function(n, t) {
                    var l = t.component;
                    n(t, 3, 0, e.dc(t, 3, 0, e.Ub(t, 4).transform("ch_current_version"))), n(t, 6, 0, e.dc(t, 6, 0, e.Ub(t, 7).transform("ch_remote_server"))), n(t, 9, 0, e.dc(t, 9, 0, e.Ub(t, 10).transform("ch_local_ip"))), n(t, 12, 0, e.dc(t, 12, 0, e.Ub(t, 13).transform("ch_public_ip"))), n(t, 15, 0, e.dc(t, 15, 0, e.Ub(t, 16).transform("ch_entity_id"))), n(t, 19, 0, l.localHostInfo.settings.version), n(t, 21, 0, l.localHostInfo.remoteServer), n(t, 23, 0, l.localHostInfo.systemInfo.localIp), n(t, 25, 0, l.localHostInfo.systemInfo.publicIp), n(t, 27, 0, l.entityId), n(t, 31, 0, e.dc(t, 31, 0, e.Ub(t, 32).transform("ch_entity_Name"))), n(t, 34, 0, e.dc(t, 34, 0, e.Ub(t, 35).transform("ch_teamviewer"))), n(t, 37, 0, e.dc(t, 37, 0, e.Ub(t, 38).transform("ch_hardware_id"))), n(t, 40, 0, e.dc(t, 40, 0, e.Ub(t, 41).transform("ch_system"))), n(t, 43, 0, e.dc(t, 43, 0, e.Ub(t, 44).transform("ch_video_streamer_status"))), n(t, 47, 0, l.entityName), n(t, 49, 0, l.localHostInfo.systemInfo.teamviewerId), n(t, 51, 0, l.hwId), n(t, 53, 0, l.localHostInfo.systemInfo.osName, l.localHostInfo.systemInfo.osVersion), n(t, 55, 0, l.localHostInfo.mediaServerStatus)
                }))
            }

            function a(n) {
                return e.ec(2, [(n()(), e.Ib(0, 0, null, null, 14, "div", [
                    ["class", "printer"]
                ], null, null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 11, "div", [
                    ["class", "printer__header grid grid-12"]
                ], null, null, null, null, null)), (n()(), e.Ib(2, 0, null, null, 10, "div", [
                    ["class", "printer__header__title col col-8"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.changeMyExpanded() && e);
                    return e
                }), null, null)), (n()(), e.Ib(3, 0, null, null, 2, "span", [
                    ["class", "printer__header__title__toggle icon"]
                ], null, null, null, null, null)), e.Zb(512, null, o.x, o.y, [e.A, e.B, e.o, e.P]), e.Hb(5, 278528, null, 0, o.k, [o.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), (n()(), e.Ib(6, 0, null, null, 0, "span", [
                    ["class", "printer__header__title__icon icon icon-tv printer__header__title__icon--not-selected"]
                ], null, null, null, null, null)), (n()(), e.Ib(7, 0, null, null, 1, "span", [
                    ["class", "printer__header__title__id printer__header__title__id--not-selected"]
                ], null, null, null, null, null)), (n()(), e.cc(8, null, ["", " "])), (n()(), e.Ib(9, 0, null, null, 1, "span", [
                    ["class", "printer__header__title__code printer__header__title__code--not-selected"]
                ], null, null, null, null, null)), (n()(), e.cc(10, null, ["", " "])), (n()(), e.Ib(11, 0, null, null, 1, "span", [
                    ["class", "printer__header__title__localhost"]
                ], null, null, null, null, null)), (n()(), e.cc(-1, null, ["LOCALHOST"])), (n()(), e.xb(16777216, null, null, 1, null, c)), e.Hb(14, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(n, t) {
                    var l = t.component;
                    n(t, 5, 0, "printer__header__title__toggle icon", l.myExpanded ? " icon-up" : "icon-down"), n(t, 14, 0, l.myExpanded)
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 8, 0, l.entityId), n(t, 10, 0, l.entityName)
                }))
            }
            e.Eb("grc-my-printer", r.a, (function(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "grc-my-printer", [], null, null, null, a, s)), e.Hb(1, 245760, null, 0, r.a, [e.i], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                unitPrinter: "unitPrinter",
                localHostInfo: "localHostInfo",
                anyUnitSelected: "anyUnitSelected",
                entityName: "entityName",
                entityId: "entityId",
                hardwareId: "hardwareId"
            }, {
                switchUnitPrinter: "switchUnitPrinter"
            }, []);
            var d = l("B8qn"),
                p = [
                    [".printer[_ngcontent-%COMP%]{width:100%;margin-bottom:10px;border:2px solid #ddd}.printer__header__title[_ngcontent-%COMP%]{padding:20px;display:inline;font-size:18px;cursor:pointer}.printer__header__title__toggle[_ngcontent-%COMP%]{color:rgba(107,107,107,.87)}.printer__header__title__icon[_ngcontent-%COMP%]{padding-left:10px}.printer__header__title__icon--selected[_ngcontent-%COMP%]{color:#4c9201}.printer__header__title__icon--not-selected[_ngcontent-%COMP%]{color:#000}.printer__header__title__id[_ngcontent-%COMP%]{padding-left:5px;font-weight:700}.printer__header__title__id--selected[_ngcontent-%COMP%]{color:#4c9201}.printer__header__title__id--not-selected[_ngcontent-%COMP%]{color:rgba(0,0,0,.87)}.printer__header__title__code[_ngcontent-%COMP%]{padding-left:10px}.printer__header__title__code--selected[_ngcontent-%COMP%]{color:#4c9201}.printer__header__title__code--not-selected[_ngcontent-%COMP%]{color:rgba(107,107,107,.87)}.printer__header__buttons[_ngcontent-%COMP%]{padding:10px}.printer__header__buttons[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{width:129px;height:48px;padding:15px 20px 20px;text-align:center}.printer__header__buttons__displays[_ngcontent-%COMP%]{float:left;color:rgba(0,0,0,.87);cursor:pointer;background-color:#ddd;text-transform:uppercase}.printer__header__buttons__displays__icon[_ngcontent-%COMP%]{position:relative;bottom:28px;left:52px;color:#3a3a39}.printer__header__buttons__switch[_ngcontent-%COMP%]{float:right;color:rgba(255,255,255,.87);text-transform:uppercase}.printer__header__buttons__switch--enabled[_ngcontent-%COMP%]{cursor:pointer;background-color:#1194f6}.printer__header__buttons__switch--disabled[_ngcontent-%COMP%]{cursor:default;background-color:rgba(17,148,246,.5)}.printer__body[_ngcontent-%COMP%]{padding:25px;margin-top:15px;font-size:16px}.printer__body__label[_ngcontent-%COMP%]{font-weight:700;line-height:25px;color:#000;text-align:left}.printer__body__text[_ngcontent-%COMP%]{line-height:25px;color:rgba(107,107,107,.87);text-align:right}"]
                ],
                b = e.Gb({
                    encapsulation: 0,
                    styles: p,
                    data: {}
                });

            function h(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 55, "div", [
                    ["class", "printer__body grid grid-12"]
                ], null, null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 15, "div", [
                    ["class", "col col-2"]
                ], null, null, null, null, null)), (n()(), e.Ib(2, 0, null, null, 2, "p", [
                    ["class", "printer__body__label"]
                ], null, null, null, null, null)), (n()(), e.cc(3, null, ["", ":"])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(5, 0, null, null, 2, "p", [
                    ["class", "printer__body__label"]
                ], null, null, null, null, null)), (n()(), e.cc(6, null, ["", ":"])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(8, 0, null, null, 2, "p", [
                    ["class", "printer__body__label"]
                ], null, null, null, null, null)), (n()(), e.cc(9, null, ["", ":"])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(11, 0, null, null, 2, "p", [
                    ["class", "printer__body__label"]
                ], null, null, null, null, null)), (n()(), e.cc(12, null, ["", ":"])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(14, 0, null, null, 2, "p", [
                    ["class", "printer__body__label"]
                ], null, null, null, null, null)), (n()(), e.cc(15, null, ["", ":"])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(17, 0, null, null, 10, "div", [
                    ["class", "col col-4"]
                ], null, null, null, null, null)), (n()(), e.Ib(18, 0, null, null, 1, "p", [
                    ["class", "printer__body__text"]
                ], null, null, null, null, null)), (n()(), e.cc(-1, null, ["- \xa0"])), (n()(), e.Ib(20, 0, null, null, 1, "p", [
                    ["class", "printer__body__text"]
                ], null, null, null, null, null)), (n()(), e.cc(-1, null, ["- \xa0"])), (n()(), e.Ib(22, 0, null, null, 1, "p", [
                    ["class", "printer__body__text"]
                ], null, null, null, null, null)), (n()(), e.cc(23, null, ["", " \xa0"])), (n()(), e.Ib(24, 0, null, null, 1, "p", [
                    ["class", "printer__body__text"]
                ], null, null, null, null, null)), (n()(), e.cc(25, null, ["", " \xa0"])), (n()(), e.Ib(26, 0, null, null, 1, "p", [
                    ["class", "printer__body__text"]
                ], null, null, null, null, null)), (n()(), e.cc(27, null, ["", " \xa0"])), (n()(), e.Ib(28, 0, null, null, 0, "div", [
                    ["class", "col col-1"]
                ], null, null, null, null, null)), (n()(), e.Ib(29, 0, null, null, 15, "div", [
                    ["class", "col col-2"]
                ], null, null, null, null, null)), (n()(), e.Ib(30, 0, null, null, 2, "p", [
                    ["class", "printer__body__label"]
                ], null, null, null, null, null)), (n()(), e.cc(31, null, ["", ":"])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(33, 0, null, null, 2, "p", [
                    ["class", "printer__body__label"]
                ], null, null, null, null, null)), (n()(), e.cc(34, null, ["", ":"])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(36, 0, null, null, 2, "p", [
                    ["class", "printer__body__label"]
                ], null, null, null, null, null)), (n()(), e.cc(37, null, ["", ":"])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(39, 0, null, null, 2, "p", [
                    ["class", "printer__body__label"]
                ], null, null, null, null, null)), (n()(), e.cc(40, null, ["", ":"])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(42, 0, null, null, 2, "p", [
                    ["class", "printer__body__label"]
                ], null, null, null, null, null)), (n()(), e.cc(43, null, ["", ":"])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(45, 0, null, null, 10, "div", [
                    ["class", "col col-3"]
                ], null, null, null, null, null)), (n()(), e.Ib(46, 0, null, null, 1, "p", [
                    ["class", "printer__body__text"]
                ], null, null, null, null, null)), (n()(), e.cc(47, null, ["", " \xa0"])), (n()(), e.Ib(48, 0, null, null, 1, "p", [
                    ["class", "printer__body__text"]
                ], null, null, null, null, null)), (n()(), e.cc(-1, null, ["- \xa0"])), (n()(), e.Ib(50, 0, null, null, 1, "p", [
                    ["class", "printer__body__text"]
                ], null, null, null, null, null)), (n()(), e.cc(51, null, ["", " \xa0"])), (n()(), e.Ib(52, 0, null, null, 1, "p", [
                    ["class", "printer__body__text"]
                ], null, null, null, null, null)), (n()(), e.cc(-1, null, ["- \xa0"])), (n()(), e.Ib(54, 0, null, null, 1, "p", [
                    ["class", "printer__body__text"]
                ], null, null, null, null, null)), (n()(), e.cc(-1, null, ["- \xa0"]))], null, (function(n, t) {
                    var l = t.component;
                    n(t, 3, 0, e.dc(t, 3, 0, e.Ub(t, 4).transform("ch_current_version"))), n(t, 6, 0, e.dc(t, 6, 0, e.Ub(t, 7).transform("ch_remote_server"))), n(t, 9, 0, e.dc(t, 9, 0, e.Ub(t, 10).transform("ch_local_ip"))), n(t, 12, 0, e.dc(t, 12, 0, e.Ub(t, 13).transform("ch_public_ip"))), n(t, 15, 0, e.dc(t, 15, 0, e.Ub(t, 16).transform("ch_entity_id"))), n(t, 23, 0, l.unitPrinter.lanUnitInfo.ip), n(t, 25, 0, l.unitPrinter.lanUnitInfo.ip), n(t, 27, 0, l.unitPrinter.lanUnitInfo.unitId), n(t, 31, 0, e.dc(t, 31, 0, e.Ub(t, 32).transform("ch_entity_Name"))), n(t, 34, 0, e.dc(t, 34, 0, e.Ub(t, 35).transform("ch_teamviewer"))), n(t, 37, 0, e.dc(t, 37, 0, e.Ub(t, 38).transform("ch_hardware_id"))), n(t, 40, 0, e.dc(t, 40, 0, e.Ub(t, 41).transform("ch_system"))), n(t, 43, 0, e.dc(t, 43, 0, e.Ub(t, 44).transform("ch_video_streamer_status"))), n(t, 47, 0, l.unitPrinter.lanUnitInfo.unitName), n(t, 51, 0, l.unitPrinter.lanUnitInfo.hardwareId)
                }))
            }

            function g(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 22, "div", [
                    ["class", "printer"]
                ], null, null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 19, "div", [
                    ["class", "printer__header grid grid-12"]
                ], null, null, null, null, null)), (n()(), e.Ib(2, 0, null, null, 8, "div", [
                    ["class", "printer__header__title col col-8"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.changeExpanded() && e);
                    return e
                }), null, null)), (n()(), e.Ib(3, 0, null, null, 2, "span", [
                    ["class", "printer__header__title__toggle icon"]
                ], null, null, null, null, null)), e.Zb(512, null, o.x, o.y, [e.A, e.B, e.o, e.P]), e.Hb(5, 278528, null, 0, o.k, [o.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), (n()(), e.Ib(6, 0, null, null, 0, "span", [
                    ["class", "printer__header__title__icon icon icon-tv printer__header__title__icon--not-selected"]
                ], null, null, null, null, null)), (n()(), e.Ib(7, 0, null, null, 1, "span", [
                    ["class", "printer__header__title__id printer__header__title__id--not-selected"]
                ], null, null, null, null, null)), (n()(), e.cc(8, null, ["", ""])), (n()(), e.Ib(9, 0, null, null, 1, "span", [
                    ["class", "printer__header__title__code printer__header__title__code--not-selected"]
                ], null, null, null, null, null)), (n()(), e.cc(10, null, ["", ""])), (n()(), e.Ib(11, 0, null, null, 9, "div", [
                    ["class", "printer__header__buttons col col-4"]
                ], null, null, null, null, null)), (n()(), e.Ib(12, 0, null, null, 3, "div", [
                    ["class", "printer__header__buttons__displays"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.display() && e);
                    return e
                }), null, null)), (n()(), e.cc(13, null, [" ", " "])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(15, 0, null, null, 0, "span", [
                    ["class", "printer__header__buttons__displays__icon icon icon-new-window"]
                ], null, null, null, null, null)), (n()(), e.Ib(16, 0, null, null, 4, "div", [
                    ["class", "printer__header__buttons__switch"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.selectUnitPrinter() && e);
                    return e
                }), null, null)), e.Zb(512, null, o.x, o.y, [e.A, e.B, e.o, e.P]), e.Hb(18, 278528, null, 0, o.k, [o.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), (n()(), e.cc(19, null, [" ", " "])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.xb(16777216, null, null, 1, null, h)), e.Hb(22, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(n, t) {
                    var l = t.component;
                    n(t, 5, 0, "printer__header__title__toggle icon", l.expanded ? " icon-up" : "icon-down");
                    n(t, 18, 0, "printer__header__buttons__switch", l.entityId === l.unitPrinter.lanUnitInfo.unitId ? "printer__header__buttons__switch--disabled" : "printer__header__buttons__switch--enabled"), n(t, 22, 0, l.expanded)
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 8, 0, l.unitPrinter.lanUnitInfo.unitId), n(t, 10, 0, l.unitPrinter.lanUnitInfo.unitName), n(t, 13, 0, e.dc(t, 13, 0, e.Ub(t, 14).transform("ch_displays"))), n(t, 19, 0, e.dc(t, 19, 0, e.Ub(t, 20).transform("ch_switch")))
                }))
            }

            function f(n) {
                return e.ec(2, [(n()(), e.xb(16777216, null, null, 1, null, g)), e.Hb(1, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(n, t) {
                    var l = t.component;
                    n(t, 1, 0, l.entityId !== l.unitPrinter.lanUnitInfo.unitId)
                }), null)
            }
            e.Eb("grc-printer", d.a, (function(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "grc-printer", [], null, null, null, f, b)), e.Hb(1, 245760, null, 0, d.a, [e.i], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                unitPrinter: "unitPrinter",
                entityId: "entityId"
            }, {
                switchUnitPrinter: "switchUnitPrinter",
                unitSelected: "unitSelected"
            }, []);
            var m = l("0sFr"),
                _ = l("V4K8"),
                v = l("oEwP"),
                y = l("7oEI"),
                C = [
                    [".printers[_ngcontent-%COMP%]{width:1150px;background-color:#fff}.printers__header[_ngcontent-%COMP%]{height:70px;border-bottom:4px solid #ddd}.printers__header__title[_ngcontent-%COMP%]{float:left;padding:20px}.printers__header__title__label[_ngcontent-%COMP%]{font-size:20px;text-transform:uppercase}.printers__header__title__icon[_ngcontent-%COMP%]{font-size:20px}.printers__header__close[_ngcontent-%COMP%]{float:right;padding:10px;cursor:pointer}.printers__header__close[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{font-size:24px}.printers__list[_ngcontent-%COMP%]{height:600px;padding:20px;overflow-y:auto}.printers__list__unit__title[_ngcontent-%COMP%]{font-size:20px;text-transform:uppercase}.printers__list__unit__container[_ngcontent-%COMP%]{margin-top:10px;margin-bottom:40px}.printers__list__unit__container__no-units[_ngcontent-%COMP%]{font-size:18px;text-align:center;text-transform:none;color:rgba(0,0,0,.6)}.printers__list__unit__loading[_ngcontent-%COMP%]{margin:40px;text-align:center}.printers__list__unit__loading__spin[_ngcontent-%COMP%]{font-size:40px;-webkit-animation:1.2s linear infinite rotate-ring;animation:1.2s linear infinite rotate-ring}.printers__list__more__title[_ngcontent-%COMP%]{font-size:20px;text-transform:uppercase}.printers__list__more__reload[_ngcontent-%COMP%]{text-transform:uppercase;float:right;font-size:14px;cursor:pointer}.printers__list__container[_ngcontent-%COMP%]{margin-top:10px}.printers__list__container__no-units[_ngcontent-%COMP%]{margin-top:150px;font-size:18px;text-align:center;text-transform:none;color:rgba(0,0,0,.6)}.printers__list__container__loading[_ngcontent-%COMP%]{margin:40px;text-align:center}.printers__list__container__loading__spin[_ngcontent-%COMP%]{font-size:40px;-webkit-animation:1.2s linear infinite rotate-ring;animation:1.2s linear infinite rotate-ring}.printers__footer[_ngcontent-%COMP%] > hr[_ngcontent-%COMP%]{border:2px solid #ddd;box-shadow:0 1px 4px rgba(0,0,0,.1)}.printers__footer__title[_ngcontent-%COMP%]{padding:30px}.printers__footer__title__icon[_ngcontent-%COMP%]{font-size:30px}.printers__footer__title__text[_ngcontent-%COMP%]{margin-left:10px;font-size:25px;text-transform:uppercase}.printers__footer__selectprinter[_ngcontent-%COMP%]{padding-top:20px}.printers__footer__selectprinter__text[_ngcontent-%COMP%]{font-size:18px;text-align:right;padding-top:15px;padding-right:10px}.printers__footer__selectprinter__select[_ngcontent-%COMP%]{width:200px;height:48px}[_ngcontent-%COMP%]::-webkit-scrollbar{width:6px}[_ngcontent-%COMP%]::-webkit-scrollbar-track{background:#f1f1f1}[_ngcontent-%COMP%]::-webkit-scrollbar-thumb{background:#c7c7c7}[_ngcontent-%COMP%]::-webkit-scrollbar-thumb:hover{background:#c7c7c7}"]
                ],
                k = e.Gb({
                    encapsulation: 0,
                    styles: C,
                    data: {}
                });

            function x(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 3, "div", [
                    ["class", "printers__list__unit__container__no-units"]
                ], null, null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 2, "span", [], null, null, null, null, null)), (n()(), e.cc(2, null, ["", ""])), e.Wb(131072, i.j, [i.k, e.i])], null, (function(n, t) {
                    n(t, 2, 0, e.dc(t, 2, 0, e.Ub(t, 3).transform("ch_no_more_units_available")))
                }))
            }

            function I(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "div", [
                    ["class", "printers__list__unit__loading"]
                ], null, null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 0, "span", [
                    ["class", "icon icon-loading-spinner printers__list__container__loading__spin"]
                ], null, null, null, null, null))], null, null)
            }

            function S(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "grc-my-printer", [], null, [
                    [null, "switchUnitPrinter"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "switchUnitPrinter" === t && (e = !1 !== i.selecthUnitPrinter(l) && e);
                    return e
                }), a, s)), e.Hb(1, 245760, null, 0, r.a, [e.i], {
                    unitPrinter: [0, "unitPrinter"],
                    localHostInfo: [1, "localHostInfo"],
                    anyUnitSelected: [2, "anyUnitSelected"],
                    entityName: [3, "entityName"],
                    entityId: [4, "entityId"],
                    hardwareId: [5, "hardwareId"]
                }, {
                    switchUnitPrinter: "switchUnitPrinter"
                })], (function(n, t) {
                    var l = t.component;
                    n(t, 1, 0, l.selectedUnitPrinter, l.localHostInfo, l.anyUnitSelected, l.entityName, l.entityId, l.hwId)
                }), null)
            }

            function w(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 2, "div", [], null, null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, S)), e.Hb(2, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(n, t) {
                    n(t, 2, 0, t.component.localHostInfo)
                }), null)
            }

            function O(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 3, "div", [
                    ["class", "printers__list__container__no-units"]
                ], null, null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 2, "span", [], null, null, null, null, null)), (n()(), e.cc(2, null, ["", ""])), e.Wb(131072, i.j, [i.k, e.i])], null, (function(n, t) {
                    n(t, 2, 0, e.dc(t, 2, 0, e.Ub(t, 3).transform("ch_no_more_units_available")))
                }))
            }

            function P(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "div", [
                    ["class", "printers__list__container__loading"]
                ], null, null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 0, "span", [
                    ["class", "icon icon-loading-spinner printers__list__container__loading__spin"]
                ], null, null, null, null, null))], null, null)
            }

            function M(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "grc-printer", [], null, [
                    [null, "switchUnitPrinter"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "switchUnitPrinter" === t && (e = !1 !== i.selecthUnitPrinter(l) && e);
                    return e
                }), f, b)), e.Hb(1, 245760, null, 0, d.a, [e.i], {
                    unitPrinter: [0, "unitPrinter"],
                    entityId: [1, "entityId"]
                }, {
                    switchUnitPrinter: "switchUnitPrinter"
                })], (function(n, t) {
                    var l = t.component;
                    n(t, 1, 0, t.context.$implicit, l.entityId)
                }), null)
            }

            function T(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 2, "div", [], null, null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, M)), e.Hb(2, 278528, null, 0, o.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(n, t) {
                    n(t, 2, 0, t.component.moreUnitsPrinter)
                }), null)
            }

            function j(n) {
                return e.ec(2, [(n()(), e.Ib(0, 0, null, null, 52, "div", [
                    ["class", "printers"]
                ], null, null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 7, "div", [
                    ["class", "printers__header"]
                ], null, null, null, null, null)), (n()(), e.Ib(2, 0, null, null, 4, "div", [
                    ["class", "printers__header__title"]
                ], null, null, null, null, null)), (n()(), e.Ib(3, 0, null, null, 0, "span", [
                    ["class", "printers__header__title__icon icon icon-unit"]
                ], null, null, null, null, null)), (n()(), e.Ib(4, 0, null, null, 2, "span", [
                    ["class", "printers__header__title__label"]
                ], null, null, null, null, null)), (n()(), e.cc(5, null, [" ", ""])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(7, 0, null, null, 1, "div", [
                    ["class", "printers__header__close"]
                ], null, null, null, null, null)), (n()(), e.Ib(8, 0, null, null, 0, "span", [
                    ["class", "icon icon-cancel"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.closePrinters() && e);
                    return e
                }), null, null)), (n()(), e.Ib(9, 0, null, null, 26, "div", [
                    ["class", "printers__list"]
                ], null, null, null, null, null)), (n()(), e.Ib(10, 0, null, null, 3, "div", [
                    ["class", "printers__list__unit"]
                ], null, null, null, null, null)), (n()(), e.Ib(11, 0, null, null, 2, "span", [
                    ["class", "printers__list__unit__title"]
                ], null, null, null, null, null)), (n()(), e.cc(12, null, ["", ""])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(14, 0, null, null, 6, "div", [
                    ["class", "printers__list__unit__container"]
                ], null, null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, x)), e.Hb(16, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.xb(16777216, null, null, 1, null, I)), e.Hb(18, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.xb(16777216, null, null, 1, null, w)), e.Hb(20, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.Ib(21, 0, null, null, 7, "div", [
                    ["class", "printers__list__more"]
                ], null, null, null, null, null)), (n()(), e.Ib(22, 0, null, null, 2, "span", [
                    ["class", "printers__list__more__title"]
                ], null, null, null, null, null)), (n()(), e.cc(23, null, [" ", ""])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(25, 0, null, null, 3, "span", [
                    ["class", "printers__list__more__reload"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.reload() && e);
                    return e
                }), null, null)), (n()(), e.cc(26, null, [" ", " "])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(28, 0, null, null, 0, "span", [
                    ["class", "icon icon-reload"]
                ], null, null, null, null, null)), (n()(), e.Ib(29, 0, null, null, 6, "div", [
                    ["class", "printers__list__container"]
                ], null, null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, O)), e.Hb(31, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.xb(16777216, null, null, 1, null, P)), e.Hb(33, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.xb(16777216, null, null, 1, null, T)), e.Hb(35, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.Ib(36, 0, null, null, 16, "div", [
                    ["class", "printers__footer"]
                ], null, null, null, null, null)), (n()(), e.Ib(37, 0, null, null, 0, "hr", [], null, null, null, null, null)), (n()(), e.Ib(38, 0, null, null, 14, "div", [
                    ["class", "grid grid-12"]
                ], null, null, null, null, null)), (n()(), e.Ib(39, 0, null, null, 4, "div", [
                    ["class", "printers__footer__title col col-3"]
                ], null, null, null, null, null)), (n()(), e.Ib(40, 0, null, null, 0, "span", [
                    ["class", "printers__footer__title__icon icon icon-printer"]
                ], null, null, null, null, null)), (n()(), e.Ib(41, 0, null, null, 2, "span", [
                    ["class", "printers__footer__title__text"]
                ], null, null, null, null, null)), (n()(), e.cc(42, null, ["", ""])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(44, 0, null, null, 8, "div", [
                    ["class", "printers__footer__selectprinter col col-9"]
                ], null, null, null, null, null)), (n()(), e.Ib(45, 0, null, null, 7, "div", [
                    ["class", "grid grid-12"]
                ], null, null, null, null, null)), (n()(), e.Ib(46, 0, null, null, 3, "div", [
                    ["class", "col col-5 printers__footer__selectprinter__text"]
                ], null, null, null, null, null)), (n()(), e.Ib(47, 0, null, null, 2, "span", [], null, null, null, null, null)), (n()(), e.cc(48, null, ["", ":"])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(50, 0, null, null, 2, "div", [
                    ["class", "col col-7 printers__footer__selectprinter__select"]
                ], null, null, null, null, null)), (n()(), e.Ib(51, 0, null, null, 1, "grc-select-printer", [], null, [
                    [null, "switchPrinter"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "switchPrinter" === t && (e = !1 !== i.switchSelectPrinter(l) && e);
                    return e
                }), m.b, m.a)), e.Hb(52, 114688, null, 0, _.a, [e.i], {
                    printers: [0, "printers"],
                    width: [1, "width"],
                    height: [2, "height"]
                }, {
                    switchPrinter: "switchPrinter"
                })], (function(n, t) {
                    var l = t.component;
                    n(t, 16, 0, !l.localHostInfo), n(t, 18, 0, l.loadUnit), n(t, 20, 0, !l.loadUnit), n(t, 31, 0, !l.moreUnitsPrinter || l.moreUnitsPrinter.length <= 0), n(t, 33, 0, l.loadMoreUnits), n(t, 35, 0, !l.loadMoreUnits), n(t, 52, 0, l.printers, l.widthSelect, l.heightSelect)
                }), (function(n, t) {
                    n(t, 5, 0, e.dc(t, 5, 0, e.Ub(t, 6).transform("ch_units"))), n(t, 12, 0, e.dc(t, 12, 0, e.Ub(t, 13).transform("ch_logging"))), n(t, 23, 0, e.dc(t, 23, 0, e.Ub(t, 24).transform("ch_more_units"))), n(t, 26, 0, e.dc(t, 26, 0, e.Ub(t, 27).transform("ch_reload"))), n(t, 42, 0, e.dc(t, 42, 0, e.Ub(t, 43).transform("ch_printer"))), n(t, 48, 0, e.dc(t, 48, 0, e.Ub(t, 49).transform("ch_ticket_printer")))
                }))
            }
            var E = e.Eb("grc-printers", v.a, (function(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "grc-printers", [], null, null, null, j, k)), e.Hb(1, 245760, null, 0, v.a, [e.i, y.a], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                title: "title",
                hwId: "hwId",
                discoverController: "discoverController",
                systemController: "systemController",
                printers: "printers",
                entityName: "entityName",
                entityId: "entityId"
            }, {
                switchPrinter: "switchPrinter",
                switchUnitPrinter: "switchUnitPrinter"
            }, [])
        },
        "2Iqj": function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return e
            }));
            l("CrY/");
            var e = function() {
                function n() {
                    this.showName = !1
                }
                return n.prototype.ngOnInit = function() {}, n
            }()
        },
        "2z2z": function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return f
            }));
            var e = l("CcnG"),
                i = l("gIcY"),
                o = l("Ip0R"),
                r = l("5EE+"),
                u = l("bma8"),
                s = l("7oEI"),
                c = [
                    [".alphanumeric-keypad[_ngcontent-%COMP%]{max-width:1225px;height:675px;padding:100px;font-weight:700}.alphanumeric-keypad__label[_ngcontent-%COMP%]{font-size:20px}.alphanumeric-keypad__input[_ngcontent-%COMP%]{width:700px;height:57px;padding-left:15px;font-size:44px;font-weight:700;pointer-events:none;border-top:0;border-right:0;border-left:0;outline:0}.alphanumeric-keypad--error[_ngcontent-%COMP%]{height:16px;margin-top:10px;margin-bottom:78px}.alphanumeric-keypad__button[_ngcontent-%COMP%]{display:flex;justify-content:center;align-items:center;padding:22px;font-size:32px;text-align:center;cursor:pointer;border-radius:2px}.alphanumeric-keypad__button--danger[_ngcontent-%COMP%]{height:100%;font-size:22px}.alphanumeric-keypad__button--success[_ngcontent-%COMP%]{height:100%;padding:0;font-size:32px}.alphanumeric-keypad__button--separation[_ngcontent-%COMP%]{padding:0 3px}.alphanumeric-keypad--resize-clear-button[_ngcontent-%COMP%]{flex-grow:2;padding-left:7.5px}.alphanumeric-keypad--resize-clear-button[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{margin-left:-5px}.alphanumeric-keypad--resize-enter-button[_ngcontent-%COMP%]{margin-left:5px}.alphanumeric-keypad--resize-container[_ngcontent-%COMP%]{flex-grow:9;margin-right:-5px}.alphanumeric-keypad--row-margin[_ngcontent-%COMP%]{margin-bottom:8px}.alphanumeric-keypad__close[_ngcontent-%COMP%]{position:absolute;top:30px;right:30px;cursor:pointer}.alphanumeric-keypad__close[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{font-size:24px}"]
                ],
                a = e.Gb({
                    encapsulation: 0,
                    styles: c,
                    data: {}
                });

            function d(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 2, "div", [
                    ["class", "col alphanumeric-keypad__button--separation"]
                ], null, null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 1, "div", [
                    ["class", "alphanumeric-keypad__button"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.insert(n.context.$implicit) && e);
                    return e
                }), null, null)), (n()(), e.cc(2, null, ["", ""]))], null, (function(n, t) {
                    n(t, 2, 0, t.context.$implicit)
                }))
            }

            function p(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 2, "div", [
                    ["class", "col alphanumeric-keypad__button--separation"]
                ], null, null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 1, "div", [
                    ["class", "alphanumeric-keypad__button"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.insert(n.context.$implicit) && e);
                    return e
                }), null, null)), (n()(), e.cc(2, null, ["", ""]))], null, (function(n, t) {
                    n(t, 2, 0, t.context.$implicit)
                }))
            }

            function b(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 2, "div", [
                    ["class", "col alphanumeric-keypad__button--separation"]
                ], null, null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 1, "div", [
                    ["class", "alphanumeric-keypad__button"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.insert(n.context.$implicit) && e);
                    return e
                }), null, null)), (n()(), e.cc(2, null, ["", ""]))], null, (function(n, t) {
                    n(t, 2, 0, t.context.$implicit)
                }))
            }

            function h(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 2, "div", [
                    ["class", "col alphanumeric-keypad__button--separation"]
                ], null, null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 1, "div", [
                    ["class", "alphanumeric-keypad__button"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.insert(n.context.$implicit) && e);
                    return e
                }), null, null)), (n()(), e.cc(2, null, ["", ""]))], null, (function(n, t) {
                    n(t, 2, 0, t.context.$implicit)
                }))
            }

            function g(n) {
                return e.ec(2, [(n()(), e.Ib(0, 0, null, null, 34, "div", [
                    ["class", "grid grid-column alphanumeric-keypad"]
                ], null, null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 1, "div", [
                    ["class", "alphanumeric-keypad__close"]
                ], null, null, null, null, null)), (n()(), e.Ib(2, 0, null, null, 0, "span", [
                    ["class", "icon icon-cancel"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.closeKeypad() && e);
                    return e
                }), null, null)), (n()(), e.Ib(3, 0, null, null, 1, "div", [
                    ["class", "alphanumeric-keypad__label"]
                ], null, null, null, null, null)), (n()(), e.cc(4, null, ["", ""])), (n()(), e.Ib(5, 0, null, null, 5, "input", [
                    ["class", "alphanumeric-keypad__input"],
                    ["type", "text"]
                ], [
                    [2, "alphanumeric-keypad__input--error", null],
                    [2, "ng-untouched", null],
                    [2, "ng-touched", null],
                    [2, "ng-pristine", null],
                    [2, "ng-dirty", null],
                    [2, "ng-valid", null],
                    [2, "ng-invalid", null],
                    [2, "ng-pending", null]
                ], [
                    [null, "input"],
                    [null, "blur"],
                    [null, "compositionstart"],
                    [null, "compositionend"]
                ], (function(n, t, l) {
                    var i = !0;
                    "input" === t && (i = !1 !== e.Ub(n, 6)._handleInput(l.target.value) && i);
                    "blur" === t && (i = !1 !== e.Ub(n, 6).onTouched() && i);
                    "compositionstart" === t && (i = !1 !== e.Ub(n, 6)._compositionStart() && i);
                    "compositionend" === t && (i = !1 !== e.Ub(n, 6)._compositionEnd(l.target.value) && i);
                    return i
                }), null, null)), e.Hb(6, 16384, null, 0, i.d, [e.P, e.o, [2, i.a]], null, null), e.Zb(1024, null, i.h, (function(n) {
                    return [n]
                }), [i.d]), e.Hb(8, 671744, null, 0, i.m, [
                    [8, null],
                    [8, null],
                    [8, null],
                    [6, i.h]
                ], {
                    model: [0, "model"]
                }, null), e.Zb(2048, null, i.i, null, [i.m]), e.Hb(10, 16384, null, 0, i.j, [
                    [4, i.i]
                ], null, null), (n()(), e.Ib(11, 0, null, null, 1, "div", [
                    ["class", "alphanumeric-keypad--error"]
                ], null, null, null, null, null)), (n()(), e.cc(12, null, ["", ""])), (n()(), e.Ib(13, 0, null, null, 21, "div", [
                    ["class", "col"]
                ], null, null, null, null, null)), (n()(), e.Ib(14, 0, null, null, 2, "div", [
                    ["class", "col grid alphanumeric-keypad--row-margin"]
                ], null, null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, d)), e.Hb(16, 278528, null, 0, o.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), (n()(), e.Ib(17, 0, null, null, 2, "div", [
                    ["class", "col grid alphanumeric-keypad--row-margin"]
                ], null, null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, p)), e.Hb(19, 278528, null, 0, o.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), (n()(), e.Ib(20, 0, null, null, 14, "div", [
                    ["class", "col grid"]
                ], null, null, null, null, null)), (n()(), e.Ib(21, 0, null, null, 10, "div", [
                    ["class", "col alphanumeric-keypad--resize-container"]
                ], null, null, null, null, null)), (n()(), e.Ib(22, 0, null, null, 2, "div", [
                    ["class", "col grid alphanumeric-keypad--row-margin"]
                ], null, null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, b)), e.Hb(24, 278528, null, 0, o.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), (n()(), e.Ib(25, 0, null, null, 6, "div", [
                    ["class", "col grid"]
                ], null, null, null, null, null)), (n()(), e.Ib(26, 0, null, null, 3, "div", [
                    ["class", "col alphanumeric-keypad--resize-clear-button alphanumeric-keypad__button--separation"]
                ], null, null, null, null, null)), (n()(), e.Ib(27, 0, null, null, 2, "div", [
                    ["class", "alphanumeric-keypad__button alphanumeric-keypad__button--danger"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.clear() && e);
                    return e
                }), null, null)), (n()(), e.cc(28, null, [" ", " "])), e.Wb(131072, r.j, [r.k, e.i]), (n()(), e.xb(16777216, null, null, 1, null, h)), e.Hb(31, 278528, null, 0, o.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), (n()(), e.Ib(32, 0, null, null, 2, "div", [
                    ["class", "col alphanumeric-keypad__button--separation"]
                ], null, null, null, null, null)), (n()(), e.Ib(33, 0, null, null, 1, "div", [
                    ["class", "alphanumeric-keypad__button alphanumeric-keypad__button--success alphanumeric-keypad--resize-enter-button"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.ok() && e);
                    return e
                }), null, null)), (n()(), e.cc(-1, null, [" OK "]))], (function(n, t) {
                    var l = t.component;
                    n(t, 8, 0, l.content), n(t, 16, 0, l.numbers), n(t, 19, 0, l.letters.rowOne), n(t, 24, 0, l.letters.rowTwo), n(t, 31, 0, l.letters.rowThree)
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 4, 0, l.title), n(t, 5, 0, l.error, e.Ub(t, 10).ngClassUntouched, e.Ub(t, 10).ngClassTouched, e.Ub(t, 10).ngClassPristine, e.Ub(t, 10).ngClassDirty, e.Ub(t, 10).ngClassValid, e.Ub(t, 10).ngClassInvalid, e.Ub(t, 10).ngClassPending), n(t, 12, 0, l.error), n(t, 28, 0, e.dc(t, 28, 0, e.Ub(t, 29).transform("ch_clear")))
                }))
            }
            var f = e.Eb("grc-alphanumeric-keypad", u.a, (function(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "grc-alphanumeric-keypad", [], null, [
                    ["document", "keydown"],
                    ["document", "keydown.backspace"],
                    ["document", "keydown.enter"],
                    ["document", "paste"]
                ], (function(n, t, l) {
                    var i = !0;
                    "document:keydown" === t && (i = !1 !== e.Ub(n, 1).onKeyDown(l.key, l.keyCode, l.ctrlKey) && i);
                    "document:keydown.backspace" === t && (i = !1 !== e.Ub(n, 1).onBackspace() && i);
                    "document:keydown.enter" === t && (i = !1 !== e.Ub(n, 1).onEnter() && i);
                    "document:paste" === t && (i = !1 !== e.Ub(n, 1).onPaste(l) && i);
                    return i
                }), g, a)), e.Hb(1, 114688, null, 0, u.a, [e.i, s.a, r.k], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                title: "title"
            }, {
                success: "success"
            }, [])
        },
        "38rj": function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return i
            }));
            var e = l("CcnG"),
                i = (l("tfG9"), function() {
                    function n(n, t) {
                        this.scriptService = n, this.renderer = t, this.formEvent = new e.q
                    }
                    return n.prototype.ngOnInit = function() {
                        var n = this.scriptService.loadJsScript(this.renderer, "assets/scripts/ngx-scanner-qrcode/index.js");
                        n.onload = function() {
                            console.log("OK")
                        }, n.onerror = function() {
                            console.log("Could not load the Google API Script!")
                        }
                    }, n.prototype.onClick = function() {
                        this.formEvent.emit(null)
                    }, n.prototype.getContent = function(n) {
                        n instanceof Array && n.length > 0 && (this.formEvent.emit(n[0].value), this.closeCamera())
                    }, n.prototype.scan = function() {
                        this.input.start()
                    }, n.prototype.closeCamera = function() {
                        this.input.isStart && this.input.stop()
                    }, n
                }())
        },
        "3cbp": function(n, t, l) {
            "use strict";
            var e;
            l.d(t, "b", (function() {
                    return e
                })), l.d(t, "a", (function() {
                    return i
                })),
                function(n) {
                    n.LEFT = "left", n.RIGHT = "right", n.CONTENT = "content"
                }(e || (e = {}));
            var i = function() {
                function n() {
                    this.side = e.LEFT, this.class = ""
                }
                return n.prototype.ngOnInit = function() {}, n
            }()
        },
        "4TAQ": function(n, t, l) {
            var e = {
                "./common.js": ["mv+f", 0],
                "./football-grammar.js": ["fnUq", 4, 6],
                "./football.js": ["ALeE", 4, 6, 0, 19],
                "./races-grammar.js": ["CAXR", 7],
                "./races.js": ["oXa/", 4, 7, 0, 20]
            };

            function i(n) {
                if (!l.o(e, n)) return Promise.resolve().then((function() {
                    var t = new Error("Cannot find module '" + n + "'");
                    throw t.code = "MODULE_NOT_FOUND", t
                }));
                var t = e[n],
                    i = t[0];
                return Promise.all(t.slice(1).map(l.e)).then((function() {
                    return l(i)
                }))
            }
            i.keys = function() {
                return Object.keys(e)
            }, i.id = "4TAQ", n.exports = i
        },
        "4hpQ": function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return e
            }));
            var e = function() {}
        },
        "5msJ": function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return r
            }));
            var e = l("0/uQ"),
                i = l("SrN3"),
                o = l("t9fZ"),
                r = function() {
                    function n(n, t, l) {
                        this.environmentPath = t, this.clientsPath = l, this.externalConfigController = new i.ExternalConfigController(n)
                    }
                    return n.prototype.init = function() {
                        return Object(e.a)(this.externalConfigController.initEnvironmentConfig(this.environmentPath)).pipe(Object(o.a)(1))
                    }, n.prototype.loadClientJsonFileParams = function(n) {
                        var t = this.clientsPath.replace(/\{id\}/, "" + n);
                        return Object(e.a)(this.externalConfigController.getEnvironmentConfig().loadClientJsonFileParams(t))
                    }, n.prototype.getEnvironmentConfig = function() {
                        return this.externalConfigController.getEnvironmentConfig()
                    }, n.prototype.updateEnvironmentConfig = function(n) {
                        this.externalConfigController.getEnvironmentConfig().updateConfigParams(n)
                    }, n
                }()
        },
        "5tmv": function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return e
            }));
            var e = function() {
                function n() {
                    this.isActive = !1
                }
                return n.prototype.ngOnInit = function() {}, n
            }()
        },
        "5y7H": function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return i
            }));
            var e = l("CcnG"),
                i = function() {
                    function n() {
                        this.numberSelected = new e.q
                    }
                    return n.prototype.onClick = function(n) {
                        this.numberSelected.emit(n)
                    }, n
                }()
        },
        "7Dvu": function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return i
            }));
            var e = l("CrY/");

            function i(n, t) {
                var l, i, o;
                return t ? "COLOR_COLOR" === (null === (l = null == n ? void 0 : n.assets) || void 0 === l ? void 0 : l.layout) && ((null === (i = t.betParam) || void 0 === i ? void 0 : i.includes(e.RainbowColorType.YELLOW)) || t.oddId === e.RainbowColorType.YELLOW) : "COLOR_COLOR" === (null === (o = null == n ? void 0 : n.assets) || void 0 === o ? void 0 : o.layout)
            }
        },
        "7oEI": function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return a
            }));
            var e = l("CcnG"),
                i = l("pugT"),
                o = l("6blF"),
                r = l("t9fZ"),
                u = l("xMyE"),
                s = l("y+mV"),
                c = l("B5my"),
                a = (l("ojct"), function() {
                    function n(n, t) {
                        this.componentFactoryResolver = n, this.modalStoreService = t
                    }
                    return n.prototype.open = function(n, t, l) {
                        void 0 === l && (l = {});
                        var s = this.modalStoreService.get(n);
                        if (s.destroyable || !s.initialized) {
                            var c = this.componentFactoryResolver.resolveComponentFactory(t);
                            s.viewContainerRef.clear(), s.currentModalRef = s.viewContainerRef.createComponent(c)
                        }
                        var a = {};
                        for (var d in l.inputs) d && (a[d] = new e.V(s.currentModalRef.instance[d], l.inputs[d], !s.initialized), s.currentModalRef.instance[d] = l.inputs[d]);
                        var p = new i.a;
                        for (var b in l.outputs) b && p.add(s.currentModalRef.instance[b].subscribe(l.outputs[b]));
                        return s.currentModalRef.instance.ngOnChanges && s.currentModalRef.instance.ngOnChanges(a), s.initialized = !0, this.modalStoreService.open(n), {
                            afterClosed: new o.a((function(n) {
                                delete s.afterClosed, s.afterClosed = n
                            })).pipe(Object(r.a)(1), Object(u.a)((function() {
                                return p.unsubscribe()
                            })))
                        }
                    }, n.prototype.openDialog = function(n, t) {
                        return this.open(n, c.a, {
                            inputs: {
                                configuration: t,
                                modalId: n
                            }
                        })
                    }, n.prototype.openDataDialog = function(n, t) {
                        return this.dataDialogOpened = !0, this.open(n, s.a, {
                            inputs: {
                                configuration: t,
                                modalId: n
                            }
                        })
                    }, n.prototype.createMaxPayoutModal = function(n) {
                        var t = this;
                        return new o.a((function(l) {
                            n ? t.openDataDialog("base", {
                                type: "danger",
                                icon: "icon icon-warning",
                                iconColor: "#000000",
                                isMaxPayout: !0
                            }).afterClosed.subscribe((function(n) {
                                t.dataDialogOpened = !1, n.detail ? l.next(n.detail.formResult) : l.next("closedModalByUser")
                            })) : l.next(null)
                        }))
                    }, n.prototype.close = function(n) {
                        this.modalStoreService.close(n)
                    }, n.prototype.closeLastOpened = function() {
                        this.modalStoreService.closeLastOpened()
                    }, n
                }())
        },
        "7x4Y": function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return E
            }));
            var e = l("+69r"),
                i = l("M3um"),
                o = l("kMfV"),
                r = l("xTWW"),
                u = l("3cbp"),
                s = l("2Iqj"),
                c = l("jMZ0"),
                a = l("RoHP"),
                d = l("yoGk"),
                p = l("PdBy"),
                b = l("5tmv"),
                h = l("Y53V"),
                g = l("bma8"),
                f = l("k1pK"),
                m = l("imdu"),
                _ = l("qQYQ"),
                v = l("rdml"),
                y = l("5y7H"),
                C = l("ghVy"),
                k = l("hkR0"),
                x = l("UhMo"),
                I = l("0ZGX"),
                S = l("oEwP"),
                w = l("B8qn"),
                O = l("hZz1"),
                P = l("V4K8"),
                M = l("bahv"),
                T = l("EVvl"),
                j = l("D3N7"),
                E = (e.a, i.a, u.a, d.a, p.a, s.a, c.b, j.a, a.a, g.a, f.a, m.a, _.a, v.a, y.a, C.a, k.a, x.a, I.a, S.a, w.a, O.a, P.a, M.a, T.a, r.a, o.a, h.a, b.a, function() {})
        },
        AZLQ: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return i
            }));
            var e = l("CcnG"),
                i = function() {
                    function n() {
                        this.close = new e.q
                    }
                    return n.prototype.ngOnInit = function() {}, n
                }()
        },
        AytR: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return e
            }));
            var e = {
                production: !0,
                hmr: !1
            }
        },
        B5my: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return e
            }));
            var e = function() {
                function n() {}
                return n.prototype.ngOnInit = function() {}, n.prototype.callAction = function(n) {
                    n && n()
                }, n
            }()
        },
        B8qn: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return r
            }));
            var e = l("CcnG"),
                i = l("pugT"),
                o = l("0/uQ"),
                r = (l("n3kJ"), function() {
                    function n(n) {
                        this.cd = n, this.switchUnitPrinter = new e.q, this.unitSelected = new e.q, this.expanded = !1, this.subscription = new i.a
                    }
                    return n.prototype.ngOnInit = function() {}, n.prototype.changeExpanded = function() {
                        this.expanded = !this.expanded, this.cd.detectChanges()
                    }, n.prototype.selectUnitPrinter = function() {
                        this.entityId !== this.unitPrinter.getLanUnitInfo().unitId && this.switchUnitPrinter.emit(this.unitPrinter.getLanUnitInfo().hardwareId)
                    }, n.prototype.display = function() {
                        var n = this,
                            t = Object(o.a)(this.unitPrinter.loadLanUnitUrls());
                        this.subscription.add(t.subscribe({
                            next: function() {
                                return n.unitPrinter.openLobbyUrl()
                            }
                        }))
                    }, n.prototype.ngOnDestroy = function() {
                        this.subscription.unsubscribe()
                    }, n
                }())
        },
        D3N7: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return i
            }));
            var e = l("CcnG"),
                i = function() {
                    function n() {
                        this.multipliers = [], this.maxMultiplier = 0, this.multiplier = new e.q, this.isMultiplierInvalid = new e.q, this.multipliersSelected = []
                    }
                    return n.prototype.ngOnInit = function() {
                        this.multipliersSelected.push(this.multipliers[0])
                    }, n.prototype.isSelected = function(n) {
                        return this.multipliersSelected.includes(n)
                    }, n.prototype.onClick = function(n) {
                        this.isSelected(n) ? this.multipliersSelected.length > 1 && this.deleteUnselected(n) : this.isValidMultiplier(n) && this.addSelected(n);
                        var t = this.getMultiplierSumatory();
                        this.multiplier.emit(t)
                    }, n.prototype.resetMultiplier = function() {
                        this.multipliersSelected = [1], this.multiplier.emit(1)
                    }, n.prototype.getMultiplierSumatory = function() {
                        return this.multipliersSelected.reduce((function(n, t) {
                            return n + t
                        }), 0)
                    }, n.prototype.addSelected = function(n) {
                        this.multipliersSelected.push(n)
                    }, n.prototype.deleteUnselected = function(n) {
                        this.multipliersSelected = this.multipliersSelected.filter((function(t) {
                            return t !== n
                        }))
                    }, n.prototype.isValidMultiplier = function(n) {
                        var t = !0;
                        return this.getMultiplierSumatory() + n > this.maxMultiplier && (t = !1, this.isMultiplierInvalid.emit(!0)), t
                    }, n
                }()
        },
        E6sH: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return p
            }));
            var e = l("CcnG"),
                i = l("Ip0R"),
                o = l("RoHP"),
                r = l("ZYjt"),
                u = [
                    ["[_nghost-%COMP%]{position:relative;display:block;height:985px}.iframe-container--src[_ngcontent-%COMP%]{width:1700px}.iframe[_ngcontent-%COMP%]{position:absolute;width:100%;height:100%;min-height:100%}.close[_ngcontent-%COMP%]{position:absolute;top:30px;right:55px;z-index:99999;font-size:24px;cursor:pointer}"]
                ],
                s = e.Gb({
                    encapsulation: 0,
                    styles: u,
                    data: {}
                });

            function c(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, [
                    [1, 0],
                    ["iframe", 1]
                ], null, 0, "iframe", [
                    ["class", "iframe"],
                    ["frameborder", "0"]
                ], [
                    [8, "name", 0],
                    [8, "srcdoc", 1]
                ], null, null, null, null))], null, (function(n, t) {
                    var l = t.component;
                    n(t, 0, 0, l.name, l.safeHtml)
                }))
            }

            function a(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, [
                    [1, 0],
                    ["iframe", 1]
                ], null, 0, "iframe", [
                    ["class", "iframe"],
                    ["frameborder", "0"]
                ], [
                    [8, "name", 0],
                    [8, "src", 5]
                ], null, null, null, null))], null, (function(n, t) {
                    var l = t.component;
                    n(t, 0, 0, l.name, l.safeSrc)
                }))
            }

            function d(n) {
                return e.ec(2, [e.ac(671088640, 1, {
                    iframe: 0
                }), (n()(), e.Ib(1, 0, null, null, 8, "div", [
                    ["class", "iframe-modal iframe-container"],
                    ["id", "iframe"]
                ], null, null, null, null, null)), e.Zb(512, null, i.x, i.y, [e.A, e.B, e.o, e.P]), e.Hb(3, 278528, null, 0, i.k, [i.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), e.Xb(4, {
                    "iframe-container--src": 0
                }), (n()(), e.Ib(5, 0, null, null, 0, "div", [
                    ["class", "close icon icon-cancel"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.closeIframe() && e);
                    return e
                }), null, null)), (n()(), e.xb(16777216, null, null, 1, null, c)), e.Hb(7, 16384, null, 0, i.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.xb(16777216, null, null, 1, null, a)), e.Hb(9, 16384, null, 0, i.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(n, t) {
                    var l = t.component,
                        e = n(t, 4, 0, l.hasSrc);
                    n(t, 3, 0, "iframe-modal iframe-container", e), n(t, 7, 0, l.safeHtml), n(t, 9, 0, l.safeSrc)
                }), null)
            }
            var p = e.Eb("grc-iframe-modal", o.a, (function(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "grc-iframe-modal", [], null, null, null, d, s)), e.Hb(1, 638976, null, 0, o.a, [r.b, e.i], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                htmlTemplate: "htmlTemplate",
                src: "src",
                name: "name",
                hasContentWindow: "hasContentWindow"
            }, {
                close: "close",
                created: "created"
            }, [])
        },
        EVvl: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return i
            }));
            var e = l("CcnG"),
                i = (l("7oEI"), function() {
                    function n(n, t) {
                        this.cd = n, this.modalService = t, this.cancel = new e.q, this.accept = new e.q
                    }
                    return n.prototype.ngOnInit = function() {}, n.prototype.closeInfo = function() {
                        this.modalService.close("base-information")
                    }, n.prototype.clickCancel = function() {
                        this.cancel.emit()
                    }, n.prototype.clickAccept = function() {
                        this.accept.emit(this.hardwareId)
                    }, n
                }())
        },
        GNnp: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return c
            }));
            var e = l("6blF"),
                i = l("F/XL"),
                o = l("G5J1"),
                r = l("W1+X"),
                u = l("psW0"),
                s = (l("iFca"), l("HQhj")),
                c = function() {
                    function n(n, t) {
                        var l = this;
                        this.sanitizer = n, this.configuration = t, this.id = 0, this.configuration = Object.assign({}, {
                            duration: 2e3,
                            closeOnClick: !0
                        }, this.configuration), this.closeObservable = new e.a((function(n) {
                            l.closeObserver = n
                        })).pipe(Object(r.a)()), this.closeObservable.connect()
                    }
                    return n.prototype.register = function(n) {
                        this.notificationsComponent = n
                    }, n.prototype.isRegistered = function() {
                        return !!this.notificationsComponent
                    }, n.prototype.close = function(n) {
                        this.closeObserver.next(n)
                    }, n.prototype.getConfiguration = function() {
                        return this.configuration
                    }, n.prototype.success = function(n) {
                        return this.addNotification(n, s.b.SUCCESS)
                    }, n.prototype.warning = function(n) {
                        return this.addNotification(n, s.b.WARNING)
                    }, n.prototype.info = function(n) {
                        return this.addNotification(n, s.b.INFO)
                    }, n.prototype.danger = function(n) {
                        return this.addNotification(n, s.b.DANGER)
                    }, n.prototype.processMessage = function(n) {
                        if (n.includes("invalid_password") && n.includes("tries_pending")) {
                            var t = n.match(/\d+/g)[0];
                            return {
                                message: n.replace(/\._\(\d+\)/g, ""),
                                value: t
                            }
                        }
                        return n.includes("max_tries_reached") ? {
                            message: n.replace(/[,)(]/g, "")
                        } : {
                            message: n
                        }
                    }, n.prototype.addNotification = function(n, t) {
                        this.notificationsComponent.addNotification({
                            type: t,
                            content: this.sanitizer.bypassSecurityTrustHtml(n),
                            id: this.id
                        });
                        var l = this.id,
                            e = this.closeObservable.pipe(Object(u.a)((function(n) {
                                return n === l ? Object(i.a)(n) : o.a
                            })));
                        return this.id += 1, e
                    }, n
                }()
        },
        GhKF: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return r
            })), l.d(t, "b", (function() {
                return s
            }));
            var e = l("CcnG"),
                i = l("3cbp"),
                o = [
                    [""]
                ],
                r = e.Gb({
                    encapsulation: 0,
                    styles: o,
                    data: {}
                });

            function u(n) {
                return e.ec(0, [e.Tb(null, 0), (n()(), e.xb(0, null, null, 0))], null, null)
            }

            function s(n) {
                return e.ec(2, [e.ac(402653184, 1, {
                    content: 0
                }), (n()(), e.xb(0, [
                    [1, 2]
                ], null, 0, null, u))], null, null)
            }
            e.Eb("grc-tab-fixed", i.a, (function(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "grc-tab-fixed", [], null, null, null, s, r)), e.Hb(1, 114688, null, 0, i.a, [], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                side: "side",
                class: "class"
            }, {}, ["*"])
        },
        HQhj: function(n, t, l) {
            "use strict";
            l.d(t, "b", (function() {
                return e
            })), l.d(t, "a", (function() {
                return o
            }));
            var e, i = l("CcnG");
            ! function(n) {
                n[n.SUCCESS = 0] = "SUCCESS", n[n.WARNING = 1] = "WARNING", n[n.INFO = 2] = "INFO", n[n.DANGER = 3] = "DANGER"
            }(e || (e = {}));
            var o = function() {
                function n() {
                    this.close = new i.q
                }
                return n.prototype.ngOnInit = function() {
                    var n = this;
                    this.timeout = setTimeout((function() {
                        n.close.emit()
                    }), this.duration)
                }, n.prototype.ngOnDestroy = function() {
                    clearTimeout(this.timeout)
                }, n.prototype.onClick = function() {
                    this.closeOnClick && this.close.emit()
                }, n.prototype.isSuccess = function() {
                    return +this.type === e.SUCCESS
                }, n.prototype.isInfo = function() {
                    return +this.type === e.INFO
                }, n.prototype.isWarning = function() {
                    return +this.type === e.WARNING
                }, n.prototype.isDanger = function() {
                    return +this.type === e.DANGER
                }, n
            }()
        },
        KhfW: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return e
            }));
            var e = [".dialog[_ngcontent-%COMP%]{min-width:780px;max-width:400px;min-height:300px;padding:90px 60px;font-weight:700}.dialog__content[_ngcontent-%COMP%]{width:100%;padding-bottom:90px;text-align:center}.dialog__buttons[_ngcontent-%COMP%]{display:flex}.dialog__buttons[_ngcontent-%COMP%] > .dialog-button[_ngcontent-%COMP%]{margin:0 10px}.dialog__buttons[_ngcontent-%COMP%] > .dialog-button[_ngcontent-%COMP%]:first-child{margin-left:0}.dialog__buttons[_ngcontent-%COMP%] > .dialog-button[_ngcontent-%COMP%]:last-child{margin-right:0}.dialog__icon[_ngcontent-%COMP%]{margin-bottom:30px;font-size:60px}.dialog__text[_ngcontent-%COMP%]{font-size:44px;font-weight:400;white-space:pre-line}.dialog--danger[_ngcontent-%COMP%]{padding:0}.dialog--danger[_ngcontent-%COMP%]   .dialog__content[_ngcontent-%COMP%]{padding:90px 60px}.dialog-button[_ngcontent-%COMP%]{display:flex;padding:20px;justify-content:center;align-items:center;font-size:32px;text-align:center;text-transform:uppercase;white-space:nowrap;cursor:pointer}.dialog-button--ghost[_ngcontent-%COMP%]{background-color:transparent;box-shadow:unset}"]
        },
        M3um: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return e
            }));
            var e = function() {
                function n() {
                    this.header = ""
                }
                return n.prototype.ngOnInit = function() {
                    this.id || (this.id = this.header)
                }, n
            }()
        },
        "Md+g": function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return a
            }));
            var e = l("CcnG"),
                i = l("5EE+"),
                o = l("EVvl"),
                r = l("7oEI"),
                u = [
                    [".info-log-off[_ngcontent-%COMP%]{text-align:center;width:600px;height:400px;background-color:#fff}.info-log-off__header__close[_ngcontent-%COMP%]{float:right;padding:10px;cursor:pointer}.info-log-off__header__close[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{font-size:24px}.info-log-off__icon[_ngcontent-%COMP%]{margin-top:40px;margin-left:10px;font-size:80px}.info-log-off__text[_ngcontent-%COMP%]{margin-top:10px;margin-left:10px;font-size:22px;color:#3a3a39}.info-log-off__hwid[_ngcontent-%COMP%]{margin-top:10px;margin-left:10px;font-size:24px;color:#000}.info-log-off__select[_ngcontent-%COMP%]{margin-top:30px;margin-left:10px}.info-log-off__buttons[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{max-width:200px;height:80px;padding:20px;margin:50px;font-size:32px;font-weight:700;text-transform:uppercase}.info-log-off__buttons__cancel[_ngcontent-%COMP%]{color:#000;background-color:#fff;border:2px solid #000;cursor:pointer}.info-log-off__buttons__accept[_ngcontent-%COMP%]{color:#fff}.info-log-off__buttons__accept--enabled[_ngcontent-%COMP%]{cursor:pointer;background-color:#618b31}.info-log-off__buttons__accept--disabled[_ngcontent-%COMP%]{cursor:default;background-color:rgba(97,139,49,.3)}"]
                ],
                s = e.Gb({
                    encapsulation: 0,
                    styles: u,
                    data: {}
                });

            function c(n) {
                return e.ec(2, [(n()(), e.Ib(0, 0, null, null, 21, "div", [
                    ["class", "info-log-off"]
                ], null, null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 1, "div", [
                    ["class", "info-log-off__header"]
                ], null, null, null, null, null)), (n()(), e.Ib(2, 0, null, null, 0, "span", [
                    ["class", "info-log-off__header__close icon icon-cancel"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.closeInfo() && e);
                    return e
                }), null, null)), (n()(), e.Ib(3, 0, null, null, 9, "div", [
                    ["class", "grid grid-12"]
                ], null, null, null, null, null)), (n()(), e.Ib(4, 0, null, null, 1, "div", [
                    ["class", "info-log-off__icon col col-12"]
                ], null, null, null, null, null)), (n()(), e.Ib(5, 0, null, null, 0, "span", [
                    ["class", "icon icon-power"]
                ], null, null, null, null, null)), (n()(), e.Ib(6, 0, null, null, 3, "div", [
                    ["class", "info-log-off__text col col-12"]
                ], null, null, null, null, null)), (n()(), e.Ib(7, 0, null, null, 2, "p", [], null, null, null, null, null)), (n()(), e.cc(8, null, ["", ""])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(10, 0, null, null, 2, "div", [
                    ["class", "info-log-off__text col col-12"]
                ], null, null, null, null, null)), (n()(), e.Ib(11, 0, null, null, 1, "p", [
                    ["class", "info-log-off__hwid"]
                ], null, null, null, null, null)), (n()(), e.cc(12, null, ["", ""])), (n()(), e.Ib(13, 0, null, null, 8, "div", [
                    ["class", "grid grid-12 info-log-off__buttons"]
                ], null, null, null, null, null)), (n()(), e.Ib(14, 0, null, null, 3, "div", [
                    ["class", "info-log-off__buttons__cancel col col-6"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.clickCancel() && e);
                    return e
                }), null, null)), (n()(), e.Ib(15, 0, null, null, 2, "span", [], null, null, null, null, null)), (n()(), e.cc(16, null, ["", ""])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(18, 0, null, null, 3, "div", [
                    ["class", "info-log-off__buttons__accept info-log-off__buttons__accept--enabled col col-6"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.clickAccept() && e);
                    return e
                }), null, null)), (n()(), e.Ib(19, 0, null, null, 2, "span", [], null, null, null, null, null)), (n()(), e.cc(20, null, ["", ""])), e.Wb(131072, i.j, [i.k, e.i])], null, (function(n, t) {
                    var l = t.component;
                    n(t, 8, 0, e.dc(t, 8, 0, e.Ub(t, 9).transform("ch_info_change_hwid"))), n(t, 12, 0, l.hardwareId), n(t, 16, 0, e.dc(t, 16, 0, e.Ub(t, 17).transform("ch_cancel"))), n(t, 20, 0, e.dc(t, 20, 0, e.Ub(t, 21).transform("ch_accept")))
                }))
            }
            var a = e.Eb("grc-info-log-off", o.a, (function(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "grc-info-log-off", [], null, null, null, c, s)), e.Hb(1, 114688, null, 0, o.a, [e.i, r.a], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                title: "title",
                hardwareId: "hardwareId"
            }, {
                cancel: "cancel",
                accept: "accept"
            }, [])
        },
        NPGq: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return e
            }));
            l("CrY/"), l("7oEI");
            var e = function() {
                function n(n) {
                    this.modalService = n
                }
                return n.prototype.ngOnInit = function() {}, n.prototype.close = function() {
                    this.confirmed.confirmed = !this.hasConfirm, this.modalService.close(this.modalId)
                }, n.prototype.confirm = function() {
                    this.confirmed.confirmed = !0, this.modalService.close(this.modalId)
                }, n
            }()
        },
        NTJ2: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return s
            }));
            var e = l("26FU"),
                i = l("K9Ia"),
                o = l("sB3t"),
                r = (l("t01L"), l("CrY/")),
                u = (l("7oEI"), l("dXOS")),
                s = function() {
                    function n(n, t, l) {
                        var s = this;
                        this.sanitizer = n, this.coreService = t, this.modalService = l, this.headerState = new e.a({
                            gameName: "",
                            eventName: "",
                            countdownEventBlockController: null,
                            iconUrl: null,
                            playList: null,
                            buttons: [],
                            hideViewerButton: !1
                        }), this.closedMarkets = new e.a(!1), this.activatedGame = new e.a(!1), this.cashTabSelected = new e.a(u.b.CASH_TICKET), this._currentConnState$ = new i.a, this.currentConnState = r.ConnectionStateEnum.CONNECTED, Object(o.a)(this.coreService.getSessionController().connection.connDiagnosis.onCurrentConnDiagnosisDatachange).subscribe((function(n) {
                            return n.requiresReload && window.location.reload(), s.currentConnState === r.ConnectionStateEnum.DISCONNECTED && n.connState === r.ConnectionStateEnum.CONNECTED ? (s.currentConnState = r.ConnectionStateEnum.CONNECTED, s._currentConnState$.next(r.ConnectionStateEnum.CONNECTED), void s.modalService.close("connections-problems")) : s.currentConnState === r.ConnectionStateEnum.CONNECTED && n.connState === r.ConnectionStateEnum.DISCONNECTED ? (s.currentConnState = r.ConnectionStateEnum.DISCONNECTED, void s._currentConnState$.next(r.ConnectionStateEnum.DISCONNECTED)) : void 0
                        }))
                    }
                    return n.prototype.setHeaderState = function(n) {
                        n.iconUrl && (n.iconUrl = this.sanitizer.bypassSecurityTrustStyle("url(" + n.iconUrl + ")")), this.headerState.next(Object.assign({}, {
                            gameName: "",
                            eventName: "",
                            countdownEventBlockController: null,
                            iconUrl: null,
                            playList: null,
                            buttons: [],
                            hideViewerButton: !1
                        }, n))
                    }, n.prototype.setCashTabSelected = function(n) {
                        this.cashTabSelected.next(n)
                    }, n.prototype.getCashTabSelected = function() {
                        return this.cashTabSelected
                    }, n.prototype.closeMarkets = function(n) {
                        void 0 === n && (n = !0), this.closedMarkets.next(n)
                    }, n.prototype.activateGame = function(n) {
                        void 0 === n && (n = !0), this.activatedGame.next(n)
                    }, Object.defineProperty(n.prototype, "currentConnState$", {
                        get: function() {
                            return this._currentConnState$.asObservable()
                        },
                        enumerable: !1,
                        configurable: !0
                    }), n
                }()
        },
        PdBy: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return e
            }));
            var e = function() {
                function n() {
                    this.isSelected = !1
                }
                return n.prototype.ngOnInit = function() {}, n.prototype.selected = function(n) {
                    this.isSelected = n
                }, n
            }()
        },
        QFAn: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return i
            }));
            var e = l("tfG9"),
                i = function() {
                    function n() {}
                    return n.forRoot = function() {
                        return {
                            ngModule: n,
                            providers: [e.a]
                        }
                    }, n.forChild = function() {
                        return {
                            ngModule: n,
                            providers: []
                        }
                    }, n
                }()
        },
        RoHP: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return i
            }));
            var e = l("CcnG"),
                i = function() {
                    function n(n, t) {
                        this.sanitizer = n, this.cd = t, this.hasContentWindow = function() {
                            return !0
                        }, this.close = new e.q, this.created = new e.q, this.hasSrc = !1
                    }
                    return Object.defineProperty(n.prototype, "iframe", {
                        get: function() {
                            return this._iframe
                        },
                        set: function(n) {
                            this._iframe = n, this.iframe && this.created.next(n.nativeElement)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), n.prototype.ngOnInit = function() {
                        this.loadSrc()
                    }, n.prototype.ngOnChanges = function(n) {
                        n.src && !n.src.isFirstChange() && this.updateContentWindow()
                    }, n.prototype.closeIframe = function() {
                        this.hasContentWindow() || (this.safeSrc = null, this.safeHtml = null), this.close.emit()
                    }, n.prototype.updateContentWindow = function() {
                        this.hasContentWindow() ? this.loadSrcEvent() : (this.loadSrc(), this.cd.detectChanges())
                    }, n.prototype.loadSrc = function() {
                        this.src ? (this.hasSrc = !0, this.safeSrc = this.sanitizer.bypassSecurityTrustResourceUrl(decodeURIComponent(this.src))) : this.htmlTemplate && (this.safeHtml = this.sanitizer.bypassSecurityTrustHtml(this.htmlTemplate))
                    }, n.prototype.loadSrcEvent = function() {
                        var n = {
                            type: "loadSrc",
                            data: {
                                src: this.src
                            }
                        };
                        this.iframe.nativeElement.contentWindow.postMessage(JSON.stringify(n), "*")
                    }, n
                }()
        },
        SLOH: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return r
            }));
            var e, i = l("NPGq"),
                o = (e = function(n, t) {
                    return (e = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(n, t) {
                            n.__proto__ = t
                        } || function(n, t) {
                            for (var l in t) Object.prototype.hasOwnProperty.call(t, l) && (n[l] = t[l])
                        })(n, t)
                }, function(n, t) {
                    function l() {
                        this.constructor = n
                    }
                    e(n, t), n.prototype = null === t ? Object.create(t) : (l.prototype = t.prototype, new l)
                }),
                r = function(n) {
                    function t() {
                        return null !== n && n.apply(this, arguments) || this
                    }
                    return o(t, n), t.prototype.ngOnInit = function() {}, t
                }(i.a)
        },
        UhMo: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return o
            }));
            var e = l("CcnG"),
                i = l("CrY/"),
                o = function() {
                    function n() {
                        this.isS2Wheels = !1, this.isRainbow = !1, this.isKinel8 = !1, this.hasX = !1, this.buttons = [], this.selectedChange = new e.q, this.rainbowMarkets = i.RainbowMarkets
                    }
                    return n.prototype.sliceLongMarketOdds = function(n) {
                        if (!n.rows) return n.odds;
                        for (var t = 0, l = n.rows, e = []; l <= n.odds.length;) e.push(n.odds.slice(t, l)), t = l, l += n.rows;
                        return e
                    }, n
                }()
        },
        V4K8: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return i
            }));
            var e = l("CcnG"),
                i = function() {
                    function n(n) {
                        this.cd = n, this.switchPrinter = new e.q
                    }
                    return n.prototype.ngOnInit = function() {
                        this.selectedPrinter = this.printers.filter((function(n) {
                            return n.info.isDefault
                        }))[0]
                    }, n.prototype.selectPrinter = function(n) {
                        this.switchPrinter.emit(n.info.printerId)
                    }, n
                }()
        },
        XAsR: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return r
            })), l.d(t, "b", (function() {
                return s
            }));
            var e = l("CcnG"),
                i = l("M3um"),
                o = [
                    [""]
                ],
                r = e.Gb({
                    encapsulation: 0,
                    styles: o,
                    data: {}
                });

            function u(n) {
                return e.ec(0, [e.Tb(null, 0), (n()(), e.xb(0, null, null, 0))], null, null)
            }

            function s(n) {
                return e.ec(2, [e.ac(402653184, 1, {
                    content: 0
                }), (n()(), e.xb(0, [
                    [1, 2]
                ], null, 0, null, u))], null, null)
            }
            e.Eb("grc-tab", i.a, (function(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "grc-tab", [], null, null, null, s, r)), e.Hb(1, 114688, null, 0, i.a, [], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                header: "header",
                id: "id"
            }, {}, ["*"])
        },
        Y53V: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return e
            }));
            var e = function() {
                function n(n) {
                    this.viewContainerRef = n
                }
                return n.prototype.ngOnInit = function() {
                    this.onInit()
                }, n.prototype.ngOnChanges = function(n) {
                    n.grcOptionHost && !n.grcOptionHost.isFirstChange() && this.onInit()
                }, n.prototype.onInit = function() {
                    this.viewContainerRef.clear(), this.viewContainerRef.createEmbeddedView(this.grcOptionHost)
                }, n
            }()
        },
        bahv: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return i
            }));
            var e = l("CcnG"),
                i = (l("7oEI"), function() {
                    function n(n, t) {
                        this.cd = n, this.modalService = t, this.switchPrinter = new e.q, this.height = 80, this.width = 300
                    }
                    return n.prototype.ngOnInit = function() {
                        this.getPrinterDefault()
                    }, n.prototype.closeInfo = function() {
                        this.modalService.close("base-information")
                    }, n.prototype.switchSelectPrinter = function(n) {
                        this.switchPrinter.emit(n), this.printers.forEach((function(t) {
                            return t.info.printerId === n ? t.info.isDefault = !0 : t.info.isDefault = !1
                        })), this.getPrinterDefault(), this.cd.detectChanges()
                    }, n.prototype.getPrinterDefault = function() {
                        this.printerDefault = this.printers.some((function(n) {
                            return n.info.isDefault
                        }))
                    }, n.prototype.applyPrinter = function() {
                        this.printerDefault && this.closeInfo()
                    }, n
                }())
        },
        bma8: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return i
            }));
            var e = l("CcnG"),
                i = (l("7oEI"), function() {
                    function n(n, t, l) {
                        this.cd = n, this.modalService = t, this.i18NService = l, this.success = new e.q, this.content = "", this.numbers = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"], this.letters = {
                            rowOne: ["q", "w", "e", "r", "t", "y", "u", "i", "o", "p"],
                            rowTwo: ["a", "s", "d", "f", "g", "h", "j", "k", "l"],
                            rowThree: ["z", "x", "c", "v", "b", "n", "m"]
                        }, this.error = "", this.rawContent = "", this.nextKey = ""
                    }
                    return n.prototype.ngOnInit = function() {}, n.prototype.insert = function(n) {
                        this.error = "", this.rawContent.length >= 16 ? this.error = "" + this.i18NService.get("ch_ticketid_maxlength_reached") : (this.rawContent += n, this.content = this.rawContent.toUpperCase(), this.cd.markForCheck())
                    }, n.prototype.closeKeypad = function() {
                        this.modalService.close("base-information")
                    }, n.prototype.clear = function() {
                        this.error = "", this.content = "", this.rawContent = "", this.cd.detectChanges()
                    }, n.prototype.ok = function() {
                        this.rawContent && "" !== this.rawContent ? this.success.next(this.rawContent) : this.error = "" + this.i18NService.get("ch_empty_ticket_id")
                    }, n.prototype.onKeyDown = function(n, t, l) {
                        var e = this;
                        this.error = "", (t >= 48 && t <= 57 || t >= 96 && t <= 105 || t >= 65 && t <= 90) && !l && (this.nextKey += n, this.clearIfIsBarcode(), this.clearIfHasTimeOut(), this.checkTimeout = setTimeout((function() {
                            e.insert(e.nextKey), e.nextKey = ""
                        }), 90))
                    }, n.prototype.onBackspace = function() {
                        this.content = this.content.slice(0, this.content.length - 1), this.rawContent = this.rawContent.slice(0, this.rawContent.length - 1)
                    }, n.prototype.onEnter = function() {
                        this.rawContent && "" !== this.rawContent ? this.success.emit(this.rawContent) : this.error = "" + this.i18NService.get("ch_empty_ticket_id")
                    }, n.prototype.onPaste = function(n) {
                        var t;
                        window.clipboardData ? t = window.clipboardData : n instanceof ClipboardEvent && n.clipboardData && (t = n.clipboardData), t && this.insert(t.getData("text/plain"))
                    }, n.prototype.clearIfIsBarcode = function() {
                        this.checkIsBarcode(this.nextKey) && (clearTimeout(this.checkTimeout), this.nextKey = this.nextKey.replace(/^0+/, ""))
                    }, n.prototype.clearIfHasTimeOut = function() {
                        this.checkTimeout && clearTimeout(this.checkTimeout)
                    }, n.prototype.checkIsBarcode = function(n) {
                        void 0 === n && (n = "");
                        return !!n.match(/(\d{9,20}\D{0,4})$/)
                    }, n
                }())
        },
        "cS+c": function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return b
            }));
            var e = l("CcnG"),
                i = l("5EE+"),
                o = l("0sFr"),
                r = l("V4K8"),
                u = l("Ip0R"),
                s = l("bahv"),
                c = l("7oEI"),
                a = [
                    [".info-no-printer[_ngcontent-%COMP%]{text-align:center;width:600px;height:450px;background-color:#fff}.info-no-printer__header__close[_ngcontent-%COMP%]{float:right;padding:10px;cursor:pointer}.info-no-printer__header__close[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{font-size:24px}.info-no-printer__icon[_ngcontent-%COMP%]{margin-top:40px;margin-left:10px;font-size:80px}.info-no-printer__text[_ngcontent-%COMP%]{margin-top:10px;margin-left:10px;font-size:40px}.info-no-printer__select[_ngcontent-%COMP%]{margin-top:30px;margin-left:10px}.info-no-printer__buttons[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{max-width:200px;height:80px;padding:20px;margin:50px;font-size:32px;font-weight:700;text-transform:uppercase}.info-no-printer__buttons__later[_ngcontent-%COMP%]{color:#000;background-color:#fff;border:2px solid #000;cursor:pointer}.info-no-printer__buttons__apply[_ngcontent-%COMP%]{color:#fff}.info-no-printer__buttons__apply--enabled[_ngcontent-%COMP%]{cursor:pointer;background-color:#618b31}.info-no-printer__buttons__apply--disabled[_ngcontent-%COMP%]{cursor:default;background-color:rgba(97,139,49,.3)}"]
                ],
                d = e.Gb({
                    encapsulation: 0,
                    styles: a,
                    data: {}
                });

            function p(n) {
                return e.ec(2, [(n()(), e.Ib(0, 0, null, null, 23, "div", [
                    ["class", "info-no-printer"]
                ], null, null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 1, "div", [
                    ["class", "info-no-printer__header"]
                ], null, null, null, null, null)), (n()(), e.Ib(2, 0, null, null, 0, "span", [
                    ["class", "info-no-printer__header__close icon icon-cancel"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.closeInfo() && e);
                    return e
                }), null, null)), (n()(), e.Ib(3, 0, null, null, 9, "div", [
                    ["class", "grid grid-12"]
                ], null, null, null, null, null)), (n()(), e.Ib(4, 0, null, null, 1, "div", [
                    ["class", "info-no-printer__icon col col-12"]
                ], null, null, null, null, null)), (n()(), e.Ib(5, 0, null, null, 0, "span", [
                    ["class", "icon icon-printer"]
                ], null, null, null, null, null)), (n()(), e.Ib(6, 0, null, null, 3, "div", [
                    ["class", "info-no-printer__text col col-12"]
                ], null, null, null, null, null)), (n()(), e.Ib(7, 0, null, null, 2, "span", [], null, null, null, null, null)), (n()(), e.cc(8, null, ["", ""])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(10, 0, null, null, 2, "div", [
                    ["class", "info-no-printer__select col col-12"]
                ], null, null, null, null, null)), (n()(), e.Ib(11, 0, null, null, 1, "grc-select-printer", [], null, [
                    [null, "switchPrinter"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "switchPrinter" === t && (e = !1 !== i.switchSelectPrinter(l) && e);
                    return e
                }), o.b, o.a)), e.Hb(12, 114688, null, 0, r.a, [e.i], {
                    printers: [0, "printers"],
                    width: [1, "width"],
                    height: [2, "height"]
                }, {
                    switchPrinter: "switchPrinter"
                }), (n()(), e.Ib(13, 0, null, null, 10, "div", [
                    ["class", "grid grid-12 info-no-printer__buttons"]
                ], null, null, null, null, null)), (n()(), e.Ib(14, 0, null, null, 3, "div", [
                    ["class", "info-no-printer__buttons__later col col-6"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.closeInfo() && e);
                    return e
                }), null, null)), (n()(), e.Ib(15, 0, null, null, 2, "span", [], null, null, null, null, null)), (n()(), e.cc(16, null, ["", ""])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(18, 0, null, null, 5, "div", [
                    ["class", "col col-6 info-no-printer__buttons__apply"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.applyPrinter() && e);
                    return e
                }), null, null)), e.Zb(512, null, u.x, u.y, [e.A, e.B, e.o, e.P]), e.Hb(20, 278528, null, 0, u.k, [u.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), (n()(), e.Ib(21, 0, null, null, 2, "span", [], null, null, null, null, null)), (n()(), e.cc(22, null, ["", ""])), e.Wb(131072, i.j, [i.k, e.i])], (function(n, t) {
                    var l = t.component;
                    n(t, 12, 0, l.printers, l.width, l.height);
                    n(t, 20, 0, "col col-6 info-no-printer__buttons__apply", l.printerDefault ? "info-no-printer__buttons__apply--enabled" : "info-no-printer__buttons__apply--disabled")
                }), (function(n, t) {
                    n(t, 8, 0, e.dc(t, 8, 0, e.Ub(t, 9).transform("ch_no_printer_selected"))), n(t, 16, 0, e.dc(t, 16, 0, e.Ub(t, 17).transform("ch_later"))), n(t, 22, 0, e.dc(t, 22, 0, e.Ub(t, 23).transform("ch_apply")))
                }))
            }
            var b = e.Eb("grc-info-no-printer", s.a, (function(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "grc-info-no-printer", [], null, null, null, p, d)), e.Hb(1, 114688, null, 0, s.a, [e.i, c.a], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                title: "title",
                printers: "printers"
            }, {
                switchPrinter: "switchPrinter"
            }, [])
        },
        crnd: function(n, t) {
            function l(n) {
                return Promise.resolve().then((function() {
                    var t = new Error("Cannot find module '" + n + "'");
                    throw t.code = "MODULE_NOT_FOUND", t
                }))
            }
            l.keys = function() {
                return []
            }, l.resolve = l, n.exports = l, l.id = "crnd"
        },
        dXOS: function(n, t, l) {
            "use strict";
            l.d(t, "b", (function() {
                return e
            })), l.d(t, "a", (function() {
                return o
            }));
            l("NTJ2");
            var e, i = l("CcnG");
            ! function(n) {
                n.CASH_TICKET = "cash-ticket", n.LOCAL_USER = "local-user", n.MANUAL_CASH = "manual-cash"
            }(e || (e = {}));
            var o = function() {
                function n(n, t) {
                    this.baseService = n, this.injector = t, this.cashManagementTabSelected = e.CASH_TICKET, this.cd = this.injector.get(i.i)
                }
                return n.prototype.ngOnInit = function() {
                    this.configureHeader(), this.baseService.activateGame(!0), this.baseService.setCashTabSelected(this.cashManagementTabSelected)
                }, n.prototype.configureHeader = function() {
                    this.baseService.setHeaderState({
                        gameName: "ch_cash_management",
                        eventName: null,
                        countdownEventBlockController: null,
                        iconUrl: "icon icon-dollar-filled",
                        playList: null,
                        buttons: [],
                        hideViewerButton: !0
                    })
                }, n.prototype.getCardId = function(n) {
                    return this.cashManagementTabSelected === e.CASH_TICKET ? n - 1 : n
                }, n.prototype.onTabCashManagementChange = function(n) {
                    this.cashManagementTabSelected = e[this.getKeyByValue(e, n)], this.baseService.setCashTabSelected(this.cashManagementTabSelected)
                }, n.prototype.getKeyByValue = function(n, t) {
                    return Object.keys(n).find((function(l) {
                        return n[l] === t
                    }))
                }, n
            }()
        },
        eZM8: function(n, t, l) {
            "use strict";
            l.d(t, "b", (function() {
                return a
            })), l.d(t, "c", (function() {
                return b
            })), l.d(t, "a", (function() {
                return h
            }));
            var e = l("CcnG"),
                i = l("gIcY"),
                o = l("5EE+"),
                r = l("Ip0R"),
                u = l("qGUr"),
                s = l("sylN"),
                c = [
                    ["input[_ngcontent-%COMP%]{font-size:26px;font-weight:500;background:#f6f6f6;border-radius:2px;border:1px solid #999;margin-bottom:10px;padding-left:8px;width:70%}h3[_ngcontent-%COMP%]{font-size:38px;font-weight:500;margin-bottom:20px}.dialog__buttons[_ngcontent-%COMP%]{margin-top:40px}.dialog__buttons[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{font-size:32px;font-weight:700;text-align:center;text-transform:uppercase;padding:8px 32px;cursor:pointer}.dialog__buttons[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:disabled, .dialog__buttons[_ngcontent-%COMP%]   button[disabled][_ngcontent-%COMP%]{background:#8a8a8a;color:#c5c5c5}.dialog__buttons[_ngcontent-%COMP%]   .left-button[_ngcontent-%COMP%]{float:left;background:#fff;border-radius:0;border:2px solid #000}.dialog__buttons[_ngcontent-%COMP%]   .right-button[_ngcontent-%COMP%]{float:right;color:#fff;border:none}.dialog__buttons[_ngcontent-%COMP%]   .center-button[_ngcontent-%COMP%]{color:#fff;border:none}"]
                ],
                a = e.Gb({
                    encapsulation: 0,
                    styles: c,
                    data: {}
                });

            function d(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 11, "div", [], [
                    [1, "data-index", 0]
                ], null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 10, "div", [], null, null, null, null, null)), (n()(), e.Ib(2, 0, null, null, 9, "input", [
                    ["autofocus", ""],
                    ["maxlength", "120"],
                    ["required", ""],
                    ["type", "text"]
                ], [
                    [8, "id", 0],
                    [8, "placeholder", 0],
                    [1, "required", 0],
                    [1, "maxlength", 0],
                    [2, "ng-untouched", null],
                    [2, "ng-touched", null],
                    [2, "ng-pristine", null],
                    [2, "ng-dirty", null],
                    [2, "ng-valid", null],
                    [2, "ng-invalid", null],
                    [2, "ng-pending", null]
                ], [
                    [null, "ngModelChange"],
                    [null, "input"],
                    [null, "blur"],
                    [null, "compositionstart"],
                    [null, "compositionend"]
                ], (function(n, t, l) {
                    var i = !0,
                        o = n.component;
                    "input" === t && (i = !1 !== e.Ub(n, 3)._handleInput(l.target.value) && i);
                    "blur" === t && (i = !1 !== e.Ub(n, 3).onTouched() && i);
                    "compositionstart" === t && (i = !1 !== e.Ub(n, 3)._compositionStart() && i);
                    "compositionend" === t && (i = !1 !== e.Ub(n, 3)._compositionEnd(l.target.value) && i);
                    "ngModelChange" === t && (i = !1 !== o.setDisableButton(e.Ub(n.parent, 5)) && i);
                    return i
                }), null, null)), e.Hb(3, 16384, null, 0, i.d, [e.P, e.o, [2, i.a]], null, null), e.Hb(4, 16384, null, 0, i.o, [], {
                    required: [0, "required"]
                }, null), e.Hb(5, 540672, null, 0, i.f, [], {
                    maxlength: [0, "maxlength"]
                }, null), e.Zb(1024, null, i.g, (function(n, t) {
                    return [n, t]
                }), [i.o, i.f]), e.Zb(1024, null, i.h, (function(n) {
                    return [n]
                }), [i.d]), e.Hb(8, 671744, [
                    ["[param.id]", 4]
                ], 0, i.m, [
                    [2, i.c],
                    [6, i.g],
                    [8, null],
                    [6, i.h]
                ], {
                    name: [0, "name"],
                    model: [1, "model"]
                }, {
                    update: "ngModelChange"
                }), e.Zb(2048, null, i.i, null, [i.m]), e.Hb(10, 16384, null, 0, i.j, [
                    [4, i.i]
                ], null, null), e.Wb(131072, o.j, [o.k, e.i])], (function(n, t) {
                    var l = t.component;
                    n(t, 4, 0, "");
                    n(t, 5, 0, "120"), n(t, 8, 0, e.Mb(1, "", t.context.$implicit.id, ""), l.scannedData ? l.scannedData[t.context.index] : "")
                }), (function(n, t) {
                    n(t, 0, 0, t.context.index), n(t, 2, 1, [e.Mb(1, "", t.context.$implicit.id, ""), e.Mb(1, "", e.dc(t, 2, 1, e.Ub(t, 11).transform(t.context.$implicit.title)), ""), e.Ub(t, 4).required ? "" : null, e.Ub(t, 5).maxlength ? e.Ub(t, 5).maxlength : null, e.Ub(t, 10).ngClassUntouched, e.Ub(t, 10).ngClassTouched, e.Ub(t, 10).ngClassPristine, e.Ub(t, 10).ngClassDirty, e.Ub(t, 10).ngClassValid, e.Ub(t, 10).ngClassInvalid, e.Ub(t, 10).ngClassPending])
                }))
            }

            function p(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 2, "button", [
                    ["class", "left-button"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.onClick() && e);
                    return e
                }), null, null)), (n()(), e.cc(1, null, ["", ""])), e.Wb(131072, o.j, [o.k, e.i])], null, (function(n, t) {
                    n(t, 1, 0, e.dc(t, 1, 0, e.Ub(t, 2).transform("ch_Back")))
                }))
            }

            function b(n) {
                return e.ec(2, [(n()(), e.Ib(0, 0, null, null, 2, "h3", [], null, null, null, null, null)), (n()(), e.cc(1, null, ["", ""])), e.Wb(131072, o.j, [o.k, e.i]), (n()(), e.Ib(3, 0, null, null, 15, "form", [
                    ["novalidate", ""]
                ], [
                    [2, "ng-untouched", null],
                    [2, "ng-touched", null],
                    [2, "ng-pristine", null],
                    [2, "ng-dirty", null],
                    [2, "ng-valid", null],
                    [2, "ng-invalid", null],
                    [2, "ng-pending", null]
                ], [
                    [null, "ngSubmit"],
                    [null, "submit"],
                    [null, "reset"]
                ], (function(n, t, l) {
                    var i = !0,
                        o = n.component;
                    "submit" === t && (i = !1 !== e.Ub(n, 5).onSubmit(l) && i);
                    "reset" === t && (i = !1 !== e.Ub(n, 5).onReset() && i);
                    "ngSubmit" === t && (i = !1 !== o.submit(e.Ub(n, 5)) && i);
                    return i
                }), null, null)), e.Hb(4, 16384, null, 0, i.t, [], null, null), e.Hb(5, 4210688, [
                    ["regForm", 4]
                ], 0, i.l, [
                    [8, null],
                    [8, null]
                ], null, {
                    ngSubmit: "ngSubmit"
                }), e.Zb(2048, null, i.c, null, [i.l]), e.Hb(7, 16384, null, 0, i.k, [
                    [4, i.c]
                ], null, null), (n()(), e.xb(16777216, null, null, 1, null, d)), e.Hb(9, 278528, null, 0, r.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), (n()(), e.Ib(10, 0, null, null, 8, "div", [
                    ["class", "dialog__buttons"]
                ], null, null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, p)), e.Hb(12, 16384, null, 0, r.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.Ib(13, 0, null, null, 5, "button", [
                    ["type", "submit"]
                ], [
                    [8, "disabled", 0]
                ], null, null, null, null)), e.Zb(512, null, r.x, r.y, [e.A, e.B, e.o, e.P]), e.Hb(15, 278528, null, 0, r.k, [r.x], {
                    ngClass: [0, "ngClass"]
                }, null), e.Xb(16, {
                    "right-button": 0,
                    "center-button": 1
                }), (n()(), e.cc(17, null, [" ", " "])), e.Wb(131072, o.j, [o.k, e.i])], (function(n, t) {
                    var l = t.component;
                    n(t, 9, 0, l.formParams), n(t, 12, 0, l.hasQRPermissions);
                    var e = n(t, 16, 0, !0 === l.hasQRPermissions, !0 !== l.hasQRPermissions);
                    n(t, 15, 0, e)
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 1, 0, e.dc(t, 1, 0, e.Ub(t, 2).transform("qr_modal_player_info"))), n(t, 3, 0, e.Ub(t, 7).ngClassUntouched, e.Ub(t, 7).ngClassTouched, e.Ub(t, 7).ngClassPristine, e.Ub(t, 7).ngClassDirty, e.Ub(t, 7).ngClassValid, e.Ub(t, 7).ngClassInvalid, e.Ub(t, 7).ngClassPending), n(t, 13, 0, l.disableButton), n(t, 17, 0, e.dc(t, 17, 0, e.Ub(t, 18).transform("ch_save")))
                }))
            }
            var h = e.Eb("grc-modal-data-dialog-form", u.a, (function(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "grc-modal-data-dialog-form", [], null, null, null, b, a)), e.Hb(1, 114688, null, 0, u.a, [s.a], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                hasQRPermissions: "hasQRPermissions",
                scannedData: "scannedData",
                formParams: "formParams",
                configuration: "configuration"
            }, {
                qrEvent: "qrEvent"
            }, [])
        },
        ee4M: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return i
            }));
            var e = l("CrY/");

            function i(n) {
                var t = e.coreModel.GameType.ValEnum;
                switch (n.gameType.val) {
                    case t.CH:
                        return n.filter.isChFilter() && n.filter.competitionType.toLowerCase();
                    case t.HORSE:
                    case t.TROTTING:
                    case t.DOG:
                    case t.SPEEDWAY:
                    case t.MOTORBIKE:
                    case t.DIRTTRACK:
                    case t.KART:
                        return "races";
                    case t.SN:
                        return "spin2win";
                    case t.LL:
                        return "mega6";
                    case t.SX:
                        return "perfect6";
                    case t.RAINBOW:
                        return "rainbow";
                    case t.KN:
                        return "keno";
                    case t.S2W:
                        return "spin2wheels";
                    case t.MMA:
                        return (n.filter.isMmaFilter() && n.filter.competitionType) === e.coreModel.MmaFilter.CompetitionTypeEnum.SINGLE ? "mma" : "mma-tournament";
                    default:
                        return "another"
                }
            }
        },
        fHz3: function(n, t, l) {
            "use strict";
            l.d(t, "b", (function() {
                return a
            })), l.d(t, "c", (function() {
                return d
            })), l.d(t, "a", (function() {
                return p
            }));
            var e = l("CcnG"),
                i = l("6kbv"),
                o = l("M3iF"),
                r = l("5EE+"),
                u = l("38rj"),
                s = l("tfG9"),
                c = [
                    [".dialog__buttons[_ngcontent-%COMP%]{margin-top:40px}.dialog__buttons[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{font-size:32px;font-weight:700;text-align:center;text-transform:uppercase;padding:8px 32px;cursor:pointer}.dialog__buttons[_ngcontent-%COMP%]   .left-button[_ngcontent-%COMP%]{float:left;background:#fff;border-radius:0;border:2px solid #000}.dialog__buttons[_ngcontent-%COMP%]   .right-button[_ngcontent-%COMP%]{float:right;color:#fff;border:none}"]
                ],
                a = e.Gb({
                    encapsulation: 0,
                    styles: c,
                    data: {}
                });

            function d(n) {
                return e.ec(2, [e.ac(671088640, 1, {
                    input: 0
                }), (n()(), e.Ib(1, 0, null, null, 2, "ngx-scanner-qrcode", [
                    ["class", "ngx-scanner-qrcode"]
                ], null, [
                    [null, "event"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "event" === t && (e = !1 !== i.getContent(l) && e);
                    return e
                }), i.b, i.a)), e.Hb(2, 245760, [
                    [1, 4],
                    ["action", 4]
                ], 0, o.a, [], {
                    isAuto: [0, "isAuto"],
                    constraints: [1, "constraints"]
                }, {
                    event: "event"
                }), e.Xb(3, {
                    audio: 0,
                    video: 1
                }), (n()(), e.Ib(4, 0, null, null, 6, "div", [
                    ["class", "dialog__buttons"]
                ], null, null, null, null, null)), (n()(), e.Ib(5, 0, null, null, 2, "button", [
                    ["class", "left-button"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.onClick() && e);
                    return e
                }), null, null)), (n()(), e.cc(6, null, ["", ""])), e.Wb(131072, r.j, [r.k, e.i]), (n()(), e.Ib(8, 0, null, null, 2, "button", [
                    ["class", "right-button"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.scan() && e);
                    return e
                }), null, null)), (n()(), e.cc(9, null, ["", ""])), e.Wb(131072, r.j, [r.k, e.i])], (function(n, t) {
                    var l = n(t, 3, 0, !1, !0);
                    n(t, 2, 0, !0, l)
                }), (function(n, t) {
                    n(t, 6, 0, e.dc(t, 6, 0, e.Ub(t, 7).transform("qr_modal_introduce_player_info"))), n(t, 9, 0, e.dc(t, 9, 0, e.Ub(t, 10).transform("qr_modal_scan_qr")))
                }))
            }
            var p = e.Eb("grc-modal-data-dialog-qr-scanner", u.a, (function(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "grc-modal-data-dialog-qr-scanner", [], null, null, null, d, a)), e.Hb(1, 114688, null, 0, u.a, [s.a, e.P], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {}, {
                formEvent: "formEvent"
            }, [])
        },
        fWpR: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return e
            }));
            l("ojct");
            var e = function() {
                function n(n) {
                    this.modalStoreService = n
                }
                return n.prototype.onClick = function() {
                    this.modalStoreService.close(this.grcModalClose)
                }, n
            }()
        },
        ghVy: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return i
            }));
            var e = l("CcnG"),
                i = function() {
                    function n(n) {
                        this.cd = n, this.buttons = [], this.selectedChange = new e.q, this.selected = 0
                    }
                    return n.prototype.ngOnInit = function() {
                        this.setButtonId()
                    }, n.prototype.ngAfterViewInit = function() {
                        this.selected || (this.select(0), this.cd.detectChanges())
                    }, n.prototype.setButtonId = function() {
                        this.buttons.forEach((function(n, t) {
                            n.id = t
                        }))
                    }, n.prototype.select = function(n) {
                        var t = this.buttons[n];
                        t && this.selected !== n && (this.selected = t.id, this.selectedChange.emit(this.selected))
                    }, n
                }()
        },
        hIlf: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return u
            }));
            var e = l("67Y/"),
                i = l("9Z1F"),
                o = l("F/XL"),
                r = l("AytR"),
                u = function() {
                    function n(n, t) {
                        this.http = n, this.themeUrl = t
                    }
                    return n.prototype.load = function(n) {
                        var t = this,
                            l = this.parseThemeUrl(n);
                        return l === this.themeLoaded ? Object(o.a)(null) : this.http.get(l, {
                            responseType: "text"
                        }).pipe(Object(e.a)((function(n) {
                            t.themeLoaded = l;
                            var e = document.createElement("style");
                            e.id = "theme", e.textContent = n, document.head.appendChild(e)
                        })), Object(i.a)((function(n) {
                            return t.load({
                                name: "default"
                            })
                        })))
                    }, n.prototype.parseThemeUrl = function(n) {
                        var t = this.themeUrl;
                        if (!r.a.production)
                            for (var l = 0, e = Object.keys(n); l < e.length; l++) {
                                var i = e[l],
                                    o = new RegExp("theme" + i.charAt(0).toUpperCase() + i.slice(1) + "=([^.]+)(&|$)"),
                                    u = window.location.href.match(o);
                                n[i] = u ? u[1] : n[i]
                            }
                        for (var s = 0, c = Object.keys(n); s < c.length; s++) {
                            i = c[s], o = new RegExp("{{[s]*" + i + "[s]*}}", "g");
                            t = t.replace(o, n[i])
                        }
                        return t
                    }, n
                }()
        },
        hZz1: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return r
            }));
            var e = l("CcnG"),
                i = (l("n3kJ"), l("pugT")),
                o = l("0/uQ"),
                r = function() {
                    function n(n) {
                        this.cd = n, this.switchUnitPrinter = new e.q, this.myExpanded = !1, this.subscription = new i.a
                    }
                    return n.prototype.ngOnInit = function() {
                        this.unitPrinter ? this.hwId = this.unitPrinter.getLanUnitInfo().hardwareId : this.hardwareId ? this.hwId = this.hardwareId : this.hwId = "-"
                    }, n.prototype.changeMyExpanded = function() {
                        this.myExpanded = !this.myExpanded, this.cd.detectChanges()
                    }, n.prototype.display = function() {
                        var n = this;
                        if (this.unitPrinter) {
                            var t = Object(o.a)(this.unitPrinter.loadLanUnitUrls());
                            this.subscription.add(t.subscribe({
                                next: function() {
                                    return n.unitPrinter.openLobbyUrl()
                                }
                            }))
                        } else window.open("http://" + this.localHostInfo.systemInfo.localIp)
                    }, n.prototype.ngOnDestroy = function() {
                        this.subscription.unsubscribe()
                    }, n
                }()
        },
        hg3l: function(n, t, l) {
            "use strict";
            var e = l("hIlf");
            l.d(t, "a", (function() {
                return e.a
            }))
        },
        hkR0: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return o
            }));
            var e = l("CrY/"),
                i = l("7Dvu"),
                o = function() {
                    function n() {
                        this.gameType = "", this.gameTypeName = ""
                    }
                    return n.prototype.ngOnInit = function() {
                        this.gameType = this.getGameType(), this.gameTypeName = this.getGameTypeName()
                    }, n.prototype.getGameType = function() {
                        return this.playlist.gameType.val === e.coreModel.GameType.ValEnum.KN && this.playlist && this.playlist.assets && "kinel8" === this.playlist.assets.iconId ? "k8" : Object(i.a)(this.playlist) ? "color-color" : this.playlist.gameType.val.toLocaleLowerCase()
                    }, n.prototype.getGameTypeName = function() {
                        var n = "";
                        switch (this.playlist.gameType.val) {
                            case e.coreModel.GameType.ValEnum.SN:
                                n = "Spin 2 Win", this.playlist.filter && this.playlist.filter.isSnFilter() && "deluxe" === this.playlist.filter.mode.toLocaleLowerCase() && (n = "Spin 2 Win Royale");
                                break;
                            case e.coreModel.GameType.ValEnum.LL:
                                n = "Mega 6";
                                break;
                            case e.coreModel.GameType.ValEnum.SX:
                                n = "Perfect 6";
                                break;
                            case e.coreModel.GameType.ValEnum.RAINBOW:
                                n = Object(i.a)(this.playlist) ? "Colour Colour" : "Rainbow Colors";
                                break;
                            case e.coreModel.GameType.ValEnum.KN:
                                n = "Keno", this.playlist.filter && this.playlist.filter.isKnFilter() && ("deluxe" === this.playlist.filter.mode.toLocaleLowerCase() ? n = "Keno Deluxe" : this.playlist && this.playlist.assets && "kinel8" === this.playlist.assets.iconId && (n = "Kinel8"));
                                break;
                            case e.coreModel.GameType.ValEnum.S2W:
                                n = "Spin 2 Wheels"
                        }
                        return n
                    }, n
                }()
        },
        iFca: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return e
            }));
            var e = new(l("CcnG").x)("NOTIFICATION_CONFIGURATION_TOKEN")
        },
        iGSx: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return h
            }));
            var e = l("KhfW"),
                i = l("CcnG"),
                o = l("Ip0R"),
                r = l("fWpR"),
                u = l("ojct"),
                s = l("B5my"),
                c = [e.a],
                a = i.Gb({
                    encapsulation: 0,
                    styles: c,
                    data: {}
                });

            function d(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 0, "div", [], [
                    [8, "className", 0],
                    [4, "color", null]
                ], null, null, null, null))], null, (function(n, t) {
                    var l = t.component;
                    n(t, 0, 0, i.Mb(1, "", l.configuration.icon, " dialog__icon"), l.configuration.iconColor)
                }))
            }

            function p(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 5, "div", [
                    ["class", "col dialog-button"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        o = n.component;
                    "click" === t && (e = !1 !== i.Ub(n, 4).onClick() && e);
                    "click" === t && (e = !1 !== o.callAction(n.context.$implicit.action) && e);
                    return e
                }), null, null)), i.Zb(512, null, o.x, o.y, [i.A, i.B, i.o, i.P]), i.Hb(2, 278528, null, 0, o.k, [o.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), i.Xb(3, {
                    "dialog-button--danger": 0,
                    "dialog-button--success": 1,
                    "dialog-button--bordered": 2
                }), i.Hb(4, 16384, null, 0, r.a, [u.a], {
                    grcModalClose: [0, "grcModalClose"]
                }, null), (n()(), i.cc(5, null, [" ", " "]))], (function(n, t) {
                    var l = t.component,
                        e = n(t, 3, 0, "danger" === t.context.$implicit.type, "success" === t.context.$implicit.type, "bordered" === t.context.$implicit.type);
                    n(t, 2, 0, "col dialog-button", e), n(t, 4, 0, l.modalId)
                }), (function(n, t) {
                    n(t, 5, 0, t.context.$implicit.text)
                }))
            }

            function b(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 8, "div", [
                    ["class", "dialog"]
                ], [
                    [2, "dialog--danger", null]
                ], null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 4, "div", [
                    ["class", "dialog__content"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, d)), i.Hb(3, 16384, null, 0, o.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.Ib(4, 0, null, null, 1, "div", [
                    ["class", "dialog__text"]
                ], null, null, null, null, null)), (n()(), i.cc(5, null, ["", ""])), (n()(), i.Ib(6, 0, null, null, 2, "div", [
                    ["class", "dialog__buttons"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, p)), i.Hb(8, 278528, null, 0, o.l, [i.eb, i.Z, i.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(n, t) {
                    var l = t.component;
                    n(t, 3, 0, l.configuration.icon), n(t, 8, 0, l.configuration.buttons)
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 0, 0, "danger" === l.configuration.type), n(t, 5, 0, l.configuration.text)
                }))
            }
            var h = i.Eb("grc-modal-dialog", s.a, (function(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-modal-dialog", [], null, null, null, b, a)), i.Hb(1, 114688, null, 0, s.a, [], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                configuration: "configuration",
                modalId: "modalId"
            }, {}, [])
        },
        ijKR: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return p
            }));
            var e = l("bne5"),
                i = l("xMyE"),
                o = l("VnD/"),
                r = l("t9fZ"),
                u = l("RoHP"),
                s = l("7oEI"),
                c = l("t01L"),
                a = l("CcnG"),
                d = l("5EE+"),
                p = function() {
                    function n(n, t, l) {
                        var o = this;
                        this.modalService = n, this.coreService = t, this.i18NService = l, this.isModalOpen = !1, this.isShopAdminLoaded = !1, this.shopadminModal = "shopadmin", this.shopadminIframeOutputs = {
                            close: function() {
                                o.modalService.close(o.shopadminModal)
                            },
                            created: function(n) {
                                var t = o.coreService.getSessionController().getReceptionProxy();
                                t && (t.setConfig({
                                    targetOrigin: n.src,
                                    targetWindow: n.contentWindow
                                }), t.restart()), o.eventSubscription = Object(e.a)(window, "message").pipe(Object(i.a)((function(n) {
                                    try {
                                        var t, l = JSON.parse(n.data);
                                        if ("function" == typeof Event) t = new KeyboardEvent(l.type, l);
                                        else {
                                            t = document.createEvent("KeyboardEvent");
                                            var e = [];
                                            l.ctrlKey && e.push("Control"), l.shiftKey && e.push("Shift"), l.altKey && e.push("Alt"), t.initKeyboardEvent(l.type, !0, !0, window, l.key, l.code, 0, e.join(" "), l.repeat)
                                        }
                                        o.coreService.getShortcutController().getConfig().domElement.dispatchEvent(t)
                                    } catch (n) {}
                                }))).subscribe(), o.createProxyMessages(n)
                            }
                        }, this.subscribeOnShopAdminInit()
                    }
                    return n.prototype.openResultHistory = function(n) {
                        var t = this,
                            l = this.getResultRoutingShopadmin(n);
                        l.startsWith("null") ? this.showShopAdminPathError() : this.modalService.open(this.shopadminModal, u.a, {
                            inputs: {
                                src: l,
                                hasContentWindow: function() {
                                    return t.isShopAdminLoaded
                                }
                            },
                            outputs: this.shopadminIframeOutputs
                        }).afterClosed.subscribe({
                            complete: function() {
                                t.isShopAdminLoaded || t.removeProxyMessages(), t.eventSubscription && t.eventSubscription.unsubscribe()
                            }
                        })
                    }, n.prototype.openShopAdmin = function() {
                        var n = this,
                            t = this.getMainRoutingShopadmin();
                        t ? this.modalService.open(this.shopadminModal, u.a, {
                            inputs: {
                                src: t,
                                id: "shopadmin",
                                name: "shopadmin",
                                hasContentWindow: function() {
                                    return n.isShopAdminLoaded
                                }
                            },
                            outputs: this.shopadminIframeOutputs
                        }).afterClosed.subscribe({
                            complete: function() {
                                n.isShopAdminLoaded || n.removeProxyMessages(), n.eventSubscription && n.eventSubscription.unsubscribe()
                            }
                        }) : this.showShopAdminPathError()
                    }, n.prototype.showShopAdminPathError = function() {
                        var n = this;
                        this.modalService.openDialog("base2", {
                            type: "danger",
                            icon: "icon icon-warning",
                            iconColor: "#d43548",
                            text: "" + this.i18NService.get("ch_shopadminpath_not_set"),
                            buttons: [{
                                type: "danger",
                                text: "" + this.i18NService.get("ch_dismiss"),
                                action: function() {
                                    n.modalService.close("base2")
                                }
                            }]
                        })
                    }, n.prototype.subscribeOnShopAdminInit = function() {
                        var n = this;
                        Object(e.a)(window, "message").pipe(Object(o.a)((function(n) {
                            return n.data && "INIT_SHOPADMIN" === n.data.type
                        })), Object(i.a)((function(t) {
                            return n.isShopAdminLoaded = !0
                        })), Object(r.a)(1)).subscribe()
                    }, n.prototype.getMainRoutingShopadmin = function() {
                        return this.coreService.getShopAdminController().getMainRoutingShopadmin()
                    }, n.prototype.getResultRoutingShopadmin = function(n) {
                        return this.coreService.getShopAdminController().getResultRoutingShopadmin(n)
                    }, n.prototype.createProxyMessages = function(n) {
                        this.coreService.getIframeProxyMessage().load(n)
                    }, n.prototype.removeProxyMessages = function() {
                        this.coreService.getIframeProxyMessage().dispose()
                    }, n.ngInjectableDef = a.ic({
                        factory: function() {
                            return new n(a.jc(s.a), a.jc(c.a), a.jc(d.k))
                        },
                        token: n,
                        providedIn: "root"
                    }), n
                }()
        },
        imdu: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return i
            }));
            var e = l("CcnG"),
                i = function() {
                    function n() {
                        this.isActive = !1, this.changed = new e.q
                    }
                    return n.prototype.ngOnInit = function() {}, n
                }()
        },
        "iz+u": function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return o
            }));
            var e = l("7oEI"),
                i = l("ojct"),
                o = function() {
                    function n() {}
                    return n.forRoot = function() {
                        return {
                            ngModule: n,
                            providers: [i.a, e.a]
                        }
                    }, n.forChild = function() {
                        return {
                            ngModule: n,
                            providers: [e.a]
                        }
                    }, n
                }()
        },
        jMZ0: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return e
            })), l.d(t, "b", (function() {
                return o
            }));
            var e, i = l("CcnG");
            l("7oEI");
            ! function(n) {
                n.Number = "Number", n.Text = "Text", n.Password = "Password"
            }(e || (e = {}));
            var o = function() {
                function n(n, t, l) {
                    this.cd = n, this.modalService = t, this.iI18NService = l, this.placeholder = " ", this.type = e.Number, this.error = "", this.emptyError = "", this.success = new i.q, this.isPassword = !1, this.isNumber = !1, this.isText = !1, this.content = "", this.numbers = ["1", "2", "3", "4", "5", "6", "7", "8", "9"], this.logging = !1, this.decimalsLength = 0, this.rawContent = ""
                }
                return n.prototype.ngOnInit = function() {
                    this.maxLength = this.type === e.Password ? 10 : 20, this.isPassword = this.type === e.Password, this.isNumber = this.type === e.Number, this.isText = this.type === e.Text, this.decimalsLength = this.iI18NService.location.getDefaultCurrency() && this.iI18NService.location.getDefaultCurrency().decimals
                }, n.prototype.insert = function(n) {
                    var t = "" + this.rawContent + n;
                    this.error = "", t.length > this.maxLength || this.isNumber && this.hasMoreDecimalsThanAllowed(t) || !this.isPassword && 0 === this.decimalsLength && "0" === t || !this.isPassword && 0 !== this.decimalsLength && "00" === t || (this.rawContent += n, this.type === e.Password ? this.content = this.rawContent.split("") : this.content = this.rawContent)
                }, n.prototype.dot = function() {
                    !this.content.includes(".") && this.content.length >= 1 && 0 !== this.decimalsLength && !this.isPassword && this.insert(".")
                }, n.prototype.closeKeypad = function() {
                    this.modalService.close("base")
                }, n.prototype.clear = function() {
                    this.error = "", this.content = "", this.rawContent = "", this.cd.markForCheck()
                }, n.prototype.ok = function() {
                    "" !== this.rawContent || this.type === e.Number ? (this.success.next(this.rawContent), this.closeKeypad()) : this.error = this.emptyError
                }, n.prototype.onKeyDown = function(n, t) {
                    this.error = "", this.logging || (isNaN(Number(n)) || this.insert(n), 110 !== t && 188 !== t && 190 !== t || this.dot())
                }, n.prototype.onBackspace = function() {
                    this.content = this.content.slice(0, this.content.length - 1), this.rawContent = this.rawContent.slice(0, this.rawContent.length - 1)
                }, n.prototype.onEnter = function() {
                    this.logging || ("" !== this.rawContent || this.type === e.Number ? this.success.emit(this.rawContent) : this.error = this.emptyError)
                }, n.prototype.hasMoreDecimalsThanAllowed = function(n) {
                    return n.includes(".") && n.split(".")[1].length > this.decimalsLength
                }, n
            }()
        },
        k1pK: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return i
            }));
            var e = l("CcnG"),
                i = function() {
                    function n(n, t) {
                        this.cd = n, this.i18NService = t, this.onlyNumbers = !1, this.showHidePassword = !1, this.success = new e.q, this.content = "", this.numbers = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0", ""], this.letters = {
                            rowOne: ["q", "w", "e", "r", "t", "y", "u", "i", "o", "p"],
                            rowTwo: ["a", "s", "d", "f", "g", "h", "j", "k", "l"],
                            rowThree: ["z", "x", "c", "v", "b", "n", "m", "@", ".", "-"]
                        }, this.error = "", this.isPasswordVisible = !1, this.passwordVisibilityIcon = !0, this.isInputPassword = !1, this.rawContent = ""
                    }
                    return n.prototype.ngOnInit = function() {
                        this.data && (this.content = this.data, this.rawContent = this.content, this.passwordVisibilityIcon = !1), this.isInputPassword = "password" === this.placeholder || "pinHash" === this.placeholder
                    }, n.prototype.insert = function(n) {
                        this.error = "", this.rawContent.length >= 35 ? this.error = "" + this.i18NService.get("ch_" + this.placeholder + "_maxlength_reached") : "" !== n && (this.rawContent += n, this.content = this.rawContent.toLowerCase())
                    }, n.prototype.clear = function() {
                        this.error = "", this.content = "", this.rawContent = "", this.passwordVisibilityIcon = !0, this.cd.detectChanges()
                    }, n.prototype.togglePasswordVisibility = function() {
                        this.isPasswordVisible = !this.isPasswordVisible, this.cd.detectChanges()
                    }, n.prototype.done = function() {
                        this.rawContent && "" !== this.rawContent ? this.success.next(this.rawContent) : this.error = "" + this.i18NService.get("ch_empty_" + this.placeholder)
                    }, n.prototype.closeVirtualKeyBoard = function() {
                        this.success.next(this.rawContent)
                    }, n.prototype.onKeyDown = function(n, t, l) {
                        this.error = "", (t >= 48 && t <= 57 || t >= 96 && t <= 105 || t >= 65 && t <= 90 || 190 === t) && !l && this.insert(n)
                    }, n.prototype.onBackspace = function() {
                        this.content = this.content.slice(0, this.content.length - 1), this.rawContent = this.rawContent.slice(0, this.rawContent.length - 1), this.rawContent.length < 35 && (this.error = ""), 0 === this.rawContent.length && (this.passwordVisibilityIcon = !0)
                    }, n.prototype.onEnter = function() {
                        this.rawContent && "" !== this.rawContent ? this.success.emit(this.rawContent) : this.error = "" + this.i18NService.get("ch_empty_" + this.placeholder)
                    }, n.prototype.onEsc = function() {
                        this.success.emit(this.rawContent)
                    }, n.prototype.onPaste = function(n) {
                        var t;
                        window.clipboardData ? t = window.clipboardData : n instanceof ClipboardEvent && n.clipboardData && (t = n.clipboardData), t && this.insert(t.getData("text/plain"))
                    }, n
                }()
        },
        kMfV: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return e
            }));
            var e = function() {
                function n() {
                    this.clazz = !0
                }
                return n.prototype.ngOnInit = function() {}, n
            }()
        },
        "l+fh": function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return I
            }));
            var e = l("CcnG"),
                i = l("Ip0R"),
                o = l("5EE+"),
                r = l("fHz3"),
                u = l("38rj"),
                s = l("tfG9"),
                c = l("eZM8"),
                a = l("qGUr"),
                d = l("sylN"),
                p = l("y+mV"),
                b = l("5msJ"),
                h = l("t01L"),
                g = [
                    [".dialog[_ngcontent-%COMP%]{min-width:900px;max-width:400px;min-height:300px;padding:90px 60px;font-weight:700;font-family:DIN}.dialog__content[_ngcontent-%COMP%]{width:100%;padding-bottom:90px;text-align:center;overflow:auto}.dialog__buttons[_ngcontent-%COMP%]{display:flex}.dialog__buttons[_ngcontent-%COMP%] > .dialog-button[_ngcontent-%COMP%]{margin:0 10px}.dialog__buttons[_ngcontent-%COMP%] > .dialog-button[_ngcontent-%COMP%]:first-child{margin-left:0}.dialog__buttons[_ngcontent-%COMP%] > .dialog-button[_ngcontent-%COMP%]:last-child{margin-right:0}.dialog__icon[_ngcontent-%COMP%]{margin-bottom:30px;font-size:60px}.dialog__text[_ngcontent-%COMP%]{font-size:30px;font-weight:400;white-space:pre-line}.dialog--danger[_ngcontent-%COMP%]{padding:0}.dialog--danger[_ngcontent-%COMP%]   .dialog__content[_ngcontent-%COMP%]{padding:1px 60px 30px}.dialog[_ngcontent-%COMP%]   .icon-dialog-position[_ngcontent-%COMP%]{float:right;margin:32px 32px auto auto;font-size:24px;cursor:pointer}.dialog-button[_ngcontent-%COMP%]{display:flex;padding:20px;justify-content:center;align-items:center;font-size:32px;text-align:center;text-transform:uppercase;white-space:nowrap;cursor:pointer}.dialog-button--ghost[_ngcontent-%COMP%]{background-color:transparent;box-shadow:unset}.dialog-header[_ngcontent-%COMP%]{margin-bottom:40px!important}.loading-container[_ngcontent-%COMP%]{height:390px;line-height:390px}.spinner[_ngcontent-%COMP%]{-webkit-filter:invert(1);filter:invert(1);height:75px;width:75px;-webkit-animation:2s linear infinite spinner;animation:2s linear infinite spinner}@-webkit-keyframes spinner{from{transform:rotate(0)}to{transform:rotate(360deg)}}@keyframes spinner{from{transform:rotate(0)}to{transform:rotate(360deg)}}"]
                ],
                f = e.Gb({
                    encapsulation: 0,
                    styles: g,
                    data: {}
                });

            function m(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 0, "div", [], [
                    [8, "className", 0],
                    [4, "color", null]
                ], null, null, null, null))], null, (function(n, t) {
                    var l = t.component;
                    n(t, 0, 0, e.Mb(1, "", l.configuration.icon, " dialog__icon"), l.configuration.iconColor)
                }))
            }

            function _(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 5, "div", [
                    ["class", "dialog-header"]
                ], null, null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, m)), e.Hb(2, 16384, null, 0, i.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.Ib(3, 0, null, null, 2, "div", [
                    ["class", "dialog__text"]
                ], null, null, null, null, null)), (n()(), e.cc(4, null, ["", ""])), e.Wb(131072, o.j, [o.k, e.i])], (function(n, t) {
                    n(t, 2, 0, t.component.configuration.icon)
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 4, 0, e.dc(t, 4, 0, e.Ub(t, 5).transform(null == l.modalData ? null : l.modalData.message)))
                }))
            }

            function v(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 2, "div", [], null, null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 1, "grc-modal-data-dialog-qr-scanner", [], null, [
                    [null, "formEvent"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "formEvent" === t && (e = !1 !== i.openForm(l) && e);
                    return e
                }), r.c, r.b)), e.Hb(2, 114688, [
                    [1, 4]
                ], 0, u.a, [s.a, e.P], null, {
                    formEvent: "formEvent"
                })], (function(n, t) {
                    n(t, 2, 0)
                }), null)
            }

            function y(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 2, "div", [], null, null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 1, "grc-modal-data-dialog-form", [], null, [
                    [null, "qrEvent"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "qrEvent" === t && (e = !1 !== i.openQR() && e);
                    return e
                }), c.c, c.b)), e.Hb(2, 114688, null, 0, a.a, [d.a], {
                    hasQRPermissions: [0, "hasQRPermissions"],
                    scannedData: [1, "scannedData"],
                    formParams: [2, "formParams"],
                    configuration: [3, "configuration"]
                }, {
                    qrEvent: "qrEvent"
                })], (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, l.hasQRPermissions, l.scannedData, null == l.modalData ? null : l.modalData.formParams, l.configuration)
                }), null)
            }

            function C(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 4, "div", [], null, null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, v)), e.Hb(2, 16384, null, 0, i.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.xb(16777216, null, null, 1, null, y)), e.Hb(4, 16384, null, 0, i.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, l.hasQRPermissions && !l.isFormButtonClicked), n(t, 4, 0, !l.hasQRPermissions || l.isFormButtonClicked)
                }), null)
            }

            function k(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "div", [
                    ["class", "loading-container"]
                ], null, null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 0, "img", [
                    ["alt", ""],
                    ["class", "spinner"],
                    ["src", "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAC4AAAAuCAMAAABgZ9sFAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAqUExURQAAAP///////////////////////////////////////////////////4a7yi8AAAANdFJOUwC07wpTiJzdzBtqPSzCC5LxAAABZElEQVRIx42WWRbDIAhFBTXitP/tNj3iVEXLl7FXAg+kUWo2HS3YsnwXUauTeYs556c8PO8SrRfh9AVm/PuU9nTAvMMzhl0ckPMezxmWiBJmGc+YRBoC+/IBBL7TsxLe7njtxCBbSq6XoEYZtoLNGfUNsxfYzM40HunGox6dW7k37OCendOpl6i7Z+fphKfuvigFx07tkC4H4xmPhdKctlMXcyyenWsg2cPqwVnzWXtgjdINT6x2CcrfcM8pliKpq5VCqarQxVhv9v5nMMixxxseOXaQL8Z6SYDLBDccuExxbH05U6wx4z9lNZxp7QY649Q6y+S7+5Fxv3NkjdwNXc5H4SZLDYAuo4AHAc03S+LrnIy/G7CJX8PqrM3NRR/Tpu3ogupgJjO8QZu+P73YU5/8EGLSOsUA/T+CvBDi1jZJWZneShZpD5N0d5oMg7lTM5kHRxaf67x6vyHcewbd+wWx/PgBSrMjPYgObLoAAAAASUVORK5CYII="]
                ], null, null, null, null, null))], null, null)
            }

            function x(n) {
                return e.ec(2, [e.ac(671088640, 1, {
                    child: 0
                }), (n()(), e.Ib(1, 0, null, null, 8, "div", [
                    ["class", "dialog"]
                ], [
                    [2, "dialog--danger", null]
                ], null, null, null, null)), (n()(), e.Ib(2, 0, null, null, 1, "div", [], null, null, null, null, null)), (n()(), e.Ib(3, 0, null, null, 0, "span", [
                    ["class", "icon icon-cancel icon-dialog-position"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.close() && e);
                    return e
                }), null, null)), (n()(), e.Ib(4, 0, null, null, 5, "div", [
                    ["class", "dialog__content"]
                ], null, null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, _)), e.Hb(6, 16384, null, 0, i.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.xb(16777216, null, null, 1, null, C)), e.Hb(8, 16384, null, 0, i.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"],
                    ngIfElse: [1, "ngIfElse"]
                }, null), (n()(), e.xb(0, [
                    ["loadingTemplate", 2]
                ], null, 0, null, k))], (function(n, t) {
                    var l = t.component;
                    n(t, 6, 0, !l.isFormButtonClicked), n(t, 8, 0, !l.isLoading, e.Ub(t, 9))
                }), (function(n, t) {
                    n(t, 1, 0, "danger" === t.component.configuration.type)
                }))
            }
            var I = e.Eb("grc-modal-data-dialog", p.a, (function(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "grc-modal-data-dialog", [], null, null, null, x, f)), e.Hb(1, 245760, null, 0, p.a, [e.i, b.a, d.a, h.a], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                configuration: "configuration",
                modalId: "modalId"
            }, {}, [])
        },
        lBSr: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return r
            }));
            var e, i = l("NPGq"),
                o = (e = function(n, t) {
                    return (e = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(n, t) {
                            n.__proto__ = t
                        } || function(n, t) {
                            for (var l in t) Object.prototype.hasOwnProperty.call(t, l) && (n[l] = t[l])
                        })(n, t)
                }, function(n, t) {
                    function l() {
                        this.constructor = n
                    }
                    e(n, t), n.prototype = null === t ? Object.create(t) : (l.prototype = t.prototype, new l)
                }),
                r = function(n) {
                    function t() {
                        return null !== n && n.apply(this, arguments) || this
                    }
                    return o(t, n), t.prototype.ngOnInit = function() {}, t
                }(i.a)
        },
        lwRT: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return u
            }));
            var e, i = l("NPGq"),
                o = l("CrY/"),
                r = (e = function(n, t) {
                    return (e = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(n, t) {
                            n.__proto__ = t
                        } || function(n, t) {
                            for (var l in t) Object.prototype.hasOwnProperty.call(t, l) && (n[l] = t[l])
                        })(n, t)
                }, function(n, t) {
                    function l() {
                        this.constructor = n
                    }
                    e(n, t), n.prototype = null === t ? Object.create(t) : (l.prototype = t.prototype, new l)
                }),
                u = function(n) {
                    function t() {
                        var t = null !== n && n.apply(this, arguments) || this;
                        return t.isAlreadyPaidout = !1, t.isExpired = !1, t
                    }
                    return r(t, n), t.prototype.ngOnInit = function() {
                        this.isAlreadyPaidout = this.serverTicket.status === o.coreModel.TicketStatus.PAIDOUT, this.isExpired = this.serverTicket.status === o.coreModel.TicketStatus.EXPIRED, this.hasConfirm = !this.isAlreadyPaidout && !this.isExpired
                    }, t
                }(i.a)
        },
        mYlp: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return c
            })), l.d(t, "b", (function() {
                return y
            })), l.d(t, "c", (function() {
                return C
            }));
            var e = l("CcnG"),
                i = l("Ip0R"),
                o = l("gIcY"),
                r = l("5EE+"),
                u = l("k1pK"),
                s = [
                    ["[_nghost-%COMP%]{display:table-cell;text-align:center;vertical-align:middle}.virtual-keyboard[_ngcontent-%COMP%]{position:relative;max-width:1225px;padding:70px 156px;margin:0 auto;font-weight:700;background-color:#fff}.virtual-keyboard__input[_ngcontent-%COMP%]{width:100%;height:44px;font-size:36px;font-weight:400;color:#000;text-align:center;pointer-events:none;border:0;outline:0}.virtual-keyboard__input[_ngcontent-%COMP%]::-webkit-input-placeholder{text-transform:capitalize}.virtual-keyboard__input[_ngcontent-%COMP%]::-moz-placeholder{text-transform:capitalize}.virtual-keyboard__input[_ngcontent-%COMP%]:-ms-input-placeholder{text-transform:capitalize}.virtual-keyboard__input[_ngcontent-%COMP%]::-ms-input-placeholder{text-transform:capitalize}.virtual-keyboard__input[_ngcontent-%COMP%]::placeholder{text-transform:capitalize}.virtual-keyboard__input--error[_ngcontent-%COMP%]{border-bottom-color:#b12828}.virtual-keyboard__password--no-visible[_ngcontent-%COMP%]{-webkit-text-security:disc}.virtual-keyboard__password--visible[_ngcontent-%COMP%]{-webkit-text-security:none}.virtual-keyboard__icon-visibility[_ngcontent-%COMP%]{position:absolute;font-size:32px;margin-top:5px;margin-left:-40px}.virtual-keyboard--error[_ngcontent-%COMP%]{height:16px;margin-top:10px;margin-bottom:50px;color:#b12828}.virtual-keyboard__button[_ngcontent-%COMP%]{display:flex;justify-content:center;align-items:center;max-width:72px;max-height:72px;padding:20px;font-size:32px;color:#000;text-align:center;cursor:pointer;background-color:#f5f5f5;border-radius:2px;box-shadow:0 1px 2px 0 #a0a0a0}.virtual-keyboard__button--icon-back[_ngcontent-%COMP%]{font-size:36px}.virtual-keyboard__button--clear[_ngcontent-%COMP%]{min-width:140px;height:100%;margin-right:7px;font-size:26px;color:#fff;background-color:#618b31}.virtual-keyboard__button--success[_ngcontent-%COMP%]{display:flex;justify-content:center;min-width:270px;height:100%;margin-left:7px;font-size:26px;color:#fff;background-color:#618b31}.virtual-keyboard__button--separation[_ngcontent-%COMP%]{padding:0 12px 0 0}.virtual-keyboard--row-margin[_ngcontent-%COMP%]{margin-bottom:12px}.virtual-keyboard--last-row-margin[_ngcontent-%COMP%]{margin-top:50px}.virtual-keyboard--row-padding[_ngcontent-%COMP%]{padding:0 60px}.virtual-keyboard--row-two-padding[_ngcontent-%COMP%]{padding:0 100px}.virtual-keyboard__close[_ngcontent-%COMP%]{position:absolute;top:30px;right:30px;cursor:pointer}.virtual-keyboard__close[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{font-size:24px}"]
                ],
                c = e.Gb({
                    encapsulation: 0,
                    styles: s,
                    data: {}
                });

            function a(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 0, "span", [
                    ["class", "virtual-keyboard__icon-visibility icon"]
                ], [
                    [2, "icon-visibility", null],
                    [2, "icon-visibility-off", null]
                ], [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.togglePasswordVisibility() && e);
                    return e
                }), null, null))], null, (function(n, t) {
                    var l = t.component;
                    n(t, 0, 0, !l.isPasswordVisible, l.isPasswordVisible)
                }))
            }

            function d(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 2, null, null, null, null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 1, "div", [
                    ["class", "virtual-keyboard__button"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.insert(n.parent.context.$implicit) && e);
                    return e
                }), null, null)), (n()(), e.cc(2, null, ["", ""]))], null, (function(n, t) {
                    n(t, 2, 0, t.parent.context.$implicit)
                }))
            }

            function p(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 0, "div", [
                    ["class", "virtual-keyboard__button icon icon-back virtual-keyboard__button--icon-back"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.onBackspace() && e);
                    return e
                }), null, null))], null, null)
            }

            function b(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 3, "div", [
                    ["class", "col"]
                ], [
                    [2, "virtual-keyboard__button--separation", null]
                ], null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, d)), e.Hb(2, 16384, null, 0, i.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"],
                    ngIfElse: [1, "ngIfElse"]
                }, null), (n()(), e.xb(0, [
                    ["deleteButton", 2]
                ], null, 0, null, p))], (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, t.context.index !== l.numbers.length - 1, e.Ub(t, 3))
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 0, 0, t.context.index !== l.numbers.length - 1)
                }))
            }

            function h(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 2, "div", [
                    ["class", "col"]
                ], [
                    [2, "virtual-keyboard__button--separation", null]
                ], null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 1, "div", [
                    ["class", "virtual-keyboard__button"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.insert(n.context.$implicit) && e);
                    return e
                }), null, null)), (n()(), e.cc(2, null, ["", ""]))], null, (function(n, t) {
                    var l = t.component;
                    n(t, 0, 0, t.context.index !== l.letters.rowOne.length - 1), n(t, 2, 0, t.context.$implicit)
                }))
            }

            function g(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 2, "div", [
                    ["class", "col col-12 grid grid-center virtual-keyboard--row-margin virtual-keyboard--row-padding"]
                ], null, null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, h)), e.Hb(2, 278528, null, 0, i.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(n, t) {
                    n(t, 2, 0, t.component.letters.rowOne)
                }), null)
            }

            function f(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 2, "div", [
                    ["class", "col"]
                ], [
                    [2, "virtual-keyboard__button--separation", null]
                ], null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 1, "div", [
                    ["class", "virtual-keyboard__button"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.insert(n.context.$implicit) && e);
                    return e
                }), null, null)), (n()(), e.cc(2, null, ["", ""]))], null, (function(n, t) {
                    var l = t.component;
                    n(t, 0, 0, t.context.index !== l.letters.rowTwo.length - 1), n(t, 2, 0, t.context.$implicit)
                }))
            }

            function m(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 2, "div", [
                    ["class", "col col-12 grid grid-center virtual-keyboard--row-margin virtual-keyboard--row-two-padding"]
                ], null, null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, f)), e.Hb(2, 278528, null, 0, i.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(n, t) {
                    n(t, 2, 0, t.component.letters.rowTwo)
                }), null)
            }

            function _(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 2, "div", [
                    ["class", "col"]
                ], [
                    [2, "virtual-keyboard__button--separation", null]
                ], null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 1, "div", [
                    ["class", "virtual-keyboard__button"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.insert(n.context.$implicit) && e);
                    return e
                }), null, null)), (n()(), e.cc(2, null, ["", ""]))], null, (function(n, t) {
                    var l = t.component;
                    n(t, 0, 0, t.context.index !== l.letters.rowThree.length - 1), n(t, 2, 0, t.context.$implicit)
                }))
            }

            function v(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 2, "div", [
                    ["class", "col col-12 grid grid-center virtual-keyboard--row-margin virtual-keyboard--row-padding"]
                ], null, null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, _)), e.Hb(2, 278528, null, 0, i.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(n, t) {
                    n(t, 2, 0, t.component.letters.rowThree)
                }), null)
            }

            function y(n) {
                return e.ec(2, [(n()(), e.Ib(0, 0, null, null, 30, "div", [
                    ["class", "grid-column virtual-keyboard"]
                ], null, null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 1, "div", [
                    ["class", "virtual-keyboard__close"]
                ], null, null, null, null, null)), (n()(), e.Ib(2, 0, null, null, 0, "span", [
                    ["class", "icon icon-cancel"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.closeVirtualKeyBoard() && e);
                    return e
                }), null, null)), (n()(), e.Ib(3, 0, null, null, 6, "input", [
                    ["class", "virtual-keyboard__input"]
                ], [
                    [8, "placeholder", 0],
                    [2, "virtual-keyboard__input--error", null],
                    [2, "virtual-keyboard__password--visible", null],
                    [2, "virtual-keyboard__password--no-visible", null],
                    [2, "ng-untouched", null],
                    [2, "ng-touched", null],
                    [2, "ng-pristine", null],
                    [2, "ng-dirty", null],
                    [2, "ng-valid", null],
                    [2, "ng-invalid", null],
                    [2, "ng-pending", null]
                ], [
                    [null, "input"],
                    [null, "blur"],
                    [null, "compositionstart"],
                    [null, "compositionend"]
                ], (function(n, t, l) {
                    var i = !0;
                    "input" === t && (i = !1 !== e.Ub(n, 4)._handleInput(l.target.value) && i);
                    "blur" === t && (i = !1 !== e.Ub(n, 4).onTouched() && i);
                    "compositionstart" === t && (i = !1 !== e.Ub(n, 4)._compositionStart() && i);
                    "compositionend" === t && (i = !1 !== e.Ub(n, 4)._compositionEnd(l.target.value) && i);
                    return i
                }), null, null)), e.Hb(4, 16384, null, 0, o.d, [e.P, e.o, [2, o.a]], null, null), e.Zb(1024, null, o.h, (function(n) {
                    return [n]
                }), [o.d]), e.Hb(6, 671744, null, 0, o.m, [
                    [8, null],
                    [8, null],
                    [8, null],
                    [6, o.h]
                ], {
                    model: [0, "model"]
                }, null), e.Zb(2048, null, o.i, null, [o.m]), e.Hb(8, 16384, null, 0, o.j, [
                    [4, o.i]
                ], null, null), e.Wb(131072, r.j, [r.k, e.i]), (n()(), e.xb(16777216, null, null, 1, null, a)), e.Hb(11, 16384, null, 0, i.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.Ib(12, 0, null, null, 1, "div", [
                    ["class", "virtual-keyboard--error"]
                ], null, null, null, null, null)), (n()(), e.cc(13, null, ["", ""])), (n()(), e.Ib(14, 0, null, null, 16, "div", [
                    ["class", "col grid grid-10"]
                ], null, null, null, null, null)), (n()(), e.Ib(15, 0, null, null, 2, "div", [
                    ["class", "col col-12 grid grid-center virtual-keyboard--row-margin"]
                ], null, null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, b)), e.Hb(17, 278528, null, 0, i.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), (n()(), e.xb(16777216, null, null, 1, null, g)), e.Hb(19, 16384, null, 0, i.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.xb(16777216, null, null, 1, null, m)), e.Hb(21, 16384, null, 0, i.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.xb(16777216, null, null, 1, null, v)), e.Hb(23, 16384, null, 0, i.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.Ib(24, 0, null, null, 6, "div", [
                    ["class", "col col-12 grid grid-center virtual-keyboard--last-row-margin"]
                ], null, null, null, null, null)), (n()(), e.Ib(25, 0, null, null, 2, "div", [
                    ["class", "virtual-keyboard__button virtual-keyboard__button--clear"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.clear() && e);
                    return e
                }), null, null)), (n()(), e.cc(26, null, ["", ""])), e.Wb(131072, r.j, [r.k, e.i]), (n()(), e.Ib(28, 0, null, null, 2, "div", [
                    ["class", "virtual-keyboard__button virtual-keyboard__button--success"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.done() && e);
                    return e
                }), null, null)), (n()(), e.cc(29, null, ["", ""])), e.Wb(131072, r.j, [r.k, e.i])], (function(n, t) {
                    var l = t.component;
                    n(t, 6, 0, l.content), n(t, 11, 0, l.showHidePassword && l.isInputPassword && l.passwordVisibilityIcon), n(t, 17, 0, l.numbers), n(t, 19, 0, !l.onlyNumbers), n(t, 21, 0, !l.onlyNumbers), n(t, 23, 0, !l.onlyNumbers)
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 3, 1, [e.Mb(1, "", e.dc(t, 3, 0, e.Ub(t, 9).transform(l.placeholder)), ""), l.error, !l.isInputPassword || l.isPasswordVisible, l.isInputPassword && !l.isPasswordVisible, e.Ub(t, 8).ngClassUntouched, e.Ub(t, 8).ngClassTouched, e.Ub(t, 8).ngClassPristine, e.Ub(t, 8).ngClassDirty, e.Ub(t, 8).ngClassValid, e.Ub(t, 8).ngClassInvalid, e.Ub(t, 8).ngClassPending]), n(t, 13, 0, l.error), n(t, 26, 0, e.dc(t, 26, 0, e.Ub(t, 27).transform("ch_clear"))), n(t, 29, 0, e.dc(t, 29, 0, e.Ub(t, 30).transform("ch_done")))
                }))
            }
            var C = e.Eb("grc-virtual-keyboard", u.a, (function(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "grc-virtual-keyboard", [], null, [
                    ["document", "keydown"],
                    ["document", "keydown.backspace"],
                    ["document", "keydown.enter"],
                    ["document", "keydown.escape"],
                    ["document", "paste"]
                ], (function(n, t, l) {
                    var i = !0;
                    "document:keydown" === t && (i = !1 !== e.Ub(n, 1).onKeyDown(l.key, l.keyCode, l.ctrlKey) && i);
                    "document:keydown.backspace" === t && (i = !1 !== e.Ub(n, 1).onBackspace() && i);
                    "document:keydown.enter" === t && (i = !1 !== e.Ub(n, 1).onEnter() && i);
                    "document:keydown.escape" === t && (i = !1 !== e.Ub(n, 1).onEsc() && i);
                    "document:paste" === t && (i = !1 !== e.Ub(n, 1).onPaste(l) && i);
                    return i
                }), y, c)), e.Hb(1, 114688, null, 0, u.a, [e.i, r.k], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                data: "data",
                onlyNumbers: "onlyNumbers",
                placeholder: "placeholder",
                showHidePassword: "showHidePassword"
            }, {
                success: "success"
            }, [])
        },
        mv7g: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return b
            })), l.d(t, "b", (function() {
                return x
            }));
            var e = l("CcnG"),
                i = l("Ip0R"),
                o = l("xTWW"),
                r = l("kMfV"),
                u = [
                    [""]
                ],
                s = e.Gb({
                    encapsulation: 0,
                    styles: u,
                    data: {}
                });

            function c(n) {
                return e.ec(0, [(n()(), e.xb(0, null, null, 0))], null, null)
            }

            function a(n) {
                return e.ec(2, [(n()(), e.xb(16777216, null, null, 1, null, c)), e.Hb(1, 81920, null, 0, o.a, [e.eb, r.a], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }
            e.Eb("grc-tab-body", r.a, (function(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "grc-tab-body", [], [
                    [2, "tab-body", null]
                ], null, null, a, s)), e.Hb(1, 114688, null, 0, r.a, [], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), (function(n, t) {
                    n(t, 0, 0, e.Ub(t, 1).clazz)
                }))
            }), {
                content: "content"
            }, {}, []);
            var d = l("+69r"),
                p = [
                    [".tab-set[_ngcontent-%COMP%]{height:100%}.tab-set__contents[_ngcontent-%COMP%], .tab-set__fixed[_ngcontent-%COMP%]{position:relative}.tab-set__contents--ghost[_ngcontent-%COMP%], .tab-set__fixed--ghost[_ngcontent-%COMP%]{background-color:transparent}.tab-set--border[_ngcontent-%COMP%]   .tab-set__headers[_ngcontent-%COMP%]{top:1px;padding-right:25px;padding-left:25px}.tab-set--border--disabled[_ngcontent-%COMP%]{border:0}.tab-set--flat[_ngcontent-%COMP%]   .tab-header[_ngcontent-%COMP%]{cursor:default;background-color:transparent;border:0}.tab-set__navigation[_ngcontent-%COMP%]{position:absolute;top:0;display:inline-flex;align-items:center;justify-content:center;min-width:38px;height:100%;padding:0 5px;cursor:pointer;border-radius:3px}.tab-set__navigation--left[_ngcontent-%COMP%]{left:0}.tab-set__navigation--right[_ngcontent-%COMP%]{right:0}.tab-set__headers[_ngcontent-%COMP%]{position:relative;z-index:2;height:45px;max-height:45px;overflow:hidden;text-transform:capitalize}.tab-set__headers-container[_ngcontent-%COMP%]{position:relative;height:100%}.tab-set__headers-container[_ngcontent-%COMP%] > .grid[_ngcontent-%COMP%]{height:100%;overflow-x:hidden;transition:.2s transform}.tab-set__headers-container[_ngcontent-%COMP%] > .grid[_ngcontent-%COMP%]::-webkit-scrollbar{display:none}.tab-set__headers--stretch[_ngcontent-%COMP%]{bottom:0}.tab-set__headers--stretch[_ngcontent-%COMP%]   .tab-header[_ngcontent-%COMP%]{flex-grow:1;padding:12px}.tab-header[_ngcontent-%COMP%]{padding:14px 20px;font-size:18px;flex:none;font-weight:700;text-align:center;text-transform:uppercase;cursor:pointer;border-radius:4px 4px 0 0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:325px}.tab-header[_ngcontent-%COMP%]:first-child{margin-left:0}.tab-header[_ngcontent-%COMP%]:last-child{margin-right:0}.tab-header--fourth_place_worse[_ngcontent-%COMP%]{max-width:130px}.tab-set__contents[_ngcontent-%COMP%]{position:relative;z-index:1}.tab-set__contents[_ngcontent-%COMP%]  .tab-body{position:relative;z-index:1;display:none;overflow-x:hidden;overflow-y:auto;flex-grow:1}.tab-set__contents[_ngcontent-%COMP%]  .tab-body--active{z-index:2;display:block}.tab-set__contents--ghost[_ngcontent-%COMP%]  .tab-body{background-color:transparent}"]
                ],
                b = e.Gb({
                    encapsulation: 0,
                    styles: p,
                    data: {}
                });

            function h(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "div", [
                    ["class", "tab-set__navigation tab-set__navigation--left"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.previousTabNavigation() && e);
                    return e
                }), null, null)), (n()(), e.Ib(1, 0, null, null, 0, "span", [
                    ["class", "icon icon-left"]
                ], null, null, null, null, null))], null, null)
            }

            function g(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 2, "div", [], [
                    [8, "className", 0],
                    [2, "tab-header--active", null],
                    [2, "tab-header--disabled", null]
                ], [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.select(n.context.index) && e);
                    return e
                }), null, null)), e.Yb(1, 1), (n()(), e.cc(2, null, [" ", " "]))], null, (function(n, t) {
                    var l = t.component,
                        i = e.Mb(1, "col tab-header tab-header--", e.dc(t, 0, 0, n(t, 1, 0, e.Ub(t.parent.parent, 0), t.context.$implicit.id)), "");
                    n(t, 0, 0, i, t.context.$implicit.id === l.selected && !l.disabled, l.disabled), n(t, 2, 0, t.context.$implicit.header)
                }))
            }

            function f(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "div", [
                    ["class", "tab-set__navigation tab-set__navigation--right"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.nextTabNavigation() && e);
                    return e
                }), null, null)), (n()(), e.Ib(1, 0, null, null, 0, "span", [
                    ["class", "icon icon-right"]
                ], null, null, null, null, null))], null, null)
            }

            function m(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 9, "div", [
                    ["class", "col tab-set__headers"]
                ], [
                    [2, "tab-set__headers--stretch", null],
                    [2, "tab-set__headers--cash", null]
                ], null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 7, "div", [
                    ["class", "tab-set__headers-container"]
                ], null, null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, h)), e.Hb(3, 16384, null, 0, i.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.Ib(4, 0, [
                    [1, 0],
                    ["tabHeaders", 1]
                ], null, 2, "div", [
                    ["class", "grid grid-no-wrap"]
                ], null, [
                    [null, "scroll"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "scroll" === t && (e = !1 !== i.onTabScroll(l) && e);
                    return e
                }), null, null)), (n()(), e.xb(16777216, null, null, 1, null, g)), e.Hb(6, 278528, null, 0, i.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), (n()(), e.xb(16777216, null, null, 1, null, f)), e.Hb(8, 16384, null, 0, i.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), e.Tb(null, 0)], (function(n, t) {
                    var l = t.component;
                    n(t, 3, 0, l.hasPreviousNavigation), n(t, 6, 0, l.tabs), n(t, 8, 0, l.hasNextNavigation)
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 0, 0, l.stretch, l.isCashManagement)
                }))
            }

            function _(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 2, "div", [], [
                    [8, "className", 0]
                ], null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 1, "grc-tab-body", [], [
                    [2, "tab-body", null]
                ], null, null, a, s)), e.Hb(2, 114688, null, 0, r.a, [], {
                    content: [0, "content"]
                }, null)], (function(n, t) {
                    n(t, 2, 0, t.context.ngIf.content)
                }), (function(n, t) {
                    n(t, 0, 0, e.Mb(1, "tab-set__fixed ", t.context.ngIf.class, "")), n(t, 1, 0, e.Ub(t, 2).clazz)
                }))
            }

            function v(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "grc-tab-body", [], [
                    [2, "tab-body--active", null],
                    [2, "tab-body", null]
                ], null, null, a, s)), e.Hb(1, 114688, null, 0, r.a, [], {
                    content: [0, "content"]
                }, null)], (function(n, t) {
                    n(t, 1, 0, t.parent.context.$implicit.content)
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 0, 0, t.parent.context.$implicit.id === l.selected, e.Ub(t, 1).clazz)
                }))
            }

            function y(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 2, null, null, null, null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, v)), e.Hb(2, 16384, null, 0, i.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.xb(0, null, null, 0))], (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, t.context.$implicit.id === l.selected)
                }), null)
            }

            function C(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 2, null, null, null, null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, y)), e.Hb(2, 278528, null, 0, i.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), (n()(), e.xb(0, null, null, 0))], (function(n, t) {
                    n(t, 2, 0, t.component.tabs)
                }), null)
            }

            function k(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 2, null, null, null, null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 1, "grc-tab-body", [
                    ["class", "tab-body--active"]
                ], [
                    [2, "tab-body--disabled", null],
                    [2, "tab-body", null]
                ], null, null, a, s)), e.Hb(2, 114688, null, 0, r.a, [], {
                    content: [0, "content"]
                }, null)], (function(n, t) {
                    n(t, 2, 0, t.component.getUniqueContent().content)
                }), (function(n, t) {
                    n(t, 1, 0, t.component.disabled, e.Ub(t, 2).clazz)
                }))
            }

            function x(n) {
                return e.ec(2, [e.Wb(0, i.j, []), e.ac(671088640, 1, {
                    tabHeaders: 0
                }), (n()(), e.Ib(2, 0, null, null, 10, "div", [
                    ["class", "grid grid-column tab-set"]
                ], [
                    [2, "tab-set--border", null]
                ], null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, m)), e.Hb(4, 16384, null, 0, i.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.Ib(5, 0, null, null, 7, "div", [
                    ["class", "col grid grid-no-wrap"]
                ], null, null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, _)), e.Hb(7, 16384, null, 0, i.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.Ib(8, 0, null, null, 4, "div", [
                    ["class", "col grid grid-no-wrap tab-set__contents"]
                ], [
                    [2, "tab-set--border--disabled", null],
                    [2, "tab-set__contents--ghost", null]
                ], null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, C)), e.Hb(10, 16384, null, 0, i.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.xb(16777216, null, null, 1, null, k)), e.Hb(12, 16384, null, 0, i.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(n, t) {
                    var l = t.component;
                    n(t, 4, 0, !l.areHiddenModeTabs && !l.hiddenTabs), n(t, 7, 0, l.getContentFixedLeft()), n(t, 10, 0, !l.sameContent), n(t, 12, 0, l.sameContent)
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, l.hasBorder), n(t, 8, 0, l.disabled, l.ghost)
                }))
            }
            e.Eb("grc-tab-set", d.a, (function(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 3, "grc-tab-set", [], [
                    [8, "className", 0]
                ], null, null, x, b)), e.Hb(1, 4308992, null, 2, d.a, [e.i], null, null), e.ac(603979776, 1, {
                    tabsContent: 1
                }), e.ac(603979776, 2, {
                    tabsFixedContent: 1
                })], (function(n, t) {
                    n(t, 1, 0)
                }), (function(n, t) {
                    n(t, 0, 0, e.Ub(t, 1).tabSetClass)
                }))
            }), {
                stretch: "stretch",
                sameContent: "sameContent",
                hasBorder: "hasBorder",
                hiddenTabs: "hiddenTabs",
                selected: "selected",
                disabled: "disabled",
                ghost: "ghost",
                isCashManagement: "isCashManagement",
                tabSetClass: "tabSetClass"
            }, {
                selectedChange: "selectedChange"
            }, ["[actionButton]"])
        },
        nYwI: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return e
            }));
            var e = {
                hasMultiplier: !1,
                preStake: null,
                hasOptionsSelected: !1,
                tabsMode: [],
                betMode: null,
                ticketEventTitle: function(n) {
                    return {
                        title: n.eventId.toString()
                    }
                },
                prefixMarket: null,
                suffixMarket: null,
                oddName: function(n, t, l, e, i) {
                    return "" + l.getMarketOptionTag(t, n.oddId, "", n.betParam, e, i)
                },
                fastbetHelp: null,
                fastbetStake: function() {
                    return 0
                }
            }
        },
        nw0P: function(n, t, l) {
            var e = {
                "./_lib/buildFormatLongFn/index.js": "HyFC",
                "./_lib/buildLocalizeFn/index.js": "rwOc",
                "./_lib/buildMatchFn/index.js": "sCib",
                "./_lib/buildMatchPatternFn/index.js": "loZk",
                "./af/_lib/formatDistance/index.js": "c8ia",
                "./af/_lib/formatLong/index.js": "14x+",
                "./af/_lib/formatRelative/index.js": "MO5o",
                "./af/_lib/localize/index.js": "ZwEY",
                "./af/_lib/match/index.js": "8wHm",
                "./af/index.js": "IqAn",
                "./ar-DZ/_lib/formatDistance/index.js": "Q/uj",
                "./ar-DZ/_lib/formatLong/index.js": "NXl1",
                "./ar-DZ/_lib/formatRelative/index.js": "XZ7z",
                "./ar-DZ/_lib/localize/index.js": "idCP",
                "./ar-DZ/_lib/match/index.js": "ve55",
                "./ar-DZ/index.js": "JVC1",
                "./ar-MA/_lib/formatDistance/index.js": "+QaL",
                "./ar-MA/_lib/formatLong/index.js": "IVf7",
                "./ar-MA/_lib/formatRelative/index.js": "uJen",
                "./ar-MA/_lib/localize/index.js": "JfA9",
                "./ar-MA/_lib/match/index.js": "bbmQ",
                "./ar-MA/index.js": "+7lX",
                "./ar-SA/_lib/formatDistance/index.js": "sKvR",
                "./ar-SA/_lib/formatLong/index.js": "owub",
                "./ar-SA/_lib/formatRelative/index.js": "x8a+",
                "./ar-SA/_lib/localize/index.js": "Tcnf",
                "./ar-SA/_lib/match/index.js": "VUfK",
                "./ar-SA/index.js": "xMju",
                "./az/_lib/formatDistance/index.js": "hcS+",
                "./az/_lib/formatLong/index.js": "+sPi",
                "./az/_lib/formatRelative/index.js": "fzjd",
                "./az/_lib/localize/index.js": "HDba",
                "./az/_lib/match/index.js": "oFZE",
                "./az/index.js": "jEeQ",
                "./be/_lib/formatDistance/index.js": "xOmX",
                "./be/_lib/formatLong/index.js": "K3tP",
                "./be/_lib/formatRelative/index.js": "3m9E",
                "./be/_lib/localize/index.js": "Z6sX",
                "./be/_lib/match/index.js": "V4d2",
                "./be/index.js": "YEhR",
                "./bg/_lib/formatDistance/index.js": "1Ipa",
                "./bg/_lib/formatLong/index.js": "xLtw",
                "./bg/_lib/formatRelative/index.js": "p1+n",
                "./bg/_lib/localize/index.js": "5oH2",
                "./bg/_lib/match/index.js": "SEnY",
                "./bg/index.js": "isx8",
                "./bn/_lib/formatDistance/index.js": "x+ST",
                "./bn/_lib/formatLong/index.js": "K6am",
                "./bn/_lib/formatRelative/index.js": "qyn7",
                "./bn/_lib/localize/index.js": "ys1e",
                "./bn/_lib/match/index.js": "kMTc",
                "./bn/index.js": "+b7I",
                "./ca/_lib/formatDistance/index.js": "lfgH",
                "./ca/_lib/formatLong/index.js": "L3Bt",
                "./ca/_lib/formatRelative/index.js": "Mwgz",
                "./ca/_lib/localize/index.js": "vwr2",
                "./ca/_lib/match/index.js": "tHEN",
                "./ca/index.js": "Vwa+",
                "./cs/_lib/formatDistance/index.js": "zdRj",
                "./cs/_lib/formatLong/index.js": "YVL8",
                "./cs/_lib/formatRelative/index.js": "raNJ",
                "./cs/_lib/localize/index.js": "o8tu",
                "./cs/_lib/match/index.js": "Xn9f",
                "./cs/index.js": "dvhP",
                "./cy/_lib/formatDistance/index.js": "8BPP",
                "./cy/_lib/formatLong/index.js": "dhnH",
                "./cy/_lib/formatRelative/index.js": "Lj+f",
                "./cy/_lib/localize/index.js": "X9is",
                "./cy/_lib/match/index.js": "Z82l",
                "./cy/index.js": "HQUR",
                "./da/_lib/formatDistance/index.js": "6VTv",
                "./da/_lib/formatLong/index.js": "vC+E",
                "./da/_lib/formatRelative/index.js": "+evU",
                "./da/_lib/localize/index.js": "lx4+",
                "./da/_lib/match/index.js": "LGYC",
                "./da/index.js": "7ur/",
                "./de/_lib/formatDistance/index.js": "hlZQ",
                "./de/_lib/formatLong/index.js": "YnsC",
                "./de/_lib/formatRelative/index.js": "DC3G",
                "./de/_lib/localize/index.js": "9a3c",
                "./de/_lib/match/index.js": "IRNh",
                "./de/index.js": "bgw5",
                "./el/_lib/formatDistance/index.js": "RQ32",
                "./el/_lib/formatLong/index.js": "YcXs",
                "./el/_lib/formatRelative/index.js": "PK2z",
                "./el/_lib/localize/index.js": "1Du0",
                "./el/_lib/match/index.js": "/uen",
                "./el/index.js": "dH0v",
                "./en-AU/_lib/formatLong/index.js": "nEdr",
                "./en-AU/index.js": "VHew",
                "./en-CA/_lib/formatDistance/index.js": "I8JE",
                "./en-CA/_lib/formatLong/index.js": "e4dT",
                "./en-CA/index.js": "wXhn",
                "./en-GB/_lib/formatLong/index.js": "qtDk",
                "./en-GB/index.js": "nwJ3",
                "./en-IN/_lib/formatLong/index.js": "cUEN",
                "./en-IN/index.js": "FRYB",
                "./en-NZ/_lib/formatLong/index.js": "9B3z",
                "./en-NZ/index.js": "RzOD",
                "./en-US/_lib/formatDistance/index.js": "qxEb",
                "./en-US/_lib/formatLong/index.js": "szUW",
                "./en-US/_lib/formatRelative/index.js": "8fa4",
                "./en-US/_lib/localize/index.js": "Siog",
                "./en-US/_lib/match/index.js": "t6IN",
                "./en-US/index.js": "IogR",
                "./en-ZA/_lib/formatLong/index.js": "t2En",
                "./en-ZA/index.js": "BxGH",
                "./eo/_lib/formatDistance/index.js": "b/1v",
                "./eo/_lib/formatLong/index.js": "7MQZ",
                "./eo/_lib/formatRelative/index.js": "ebFE",
                "./eo/_lib/localize/index.js": "XQt2",
                "./eo/_lib/match/index.js": "5UzG",
                "./eo/index.js": "UB7v",
                "./es/_lib/formatDistance/index.js": "GNSh",
                "./es/_lib/formatLong/index.js": "Jg+y",
                "./es/_lib/formatRelative/index.js": "CWIL",
                "./es/_lib/localize/index.js": "seCm",
                "./es/_lib/match/index.js": "V5qT",
                "./es/index.js": "/S0t",
                "./et/_lib/formatDistance/index.js": "2NyG",
                "./et/_lib/formatLong/index.js": "+NT0",
                "./et/_lib/formatRelative/index.js": "ZbG8",
                "./et/_lib/localize/index.js": "XUoo",
                "./et/_lib/match/index.js": "HPOC",
                "./et/index.js": "Br0m",
                "./eu/_lib/formatDistance/index.js": "1mmG",
                "./eu/_lib/formatLong/index.js": "jNk+",
                "./eu/_lib/formatRelative/index.js": "qt8s",
                "./eu/_lib/localize/index.js": "cF4e",
                "./eu/_lib/match/index.js": "3TMN",
                "./eu/index.js": "11Eb",
                "./fa-IR/_lib/formatDistance/index.js": "K5/F",
                "./fa-IR/_lib/formatLong/index.js": "igmP",
                "./fa-IR/_lib/formatRelative/index.js": "ovYP",
                "./fa-IR/_lib/localize/index.js": "G5mO",
                "./fa-IR/_lib/match/index.js": "E04f",
                "./fa-IR/index.js": "gEFy",
                "./fi/_lib/formatDistance/index.js": "qRs0",
                "./fi/_lib/formatLong/index.js": "Hfjm",
                "./fi/_lib/formatRelative/index.js": "A9/m",
                "./fi/_lib/localize/index.js": "noZQ",
                "./fi/_lib/match/index.js": "j9SO",
                "./fi/index.js": "ndVD",
                "./fr-CA/_lib/formatLong/index.js": "dPPI",
                "./fr-CA/index.js": "KTij",
                "./fr-CH/_lib/formatDistance/index.js": "Rwvh",
                "./fr-CH/_lib/formatLong/index.js": "6eKV",
                "./fr-CH/_lib/formatRelative/index.js": "doW0",
                "./fr-CH/_lib/formatters/index.js": "HXlE",
                "./fr-CH/_lib/localize/index.js": "y/Xp",
                "./fr-CH/_lib/match/index.js": "FVFb",
                "./fr-CH/index.js": "yZM9",
                "./fr/_lib/formatDistance/index.js": "9zBo",
                "./fr/_lib/formatLong/index.js": "rqFL",
                "./fr/_lib/formatRelative/index.js": "u9/t",
                "./fr/_lib/formatters/index.js": "viyP",
                "./fr/_lib/localize/index.js": "XQCa",
                "./fr/_lib/match/index.js": "wDUc",
                "./fr/index.js": "LKA2",
                "./gd/_lib/formatDistance/index.js": "4l3Z",
                "./gd/_lib/formatLong/index.js": "kscK",
                "./gd/_lib/formatRelative/index.js": "ZNYn",
                "./gd/_lib/localize/index.js": "IcOb",
                "./gd/_lib/match/index.js": "aahG",
                "./gd/index.js": "Mh5y",
                "./gl/_lib/formatDistance/index.js": "EIwU",
                "./gl/_lib/formatLong/index.js": "6B3v",
                "./gl/_lib/formatRelative/index.js": "c3OS",
                "./gl/_lib/localize/index.js": "72dw",
                "./gl/_lib/match/index.js": "oVBZ",
                "./gl/index.js": "4bge",
                "./gu/_lib/formatDistance/index.js": "GWLP",
                "./gu/_lib/formatLong/index.js": "vkF+",
                "./gu/_lib/formatRelative/index.js": "8dkQ",
                "./gu/_lib/localize/index.js": "+1LZ",
                "./gu/_lib/match/index.js": "fHM3",
                "./gu/index.js": "3t4y",
                "./he/_lib/formatDistance/index.js": "pr88",
                "./he/_lib/formatLong/index.js": "cCh9",
                "./he/_lib/formatRelative/index.js": "Hubt",
                "./he/_lib/localize/index.js": "wKR7",
                "./he/_lib/match/index.js": "K19H",
                "./he/index.js": "75M+",
                "./hi/_lib/formatDistance/index.js": "MFcU",
                "./hi/_lib/formatLong/index.js": "9pab",
                "./hi/_lib/formatRelative/index.js": "WTYQ",
                "./hi/_lib/localize/index.js": "zuDI",
                "./hi/_lib/match/index.js": "EBZM",
                "./hi/index.js": "CUe2",
                "./hr/_lib/formatDistance/index.js": "HOlz",
                "./hr/_lib/formatLong/index.js": "eflq",
                "./hr/_lib/formatRelative/index.js": "otVg",
                "./hr/_lib/localize/index.js": "kqjF",
                "./hr/_lib/match/index.js": "IayM",
                "./hr/index.js": "L9Jq",
                "./hu/_lib/formatDistance/index.js": "ZacL",
                "./hu/_lib/formatLong/index.js": "NffL",
                "./hu/_lib/formatRelative/index.js": "50U5",
                "./hu/_lib/localize/index.js": "xwek",
                "./hu/_lib/match/index.js": "Gh4/",
                "./hu/index.js": "Nm+E",
                "./hy/_lib/formatDistance/index.js": "UnkA",
                "./hy/_lib/formatLong/index.js": "l/cH",
                "./hy/_lib/formatRelative/index.js": "dAMG",
                "./hy/_lib/localize/index.js": "Bo+7",
                "./hy/_lib/match/index.js": "vYLf",
                "./hy/index.js": "netp",
                "./id/_lib/formatDistance/index.js": "WSz3",
                "./id/_lib/formatLong/index.js": "pbaL",
                "./id/_lib/formatRelative/index.js": "y9TF",
                "./id/_lib/localize/index.js": "n5yf",
                "./id/_lib/match/index.js": "bf6i",
                "./id/index.js": "A6C3",
                "./is/_lib/formatDistance/index.js": "h7Q4",
                "./is/_lib/formatLong/index.js": "yIK7",
                "./is/_lib/formatRelative/index.js": "CXdO",
                "./is/_lib/localize/index.js": "YCN6",
                "./is/_lib/match/index.js": "0QQ0",
                "./is/index.js": "N4bE",
                "./it/_lib/formatDistance/index.js": "4Y1u",
                "./it/_lib/formatLong/index.js": "7WKg",
                "./it/_lib/formatRelative/index.js": "VaQz",
                "./it/_lib/localize/index.js": "kUuR",
                "./it/_lib/match/index.js": "tlu+",
                "./it/index.js": "hmb4",
                "./ja/_lib/formatDistance/index.js": "kJUF",
                "./ja/_lib/formatLong/index.js": "jmlk",
                "./ja/_lib/formatRelative/index.js": "xALV",
                "./ja/_lib/localize/index.js": "nYeE",
                "./ja/_lib/match/index.js": "yFey",
                "./ja/index.js": "uAXs",
                "./ka/_lib/formatDistance/index.js": "X1Qi",
                "./ka/_lib/formatLong/index.js": "Lubg",
                "./ka/_lib/formatRelative/index.js": "N0u8",
                "./ka/_lib/localize/index.js": "Ec2b",
                "./ka/_lib/match/index.js": "8cQ2",
                "./ka/index.js": "pwL5",
                "./kk/_lib/formatDistance/index.js": "wMoF",
                "./kk/_lib/formatLong/index.js": "uI5M",
                "./kk/_lib/formatRelative/index.js": "phs0",
                "./kk/_lib/localize/index.js": "3J9E",
                "./kk/_lib/match/index.js": "7nJJ",
                "./kk/index.js": "zGPi",
                "./kn/_lib/formatDistance/index.js": "tVtd",
                "./kn/_lib/formatLong/index.js": "RI9n",
                "./kn/_lib/formatRelative/index.js": "CTZZ",
                "./kn/_lib/localize/index.js": "hHaz",
                "./kn/_lib/match/index.js": "Pgr4",
                "./kn/index.js": "0nlh",
                "./ko/_lib/formatDistance/index.js": "sQmt",
                "./ko/_lib/formatLong/index.js": "kVV9",
                "./ko/_lib/formatRelative/index.js": "MsJH",
                "./ko/_lib/localize/index.js": "2X5S",
                "./ko/_lib/match/index.js": "D/y+",
                "./ko/index.js": "iW8+",
                "./lb/_lib/formatDistance/index.js": "hRnw",
                "./lb/_lib/formatLong/index.js": "tWbx",
                "./lb/_lib/formatRelative/index.js": "Jky/",
                "./lb/_lib/localize/index.js": "1Gj0",
                "./lb/_lib/match/index.js": "JovC",
                "./lb/index.js": "cxWv",
                "./lt/_lib/formatDistance/index.js": "W4RJ",
                "./lt/_lib/formatLong/index.js": "503P",
                "./lt/_lib/formatRelative/index.js": "JQY7",
                "./lt/_lib/localize/index.js": "aU+w",
                "./lt/_lib/match/index.js": "jODQ",
                "./lt/index.js": "xj+b",
                "./lv/_lib/formatDistance/index.js": "m0hv",
                "./lv/_lib/formatLong/index.js": "RbFU",
                "./lv/_lib/formatRelative/index.js": "BCEb",
                "./lv/_lib/localize/index.js": "nPwI",
                "./lv/_lib/match/index.js": "KAEy",
                "./lv/index.js": "x5pY",
                "./mk/_lib/formatDistance/index.js": "4Ky/",
                "./mk/_lib/formatLong/index.js": "iZmK",
                "./mk/_lib/formatRelative/index.js": "3+LC",
                "./mk/_lib/localize/index.js": "bbMd",
                "./mk/_lib/match/index.js": "+Kbo",
                "./mk/index.js": "GzBU",
                "./ms/_lib/formatDistance/index.js": "261L",
                "./ms/_lib/formatLong/index.js": "Mnmc",
                "./ms/_lib/formatRelative/index.js": "UdCE",
                "./ms/_lib/localize/index.js": "kn1/",
                "./ms/_lib/match/index.js": "sTwf",
                "./ms/index.js": "gUWk",
                "./mt/_lib/formatDistance/index.js": "NDSc",
                "./mt/_lib/formatLong/index.js": "yZWy",
                "./mt/_lib/formatRelative/index.js": "uL9e",
                "./mt/_lib/localize/index.js": "qiTB",
                "./mt/_lib/match/index.js": "tc39",
                "./mt/index.js": "6zy0",
                "./nb/_lib/formatDistance/index.js": "1OW6",
                "./nb/_lib/formatLong/index.js": "RYLZ",
                "./nb/_lib/formatRelative/index.js": "mm8q",
                "./nb/_lib/localize/index.js": "nMv5",
                "./nb/_lib/match/index.js": "vQZc",
                "./nb/index.js": "73vv",
                "./nl-BE/_lib/formatDistance/index.js": "6W/4",
                "./nl-BE/_lib/formatLong/index.js": "t4ye",
                "./nl-BE/_lib/formatRelative/index.js": "gCOV",
                "./nl-BE/_lib/localize/index.js": "en81",
                "./nl-BE/_lib/match/index.js": "Z8H1",
                "./nl-BE/index.js": "lUku",
                "./nl/_lib/formatDistance/index.js": "D16g",
                "./nl/_lib/formatLong/index.js": "Tfna",
                "./nl/_lib/formatRelative/index.js": "sLDj",
                "./nl/_lib/localize/index.js": "TV9Q",
                "./nl/_lib/match/index.js": "20b9",
                "./nl/index.js": "hCQt",
                "./nn/_lib/formatDistance/index.js": "ildQ",
                "./nn/_lib/formatLong/index.js": "PnRQ",
                "./nn/_lib/formatRelative/index.js": "Yi/L",
                "./nn/_lib/localize/index.js": "VrHG",
                "./nn/_lib/match/index.js": "VDBj",
                "./nn/index.js": "vORL",
                "./pl/_lib/formatDistance/index.js": "pXM/",
                "./pl/_lib/formatLong/index.js": "mTHB",
                "./pl/_lib/formatRelative/index.js": "LRbD",
                "./pl/_lib/localize/index.js": "p8MS",
                "./pl/_lib/match/index.js": "v8qn",
                "./pl/index.js": "B6yL",
                "./pt-BR/_lib/formatDistance/index.js": "c4nb",
                "./pt-BR/_lib/formatLong/index.js": "9QKF",
                "./pt-BR/_lib/formatRelative/index.js": "ofQ0",
                "./pt-BR/_lib/localize/index.js": "99bE",
                "./pt-BR/_lib/match/index.js": "xWxM",
                "./pt-BR/index.js": "2dYp",
                "./pt/_lib/formatDistance/index.js": "kkjR",
                "./pt/_lib/formatLong/index.js": "9aPq",
                "./pt/_lib/formatRelative/index.js": "x+oN",
                "./pt/_lib/localize/index.js": "qumc",
                "./pt/_lib/match/index.js": "zMeq",
                "./pt/index.js": "gdks",
                "./ro/_lib/formatDistance/index.js": "LyXU",
                "./ro/_lib/formatLong/index.js": "6XhT",
                "./ro/_lib/formatRelative/index.js": "aItZ",
                "./ro/_lib/localize/index.js": "TvXE",
                "./ro/_lib/match/index.js": "+OZh",
                "./ro/index.js": "r2yp",
                "./ru/_lib/formatDistance/index.js": "mscr",
                "./ru/_lib/formatLong/index.js": "Q7oV",
                "./ru/_lib/formatRelative/index.js": "hmfN",
                "./ru/_lib/localize/index.js": "rueu",
                "./ru/_lib/match/index.js": "6ZU5",
                "./ru/index.js": "nz/o",
                "./sk/_lib/formatDistance/index.js": "xVEc",
                "./sk/_lib/formatLong/index.js": "ypqe",
                "./sk/_lib/formatRelative/index.js": "DD+b",
                "./sk/_lib/localize/index.js": "58G8",
                "./sk/_lib/match/index.js": "LCFD",
                "./sk/index.js": "Wqan",
                "./sl/_lib/formatDistance/index.js": "EcoP",
                "./sl/_lib/formatLong/index.js": "6N3H",
                "./sl/_lib/formatRelative/index.js": "wB8V",
                "./sl/_lib/localize/index.js": "T/oY",
                "./sl/_lib/match/index.js": "tibx",
                "./sl/index.js": "KYSo",
                "./sr-Latn/_lib/formatDistance/index.js": "ohiq",
                "./sr-Latn/_lib/formatLong/index.js": "9XZl",
                "./sr-Latn/_lib/formatRelative/index.js": "SHHn",
                "./sr-Latn/_lib/localize/index.js": "lV88",
                "./sr-Latn/_lib/match/index.js": "XKqi",
                "./sr-Latn/index.js": "O2Rb",
                "./sr/_lib/formatDistance/index.js": "7e+M",
                "./sr/_lib/formatLong/index.js": "rL8U",
                "./sr/_lib/formatRelative/index.js": "g+sm",
                "./sr/_lib/localize/index.js": "iBMZ",
                "./sr/_lib/match/index.js": "6cI6",
                "./sr/index.js": "7mU3",
                "./sv/_lib/formatDistance/index.js": "uBiS",
                "./sv/_lib/formatLong/index.js": "xPA0",
                "./sv/_lib/formatRelative/index.js": "g2dR",
                "./sv/_lib/localize/index.js": "c8gk",
                "./sv/_lib/match/index.js": "FZPo",
                "./sv/index.js": "hxgj",
                "./ta/_lib/formatDistance/index.js": "3+hJ",
                "./ta/_lib/formatLong/index.js": "6oUG",
                "./ta/_lib/formatRelative/index.js": "Fj/E",
                "./ta/_lib/localize/index.js": "wqQC",
                "./ta/_lib/match/index.js": "Znkj",
                "./ta/index.js": "1ssA",
                "./te/_lib/formatDistance/index.js": "FGw1",
                "./te/_lib/formatLong/index.js": "T135",
                "./te/_lib/formatRelative/index.js": "uPKI",
                "./te/_lib/localize/index.js": "vYQK",
                "./te/_lib/match/index.js": "NJ1g",
                "./te/index.js": "SGoj",
                "./th/_lib/formatDistance/index.js": "LY2f",
                "./th/_lib/formatLong/index.js": "8kpn",
                "./th/_lib/formatRelative/index.js": "UGeg",
                "./th/_lib/localize/index.js": "lJYv",
                "./th/_lib/match/index.js": "F67P",
                "./th/index.js": "Pk+z",
                "./tr/_lib/formatDistance/index.js": "92ey",
                "./tr/_lib/formatLong/index.js": "t+kV",
                "./tr/_lib/formatRelative/index.js": "dZIH",
                "./tr/_lib/localize/index.js": "nkax",
                "./tr/_lib/match/index.js": "gcB3",
                "./tr/index.js": "3ZWG",
                "./ug/_lib/formatDistance/index.js": "QfpD",
                "./ug/_lib/formatLong/index.js": "ZKWv",
                "./ug/_lib/formatRelative/index.js": "TsbI",
                "./ug/_lib/localize/index.js": "mp/g",
                "./ug/_lib/match/index.js": "XKCu",
                "./ug/index.js": "yT3n",
                "./uk/_lib/formatDistance/index.js": "atPq",
                "./uk/_lib/formatLong/index.js": "GhUO",
                "./uk/_lib/formatRelative/index.js": "jQGN",
                "./uk/_lib/localize/index.js": "+GzN",
                "./uk/_lib/match/index.js": "iQRE",
                "./uk/index.js": "LCGg",
                "./uz/_lib/formatDistance/index.js": "nl+O",
                "./uz/_lib/formatLong/index.js": "S0u8",
                "./uz/_lib/formatRelative/index.js": "y4ds",
                "./uz/_lib/localize/index.js": "HHV9",
                "./uz/_lib/match/index.js": "BUPi",
                "./uz/index.js": "CXIP",
                "./vi/_lib/formatDistance/index.js": "x6Fu",
                "./vi/_lib/formatLong/index.js": "m0m2",
                "./vi/_lib/formatRelative/index.js": "/qvb",
                "./vi/_lib/localize/index.js": "I4E4",
                "./vi/_lib/match/index.js": "OtH/",
                "./vi/index.js": "dGQT",
                "./zh-CN/_lib/formatDistance/index.js": "eGy/",
                "./zh-CN/_lib/formatLong/index.js": "FprD",
                "./zh-CN/_lib/formatRelative/index.js": "vODD",
                "./zh-CN/_lib/localize/index.js": "vPtV",
                "./zh-CN/_lib/match/index.js": "eKnR",
                "./zh-CN/index.js": "UJqf",
                "./zh-TW/_lib/formatDistance/index.js": "yeC0",
                "./zh-TW/_lib/formatLong/index.js": "Q2VH",
                "./zh-TW/_lib/formatRelative/index.js": "Qb8w",
                "./zh-TW/_lib/localize/index.js": "I9DF",
                "./zh-TW/_lib/match/index.js": "WlfW",
                "./zh-TW/index.js": "zn9v"
            };

            function i(n) {
                var t = o(n);
                return l(t)
            }

            function o(n) {
                if (!l.o(e, n)) {
                    var t = new Error("Cannot find module '" + n + "'");
                    throw t.code = "MODULE_NOT_FOUND", t
                }
                return e[n]
            }
            i.keys = function() {
                return Object.keys(e)
            }, i.resolve = o, n.exports = i, i.id = "nw0P"
        },
        oEwP: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return r
            }));
            var e = l("CcnG"),
                i = (l("7oEI"), l("pugT")),
                o = l("0/uQ"),
                r = function() {
                    function n(n, t) {
                        this.cd = n, this.modalService = t, this.switchPrinter = new e.q, this.switchUnitPrinter = new e.q, this.widthSelect = 165, this.heightSelect = 55, this.loadMoreUnits = !0, this.loadUnit = !0, this.anyUnitSelected = !1, this.subscription = new i.a
                    }
                    return n.prototype.ngOnInit = function() {
                        this.loadMoreUnitsPrinters(!0), this.loadSystemController(!0)
                    }, n.prototype.loadMoreUnitsPrinters = function(n) {
                        var t = this;
                        this.loadMoreUnits = !0, setTimeout((function() {
                            t.subscription.add(t.discoverController.subscribe((function(l) {
                                var e = Object(o.a)(l.getNearUnits(n));
                                t.subscription.add(e.subscribe((function(n) {
                                    t.moreUnitsPrinter = n, t.loadMoreUnits = !1, t.cd.detectChanges()
                                })))
                            })))
                        }), 300)
                    }, n.prototype.loadSystemController = function(n) {
                        var t = this;
                        this.loadUnit = !0, setTimeout((function() {
                            t.subscription.add(t.systemController.subscribe((function(l) {
                                var e = Object(o.a)(l.getSystemInfo(n));
                                t.subscription.add(e.subscribe((function(n) {
                                    t.localHostInfo = n, t.loadUnit = !1, t.selectedUnitPrinter = t.getUnitSelected(), t.cd.detectChanges()
                                })))
                            })))
                        }), 300)
                    }, n.prototype.selecthUnitPrinter = function(n) {
                        this.switchUnitPrinter.emit(n)
                    }, n.prototype.switchSelectPrinter = function(n) {
                        this.switchPrinter.emit(n)
                    }, n.prototype.closePrinters = function() {
                        this.modalService.close("base-information"), this.ngOnDestroy()
                    }, n.prototype.getUnitSelected = function() {
                        var n = this;
                        return this.moreUnitsPrinter.filter((function(t) {
                            return t.getLanUnitInfo().unitId === n.entityId
                        }))[0] ? this.moreUnitsPrinter.filter((function(t) {
                            return t.getLanUnitInfo().unitId === n.entityId
                        }))[0] : null
                    }, n.prototype.reload = function() {
                        this.loadMoreUnitsPrinters(!0)
                    }, n.prototype.ngOnDestroy = function() {
                        this.subscription.unsubscribe()
                    }, n
                }()
        },
        ojct: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return i
            }));
            var e = l("K9Ia"),
                i = function() {
                    function n() {
                        this.toggleModal = new e.a, this.lifoModals = [], this.modals = {}
                    }
                    return n.prototype.register = function(n, t, l) {
                        if (this.modals[n]) throw new Error("Modal with id " + n + " is registered yet");
                        this.modals[n] = {
                            viewContainerRef: t,
                            destroyable: l,
                            initialized: !1
                        }
                    }, n.prototype.unregister = function(n) {
                        this.modals[n] && delete this.modals[n]
                    }, n.prototype.get = function(n) {
                        return this.modals[n]
                    }, n.prototype.open = function(n) {
                        this.lifoModals.unshift(n), this.toggleModal.next({
                            id: n,
                            open: !0
                        })
                    }, n.prototype.close = function(n) {
                        this.lifoModals = this.lifoModals.filter((function(t) {
                            return t !== n
                        })), this.toggleModal.next({
                            id: n,
                            open: !1
                        })
                    }, n.prototype.closeLastOpened = function() {
                        var n = this.lifoModals[0];
                        n && this.close(n)
                    }, n.prototype.postSave = function(n) {
                        var t = this.get(n);
                        t.destroyable && t.currentModalRef && t.currentModalRef.destroy()
                    }, n.prototype.postClose = function(n, t) {
                        var l = this.get(n);
                        l.destroyable && l.currentModalRef && l.currentModalRef.destroy(), l.afterClosed && (l.afterClosed.next(t), l.afterClosed.complete())
                    }, n
                }()
        },
        qGUr: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return i
            }));
            var e = l("CcnG"),
                i = (l("sylN"), function() {
                    function n(n) {
                        this.betslipService = n, this.qrEvent = new e.q, this.disableButton = !0
                    }
                    return n.prototype.ngOnInit = function() {
                        this.scannedData && (this.disableButton = !1)
                    }, n.prototype.setDisableButton = function(n) {
                        n.valid ? this.disableButton = !1 : this.disableButton = !0
                    }, n.prototype.submit = function(n) {
                        n.valid && (this.configuration.isMaxPayout || this.betslipService.setTicketExtData(JSON.stringify(n.value)), document.dispatchEvent(new CustomEvent("actionDataDialog", {
                            detail: {
                                formResult: JSON.stringify(n.value)
                            }
                        })))
                    }, n.prototype.onClick = function() {
                        this.qrEvent.emit(!0)
                    }, n
                }())
        },
        qIYQ: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return y
            }));
            var e = l("CcnG"),
                i = l("5EE+"),
                o = l("Ip0R"),
                r = l("jMZ0"),
                u = l("7oEI"),
                s = [
                    [".numeric-keypad[_ngcontent-%COMP%]{width:510px;height:662px;padding:60px 100px;font-weight:700}.numeric-keypad__label[_ngcontent-%COMP%]{font-size:20px;text-transform:capitalize}.numeric-keypad__buttons[_ngcontent-%COMP%]{margin:27px 0 0}.numeric-keypad__buttons[_ngcontent-%COMP%] > .col[_ngcontent-%COMP%]{padding:4px 12px}.numeric-keypad__button[_ngcontent-%COMP%]{display:flex;height:100%;justify-content:center;align-items:center;padding:18px;margin:-8px;font-size:32px;cursor:pointer}.numeric-keypad__button--danger[_ngcontent-%COMP%]{font-size:22px}.numeric-keypad__close[_ngcontent-%COMP%]{position:absolute;top:27px;right:30px;font-size:24px;cursor:pointer}.numeric-keypad__close[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{font-size:24px}.numeric-keypad-input[_ngcontent-%COMP%]{position:relative;min-height:32px;padding-bottom:6px;margin-top:16px;font-size:22px}.numeric-keypad-input__password[_ngcontent-%COMP%]{display:inline-block;width:20px;height:20px;margin-right:10px;border-radius:100%}.numeric-keypad-input__password[_ngcontent-%COMP%]:last-child{margin-right:0}.numeric-keypad-input__clear[_ngcontent-%COMP%]{position:absolute;right:0;padding:5px;font-size:18px;cursor:pointer}.numeric-keypad-input__error[_ngcontent-%COMP%]{height:16px;margin-top:10px}"]
                ],
                c = e.Gb({
                    encapsulation: 0,
                    styles: s,
                    data: {}
                });

            function a(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "div", [
                    ["class", "numeric-keypad__close"]
                ], null, null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 0, "span", [
                    ["class", "icon icon-cancel"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.closeKeypad() && e);
                    return e
                }), null, null))], null, null)
            }

            function d(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "div", [
                    ["class", "numeric-keypad__label"]
                ], null, null, null, null, null)), (n()(), e.cc(1, null, ["", ""]))], null, (function(n, t) {
                    n(t, 1, 0, t.component.title)
                }))
            }

            function p(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "span", [
                    ["class", "numeric-keypad-input__placeholder"]
                ], null, null, null, null, null)), (n()(), e.cc(1, null, ["", ""]))], null, (function(n, t) {
                    n(t, 1, 0, t.component.placeholder)
                }))
            }

            function b(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 3, "span", [], null, null, null, null, null)), (n()(), e.cc(1, null, ["", ""])), e.Xb(2, {
                    showSymbol: 0,
                    noZeros: 1
                }), e.Wb(131072, i.b, [i.k, e.i])], null, (function(n, t) {
                    var l = t.component,
                        i = e.dc(t, 1, 0, e.Ub(t, 3).transform(l.content, n(t, 2, 0, !0, !0)));
                    n(t, 1, 0, i)
                }))
            }

            function h(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 0, "span", [
                    ["class", "numeric-keypad-input__password"]
                ], null, null, null, null, null))], null, null)
            }

            function g(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 2, null, null, null, null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, h)), e.Hb(2, 278528, null, 0, o.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), (n()(), e.xb(0, null, null, 0))], (function(n, t) {
                    n(t, 2, 0, t.component.content)
                }), null)
            }

            function f(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 2, "div", [
                    ["class", "col"]
                ], null, null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 1, "div", [
                    ["class", "numeric-keypad__button"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.insert(n.context.$implicit) && e);
                    return e
                }), null, null)), (n()(), e.cc(2, null, ["", ""]))], null, (function(n, t) {
                    n(t, 2, 0, t.context.$implicit)
                }))
            }

            function m(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 7, null, null, null, null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 3, "div", [
                    ["class", "col"]
                ], null, null, null, null, null)), (n()(), e.Ib(2, 0, null, null, 2, "div", [
                    ["class", "numeric-keypad__button numeric-keypad__button--danger"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.clear() && e);
                    return e
                }), null, null)), (n()(), e.cc(3, null, ["", ""])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(5, 0, null, null, 2, "div", [
                    ["class", "col"]
                ], null, null, null, null, null)), (n()(), e.Ib(6, 0, null, null, 1, "div", [
                    ["class", "numeric-keypad__button"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.insert("0") && e);
                    return e
                }), null, null)), (n()(), e.cc(-1, null, ["0"]))], null, (function(n, t) {
                    n(t, 3, 0, e.dc(t, 3, 0, e.Ub(t, 4).transform("ch_clear")))
                }))
            }

            function _(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 11, null, null, null, null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 3, "div", [
                    ["class", "col col-4"]
                ], null, null, null, null, null)), (n()(), e.Ib(2, 0, null, null, 2, "div", [
                    ["class", "numeric-keypad__button"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.dot() && e);
                    return e
                }), null, null)), (n()(), e.cc(3, null, ["", ""])), e.Wb(131072, i.j, [i.k, e.i]), (n()(), e.Ib(5, 0, null, null, 2, "div", [
                    ["class", "col col-8"]
                ], null, null, null, null, null)), (n()(), e.Ib(6, 0, null, null, 1, "div", [
                    ["class", "numeric-keypad__button"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.insert("0") && e);
                    return e
                }), null, null)), (n()(), e.cc(-1, null, ["0"])), (n()(), e.Ib(8, 0, null, null, 3, "div", [
                    ["class", "col col-4"]
                ], null, null, null, null, null)), (n()(), e.Ib(9, 0, null, null, 2, "div", [
                    ["class", "numeric-keypad__button numeric-keypad__button--danger"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.clear() && e);
                    return e
                }), null, null)), (n()(), e.cc(10, null, ["", ""])), e.Wb(131072, i.j, [i.k, e.i])], null, (function(n, t) {
                    n(t, 3, 0, e.dc(t, 3, 0, e.Ub(t, 4).transform("locale.DECIMAL_SEPARATOR"))), n(t, 10, 0, e.dc(t, 10, 0, e.Ub(t, 11).transform("ch_clear")))
                }))
            }

            function v(n) {
                return e.ec(2, [(n()(), e.Ib(0, 0, null, null, 27, "div", [
                    ["class", "grid grid-column numeric-keypad"]
                ], null, null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, a)), e.Hb(2, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.xb(16777216, null, null, 1, null, d)), e.Hb(4, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.Ib(5, 0, null, null, 6, "div", [
                    ["class", "numeric-keypad-input"]
                ], [
                    [2, "numeric-keypad-input--error", null]
                ], null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, p)), e.Hb(7, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.xb(16777216, null, null, 1, null, b)), e.Hb(9, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.xb(16777216, null, null, 1, null, g)), e.Hb(11, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.Ib(12, 0, null, null, 1, "div", [
                    ["class", "numeric-keypad-input__error"]
                ], null, null, null, null, null)), (n()(), e.cc(13, null, ["", ""])), (n()(), e.Ib(14, 0, null, null, 13, "div", [
                    ["class", "col grid grid-3 numeric-keypad__buttons"]
                ], null, null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, f)), e.Hb(16, 278528, null, 0, o.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), (n()(), e.xb(16777216, null, null, 1, null, m)), e.Hb(18, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.xb(16777216, null, null, 1, null, _)), e.Hb(20, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.Ib(21, 0, null, null, 6, "div", [
                    ["class", "col"]
                ], null, null, null, null, null)), e.Zb(512, null, o.x, o.y, [e.A, e.B, e.o, e.P]), e.Hb(23, 278528, null, 0, o.k, [o.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), e.Xb(24, {
                    "col-8": 0
                }), (n()(), e.Ib(25, 0, null, null, 2, "div", [
                    ["class", "numeric-keypad__button numeric-keypad__button--success"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.ok() && e);
                    return e
                }), null, null)), (n()(), e.cc(26, null, ["", ""])), e.Wb(131072, i.j, [i.k, e.i])], (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, !l.isPassword), n(t, 4, 0, l.title), n(t, 7, 0, !l.content || 0 === l.content.length), n(t, 9, 0, !l.isPassword && l.content.length > 0), n(t, 11, 0, l.isPassword && l.content.length > 0), n(t, 16, 0, l.numbers), n(t, 18, 0, l.isPassword || 0 === l.decimalsLength), n(t, 20, 0, l.isNumber && 0 !== l.decimalsLength);
                    var e = n(t, 24, 0, l.isNumber && 0 !== l.decimalsLength);
                    n(t, 23, 0, "col", e)
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 5, 0, l.error), n(t, 13, 0, l.error), n(t, 26, 0, e.dc(t, 26, 0, e.Ub(t, 27).transform("ch_ok")))
                }))
            }
            var y = e.Eb("grc-numeric-keypad", r.b, (function(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "grc-numeric-keypad", [], null, [
                    ["document", "keydown"],
                    ["document", "keydown.backspace"],
                    ["document", "keydown.enter"]
                ], (function(n, t, l) {
                    var i = !0;
                    "document:keydown" === t && (i = !1 !== e.Ub(n, 1).onKeyDown(l.key, l.keyCode) && i);
                    "document:keydown.backspace" === t && (i = !1 !== e.Ub(n, 1).onBackspace() && i);
                    "document:keydown.enter" === t && (i = !1 !== e.Ub(n, 1).onEnter() && i);
                    return i
                }), v, c)), e.Hb(1, 114688, null, 0, r.b, [e.i, u.a, i.k], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                title: "title",
                placeholder: "placeholder",
                type: "type",
                error: "error",
                emptyError: "emptyError"
            }, {
                success: "success"
            }, [])
        },
        qQYQ: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return e
            }));
            var e = function() {
                function n() {}
                return n.prototype.ngOnInit = function() {}, n
            }()
        },
        rdml: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return e
            }));
            var e = function() {
                function n() {}
                return n.prototype.ngOnInit = function() {}, n
            }()
        },
        sB3t: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return i
            }));
            var e = l("6blF");

            function i(n) {
                return new e.a((function(t) {
                    var l = n.add((function(n) {
                        return t.next(n)
                    }));
                    return function() {
                        return n.remove(l)
                    }
                }))
            }
        },
        sJrH: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return o
            }));
            var e = l("hg3l"),
                i = l("ssOW"),
                o = function() {
                    function n() {}
                    return n.forRoot = function(t) {
                        return void 0 === t && (t = ""), {
                            ngModule: n,
                            providers: [{
                                provide: i.a,
                                useValue: t
                            }, e.a]
                        }
                    }, n.forChild = function(t) {
                        return void 0 === t && (t = ""), {
                            ngModule: n,
                            providers: [{
                                provide: i.a,
                                useValue: t
                            }, e.a]
                        }
                    }, n
                }()
        },
        ssOW: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return e
            }));
            var e = new(l("CcnG").x)("ThemeUrl")
        },
        sylN: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return L
            }));
            var e = l("CrY/"),
                i = l("n3kJ"),
                o = l("K9Ia"),
                r = l("26FU"),
                u = l("pugT"),
                s = l("F/XL"),
                c = l("XlPw"),
                a = l("0/uQ"),
                d = l("G5J1"),
                p = l("6blF"),
                b = l("xMyE"),
                h = l("15JJ"),
                g = l("p0Sj"),
                f = l("VQ2P"),
                m = l("t9fZ"),
                _ = l("aGNc"),
                v = l("psW0"),
                y = l("9Z1F"),
                C = l("67Y/"),
                k = l("S1nX"),
                x = l("VnD/"),
                I = l("bma8"),
                S = l("/6R9"),
                w = l("7oEI"),
                O = l("GNnp"),
                P = l("AZLQ"),
                M = l("ijKR"),
                T = l("sB3t"),
                j = l("t01L"),
                E = l("nYwI"),
                U = l("Qkcr"),
                A = l("CcnG"),
                B = l("5EE+"),
                H = l("ZYCi"),
                D = function() {
                    for (var n = 0, t = 0, l = arguments.length; t < l; t++) n += arguments[t].length;
                    var e = Array(n),
                        i = 0;
                    for (t = 0; t < l; t++)
                        for (var o = arguments[t], r = 0, u = o.length; r < u; r++, i++) e[i] = o[r];
                    return e
                },
                L = function() {
                    function n(n, t, l, e, i, u, s) {
                        this.modalService = n, this.ticketModalService = t, this.notificationsService = l, this.coreService = e, this.i18NService = i, this.shopAdminService = u, this.router = s, this.onRebet = new o.a, this.onTicketBetAdded = new o.a, this.onTicketBetRemoved = new o.a, this.onTicketBetUpdated = new o.a, this.onStake = new o.a, this.onClear = new o.a, this.onTabChange = new o.a, this.onBetModeChange = new o.a, this.onFastbetEnableChange = new o.a, this.onFastbetParserChange = new o.a, this.onToggleFullScreen = new o.a, this.onSendTicket = new o.a, this.processing = new o.a, this.addBet = new o.a, this.onBet = new o.a, this.onChangedStake = new o.a, this.onBetErrors = new o.a, this.onConfiguration = new r.a(E.a), this.onTicketErrorSent = new r.a(!1), this.maxMultiplier = 0, this.stake = 0, this.isModalOpen = !1, this.isScanBarcode = !1, this.configuration = E.a, this.multiplier = 1, this.isPrintTicketFromAlphaNumericKeypad = !1, this.rebets = []
                    }
                    return n.prototype.init = function() {
                        this.subscriptions = new u.a, this.subscribeShortcuts(), this.subscribeToScanBarCode()
                    }, n.prototype.destroy = function() {
                        this.subscriptions.unsubscribe()
                    }, n.prototype.setConfiguration = function(n) {
                        void 0 === n && (n = E.a), n.betMode && this.setBetMode(n.betMode), this.configuration = Object.assign({}, E.a, n), this.onConfiguration.next(this.configuration)
                    }, n.prototype.updateConfiguration = function(n) {
                        this.setConfiguration(Object.assign({}, this.configuration, n))
                    }, n.prototype.hasLastTicket = function() {
                        return !!this.coreService.getPrintTicketController().getLastTicket()
                    }, n.prototype.getLastTicket = function() {
                        return this.coreService.getPrintTicketController().getLastTicket()
                    }, n.prototype.openShortcutsHelp = function() {
                        var n = this;
                        this.modalService.open("base-help", P.a, {
                            outputs: {
                                close: function() {
                                    n.modalService.close("base-help")
                                }
                            }
                        })
                    }, n.prototype.hasFastbetHelp = function() {
                        return !(this.coreService.disableFastBet() || !this.configuration.fastbetHelp)
                    }, n.prototype.openFastbetHelp = function() {
                        this.hasFastbetHelp() && !this.coreService.disableFastBet() && this.configuration.fastbetHelp()
                    }, n.prototype.enableFastbet = function(n) {
                        this.onFastbetEnableChange.next(n)
                    }, n.prototype.isEmpty = function() {
                        return this.getBetslip().isEmpty()
                    }, n.prototype.addBets = function(n, t, l) {
                        var i;
                        void 0 === n && (n = []), void 0 === t && (t = !1), void 0 === l && (l = e.DuplicateTicketBetBehaviour.THORW_EXCEPTION);
                        var o = !0,
                            r = [],
                            u = this.coreService.getCashierProfileSettings().duplicateTips;
                        n.filter((function(n) {
                            return n.odd._clData.isEnabledToBet()
                        })).length < n.length && (o = !1);
                        for (var s = 0, c = n; s < c.length; s++) {
                            var a = c[s],
                                d = {
                                    eventBlock: a.eventBlock,
                                    event: a.event,
                                    oddId: a.odd.id,
                                    oddValue: a.odd.value,
                                    betParam: a.betParam,
                                    stake: a.stake || 0,
                                    defaultMaxOdd: null === (i = a.odd._clData) || void 0 === i ? void 0 : i.defaultMaxOdd
                                };
                            r.push(d)
                        }
                        try {
                            if (u && (l = e.DuplicateTicketBetBehaviour.INSERT_DUPLICATE), this.configuration.hasMultiplier) {
                                var p = this.getBetslip().addMultiplier(r, this.multiplier, l, this.coreService.getWalletManager().getCurrentWallet().calculation.taxManager);
                                if (this.getBetMode() === e.BetModeEnum.SINGLEBETMODE) {
                                    var b = p.getTicketBetErrors();
                                    this.onBetErrors.next({
                                        errors: b
                                    })
                                }
                            } else if (t) this.fastbetHandler(r);
                            else {
                                p = this.getBetslip().addBetByOddId(r, this.coreService.getWalletManager().getCurrentWallet().calculation.taxManager, l);
                                if (this.getBetMode() === e.BetModeEnum.SINGLEBETMODE) {
                                    b = p.getTicketBetErrors();
                                    this.onBetErrors.next({
                                        errors: b
                                    })
                                }
                            }
                            this.setFastbetMaxCombiGroup(), this.onStake.next(), this.onTicketBetAdded.next(r)
                        } catch (h) {
                            this.addBet.next(!1), this.errorHandler(h, n)
                        }
                        return this.addBet.next(!0), o
                    }, n.prototype.errorHandler = function(n, t) {
                        var l = this;
                        if (n && n.message) switch (n.message) {
                            case e.coreUtils.TicketErrorCodEnum.MAX_ODD_VALIDATION_TICKET:
                                this.modalService.openDialog("base", {
                                    type: "danger",
                                    icon: "icon icon-warning",
                                    iconColor: "#d43548",
                                    text: "" + this.i18NService.get("betslip_invalid_max_odd", {
                                        defaultMaxOdd: n.param.defaultMaxOdd
                                    }),
                                    buttons: [{
                                        type: "danger",
                                        text: "" + this.i18NService.get("ch_dismiss"),
                                        action: function() {
                                            l.modalService.close("base")
                                        }
                                    }]
                                });
                                break;
                            case e.coreUtils.TicketErrorCodEnum.ODD_VALIDATION_TICKET:
                                this.modalService.openDialog("base", {
                                    type: "danger",
                                    icon: "icon icon-warning",
                                    iconColor: "#d43548",
                                    text: this.i18NService.get("ch_invalid_selection", {
                                        oddValue: this.i18NService.location.getCredit(t[0].odd._clData.taxManager.getMinValidOdd(), {
                                            showSymbol: !1,
                                            noZeros: !0
                                        })
                                    }) + "\n" + this.i18NService.get("ch_change_selection"),
                                    buttons: [{
                                        type: "danger",
                                        text: "" + this.i18NService.get("ch_dismiss"),
                                        action: function() {
                                            l.modalService.close("base")
                                        }
                                    }]
                                });
                                break;
                            case e.coreUtils.TicketErrorCodEnum.LIMIT_SELECTIONS_REACHED:
                                var i = this.coreService.getTicketController().getTicketControllerConfig().maxSelections,
                                    o = void 0 === i ? {} : i,
                                    r = o.byGame,
                                    u = void 0 === r ? {} : r,
                                    s = o.defaultMaxSelections,
                                    c = void 0 === s ? 0 : s,
                                    a = u[Object.keys(u).find((function(n) {
                                        return n.toLowerCase() === t[0].playlist.gameType.val.toLowerCase()
                                    }))],
                                    d = a || c;
                                this.notificationsService.warning("" + this.i18NService.get("ch_limit_selections", {
                                    limit: d
                                }));
                                break;
                            case e.coreUtils.TicketErrorCodEnum.ADDBET_BETALREADYSELECTED:
                                this.notificationsService.warning("" + this.i18NService.get("ch_duplicate_bet"))
                        }
                    }, n.prototype.setMultiplier = function(n) {
                        this.multiplier = n
                    }, n.prototype.setMaxMultiplier = function(n) {
                        this.maxMultiplier = n
                    }, n.prototype.getMaxMultiplier = function() {
                        return this.maxMultiplier
                    }, n.prototype.hasBet = function(n, t, l) {
                        return this.getBetslipInfo().events.some((function(e) {
                            return e.playlistId === n && e.eventId === t && e.bets.some((function(n) {
                                return n.oddId === l
                            }))
                        }))
                    }, n.prototype.removeBet = function(n, t, l, e) {
                        var i = {
                            playlistId: n,
                            eventId: t,
                            oddId: l,
                            betParam: e
                        };
                        this.getBetslip().removeBetByOdd([i]), this.onTicketBetRemoved.next(i)
                    }, n.prototype.countBets = function() {
                        return this.getBetslipInfo().events.map((function(n) {
                            return n.bets.length
                        })).reduce((function(n, t) {
                            return n + t
                        }), 0)
                    }, n.prototype.getBetslipInfo = function() {
                        return this.getBetslip().getInfo()
                    }, n.prototype.hasOdd = function(n, t) {
                        return this.getBetslipInfo().events.some((function(l) {
                            return l.eventId === n.eventId && l.playlistId === n._clData.playlist.id && l.bets.some((function(n) {
                                return n.oddId === t.id
                            }))
                        }))
                    }, n.prototype.getChips = function() {
                        var n = this;
                        return this.coreService.getSessionController().sessionSettings.localizationContext.currencies.find((function(t) {
                            return t.key === n.coreService.getWalletManager().getCurrentWallet().currency.code
                        })).value
                    }, n.prototype.setStake = function(n) {
                        this.stake = n
                    }, n.prototype.getStake = function() {
                        return this.stake
                    }, n.prototype.setSingleStake = function(n, t) {
                        void 0 === t && (t = !0), this.configuration.preStake && this.configuration.preStake(), this.getBetslip().isEmpty() || (this.getBetslip().setSingleStake(n, t), this.onStake.next())
                    }, n.prototype.setStakeForSingleBet = function(n, t, l, e, i) {
                        void 0 === i && (i = !1);
                        var o = this.getBetslip().setSingleStakeByOddId([{
                            playlistId: e,
                            eventId: l,
                            oddId: n.oddId,
                            betParam: n.betParam,
                            stake: t
                        }], i).getTicketBetErrors();
                        return this.onStake.next(), o
                    }, n.prototype.setSingleStakeByBets = function(n, t) {
                        var l = this;
                        (void 0 === t && (t = !1), this.configuration.preStake && this.configuration.preStake(), this.getBetslip().isEmpty()) || this.getBetslipInfo().events.filter((function(t) {
                            return t.bets.some((function(t) {
                                return t.stake !== n
                            }))
                        })).map((function(t) {
                            return D([t], t.bets.filter((function(t) {
                                return t.stake !== n
                            })))
                        })).map((function(e) {
                            var i = e[0];
                            return e.slice(1).map((function(e) {
                                l.getBetslip().setSingleStakeByOddId([{
                                    playlistId: i.playlistId,
                                    eventId: i.eventId,
                                    oddId: e.oddId,
                                    betParam: e.betParam,
                                    stake: n
                                }], t), l.onStake.next()
                            }))
                        }))
                    }, n.prototype.setSingleStakeByOddId = function(n, t) {
                        void 0 === t && (t = !1), this.configuration.preStake && this.configuration.preStake(), this.getBetslip().setSingleStakeByOddId(n, t), this.onStake.next()
                    }, n.prototype.setBetMode = function(n) {
                        this.getBetslip().changeBetMode(n, !1), this.setFastbetMaxCombiGroup(), this.onTabChange.next()
                    }, n.prototype.getBetMode = function() {
                        return this.getBetslip().getBetMode()
                    }, n.prototype.clear = function() {
                        this.getBetslip().clean(), this.onClear.next(), this.closeModalWindow()
                    }, n.prototype.getTotalStakeItemized = function() {
                        var n = this.getBetslip();
                        if (!n.isEmpty()) return n.getTotalStakeItemized()
                    }, n.prototype.getTotalMaxWinningItemized = function() {
                        var n = this.getBetslip();
                        if (!n.isEmpty()) return n.getTotalMaxWinningItemized()
                    }, n.prototype.setCombiStake = function(n) {
                        this.getBetMode() === e.BetModeEnum.SYSTEMBETMODE && (this.getBetslip().setCombiStake(n, !0), this.resolveTicketMaxWinningsReached(), this.onStake.next())
                    }, n.prototype.setTicketExtData = function(n) {
                        this.getBetslip().setTicketExtData(n)
                    }, n.prototype.sendTicket = function(n) {
                        var t = this;
                        return this.showLocalUsersModal().pipe(Object(b.a)((function() {
                            t.processing.next(!0)
                        })), Object(h.a)((function(l) {
                            return t.getBetMode() === e.BetModeEnum.SINGLEBETMODE ? (t.getBetslip().linkMaxWinningToMaxPayout() || t.setSingleStake(n, !0), Object(s.a)(l)) : t.getBetslipInfo().systemBets.some((function(n) {
                                return 0 !== n.stake
                            })) ? Object(s.a)(l) : (t.setCombiStake([{
                                stake: n,
                                combiGroup: D(t.getBetslipInfo().systemBets).reverse().find((function(n) {
                                    return !n._clData.maxCombicountError.isError
                                })).grouping
                            }]), t.onStake.pipe(Object(g.a)(void 0), Object(f.a)((function() {
                                return t.coreService.getBetSlip().getSystemBetErrors().length > 0
                            })), Object(m.a)(1), Object(_.a)(l)))
                        })), Object(h.a)((function(n) {
                            var l = null;
                            return t.checkTicketPolicyError() && (t.processing.next(!1), l = t.modalService.openDataDialog("base", {
                                type: "danger",
                                icon: "icon icon-warning",
                                iconColor: "#000000",
                                isMaxPayout: !1
                            })), (null == l ? void 0 : l.afterClosed) ? l.afterClosed.pipe(Object(b.a)((function(n) {
                                t.modalService.dataDialogOpened = !1
                            }))) : Object(s.a)(null)
                        })), Object(h.a)((function(n) {
                            if (n) {
                                if (n.detail) return n.detail.formResult ? (t.processing.next(!0), Object(s.a)("sendTicket")) : Object(s.a)(null);
                                var l = new e.coreModel.ErrorInfo;
                                return l.message = "sendticket_ticketpolicy_stakethreshold_noextdata", Object(c.a)(l)
                            }
                            return Object(s.a)("sendTicket")
                        })), Object(v.a)((function(n) {
                            return "sendTicket" === n ? Object(a.a)(t.getBetslip().sendTicketToServer()) : Object(s.a)(n)
                        })), Object(y.a)((function(n) {
                            return console.log(n), t.processing.next(!1), t.onStake.next(), t.showErrorModal(n), Object(c.a)(n)
                        })), Object(C.a)((function(n) {
                            return t.onClear.next(), n
                        })))
                    }, n.prototype.printTicketById = function(n) {
                        var t = this;
                        void 0 === n && (n = !1), this.isPrintTicketFromAlphaNumericKeypad = !0, this.enableFastbet(!1);
                        var l = null;
                        this.modalService.open("base-information", I.a, {
                            inputs: {
                                title: this.i18NService.get("ch_ticket_id")
                            },
                            outputs: {
                                success: function(n) {
                                    l = n, t.isScanBarcode = !0, t.processing.next(!0), t.modalService.close("base-information")
                                }
                            }
                        }).afterClosed.subscribe(null, null, (function() {
                            if (l || "" === l) {
                                var e = t.coreService.getScanTicketModel(l);
                                n ? t.reprintTicketByIdHandler(e) : t.printTicketByIdHandler(e)
                            }
                            t.isScanBarcode = !1, t.processing.next(!1), t.enableFastbet(!0), t.isPrintTicketFromAlphaNumericKeypad = !1
                        }))
                    }, n.prototype.toggleFullScreen = function() {
                        this.coreService.getFullscreenController().toggleFullscreen(), this.onToggleFullScreen.next()
                    }, n.prototype.checkTicketPolicyError = function() {
                        var n = this.getBetslip().getTicketErrors();
                        return 1 == n.length && (n[0].message === e.coreUtils.TicketErrorCodEnum.SENDTICKET_TICKETPOLICY_STAKETHRESHOLD_NOEXTDATA || n[0].message === e.coreUtils.TicketErrorCodEnum.SENDTICKET_TICKETPOLICY_VALIDATEEXTRAINFO_NOEXTDATA) || null
                    }, n.prototype.printCashTicket = function(n) {
                        return this.coreService.getPrintTicketController().printCashTicket(n)
                    }, n.prototype.printLocalUserTicket = function(n, t) {
                        return this.coreService.getPrintTicketController().printLocalUserTicket(n, t)
                    }, n.prototype.printTicket = function(n) {
                        var t = this,
                            l = function(n) {
                                return Object(a.a)(t.coreService.getTicketController().ticketPrintConfirm(n.successPrint[0].ticketId)).pipe(Object(C.a)((function() {
                                    return n
                                })))
                            };
                        return Object(a.a)(this.coreService.getPrintTicketController().print(n)).pipe(Object(v.a)((function(e) {
                            var i, o;
                            return 1 === e.failPrint.length ? (console.error("ERROR PRINTING: ", null !== (o = null === (i = e.failPrint[0]) || void 0 === i ? void 0 : i.error) && void 0 !== o ? o : e.failPrint[0]), t.coreService.registerPrintingError(), function(e) {
                                return t.showPrintingErrorModal().pipe(Object(v.a)((function(i) {
                                    return i ? t.printTicket(n) : i ? l(e) : Object(s.a)(e)
                                })))
                            }(e)) : l(e)
                        })))
                    }, n.prototype.printProcessByTicketStatus = function(n, t) {
                        var l, i = this;
                        if (n && n.length > 0)
                            if (n[0].status === e.coreModel.TicketStatus.PRETICKET) l = this.preTicket(n[0], t.hashCode);
                            else if (n[0].status === e.coreModel.TicketStatus.OPEN) l = this.cancelTicket(n[0], t.hashCode);
                        else if (n[0].status === e.coreModel.TicketStatus.CANCELLED || n[0].status === e.coreModel.TicketStatus.CANCELLING) l = this.ticketModalService.showTicketInfo("base", n[0], {
                            hasConfirm: !1
                        });
                        else if (n[0].status === e.coreModel.TicketStatus.PENDING) l = this.ticketModalService.showTicketInfo("base", n[0], {
                            hasConfirm: !1
                        });
                        else {
                            if (n[0].status === e.coreModel.TicketStatus.WON) return n[0]._clData.isCashTicket() ? this.cashTicket(n[0], t.hashCode) : (l = this.modalService.createMaxPayoutModal(n[0]._clData.isTicketPayoutThresholdReached())).pipe(Object(v.a)((function(n) {
                                return "closedModalByUser" === n ? (i.notificationsService.danger("" + i.i18NService.get("ticketpayoutpolicy_wonamount_threshold_noextdata")), Object(s.a)()) : i.ticketResolve(t.ticketId, t.hashCode, e.ResolveAction.PAY, {
                                    extData: n
                                }).pipe(Object(v.a)((function(n) {
                                    return i.printPaidoutTicket(n)
                                })))
                            })));
                            if (n[0].status === e.coreModel.TicketStatus.PAIDOUT) l = this.canRebet(n[0]) ? this.rebetTicket(n[0]) : this.ticketModalService.showTicketInfo("base", n[0], {
                                hasConfirm: !1,
                                isAlreadyPaidout: !0,
                                isCashTicket: n[0]._clData.isCashTicket()
                            });
                            else if (n[0].status === e.coreModel.TicketStatus.LOST) l = this.canRebet(n[0]) ? this.rebetTicket(n[0]) : this.ticketModalService.showTicketInfo("base", n[0], {
                                hasConfirm: !1
                            });
                            else if (n[0].status === e.coreModel.TicketStatus.EXPIRED)
                                if (n[0]._clData.isCashTicket()) l = this.ticketModalService.showTicketInfo("base", n[0], {
                                    hasConfirm: !1,
                                    isCashTicket: !0,
                                    isExpired: !0
                                });
                                else {
                                    var o = t.ticketId;
                                    l = this.notificationsService.info("" + this.i18NService.get("ch_ticket_is_expired", {
                                        ticketId: o
                                    }))
                                }
                        } else l = Object(c.a)(n);
                        return l
                    }, n.prototype.printTicketByIdErrorHandler = function(n, t) {
                        this.handlerGetTicketByIdError(n, t)
                    }, n.prototype.reprintLastOpenTicket = function() {
                        var n, t = this;
                        return this.hasLastTicket() && this.getCashierProfileSettings().reprintLastTicket ? (n = Object(a.a)(this.coreService.reprintLastOpenTicket()).pipe(Object(k.a)(), Object(y.a)((function(n, l) {
                            return t.coreService.registerPrintingError(), t.handlerGetTicketByIdError(n, t.coreService.getLastTicket().serverTicket.ticketId), d.a
                        })))).subscribe() : n = d.a, n
                    }, n.prototype.reprintTicketByIdHandler = function(n) {
                        var t = this;
                        this.getTicketById(+n.ticketId, !0, !0).pipe(Object(v.a)((function(l) {
                            return t.reprintTicketProcess(l, n)
                        }))).subscribe({
                            error: function(l) {
                                return t.reprintTicketByIdErrorHandler(l, n.ticketId)
                            }
                        })
                    }, n.prototype.reprintTicketProcess = function(n, t) {
                        return n[0].timePrint && n[0].serverHash.toUpperCase() !== t.hashCode.toUpperCase() ? (this.coreService.registerPrintingError(), Object(c.a)(n)) : n && n.length > 0 ? this.reprintTicket(n[0]) : (this.coreService.registerPrintingError(), void Object(c.a)(n))
                    }, n.prototype.prepareReprintCashTicket = function(n) {
                        return delete n.timeSend, n.status = U.TicketStatus.WON, n
                    }, n.prototype.reprintTicketByIdErrorHandler = function(n, t) {
                        this.coreService.registerPrintingError(), this.handlerGetTicketByIdError(n, t)
                    }, n.prototype.reprintTicket = function(n) {
                        return n._clData.isCashTicket() ? Object(a.a)(this.coreService.getPrintTicketController().printCashTicket(this.prepareReprintCashTicket(n))) : Object(a.a)(this.coreService.getPrintTicketController().reprint(n))
                    }, n.prototype.getCashierProfileSettings = function() {
                        return this.coreService.getCashierProfileSettings()
                    }, n.prototype.getShopadminProfileSettings = function() {
                        return this.coreService.getShopadminProfileSettings()
                    }, n.prototype.getPrintProfileSettings = function() {
                        return this.coreService.getPrintProfileSettings()
                    }, n.prototype.getFastbetParser = function(n, t) {
                        var e = this,
                            i = Object(a.a)(l("4TAQ")("./" + t + ".js")).pipe(Object(k.a)());
                        return i.subscribe((function(t) {
                            e.currentPlaylistId = n, e.grammar = t, e.grammar.setMaxStake(Number.MAX_SAFE_INTEGER), e.onFastbetParserChange.next(t.parser)
                        }), (function(n) {
                            e.onFastbetEnableChange.next(!1)
                        })), i
                    }, n.prototype.removeCurrentFastbetParser = function() {
                        this.onFastbetParserChange.next()
                    }, n.prototype.addFastBetResults = function(n) {
                        for (var t = this, l = [], e = [], i = 0, o = n; i < o.length; i++) {
                            var r = o[i];
                            if (void 0 === r.combiGroup) {
                                var u = this.coreService.getPlaylistById(this.currentPlaylistId),
                                    s = this.coreService.getEventControllerByPlaylistId(this.currentPlaylistId, u.mode).getEventBlockOpen()[0],
                                    c = r.order || 1,
                                    a = s && s.events[c - 1],
                                    d = a.data._clData.oddMap.get(r.odd);
                                if (!d) return void this.showErrorMessage();
                                r.stake || (r.stake = this.configuration.fastbetStake()), l.push({
                                    playlist: u,
                                    eventBlock: s,
                                    event: a,
                                    odd: d,
                                    stake: r.stake,
                                    betParam: r.betParam
                                })
                            } else e.push({
                                combiGroup: r.combiGroup,
                                stake: r.stake
                            })
                        }
                        this.addBets(l, !0), this.setCombiStake(e), setTimeout((function() {
                            t.enableSendTicketShortcut(), t.enableFullScreenShortcut(), t.enableReprintLastTicketShortcut()
                        }), 150)
                    }, n.prototype.showNotEnoughCreditModal = function() {
                        var n = this;
                        this.modalService.openDialog("base", {
                            type: "danger",
                            icon: "icon icon-warning",
                            iconColor: "#d43548",
                            text: "" + this.i18NService.get("ch_not_enought_credit"),
                            buttons: [{
                                type: "danger",
                                text: "" + this.i18NService.get("ch_dismiss"),
                                action: function() {
                                    n.modalService.close("base")
                                }
                            }]
                        })
                    }, n.prototype.showConnectionErrorModal = function() {
                        this.processing.next(!1), this.modalService.openDialog("base", {
                            type: "danger",
                            icon: "icon icon-warning",
                            iconColor: "#d43548",
                            text: "" + this.i18NService.get("ch_connection_error"),
                            buttons: [{
                                type: "danger",
                                text: "" + this.i18NService.get("ch_reload"),
                                action: function() {
                                    window.location.reload()
                                }
                            }]
                        })
                    }, n.prototype.showErrorModal = function(n) {
                        var t = this,
                            l = this.getTagTranslationFromServerError(n);
                        this.processing.next(!1), n && n.message && this.modalService.openDialog("base", {
                            type: "danger",
                            icon: "icon icon-warning",
                            iconColor: "#d43548",
                            text: "" + this.i18NService.get(l.tag, {
                                value: l.param
                            }),
                            buttons: [{
                                type: "danger",
                                text: "" + this.i18NService.get("ch_dismiss"),
                                action: function() {
                                    t.modalService.close("base")
                                }
                            }]
                        })
                    }, n.prototype.hasEnoughtCredit = function(n) {
                        var t = this.coreService.getWalletStatus().balance;
                        return !((this.getTotalStakeItemized() ? this.getTotalStakeItemized().gross : n + 0) > t)
                    }, n.prototype.isLowCredit = function() {
                        var n, t = this.coreService.getCashierProfileSettings().lowBalanceWarning,
                            l = null === (n = this.coreService.getWalletStatus()) || void 0 === n ? void 0 : n.balance;
                        return !!l && l <= t
                    }, n.prototype.disableFullScreenShortcut = function() {
                        this.coreService.getShortcutController().disableAction(i.a.Fullscreen)
                    }, n.prototype.enableFullScreenShortcut = function() {
                        this.coreService.getShortcutController().enableAction(i.a.Fullscreen)
                    }, n.prototype.disableSendTicketShortcut = function() {
                        this.coreService.getShortcutController().disableAction(i.a.SendTicket)
                    }, n.prototype.enableSendTicketShortcut = function() {
                        this.coreService.getShortcutController().enableAction(i.a.SendTicket)
                    }, n.prototype.disableReprintLastTicketShortcut = function() {
                        this.coreService.getShortcutController().disableAction(i.a.ReprintTicket)
                    }, n.prototype.enableReprintLastTicketShortcut = function() {
                        this.coreService.getShortcutController().enableAction(i.a.ReprintTicket)
                    }, n.prototype.resolveTicketMaxWinningsReached = function() {
                        var n = this.getTotalMaxWinningItemized(),
                            t = null == n ? void 0 : n.ticketMaxPayoutError,
                            l = null == n ? void 0 : n.ajustedStakeOnTicketPolicyError;
                        this.coreService.getBetSlip().linkMaxWinningToMaxPayout() && t && (l.single ? this.notificationsService.warning(this.i18NService.get("ch_default_value_applied") + "<br>" + this.i18NService.get("ch_exceed_maximum_payout")) : this.notificationsService.warning(l.stake ? this.i18NService.get("ch_default_value_applied") + "<br> " + this.i18NService.get("ch_max_payout_combinations") : "" + this.i18NService.get("betslip_maxpayoutadjuststakeerror")), this.coreService.getBetSlip().resolveTicketErrors())
                    }, n.prototype.isFastBetDisabledBackOffice = function() {
                        return this.coreService.disableFastBet()
                    }, n.prototype.hasRebets = function() {
                        return this.rebets.length > 0
                    }, n.prototype.clearRebets = function() {
                        this.rebets = []
                    }, n.prototype.rebet = function(n, t) {
                        var l = this.rebets.map((function(l) {
                            return {
                                eventBlock: n,
                                event: t,
                                playlist: n._clData.playlist,
                                odd: t.data._clData.oddMap.get(l.oddId),
                                betParam: l.betParam,
                                stake: l._clData.getStakeSingleItemized().gross
                            }
                        }));
                        this.addBets(l), this.clearRebets(), this.onSendTicket.next()
                    }, n.prototype.notifyTicketBetUpdated = function() {
                        this.onTicketBetUpdated.next()
                    }, n.prototype.updateBets = function() {
                        this.configuration.preStake && this.configuration.preStake()
                    }, n.prototype.getTagTranslationFromServerError = function(n) {
                        var t;
                        switch (t = {
                            tag: "",
                            param: ""
                        }, n.errorCode ? n.errorCode : n.message) {
                            case "602":
                                t.tag = "ch_ticket_rejected_close_markets";
                                break;
                            case "624":
                                t.tag = "ch_invalid_ticket_rtp_cannot_be_higher_than_allowed";
                                break;
                            case "625":
                                t.tag = "ch_invalid_min_system_bet_stake";
                                break;
                            case "626":
                                t.tag = "ch_invalid_ticket_time";
                                break;
                            case "611":
                                t.tag = "ch_blocked_sales_limit";
                                break;
                            case "628":
                                t.tag = "betslip_max_stake_per_event", t.param = n.param;
                                break;
                            default:
                                t.tag = "ch_" + n.message.toLowerCase()
                        }
                        return t
                    }, n.prototype.handlerGetTicketByIdError = function(n, t) {
                        var l = n instanceof e.coreModel.ErrorInfo ? n.errorCode : n && n.error && n.error.errorCode;
                        switch (l = l || n.errorCode) {
                            case "500":
                                this.notificationsService.danger("" + this.i18NService.get("ch_unexpected_server_error"));
                                break;
                            case "403":
                                this.notificationsService.danger("" + this.i18NService.get("ch_unauthorized_operation"));
                                break;
                            case "1032":
                                this.notificationsService.danger("" + this.i18NService.get("ticketpayoutpolicy_wonamount_threshold_noextdata"));
                                break;
                            default:
                                this.notificationsService.danger("" + this.i18NService.get("ch_ticket_not_found", {
                                    ticketId: t
                                }))
                        }
                    }, n.prototype.fastbetHandler = function(n) {
                        void 0 === n && (n = []);
                        var t = this.getBetMode();
                        0 === this.getTotalSelections() && 1 === n.length ? this.addSingleBetByFastbet(n) : this.addMultipleBetsByFastbet(n, t)
                    }, n.prototype.getTotalSelections = function() {
                        return this.getBetslipInfo()._clData.getTotalSelections()
                    }, n.prototype.addSingleBetByFastbet = function(n) {
                        void 0 === n && (n = []), n[0].stake > 0 && this.onBetModeChange.next(e.BetModeEnum.SINGLEBETMODE), this.getBetslip().addBetByOddId(n, this.coreService.getWalletManager().getCurrentWallet().calculation.taxManager, e.DuplicateTicketBetBehaviour.IGNORE)
                    }, n.prototype.addMultipleBetsByFastbet = function(n, t) {
                        var l = this;
                        void 0 === n && (n = []);
                        var i = 0;
                        n.forEach((function(o, r) {
                            l.onBetModeChange.next(e.BetModeEnum.SINGLEBETMODE), t === e.BetModeEnum.SYSTEMBETMODE && n[r].stake > 0 && (i = n[r].stake, n[r].stake = 0), l.getBetslip().addBetByOddId([o], l.coreService.getWalletManager().getCurrentWallet().calculation.taxManager, e.DuplicateTicketBetBehaviour.IGNORE)
                        })), t === e.BetModeEnum.SYSTEMBETMODE && this.setFastbetCombiStake(i)
                    }, n.prototype.setFastbetCombiStake = function(n) {
                        void 0 === n && (n = 0), this.onBetModeChange.next(e.BetModeEnum.SYSTEMBETMODE), this.getBetslipInfo().systemBets.length > 0 && this.setCombiStake([{
                            stake: n,
                            combiGroup: D(this.getBetslipInfo().systemBets).reverse()[0].grouping
                        }])
                    }, n.prototype.getLanguage = function() {
                        return this.i18NService.getCurrentLanguage() ? this.i18NService.getCurrentLanguage() : this.i18NService.getDefaultLanguage()
                    }, n.prototype.showLocalUsersModal = function() {
                        return new p.a((function(n) {
                            return n.next()
                        }))
                    }, n.prototype.showPrintingErrorModal = function() {
                        var n = this;
                        return this.processing.next(!1), new p.a((function(t) {
                            var l;
                            n.modalService.openDialog("base", {
                                icon: "icon icon-warning",
                                iconColor: "#d43548",
                                text: "" + n.i18NService.get("ch_printing_error"),
                                buttons: [{
                                    text: "" + n.i18NService.get("ch_no"),
                                    type: "bordered",
                                    action: function() {
                                        l = !1
                                    }
                                }, {
                                    text: "" + n.i18NService.get("ch_yes"),
                                    type: "success",
                                    action: function() {
                                        l = !0
                                    }
                                }]
                            }).afterClosed.subscribe(null, null, (function() {
                                t.next(l)
                            }))
                        }))
                    }, n.prototype.setFastbetMaxCombiGroup = function() {
                        if (this.grammar && this.grammar.setMaxCombiGroup) {
                            var n = this.getBetslipInfo().systemBets.map((function(n) {
                                return n.grouping
                            })).reduce((function(n, t) {
                                return Math.max(n, t)
                            }), 0);
                            this.grammar.setMaxCombiGroup(n)
                        }
                    }, n.prototype.printTicketByIdHandler = function(n) {
                        var t = this,
                            l = +n.ticketId;
                        this.getTicketById(l, !0).pipe(Object(v.a)((function(l) {
                            return t.printProcessByTicketStatus(l, n)
                        }))).subscribe({
                            error: function(n) {
                                return t.printTicketByIdErrorHandler(n, l)
                            }
                        })
                    }, n.prototype.canRebet = function(n) {
                        var t = n.gameType[0].toUpperCase();
                        return this.getPrintProfileSettings().rebetCasinoTickets && (t === e.coreModel.GameType.ValEnum.SN || t === e.coreModel.GameType.ValEnum.KN || t === e.coreModel.GameType.ValEnum.SX || t === e.coreModel.GameType.ValEnum.RAINBOW || t === e.coreModel.GameType.ValEnum.LOTTOFIVE || t === e.coreModel.GameType.ValEnum.LL || t === e.coreModel.GameType.ValEnum.S7 || t === e.coreModel.GameType.ValEnum.S2W)
                    }, n.prototype.getGameType = function(n) {
                        var t = e.coreModel.GameType.ValEnum;
                        switch (n) {
                            case t.SN:
                                return "spin2win";
                            case t.LL:
                                return "mega6";
                            case t.SX:
                                return "perfect6";
                            case t.RAINBOW:
                                return "rainbow";
                            case t.KN:
                                return "keno";
                            case t.S2W:
                                return "spin2wheels"
                        }
                    }, n.prototype.getPlaylistId = function(n) {
                        return n.details.events[0].playlistId
                    }, n.prototype.rebetTicket = function(n) {
                        var t = this;
                        return this.ticketModalService.rebetTicket("base", n).pipe(Object(b.a)((function() {
                            t.rebets = n.details.events[0].bets
                        })), Object(v.a)((function() {
                            return Object(a.a)(t.router.navigate(["/cashier/" + t.getGameType(n.gameType[0]) + "/" + t.getPlaylistId(n)], {
                                queryParamsHandling: "merge"
                            }))
                        })), Object(b.a)((function() {
                            return t.onRebet.next()
                        })))
                    }, n.prototype.cancelTicket = function(n, t) {
                        var l = this;
                        Object(s.a)({
                            serverTickets: [],
                            successPrint: [],
                            failPrint: []
                        });
                        return this.ticketModalService.cancelTicket("base", n, {
                            hasConfirm: this.getCashierProfileSettings().cancelConfirm,
                            confirmOnClose: !this.getCashierProfileSettings().cancelConfirm || null
                        }).pipe(Object(v.a)((function() {
                            return l.ticketResolve(n.ticketId, t, e.ResolveAction.CANCEL)
                        })), Object(v.a)((function(n) {
                            return l.printCancelTicket(n)
                        })), Object(y.a)((function(t, e) {
                            return l.coreService.registerPrintingError(), l.handlerGetTicketByIdError(t, n.ticketId), d.a
                        })))
                    }, n.prototype.cashTicket = function(n, t) {
                        var l = this;
                        return this.ticketModalService.cashTicket("base", n).pipe(Object(v.a)((function() {
                            return l.ticketResolve(n.ticketId, t, e.ResolveAction.PAY)
                        })), Object(v.a)((function(n) {
                            return l.ticketModalService.showTicketInfo("base", n, null)
                        })))
                    }, n.prototype.preTicket = function(n, t) {
                        var l = this;
                        Object(s.a)({
                            serverTickets: [],
                            successPrint: [],
                            failPrint: []
                        });
                        return this.ticketModalService.preTicket("base", n, {
                            hasConfirm: !0
                        }).pipe(Object(v.a)((function() {
                            return l.ticketResolve(n.ticketId, t, e.ResolveAction.VALIDATE)
                        })), Object(v.a)((function(t) {
                            return t.winningData = n.winningData, l.printPreTicket(t)
                        })))
                    }, n.prototype.printPreTicket = function(n) {
                        var t = this;
                        Object(s.a)({
                            serverTickets: [],
                            successPrint: [],
                            failPrint: []
                        });
                        return this.ticketModalService.showTicketInfo("base", n, {
                            hasConfirm: !0
                        }).pipe(Object(v.a)((function() {
                            return t.printTicket(n)
                        })))
                    }, n.prototype.getTicketById = function(n, t, l) {
                        return Object(a.a)(this.coreService.getTicketById(n, t, l))
                    }, n.prototype.ticketResolve = function(n, t, l, e) {
                        return Object(a.a)(this.coreService.getTicketController().ticketResolve(n, t, l, e))
                    }, n.prototype.printCancelTicket = function(n) {
                        var t = this,
                            l = Object(s.a)({
                                serverTickets: [],
                                successPrint: [],
                                failPrint: []
                            });
                        return this.getCashierProfileSettings().canPrintCancel && (l = this.ticketModalService.showTicketInfo("base", n, {
                            hasConfirm: this.getCashierProfileSettings().printCancelConfirm
                        }).pipe(Object(v.a)((function() {
                            return t.printTicket(n)
                        })))), l
                    }, n.prototype.printPaidoutTicket = function(n) {
                        var t = this;
                        return this.ticketModalService.showTicketInfo("base", n, {
                            hasConfirm: this.getCashierProfileSettings().canPrintPayout && this.getCashierProfileSettings().printPayoutConfirm && !n._clData.isRejected()
                        }).pipe(Object(x.a)((function() {
                            return !n._clData.isRejected()
                        })), Object(x.a)((function() {
                            return t.getCashierProfileSettings().canPrintPayout
                        })), Object(v.a)((function() {
                            return t.printTicket(n)
                        })))
                    }, n.prototype.getBetslip = function() {
                        return this.coreService.getTicketController().getBetslip()
                    }, n.prototype.subscribeToScanBarCode = function() {
                        var n = this;
                        this.subscriptions.add(Object(T.a)(this.coreService.getScanBarcodeController().onScantBarcode).subscribe((function(t) {
                            n.isPrintTicketFromAlphaNumericKeypad || n.printTicketByIdHandler(t)
                        })))
                    }, n.prototype.subscribeShortcuts = function() {
                        var n = this;
                        this.subscriptions.add(this.coreService.onShortcut(i.a.ReprintTicket).subscribe((function() {
                            n.reprintLastOpenTicket()
                        }))), this.subscriptions.add(this.coreService.onShortcut(i.a.FastbetHelp).subscribe((function() {
                            n.openFastbetHelp()
                        }))), this.subscriptions.add(this.coreService.onShortcut(i.a.Shopadmin).subscribe((function() {
                            n.shopAdminService.openShopAdmin()
                        }))), this.subscriptions.add(this.coreService.onShortcut(i.a.Fullscreen).subscribe((function() {
                            n.toggleFullScreen()
                        })))
                    }, n.prototype.closeModalWindow = function() {
                        this.isModalOpen && (this.isModalOpen = !1, this.modalService.close("base"))
                    }, n.prototype.showErrorMessage = function() {
                        var n = "" + this.i18NService.get("ch_invalid_fastbet");
                        this.notificationsService.danger(n)
                    }, n.ngInjectableDef = A.ic({
                        factory: function() {
                            return new n(A.jc(w.a), A.jc(S.a), A.jc(O.a), A.jc(j.a), A.jc(B.k), A.jc(M.a), A.jc(H.l))
                        },
                        token: n,
                        providedIn: "root"
                    }), n
                }()
        },
        t01L: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return S
            }));
            var e = l("ZYCi"),
                i = l("IPGB"),
                o = l("WGel"),
                r = l("CrY/"),
                u = l("n3kJ"),
                s = l("K9Ia"),
                c = l("0/uQ"),
                a = l("F/XL"),
                d = l("t9fZ"),
                p = l("xMyE"),
                b = l("psW0"),
                h = l("67Y/"),
                g = l("15JJ"),
                f = l("VnD/"),
                m = l("ee4M"),
                _ = l("sB3t"),
                v = l("5msJ"),
                y = l("GNnp"),
                C = l("CcnG"),
                k = l("5EE+"),
                x = function(n, t, l, e) {
                    return new(l || (l = Promise))((function(i, o) {
                        function r(n) {
                            try {
                                s(e.next(n))
                            } catch (t) {
                                o(t)
                            }
                        }

                        function u(n) {
                            try {
                                s(e.throw(n))
                            } catch (t) {
                                o(t)
                            }
                        }

                        function s(n) {
                            var t;
                            n.done ? i(n.value) : (t = n.value, t instanceof l ? t : new l((function(n) {
                                n(t)
                            }))).then(r, u)
                        }
                        s((e = e.apply(n, t || [])).next())
                    }))
                },
                I = function(n, t) {
                    var l, e, i, o, r = {
                        label: 0,
                        sent: function() {
                            if (1 & i[0]) throw i[1];
                            return i[1]
                        },
                        trys: [],
                        ops: []
                    };
                    return o = {
                        next: u(0),
                        throw: u(1),
                        return: u(2)
                    }, "function" == typeof Symbol && (o[Symbol.iterator] = function() {
                        return this
                    }), o;

                    function u(o) {
                        return function(u) {
                            return function(o) {
                                if (l) throw new TypeError("Generator is already executing.");
                                for (; r;) try {
                                    if (l = 1, e && (i = 2 & o[0] ? e.return : o[0] ? e.throw || ((i = e.return) && i.call(e), 0) : e.next) && !(i = i.call(e, o[1])).done) return i;
                                    switch (e = 0, i && (o = [2 & o[0], i.value]), o[0]) {
                                        case 0:
                                        case 1:
                                            i = o;
                                            break;
                                        case 4:
                                            return r.label++, {
                                                value: o[1],
                                                done: !1
                                            };
                                        case 5:
                                            r.label++, e = o[1], o = [0];
                                            continue;
                                        case 7:
                                            o = r.ops.pop(), r.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = r.trys, (i = i.length > 0 && i[i.length - 1]) || 6 !== o[0] && 2 !== o[0])) {
                                                r = 0;
                                                continue
                                            }
                                            if (3 === o[0] && (!i || o[1] > i[0] && o[1] < i[3])) {
                                                r.label = o[1];
                                                break
                                            }
                                            if (6 === o[0] && r.label < i[1]) {
                                                r.label = i[1], i = o;
                                                break
                                            }
                                            if (i && r.label < i[2]) {
                                                r.label = i[2], r.ops.push(o);
                                                break
                                            }
                                            i[2] && r.ops.pop(), r.trys.pop();
                                            continue
                                    }
                                    o = t.call(n, r)
                                } catch (u) {
                                    o = [6, u], e = 0
                                } finally {
                                    l = i = 0
                                }
                                if (5 & o[0]) throw o[1];
                                return {
                                    value: o[0] ? o[1] : void 0,
                                    done: !0
                                }
                            }([o, u])
                        }
                    }
                },
                S = function() {
                    function n(n, t, l, e) {
                        this.externalConfigService = n, this.injector = t, this.i18nService = l, this.notificationService = e, this.sessionExpired = !1, this.onPlaylistChanged = new s.a
                    }
                    return n.prototype.init = function(n) {
                        var t = this;
                        return this.environmentConfigController = n, this.initCore(n).pipe(Object(d.a)(1), Object(p.a)((function() {
                            return t.checkMinConfig()
                        })), Object(p.a)((function() {
                            return t.setCoreConfiguration()
                        })), Object(b.a)((function() {
                            return t.initCashierCore(n)
                        })), Object(b.a)((function() {
                            return t.initAssetsController(n)
                        })), Object(h.a)((function() {
                            return t.sessionExpired = !1
                        })), Object(p.a)((function() {
                            return t.subscribeShortcuts()
                        })))
                    }, n.prototype.setEnvironmentConfigController = function(n) {
                        this.environmentConfigController = n
                    }, n.prototype.destroy = function() {
                        this.coreController.destroy(), delete this.coreController
                    }, n.prototype.findByHwId = function(n, t) {
                        return x(this, void 0, void 0, (function() {
                            var l;
                            return I(this, (function(e) {
                                switch (e.label) {
                                    case 0:
                                        return (l = this.getSessionControllerConfig(n)).loginParams.hardwareId = t, [4, r.CoreController.factoryCoreController().findByHwid(l, null)];
                                    case 1:
                                        return [2, e.sent()]
                                }
                            }))
                        }))
                    }, n.prototype.getLocalizationLanguage = function() {
                        var n = o.SupportedLanguages,
                            t = n.en_GB,
                            l = this.externalConfigService.getEnvironmentConfig().configParams.lang;
                        if (l || (l = localStorage.getItem("lastLanguageSelected")), l && n[l]);
                        else if (this.isInitialized()) {
                            n[l = this.getSessionController().sessionSettings.localizationContext.language.replace(/\-/g, "_")] || (l = t)
                        } else l = t;
                        return l
                    }, n.prototype.initLocalization = function() {
                        if (this.isInitialized()) {
                            var n = this.getSessionController().sessionSettings.localizationContext;
                            this.i18nService.location.setDefaultUtcOffset(n.utcOffset), this.i18nService.location.setDefaultCurrency(this.getWalletManager().getCurrentWallet().currency), this.i18nService.location.setCustomDateTimeFormat(n.dateTimeFormat)
                        } else this.i18nService.location.setDefaultUtcOffset(0), this.i18nService.location.setDefaultCurrency({
                            code: "EUR",
                            decimals: 2,
                            symbol: "20ac",
                            step: void 0
                        });
                        var t = this.getLocalizationLanguage();
                        return this.retailController && this.retailController.setLanguage(o.SupportedLanguages[t]), this.i18nService.use(t)
                    }, n.prototype.getAllEventControllers = function() {
                        return this.coreController.getAllEventControllersByPriority(!0, !0, !1).filter((function(n) {
                            return n.content.isPlaylistContent() && "another" !== Object(m.a)(n.content._clData.playlist)
                        }))
                    }, n.prototype.getPlaylistById = function(n) {
                        return this.coreController.getSessionController().allPlaylists.get(n)
                    }, n.prototype.getInitialDisplayId = function(n) {
                        var t = n.getEnvironmentConfig().configParams.displayId;
                        return t ? decodeURIComponent(t) : null
                    }, n.prototype.getPlaylistIdFromDisplayId = function(n) {
                        var t = this.coreController.getAllEventControllers().find((function(t) {
                            return t.content._clDataParent.displayIds.includes(n)
                        }));
                        return String(t.content.playlistId)
                    }, n.prototype.getDisplayIdFromPlaylistId = function(n) {
                        var t = this.coreController.getAllEventControllers().find((function(t) {
                            return t.content.playlistId === Number(n)
                        }));
                        return t.content._clDataParent ? t.content._clDataParent.displayIds : null
                    }, n.prototype.getEventControllerByPlaylistId = function(n, t) {
                        var l;
                        return t === r.coreModel.Playlist.ModeEnum.SCHEDULED ? l = this.coreController.getEventControllerByPlaylistId(n) : t === r.coreModel.Playlist.ModeEnum.ONDEMAND ? l = this.coreController.getEventControllerByPlaylistIdOnDemand(n) : t === r.coreModel.Playlist.ModeEnum.LIVE && (l = this.coreController.getEventControllerByPlaylistIdLive(n)), l
                    }, n.prototype.getEventByEventId = function(n, t, l) {
                        return this.getEventControllerByPlaylistId(n, l).getEventById(n, t)
                    }, n.prototype.getJackpots = function() {
                        return this.coreController.getSessionController().sessionSettings.sessionStatus.jackpots
                    }, n.prototype.getSessionController = function() {
                        return this.coreController.getSessionController()
                    }, n.prototype.getTicketController = function() {
                        return this.coreController.getTicketController()
                    }, n.prototype.getCashController = function() {
                        return this.coreController.getCashController()
                    }, n.prototype.getScanTicketModel = function(n) {
                        return this.retailController.getScanBarcodeController().processRawBarcode(n)
                    }, n.prototype.getTicketById = function(n, t, l) {
                        return void 0 === t && (t = !0), void 0 === l && (l = !1), Object(c.a)(this.getTicketController().ticketFindById(1, !1, null, n, t, l))
                    }, n.prototype.getFullscreenController = function() {
                        return this.retailController.getFullscreenController()
                    }, n.prototype.getInactivityController = function() {
                        return this.retailController.getInactivityController()
                    }, n.prototype.getPrintTicketController = function() {
                        return this.retailController.getPrintTicketController()
                    }, n.prototype.getScanBarcodeController = function() {
                        return this.retailController.getScanBarcodeController()
                    }, n.prototype.getWalletManager = function() {
                        return this.getSessionController().walletManager
                    }, n.prototype.hasInfiniteCredit = function() {
                        return this.getWalletManager().getCurrentWallet().walletType === r.WalletType.NO_CREDIT
                    }, n.prototype.hasBarCodeButton = function() {
                        return this.getCashierProfileSettings().canPrintCancel || this.getCashierProfileSettings().canPrintPayout || this.getCashierProfileSettings().printTicketAndCopy
                    }, n.prototype.hasButtonText = function() {
                        return this.getCashierProfileSettings().hasButtonText
                    }, n.prototype.hideHeaderLogo = function() {
                        return this.getCashierProfileSettings().hideHeaderLogo
                    }, n.prototype.disableFastBet = function() {
                        return this.getCashierProfileSettings().disableFastbet
                    }, n.prototype.hideNotificationTopBar = function() {
                        return this.getCashierProfileSettings().hideNotificationTopBar
                    }, n.prototype.hideCreditArea = function() {
                        return this.getCashierProfileSettings().hideCreditArea
                    }, n.prototype.hideUsernameArea = function() {
                        return this.getCashierProfileSettings().hideUsernameArea
                    }, n.prototype.hideOptionMenuButton = function() {
                        return this.getCashierProfileSettings().hideOptionMenuButton
                    }, n.prototype.getWalletStatus = function() {
                        return this.getWalletManager().getCurrentWallet().walletStatus
                    }, n.prototype.getCashierProfileSettings = function() {
                        return this.coreController.getSessionController().sessionSettings.generalSettings.profilesContext.cashier
                    }, n.prototype.getShopadminProfileSettings = function() {
                        return this.coreController.getSessionController().sessionSettings.generalSettings.profilesContext.shopadmin
                    }, n.prototype.getPrintProfileSettings = function() {
                        return this.coreController.getSessionController().sessionSettings.generalSettings.profilesContext.print
                    }, n.prototype.getAssetsController = function() {
                        return this.assetsController
                    }, n.prototype.getShopAdminController = function() {
                        return this.retailController.getShopadminController()
                    }, n.prototype.getShortcutController = function() {
                        return this.retailController.getShortcutController()
                    }, n.prototype.getBetSlip = function() {
                        return this.coreController.getTicketController().getBetslip()
                    }, n.prototype.registerPrintingError = function() {
                        this.coreController.getLogController().registerPrintingError()
                    }, n.prototype.logOut = function(n) {
                        return void 0 === n && (n = !1), x(this, void 0, void 0, (function() {
                            return I(this, (function(t) {
                                switch (t.label) {
                                    case 0:
                                        return this.getShortcutController().disableAll(), this.externalConfigService.getEnvironmentConfig().configParams.registerLogOut ? [4, this.coreController.getLogController().registerLogOut()] : [3, 2];
                                    case 1:
                                        t.sent(), t.label = 2;
                                    case 2:
                                        return this.destroy(), n && (this.sessionExpired = !0), this.injector.get(e.l).navigate(["/login"], {
                                            queryParamsHandling: "preserve"
                                        }), [2]
                                }
                            }))
                        }))
                    }, n.prototype.setLocalStorageParams = function(n) {
                        n.setLocalStorageParamsAttr("loginDomain"), n.setLocalStorageParamsAttr("loginUser"), n.setLocalStorageParamsAttr("loginPassword")
                    }, n.prototype.onShortcut = function(n) {
                        return Object(_.a)(this.getShortcutController().onAction).pipe(Object(g.a)((function(n) {
                            return a.a.apply(void 0, n)
                        })), Object(f.a)((function(t) {
                            return t.action === n
                        })))
                    }, n.prototype.isInitialized = function() {
                        return !!this.coreController
                    }, n.prototype.getIframeProxyMessage = function() {
                        return this.retailController.webframeCommProxyMessage
                    }, n.prototype.getLastTicket = function() {
                        return this.retailController.getPrintTicketController().getLastTicket()
                    }, n.prototype.reprintLastOpenTicket = function() {
                        return Object(c.a)(this.retailController.getPrintTicketController().reprintLastOpenTicket())
                    }, n.prototype.getEnvironmentConfigController = function() {
                        return this.environmentConfigController
                    }, n.prototype.getLocalizationContext = function() {
                        return this.coreController.getSessionController().sessionSettings.localizationContext
                    }, n.prototype.isModeVboxCashier = function() {
                        return u.h.isVboxCashierMode()
                    }, n.prototype.getHwId = function(n) {
                        return n.configParams.hwId
                    }, n.prototype.getDiscoverController = function(n) {
                        return x(this, void 0, void 0, (function() {
                            var t, l;
                            return I(this, (function(e) {
                                switch (e.label) {
                                    case 0:
                                        return (t = this.retailController.getDiscoverController()) ? [3, 2] : (l = new u.c({
                                            platformsLocalServerUrl: n.configParams.platformsLocalServerUrl,
                                            loadDataOnInit: !!this.isModeVboxCashier()
                                        }), [4, this.retailController.createDiscoverController(l)]);
                                    case 1:
                                        return [2, e.sent()];
                                    case 2:
                                        return [2, t]
                                }
                            }))
                        }))
                    }, n.prototype.getRetailCoreSessionController = function(n) {
                        return x(this, void 0, void 0, (function() {
                            var t, l;
                            return I(this, (function(e) {
                                switch (e.label) {
                                    case 0:
                                        return (t = this.retailController.getSessionController()) ? [3, 2] : (l = new u.j({
                                            platformsLocalServerUrl: n.configParams.platformsLocalServerUrl,
                                            loadDataOnInit: !!this.isModeVboxCashier()
                                        }), [4, this.retailController.createSessionController(l)]);
                                    case 1:
                                        return [2, e.sent()];
                                    case 2:
                                        return [2, t]
                                }
                            }))
                        }))
                    }, n.prototype.getSystemController = function(n) {
                        return x(this, void 0, void 0, (function() {
                            var n, t;
                            return I(this, (function(l) {
                                switch (l.label) {
                                    case 0:
                                        return n = this.retailController.getSystemController(), this.systemController ? [3, 2] : (t = new u.m({
                                            platformsLocalServerUrl: null,
                                            loadDataOnInit: !0
                                        }), [4, this.retailController.createSystemController(t)]);
                                    case 1:
                                        return [2, l.sent()];
                                    case 2:
                                        return [2, n]
                                }
                            }))
                        }))
                    }, n.prototype.getNextEventblockDataDependOfPreviousResult = function(n) {
                        return r.SessionController.gameManager.getGame(n).nextEventblockDataDependOfPreviousResult(null)
                    }, n.prototype.initI18nOnRetailCore = function(n) {
                        return this.retailController = new u.g, this.retailController.initI18n(n)
                    }, n.prototype.setI18nLoader = function(n, t) {
                        this.retailController.seti18nLoader(n, t)
                    }, n.prototype.initCore = function(n) {
                        return this.coreController = r.CoreController.factoryCoreController(), Object(c.a)(this.coreController.init(this.getSessionControllerConfig(n), this.getEBControllerConfig(), this.getTicketControllerConfig(), this.getCreditControllerConfig(), this.getStatsControllerConfig(), this.getReportControllerConfig(), this.getLogControllerConfig(), this.getCashControllerConfig()))
                    }, n.prototype.initCashierCore = function(n) {
                        var t, l = this;
                        return t = [this.getPrinterControllerConfig(n), this.getFullscreenControllerConfig(), this.getScanBarcodeControllerConfig(), this.getInactivityControllerConfig(), this.getShopadminControllerConfig(n), this.getShortcutControllerConfig()], Object(c.a)(this.retailController.init(t, n.configParams.platformsLocalServerUrl)).pipe(Object(b.a)((function() {
                            return l.retailController.getShopadminController().init()
                        })), Object(h.a)((function() {
                            var n = l.getShopAdminController();
                            n.shopadminRequest = n.shopadminPath + "?" + window.location.href.split("?")[1]
                        })))
                    }, n.prototype.initAssetsController = function(n) {
                        var t = this.getSessionController().sessionSettings;
                        return this.assetsController = new i.AssetsController(decodeURIComponent(n.configParams.provisioningUrl), t.localizationContext.language, t.localizationContext.skin.toLowerCase()), Object(c.a)(this.assetsController.init())
                    }, n.prototype.getReportControllerConfig = function() {
                        return new r.ReportControllerConfig
                    }, n.prototype.getLogControllerConfig = function() {
                        return new r.LogControllerConfig
                    }, n.prototype.getCashControllerConfig = function() {
                        return new r.CashControllerConfig
                    }, n.prototype.getSessionControllerConfig = function(t) {
                        var l = new r.LoginParams;
                        t.configParams.onlineHash ? l.onlineHash = t.configParams.onlineHash : t.configParams.barcode && t.configParams.pin ? (l.barcode = t.configParams.barcode, l.pinHash = t.configParams.pin) : (l.domain = t.configParams.domain, l.username = t.configParams.user, l.digestedPassword = t.configParams.password, l.hardwareId = t.configParams.hwId), l.serverUrl = decodeURIComponent(t.configParams.serverUrl), l.profile = [r.coreModel.ProfileType.ValEnum.CASHIER, r.coreModel.ProfileType.ValEnum.PRINTING, r.coreModel.ProfileType.ValEnum.SHOPADMIN], l.tags = [r.coreModel.ProfileType.ValEnum.CASHIER];
                        var e = new r.SessionControllerConfig(l);
                        return e.activeTickSystemClock = !0, e.disableByPlaylistByPlaylistType = [r.coreModel.Playlist.ModeEnum.ONDEMAND], this.useReceptionProxy() && (e.receptionProxyUrl = n.receptionUrl, e.enabledRequestCache = !0, e.collapseRequest = !0), e.initRetryPolicy = {
                            maxRetry: -1,
                            retryInterval: 1e4,
                            randomRetryInterval: !0
                        }, e
                    }, n.prototype.useReceptionProxy = function() {
                        return !!this.externalConfigService.getEnvironmentConfig().configParams.useReceptionProxy
                    }, n.prototype.getEBControllerConfig = function() {
                        var n = new r.EBControllerConfig,
                            t = n.getDefaultEBControllerConfigItem();
                        return t.windowOpenSize = 2, t.setCurrStatusViewNotificationOnEntryApp = !1, n.setConfigPlaylistForAllGames(t), n
                    }, n.prototype.getTicketControllerConfig = function() {
                        var n = new r.TicketControllerConfig;
                        return n.calculateMaxMinOddWithZeroStake = !0, n.proccessCombi1 = !1, n.injectClientResolvedTicketOnFind = !1, n.liveResolveWithEventBlockEnds = !1, n.liveResolveWithHappenings = !1, n.maxEvent = 22, n.maxSelections.byGame.CH = 25, n.myBetStorageType = r.MyBetStorageType.NONE, n
                    }, n.prototype.getCreditControllerConfig = function() {
                        return new r.CreditControllerConfig
                    }, n.prototype.getStatsControllerConfig = function() {
                        return new r.StatsControllerConfig
                    }, n.prototype.getScanBarcodeControllerConfig = function() {
                        return new u.i
                    }, n.prototype.getShopadminControllerConfig = function(t) {
                        return new u.k({
                            shopadminUrl: decodeURIComponent(t.configParams.shopadminUrl),
                            params: {
                                onlineHash: t.configParams.onlineHash,
                                hwId: t.configParams.hwId,
                                domain: t.configParams.domain,
                                user: t.configParams.user,
                                password: t.configParams.password,
                                barcode: t.configParams.barcode,
                                pin: t.configParams.pin,
                                serverUrl: this.useReceptionProxy() ? n.receptionUrl : decodeURIComponent(t.configParams.serverUrl),
                                lang: this.getLocalizationLanguage(),
                                platformsLocalServerUrl: t.configParams.platformsLocalServerUrl ? decodeURIComponent(t.configParams.platformsLocalServerUrl) : null,
                                processCombi1: !1
                            }
                        })
                    }, n.prototype.getInactivityControllerConfig = function() {
                        var n = this.getCashierProfileSettings().inactivityTimeout;
                        return new u.e({
                            inactivityTimeoutSeconds: n
                        })
                    }, n.prototype.getFullscreenControllerConfig = function() {
                        var n = this.getCashierProfileSettings().startFullScreen;
                        return new u.d({
                            startFullScreen: n
                        })
                    }, n.prototype.getPrinterControllerConfig = function(n) {
                        var t = this.getSessionController().sessionSettings.localizationContext;
                        return new u.f({
                            platformsLocalServerUrl: n.configParams.platformsLocalServerUrl,
                            loadDataOnInit: !!this.isModeVboxCashier(),
                            cssBasePath: "./assets/cashier/",
                            logoBasePath: "./assets/cashier/logos",
                            fontsBasePath: "./assets/cashier/fonts",
                            skin: t.skin,
                            langCode: t.language.replace(/\-/g, "_"),
                            timeOffset: t.utcOffset,
                            qrBasePath: "https://vs-qa.golden-race.net/qr",
                            printTicketAndCopy: this.getCashierProfileSettings().printTicketAndCopy,
                            browserPrinterMode: this.isModeVboxCashier() ? null : n.configParams.browserPrinterMode,
                            formatConfig: this.getSessionController().sessionSettings.generalSettings.profilesContext.print
                        })
                    }, n.prototype.getShortcutControllerConfig = function() {
                        var n = new u.l;
                        return n.domElement = document, n
                    }, n.prototype.setCoreConfiguration = function() {
                        var n = this.getCashierProfileSettings();
                        this.getTicketController().getBetslip().changeStakeMode(n.splitStake ? r.StakeModeEnum.SPLIT : r.StakeModeEnum.PERBET)
                    }, n.prototype.subscribeShortcuts = function() {
                        var n = this;
                        Object(c.a)(this.onShortcut(u.a.Logout)).subscribe((function() {
                            n.logOut()
                        }))
                    }, n.prototype.checkMinConfig = function() {
                        var n = this.getSessionController().sessionSettings.localizationContext;
                        if (!n.language) throw new Error("language_cannot_null");
                        if (!n.skin) throw new Error("skin_cannot_null");
                        if (!n.timezone) throw new Error("timezone_cannot_null")
                    }, n.receptionUrl = "iframe://cashier-shopadmin-channel:cashier", n.ngInjectableDef = C.ic({
                        factory: function() {
                            return new n(C.jc(v.a), C.jc(C.u), C.jc(k.k), C.jc(y.a))
                        },
                        token: n,
                        providedIn: "root"
                    }), n
                }()
        },
        tfG9: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return e
            }));
            var e = function() {
                function n(n) {
                    this.document = n
                }
                return n.prototype.loadJsScript = function(n, t) {
                    var l = n.createElement("script");
                    return l.type = "text/javascript", l.src = t, n.appendChild(this.document.body, l), l
                }, n
            }()
        },
        xTWW: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return e
            }));
            l("kMfV");
            var e = function() {
                function n(n, t) {
                    this.viewContainerRef = n, this.host = t
                }
                return n.prototype.ngOnInit = function() {
                    this.viewContainerRef.createEmbeddedView(this.host.content)
                }, n
            }()
        },
        "y+mV": function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return i
            }));
            var e = l("pugT"),
                i = (l("sylN"), l("t01L"), l("5msJ"), l("38rj"), function() {
                    function n(n, t, l, i) {
                        this.cd = n, this.externalConfigService = t, this.betslipService = l, this.coreService = i, this.hasQRPermissions = !1, this.isFormButtonClicked = !1, this.scannedData = null, this.isLoading = !1, this.subscriptions = new e.a
                    }
                    return n.prototype.ngOnInit = function() {
                        var n = this;
                        this.isLoading = !0, this.addSubscriptions(), this.modalData = this.getDataModal(), navigator.mediaDevices.getUserMedia({
                            video: !0
                        }).then((function(t) {
                            n.hasQRPermissions = !0, n.isLoading = !1, n.cd.detectChanges()
                        })).catch((function(t) {
                            console.log(t), n.isLoading = !1, n.cd.detectChanges()
                        }))
                    }, n.prototype.openForm = function(n) {
                        var t;
                        null === (t = this.child) || void 0 === t || t.closeCamera(), this.isFormButtonClicked = !0, this.scannedData = n ? JSON.parse(n) : null, this.cd.detectChanges()
                    }, n.prototype.openQR = function() {
                        this.isFormButtonClicked = !1
                    }, n.prototype.callAction = function(n) {
                        n && n()
                    }, n.prototype.close = function(n) {
                        var t;
                        null === (t = this.child) || void 0 === t || t.closeCamera();
                        var l = n ? new CustomEvent("actionDataDialog", {
                            detail: {
                                marketClose: !0
                            }
                        }) : new CustomEvent("actionDataDialog");
                        document.dispatchEvent(l)
                    }, n.prototype.ngOnDestroy = function() {
                        this.subscriptions.unsubscribe()
                    }, n.prototype.addSubscriptions = function() {
                        var n = this;
                        this.configuration.isMaxPayout || this.subscriptions.add(this.betslipService.onClear.subscribe((function() {
                            n.close(!0)
                        })))
                    }, n.prototype.getDataModal = function() {
                        if (this.coreService.getCashierProfileSettings().extDataModal) try {
                            var n = JSON.parse(this.coreService.getCashierProfileSettings().extDataModal);
                            if ((null == n ? void 0 : n.message) && Array.isArray(null == n ? void 0 : n.formParams) && n.formParams.length && n.formParams.every((function(n) {
                                    return (null == n ? void 0 : n.id) && (null == n ? void 0 : n.title)
                                }))) return n
                        } catch (t) {}
                        return JSON.parse(this.externalConfigService.getEnvironmentConfig().configParams.dataModal)
                    }, n
                }())
        },
        yoGk: function(n, t, l) {
            "use strict";
            l.d(t, "b", (function() {
                return e
            })), l.d(t, "a", (function() {
                return o
            }));
            var e, i = l("CcnG");
            l("PdBy");
            ! function(n) {
                n.HORIZONTAL = "horizontal", n.VERTICAL = "vertical"
            }(e || (e = {}));
            var o = function() {
                function n() {
                    this.optionsArray = [], this.orientation = e.HORIZONTAL, this.openedChange = new i.q, this.change = new i.q, this.isOpened = !1, this.orderedGroupsOptions = []
                }
                return n.prototype.ngOnInit = function() {}, n.prototype.ngAfterContentInit = function() {
                    var n = this;
                    if (this.orientation === e.HORIZONTAL) this.orderedGroupsOptions.push(this.options.filter((function(n, t) {
                        return t % 4 == 0
                    }))), this.orderedGroupsOptions.push(this.options.filter((function(n, t) {
                        return 0 !== t && t % 4 == 1
                    }))), this.orderedGroupsOptions.push(this.options.filter((function(n, t) {
                        return 0 !== t && t % 4 == 2
                    }))), this.orderedGroupsOptions.push(this.options.filter((function(n, t) {
                        return 0 !== t && t % 4 == 3
                    })));
                    else {
                        var t = Math.ceil(this.options.length / 4);
                        this.orderedGroupsOptions.push(this.options.filter((function(n, l) {
                            return l >= 0 * t && l < 1 * t
                        }))), this.orderedGroupsOptions.push(this.options.filter((function(n, l) {
                            return l >= 1 * t && l < 2 * t
                        }))), this.orderedGroupsOptions.push(this.options.filter((function(n, l) {
                            return l >= 2 * t && l < 3 * t
                        }))), this.orderedGroupsOptions.push(this.options.filter((function(n, l) {
                            return l >= 3 * t && l < 4 * t
                        })))
                    }
                    this.optionSelected = this.options.filter((function(t) {
                        return t.value === n.languageSelected
                    }))[0], this.optionSelected.isSelected = !0, this.optionValue = this.optionsArray.find((function(t) {
                        return t.value === n.optionSelected.value
                    })).key
                }, n.prototype.toggle = function() {
                    this.isOpened = !this.isOpened && this.options.length > 1, this.openedChange.emit(this.isOpened)
                }, n.prototype.select = function(n) {
                    var t = this;
                    this.toggle(), this.optionSelected && (this.optionSelected.isSelected = !1);
                    var l = this.options.find((function(t) {
                        return t.value === n
                    }));
                    l.isSelected = !0, this.optionSelected = l, this.optionValue = this.optionsArray.find((function(n) {
                        return n.value === t.options.find((function(n) {
                            return n.isSelected
                        })).value
                    })).key, this.change.emit(this.optionSelected.value)
                }, n
            }()
        },
        zAiC: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return r
            }));
            var e, i = l("NPGq"),
                o = (e = function(n, t) {
                    return (e = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(n, t) {
                            n.__proto__ = t
                        } || function(n, t) {
                            for (var l in t) Object.prototype.hasOwnProperty.call(t, l) && (n[l] = t[l])
                        })(n, t)
                }, function(n, t) {
                    function l() {
                        this.constructor = n
                    }
                    e(n, t), n.prototype = null === t ? Object.create(t) : (l.prototype = t.prototype, new l)
                }),
                r = function(n) {
                    function t() {
                        return null !== n && n.apply(this, arguments) || this
                    }
                    return o(t, n), t.prototype.ngOnInit = function() {}, t
                }(i.a)
        },
        zUnb: function(n, t, l) {
            "use strict";
            l.r(t), l.d(t, "\u02750", (function() {
                return wu
            }));
            var e, i = l("CcnG"),
                o = l("AytR"),
                r = l("ZYCi"),
                u = l("SrN3"),
                s = l("5EE+"),
                c = l("F/XL"),
                a = l("psW0"),
                d = l("67Y/"),
                p = l("xMyE"),
                b = l("GNnp"),
                h = (l("hg3l"), l("ssOW")),
                g = l("sJrH"),
                f = function() {
                    function n(n) {
                        this.rendererFactory = n, this.renderer = this.rendererFactory.createRenderer(null, null), this.splashContainer = document.getElementsByClassName("splash-screen")[0], this.splashMessage = document.getElementsByClassName("splash-screen__message")[0]
                    }
                    return n.prototype.hide = function(n) {
                        var t = this;
                        n ? setTimeout((function() {
                            t.renderer.addClass(t.splashContainer, "splash-screen-hide"), t.cleanMessage()
                        }), n) : (this.renderer.addClass(this.splashContainer, "splash-screen-hide"), this.cleanMessage())
                    }, n.prototype.show = function() {
                        this.renderer.removeClass(this.splashContainer, "splash-screen-hide")
                    }, n.prototype.showMessage = function(n) {
                        this.renderer.setProperty(this.splashMessage, "innerHTML", n)
                    }, n.prototype.cleanMessage = function() {
                        this.renderer.setProperty(this.splashMessage, "innerHTML", "")
                    }, n.ngInjectableDef = i.ic({
                        factory: function() {
                            return new n(i.jc(i.Q))
                        },
                        token: n,
                        providedIn: "root"
                    }), n
                }(),
                m = l("t01L"),
                _ = l("5msJ"),
                v = l("26FU"),
                y = function() {
                    function n() {
                        this.buttonStatus = new v.a(!0), this.onSendTicketError = new v.a(!1)
                    }
                    return Object.defineProperty(n.prototype, "contextObject", {
                        get: function() {
                            return this._contextObject
                        },
                        set: function(n) {
                            this._contextObject = n
                        },
                        enumerable: !1,
                        configurable: !0
                    }), n
                }(),
                C = l("O0xz"),
                k = (e = function(n, t) {
                    return (e = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(n, t) {
                            n.__proto__ = t
                        } || function(n, t) {
                            for (var l in t) Object.prototype.hasOwnProperty.call(t, l) && (n[l] = t[l])
                        })(n, t)
                }, function(n, t) {
                    function l() {
                        this.constructor = n
                    }
                    e(n, t), n.prototype = null === t ? Object.create(t) : (l.prototype = t.prototype, new l)
                }),
                x = function(n) {
                    function t() {
                        return null !== n && n.apply(this, arguments) || this
                    }
                    return k(t, n), t.prototype.onBetHistory = function() {
                        this.send("onBetHistory")
                    }, t.prototype.onFindTicket = function(n) {
                        this.send("onFindTicket", n)
                    }, t.prototype.onPrintTicket = function(n) {
                        this.send("onPrintTicket", n)
                    }, t.prototype.onLogin = function(n, t, l, e, i) {
                        this.send("onLogin", n, t, l, e, i)
                    }, t.prototype.onLogout = function() {
                        this.send("onLogout")
                    }, t.prototype.onRestart = function() {
                        this.send("onRestart")
                    }, t.prototype.onUpdateWallet = function(n) {
                        this.send("onUpdateWallet", n)
                    }, t.prototype.onGameSelected = function(n) {
                        this.send("onGameSelected", n)
                    }, t.prototype.onNavigation = function(n) {
                        this.send("onNavigation", n)
                    }, t.prototype.onInitSession = function(n, t, l, e, i) {
                        this.send("onInitSession", n, t, l, e, i)
                    }, t.prototype.onDestroySession = function(n) {
                        this.send("onDestroySession", n)
                    }, t.prototype.onCatchError = function(n) {
                        this.send("onCatchError", n)
                    }, t.prototype.getContextObject = function(n) {
                        this.send("getContextObject", n)
                    }, t.prototype.onSendTicketError = function(n) {
                        this.send("onSendTicketError", n)
                    }, t
                }(C.ProductIntegration),
                I = l("15JJ"),
                S = l("VnD/"),
                w = l("ad02"),
                O = l("ee4M"),
                P = l("sB3t"),
                M = l("sylN"),
                T = function() {
                    function n() {}
                    return n.playlist = function(n) {
                        return {
                            id: "" + n.id,
                            gameType: n.gameType.val,
                            mode: n.mode,
                            description: n.description,
                            descriptionTag: n.descriptionTag
                        }
                    }, n.walletStatus = function(n) {
                        var t = n.wallet;
                        return {
                            balance: n.walletStatus.balance,
                            wallet: {
                                currency: t.currency,
                                endDate: t.endDate,
                                extData: t.extData,
                                extId: t.extId,
                                id: t.id,
                                isPromotion: t.isPromotion,
                                onCredit: t.onCredit,
                                priority: t.priority,
                                startDate: t.startDate
                            }
                        }
                    }, n.entity = function(n) {
                        return {
                            extData: n.extData,
                            extId: n.extId,
                            id: n.id,
                            name: n.name
                        }
                    }, n
                }(),
                j = function() {
                    function n(n, t, l, e, i) {
                        var o = this;
                        this.coreService = n, this.betslipService = t, this.activatedRoute = l, this.router = e, this.contextObjectService = i, this.subscriptions = [], this.integration = new x, this.integration.on("selectPlaylist", (function(n) {
                            return o.selectPlaylist(n)
                        })), this.integration.on("navigate", (function(n) {
                            return o.navigate(n)
                        })), this.integration.on("findTicket", (function(n) {
                            return o.findTicketById(n)
                        })), this.integration.on("printTicket", (function(n) {
                            return o.printTicketById(n)
                        })), this.integration.on("setContextObject", (function(n) {
                            return o.setContextObject(n)
                        })), this.integration.on("getContextObject", (function(n) {
                            return o.getContextObject()
                        })), this.integration.on("resetContextObject", (function(n) {
                            return o.setContextObject(null)
                        })), this.integration.on("enableTicketButton", (function(n) {
                            return o.setButtonStatus(!0)
                        })), this.integration.on("disableTicketButton", (function(n) {
                            return o.setButtonStatus(!1)
                        })), this.integration.start()
                    }
                    return n.prototype.ngOnDestroy = function() {
                        this.integration.stop(), this.subscriptions.forEach((function(n) {
                            return n.unsubscribe()
                        }))
                    }, n.prototype.ready = function() {
                        this.coreService.isInitialized() && (this.subscriptions = [this.onCreditUpdate(), this.onGameSelected(), this.onBetHistory(), this.onLoginChange(), this.onSendTicketError()])
                    }, n.prototype.selectPlaylist = function(n) {
                        var t = this.coreService.getPlaylistById(+n);
                        t && this.router.navigate(["cashier", Object(O.a)(t), n])
                    }, n.prototype.navigate = function(n) {
                        this.selectPlaylist(this.coreService.getPlaylistIdFromDisplayId(n))
                    }, n.prototype.findTicketById = function(n) {
                        var t = this,
                            l = this.coreService.getScanTicketModel(n);
                        if (!l.ticketId) return this.integration.onFindTicket(!1);
                        this.coreService.getTicketById(l.ticketId).pipe(Object(I.a)((function(n) {
                            return t.betslipService.printProcessByTicketStatus(n, l)
                        }))).subscribe({
                            error: function(n) {
                                t.betslipService.printTicketByIdErrorHandler(n, l.ticketId), t.integration.onFindTicket(!1)
                            }
                        })
                    }, n.prototype.printTicketById = function(n) {
                        var t = this,
                            l = this.coreService.getScanTicketModel(n);
                        if (!l.ticketId) return this.integration.onPrintTicket(!1);
                        this.coreService.getTicketById(l.ticketId, !0, !0).pipe(Object(I.a)((function(n) {
                            return t.betslipService.reprintTicketProcess(n, l)
                        }))).subscribe({
                            error: function(n) {
                                t.betslipService.reprintTicketByIdErrorHandler(n, l.ticketId), t.integration.onPrintTicket(!1)
                            }
                        })
                    }, n.prototype.setContextObject = function(n) {
                        this.contextObjectService.contextObject = n
                    }, n.prototype.getContextObject = function() {
                        this.integration.getContextObject(this.contextObjectService.contextObject)
                    }, n.prototype.setButtonStatus = function(n) {
                        this.contextObjectService.buttonStatus.next(n)
                    }, n.prototype.onCreditUpdate = function() {
                        var n = this;
                        return Object(P.a)(this.coreService.getWalletManager().onUpdateCredit).subscribe((function(t) {
                            n.integration.onUpdateWallet({
                                balance: t.walletStatus.balance,
                                wallet: t.wallet
                            })
                        }))
                    }, n.prototype.onSendTicketError = function() {
                        var n = this;
                        return this.contextObjectService.onSendTicketError.subscribe((function(t) {
                            return n.integration.onSendTicketError(t)
                        }))
                    }, n.prototype.onGameSelected = function() {
                        var n = this;
                        return this.getNavigationChange().pipe(Object(d.a)((function(t) {
                            var l = t.url.slice(-1).pop();
                            if (l && "cashier" === l.path) {
                                var e = t.firstChild.paramMap.get("playlistId");
                                return n.coreService.getPlaylistById(+e)
                            }
                            return null
                        })), Object(S.a)((function(n) {
                            return !!n
                        })), Object(w.a)(), Object(d.a)((function(n) {
                            return T.playlist(n)
                        }))).subscribe((function(t) {
                            n.integration.onGameSelected(t), n.integration.onNavigation(n.coreService.getDisplayIdFromPlaylistId(t.id))
                        }))
                    }, n.prototype.onBetHistory = function() {
                        return null
                    }, n.prototype.onLoginChange = function() {
                        var n = this;
                        return this.getNavigationChange().pipe(Object(d.a)((function(n) {
                            var t = n.url.slice(-1).pop();
                            return t && "cashier" === t.path
                        })), Object(w.a)()).subscribe((function(t) {
                            t ? n.integration.onLogin(n.getUnit(), n.getWallets(), n.getPlaylists(), n.getStaff(), n.getSessionContext()) : n.integration.onLogout()
                        }))
                    }, n.prototype.getWallets = function() {
                        return this.coreService.getWalletManager().getAllWallets().map((function(n) {
                            return T.walletStatus(n)
                        }))
                    }, n.prototype.getUnit = function() {
                        var n = this.coreService.getSessionController().getSessionSettings().auth.unit;
                        return T.entity(n)
                    }, n.prototype.getStaff = function() {
                        var n = this.coreService.getSessionController().getSessionSettings().auth.staff;
                        return T.entity(n)
                    }, n.prototype.getPlaylists = function() {
                        return this.coreService.getAllEventControllers().map((function(n) {
                            return n.content.isPlaylistContent() && n.content._clData.playlist
                        })).filter((function(n) {
                            return !!n
                        })).map((function(n) {
                            return T.playlist(n)
                        }))
                    }, n.prototype.getSessionContext = function() {
                        return this.coreService.getSessionController().sessionSettings.sessionContext
                    }, n.prototype.getNavigationChange = function() {
                        var n = this;
                        return this.router.events.pipe(Object(S.a)((function(n) {
                            return n instanceof r.d
                        })), Object(d.a)((function() {
                            return n.activatedRoute.snapshot.firstChild
                        })))
                    }, n.ngInjectableDef = i.ic({
                        factory: function() {
                            return new n(i.jc(m.a), i.jc(M.a), i.jc(r.a), i.jc(r.l), i.jc(y))
                        },
                        token: n,
                        providedIn: "root"
                    }), n
                }();

            function E(n, t, l, e, i, o, u, b, h, g) {
                return function() {
                    return new Promise((function(n) {
                        if (0 === location.hash.length) {
                            var t = location.href.split("?"),
                                l = t[0],
                                e = t[1];
                            location.href = e ? l + "#/?" + e : l + "#/"
                        }
                        n()
                    })).then((function() {
                        return l.init().pipe(Object(a.a)((function() {
                            var n = l.getEnvironmentConfig().configParams;
                            return b.i18nUrl = n.i18nUrl + "/lang", e.initI18nOnRetailCore(b).then((function() {
                                t.setInstance(e.retailController.i18n)
                            })), e.setEnvironmentConfigController(l.getEnvironmentConfig()), (n.onlineHash || n.domain && n.user && n.password) && !JSON.parse(localStorage.getItem("isLogOut")) ? e.init(l.getEnvironmentConfig()).pipe(Object(a.a)((function() {
                                return i.load({
                                    name: e.getSessionController().sessionSettings.localizationContext.skin.toLowerCase()
                                })
                            })), Object(a.a)((function() {
                                var n = e.getSessionController().sessionSettings.localizationContext.skin.toLowerCase();
                                return "default" !== n && e.setI18nLoader(b, n), e.initLocalization()
                            })), Object(a.a)((function() {
                                return "default" !== e.getSessionController().sessionSettings.localizationContext.skin.toLowerCase() && "en_GB" === t.getCurrentLanguage() ? t.reloadLanguage(t.getCurrentLanguage()) : Object(c.a)(null)
                            }))) : (t.setInstance(e.retailController.i18n), i.load({
                                name: "default"
                            }))
                        })), Object(d.a)((function() {
                            o.get(r.l).initialNavigation()
                        })), Object(p.a)((function() {
                            o.get(j).ready()
                        }))).toPromise().catch((function(e) {
                            throw t.setLoader(function(n, t) {
                                var l = "assets/i18n";
                                return t && (l = t.getEnvironmentConfig().configParams.i18nUrl + "/lang" || !1), new s.d(n, l + "/retail_", ".json", l + "/_default/retail_", "en_GB")
                            }(n, l)), t.use("en_GB").toPromise().then((function() {
                                setTimeout((function() {
                                    var n = e.message.toLowerCase(),
                                        i = l.getEnvironmentConfig().configParams.onlineHash;
                                    i && (n = n.replace(i + "_", ""));
                                    var o = u.processMessage(n),
                                        r = t.get("ch_" + o.message, {
                                            value: o.value
                                        });
                                    u.isRegistered() ? u.danger(r) : h.showMessage("ERROR: " + r)
                                }), 0)
                            })), e
                        }))
                    }))
                }
            }
            var U = u.ProfileType.CASHIER,
                A = function(n) {
                    return n.getBaseHrefFromDOM()
                },
                B = function() {},
                H = l("WGel"),
                D = l("1A4t"),
                L = function() {
                    function n(n) {
                        this.scaleService = n, this.supportedLanguages = H.SupportedLanguages
                    }
                    return n.prototype.ngOnInit = function() {
                        this.scaleService.setSize(1920, 1080), this.scaleService.setElement(document.body)
                    }, n
                }(),
                N = l("pMnS"),
                z = function() {
                    function n() {}
                    return n.prototype.ngOnInit = function() {}, n
                }(),
                R = [
                    ["[_nghost-%COMP%]{position:absolute;top:0;left:0;z-index:9;width:100%;height:100%;padding:15px 15px 15px 0}.markets-closed[_ngcontent-%COMP%]{height:100%;font-weight:700;text-align:center}.markets-closed[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]:first-child{margin-bottom:30px;font-size:64px}.markets-closed[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]:last-child{font-size:36px}"]
                ],
                W = i.Gb({
                    encapsulation: 0,
                    styles: R,
                    data: {}
                });

            function F(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 4, "div", [
                    ["class", "grid grid-column grid-center markets-closed"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 0, "span", [
                    ["class", "icon icon-hand"]
                ], null, null, null, null, null)), (n()(), i.Ib(2, 0, null, null, 2, "div", [], null, null, null, null, null)), (n()(), i.cc(3, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i])], null, (function(n, t) {
                    n(t, 3, 0, i.dc(t, 3, 0, i.Ub(t, 4).transform("ch_markets_closed")))
                }))
            }
            i.Eb("grc-markets-closed", z, (function(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-markets-closed", [], null, null, null, F, W)), i.Hb(1, 114688, null, 0, z, [], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {}, {}, []);
            var G = l("qQYQ"),
                Z = [
                    ["[_nghost-%COMP%]{position:absolute;top:0;left:0;z-index:8;width:100%;height:100%;padding:15px 15px 15px 0}.loading[_ngcontent-%COMP%]{height:100%}.splash-screen__loading[_ngcontent-%COMP%]{-webkit-animation:2s linear infinite splashScreenLoadingIndicator;animation:2s linear infinite splashScreenLoadingIndicator}@-webkit-keyframes splashScreenLoadingIndicator{from{transform:rotate(0)}to{transform:rotate(360deg)}}@keyframes splashScreenLoadingIndicator{from{transform:rotate(0)}to{transform:rotate(360deg)}}"]
                ],
                V = i.Gb({
                    encapsulation: 0,
                    styles: Z,
                    data: {}
                });

            function K(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 2, "div", [
                    ["class", "grid grid-column grid-center grid-middle loading"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 1, "div", [], null, null, null, null, null)), (n()(), i.Ib(2, 0, null, null, 0, "img", [
                    ["alt", ""],
                    ["class", "splash-screen__loading"],
                    ["src", "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAC4AAAAuCAMAAABgZ9sFAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAqUExURQAAAP///////////////////////////////////////////////////4a7yi8AAAANdFJOUwC07wpTiJzdzBtqPSzCC5LxAAABZElEQVRIx42WWRbDIAhFBTXitP/tNj3iVEXLl7FXAg+kUWo2HS3YsnwXUauTeYs556c8PO8SrRfh9AVm/PuU9nTAvMMzhl0ckPMezxmWiBJmGc+YRBoC+/IBBL7TsxLe7njtxCBbSq6XoEYZtoLNGfUNsxfYzM40HunGox6dW7k37OCendOpl6i7Z+fphKfuvigFx07tkC4H4xmPhdKctlMXcyyenWsg2cPqwVnzWXtgjdINT6x2CcrfcM8pliKpq5VCqarQxVhv9v5nMMixxxseOXaQL8Z6SYDLBDccuExxbH05U6wx4z9lNZxp7QY649Q6y+S7+5Fxv3NkjdwNXc5H4SZLDYAuo4AHAc03S+LrnIy/G7CJX8PqrM3NRR/Tpu3ogupgJjO8QZu+P73YU5/8EGLSOsUA/T+CvBDi1jZJWZneShZpD5N0d5oMg7lTM5kHRxaf67x6vyHcewbd+wWx/PgBSrMjPYgObLoAAAAASUVORK5CYII="]
                ], null, null, null, null, null))], null, null)
            }
            i.Eb("grc-loading", G.a, (function(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-loading", [], null, null, null, K, V)), i.Hb(1, 114688, null, 0, G.a, [], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {}, {}, []);
            var Y = l("Ip0R"),
                q = l("rdml"),
                X = [
                    ["[data-tooltip][_ngcontent-%COMP%]{position:relative;z-index:99999}[data-tooltip][_ngcontent-%COMP%]::before{position:absolute;bottom:100%;left:0;width:auto;padding:7px;margin-bottom:2px;font-size:16px;text-align:center;white-space:nowrap;visibility:hidden;content:attr(data-tooltip);border-radius:3px;opacity:0}[data-tooltip][_ngcontent-%COMP%]:hover::before{visibility:visible;opacity:1}"]
                ],
                J = i.Gb({
                    encapsulation: 0,
                    styles: X,
                    data: {}
                });

            function Q(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 1, "span", [], [
                    [1, "data-tooltip", 0]
                ], null, null, null, null)), i.Tb(null, 0)], null, (function(n, t) {
                    n(t, 0, 0, t.component.text)
                }))
            }
            i.Eb("grc-tooltip", q.a, (function(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-tooltip", [], null, null, null, Q, J)), i.Hb(1, 114688, null, 0, q.a, [], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                text: "text"
            }, {}, ["*"]);
            var $ = l("CrY/"),
                nn = l("7Dvu"),
                tn = function() {
                    function n(n) {
                        this.router = n, this.active = new i.q, this.gameType = "", this.iconName = "", this.gameTypeName = "", this.urlGameType = "", this.playlistName = "", this.navigateCommands = []
                    }
                    return n.prototype.ngOnInit = function() {
                        var n = this;
                        this.gameType = this.playlist.gameType.val.toLocaleLowerCase(), this.iconName = this.getIconName(), this.urlGameType = Object(O.a)(this.playlist), this.gameTypeName = this.getGameType(), this.playlistName = this.playlist.descriptionTag, this.playlistId = this.playlist.id, this.checkSpin2WinRoulette() ? this.navigateCommands = ["/cashier", this.urlGameType + "-roulette", this.playlist.id] : this.navigateCommands = ["/cashier", this.urlGameType, this.playlist.id], this.router.events.pipe(Object(S.a)((function(n) {
                            return n instanceof r.d
                        }))).subscribe((function(t) {
                            n.activated()
                        })), this.activated()
                    }, n.prototype.checkSpin2WinRoulette = function() {
                        return this.setModeAndSpinType()
                    }, n.prototype.getSpin2WinMode = function() {
                        return this.playlist.filter.isSnFilter() && this.playlist.filter.mode
                    }, n.prototype.setModeAndSpinType = function() {
                        return this.getSpin2WinMode() === $.coreModel.SnFilter.ModeEnum.ROULETTE
                    }, n.prototype.load = function() {
                        this.router.navigate(this.navigateCommands, {
                            queryParamsHandling: "merge"
                        })
                    }, n.prototype.activated = function() {
                        this.router.isActive(this.router.createUrlTree(this.navigateCommands), !1) && this.active.emit(this.playlist)
                    }, n.prototype.getIconName = function() {
                        var n;
                        return {
                            ch: this.gameType + "-" + this.getCompetitionSubType(),
                            kn: this.isKinel8() ? this.gameType + "-" + (null === (n = this.playlist) || void 0 === n ? void 0 : n.description.toLocaleLowerCase()) : this.gameType + "-" + this.getKnMode(),
                            sx: this.isKingsLuckyBall() ? "xklb" : "" + this.gameType,
                            sn: this.checkSpin2WinRoulette() ? this.gameType + "-" + this.getSnType() + "-deluxe" : this.gameType + "-" + this.getSnType() + "-" + this.getSnMode(),
                            horse: this.gameType + "-" + this.getNumParticipants(),
                            ll: "ll_live",
                            motorbike: "bike-racing",
                            rainbow: Object(nn.a)(this.playlist) ? "color-color" : this.gameType
                        }[this.gameType] || "" + this.gameType
                    }, n.prototype.getCompetitionSubType = function() {
                        var n, t;
                        return (null === (n = this.playlist) || void 0 === n ? void 0 : n.filter.isChFilter()) && (null === (t = this.playlist) || void 0 === t ? void 0 : t.filter.competitionSubType.toLocaleLowerCase())
                    }, n.prototype.getNumParticipants = function() {
                        var n, t;
                        return (null === (n = this.playlist) || void 0 === n ? void 0 : n.filter.isHorseFilter()) && (null === (t = this.playlist) || void 0 === t ? void 0 : t.filter.numParticipants)
                    }, n.prototype.getKnMode = function() {
                        var n, t;
                        return (null === (n = this.playlist) || void 0 === n ? void 0 : n.filter.isKnFilter()) && (null === (t = this.playlist) || void 0 === t ? void 0 : t.filter.mode.toLocaleLowerCase())
                    }, n.prototype.isKinel8 = function() {
                        var n, t;
                        return (null === (n = this.playlist) || void 0 === n ? void 0 : n.assets) && "kinel8" === (null === (t = this.playlist) || void 0 === t ? void 0 : t.assets.iconId)
                    }, n.prototype.getSnType = function() {
                        var n, t;
                        return (null === (n = this.playlist) || void 0 === n ? void 0 : n.filter.isSnFilter()) && (null === (t = this.playlist) || void 0 === t ? void 0 : t.filter.spinType.toLocaleLowerCase())
                    }, n.prototype.getSnMode = function() {
                        var n, t;
                        return (null === (n = this.playlist) || void 0 === n ? void 0 : n.filter.isSnFilter()) && (null === (t = this.playlist) || void 0 === t ? void 0 : t.filter.mode.toLocaleLowerCase())
                    }, n.prototype.getGameType = function() {
                        var n = "";
                        switch (this.playlist.gameType.val) {
                            case $.coreModel.GameType.ValEnum.HORSE:
                                n = "pdt_" + $.coreModel.GameType.ValEnum.HORSE.toLowerCase() + "_racing";
                                break;
                            case $.coreModel.GameType.ValEnum.TROTTING:
                                n = "pdt_" + $.coreModel.GameType.ValEnum.TROTTING.toLowerCase() + "_racing";
                                break;
                            case $.coreModel.GameType.ValEnum.DOG:
                                n = "pdt_" + $.coreModel.GameType.ValEnum.DOG.toLowerCase() + "_racing";
                                break;
                            case $.coreModel.GameType.ValEnum.SN:
                                n = "pdt_" + $.coreModel.GameType.ValEnum.SN.toLowerCase();
                                break;
                            case $.coreModel.GameType.ValEnum.MOTORBIKE:
                                n = "pdt_" + $.coreModel.GameType.ValEnum.MOTORBIKE.toLowerCase() + "_racing";
                                break;
                            case $.coreModel.GameType.ValEnum.LL:
                                n = "pdt_" + $.coreModel.GameType.ValEnum.LL.toLowerCase();
                                break;
                            case $.coreModel.GameType.ValEnum.SX:
                                n = "pdt_" + $.coreModel.GameType.ValEnum.SX.toLowerCase();
                                break;
                            case $.coreModel.GameType.ValEnum.RAINBOW:
                                n = Object(nn.a)(this.playlist) ? "pdt_colourcolour" : "pdt_" + $.coreModel.GameType.ValEnum.RAINBOW.toLowerCase();
                                break;
                            case $.coreModel.GameType.ValEnum.KN:
                                n = this.playlist && this.playlist.assets && "kinel8" === this.playlist.assets.iconId ? "pdt_k8" : "LIVE" === this.playlist.mode ? "pdt_kn_dlx_live" : "pdt_" + $.coreModel.GameType.ValEnum.KN.toLowerCase();
                                break;
                            case $.coreModel.GameType.ValEnum.SPEEDWAY:
                                n = "pdt_" + $.coreModel.GameType.ValEnum.SPEEDWAY.toLowerCase() + "_racing";
                                break;
                            case $.coreModel.GameType.ValEnum.DIRTTRACK:
                                n = "pdt_dirt_track_racing";
                                break;
                            case $.coreModel.GameType.ValEnum.CH:
                                n = "pdt_ch_" + this.getCompetitionSubType().toLowerCase();
                                break;
                            case $.coreModel.GameType.ValEnum.KART:
                                n = "pdt_" + $.coreModel.GameType.ValEnum.KART.toLowerCase() + "_racing";
                                break;
                            case $.coreModel.GameType.ValEnum.S2W:
                                n = "pdt_" + $.coreModel.GameType.ValEnum.S2W.toLowerCase();
                                break;
                            case $.coreModel.GameType.ValEnum.MMA:
                                n = "pdt_" + $.coreModel.GameType.ValEnum.MMA.toLowerCase() + "_single";
                                break;
                            default:
                                n = "Another"
                        }
                        return n
                    }, n.prototype.isKingsLuckyBall = function() {
                        var n, t, l;
                        return this.playlist && (null === (n = this.playlist) || void 0 === n ? void 0 : n.assets) && "kings_lucky_ball" === (null === (l = null === (t = this.playlist) || void 0 === t ? void 0 : t.assets) || void 0 === l ? void 0 : l.iconId)
                    }, n
                }(),
                ln = [
                    [".game-navbar-item[_ngcontent-%COMP%]{width:100%;height:90px;padding:23px 16px 22px 10px;font-weight:400;cursor:pointer;outline:0;align-items:baseline}.game-navbar-item[_ngcontent-%COMP%] > .grid[_ngcontent-%COMP%]{width:69%;height:100%;padding:0 10px 0 0}.game-navbar-item__icon[_ngcontent-%COMP%]{margin-right:10px;font-size:44px}.game-navbar-item__title[_ngcontent-%COMP%]{overflow:hidden;font-size:22px;text-overflow:ellipsis;text-transform:uppercase;white-space:nowrap}.game-navbar-item__subtitle[_ngcontent-%COMP%]{margin-bottom:2px;overflow:hidden;font-size:16px;font-weight:700;line-height:1.2;text-overflow:ellipsis;text-transform:capitalize;white-space:nowrap}"]
                ],
                en = i.Gb({
                    encapsulation: 0,
                    styles: ln,
                    data: {}
                });

            function on(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 19, "div", [
                    ["class", "grid grid-no-wrap game-navbar-item"],
                    ["queryParamsHandling", "merge"],
                    ["routerLinkActive", "game-navbar-item--active"],
                    ["tabindex", "-1"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0;
                    "click" === t && (e = !1 !== i.Ub(n, 1).onClick() && e);
                    return e
                }), null, null)), i.Hb(1, 16384, [
                    [1, 4]
                ], 0, r.m, [r.l, r.a, [8, "-1"], i.P, i.o], {
                    queryParamsHandling: [0, "queryParamsHandling"],
                    routerLink: [1, "routerLink"]
                }, null), i.Hb(2, 1720320, null, 2, r.n, [r.l, i.o, i.P, [2, r.m],
                    [2, r.o]
                ], {
                    routerLinkActive: [0, "routerLinkActive"]
                }, null), i.ac(603979776, 1, {
                    links: 1
                }), i.ac(603979776, 2, {
                    linksWithHrefs: 1
                }), (n()(), i.Ib(5, 0, null, null, 1, "div", [
                    ["class", "col-middle"]
                ], null, null, null, null, null)), (n()(), i.Ib(6, 0, null, null, 0, "span", [], [
                    [8, "className", 0]
                ], null, null, null, null)), (n()(), i.Ib(7, 0, null, null, 12, "div", [
                    ["class", "grid grid-no-wrap grid-column grid-center"]
                ], null, null, null, null, null)), (n()(), i.Ib(8, 0, null, null, 5, "grc-tooltip", [], null, null, null, Q, J)), i.Hb(9, 114688, null, 0, q.a, [], {
                    text: [0, "text"]
                }, null), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(11, 0, null, 0, 2, "div", [
                    ["class", "game-navbar-item__subtitle"]
                ], null, null, null, null, null)), (n()(), i.cc(12, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(14, 0, null, null, 5, "grc-tooltip", [], null, null, null, Q, J)), i.Hb(15, 114688, null, 0, q.a, [], {
                    text: [0, "text"]
                }, null), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(17, 0, null, 0, 2, "div", [
                    ["class", "game-navbar-item__title"]
                ], null, null, null, null, null)), (n()(), i.cc(18, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i])], (function(n, t) {
                    var l = t.component;
                    n(t, 1, 0, "merge", l.navigateCommands);
                    n(t, 2, 0, "game-navbar-item--active"), n(t, 9, 0, i.dc(t, 9, 0, i.Ub(t, 10).transform(l.playlistName))), n(t, 15, 0, i.dc(t, 15, 0, i.Ub(t, 16).transform(l.gameTypeName)))
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 6, 0, i.Mb(1, "game-icon game-icon-", l.iconName, " game-navbar-item__icon")), n(t, 12, 0, i.dc(t, 12, 0, i.Ub(t, 13).transform(l.playlistName))), n(t, 18, 0, i.dc(t, 18, 0, i.Ub(t, 19).transform(l.gameTypeName)))
                }))
            }
            i.Eb("grc-game-navbar-item", tn, (function(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-game-navbar-item", [], [
                    [8, "id", 0]
                ], null, null, on, en)), i.Hb(1, 114688, null, 0, tn, [r.l], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), (function(n, t) {
                    n(t, 0, 0, i.Ub(t, 1).playlistId)
                }))
            }), {
                playlist: "playlist"
            }, {
                active: "active"
            }, []);
            var rn = l("n3kJ"),
                un = l("pugT"),
                sn = function() {
                    function n(n, t, l, e) {
                        this.domSanitizer = n, this.coreService = t, this.router = l, this.externalConfigService = e, this.playlists = [], this.allowCashManagement = !1, this.isCashManagementOpened = !1, this.hasMoreGames = !1, this.maxItemsPerRow = 6, this.statusState = "close", this.transform = "translateY(0)", this.height = 90, this.subscriptions = new un.a
                    }
                    return n.prototype.ngOnInit = function() {
                        this.hasMoreGames = this.playlists.length > 6, this.maxItemsPerRow = this.hasMoreGames ? 6 : this.playlists.length, this.transformCollapsable = this.domSanitizer.bypassSecurityTrustStyle("rotateZ(0)"), this.subscribeShortcuts()
                    }, n.prototype.ngOnDestroy = function() {
                        this.subscriptions.unsubscribe()
                    }, n.prototype.toggleStatus = function() {
                        if ("open" === this.statusState) this.transform = "translateY(0)", this.transformCollapsable = this.domSanitizer.bypassSecurityTrustStyle("rotateZ(0)"), this.statusState = "close";
                        else {
                            var n = 90 * (Math.ceil(this.playlists.length / 6) - 1);
                            this.transform = "translateY(" + -n + "px)", this.transformCollapsable = this.domSanitizer.bypassSecurityTrustStyle("rotateZ(180deg)"), this.statusState = "open"
                        }
                    }, n.prototype.closeMenu = function() {
                        "open" === this.statusState && this.toggleStatus()
                    }, n.prototype.onGameNavbarItemActive = function(n, t) {
                        this.activeItemIndex = t, this.coreService.onPlaylistChanged.next(n)
                    }, n.prototype.goToCashPage = function() {
                        this.activeItemIndex = 0, this.router.navigate(["/cash", "cashManagement"], {
                            queryParamsHandling: "merge"
                        })
                    }, n.prototype.previousPlaylist = function() {
                        var n = this.activeItemIndex - 1;
                        n < 0 && (n = this.navbarItems.length - 1), this.loadItem(n)
                    }, n.prototype.nextPlaylist = function() {
                        var n = (this.activeItemIndex + 1) % this.navbarItems.length;
                        this.loadItem(n)
                    }, n.prototype.loadItem = function(n) {
                        var t = this.navbarItems.find((function(t, l) {
                            return l === n
                        }));
                        t && t.load()
                    }, n.prototype.subscribeShortcuts = function() {
                        var n = this;
                        this.subscriptions.add(this.coreService.onShortcut(rn.a.PreviousPlaylist).subscribe((function() {
                            n.previousPlaylist()
                        }))), this.subscriptions.add(this.coreService.onShortcut(rn.a.NextPlaylist).subscribe((function() {
                            n.nextPlaylist()
                        })))
                    }, n
                }(),
                cn = l("ZYjt"),
                an = [
                    ["[_nghost-%COMP%]{position:relative;z-index:9;display:block;padding:0 15px 0 0;overflow:visible}.game-navbar[_ngcontent-%COMP%]{position:relative;z-index:99;transition:transform .15s;min-height:90px}.game-navbar__button[_ngcontent-%COMP%]{width:77px;max-width:77px;cursor:pointer}.game-navbar__button[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{display:flex;justify-content:center;align-items:center;font-size:32px;transition:transform .15s}.game-navbar__button__cash[_ngcontent-%COMP%]{width:130px!important;max-width:130px!important;max-height:90px}.game-navbar__button__cash__icon[_ngcontent-%COMP%]{height:67px;font-size:75px!important}.game-navbar__overlay[_ngcontent-%COMP%]{position:fixed;top:0;left:0;width:100%;height:100%;opacity:0}"]
                ],
                dn = i.Gb({
                    encapsulation: 0,
                    styles: an,
                    data: {
                        animation: [{
                            type: 7,
                            name: "statusState",
                            definitions: [{
                                type: 0,
                                name: "open",
                                styles: {
                                    type: 6,
                                    styles: {
                                        opacity: .4
                                    },
                                    offset: null
                                },
                                options: void 0
                            }, {
                                type: 0,
                                name: "close",
                                styles: {
                                    type: 6,
                                    styles: {
                                        opacity: 0
                                    },
                                    offset: null
                                },
                                options: void 0
                            }, {
                                type: 1,
                                expr: "void <=> *",
                                animation: {
                                    type: 4,
                                    styles: null,
                                    timings: "350ms ease-in"
                                },
                                options: null
                            }],
                            options: {}
                        }]
                    }
                });

            function pn(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 0, "div", [
                    ["class", "game-navbar__overlay"]
                ], [
                    [24, "@statusState", 0]
                ], null, null, null, null))], null, (function(n, t) {
                    n(t, 0, 0, t.component.statusState)
                }))
            }

            function bn(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 4, "div", [
                    ["class", "col game-navbar__button game-navbar__button__cash"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.goToCashPage() && e);
                    return e
                }), null, null)), i.Zb(512, null, Y.x, Y.y, [i.A, i.B, i.o, i.P]), i.Hb(2, 278528, null, 0, Y.k, [Y.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), i.Xb(3, {
                    "game-navbar__button__cash--active": 0
                }), (n()(), i.Ib(4, 0, null, null, 0, "span", [
                    ["class", "icon icon-withdraw-ticket game-navbar__button__cash__icon"]
                ], null, null, null, null, null))], (function(n, t) {
                    var l = n(t, 3, 0, t.component.isCashManagementOpened);
                    n(t, 2, 0, "col game-navbar__button game-navbar__button__cash", l)
                }), null)
            }

            function hn(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 2, "div", [
                    ["class", "col game-navbar--border-bottom"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 1, "grc-game-navbar-item", [], [
                    [8, "id", 0]
                ], [
                    [null, "click"],
                    [null, "active"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.closeMenu() && e);
                    "active" === t && (e = !1 !== i.onGameNavbarItemActive(l, n.context.index) && e);
                    return e
                }), on, en)), i.Hb(2, 114688, [
                    [1, 4]
                ], 0, tn, [r.l], {
                    playlist: [0, "playlist"]
                }, {
                    active: "active"
                })], (function(n, t) {
                    n(t, 2, 0, t.context.$implicit)
                }), (function(n, t) {
                    n(t, 1, 0, i.Ub(t, 2).playlistId)
                }))
            }

            function gn(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "div", [
                    ["class", "col game-navbar__button"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.toggleStatus() && e);
                    return e
                }), null, null)), (n()(), i.Ib(1, 0, null, null, 0, "span", [
                    ["class", "icon icon-up"]
                ], [
                    [4, "height", "px"],
                    [4, "transform", null]
                ], null, null, null, null))], null, (function(n, t) {
                    var l = t.component;
                    n(t, 1, 0, l.height, l.transformCollapsable)
                }))
            }

            function fn(n) {
                return i.ec(2, [i.ac(671088640, 1, {
                    navbarItems: 1
                }), (n()(), i.xb(16777216, null, null, 1, null, pn)), i.Hb(2, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.Ib(3, 0, null, null, 7, "div", [
                    ["class", "grid game-navbar"]
                ], [
                    [4, "transform", null]
                ], null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, bn)), i.Hb(5, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.Ib(6, 0, null, null, 2, "div", [], [
                    [8, "className", 0]
                ], null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, hn)), i.Hb(8, 278528, null, 0, Y.l, [i.eb, i.Z, i.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, gn)), i.Hb(10, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, "open" === l.statusState), n(t, 5, 0, l.allowCashManagement), n(t, 8, 0, l.playlists), n(t, 10, 0, l.playlists.length > 6)
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 3, 0, l.transform), n(t, 6, 0, i.Mb(1, "col grid grid-", l.maxItemsPerRow, ""))
                }))
            }
            i.Eb("grc-game-navbar", sn, (function(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-game-navbar", [], null, null, null, fn, dn)), i.Hb(1, 245760, null, 0, sn, [cn.b, m.a, r.l, _.a], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                playlists: "playlists",
                allowCashManagement: "allowCashManagement",
                isCashManagementOpened: "isCashManagementOpened"
            }, {}, []);
            var mn = function() {
                    function n(n) {
                        this.cd = n, this.displayCountdown = !0, this.subscription = new un.a
                    }
                    return n.prototype.ngOnInit = function() {
                        this.onInit()
                    }, n.prototype.ngOnChanges = function(n) {
                        n.eventBlockController.isFirstChange() || this.onInit()
                    }, n.prototype.ngOnDestroy = function() {
                        this.subscription.unsubscribe()
                    }, n.prototype.onInit = function() {
                        var n = this;
                        if (this.subscription.unsubscribe(), this.subscription = new un.a, this.eventBlockController) {
                            if (this.displayCountdown = !!this.hasContentToShow(), this.eventBlockController.isEBControllerScheduled() && this.eventBlockController.getCurrentEventBlockOpen()) {
                                var t = this.eventBlockController.getCurrentEventBlockOpen()._clData.currCountdown;
                                this.setTime(t)
                            }
                            this.subscription.add(Object(P.a)(this.eventBlockController.onTickCountdown).subscribe((function(t) {
                                if (t.isCurrentEblock) return n.setTime(t.countdown)
                            }))), this.subscription.add(Object(P.a)(this.eventBlockController.onContentStatusChange).pipe(Object(I.a)((function(t) {
                                if ("HAS_CONTENT" !== t.contentStatus) return Object(P.a)(n.eventBlockController.onAllPlayerStart).pipe(Object(p.a)((function() {
                                    n.displayCountdown = !1, n.setTime()
                                })));
                                n.displayCountdown = !0
                            }))).subscribe())
                        }
                    }, n.prototype.setTime = function(n) {
                        this.time = n ? new Date(1e3 * n) : null, this.cd.markForCheck()
                    }, n.prototype.hasContentToShow = function() {
                        return "HAS_CONTENT" === this.eventBlockController.contentStatus
                    }, n
                }(),
                _n = [
                    [""]
                ],
                vn = i.Gb({
                    encapsulation: 0,
                    styles: _n,
                    data: {}
                });

            function yn(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 3, null, null, null, null, null, null, null)), (n()(), i.cc(1, null, ["", ""])), i.Xb(2, {
                    format: 0,
                    utcOffset: 1
                }), i.Wb(131072, s.c, [s.k, i.i])], null, (function(n, t) {
                    var l = t.component,
                        e = i.dc(t, 1, 0, i.Ub(t, 3).transform(l.time, "time", n(t, 2, 0, "mm:ss", 0)));
                    n(t, 1, 0, e)
                }))
            }

            function Cn(n) {
                return i.ec(0, [(n()(), i.cc(-1, null, ["--:--"]))], null, null)
            }

            function kn(n) {
                return i.ec(2, [(n()(), i.xb(16777216, null, null, 1, null, yn)), i.Hb(1, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"],
                    ngIfElse: [1, "ngIfElse"]
                }, null), (n()(), i.xb(0, [
                    ["noCountdown", 2]
                ], null, 0, null, Cn))], (function(n, t) {
                    var l = t.component;
                    n(t, 1, 0, l.eventBlockController && l.displayCountdown && l.time, i.Ub(t, 2))
                }), null)
            }
            i.Eb("grc-countdown", mn, (function(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-countdown", [], null, null, null, kn, vn)), i.Hb(1, 770048, null, 0, mn, [i.i], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                eventBlockController: "eventBlockController"
            }, {}, []);
            var xn = function() {
                    function n(n, t, l, e) {
                        this.cd = n, this.coreService = t, this.notificationService = l, this.i18NService = e, this.TargetType = $.JackpotInternalType, this.subscriptions = new un.a
                    }
                    return n.prototype.ngOnInit = function() {
                        var n = this,
                            t = this.coreService.getSessionController();
                        this.jackpot = t.jackpotManager.getJackpots().find((function(t) {
                            return t.jackpotSetting.jackpotId.toLowerCase() === n.jackpotId.toLowerCase()
                        })), this.subscriptions.add(Object(P.a)(this.coreService.getSessionController().jackpotManager.onUpdateJackpotAmount).subscribe((function(t) {
                            t.jackpotSetting.jackpotId.toLowerCase() === n.jackpotId.toLowerCase() && (n.jackpot = t, n.cd.detectChanges())
                        }))), this.subscriptions.add(Object(P.a)(this.coreService.getSessionController().jackpotManager.onUpdateJackpotWin).subscribe((function(t) {
                            n.showNotification(t) && n.notificationService.success(n.messageNotification(t))
                        })))
                    }, n.prototype.ngOnDestroy = function() {
                        this.subscriptions.unsubscribe()
                    }, n.prototype.showNotification = function(n) {
                        return n.jackpotSetting.jackpotId.toLowerCase() === this.jackpot.jackpotSetting.jackpotId.toLowerCase() && (this.thisUserWonJackpot() || this.otherUserWonJackpot(n)) && null != this.jackpot.jackpotStatus
                    }, n.prototype.messageNotification = function(n) {
                        var t = n.jackpotSetting.jackpotDesc + " " + this.i18NService.location.getCredit(this.jackpot.jackpotStatus.lastTicket.amount) + " - " + (this.i18NService.get("ch_ticket_won") + " #" + this.jackpot.jackpotStatus.lastTicket.ticketId);
                        this.otherUserWonJackpot(n) && (t += " - " + n.jackpotStatus.lastTicket.entity.name + " " + this.i18NService.location.getDate(n.jackpotStatus.lastTicket.date, "time"));
                        return t
                    }, n.prototype.thisUserWonJackpot = function() {
                        return this.jackpot.jackpotStatus.lastTicket.entity.id === this.coreService.getSessionController().sessionSettings.auth.unit.id
                    }, n.prototype.otherUserWonJackpot = function(n) {
                        var t = this.coreService.getWalletManager().getCurrentWallet().currency.code;
                        return !this.thisUserWonJackpot() && t === n.jackpotStatus.currency
                    }, n
                }(),
                In = [
                    [".jackpot[_ngcontent-%COMP%]{height:100%;padding:0 10px 0 20px}.jackpot__name[_ngcontent-%COMP%]{margin-right:20px;font-size:16px;font-weight:400}.jackpot__value[_ngcontent-%COMP%]{font-size:32px}"]
                ],
                Sn = i.Gb({
                    encapsulation: 0,
                    styles: In,
                    data: {}
                });

            function wn(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 6, "div", [
                    ["class", "grid grid-middle grid-space-between jackpot"]
                ], [
                    [2, "jackpot--blue", null],
                    [2, "jackpot--pink", null]
                ], null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 1, "span", [
                    ["class", "jackpot__name"]
                ], null, null, null, null, null)), (n()(), i.cc(2, null, [" ", " "])), (n()(), i.Ib(3, 0, null, null, 3, "span", [
                    ["class", "jackpot__value"]
                ], null, null, null, null, null)), (n()(), i.cc(4, null, ["", " "])), i.Xb(5, {
                    currency: 0
                }), i.Wb(131072, s.b, [s.k, i.i])], null, (function(n, t) {
                    var l = t.component;
                    n(t, 0, 0, l.jackpot.internalType === l.TargetType.LOCAL, l.jackpot.internalType === l.TargetType.NETWORK), n(t, 2, 0, l.jackpot.jackpotSetting.jackpotDesc);
                    var e = i.dc(t, 4, 0, i.Ub(t, 6).transform(l.jackpot.jackpotStatus.amount, n(t, 5, 0, l.jackpot.jackpotStatus._clData.currency)));
                    n(t, 4, 0, e)
                }))
            }
            i.Eb("grc-jackpot", xn, (function(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-jackpot", [], null, null, null, wn, Sn)), i.Hb(1, 245760, null, 0, xn, [i.i, m.a, b.a, s.k], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                jackpotId: "jackpotId"
            }, {}, []);
            var On = function() {
                    for (var n = 0, t = 0, l = arguments.length; t < l; t++) n += arguments[t].length;
                    var e = Array(n),
                        i = 0;
                    for (t = 0; t < l; t++)
                        for (var o = arguments[t], r = 0, u = o.length; r < u; r++, i++) e[i] = o[r];
                    return e
                },
                Pn = function() {
                    function n(n) {
                        this.cd = n
                    }
                    return n.prototype.ngOnInit = function() {
                        var n = this;
                        this.jackpots = this.jackpotIds.slice(0, 2), this.jackpotIds.length > 2 && (this.jackpotIds = On(this.jackpotIds, [this.jackpotIds[0]]), setInterval((function() {
                            var t = n.jackpotIds.indexOf(n.jackpots[1]);
                            n.jackpots = [n.jackpots[1]], n.cd.markForCheck(), setTimeout((function() {
                                n.jackpots.push(n.jackpotIds[t + 1]), n.cd.markForCheck()
                            }), 500)
                        }), 1e4))
                    }, n
                }(),
                Mn = [
                    [".jackpot-container[_ngcontent-%COMP%]{height:100%}"]
                ],
                Tn = i.Gb({
                    encapsulation: 0,
                    styles: Mn,
                    data: {
                        animation: [{
                            type: 7,
                            name: "jackpotsAnimation",
                            definitions: [{
                                type: 0,
                                name: "*",
                                styles: {
                                    type: 6,
                                    styles: {
                                        opacity: 1
                                    },
                                    offset: null
                                },
                                options: void 0
                            }, {
                                type: 1,
                                expr: ":enter",
                                animation: [{
                                    type: 6,
                                    styles: {
                                        opacity: 0
                                    },
                                    offset: null
                                }, {
                                    type: 4,
                                    styles: null,
                                    timings: 1e3
                                }],
                                options: null
                            }, {
                                type: 1,
                                expr: ":leave",
                                animation: [{
                                    type: 4,
                                    styles: {
                                        type: 6,
                                        styles: {
                                            transform: "translateX(100%)",
                                            opacity: 0
                                        },
                                        offset: null
                                    },
                                    timings: 500
                                }],
                                options: null
                            }],
                            options: {}
                        }]
                    }
                });

            function jn(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-jackpot", [
                    ["class", "col"]
                ], [
                    [24, "@jackpotsAnimation", 0]
                ], null, null, wn, Sn)), i.Hb(1, 245760, null, 0, xn, [i.i, m.a, b.a, s.k], {
                    jackpotId: [0, "jackpotId"]
                }, null)], (function(n, t) {
                    n(t, 1, 0, t.context.$implicit)
                }), (function(n, t) {
                    n(t, 0, 0, void 0)
                }))
            }

            function En(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 2, "div", [
                    ["class", "grid grid-column jackpot-container"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, jn)), i.Hb(2, 278528, null, 0, Y.l, [i.eb, i.Z, i.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(n, t) {
                    n(t, 2, 0, t.component.jackpots)
                }), null)
            }
            i.Eb("grc-jackpot-container", Pn, (function(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-jackpot-container", [], null, null, null, En, Tn)), i.Hb(1, 114688, null, 0, Pn, [i.i], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                jackpotIds: "jackpotIds"
            }, {}, []);
            var Un = l("NTJ2"),
                An = function() {
                    function n(n, t, l, e) {
                        this.cd = n, this.externalConfigService = t, this.coreService = l, this.basePageService = e, this.isCashManagementOpened = !1, this.hideNotificationTopBar = !1, this.hasButtonText = !1, this.hideHeaderLogo = !1, this.hideViewerButton = !1, this.unitId = 0, this.unitName = "", this.subscription = new un.a, this.shortCutSubscription = new un.a
                    }
                    return n.prototype.ngOnInit = function() {
                        var n, t = this;
                        this.subscription.add(this.basePageService.headerState.subscribe((function(n) {
                            var l;
                            t.headerState = n, t.buttons = t.headerState.buttons, t.playList = t.headerState.playList, t.gameType = null === (l = t.playList) || void 0 === l ? void 0 : l.gameType.val.toLocaleLowerCase(), t.hideNotificationTopBar = t.coreService.hideNotificationTopBar(), t.setShortcuts(), t.cd.markForCheck(), t.setButtonIconType(), t.hasButtonText = t.coreService.hasButtonText(), t.hideHeaderLogo = t.coreService.hideHeaderLogo(), t.iconName = t.getIconName(), t.hideViewerButton = t.headerState.hideViewerButton
                        }))), this.jackpotIds = this.coreService.getJackpots().map((function(n) {
                            return n.jackpotId
                        }));
                        var l = this.coreService.getSessionController();
                        this.unitId = l.sessionSettings.auth.unit.id, this.unitName = l.sessionSettings.auth.unit.name, this.showJackpot = null === (n = this.coreService.getCashierProfileSettings().showJackpot) || void 0 === n || n
                    }, n.prototype.ngOnDestroy = function() {
                        this.subscription.unsubscribe(), this.shortCutSubscription && this.shortCutSubscription.unsubscribe()
                    }, n.prototype.setShortcuts = function() {
                        var n = this;
                        this.shortCutSubscription.unsubscribe(), this.shortCutSubscription = new un.a, this.buttons.forEach((function(t) {
                            t.shortcuts && !t.disabled && t.shortcuts.forEach((function(l) {
                                n.shortCutSubscription.add(n.coreService.onShortcut(l).subscribe((function() {
                                    t.callback()
                                })))
                            }))
                        }))
                    }, n.prototype.setButtonIconType = function() {
                        var n = this;
                        this.buttons.forEach((function(t) {
                            "ch_league_table" === t.title ? t.iconType = "icon-league-table" : "ch_pay_table" === t.title ? t.iconType = "icon-paytable" : "ch_results_history" === t.title ? t.iconType = "icon-results" : "ch_standings" === t.title ? t.iconType = "icon-league-table" : "ch_game_rules" === t.title && (t.iconType = "icon-question-mark", t.hideGameRules = n.hideGameRules)
                        }))
                    }, Object.defineProperty(n.prototype, "hideGameRules", {
                        get: function() {
                            return this.coreService.getCashierProfileSettings().hideRules
                        },
                        enumerable: !1,
                        configurable: !0
                    }), n.prototype.getIconName = function() {
                        var n;
                        return {
                            ch: this.gameType + "-" + this.getCompetitionSubType(),
                            kn: this.isKinel8() ? this.gameType + "-" + (null === (n = this.playList) || void 0 === n ? void 0 : n.description.toLocaleLowerCase()) : this.gameType + "-" + this.getKnMode(),
                            sx: this.isKingsLuckyBall() ? "xklb" : "" + this.gameType,
                            sn: this.gameType + "-" + this.getSnType() + "-" + this.getSnMode(),
                            horse: this.gameType + "-" + this.getNumParticipants(),
                            motorbike: "bike-racing",
                            rainbow: Object(nn.a)(this.playList) ? "color-color" : this.gameType
                        }[this.gameType] || "" + this.gameType
                    }, n.prototype.onNavigateViewer = function() {
                        var n = "",
                            t = ["height=" + screen.availHeight, "width=" + screen.availWidth, "fullscreen=1", "toolbar=0", "menubar=0", "location=0", "status=no", "top=0", "left=0", "directories=no", "channelmode=no", "history=no", "maximize=true"].join(",");
                        this.hwId = this.coreService.getHwId(this.coreService.getEnvironmentConfigController()), this.currentDisplayID = this.coreService.getDisplayIdFromPlaylistId(this.playList.id.toString())[0], this.launcherUrl = this.externalConfigService.getEnvironmentConfig().configParams.launcherUrl, this.launcherUrl = this.launcherUrl ? this.launcherUrl : "launcher", n = this.hwId ? window.location.protocol + "//" + window.location.host + "/" + this.launcherUrl + "/" + this.hwId + "/" + this.currentDisplayID : window.location.protocol + "//" + window.location.host + "/" + this.launcherUrl + "/", window.open(n, "_blank", t)
                    }, n.prototype.getCompetitionSubType = function() {
                        var n, t;
                        return (null === (n = this.playList) || void 0 === n ? void 0 : n.filter.isChFilter()) && (null === (t = this.playList) || void 0 === t ? void 0 : t.filter.competitionSubType.toLocaleLowerCase())
                    }, n.prototype.getNumParticipants = function() {
                        var n, t;
                        return (null === (n = this.playList) || void 0 === n ? void 0 : n.filter.isHorseFilter()) && (null === (t = this.playList) || void 0 === t ? void 0 : t.filter.numParticipants)
                    }, n.prototype.getKnMode = function() {
                        var n, t;
                        return (null === (n = this.playList) || void 0 === n ? void 0 : n.filter.isKnFilter()) && (null === (t = this.playList) || void 0 === t ? void 0 : t.filter.mode.toLocaleLowerCase())
                    }, n.prototype.isKinel8 = function() {
                        var n, t;
                        return (null === (n = this.playList) || void 0 === n ? void 0 : n.assets) && "kinel8" === (null === (t = this.playList) || void 0 === t ? void 0 : t.assets.iconId)
                    }, n.prototype.getSnType = function() {
                        var n, t;
                        return (null === (n = this.playList) || void 0 === n ? void 0 : n.filter.isSnFilter()) && (null === (t = this.playList) || void 0 === t ? void 0 : t.filter.spinType.toLocaleLowerCase())
                    }, n.prototype.getSnMode = function() {
                        var n, t;
                        return (null === (n = this.playList) || void 0 === n ? void 0 : n.filter.isSnFilter()) && (null === (t = this.playList) || void 0 === t ? void 0 : t.filter.mode.toLocaleLowerCase())
                    }, n.prototype.isKingsLuckyBall = function() {
                        var n, t, l;
                        return this.playList && (null === (n = this.playList) || void 0 === n ? void 0 : n.assets) && "kings_lucky_ball" === (null === (l = null === (t = this.playList) || void 0 === t ? void 0 : t.assets) || void 0 === l ? void 0 : l.iconId)
                    }, n
                }(),
                Bn = [
                    [".header[_ngcontent-%COMP%]{height:100%;font-weight:700}.header__top[_ngcontent-%COMP%]{height:25px;padding:0 30px}.header__logo[_ngcontent-%COMP%]{height:100%;margin:0 22px;text-align:center;background-repeat:no-repeat;background-position:center;background-size:contain}.header__separator[_ngcontent-%COMP%]{max-width:2px;height:80%}.header__unit[_ngcontent-%COMP%]{margin:0 8px}.header__unit--name[_ngcontent-%COMP%]{margin:0 20px 0 8px;text-transform:capitalize}.header__point[_ngcontent-%COMP%]{position:relative;top:-4px}.header__version[_ngcontent-%COMP%]{font-size:16px;vertical-align:top}.header-info[_ngcontent-%COMP%]{height:100%;overflow:hidden}.header-info__countdown[_ngcontent-%COMP%]{align-self:center;padding:0 10px 0 40px;font-size:36px;font-weight:400}.header-info__game[_ngcontent-%COMP%]{max-width:700px;padding:10px;overflow:hidden;font-size:36px;text-overflow:ellipsis;text-transform:capitalize;white-space:nowrap}.header-info__event[_ngcontent-%COMP%]{padding:8px 35px;margin-right:22px;margin-left:15px;font-size:18px;text-transform:uppercase}.header-info__button[_ngcontent-%COMP%]{padding:8px 22px;margin-right:20px;font-size:18px;text-transform:uppercase;cursor:pointer}.header-info__button--disabled[_ngcontent-%COMP%]{cursor:default;opacity:.3}.header-info__button-icon[_ngcontent-%COMP%]{border-radius:50%;cursor:pointer;font-size:25px;padding:4.5px 11px;margin-right:10px;height:40px;width:40px;display:inline-block}.header-info__button-icon--disabled[_ngcontent-%COMP%]{cursor:default;opacity:.3}.header-info__button-text[_ngcontent-%COMP%]{margin:0 5px 0 10px;font-size:18px;border-radius:2px;padding:8px 10px;text-transform:uppercase;cursor:pointer}.header-info__button-text--disabled[_ngcontent-%COMP%]{cursor:default;opacity:.3}.header-info__icon[_ngcontent-%COMP%]{align-self:center;font-size:40px}.header-info__icon--cashTicket[_ngcontent-%COMP%]{font-size:70px;padding:0 20px 0 40px}.header-info__jackpot[_ngcontent-%COMP%]{height:100%}.header-info__viewer-btn[_ngcontent-%COMP%]{margin-right:30px;border-radius:50px;height:38px;text-transform:uppercase;padding:0 8px;cursor:pointer}.header-info__viewer-btn--text[_ngcontent-%COMP%]{padding:12px}.header-info__icon-launcher[_ngcontent-%COMP%]{margin-right:6px}.header-info__icon-launcher[_ngcontent-%COMP%]   img[_ngcontent-%COMP%]{width:20px;height:22px}.header-info[_ngcontent-%COMP%]   .header-cash-ticket[_ngcontent-%COMP%]{align-items:self-end;margin-bottom:12px}"]
                ],
                Hn = i.Gb({
                    encapsulation: 0,
                    styles: Bn,
                    data: {}
                });

            function Dn(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 11, "div", [
                    ["class", "grid grid-middle header__top"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 10, "div", [
                    ["class", "header__version"]
                ], null, null, null, null, null)), (n()(), i.Ib(2, 0, null, null, 0, "span", [
                    ["class", "header__icon icon icon-home"]
                ], null, null, null, null, null)), (n()(), i.Ib(3, 0, null, null, 1, "span", [
                    ["class", "header__unit"]
                ], null, null, null, null, null)), (n()(), i.cc(4, null, ["", ""])), (n()(), i.Ib(5, 0, null, null, 1, "span", [
                    ["class", "col header__point"]
                ], null, null, null, null, null)), (n()(), i.cc(-1, null, ["."])), (n()(), i.Ib(7, 0, null, null, 1, "span", [
                    ["class", "header__unit header__unit--name"]
                ], null, null, null, null, null)), (n()(), i.cc(8, null, ["", ""])), (n()(), i.Ib(9, 0, null, null, 2, "span", [], null, null, null, null, null)), (n()(), i.cc(10, null, ["", ": 1.72.9-5"])), i.Wb(131072, s.j, [s.k, i.i])], null, (function(n, t) {
                    var l = t.component;
                    n(t, 4, 0, l.unitId), n(t, 8, 0, l.unitName), n(t, 10, 0, i.dc(t, 10, 0, i.Ub(t, 11).transform("ch_version")))
                }))
            }

            function Ln(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 2, null, null, null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 0, "div", [
                    ["class", "col header__logo"]
                ], null, null, null, null, null)), (n()(), i.Ib(2, 0, null, null, 0, "div", [
                    ["class", "col header__separator"]
                ], null, null, null, null, null))], null, null)
            }

            function Nn(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 2, "span", [
                    ["class", "header-info__countdown"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 1, "grc-countdown", [], null, null, null, kn, vn)), i.Hb(2, 770048, null, 0, mn, [i.i], {
                    eventBlockController: [0, "eventBlockController"]
                }, null)], (function(n, t) {
                    n(t, 2, 0, t.component.headerState.countdownEventBlockController)
                }), null)
            }

            function zn(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 0, "span", [], [
                    [8, "className", 0]
                ], null, null, null, null))], null, (function(n, t) {
                    var l = t.component;
                    n(t, 0, 0, i.Mb(1, "game-icon game-icon-", l.iconName, " header-info__icon"))
                }))
            }

            function Rn(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 0, "span", [
                    ["class", "icon icon-withdraw-ticket header-info__icon header-info__icon--cashTicket"]
                ], null, null, null, null, null))], null, null)
            }

            function Wn(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 6, "div", [
                    ["class", "col grid grid-middle grid-right"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 5, "div", [
                    ["class", "grid grid-middle grid-center header-info__viewer-btn text-center"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.onNavigateViewer() && e);
                    return e
                }), null, null)), (n()(), i.Ib(2, 0, null, null, 1, "span", [
                    ["class", "col header-info__icon-launcher"]
                ], null, null, null, null, null)), (n()(), i.Ib(3, 0, null, null, 0, "img", [
                    ["src", "./assets/images/launcher.svg"]
                ], null, null, null, null, null)), (n()(), i.Ib(4, 0, null, null, 2, "span", [
                    ["class", "col header-info__viewer-btn--text"]
                ], null, null, null, null, null)), (n()(), i.cc(5, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i])], null, (function(n, t) {
                    n(t, 5, 0, i.dc(t, 5, 0, i.Ub(t, 6).transform("ch_viewer")))
                }))
            }

            function Fn(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "span", [], [
                    [8, "className", 0],
                    [8, "title", 0]
                ], [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0;
                    "click" === t && (e = !1 !== (!n.parent.parent.context.$implicit.disabled && n.parent.parent.context.$implicit.callback()) && e);
                    return e
                }), null, null)), i.Wb(131072, s.j, [s.k, i.i])], null, (function(n, t) {
                    n(t, 0, 0, i.Mb(1, "header-info__button-icon icon ", t.parent.parent.context.$implicit.iconType, ""), i.Mb(1, "", i.dc(t, 0, 1, i.Ub(t, 1).transform(t.parent.parent.context.$implicit.title)), ""))
                }))
            }

            function Gn(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 2, null, null, null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, Fn)), i.Hb(2, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(0, null, null, 0))], (function(n, t) {
                    n(t, 2, 0, !t.parent.context.$implicit.disabled && !t.parent.context.$implicit.hideGameRules)
                }), null)
            }

            function Zn(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 2, "span", [
                    ["class", "header-info__button-text"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0;
                    "click" === t && (e = !1 !== (!n.parent.parent.context.$implicit.disabled && n.parent.parent.context.$implicit.callback()) && e);
                    return e
                }), null, null)), (n()(), i.cc(1, null, [" ", " "])), i.Wb(131072, s.j, [s.k, i.i])], null, (function(n, t) {
                    n(t, 1, 0, i.dc(t, 1, 0, i.Ub(t, 2).transform(t.parent.parent.context.$implicit.title)))
                }))
            }

            function Vn(n) {
                return i.ec(0, [(n()(), i.xb(16777216, null, null, 1, null, Zn)), i.Hb(1, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(0, null, null, 0))], (function(n, t) {
                    n(t, 1, 0, !t.parent.context.$implicit.disabled && !t.parent.context.$implicit.hideGameRules)
                }), null)
            }

            function Kn(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 3, "div", [
                    ["class", "col-middle"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, Gn)), i.Hb(2, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"],
                    ngIfElse: [1, "ngIfElse"]
                }, null), (n()(), i.xb(0, [
                    ["buttonText", 2]
                ], null, 0, null, Vn))], (function(n, t) {
                    n(t, 2, 0, !t.component.hasButtonText, i.Ub(t, 3))
                }), null)
            }

            function Yn(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 2, "div", [
                    ["class", "col-middle"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 1, "span", [
                    ["class", "header-info__event"]
                ], null, null, null, null, null)), (n()(), i.cc(2, null, ["", ""]))], null, (function(n, t) {
                    n(t, 2, 0, t.component.headerState.eventName)
                }))
            }

            function qn(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-jackpot-container", [
                    ["class", "col col-3"]
                ], null, null, null, En, Tn)), i.Hb(1, 114688, null, 0, Pn, [i.i], {
                    jackpotIds: [0, "jackpotIds"]
                }, null)], (function(n, t) {
                    n(t, 1, 0, t.component.jackpotIds)
                }), null)
            }

            function Xn(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 28, "div", [
                    ["class", "grid grid-column header"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, Dn)), i.Hb(2, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.Ib(3, 0, null, null, 25, "div", [
                    ["class", "col grid grid-middle"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, Ln)), i.Hb(5, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.Ib(6, 0, null, null, 22, "div", [
                    ["class", "col header-info grid grid-no-wrap"]
                ], null, null, null, null, null)), (n()(), i.Ib(7, 0, null, null, 15, "div", [
                    ["class", "col col-middle grid"]
                ], null, null, null, null, null)), i.Zb(512, null, Y.x, Y.y, [i.A, i.B, i.o, i.P]), i.Hb(9, 278528, null, 0, Y.k, [Y.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), i.Xb(10, {
                    "header-cash-ticket": 0
                }), (n()(), i.xb(16777216, null, null, 1, null, Nn)), i.Hb(12, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.Ib(13, 0, null, null, 2, "div", [
                    ["class", "col-middle"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, zn)), i.Hb(15, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, Rn)), i.Hb(17, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.Ib(18, 0, null, null, 2, "span", [
                    ["class", "col header-info__game"]
                ], null, null, null, null, null)), (n()(), i.cc(19, null, [" ", " "])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.xb(16777216, null, null, 1, null, Wn)), i.Hb(22, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, Kn)), i.Hb(24, 278528, null, 0, Y.l, [i.eb, i.Z, i.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, Yn)), i.Hb(26, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, qn)), i.Hb(28, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, !l.hideNotificationTopBar), n(t, 5, 0, !l.hideHeaderLogo);
                    var e = n(t, 10, 0, l.isCashManagementOpened);
                    n(t, 9, 0, "col col-middle grid", e), n(t, 12, 0, l.playList), n(t, 15, 0, l.iconName && !l.isCashManagementOpened), n(t, 17, 0, l.isCashManagementOpened), n(t, 22, 0, !l.hideViewerButton), n(t, 24, 0, l.buttons), n(t, 26, 0, l.headerState.eventName), n(t, 28, 0, l.showJackpot && l.jackpotIds.length)
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 19, 0, i.dc(t, 19, 0, i.Ub(t, 20).transform(l.headerState.gameName)))
                }))
            }
            i.Eb("grc-header", An, (function(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-header", [], null, null, null, Xn, Hn)), i.Hb(1, 245760, null, 0, An, [i.i, _.a, m.a, Un.a], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                isCashManagementOpened: "isCashManagementOpened"
            }, {}, []);
            var Jn = l("XAsR"),
                Qn = l("M3um"),
                $n = l("7oEI"),
                nt = l("jMZ0"),
                tt = function() {
                    function n(n, t, l, e, o, r) {
                        this.modalService = n, this.notificationsService = t, this.betslipService = l, this.i18NService = e, this.coreService = o, this.changeDetector = r, this.hasLastAction = !1, this.hasLastActionChange = new i.q, this.minOdd = 0, this.maxOdd = 0, this.numberOfCombinations = 0, this.typeErrors = ["MAXPAYOUTPERBET", "MAXSTAKEPERBET", "MINSTAKEPERBET", "ROUNDINGSTEP", "TICKETPOLICY"], this.subscriptions = new un.a
                    }
                    return n.prototype.ngOnInit = function() {
                        var n = this;
                        this.update(), this.subscriptions.add(this.betslipService.onTicketBetUpdated.subscribe((function() {
                            n.update(), n.changeDetector.detectChanges()
                        })))
                    }, n.prototype.ngOnDestroy = function() {
                        this.subscriptions.unsubscribe()
                    }, n.prototype.openKeypad = function() {
                        var n = this;
                        this.betslipService.enableFastbet(!1), this.betslipService.disableSendTicketShortcut(), this.modalService.open("base", nt.b, {
                            inputs: {
                                title: this.i18NService.get("ch_stake"),
                                type: nt.a.Number
                            },
                            outputs: {
                                success: function(t) {
                                    n.insertStake(+t), n.modalService.close("base")
                                }
                            }
                        }).afterClosed.subscribe(null, null, (function() {
                            n.betslipService.enableFastbet(!0), n.betslipService.enableSendTicketShortcut()
                        }))
                    }, n.prototype.setMinOdd = function() {
                        this.combination ? (this.minOdd = this.combination._clData.getMinWinningItemized().minOdd, this.minOdd > this.combination._clData.getMinWinningItemized().limit && (this.minOdd = this.combination._clData.getMinWinningItemized().limit)) : this.minOdd = this.bet.minOdd
                    }, n.prototype.setMaxOdd = function() {
                        this.combination ? (this.maxOdd = this.combination._clData.getMaxWinningItemized().maxOdd, this.maxOdd > this.combination._clData.getMaxWinningItemized().limit && (this.maxOdd = this.combination._clData.getMaxWinningItemized().limit)) : this.maxOdd = this.bet.maxOdd
                    }, n.prototype.setNumberOfCombinationsOfSingleBet = function() {
                        if (!this.combination) {
                            var n = this.bet.betParam.split(";")[0].split(",").length,
                                t = this.bet.betParam.split(";")[1].split(",").length;
                            this.numberOfCombinations = n * t
                        }
                    }, n.prototype.update = function() {
                        var n = this;
                        this.combination && (this.hasSystemErrors(), this.typeErrors.some((function(t) {
                            return n.hasStakeError(t)
                        }))), this.setMaxOdd(), this.setMinOdd(), this.setNumberOfCombinationsOfSingleBet()
                    }, n.prototype.insertStake = function(n) {
                        this.hasLastActionChange.emit(!0), this.combination ? this.betslipService.setCombiStake([{
                            stake: n,
                            combiGroup: this.combination.grouping
                        }]) : (this.betslipService.setSingleStakeByBets(n), this.changeDetector.markForCheck())
                    }, n.prototype.adjustStake = function(n) {
                        n > -1 && this.insertStake(n)
                    }, n.prototype.hasStakeError = function(n) {
                        var t = this.coreService.getBetSlip().getSystemBetErrors().filter((function(t) {
                            return t.stakeError.errorType.some((function(t) {
                                return t === n
                            }))
                        }));
                        if (t.length > 0 && this.combination.grouping === t[0].sysBet.grouping) {
                            var l = void 0;
                            switch (l = t[0].stakeError.adjustedStake, n) {
                                case "MAXPAYOUTPERBET":
                                    l = -1, this.showError("ch_max_payout_combinations", t[0].ticketPolicyError.isError);
                                    break;
                                case "MINSTAKEPERBET":
                                    this.showError("ch_minimum_stake", t[0].stakeError.minStakePerBetLimit);
                                    break;
                                case "MAXSTAKEPERBET":
                                    this.showError("ch_maximum_stake", t[0].stakeError.maxStakePerBetLimit);
                                    break;
                                case "ROUNDINGSTEP":
                                    this.showError("ch_rounding_stake_error", t[0].stakeError.adjustedStake);
                                    break;
                                case "TICKETPOLICY":
                                    this.showTicketPolicyError(t[0].ticketPolicyError, t[0].stakeError.adjustedStake)
                            }
                            return this.adjustStake(l), l > -1
                        }
                    }, n.prototype.hasSystemErrors = function() {
                        var n = this.coreService.getBetSlip().getSystemBetErrors();
                        n.length > 0 && (n[0].maxCombiCountError.isError && (this.showError("ch_maximum_combinations"), n[0].maxCombiCountError.limit), n[0].invalidSystemBetError.isError && this.showError("ch_invalid_systembet"))
                    }, n.prototype.showError = function(n, t) {
                        t ? this.notificationsService.warning(this.i18NService.get("ch_default_value_applied") + "<br> " + this.i18NService.get(n, {
                            stakeLimit: t
                        })) : this.notificationsService.warning("" + this.i18NService.get(n))
                    }, n.prototype.showTicketPolicyError = function(n, t) {
                        t ? n.step && this.showError("ch_spain_ticket_policy_combi_error", n.step) : this.showError("betslip_maxpayoutadjuststakeerror")
                    }, n
                }(),
                lt = [
                    [".betslip-combination[_ngcontent-%COMP%]{width:100%;padding:8px 10px;font-size:18px}.betslip-combination__stake[_ngcontent-%COMP%]{padding:4px;cursor:pointer;border-radius:1px}.betslip-combination__right[_ngcontent-%COMP%]{max-width:72px;overflow:hidden;text-align:right;text-overflow:ellipsis;white-space:nowrap}"]
                ],
                et = i.Gb({
                    encapsulation: 0,
                    styles: lt,
                    data: {}
                });

            function it(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 23, "div", [
                    ["class", "grid grid-middle betslip-combination"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 1, "div", [
                    ["class", "col col-2"]
                ], null, null, null, null, null)), (n()(), i.cc(2, null, ["", ""])), (n()(), i.Ib(3, 0, null, null, 1, "div", [
                    ["class", "col col-2"]
                ], null, null, null, null, null)), (n()(), i.cc(4, null, ["", ""])), (n()(), i.Ib(5, 0, null, null, 4, "div", [
                    ["class", "col"]
                ], null, null, null, null, null)), (n()(), i.Ib(6, 0, null, null, 3, "div", [
                    ["class", "betslip-combination__stake betslip-combination__right"]
                ], [
                    [2, "betslip-combination__stake--highlight", null]
                ], [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.openKeypad() && e);
                    return e
                }), null, null)), (n()(), i.cc(7, null, [" ", " "])), i.Xb(8, {
                    showSymbol: 0
                }), i.Wb(131072, s.b, [s.k, i.i]), (n()(), i.Ib(10, 0, null, null, 6, "div", [
                    ["class", "col"]
                ], null, null, null, null, null)), (n()(), i.Ib(11, 0, null, null, 5, "grc-tooltip", [], null, null, null, Q, J)), i.Hb(12, 114688, null, 0, q.a, [], {
                    text: [0, "text"]
                }, null), (n()(), i.Ib(13, 0, null, 0, 3, "div", [
                    ["class", "betslip-combination__right"]
                ], null, null, null, null, null)), (n()(), i.cc(14, null, ["", ""])), i.Xb(15, {
                    condensed: 0,
                    showSymbol: 1,
                    noZeros: 2
                }), i.Wb(131072, s.b, [s.k, i.i]), (n()(), i.Ib(17, 0, null, null, 6, "div", [
                    ["class", "col"]
                ], null, null, null, null, null)), (n()(), i.Ib(18, 0, null, null, 5, "grc-tooltip", [], null, null, null, Q, J)), i.Hb(19, 114688, null, 0, q.a, [], {
                    text: [0, "text"]
                }, null), (n()(), i.Ib(20, 0, null, 0, 3, "div", [
                    ["class", "betslip-combination__right"]
                ], null, null, null, null, null)), (n()(), i.cc(21, null, ["", ""])), i.Xb(22, {
                    condensed: 0,
                    showSymbol: 1,
                    noZeros: 2
                }), i.Wb(131072, s.b, [s.k, i.i])], (function(n, t) {
                    var l = t.component;
                    n(t, 12, 0, l.minOdd), n(t, 19, 0, l.maxOdd)
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, l.combination ? l.combination.grouping : 2), n(t, 4, 0, l.combination ? l.combination.systemCount : l.numberOfCombinations), n(t, 6, 0, l.hasLastAction);
                    var e = i.dc(t, 7, 0, i.Ub(t, 9).transform(l.combination ? l.combination._clData.getInputStake() : l.bet._clData.getStakeSingleItemized().gross, n(t, 8, 0, !1)));
                    n(t, 7, 0, e);
                    var o = i.dc(t, 14, 0, i.Ub(t, 16).transform(l.minOdd, n(t, 15, 0, !0, !1, !0)));
                    n(t, 14, 0, o);
                    var r = i.dc(t, 21, 0, i.Ub(t, 23).transform(l.maxOdd, n(t, 22, 0, !0, !1, !0)));
                    n(t, 21, 0, r)
                }))
            }
            i.Eb("grc-betslip-combination", tt, (function(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-betslip-combination", [], null, null, null, it, et)), i.Hb(1, 245760, null, 0, tt, [$n.a, b.a, M.a, s.k, m.a, i.i], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                combination: "combination",
                bet: "bet",
                hasLastAction: "hasLastAction"
            }, {
                hasLastActionChange: "hasLastActionChange"
            }, []);
            var ot = l("nYwI"),
                rt = function() {
                    function n(n, t, l, e, o, r) {
                        this.cd = n, this.betslipService = t, this.i18NService = l, this.coreService = e, this.notificationsService = o, this.modalService = r, this.showStake = !0, this.combinationsUpdated = new i.q, this.subscriptions = new un.a
                    }
                    return n.prototype.ngOnInit = function() {
                        this.subscribeToBetslipChange()
                    }, n.prototype.ngOnDestroy = function() {
                        this.subscriptions.unsubscribe()
                    }, n.prototype.openKeypad = function(n) {
                        var t = this;
                        this.betslipService.enableFastbet(!1), this.betslipService.disableSendTicketShortcut(), this.modalService.open("base", nt.b, {
                            inputs: {
                                title: this.i18NService.get("ch_stake"),
                                type: nt.a.Number
                            },
                            outputs: {
                                success: function(l) {
                                    var e = t.insertStake(n, l);
                                    t.betslipService.onChangedStake.next({
                                        ticketBet: n,
                                        stake: Number(l)
                                    }), t.betslipService.onBetErrors.next({
                                        errors: e
                                    }), t.modalService.close("base")
                                }
                            }
                        }).afterClosed.subscribe(null, null, (function() {
                            t.betslipService.enableFastbet(!0), t.betslipService.enableSendTicketShortcut()
                        }))
                    }, n.prototype.insertStake = function(n, t) {
                        return this.betslipService.setStakeForSingleBet(n, Number(t), this.ticketEvent.eventId, this.ticketEvent.playlistId)
                    }, n.prototype.removeTicketBet = function(n) {
                        this.betslipService.removeBet(this.ticketEvent.playlistId, this.ticketEvent.eventId, n.oddId, n.betParam)
                    }, n.prototype.getPrefixMarket = function(n) {
                        return this.configuration.prefixMarket ? this.configuration.prefixMarket(n) : ""
                    }, n.prototype.getSuffixMarket = function(n) {
                        return this.configuration.suffixMarket ? this.configuration.suffixMarket(n) : ""
                    }, n.prototype.getOddName = function(n, t) {
                        if (this.configuration.oddName) {
                            var l = "",
                                e = this.coreService.getPlaylistById(this.ticketEvent.playlistId);
                            if (Object(nn.a)(e, n)) l = ot.a.oddName(n, H.I18NGameType[t.val], this.i18NService, H.TagsProfile.TICKET, e.assets);
                            else l = this.configuration.oddName(n, H.I18NGameType[t.val], this.i18NService);
                            return l
                        }
                        return ""
                    }, n.prototype.isSystemSpin2Wheels = function(n) {
                        return "SystemMultiplier" === n.marketId || "SystemDoubleChance" === n.marketId
                    }, n.prototype.hasSeveralSuffixes = function(n) {
                        return this.getSuffixMarket(n) instanceof Array
                    }, n.prototype.removeElementFromBetParam = function(n, t) {
                        isNaN(+n) && (n = t ? "W18" + n : "W36" + n);
                        var l = this.getLastBetFromBetslip();
                        l.betParam.split(";")[t].split(",").length > 2 || l.betParam.split(";")[t].split(",").length > 1 && l.betParam.split(";")[t ? 0 : 1].split(",").length > 1 ? (l.betParam = t ? l.betParam.split(";")[0] + ";" + l.betParam.split(";")[1].split(",").filter((function(t) {
                            return t !== n
                        })).join(",") : l.betParam.split(";")[0].split(",").filter((function(t) {
                            return t !== n
                        })).join(",") + ";" + l.betParam.split(";")[1], this.combinationsUpdated.emit(), this.cd.markForCheck()) : this.notificationsService.info("" + this.i18NService.get("ch_no_more_bets_can_be_removed"))
                    }, n.prototype.getOddValue = function(n, t) {
                        var l = this.coreService.getSessionController().sessionSettings.calculationContext.oddContext.gameOddSettings.find((function(n) {
                                return "S2wGameOddSettings" === n.classType
                            })),
                            e = l && l.payTable;
                        return isNaN(+n) ? t ? e["w18_" + n.toLowerCase()] : e["w36_" + n.toLowerCase()] : t ? e.w18_numbers : e.w36_numbers
                    }, n.prototype.subscribeToBetslipChange = function() {
                        var n = this;
                        this.subscriptions.add(this.betslipService.onTicketBetAdded.subscribe((function() {
                            n.cd.markForCheck()
                        }))), this.subscriptions.add(this.betslipService.onTicketBetRemoved.subscribe((function() {
                            n.cd.markForCheck()
                        }))), this.subscriptions.add(this.betslipService.onStake.subscribe((function() {
                            n.cd.markForCheck()
                        }))), this.subscriptions.add(this.betslipService.onConfiguration.subscribe((function(t) {
                            var l = t.ticketEventTitle(n.ticketEvent);
                            n.ticketEventOrder = +l.order, n.ticketEventTitle = l.title, n.configuration = t
                        })))
                    }, n.prototype.getLastBetFromBetslip = function() {
                        var n = this.betslipService.getBetslipInfo().events[0];
                        return null == n ? void 0 : n.bets[n.bets.length - 1]
                    }, n
                }(),
                ut = [
                    ["[_nghost-%COMP%]{font-size:18px}.betslip-ticket-event[_ngcontent-%COMP%]{font-size:20px}.betslip-ticket-event__header[_ngcontent-%COMP%]{padding:8px 8px 0;margin-bottom:10px}.betslip-ticket-event__order[_ngcontent-%COMP%]{padding:2px 5px}.betslip-ticket-event__title[_ngcontent-%COMP%]{padding:2px 10px}.betslip-ticket-bet[_ngcontent-%COMP%]{width:100%;margin-bottom:8px;text-transform:capitalize;word-wrap:break-word}.betslip-ticket-bet[_ngcontent-%COMP%]:last-child{margin-bottom:12px}.betslip-ticket-bet__icon[_ngcontent-%COMP%]{cursor:pointer}.betslip-ticket-bet__system-mode[_ngcontent-%COMP%]{padding:5px;margin:0 0 0 8px}.betslip-ticket-bet__system-mode--alternative[_ngcontent-%COMP%]{margin:0 8px 0 0}.betslip-ticket-bet__combination[_ngcontent-%COMP%]{width:100%}.betslip-ticket-bet__combination-header[_ngcontent-%COMP%]{padding:5px;margin-top:8px}.betslip-ticket-bet__combination-header--right[_ngcontent-%COMP%]{text-align:right}.betslip-ticket-bet__odd-name[_ngcontent-%COMP%]{padding:8px 8px 0}.betslip-ticket-bet__cancel[_ngcontent-%COMP%]{padding:8px 8px 0 0}.betslip-ticket-bet__bet-param-group[_ngcontent-%COMP%]{padding:5px 0}.betslip-ticket-bet__bet-param[_ngcontent-%COMP%]{height:22px;padding:5px 0;font-family:DIN;font-size:18px;font-weight:500}.betslip-ticket-bet__stake[_ngcontent-%COMP%]{padding:0 4px;margin-left:8px;cursor:pointer;border-radius:1px}.betslip-ticket-bet__stake--single-bet-mode[_ngcontent-%COMP%]{max-width:80px;max-height:25px;background-color:#f6f6f6}.betslip-ticket-bet__right[_ngcontent-%COMP%]{max-width:72px;overflow:hidden;text-align:right;text-overflow:ellipsis;white-space:nowrap}.icon[_ngcontent-%COMP%]{font-size:18px}"]
                ],
                st = i.Gb({
                    encapsulation: 0,
                    styles: ut,
                    data: {}
                });

            function ct(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "span", [], null, null, null, null, null)), (n()(), i.cc(-1, null, ["0"]))], null, null)
            }

            function at(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 3, "span", [
                    ["class", "betslip-ticket-event__order"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, ct)), i.Hb(2, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.cc(3, null, ["", " "]))], (function(n, t) {
                    n(t, 2, 0, t.component.ticketEventOrder < 10)
                }), (function(n, t) {
                    n(t, 3, 0, t.component.ticketEventOrder)
                }))
            }

            function dt(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 8, "div", [
                    ["class", "grid self-center-middle betslip-ticket-bet__bet-param"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 1, "div", [
                    ["class", "col-7"]
                ], null, null, null, null, null)), (n()(), i.cc(2, null, [" ", " "])), (n()(), i.Ib(3, 0, null, null, 2, "div", [
                    ["class", "col-3"]
                ], null, null, null, null, null)), (n()(), i.Ib(4, 0, null, null, 1, "span", [], null, null, null, null, null)), (n()(), i.cc(5, null, ["", ""])), (n()(), i.Ib(6, 0, null, null, 2, "div", [
                    ["class", "col-2 text-right"]
                ], null, null, null, null, null)), (n()(), i.Ib(7, 0, null, null, 1, "span", [
                    ["class", "betslip-ticket-bet__icon"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.removeElementFromBetParam(n.context.$implicit, n.parent.context.index) && e);
                    return e
                }), null, null)), (n()(), i.Ib(8, 0, null, null, 0, "span", [
                    ["class", "icon icon-cancel"]
                ], null, null, null, null, null))], null, (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, t.context.$implicit), n(t, 5, 0, l.getOddValue(t.context.$implicit, t.parent.context.index))
                }))
            }

            function pt(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 6, "div", [
                    ["class", "betslip-ticket-bet__bet-param-group"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 3, "div", [
                    ["class", ""]
                ], null, null, null, null, null)), (n()(), i.cc(2, null, [" ", " "])), i.Vb(3, 2), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.xb(16777216, null, null, 1, null, dt)), i.Hb(6, 278528, null, 0, Y.l, [i.eb, i.Z, i.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(n, t) {
                    var l = t.context.$implicit.split(",");
                    n(t, 6, 0, l)
                }), (function(n, t) {
                    var l = i.dc(t, 2, 0, i.Ub(t, 4).transform(n(t, 3, 0, "betslip_wheel_36", "betslip_wheel_18")[t.context.index]));
                    n(t, 2, 0, l)
                }))
            }

            function bt(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 2, null, null, null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, pt)), i.Hb(2, 278528, null, 0, Y.l, [i.eb, i.Z, i.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), (n()(), i.xb(0, null, null, 0))], (function(n, t) {
                    n(t, 2, 0, t.component.getSuffixMarket(t.parent.parent.context.$implicit))
                }), null)
            }

            function ht(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "span", [], null, null, null, null, null)), (n()(), i.cc(1, null, [" ", "", "", " "]))], null, (function(n, t) {
                    var l = t.component;
                    n(t, 1, 0, l.getPrefixMarket(t.parent.parent.context.$implicit), l.getOddName(t.parent.parent.context.$implicit, l.ticketEvent.gameType), l.getSuffixMarket(t.parent.parent.context.$implicit))
                }))
            }

            function gt(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 30, null, null, null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 6, "div", [
                    ["class", "col-12 grid"]
                ], null, null, null, null, null)), (n()(), i.Ib(2, 0, null, null, 2, "span", [
                    ["class", "betslip-ticket-bet__system-mode"]
                ], null, null, null, null, null)), (n()(), i.cc(3, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(5, 0, null, null, 2, "span", [
                    ["class", "betslip-ticket-bet__system-mode betslip-ticket-bet__system-mode--alternative"]
                ], null, null, null, null, null)), (n()(), i.cc(6, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(8, 0, null, null, 3, "div", [
                    ["class", "betslip-ticket-bet__odd-name col-12"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, bt)), i.Hb(10, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"],
                    ngIfElse: [1, "ngIfElse"]
                }, null), (n()(), i.xb(0, [
                    ["oneSuffixTemplate", 2]
                ], null, 0, null, ht)), (n()(), i.Ib(12, 0, null, null, 0, "div", [
                    ["class", "col-3 text-right"]
                ], null, null, null, null, null)), (n()(), i.Ib(13, 0, null, null, 15, "div", [
                    ["class", "col-12 grid betslip-ticket-bet__combination-header"]
                ], null, null, null, null, null)), (n()(), i.Ib(14, 0, null, null, 2, "div", [
                    ["class", "col-2"]
                ], null, null, null, null, null)), (n()(), i.cc(15, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(17, 0, null, null, 2, "div", [
                    ["class", "col-2"]
                ], null, null, null, null, null)), (n()(), i.cc(18, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(20, 0, null, null, 2, "div", [
                    ["class", "col betslip-ticket-bet__combination-header--right"]
                ], null, null, null, null, null)), (n()(), i.cc(21, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(23, 0, null, null, 2, "div", [
                    ["class", "col betslip-ticket-bet__combination-header--right"]
                ], null, null, null, null, null)), (n()(), i.cc(24, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(26, 0, null, null, 2, "div", [
                    ["class", "col betslip-ticket-bet__combination-header--right"]
                ], null, null, null, null, null)), (n()(), i.cc(27, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(29, 0, null, null, 1, "grc-betslip-combination", [
                    ["class", "betslip-ticket-bet__combination"]
                ], null, null, null, it, et)), i.Hb(30, 245760, null, 0, tt, [$n.a, b.a, M.a, s.k, m.a, i.i], {
                    bet: [0, "bet"]
                }, null)], (function(n, t) {
                    n(t, 10, 0, t.component.hasSeveralSuffixes(t.parent.context.$implicit), i.Ub(t, 11)), n(t, 30, 0, t.parent.context.$implicit)
                }), (function(n, t) {
                    n(t, 3, 0, i.dc(t, 3, 0, i.Ub(t, 4).transform("betslip_system")));
                    var l = i.dc(t, 6, 0, i.Ub(t, 7).transform("betslip_" + t.parent.context.$implicit.marketId.toLowerCase()));
                    n(t, 6, 0, l), n(t, 15, 0, i.dc(t, 15, 0, i.Ub(t, 16).transform("ch_size"))), n(t, 18, 0, i.dc(t, 18, 0, i.Ub(t, 19).transform("ch_combs"))), n(t, 21, 0, i.dc(t, 21, 0, i.Ub(t, 22).transform("ch_stake"))), n(t, 24, 0, i.dc(t, 24, 0, i.Ub(t, 25).transform("ch_min"))), n(t, 27, 0, i.dc(t, 27, 0, i.Ub(t, 28).transform("ch_max")))
                }))
            }

            function ft(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 3, "span", [], null, null, null, null, null)), (n()(), i.cc(1, null, [" ", " "])), i.Xb(2, {
                    showSymbol: 0
                }), i.Wb(131072, s.b, [s.k, i.i])], null, (function(n, t) {
                    var l = i.dc(t, 1, 0, i.Ub(t, 3).transform(t.parent.parent.context.$implicit._clData.getInputStake(), n(t, 2, 0, !1)));
                    n(t, 1, 0, l)
                }))
            }

            function mt(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 2, "div", [
                    ["class", "col col-5"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 1, "span", [], null, null, null, null, null)), (n()(), i.cc(2, null, [" ", "", "", " "])), (n()(), i.Ib(3, 0, null, null, 2, "div", [
                    ["class", "col col-3 text-right text-odd-value-color"]
                ], null, null, null, null, null)), (n()(), i.Ib(4, 0, null, null, 1, "span", [], null, null, null, null, null)), (n()(), i.cc(5, null, ["", ""])), (n()(), i.Ib(6, 0, null, null, 2, "div", [
                    ["class", "col col-3 text-right betslip-ticket-bet__stake betslip-ticket-bet__right"]
                ], [
                    [2, "betslip-ticket-bet__stake--single-bet-mode", null]
                ], [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.openKeypad(n.parent.context.$implicit) && e);
                    return e
                }), null, null)), (n()(), i.xb(16777216, null, null, 1, null, ft)), i.Hb(8, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.Ib(9, 0, null, null, 2, "div", [
                    ["class", "col col-1 text-right"]
                ], null, null, null, null, null)), (n()(), i.Ib(10, 0, null, null, 1, "span", [
                    ["class", "betslip-ticket-bet__icon"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.removeTicketBet(n.parent.context.$implicit) && e);
                    return e
                }), null, null)), (n()(), i.Ib(11, 0, null, null, 0, "span", [
                    ["class", "icon icon-cancel"]
                ], null, null, null, null, null))], (function(n, t) {
                    n(t, 8, 0, t.component.showStake)
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, l.getPrefixMarket(t.parent.context.$implicit), l.getOddName(t.parent.context.$implicit, l.ticketEvent.gameType), l.getSuffixMarket(t.parent.context.$implicit)), n(t, 5, 0, t.parent.context.$implicit.oddValue), n(t, 6, 0, l.showStake)
                }))
            }

            function _t(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 3, "div", [
                    ["class", "grid betslip-ticket-bet"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, gt)), i.Hb(2, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"],
                    ngIfElse: [1, "ngIfElse"]
                }, null), (n()(), i.xb(0, [
                    ["defaultBet", 2]
                ], null, 0, null, mt))], (function(n, t) {
                    n(t, 2, 0, t.component.isSystemSpin2Wheels(t.context.$implicit), i.Ub(t, 3))
                }), null)
            }

            function vt(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 8, null, null, null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 7, "div", [
                    ["class", "betslip-ticket-event"]
                ], null, null, null, null, null)), (n()(), i.Ib(2, 0, null, null, 4, "div", [
                    ["class", "betslip-ticket-event__header"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, at)), i.Hb(4, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.Ib(5, 0, null, null, 1, "span", [
                    ["class", "betslip-ticket-event__title"]
                ], null, null, null, null, null)), (n()(), i.cc(6, null, [" ", " "])), (n()(), i.xb(16777216, null, null, 1, null, _t)), i.Hb(8, 278528, null, 0, Y.l, [i.eb, i.Z, i.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(n, t) {
                    var l = t.component;
                    n(t, 4, 0, l.ticketEventOrder), n(t, 8, 0, l.ticketEvent.bets)
                }), (function(n, t) {
                    n(t, 6, 0, t.component.ticketEventTitle)
                }))
            }

            function yt(n) {
                return i.ec(2, [(n()(), i.xb(16777216, null, null, 1, null, vt)), i.Hb(1, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(n, t) {
                    n(t, 1, 0, t.component.ticketEvent.bets.length)
                }), null)
            }
            i.Eb("grc-betslip-ticket-event", rt, (function(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-betslip-ticket-event", [], null, null, null, yt, st)), i.Hb(1, 245760, null, 0, rt, [i.i, M.a, s.k, m.a, b.a, $n.a], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                ticketEvent: "ticketEvent",
                showStake: "showStake"
            }, {
                combinationsUpdated: "combinationsUpdated"
            }, []);
            var Ct = function() {
                    function n(n) {
                        this.modalService = n, this.lastActionGroups = [], this.lastActionGroupChange = new i.q
                    }
                    return n.prototype.ngOnChanges = function(n) {
                        var t;
                        n.combinations && !n.combinations.isFirstChange() && (null === (t = n.combinations.previousValue) || void 0 === t ? void 0 : t.length) !== n.combinations.currentValue.length && this.modalService.close("base")
                    }, n.prototype.ngOnDestroy = function() {
                        this.modalService.close("base")
                    }, n.prototype.combinationHasLastAction = function(n) {
                        return this.lastActionGroups.includes(n)
                    }, n.prototype.onHasLastActionChange = function(n) {
                        this.lastActionGroups = [n], this.lastActionGroupChange.emit(this.lastActionGroups)
                    }, n
                }(),
                kt = [
                    [".betslip-combinations[_ngcontent-%COMP%]{font-size:18px;text-transform:capitalize}.betslip-combinations__header[_ngcontent-%COMP%]{padding:3px 10px}.betslip-combinations__header--right[_ngcontent-%COMP%]{text-align:right}"]
                ],
                xt = i.Gb({
                    encapsulation: 0,
                    styles: kt,
                    data: {}
                });

            function It(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 15, "div", [
                    ["class", "grid betslip-combinations__header"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 2, "div", [
                    ["class", "col col-2"]
                ], null, null, null, null, null)), (n()(), i.cc(2, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(4, 0, null, null, 2, "div", [
                    ["class", "col col-2"]
                ], null, null, null, null, null)), (n()(), i.cc(5, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(7, 0, null, null, 2, "div", [
                    ["class", "col betslip-combinations__header--right"]
                ], null, null, null, null, null)), (n()(), i.cc(8, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(10, 0, null, null, 2, "div", [
                    ["class", "col betslip-combinations__header--right"]
                ], null, null, null, null, null)), (n()(), i.cc(11, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(13, 0, null, null, 2, "div", [
                    ["class", "col betslip-combinations__header--right"]
                ], null, null, null, null, null)), (n()(), i.cc(14, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i])], null, (function(n, t) {
                    n(t, 2, 0, i.dc(t, 2, 0, i.Ub(t, 3).transform("ch_size"))), n(t, 5, 0, i.dc(t, 5, 0, i.Ub(t, 6).transform("ch_combs"))), n(t, 8, 0, i.dc(t, 8, 0, i.Ub(t, 9).transform("ch_stake"))), n(t, 11, 0, i.dc(t, 11, 0, i.Ub(t, 12).transform("ch_min"))), n(t, 14, 0, i.dc(t, 14, 0, i.Ub(t, 15).transform("ch_max")))
                }))
            }

            function St(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-betslip-combination", [
                    ["class", "grid grid-middle betslip-combination"]
                ], null, [
                    [null, "hasLastActionChange"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "hasLastActionChange" === t && (e = !1 !== i.onHasLastActionChange(n.context.$implicit.grouping) && e);
                    return e
                }), it, et)), i.Hb(1, 245760, null, 0, tt, [$n.a, b.a, M.a, s.k, m.a, i.i], {
                    combination: [0, "combination"],
                    hasLastAction: [1, "hasLastAction"]
                }, {
                    hasLastActionChange: "hasLastActionChange"
                })], (function(n, t) {
                    var l = t.component;
                    n(t, 1, 0, t.context.$implicit, l.combinationHasLastAction(t.context.$implicit.grouping))
                }), null)
            }

            function wt(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 4, "div", [
                    ["class", "betslip-combinations"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, It)), i.Hb(2, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, St)), i.Hb(4, 278528, null, 0, Y.l, [i.eb, i.Z, i.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, l.combinations && l.combinations.length > 0), n(t, 4, 0, l.combinations)
                }), null)
            }
            i.Eb("grc-betslip-combinations", Ct, (function(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-betslip-combinations", [], null, null, null, wt, xt)), i.Hb(1, 704512, null, 0, Ct, [$n.a], null, null)], null, null)
            }), {
                combinations: "combinations",
                lastActionGroups: "lastActionGroups",
                bet: "bet"
            }, {
                lastActionGroupChange: "lastActionGroupChange"
            }, []);
            var Ot = l("mv7g"),
                Pt = l("+69r"),
                Mt = l("GhKF"),
                Tt = l("3cbp"),
                jt = l("gIcY"),
                Et = function() {
                    function n(n, t, l) {
                        this.cd = n, this.betslipService = t, this.modalService = l, this.disabledKeys = [], this.combinations = new i.q, this.opened = new i.q, this.code = "", this.isHidden = !0, this.isEnabled = !0, this.subscriptions = new un.a, this.allowedKeys = /^[a-zA-Z0-9\*\/\-\|\+%\.]$/, this.nextKey = ""
                    }
                    return n.prototype.ngOnInit = function() {
                        var n = this,
                            t = this.isFastbetDisabledInBackOffice();
                        this.subscribeToFastbetEvents(t), this.subscribeToBetslipChanges(), document.addEventListener("keydown", (function(t) {
                            n.modalService.dataDialogOpened || n.onKeyDown(t)
                        }))
                    }, n.prototype.ngOnDestroy = function() {
                        this.subscriptions.unsubscribe()
                    }, n.prototype.hasCode = function() {
                        return this.code && this.code.length > 0
                    }, n.prototype.onKeyDown = function(n) {
                        var t = this;
                        this.isEnabled && this.parser && this.allowedKeys.test(n.key) && !this.isDisabledKey(n) && (this.nextKey += n.key, this.clearIfHasTimeOut(), this.checkTimeout = setTimeout((function() {
                            t.clearIfIsBarcode(), t.parseCode(t.nextKey), t.nextKey = ""
                        }), 90))
                    }, n.prototype.sendCombinations = function() {
                        var n = this.results.filter((function(n) {
                            return !!n.combiGroup
                        })).map((function(n) {
                            return n.combiGroup
                        }));
                        n.length > 0 && this.combinations.emit(n)
                    }, n.prototype.onBackspace = function() {
                        this.isEnabled && (this.code = this.code.slice(0, this.code.length - 1), 0 === this.code.length && (this.isHidden = !0, this.opened.emit(!1)), this.parseCode(), this.cd.detectChanges())
                    }, n.prototype.onEnter = function() {
                        this.isEnabled && !this.modalService.dataDialogOpened && (this.results && this.results.length > 0 && (this.betslipService.addFastBetResults(this.results), this.sendCombinations(), this.code = "", this.results = [], this.isHidden = !0, this.opened.emit(!1)), this.cd.markForCheck())
                    }, n.prototype.openFastbetHelp = function() {
                        this.betslipService.openFastbetHelp()
                    }, n.prototype.isDisabledKey = function(n) {
                        return this.disabledKeys.some((function(t) {
                            return t.key.toLowerCase() === n.key.toLowerCase() && t.ctrlKey === n.ctrlKey && t.shiftKey === n.shiftKey && t.altKey === n.altKey
                        }))
                    }, n.prototype.clearIfIsBarcode = function() {
                        this.checkIsBarcode(this.nextKey) && (this.nextKey = "")
                    }, n.prototype.clearIfHasTimeOut = function() {
                        this.checkTimeout && clearTimeout(this.checkTimeout)
                    }, n.prototype.parseCode = function(n) {
                        void 0 === n && (n = "");
                        var t = n;
                        try {
                            this.results = this.parser.parse("" + this.code.toLowerCase() + n.toLowerCase())
                        } catch (l) {
                            this.results = [], l && l.location && l.location.start && (t = n.substr(0, l.location.start.offset - this.code.length))
                        }
                        t && (this.code += t, this.isHidden && this.opened.emit(!0), this.isHidden = !1, this.cd.markForCheck())
                    }, n.prototype.subscribeToFastbetEvents = function(n) {
                        var t = this;
                        this.subscriptions.add(this.betslipService.onFastbetEnableChange.subscribe((function(l) {
                            return t.isEnabled = l && !n
                        }))), this.subscriptions.add(this.betslipService.onFastbetParserChange.subscribe((function(n) {
                            t.parser = n, t.clearFastbet(), t.cd.markForCheck()
                        })))
                    }, n.prototype.checkIsBarcode = function(n) {
                        void 0 === n && (n = "");
                        return !!n.match(/(\d{9,20}\D{0,5})$/)
                    }, n.prototype.clearFastbet = function() {
                        this.code = "", this.results = [], this.isHidden = !0
                    }, n.prototype.subscribeToBetslipChanges = function() {
                        var n = this;
                        this.subscriptions.add(this.betslipService.onClear.subscribe((function() {
                            n.clearFastbet(), n.opened.emit(!1), n.cd.markForCheck()
                        })))
                    }, n.prototype.isFastbetDisabledInBackOffice = function() {
                        return this.betslipService.isFastBetDisabledBackOffice()
                    }, n
                }(),
                Ut = [
                    ["[_nghost-%COMP%]{position:relative;left:-5px;display:block;width:calc(100% + 10px)}.betslip-fastbet[_ngcontent-%COMP%]{padding:0 0 0 15px;margin-bottom:20px;font-size:20px;font-weight:700}.betslip-fastbet__info[_ngcontent-%COMP%]{padding:15px 12px;font-size:20px;cursor:pointer}.betslip-fastbet__info[_ngcontent-%COMP%] > span.icon[_ngcontent-%COMP%]{font-size:20px}.betslip-fastbet__code[_ngcontent-%COMP%]{width:100%;font-family:inherit;font-size:inherit;text-transform:uppercase;pointer-events:none;background-color:transparent;border:0;outline:0}.betslip-fastbet--hidden[_ngcontent-%COMP%]{display:none}"]
                ],
                At = i.Gb({
                    encapsulation: 0,
                    styles: Ut,
                    data: {}
                });

            function Bt(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 9, "div", [
                    ["class", "grid grid-middle betslip-fastbet"]
                ], [
                    [2, "betslip-fastbet--hidden", null]
                ], null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 6, "div", [
                    ["class", "col"]
                ], null, null, null, null, null)), (n()(), i.Ib(2, 0, null, null, 5, "input", [
                    ["class", "betslip-fastbet__code"],
                    ["type", "text"]
                ], [
                    [2, "ng-untouched", null],
                    [2, "ng-touched", null],
                    [2, "ng-pristine", null],
                    [2, "ng-dirty", null],
                    [2, "ng-valid", null],
                    [2, "ng-invalid", null],
                    [2, "ng-pending", null]
                ], [
                    [null, "keydown"],
                    [null, "ngModelChange"],
                    [null, "input"],
                    [null, "blur"],
                    [null, "compositionstart"],
                    [null, "compositionend"]
                ], (function(n, t, l) {
                    var e = !0,
                        o = n.component;
                    "input" === t && (e = !1 !== i.Ub(n, 3)._handleInput(l.target.value) && e);
                    "blur" === t && (e = !1 !== i.Ub(n, 3).onTouched() && e);
                    "compositionstart" === t && (e = !1 !== i.Ub(n, 3)._compositionStart() && e);
                    "compositionend" === t && (e = !1 !== i.Ub(n, 3)._compositionEnd(l.target.value) && e);
                    "keydown" === t && (e = !1 !== l.preventDefault() && e);
                    "ngModelChange" === t && (e = !1 !== (o.code = l) && e);
                    return e
                }), null, null)), i.Hb(3, 16384, null, 0, jt.d, [i.P, i.o, [2, jt.a]], null, null), i.Zb(1024, null, jt.h, (function(n) {
                    return [n]
                }), [jt.d]), i.Hb(5, 671744, null, 0, jt.m, [
                    [8, null],
                    [8, null],
                    [8, null],
                    [6, jt.h]
                ], {
                    model: [0, "model"]
                }, {
                    update: "ngModelChange"
                }), i.Zb(2048, null, jt.i, null, [jt.m]), i.Hb(7, 16384, null, 0, jt.j, [
                    [4, jt.i]
                ], null, null), (n()(), i.Ib(8, 0, null, null, 1, "div", [
                    ["class", "betslip-fastbet__info"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.openFastbetHelp() && e);
                    return e
                }), null, null)), (n()(), i.Ib(9, 0, null, null, 0, "span", [
                    ["class", "icon icon-questionmark"]
                ], null, null, null, null, null))], (function(n, t) {
                    n(t, 5, 0, t.component.code)
                }), (function(n, t) {
                    n(t, 0, 0, t.component.isHidden), n(t, 2, 0, i.Ub(t, 7).ngClassUntouched, i.Ub(t, 7).ngClassTouched, i.Ub(t, 7).ngClassPristine, i.Ub(t, 7).ngClassDirty, i.Ub(t, 7).ngClassValid, i.Ub(t, 7).ngClassInvalid, i.Ub(t, 7).ngClassPending)
                }))
            }
            i.Eb("grc-betslip-fastbet", Et, (function(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-betslip-fastbet", [], null, [
                    ["document", "keydown.backspace"],
                    ["document", "keyup.enter"]
                ], (function(n, t, l) {
                    var e = !0;
                    "document:keydown.backspace" === t && (e = !1 !== i.Ub(n, 1).onBackspace() && e);
                    "document:keyup.enter" === t && (e = !1 !== i.Ub(n, 1).onEnter() && e);
                    return e
                }), Bt, At)), i.Hb(1, 245760, null, 0, Et, [i.i, M.a, $n.a], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                disabledKeys: "disabledKeys"
            }, {
                combinations: "combinations",
                opened: "opened"
            }, []);
            var Ht = function() {
                    function n(n, t) {
                        this.cd = n, this.betslipService = t, this.totalBets = 0, this.maxWinning = 0, this.subscription = new un.a
                    }
                    return n.prototype.ngOnInit = function() {
                        this.updateInfo(), this.subscribeToBetslipChanges()
                    }, n.prototype.ngOnDestroy = function() {
                        this.subscription.unsubscribe()
                    }, n.prototype.subscribeToBetslipChanges = function() {
                        var n = this;
                        this.subscription.add(this.betslipService.onStake.subscribe((function() {
                            n.updateInfo()
                        }))), this.subscription.add(this.betslipService.onClear.subscribe((function() {
                            n.updateInfo()
                        }))), this.subscription.add(this.betslipService.onTicketBetRemoved.subscribe((function() {
                            n.updateInfo()
                        }))), this.subscription.add(this.betslipService.onTabChange.subscribe((function() {
                            n.updateInfo()
                        })))
                    }, n.prototype.updateInfo = function() {
                        var n = this.betslipService.getTotalStakeItemized();
                        this.totalBets = n ? n.gross : 0;
                        var t = this.betslipService.getTotalMaxWinningItemized();
                        this.maxWinning = t ? t.gross : 0, this.cd.markForCheck()
                    }, n
                }(),
                Dt = [
                    [".betslip-bet-info[_ngcontent-%COMP%]{padding:13px 9px 8px;text-transform:capitalize}.betslip-bet-info__separator[_ngcontent-%COMP%]{padding-top:8px}.betslip-bet-info__label[_ngcontent-%COMP%]{font-size:16px}.betslip-bet-info__label--big[_ngcontent-%COMP%]{margin-bottom:8px;font-size:20px}.betslip-bet-info__value[_ngcontent-%COMP%]{font-size:20px}.betslip-bet-info__value--big[_ngcontent-%COMP%]{margin-bottom:11px;font-size:26px}.grid-end[_ngcontent-%COMP%]{justify-content:flex-end}"]
                ],
                Lt = i.Gb({
                    encapsulation: 0,
                    styles: Dt,
                    data: {}
                });

            function Nt(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 14, "div", [
                    ["class", "grid grid-column betslip-bet-info"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 6, "div", [
                    ["class", "grid grid-right grid-column text-right"]
                ], null, null, null, null, null)), (n()(), i.Ib(2, 0, null, null, 2, "div", [
                    ["class", "betslip-bet-info__label betslip-bet-info__label--big"]
                ], null, null, null, null, null)), (n()(), i.cc(3, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(5, 0, null, null, 2, "div", [
                    ["class", "betslip-bet-info__value betslip-bet-info__value--big"]
                ], null, null, null, null, null)), (n()(), i.cc(6, null, ["", ""])), i.Wb(131072, s.b, [s.k, i.i]), (n()(), i.Ib(8, 0, null, null, 6, "div", [
                    ["class", "grid grid-space-between betslip-bet-info__separator betslip-bet-info--opacity"]
                ], null, null, null, null, null)), (n()(), i.Ib(9, 0, null, null, 2, "div", [
                    ["class", "betslip-bet-info__label"]
                ], null, null, null, null, null)), (n()(), i.cc(10, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(12, 0, null, null, 2, "div", [
                    ["class", "betslip-bet-info__value betslip-bet-info__value--opacity"]
                ], null, null, null, null, null)), (n()(), i.cc(13, null, ["", ""])), i.Wb(131072, s.b, [s.k, i.i])], null, (function(n, t) {
                    var l = t.component;
                    n(t, 3, 0, i.dc(t, 3, 0, i.Ub(t, 4).transform("ch_total_bet"))), n(t, 6, 0, i.dc(t, 6, 0, i.Ub(t, 7).transform(l.totalBets))), n(t, 10, 0, i.dc(t, 10, 0, i.Ub(t, 11).transform("ch_max_winning"))), n(t, 13, 0, i.dc(t, 13, 0, i.Ub(t, 14).transform(l.maxWinning)))
                }))
            }
            i.Eb("grc-betslip-bet-info", Ht, (function(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-betslip-bet-info", [], null, null, null, Nt, Lt)), i.Hb(1, 245760, null, 0, Ht, [i.i, M.a], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {}, {}, []);
            var zt = function() {
                    function n(n, t) {
                        this.cd = n, this.coreService = t, this.data = {}, this.subscriptions = new un.a
                    }
                    return n.prototype.ngOnInit = function() {
                        var n = this,
                            t = this.coreService.getSessionController();
                        this.updateTime({
                            seconds: t.systemClock.getTime() / 1e3,
                            utcOffset: t.sessionSettings.localizationContext.utcOffset
                        }), this.subscriptions.add(Object(P.a)(this.coreService.getSessionController().onTickSystemClock).subscribe((function(t) {
                            n.updateTime(t)
                        })))
                    }, n.prototype.ngOnDestroy = function() {
                        this.subscriptions.unsubscribe()
                    }, n.prototype.updateTime = function(n) {
                        this.data = {
                            ms: 1e3 * n.seconds,
                            utcOffset: n.utcOffset
                        }, this.cd.detectChanges()
                    }, n
                }(),
                Rt = [
                    [".betslip-time__value[_ngcontent-%COMP%]{margin-left:3px;font-size:16px}"]
                ],
                Wt = i.Gb({
                    encapsulation: 0,
                    styles: Rt,
                    data: {}
                });

            function Ft(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 3, "span", [
                    ["class", "betslip-time__value"]
                ], null, null, null, null, null)), (n()(), i.cc(1, null, [" ", " "])), i.Xb(2, {
                    utcOffset: 0
                }), i.Wb(131072, s.c, [s.k, i.i])], null, (function(n, t) {
                    var l = t.component,
                        e = i.dc(t, 1, 0, i.Ub(t, 3).transform(l.data.ms, "time", n(t, 2, 0, l.data.utcOffset)));
                    n(t, 1, 0, e)
                }))
            }

            function Gt(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 2, "div", [
                    ["class", "betslip-time"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, Ft)), i.Hb(2, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(n, t) {
                    n(t, 2, 0, t.component.data)
                }), null)
            }
            i.Eb("grc-betslip-time", zt, (function(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-betslip-time", [], null, null, null, Gt, Wt)), i.Hb(1, 245760, null, 0, zt, [i.i, m.a], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {}, {}, []);
            var Zt = l("0/uQ"),
                Vt = l("oEwP"),
                Kt = l("bahv"),
                Yt = l("EVvl"),
                qt = function() {
                    function n(n, t) {
                        this.modalService = n, this.coreService = t
                    }
                    return n.prototype.init = function() {
                        this.coreService.isModeVboxCashier() && this.loadPrinters()
                    }, n.prototype.showModalUnitsPrinters = function() {
                        this.loadUnitsPrinter(!1)
                    }, n.prototype.loadUnitsPrinter = function(n) {
                        this.discoverController || (this.discoverController = Object(Zt.a)(this.coreService.getDiscoverController(this.coreService.getEnvironmentConfigController())), this.systemController = Object(Zt.a)(this.coreService.getSystemController(this.coreService.getEnvironmentConfigController()))), this.hwId = this.coreService.getHwId(this.coreService.getEnvironmentConfigController()), this.openModalUnitsPrinter()
                    }, n.prototype.openModalInfoNoPrinter = function() {
                        var n = this;
                        this.modalService.open("base-information", Kt.a, {
                            inputs: {
                                title: "",
                                printers: this.printers
                            },
                            outputs: {
                                switchPrinter: function(t) {
                                    n.selectNewPrinter(t)
                                }
                            }
                        }).afterClosed.subscribe(null, null, (function() {}))
                    }, n.prototype.loadPrinters = function() {
                        var n = this;
                        this.printTicketController = this.coreService.getPrintTicketController(), setTimeout((function() {
                            Object(Zt.a)(n.printTicketController.getPrintersAvailable()).subscribe((function(t) {
                                n.printers = t, n.printers.some((function(n) {
                                    return n.info.isDefault
                                })) || n.openModalInfoNoPrinter()
                            }))
                        }), 100)
                    }, n.prototype.openModalUnitsPrinter = function() {
                        var n = this;
                        this.modalService.open("base-information", Vt.a, {
                            inputs: {
                                title: "",
                                systemController: this.systemController,
                                discoverController: this.discoverController,
                                hwId: this.hwId,
                                printers: this.printers,
                                entityId: this.coreService.getSessionController().sessionSettings.auth.staff.id,
                                entityName: this.coreService.getSessionController().sessionSettings.auth.staff.name
                            },
                            outputs: {
                                switchPrinter: function(t) {
                                    n.selectNewPrinter(t)
                                },
                                switchUnitPrinter: function(t) {
                                    n.openModalInfoLogOff(t)
                                }
                            }
                        }).afterClosed.subscribe(null, null, (function() {}))
                    }, n.prototype.openModalInfoLogOff = function(n) {
                        var t = this;
                        this.modalService.open("base-information", Yt.a, {
                            inputs: {
                                title: "",
                                hardwareId: n
                            },
                            outputs: {
                                accept: function(n) {
                                    t.changeHwId(n)
                                },
                                cancel: function() {
                                    t.openModalUnitsPrinter()
                                }
                            }
                        }).afterClosed.subscribe(null, null, (function() {}))
                    }, n.prototype.selectNewPrinter = function(n) {
                        this.printTicketController.setPrinterToUse(n), this.updatePrinters(n)
                    }, n.prototype.changeHwId = function(n) {
                        var t = JSON.parse(localStorage.getItem("loginCredentials"));
                        t.hwId = window.btoa(n), localStorage.setItem("loginCredentials", JSON.stringify(t)), this.coreService.logOut()
                    }, n.prototype.updatePrinters = function(n) {
                        this.printers.forEach((function(t) {
                            return t.info.printerId === n ? t.info.isDefault = !0 : t.info.isDefault = !1
                        }))
                    }, n.ngInjectableDef = i.ic({
                        factory: function() {
                            return new n(i.jc($n.a), i.jc(m.a))
                        },
                        token: n,
                        providedIn: "root"
                    }), n
                }(),
                Xt = l("ijKR"),
                Jt = function() {
                    function n(n, t, l, e, o, r) {
                        this.coreService = n, this.betslipService = t, this.shopAdminService = l, this.externalConfigService = e, this.printersService = o, this.cd = r, this.close = new i.q, this.statusState = "open", this.canReprint = !0, this.hasLastTicket = !1, this.hasFastHelp = !1, this.showLogoutButton = !0, this.fullScreenEnabled = !0, this.reprintLastTicket = !1, this.fullScreenEnabledButton = !0
                    }
                    return n.prototype.ngOnInit = function() {
                        var n, t = this,
                            l = this.externalConfigService.getEnvironmentConfig().configParams;
                        this.coreService.isModeVboxCashier() ? this.fullScreenEnabledButton = !1 : this.fullScreenEnabledButton = !0, this.fullScreenEnabled = this.betslipService.getCashierProfileSettings().startFullScreen, this.showLogoutButton = !("false" === l.showLogoutButton), this.lastTicket = null === (n = this.betslipService.getLastTicket()) || void 0 === n ? void 0 : n.serverTicket, this.hasLastTicket = this.betslipService.hasLastTicket(), this.reprintLastTicket = this.betslipService.getCashierProfileSettings().reprintLastTicket, this.canReprint = this.betslipService.getCashierProfileSettings().reprint, this.betslipService.onConfiguration.subscribe((function() {
                            t.hasFastHelp = t.betslipService.hasFastbetHelp(), t.cd.markForCheck()
                        }))
                    }, n.prototype.toggleFullScreen = function() {
                        (this.fullScreenEnabled || this.fullScreenEnabledButton) && this.betslipService.toggleFullScreen()
                    }, n.prototype.reprintLastOpenTicket = function() {
                        this.hasLastTicket && (this.lastTicket._clData.isCashTicket() ? (this.lastTicket = this.betslipService.prepareReprintCashTicket(this.lastTicket), this.betslipService.printCashTicket(this.lastTicket)) : this.betslipService.reprintLastOpenTicket(), this.onClose())
                    }, n.prototype.reprintTicketById = function() {
                        this.betslipService.printTicketById(!0), this.onClose()
                    }, n.prototype.openFastbetHelp = function() {
                        this.betslipService.openFastbetHelp(), this.onClose()
                    }, n.prototype.showAdmin = function() {
                        this.shopAdminService.openShopAdmin(), this.onClose()
                    }, n.prototype.showShortcutsHelp = function() {
                        this.betslipService.openShortcutsHelp(), this.onClose()
                    }, n.prototype.openPrinters = function() {
                        this.coreService.isModeVboxCashier() && (this.printersService.showModalUnitsPrinters(), this.onClose())
                    }, n.prototype.onLogOut = function() {
                        this.coreService.logOut()
                    }, n.prototype.onClose = function() {
                        this.close.next()
                    }, n
                }(),
                Qt = [
                    ["[_nghost-%COMP%]{position:absolute;top:0;left:0;z-index:99999999;display:block;width:100%;height:100%}.betslip-menu[_ngcontent-%COMP%]{font-weight:700;text-transform:capitalize}.betslip-menu__sidebar[_ngcontent-%COMP%]{position:relative;left:100%;width:426px;height:100%;padding:56px 98px;transform:translateX(-100%)}.betslip-menu__button[_ngcontent-%COMP%]{padding:22px 0;margin-bottom:15px;font-size:24px;text-align:center;cursor:pointer;border-radius:3px}.betslip-menu__button-icon[_ngcontent-%COMP%]{margin-bottom:15px;font-size:30px}.betslip-menu__button--bordered[_ngcontent-%COMP%]{background-color:transparent}.betslip-menu__button--inline[_ngcontent-%COMP%]   .betslip-menu__button-icon[_ngcontent-%COMP%]{margin-right:10px;margin-bottom:0;font-weight:500}.betslip-menu__button--disabled[_ngcontent-%COMP%]{cursor:default;opacity:.4}"]
                ],
                $t = i.Gb({
                    encapsulation: 0,
                    styles: Qt,
                    data: {
                        animation: [{
                            type: 7,
                            name: "statusState",
                            definitions: [{
                                type: 0,
                                name: "open",
                                styles: {
                                    type: 6,
                                    styles: {
                                        opacity: 1
                                    },
                                    offset: null
                                },
                                options: void 0
                            }, {
                                type: 0,
                                name: "close",
                                styles: {
                                    type: 6,
                                    styles: {
                                        opacity: 0
                                    },
                                    offset: null
                                },
                                options: void 0
                            }, {
                                type: 1,
                                expr: ":enter",
                                animation: [{
                                    type: 3,
                                    steps: [{
                                        type: 4,
                                        styles: null,
                                        timings: "150ms ease-in"
                                    }, {
                                        type: 11,
                                        selector: ".betslip-menu__sidebar",
                                        animation: [{
                                            type: 6,
                                            styles: {
                                                transform: "translateX(0%)"
                                            },
                                            offset: null
                                        }, {
                                            type: 4,
                                            styles: {
                                                type: 6,
                                                styles: {
                                                    transform: "translateX(-100%)"
                                                },
                                                offset: null
                                            },
                                            timings: "150ms ease-in-out"
                                        }],
                                        options: null
                                    }],
                                    options: null
                                }],
                                options: null
                            }, {
                                type: 1,
                                expr: ":leave",
                                animation: [{
                                    type: 3,
                                    steps: [{
                                        type: 4,
                                        styles: null,
                                        timings: "150ms ease-in"
                                    }, {
                                        type: 11,
                                        selector: ".betslip-menu__sidebar",
                                        animation: [{
                                            type: 6,
                                            styles: {
                                                transform: "translateX(-100%)"
                                            },
                                            offset: null
                                        }, {
                                            type: 4,
                                            styles: {
                                                type: 6,
                                                styles: {
                                                    transform: "translateX(0%)"
                                                },
                                                offset: null
                                            },
                                            timings: "150ms ease-in-out"
                                        }],
                                        options: null
                                    }],
                                    options: null
                                }],
                                options: null
                            }],
                            options: {}
                        }]
                    }
                });

            function nl(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 7, "div", [
                    ["class", "col grid grid-column grid-center betslip-menu__button"]
                ], [
                    [2, "betslip-menu__button--disabled", null]
                ], [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.reprintLastOpenTicket() && e);
                    return e
                }), null, null)), (n()(), i.Ib(1, 0, null, null, 0, "span", [
                    ["class", "betslip-menu__button-icon icon icon-print-last"]
                ], null, null, null, null, null)), (n()(), i.Ib(2, 0, null, null, 5, "span", [], null, null, null, null, null)), (n()(), i.cc(3, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), i.Wb(131072, s.j, [s.k, i.i]), i.Wb(0, Y.t, []), i.Wb(131072, s.j, [s.k, i.i])], null, (function(n, t) {
                    n(t, 0, 0, !t.component.hasLastTicket), n(t, 3, 0, i.dc(t, 3, 0, i.Ub(t, 4).transform("ch_print_last_ticket")).length > 17 ? i.dc(t, 3, 0, i.Ub(t, 6).transform(i.dc(t, 3, 0, i.Ub(t, 5).transform("ch_print_last_ticket")), 0, 17)) + "..." : i.dc(t, 3, 0, i.Ub(t, 7).transform("ch_print_last_ticket")))
                }))
            }

            function tl(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 7, "div", [
                    ["class", "col grid grid-column grid-center betslip-menu__button"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.reprintTicketById() && e);
                    return e
                }), null, null)), (n()(), i.Ib(1, 0, null, null, 0, "span", [
                    ["class", "betslip-menu__button-icon icon icon-print-reprint"]
                ], null, null, null, null, null)), (n()(), i.Ib(2, 0, null, null, 5, "span", [], null, null, null, null, null)), (n()(), i.cc(3, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), i.Wb(131072, s.j, [s.k, i.i]), i.Wb(0, Y.t, []), i.Wb(131072, s.j, [s.k, i.i])], null, (function(n, t) {
                    n(t, 3, 0, i.dc(t, 3, 0, i.Ub(t, 4).transform("ch_reprint_ticket")).length > 17 ? i.dc(t, 3, 0, i.Ub(t, 6).transform(i.dc(t, 3, 0, i.Ub(t, 5).transform("ch_reprint_ticket")), 0, 17)) + "..." : i.dc(t, 3, 0, i.Ub(t, 7).transform("ch_reprint_ticket")))
                }))
            }

            function ll(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 4, "div", [
                    ["class", "grid grid-center grid-middle betslip-menu__button betslip-menu__button--inline betslip-menu__button--bordered"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.onLogOut() && e);
                    return e
                }), null, null)), (n()(), i.Ib(1, 0, null, null, 0, "span", [
                    ["class", "betslip-menu__button-icon icon icon-power"]
                ], null, null, null, null, null)), (n()(), i.Ib(2, 0, null, null, 2, "span", [], null, null, null, null, null)), (n()(), i.cc(3, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i])], null, (function(n, t) {
                    n(t, 3, 0, i.dc(t, 3, 0, i.Ub(t, 4).transform("ch_logout")))
                }))
            }

            function el(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 41, "div", [
                    ["class", "grid grid-column betslip-menu betslip-menu__sidebar"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0;
                    "click" === t && (e = !1 !== l.stopPropagation() && e);
                    return e
                }), null, null)), (n()(), i.Ib(1, 0, null, null, 7, "div", [
                    ["class", "col grid grid-column grid-center betslip-menu__button"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.showAdmin() && e);
                    return e
                }), null, null)), (n()(), i.Ib(2, 0, null, null, 0, "span", [
                    ["class", "betslip-menu__button-icon icon icon-admin"]
                ], null, null, null, null, null)), (n()(), i.Ib(3, 0, null, null, 5, "span", [], null, null, null, null, null)), (n()(), i.cc(4, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), i.Wb(131072, s.j, [s.k, i.i]), i.Wb(0, Y.t, []), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.xb(16777216, null, null, 1, null, nl)), i.Hb(10, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, tl)), i.Hb(12, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.Ib(13, 0, null, null, 7, "div", [
                    ["class", "col grid grid-column grid-center betslip-menu__button"]
                ], [
                    [2, "betslip-menu__button--disabled", null]
                ], [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.openFastbetHelp() && e);
                    return e
                }), null, null)), (n()(), i.Ib(14, 0, null, null, 0, "span", [
                    ["class", "betslip-menu__button-icon icon icon-questionmark"]
                ], null, null, null, null, null)), (n()(), i.Ib(15, 0, null, null, 5, "span", [], null, null, null, null, null)), (n()(), i.cc(16, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), i.Wb(131072, s.j, [s.k, i.i]), i.Wb(0, Y.t, []), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(21, 0, null, null, 5, "div", [
                    ["class", "col grid grid-column grid-center betslip-menu__button"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.showShortcutsHelp() && e);
                    return e
                }), null, null)), (n()(), i.Ib(22, 0, null, null, 0, "span", [
                    ["class", "betslip-menu__button-icon icon icon-shortcuts"]
                ], null, null, null, null, null)), (n()(), i.Ib(23, 0, null, null, 3, "span", [], null, null, null, null, null)), (n()(), i.cc(24, null, ["", " ", ""])), i.Wb(131072, s.j, [s.k, i.i]), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(27, 0, null, null, 4, "div", [
                    ["class", "col grid grid-column grid-center betslip-menu__button"]
                ], [
                    [2, "betslip-menu__button--disabled", null]
                ], [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.toggleFullScreen() && e);
                    return e
                }), null, null)), (n()(), i.Ib(28, 0, null, null, 0, "span", [
                    ["class", "betslip-menu__button-icon icon icon-fullscreen"]
                ], null, null, null, null, null)), (n()(), i.Ib(29, 0, null, null, 2, "span", [], null, null, null, null, null)), (n()(), i.cc(30, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(32, 0, null, null, 7, "div", [
                    ["class", "col grid grid-column grid-center betslip-menu__button"]
                ], [
                    [2, "betslip-menu__button--disabled", null]
                ], [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.openPrinters() && e);
                    return e
                }), null, null)), (n()(), i.Ib(33, 0, null, null, 0, "span", [
                    ["class", "betslip-menu__button-icon icon icon-unit"]
                ], null, null, null, null, null)), (n()(), i.Ib(34, 0, null, null, 5, "span", [], null, null, null, null, null)), (n()(), i.cc(35, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), i.Wb(131072, s.j, [s.k, i.i]), i.Wb(0, Y.t, []), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.xb(16777216, null, null, 1, null, ll)), i.Hb(41, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(n, t) {
                    var l = t.component;
                    n(t, 10, 0, l.reprintLastTicket), n(t, 12, 0, l.canReprint), n(t, 41, 0, l.showLogoutButton)
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 4, 0, i.dc(t, 4, 0, i.Ub(t, 5).transform("ch_admin")).length > 17 ? i.dc(t, 4, 0, i.Ub(t, 7).transform(i.dc(t, 4, 0, i.Ub(t, 6).transform("ch_admin")), 0, 17)) + "..." : i.dc(t, 4, 0, i.Ub(t, 8).transform("ch_admin"))), n(t, 13, 0, !l.hasFastHelp), n(t, 16, 0, i.dc(t, 16, 0, i.Ub(t, 17).transform("ch_fastbet_help")).length > 16 ? i.dc(t, 16, 0, i.Ub(t, 19).transform(i.dc(t, 16, 0, i.Ub(t, 18).transform("ch_fastbet_help")), 0, 16)) + "..." : i.dc(t, 16, 0, i.Ub(t, 20).transform("ch_fastbet_help"))), n(t, 24, 0, i.dc(t, 24, 0, i.Ub(t, 25).transform("ch_shortcuts")), i.dc(t, 24, 1, i.Ub(t, 26).transform("ch_help"))), n(t, 27, 0, !l.fullScreenEnabledButton), n(t, 30, 0, i.dc(t, 30, 0, i.Ub(t, 31).transform("ch_full_screen"))), n(t, 32, 0, !l.coreService.isModeVboxCashier()), n(t, 35, 0, i.dc(t, 35, 0, i.Ub(t, 36).transform("ch_units_printer")).length > 16 ? i.dc(t, 35, 0, i.Ub(t, 38).transform(i.dc(t, 35, 0, i.Ub(t, 37).transform("ch_units_printer")), 0, 16)) + "..." : i.dc(t, 35, 0, i.Ub(t, 39).transform("ch_units_printer")))
                }))
            }
            i.Eb("grc-betslip-menu", Jt, (function(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-betslip-menu", [], [
                    [40, "@statusState", 0]
                ], [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0;
                    "click" === t && (e = !1 !== i.Ub(n, 1).onClose() && e);
                    return e
                }), el, $t)), i.Hb(1, 114688, null, 0, Jt, [m.a, M.a, Xt.a, _.a, qt, i.i], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), (function(n, t) {
                    n(t, 0, 0, i.Ub(t, 1).statusState)
                }))
            }), {}, {
                close: "close"
            }, []);
            var il = function() {
                    function n(n, t, l) {
                        this.coreService = n, this.externalConfigService = t, this.cd = l, this.isMenuOpened = !1, this.openedMenu = new i.q, this.infiniteCredit = !1, this.hideNotificationTopBar = !1, this.hideCreditArea = !1, this.hideUsernameArea = !1, this.hideOptionMenuButton = !1, this.hideHeaderSection = !1, this.credit = 0, this.userId = "", this.userName = ""
                    }
                    return n.prototype.ngOnInit = function() {
                        var n = this,
                            t = this.coreService.getSessionController(),
                            l = this.externalConfigService.getEnvironmentConfig().configParams;
                        this.infiniteCredit = this.coreService.hasInfiniteCredit(), this.hideNotificationTopBar = this.coreService.hideNotificationTopBar(), this.hideCreditArea = this.coreService.hideCreditArea(), this.hideUsernameArea = this.coreService.hideUsernameArea(), this.hideOptionMenuButton = this.coreService.hideOptionMenuButton(), this.hideHeaderSection = this.hideCreditArea && this.hideUsernameArea && this.hideOptionMenuButton, this.userId = t.sessionSettings.auth.staff.name, this.userName = this.userId ? this.userId : l.user, this.infiniteCredit || (this.credit = this.getCurrentWallet().walletStatus.balance, Object(P.a)(this.coreService.getWalletManager().onUpdateCredit).subscribe((function(t) {
                            t.isCurrentWallet && n.updateCredit(t.walletStatus.balance)
                        })))
                    }, n.prototype.toggleMenu = function(n) {
                        this.isMenuOpened = n, this.openedMenu.emit(n)
                    }, n.prototype.getCurrentWallet = function() {
                        return this.coreService.getWalletManager().getCurrentWallet()
                    }, n.prototype.updateCredit = function(n) {
                        this.credit = n, this.cd.markForCheck()
                    }, n
                }(),
                ol = [
                    [".betslip-header[_ngcontent-%COMP%]{height:100%}.betslip-header__top[_ngcontent-%COMP%]{width:100%;min-height:25px;padding:0 8px;font-size:18px}.betslip-user-info[_ngcontent-%COMP%]{z-index:0;padding:13px 16px;font-weight:400}.betslip-user-info__label[_ngcontent-%COMP%]{font-size:24px}.betslip-user-info__value[_ngcontent-%COMP%]{width:100px;overflow:hidden;font-size:22px;line-height:1.5em;text-overflow:ellipsis;white-space:nowrap}.betslip-user-info__separator[_ngcontent-%COMP%]{max-width:2px;height:100%;margin:0 16px 0 10px}.betslip-user-info__icon[_ngcontent-%COMP%]{padding:20px 15px 20px 6px;cursor:pointer}.betslip-user-info__icon[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{font-size:30px;font-weight:500}.betslip-user-info--no-icons[_ngcontent-%COMP%]{align-self:flex-end}"]
                ],
                rl = i.Gb({
                    encapsulation: 0,
                    styles: ol,
                    data: {}
                });

            function ul(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 2, "div", [
                    ["class", "grid grid-middle grid-right betslip-header__top"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 1, "grc-betslip-time", [], null, null, null, Gt, Wt)), i.Hb(2, 245760, null, 0, zt, [i.i, m.a], null, null)], (function(n, t) {
                    n(t, 2, 0)
                }), null)
            }

            function sl(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 0, "div", [
                    ["class", "col betslip-user-info__separator"]
                ], null, null, null, null, null))], null, null)
            }

            function cl(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 12, null, null, null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 9, "div", [
                    ["class", "col"]
                ], null, null, null, null, null)), (n()(), i.Ib(2, 0, null, null, 0, "div", [
                    ["class", "betslip-user-info__label icon icon-money"]
                ], null, null, null, null, null)), (n()(), i.Ib(3, 0, null, null, 7, "grc-tooltip", [], null, null, null, Q, J)), i.Hb(4, 114688, null, 0, q.a, [], {
                    text: [0, "text"]
                }, null), i.Xb(5, {
                    noZeros: 0
                }), i.Wb(131072, s.b, [s.k, i.i]), (n()(), i.Ib(7, 0, null, 0, 3, "div", [
                    ["class", "betslip-user-info__value"]
                ], null, null, null, null, null)), (n()(), i.cc(8, null, ["", ""])), i.Xb(9, {
                    condensed: 0
                }), i.Wb(131072, s.b, [s.k, i.i]), (n()(), i.xb(16777216, null, null, 1, null, sl)), i.Hb(12, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(0, null, null, 0))], (function(n, t) {
                    var l = t.component,
                        e = i.dc(t, 4, 0, i.Ub(t, 6).transform(l.credit, n(t, 5, 0, !0)));
                    n(t, 4, 0, e), n(t, 12, 0, !l.hideUsernameArea)
                }), (function(n, t) {
                    var l = t.component,
                        e = i.dc(t, 8, 0, i.Ub(t, 10).transform(l.credit, n(t, 9, 0, !0)));
                    n(t, 8, 0, e)
                }))
            }

            function al(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 5, "div", [
                    ["class", "col"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 0, "div", [
                    ["class", "betslip-user-info__label icon icon-user"]
                ], null, null, null, null, null)), (n()(), i.Ib(2, 0, null, null, 3, "grc-tooltip", [], null, null, null, Q, J)), i.Hb(3, 114688, null, 0, q.a, [], {
                    text: [0, "text"]
                }, null), (n()(), i.Ib(4, 0, null, 0, 1, "div", [
                    ["class", "betslip-user-info__value"]
                ], null, null, null, null, null)), (n()(), i.cc(5, null, ["", ""]))], (function(n, t) {
                    n(t, 3, 0, t.component.userName)
                }), (function(n, t) {
                    n(t, 5, 0, t.component.userName)
                }))
            }

            function dl(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 0, "div", [
                    ["class", "col betslip-user-info__separator"]
                ], null, null, null, null, null))], null, null)
            }

            function pl(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "div", [
                    ["class", "col-middle betslip-user-info__icon"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.toggleMenu(!0) && e);
                    return e
                }), null, null)), (n()(), i.Ib(1, 0, null, null, 0, "span", [
                    ["class", "icon icon-menu"]
                ], null, null, null, null, null))], null, null)
            }

            function bl(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 12, "div", [
                    ["class", "col grid betslip-user-info"]
                ], null, null, null, null, null)), i.Zb(512, null, Y.x, Y.y, [i.A, i.B, i.o, i.P]), i.Hb(2, 278528, null, 0, Y.k, [Y.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), i.Xb(3, {
                    "betslip-user-info--no-icons": 0
                }), (n()(), i.Ib(4, 0, null, null, 8, "div", [
                    ["class", "col grid"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, cl)), i.Hb(6, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, al)), i.Hb(8, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, dl)), i.Hb(10, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, pl)), i.Hb(12, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(n, t) {
                    var l = t.component,
                        e = n(t, 3, 0, l.hideCreditArea && l.hideUsernameArea);
                    n(t, 2, 0, "col grid betslip-user-info", e), n(t, 6, 0, !l.infiniteCredit && !l.hideCreditArea), n(t, 8, 0, !l.hideUsernameArea), n(t, 10, 0, !l.hideOptionMenuButton), n(t, 12, 0, !l.hideOptionMenuButton)
                }), null)
            }

            function hl(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-betslip-menu", [], [
                    [40, "@statusState", 0]
                ], [
                    [null, "close"],
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        o = n.component;
                    "click" === t && (e = !1 !== i.Ub(n, 1).onClose() && e);
                    "close" === t && (e = !1 !== o.toggleMenu(!1) && e);
                    return e
                }), el, $t)), i.Hb(1, 114688, null, 0, Jt, [m.a, M.a, Xt.a, _.a, qt, i.i], null, {
                    close: "close"
                })], (function(n, t) {
                    n(t, 1, 0)
                }), (function(n, t) {
                    n(t, 0, 0, i.Ub(t, 1).statusState)
                }))
            }

            function gl(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 4, "div", [
                    ["class", "grid grid-column betslip-header"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, ul)), i.Hb(2, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, bl)), i.Hb(4, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, hl)), i.Hb(6, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, !l.hideNotificationTopBar), n(t, 4, 0, !l.hideHeaderSection), n(t, 6, 0, l.isMenuOpened)
                }), null)
            }
            i.Eb("grc-betslip-header", il, (function(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-betslip-header", [], null, null, null, gl, rl)), i.Hb(1, 114688, null, 0, il, [m.a, _.a, i.i], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                isMenuOpened: "isMenuOpened"
            }, {
                openedMenu: "openedMenu"
            }, []);
            var fl = function() {
                    function n(n, t) {
                        this.renderer = n, this.changeDetector = t, this.chip = 0, this.isActive = !1, this.isActiveChange = new i.q, this.fontSize = 32
                    }
                    return n.prototype.ngAfterViewInit = function() {
                        if (this.chipElement)
                            for (; this.isOverflown(this.chipElement) && this.fontSize >= 1;) this.renderer.setStyle(this.chipElement.nativeElement, "fontSize", this.fontSize-- + "px"), this.changeDetector.detectChanges()
                    }, n.prototype.onClick = function() {
                        this.isActiveChange.emit(!this.isActive)
                    }, n.prototype.isOverflown = function(n) {
                        var t = n.nativeElement;
                        return t.scrollHeight > t.clientHeight || t.scrollWidth > t.clientWidth
                    }, n
                }(),
                ml = [
                    [".betslip-chip[_ngcontent-%COMP%]{display:flex;height:58px;align-items:center;justify-content:center;font-size:32px;font-weight:700;cursor:pointer}"]
                ],
                _l = i.Gb({
                    encapsulation: 0,
                    styles: ml,
                    data: {}
                });

            function vl(n) {
                return i.ec(2, [i.ac(671088640, 1, {
                    chipElement: 0
                }), (n()(), i.Ib(1, 0, [
                    [1, 0],
                    ["betslipChip", 1]
                ], null, 3, "div", [
                    ["class", "betslip-chip"]
                ], [
                    [2, "betslip-chip--active", null]
                ], null, null, null, null)), (n()(), i.cc(2, null, [" ", "\n"])), i.Xb(3, {
                    condensed: 0,
                    showSymbol: 1,
                    noZeros: 2
                }), i.Wb(131072, s.b, [s.k, i.i])], null, (function(n, t) {
                    var l = t.component;
                    n(t, 1, 0, l.isActive);
                    var e = i.dc(t, 2, 0, i.Ub(t, 4).transform(l.chip, n(t, 3, 0, !0, !1, !0)));
                    n(t, 2, 0, e)
                }))
            }
            i.Eb("grc-betslip-chip", fl, (function(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-betslip-chip", [], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0;
                    "click" === t && (e = !1 !== i.Ub(n, 1).onClick() && e);
                    return e
                }), vl, _l)), i.Hb(1, 4243456, null, 0, fl, [i.P, i.i], null, null)], null, null)
            }), {
                chip: "chip",
                isActive: "isActive"
            }, {
                isActiveChange: "isActiveChange"
            }, []);
            var yl = function() {
                    function n() {
                        this.isSnRoulette = !1, this.chipSelected = new i.q, this.chipUnselected = new i.q
                    }
                    return n.prototype.ngOnInit = function() {}, n.prototype.onChipActiveChange = function(n, t) {
                        this.isSnRoulette || (t ? this.chipSelected.emit(n) : this.chipUnselected.emit(n))
                    }, n.prototype.isSelected = function(n) {
                        return this.chipsSelected.includes(n)
                    }, n
                }(),
                Cl = [
                    [".betslip-chips[_ngcontent-%COMP%]{margin:0 -4px}.betslip-chips__chip-disabled[_ngcontent-%COMP%]  .betslip-chip{cursor:default;opacity:.4}.betslip-chips[_ngcontent-%COMP%]   .betslip-chip[_ngcontent-%COMP%]{margin:4px}"]
                ],
                kl = i.Gb({
                    encapsulation: 0,
                    styles: Cl,
                    data: {}
                });

            function xl(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 5, "div", [
                    ["class", "col"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 4, "grc-betslip-chip", [], null, [
                    [null, "isActiveChange"],
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        o = n.component;
                    "click" === t && (e = !1 !== i.Ub(n, 5).onClick() && e);
                    "isActiveChange" === t && (e = !1 !== o.onChipActiveChange(n.context.$implicit, l) && e);
                    return e
                }), vl, _l)), i.Zb(512, null, Y.x, Y.y, [i.A, i.B, i.o, i.P]), i.Hb(3, 278528, null, 0, Y.k, [Y.x], {
                    ngClass: [0, "ngClass"]
                }, null), i.Xb(4, {
                    "betslip-chips__chip-disabled": 0
                }), i.Hb(5, 4243456, null, 0, fl, [i.P, i.i], {
                    chip: [0, "chip"],
                    isActive: [1, "isActive"]
                }, {
                    isActiveChange: "isActiveChange"
                })], (function(n, t) {
                    var l = t.component,
                        e = n(t, 4, 0, l.isSnRoulette);
                    n(t, 3, 0, e), n(t, 5, 0, t.context.$implicit, l.isSelected(t.context.$implicit))
                }), null)
            }

            function Il(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 2, "div", [
                    ["class", "grid grid-4 betslip-chips"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, xl)), i.Hb(2, 278528, null, 0, Y.l, [i.eb, i.Z, i.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(n, t) {
                    n(t, 2, 0, t.component.chips)
                }), null)
            }
            i.Eb("grc-betslip-chips", yl, (function(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-betslip-chips", [], null, null, null, Il, kl)), i.Hb(1, 114688, null, 0, yl, [], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                chips: "chips",
                chipsSelected: "chipsSelected",
                isSnRoulette: "isSnRoulette"
            }, {
                chipSelected: "chipSelected",
                chipUnselected: "chipUnselected"
            }, []);
            var Sl = l("nbsC"),
                wl = l.n(Sl),
                Ol = l("bma8"),
                Pl = l("dXOS"),
                Ml = function() {
                    function n(n, t, l, e, o, r, u, s, c, a, d) {
                        this.changeDetector = n, this.renderer = t, this.notificationsService = l, this.betslipService = e, this.coreService = o, this.i18NService = r, this.scaleService = u, this.modalService = s, this.iI18NService = c, this.baseService = a, this.contextObjectService = d, this.isMenuOpened = !1, this.isCashManagementOpened = !1, this.openedMenu = new i.q, this.cashTabSelected = Pl.b.CASH_TICKET, this.chips = [], this.chipsSelected = [], this.lastActionGroups = [], this.stake = 0, this.cashEntityName = "", this.maxTicketCashLength = 20, this.isSingleTabSelected = !0, this.enoughtCredit = !0, this.hasBarCodeButton = !0, this.isStakeAdded = !1, this.hideHeaderSection = !1, this.BetModeEnum = $.BetModeEnum, this.fastbetDisabledKeys = [], this.isSnRoulette = !1, this.cashTicketChipsValues = [1, 2, 3, 4, 5, 6, 7, 8, 9, ",", 0], this.isDotPushed = !1, this.decimalsLength = 0, this.footerTagStake = "ch_stake", this.subscriptions = new un.a, this.isSendingTicket = !1, this.isShowNotificationSendingTicket = !1, this.allowedKeys = /^[0-9,.]$/
                    }
                    return Object.defineProperty(n.prototype, "tabContent", {
                        set: function(n) {
                            this.betslipTabContent = n, this.fixHeightBetslipTabContent()
                        },
                        enumerable: !1,
                        configurable: !0
                    }), n.prototype.ngOnInit = function() {
                        var n = this;
                        this.betslipInfo = this.betslipService.getBetslipInfo(), this.betslipService.getChips().length > 0 && (this.chips = this.betslipService.getChips(), this.chipsSelected = [this.chips[0]], this.selectChip(this.chips[0])), this.betMode = this.betslipService.getBetMode(), this.hasBarCodeButton = this.coreService.hasBarCodeButton(), this.hideHeaderSection = this.coreService.hideCreditArea() && this.coreService.hideUsernameArea() && this.coreService.hideOptionMenuButton(), this.getCombinations(), this.setFastbetDisabledKeys(), this.addSubscriptions(), this.subscribeToShortcuts(), this.isCashManagementOpened && this.inputStake.nativeElement.addEventListener("focusout", (function() {
                            return n.onInputStakeFocusOut()
                        })), this.decimalsLength = this.iI18NService.location.getDefaultCurrency() && this.iI18NService.location.getDefaultCurrency().decimals, this.launchLowCreditWarning(), this.mobileEndPoint = window.location.hash.includes("cashier-v1") ? "/mobile-v4/" : "/mobile/"
                    }, n.prototype.ngOnDestroy = function() {
                        this.subscriptions.unsubscribe()
                    }, n.prototype.onKeydown = function(n) {
                        this.modalService.dataDialogOpened || ("+" !== n.key || this.isFastBetOpened || (this.isManualStake = !0, this.inputStake.nativeElement.focus(), this.inputStake.nativeElement.value = "", this.chipsSelected = [], this.setFastbetActivationState(!1)), this.allowedKeys.test(n.key) || "Backspace" === n.key || n.preventDefault())
                    }, n.prototype.onEnter = function() {
                        if (!this.isFastBetOpened && !this.modalService.dataDialogOpened) {
                            this.inputStake.nativeElement.blur();
                            var n = this.inputStake.nativeElement.value;
                            "" !== n ? (this.stake = n.replace(/[^0-9,.]/g, "").replace(",", "."), this.stake = +this.stake, this.isManualStake && this.setStakeToBets(this.stake), this.setFastbetActivationState(!0)) : this.resetStakeToDefault()
                        }
                    }, n.prototype.onResize = function() {
                        this.fixHeightBetslipTabContent()
                    }, n.prototype.selectChip = function(n) {
                        0 === this.chipsSelected.length ? this.stake = n : this.stake += n, this.stake = this.adjustFloatError(this.stake), this.chipsSelected.push(n), this.betslipService.setStake(this.stake)
                    }, n.prototype.unselectChip = function(n) {
                        this.stake -= n, this.stake = this.adjustFloatError(this.stake), this.chipsSelected = this.chipsSelected.filter((function(t) {
                            return n !== t
                        })), this.betslipService.setStake(this.stake)
                    }, n.prototype.adjustFloatError = function(n) {
                        return parseFloat((1e7 * n / 1e7).toFixed(2))
                    }, n.prototype.tabChange = function(n) {
                        this.betslipService.setBetMode(n), this.betMode = this.betslipService.getBetMode(), this.isSystemBetMode() && this.getCombinations(), this.changeDetector.markForCheck()
                    }, n.prototype.setStakeToBets = function(n) {
                        this.stake = n, this.isStakeAdded = !0, this.checkIfCanBet(n) && this.setBetsOnBetslip(n)
                    }, n.prototype.clearBetslip = function() {
                        this.betslipService.onClear.next()
                    }, n.prototype.clearChipsSelected = function() {
                        this.chipsSelected = [], this.selectChip(this.chips[0]), this.stake = this.chips[0], this.betslipService.setStake(this.stake)
                    }, n.prototype.isDisabledPrint = function() {
                        var n = this.betslipService.getTotalStakeItemized();
                        return 0 === this.betslipInfo.events.length || !n || 0 === n.gross || this.checkBlockMaxPayout() || !this.contextObjectButtonEnabled
                    }, n.prototype.isDisabledPrintCashTicket = function() {
                        return 0 === this.stake
                    }, n.prototype.checkBlockMaxPayout = function() {
                        return !!this.coreService.getCashierProfileSettings().blockMaxPayoutTicket && (this.hasMaxPayoutReachedPerTicket() ? (this.notificationsService.warning("" + this.i18NService.get("ch_payout_over_limit")), !0) : this.betMode === $.BetModeEnum.SINGLEBETMODE ? this.coreService.getBetSlip().getTicketBetErrors().some((function(n) {
                            return "MAXPAYOUTPERBET" === n.error.errorType[0]
                        })) : this.coreService.getBetSlip().getSystemBetErrors().some((function(n) {
                            return "MAXPAYOUTPERBET" === n.stakeError.errorType[0] || "MAXPAYOUTTICKET" === n.stakeError.errorType[0]
                        })))
                    }, n.prototype.sendCashManagement = function() {
                        var n = this;
                        this.betslipService.processing.next(!0), this.cashTabSelected === Pl.b.CASH_TICKET ? this.coreService.getCashController().createCashTicket(this.betslipService.getStake()).then((function(t) {
                            return n.betslipService.printCashTicket(t)
                        })).then((function(t) {
                            t.error || n.coreService.getTicketController().ticketPrintConfirm(t.serverTicket.ticketId), n.betslipService.processing.next(!1)
                        })).catch((function(t) {
                            console.log(t), "400" === t.error.errorCode && n.notificationsService.danger("" + n.i18NService.get("ch_cashticket_error")).subscribe((function() {
                                n.isShowNotificationSendingTicket = !1
                            }))
                        })) : this.cashTabSelected === Pl.b.LOCAL_USER && this.coreService.getCashController().createLocalPlayer(this.betslipService.getStake(), this.coreService.getSessionController().systemClock.getTime().toString(), this.inputCashEntityName.nativeElement.value).then((function(t) {
                            var l = t.credential.domain,
                                e = t.credential.username,
                                i = t.credential.password,
                                o = "" + window.location.origin + n.mobileEndPoint + "?domain=" + l + "&user=" + e + "&password=" + i,
                                r = t.ticketTransaction.ticket;
                            return r = n.prepareLocalUserTicket(r, t.entityId, t.credential.username), n.betslipService.printLocalUserTicket(r, o)
                        })).catch((function(t) {
                            console.log(t), "400" === t.error.errorCode && n.notificationsService.danger("" + n.i18NService.get("ch_user_exist")).subscribe((function() {
                                n.isShowNotificationSendingTicket = !1
                            }))
                        })).then((function(t) {
                            n.betslipService.processing.next(!1)
                        })), this.chipsSelected = [], this.setCashTo(0)
                    }, n.prototype.prepareLocalUserTicket = function(n, t, l) {
                        var e = this.coreService.getSessionController();
                        return n.sellStaff = new $.coreModel.Entity, n.sellStaff.id = e.sessionSettings.auth.staff.id, n.sellStaff.name = e.sessionSettings.auth.staff.name, n.unit = new $.coreModel.Entity, n.unit.id = t, n.unit.name = l, n
                    }, n.prototype.sendTicket = function() {
                        var n = this,
                            t = this.coreService.getSessionController();
                        this.isStakeAdded && !this.betslipService.isEmpty() || this.setStakeToBets(this.betslipService.getStake()), this.isDisabledPrint() || (this.validateTicketExtData(), this.betslipService.isEmpty() || this.isSendingTicket || this.betslipService.checkTicketPolicyError() ? this.isSendingTicket ? this.isShowNotificationSendingTicket || (this.isShowNotificationSendingTicket = !0, this.notificationsService.warning("" + this.i18NService.get("ch_ticket_being_send")).subscribe((function() {
                            n.isShowNotificationSendingTicket = !1
                        }))) : this.betslipService.checkTicketPolicyError() && this.contextObjectService.onSendTicketError.next(!0) : (this.isSendingTicket = !0, this.isSystemBetMode() && 0 === this.betslipService.getBetslipInfo().systemBets.length && this.tabChange($.BetModeEnum.SINGLEBETMODE), this.betslipService.sendTicket(this.stake).pipe(Object(a.a)((function(l) {
                            var e = t.sessionSettings.generalSettings.profilesContext.isProfilesContext() && t.sessionSettings.generalSettings.profilesContext;
                            return l && !e.cashier.disablePrintingBetTickets ? n.betslipService.printTicket(l[0]).pipe(Object(d.a)((function(n) {
                                return n
                            }))) : Object(c.a)(l)
                        }))).subscribe((function(t) {
                            n.betslipService.processing.next(!1), n.getCombinations(), n.clearChipsSelected(), n.changeDetector.detectChanges(), n.isSendingTicket = !1, n.launchLowCreditWarning()
                        }), (function(t) {
                            n.betslipService.processing.next(!1), n.isSendingTicket = !1
                        }), (function() {
                            n.betslipService.processing.next(!1), n.isSendingTicket = !1
                        })))), this.isStakeAdded = !1
                    }, n.prototype.printTicketById = function() {
                        this.betslipService.printTicketById()
                    }, n.prototype.onLastActionGroupChange = function(n) {
                        this.lastActionGroups = n
                    }, n.prototype.onFastbetOpened = function(n) {
                        this.isFastBetOpened = n, this.isFastBetOpened ? this.disableAllShortcuts() : this.enableAllShortcuts()
                    }, n.prototype.hasCombiBetStake = function() {
                        return !!this.betslipService.getBetslipInfo().systemBets && this.betslipService.getBetslipInfo().systemBets.some((function(n) {
                            return n.stake > 0
                        }))
                    }, n.prototype.showHiddenSection = function(n) {
                        this.openedMenu.emit(n)
                    }, n.prototype.onCombinationsUpdated = function() {
                        this.changeDetector.detectChanges(), this.betslipService.updateBets(), this.betslipService.notifyTicketBetUpdated()
                    }, n.prototype.openWordPad = function() {
                        var n = this;
                        this.inputCashEntityName.nativeElement.blur(), this.setFastbetActivationState(!1), this.modalService.open("base", Ol.a, {
                            inputs: {
                                title: this.i18NService.get("ch_entity_Name"),
                                type: nt.a.Text
                            },
                            outputs: {
                                success: function(t) {
                                    n.cashEntityName = t, n.inputCashEntityName.nativeElement.value = t, n.modalService.close("base"), n.changeDetector.detectChanges()
                                }
                            }
                        }).afterClosed.subscribe(null, null, (function() {
                            n.setFastbetActivationState(!0)
                        }))
                    }, n.prototype.openKeypad = function() {
                        var n = this;
                        this.isSnRoulette || this.isCashManagementOpened || (this.inputStake.nativeElement.blur(), this.setFastbetActivationState(!1), this.modalService.open("base", nt.b, {
                            inputs: {
                                title: this.i18NService.get("ch_stake"),
                                type: nt.a.Number
                            },
                            outputs: {
                                success: function(t) {
                                    n.setStakeToBets(+t), n.inputStake.nativeElement.value = n.stake, n.chipsSelected = [], n.betslipService.setStake(n.stake), n.modalService.close("base"), n.changeDetector.detectChanges()
                                }
                            }
                        }).afterClosed.subscribe(null, null, (function() {
                            n.setFastbetActivationState(!0)
                        })))
                    }, n.prototype.resetStakeToDefault = function() {
                        if (!this.inputStake.nativeElement.value) {
                            this.clearChipsSelected();
                            var n = new s.b(this.i18NService, this.changeDetector);
                            this.inputStake.nativeElement.value = n.transform(this.stake, {
                                noZeros: !0
                            }), this.setStakeToBets(this.stake), this.changeDetector.detectChanges()
                        }
                    }, n.prototype.addValueFromCashTicketChips = function(n) {
                        var t = this.stake.toString(),
                            l = this.stake.toString().includes(".");
                        if (this.chipsSelected.length > 0 && (this.resetStakeToDefault(), this.chipsSelected = [], this.setCashTo(0), t = this.stake.toString()), "," === n) !l && t.length >= 1 && "0" !== t && (this.isDotPushed = !0);
                        else if ("x" === n) 0 !== this.stake && (this.chipsSelected = [], this.setCashTo(0));
                        else if (t.length < this.maxTicketCashLength) {
                            if (l && t.split(".")[1].length >= this.decimalsLength) return;
                            var e = this.isDotPushed ? t + "." + n : "" + t + n; + e > 0 && this.setCashTo(+e), this.isDotPushed = !1
                        }
                    }, n.prototype.setCashTo = function(n) {
                        this.stake = n, this.inputStake.nativeElement.value = this.stake, this.betslipService.setStake(this.stake)
                    }, n.prototype.setStakeTo = function(n) {
                        this.setStakeToBets(n), this.inputStake.nativeElement.value = this.stake, this.betslipService.setStake(this.stake)
                    }, n.prototype.validateTicketExtData = function() {
                        var n = this.betslipService.getPrintProfileSettings().templateExtraInfo,
                            t = n && this.contextObjectService.contextObject && wl.a.parse(n).filter((function(n) {
                                return n.includes("name")
                            })).flatMap((function(n) {
                                return n[1]
                            })),
                            l = t && Object.keys(this.contextObjectService.contextObject),
                            e = l && l.length === t.length && l.every((function(n) {
                                return t.includes(n)
                            }));
                        this.betslipService.setTicketExtData(e ? JSON.stringify(this.contextObjectService.contextObject) : null)
                    }, n.prototype.hasMaxPayoutReachedPerTicket = function() {
                        return this.coreService.getBetSlip().getTicketErrors().some((function(n) {
                            return n.message === $.coreUtils.TicketErrorCodEnum.SENDTICKET_TICKETMAXWINNINGREACHED
                        }))
                    }, n.prototype.getCombinations = function(n, t) {
                        if (void 0 === n && (n = !1), void 0 === t && (t = !1), t || (this.lastActionGroups = []), this.betslipService.getBetMode() === $.BetModeEnum.SYSTEMBETMODE) {
                            var l = this.betslipInfo.systemBets,
                                e = l.findIndex((function(n) {
                                    return 1 === n.grouping
                                }));
                            e > -1 && l.splice(e, 1), this.combinations = l.filter((function(n) {
                                return !n._clData.maxCombicountError.isError
                            })), this.changeDetector.markForCheck()
                        }
                    }, n.prototype.fixHeightBetslipTabContent = function() {
                        var n = this;
                        this.betslipTabContent && setTimeout((function() {
                            var t = n.renderer.parentNode(n.betslipTabContent.nativeElement),
                                l = t.querySelector(".betslip-tab-header"),
                                e = t.getBoundingClientRect().height,
                                i = l.getBoundingClientRect().height;
                            n.betslipTabContentHeight = n.scaleService.getUnscaledHeight(e - i), n.changeDetector.markForCheck()
                        }), 0)
                    }, n.prototype.setNextBetMode = function() {
                        var n = this,
                            t = this.tabSet.tabs.toArray(),
                            l = (t.findIndex((function(t) {
                                return t.id === n.tabSet.selected
                            })) + 1) % t.length;
                        this.tabSet.select(l)
                    }, n.prototype.setPreviousBetMode = function() {
                        var n = this,
                            t = this.tabSet.tabs.toArray(),
                            l = t.findIndex((function(t) {
                                return t.id === n.tabSet.selected
                            })) - 1;
                        this.tabSet.select(l < 0 ? t.length - 1 : l)
                    }, n.prototype.setFastbetDisabledKeys = function() {
                        var n = this;
                        this.coreService.getShortcutController().getConfig().shortcutMap.forEach((function(t) {
                            var l = t.keys.map((function(n) {
                                var t = n.toLowerCase();
                                return t.startsWith("key") ? {
                                    key: t.replace("key", "")[0]
                                } : t.startsWith("shift") ? {
                                    shiftKey: !0
                                } : t.startsWith("control") ? {
                                    ctrlKey: !0
                                } : t.startsWith("alt") ? {
                                    altKey: !0
                                } : void 0
                            })).reduce((function(n, t) {
                                return Object.assign(n, t)
                            }), {
                                key: "",
                                ctrlKey: !1,
                                shiftKey: !1,
                                altKey: !1
                            });
                            n.fastbetDisabledKeys.push(l)
                        })), this.fastbetDisabledKeys = this.fastbetDisabledKeys.filter((function(n, t, l) {
                            return l.findIndex((function(t) {
                                return t.key === n.key && t.shiftKey === n.shiftKey && t.ctrlKey === n.ctrlKey
                            })) === t
                        }))
                    }, n.prototype.addSubscriptions = function() {
                        var n = this;
                        this.subscriptions.add(this.betslipService.onSendTicket.subscribe((function() {
                            n.sendTicket()
                        }))), this.subscriptions.add(this.betslipService.onBetModeChange.subscribe((function(t) {
                            n.tabChange(t)
                        }))), this.subscriptions.add(this.betslipService.onTicketBetAdded.subscribe((function() {
                            n.getCombinations(!0), n.changeDetector.markForCheck()
                        }))), this.subscriptions.add(this.betslipService.onTicketBetRemoved.subscribe((function() {
                            n.getCombinations(!0), n.changeDetector.markForCheck()
                        }))), this.subscriptions.add(this.betslipService.onStake.subscribe((function() {
                            var t;
                            n.betMode === $.BetModeEnum.SINGLEBETMODE ? (t = n.coreService.getBetSlip().getTicketBetErrors()).length > 0 && n.checkTypeSingleTicketError(t) : (t = n.coreService.getBetSlip().getSystemBetErrors()).length > 0 && n.checkTypeSystemTicketError(t);
                            n.betslipService.resolveTicketMaxWinningsReached(), n.getCombinations(!1, !0), setTimeout((function() {
                                return n.changeDetector.detectChanges()
                            }), 0)
                        }))), this.subscriptions.add(this.betslipService.onConfiguration.subscribe((function(t) {
                            n.configuration = t, n.fixHeightBetslipTabContent(), n.changeDetector.detectChanges()
                        }))), this.subscriptions.add(this.betslipService.onClear.subscribe((function() {
                            n.isStakeAdded = !1, 0 !== n.betslipInfo.events.length && n.betslipService.clear(), n.clearChipsSelected(), n.getCombinations(), n.changeDetector.markForCheck()
                        }))), this.subscriptions.add(this.betslipService.onToggleFullScreen.subscribe((function() {
                            n.fixHeightBetslipTabContent(), n.changeDetector.detectChanges()
                        }))), this.subscriptions.add(this.betslipService.onTabChange.subscribe((function() {
                            n.betMode = n.betslipService.getBetMode(), n.changeDetector.detectChanges()
                        }))), this.subscriptions.add(this.betslipService.onTicketBetUpdated.subscribe((function() {
                            return n.betslipInfo = n.betslipService.getBetslipInfo()
                        }))), this.subscriptions.add(this.betslipService.onTicketBetUpdated.subscribe((function() {
                            return n.betslipInfo = n.betslipService.getBetslipInfo()
                        }))), this.subscriptions.add(this.betslipService.onTicketBetUpdated.subscribe((function() {
                            return n.betslipInfo = n.betslipService.getBetslipInfo()
                        }))), this.subscriptions.add(this.coreService.onPlaylistChanged.subscribe((function(t) {
                            n.isSnRoulette = !(!t.filter.isSnFilter() || t.filter.mode !== $.coreModel.SnFilter.ModeEnum.ROULETTE)
                        }))), this.subscriptions.add(this.betslipService.onBet.subscribe((function() {
                            var t = n.betslipService.getStake();
                            n.checkIfCanBet(t) && n.isSnRoulette && n.setBetsOnBetslip(t)
                        }))), this.subscriptions.add(this.baseService.getCashTabSelected().asObservable().subscribe((function(t) {
                            n.cashTabSelected = t, n.changeDetector.detectChanges()
                        }))), this.subscriptions.add(this.contextObjectService.buttonStatus.subscribe((function(t) {
                            n.contextObjectButtonEnabled = t, n.changeDetector.detectChanges()
                        })))
                    }, n.prototype.subscribeToShortcuts = function() {
                        var n = this;
                        this.subscriptions.add(this.coreService.onShortcut(rn.a.SendTicket).subscribe((function() {
                            n.sendTicket()
                        }))), this.subscriptions.add(this.coreService.onShortcut(rn.a.CleanBetslip).subscribe((function() {
                            return n.clearBetslip()
                        }))), this.subscriptions.add(this.coreService.onShortcut(rn.a.NextBetMode).subscribe((function() {
                            n.setNextBetMode()
                        })))
                    }, n.prototype.showError = function(n, t) {
                        t ? this.notificationsService.warning(this.i18NService.get("ch_default_value_applied") + "<br> " + this.i18NService.get(n, {
                            stakeLimit: t
                        })) : this.notificationsService.warning("" + this.i18NService.get(n))
                    }, n.prototype.showTicketPolicyError = function(n) {
                        n.step && this.showError("ch_spain_ticket_policy_single_error", n.step)
                    }, n.prototype.onInputStakeFocusOut = function() {
                        this.resetStakeToDefault(), this.betslipService.enableSendTicketShortcut()
                    }, n.prototype.isSystemBetMode = function() {
                        return this.betMode === $.BetModeEnum.SYSTEMBETMODE
                    }, n.prototype.isSingleBetMode = function() {
                        return this.betMode === $.BetModeEnum.SINGLEBETMODE
                    }, n.prototype.disableAllShortcuts = function() {
                        this.betslipService.disableFullScreenShortcut(), this.betslipService.disableSendTicketShortcut(), this.betslipService.disableReprintLastTicketShortcut()
                    }, n.prototype.enableAllShortcuts = function() {
                        this.betslipService.enableFullScreenShortcut(), this.betslipService.enableSendTicketShortcut(), this.betslipService.enableReprintLastTicketShortcut()
                    }, n.prototype.checkTypeSingleTicketError = function(n) {
                        var t = this,
                            l = {
                                update: function() {
                                    return null
                                }
                            };
                        n.forEach((function(n) {
                            switch (n.error.errorType[0]) {
                                case "MAXPAYOUTPERBET":
                                    t.showError("ch_exceed_maximum_payout", n.ticketPolicyError);
                                    break;
                                case "MINSTAKEPERBET":
                                    t.showError("ch_min_stake_error", n.error.minStakeLimit);
                                    break;
                                case "MAXSTAKEPERBET":
                                    t.showError("ch_max_stake_error", n.error.maxStakeLimit);
                                    break;
                                case "ROUNDINGSTEP":
                                    t.showError("ch_rounding_stake_error", n.error.adjustedStake);
                                    break;
                                case "TICKETPOLICY":
                                    t.showTicketPolicyError(n.ticketPolicyError)
                            }
                            null !== n.error.adjustedStake && (t.coreService.getBetSlip().resolveTicketBetErrors(), l.update = function() {
                                return t.betslipService.onStake.next()
                            })
                        })), l.update()
                    }, n.prototype.checkTypeSystemTicketError = function(n) {
                        var t = this,
                            l = {
                                update: function() {
                                    return null
                                }
                            };
                        n.forEach((function(n) {
                            switch (n.stakeError.errorType[0]) {
                                case "MAXPAYOUTTICKET":
                                    t.showError("ch_exceed_maximum_payout", n.stakeError.maxPayoutTicketLimit);
                                    break;
                                case "MAXPAYOUTPERBET":
                                    t.showError("ch_exceed_maximum_payout", n.stakeError.maxPayoutPerBetLimit);
                                    break;
                                case "MINSTAKEPERBET":
                                    t.showError("ch_min_stake_error", n.stakeError.minStakePerBetLimit);
                                    break;
                                case "MAXSTAKEPERBET":
                                    t.showError("ch_max_stake_error", n.stakeError.maxStakePerBetLimit);
                                    break;
                                case "ROUNDINGSTEP":
                                    t.showError("ch_rounding_stake_error", n.stakeError.adjustedStake);
                                    break;
                                case "TICKETPOLICY":
                                    t.showTicketPolicyError(n.ticketPolicyError)
                            }
                            null !== n.stakeError.adjustedStake && (t.coreService.getBetSlip().resolveSystemBetErrors(), l.update = function() {
                                return t.betslipService.onStake.next()
                            })
                        })), l.update()
                    }, n.prototype.setFastbetActivationState = function(n) {
                        this.betslipService.enableFastbet(n), n ? this.betslipService.enableSendTicketShortcut() : this.betslipService.disableSendTicketShortcut()
                    }, n.prototype.checkIfCanBet = function(n) {
                        return !(0 === n || 0 === this.betslipInfo.events.length && !this.configuration.preStake || this.hasCombiBetStake() && this.isSystemBetMode())
                    }, n.prototype.setBetsOnBetslip = function(n) {
                        var t, l;
                        if (this.isSingleBetMode() || 0 === (null === (t = this.combinations) || void 0 === t ? void 0 : t.length)) {
                            if (0 === (null === (l = this.combinations) || void 0 === l ? void 0 : l.length) && this.tabSet.select(0), this.betslipService.setSingleStake(n), this.betslipInfo.events.length > 0) {
                                var e = this.betslipInfo.events[0]._clData.winningEventdata.compatibleMaxWinningg;
                                this.coreService.getBetSlip().linkMaxWinningToMaxPayout() && this.coreService.getBetSlip().getTotalMaxWinningItemized().ticketMaxPayoutLimit < e && this.betslipInfo.events.length > 0 && this.betslipService.setSingleStakeByBets(n)
                            }
                        } else {
                            var i = this.combinations[this.combinations.length - 1];
                            this.betslipService.setCombiStake([{
                                stake: n,
                                combiGroup: i.grouping
                            }]), this.lastActionGroups = [i.grouping]
                        }
                    }, n.prototype.launchLowCreditWarning = function() {
                        this.betslipService.isLowCredit() && this.notificationsService.warning("" + this.i18NService.get("ch_warning_low_credit")).subscribe()
                    }, n
                }(),
                Tl = [
                    ["[_nghost-%COMP%]{display:flex;height:100%;flex-direction:column}[_nghost-%COMP%] > .grid[_ngcontent-%COMP%]{height:100%}.betslip-header-section[_ngcontent-%COMP%]{max-height:115px}.betslip-header-section--hide[_ngcontent-%COMP%]{flex:0}.betslip-content-section[_ngcontent-%COMP%]{padding:15px 10px 0}.betslip-tab-set[_ngcontent-%COMP%]  .tab-set__contents>.tab-body{overflow:hidden}.betslip-tab-header[_ngcontent-%COMP%]{height:35px;padding:8px 10px;font-size:15px}.betslip-tab-header[_ngcontent-%COMP%]   .text__stake[_ngcontent-%COMP%]{display:inline-block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}.betslip-tab-content[_ngcontent-%COMP%]{overflow-x:hidden;overflow-y:auto}.betslip-footer-section[_ngcontent-%COMP%]{margin:12px 10px}.betslip-buttons[_ngcontent-%COMP%]{display:flex;height:70px}.betslip-buttons[_ngcontent-%COMP%]   .betslip-button[_ngcontent-%COMP%]{margin-right:4px;margin-left:4px}.betslip-buttons[_ngcontent-%COMP%]   .betslip-button[_ngcontent-%COMP%]:first-child{margin-left:0}.betslip-buttons[_ngcontent-%COMP%]   .betslip-button[_ngcontent-%COMP%]:last-child{margin-right:0}.betslip-button[_ngcontent-%COMP%]{display:flex;width:100%;height:100%;justify-content:center;align-items:center;cursor:pointer;border-radius:3px}.betslip-button[_ngcontent-%COMP%] > .betslipt-button__icon[_ngcontent-%COMP%]{font-size:36px}.betslip-button--disabled[_ngcontent-%COMP%]{cursor:default;opacity:.4}.betslip-separator[_ngcontent-%COMP%]{width:100%;height:1px;margin:17px 0 10px;border:0}.betslip-separator--up[_ngcontent-%COMP%]{margin:0}.betslip-bet-information[_ngcontent-%COMP%]{margin-bottom:8px}.betslip-bet-information__label[_ngcontent-%COMP%]{font-size:18px}.betslip-bet-information__label--margin[_ngcontent-%COMP%]{margin-right:10px}.betslip-bet-information__label--cashTicket[_ngcontent-%COMP%]{margin-bottom:8px;text-transform:uppercase}.betslip-bet-information__value[_ngcontent-%COMP%]{font-size:18px}.betslip-bet-information--cashManagement[_ngcontent-%COMP%]{margin-bottom:25px}.betslip-stake[_ngcontent-%COMP%]{width:100%;padding:8px 10px;font-size:32px;font-weight:700;font-family:DIN}.betslip-stake__input[_ngcontent-%COMP%]{padding:4px;cursor:pointer;border-radius:1px;overflow:hidden;text-align:right;text-overflow:ellipsis;white-space:nowrap;color:#030303;background-color:#fefefe}.betslip-stake__input--disabled[_ngcontent-%COMP%]{cursor:default;opacity:.4}.cashTicketChips[_ngcontent-%COMP%]{display:flex;flex-wrap:wrap;height:100%;margin-bottom:25px;font-size:32px;font-weight:700;gap:10px}.cashTicketChips[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{flex-basis:30%;flex-grow:1;height:auto}.clearChipCashTicket[_ngcontent-%COMP%]{color:red}.titleCashTicket[_ngcontent-%COMP%]{display:grid;width:100%;padding:10px;font-size:2rem}.titleCashTicket__desc[_ngcontent-%COMP%]{font-size:1rem;padding-bottom:10px}.cashTicketHeader[_ngcontent-%COMP%]{display:flex;align-items:center;height:40%;justify-content:center}"]
                ],
                jl = i.Gb({
                    encapsulation: 0,
                    styles: Tl,
                    data: {}
                });

            function El(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 6, "div", [
                    ["class", "titleCashTicket"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 2, "span", [
                    ["class", "titleCashTicket__desc"]
                ], null, null, null, null, null)), (n()(), i.cc(2, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(4, 0, null, null, 2, "span", [], null, null, null, null, null)), (n()(), i.cc(5, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i])], null, (function(n, t) {
                    n(t, 2, 0, i.dc(t, 2, 0, i.Ub(t, 3).transform("ch_cash_ticket_desc"))), n(t, 5, 0, i.dc(t, 5, 0, i.Ub(t, 6).transform("ch_cash_ticket_title")))
                }))
            }

            function Ul(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 4, "div", [], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 2, "div", [
                    ["class", "col col-12 betslip-bet-information__label betslip-bet-information__label--cashTicket"]
                ], null, null, null, null, null)), (n()(), i.cc(2, null, [" ", ": "])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(4, 0, [
                    [3, 0],
                    ["inputCashEntityName", 1]
                ], null, 0, "input", [
                    ["class", "betslip-stake betslip-stake__input"],
                    ["readonly", ""],
                    ["type", "text"]
                ], null, [
                    [null, "click"],
                    [null, "ngModelChange"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.openWordPad() && e);
                    "ngModelChange" === t && (e = !1 !== i.cashEntityName && e);
                    return e
                }), null, null))], null, (function(n, t) {
                    n(t, 2, 0, i.dc(t, 2, 0, i.Ub(t, 3).transform("ch_entity_Name")))
                }))
            }

            function Al(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "span", [
                    ["class", "betslip-chip betslip-button"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.addValueFromCashTicketChips(n.context.$implicit) && e);
                    return e
                }), null, null)), (n()(), i.cc(1, null, ["", ""]))], null, (function(n, t) {
                    n(t, 1, 0, t.context.$implicit)
                }))
            }

            function Bl(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 11, "div", [
                    ["class", "cashTicket col grid grid-column betslip-content-section"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 0, "hr", [
                    ["class", "betslip-separator betslip-separator--up"]
                ], null, null, null, null, null)), (n()(), i.Ib(2, 0, null, null, 4, "div", [
                    ["class", "cashTicketHeader"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, El)), i.Hb(4, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, Ul)), i.Hb(6, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.Ib(7, 0, null, null, 4, "div", [
                    ["class", "cashTicketChips"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, Al)), i.Hb(9, 278528, null, 0, Y.l, [i.eb, i.Z, i.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), (n()(), i.Ib(10, 0, null, null, 1, "span", [
                    ["class", "betslip-chip clearChipCashTicket betslip-button"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.addValueFromCashTicketChips("x") && e);
                    return e
                }), null, null)), (n()(), i.cc(-1, null, ["x"]))], (function(n, t) {
                    var l = t.component;
                    n(t, 4, 0, "cash-ticket" === l.cashTabSelected), n(t, 6, 0, "local-user" === l.cashTabSelected), n(t, 9, 0, l.cashTicketChipsValues)
                }), null)
            }

            function Hl(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 2, "grc-tab", [], null, null, null, Jn.b, Jn.a)), i.Hb(1, 114688, [
                    [5, 4]
                ], 0, Qn.a, [], {
                    header: [0, "header"],
                    id: [1, "id"]
                }, null), i.Wb(131072, s.j, [s.k, i.i])], (function(n, t) {
                    var l = t.component;
                    n(t, 1, 0, i.Mb(1, "", i.dc(t, 1, 0, i.Ub(t, 2).transform("ch_single")), ""), l.BetModeEnum.SINGLEBETMODE)
                }), null)
            }

            function Dl(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 2, "grc-tab", [], null, null, null, Jn.b, Jn.a)), i.Hb(1, 114688, [
                    [5, 4]
                ], 0, Qn.a, [], {
                    header: [0, "header"],
                    id: [1, "id"]
                }, null), i.Wb(131072, s.j, [s.k, i.i])], (function(n, t) {
                    var l = t.component;
                    n(t, 1, 0, i.Mb(1, "", i.dc(t, 1, 0, i.Ub(t, 2).transform("ch_combi")), ""), l.BetModeEnum.SYSTEMBETMODE)
                }), null)
            }

            function Ll(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 2, "span", [
                    ["class", "text__stake"]
                ], null, null, null, null, null)), (n()(), i.cc(1, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i])], null, (function(n, t) {
                    n(t, 1, 0, i.dc(t, 1, 0, i.Ub(t, 2).transform("ch_stake")))
                }))
            }

            function Nl(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-betslip-ticket-event", [], null, [
                    [null, "combinationsUpdated"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "combinationsUpdated" === t && (e = !1 !== i.onCombinationsUpdated() && e);
                    return e
                }), yt, st)), i.Hb(1, 245760, null, 0, rt, [i.i, M.a, s.k, m.a, b.a, $n.a], {
                    ticketEvent: [0, "ticketEvent"],
                    showStake: [1, "showStake"]
                }, {
                    combinationsUpdated: "combinationsUpdated"
                })], (function(n, t) {
                    var l = t.component;
                    n(t, 1, 0, t.context.$implicit, l.betMode === l.BetModeEnum.SINGLEBETMODE)
                }), null)
            }

            function zl(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-betslip-combinations", [], null, [
                    [null, "lastActionGroupChange"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "lastActionGroupChange" === t && (e = !1 !== i.onLastActionGroupChange(l) && e);
                    return e
                }), wt, xt)), i.Hb(1, 704512, null, 0, Ct, [$n.a], {
                    combinations: [0, "combinations"],
                    lastActionGroups: [1, "lastActionGroups"]
                }, {
                    lastActionGroupChange: "lastActionGroupChange"
                })], (function(n, t) {
                    var l = t.component;
                    n(t, 1, 0, l.combinations, l.lastActionGroups)
                }), null)
            }

            function Rl(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 31, "div", [
                    ["class", "col grid grid-column betslip-content-section"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 28, "grc-tab-set", [
                    ["tabSetClass", "col betslip-tab-set"]
                ], [
                    [8, "className", 0]
                ], [
                    [null, "selectedChange"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "selectedChange" === t && (e = !1 !== i.tabChange(l) && e);
                    return e
                }), Ot.b, Ot.a)), i.Hb(2, 4308992, [
                    [1, 4]
                ], 2, Pt.a, [i.i], {
                    stretch: [0, "stretch"],
                    sameContent: [1, "sameContent"],
                    selected: [2, "selected"],
                    tabSetClass: [3, "tabSetClass"]
                }, {
                    selectedChange: "selectedChange"
                }), i.ac(603979776, 5, {
                    tabsContent: 1
                }), i.ac(603979776, 6, {
                    tabsFixedContent: 1
                }), (n()(), i.xb(16777216, null, null, 1, null, Hl)), i.Hb(6, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, Dl)), i.Hb(8, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.Ib(9, 0, null, null, 20, "grc-tab-fixed", [
                    ["side", "content"]
                ], null, null, null, Mt.b, Mt.a)), i.Hb(10, 114688, [
                    [6, 4]
                ], 0, Tt.a, [], {
                    side: [0, "side"]
                }, null), (n()(), i.Ib(11, 0, null, 0, 11, "div", [
                    ["class", "grid betslip-tab-header"]
                ], null, null, null, null, null)), (n()(), i.Ib(12, 0, null, null, 3, "div", [
                    ["class", "col col-7"]
                ], null, null, null, null, null)), (n()(), i.Ib(13, 0, null, null, 2, "span", [], null, null, null, null, null)), (n()(), i.cc(14, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(16, 0, null, null, 3, "div", [
                    ["class", "col col-3 text-left"]
                ], null, null, null, null, null)), (n()(), i.Ib(17, 0, null, null, 2, "span", [], null, null, null, null, null)), (n()(), i.cc(18, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(20, 0, null, null, 2, "div", [
                    ["class", "col col-2 text-left"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, Ll)), i.Hb(22, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.Ib(23, 0, [
                    [4, 0],
                    ["betslipTapContent", 1]
                ], 0, 6, "div", [
                    ["class", "betslip-tab-content"]
                ], [
                    [4, "maxHeight", "px"]
                ], null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, Nl)), i.Hb(25, 278528, null, 0, Y.l, [i.eb, i.Z, i.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, zl)), i.Hb(27, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.Ib(28, 0, null, null, 1, "grc-betslip-fastbet", [], null, [
                    [null, "combinations"],
                    [null, "opened"],
                    ["document", "keydown.backspace"],
                    ["document", "keyup.enter"]
                ], (function(n, t, l) {
                    var e = !0,
                        o = n.component;
                    "document:keydown.backspace" === t && (e = !1 !== i.Ub(n, 29).onBackspace() && e);
                    "document:keyup.enter" === t && (e = !1 !== i.Ub(n, 29).onEnter() && e);
                    "combinations" === t && (e = !1 !== o.onLastActionGroupChange(l) && e);
                    "opened" === t && (e = !1 !== o.onFastbetOpened(l) && e);
                    return e
                }), Bt, At)), i.Hb(29, 245760, null, 0, Et, [i.i, M.a, $n.a], {
                    disabledKeys: [0, "disabledKeys"]
                }, {
                    combinations: "combinations",
                    opened: "opened"
                }), (n()(), i.Ib(30, 0, null, null, 1, "grc-betslip-bet-info", [], null, null, null, Nt, Lt)), i.Hb(31, 245760, null, 0, Ht, [i.i, M.a], null, null)], (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, !0, !0, l.betMode, "col betslip-tab-set"), n(t, 6, 0, l.configuration.tabsMode.includes(l.BetModeEnum.SINGLEBETMODE)), n(t, 8, 0, l.configuration.tabsMode.includes(l.BetModeEnum.SYSTEMBETMODE));
                    n(t, 10, 0, "content"), n(t, 22, 0, l.betMode === l.BetModeEnum.SINGLEBETMODE), n(t, 25, 0, l.betslipInfo.events), n(t, 27, 0, l.betMode !== l.BetModeEnum.SINGLEBETMODE), n(t, 29, 0, l.fastbetDisabledKeys), n(t, 31, 0)
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 1, 0, i.Ub(t, 2).tabSetClass), n(t, 14, 0, i.dc(t, 14, 0, i.Ub(t, 15).transform("ch_selection"))), n(t, 18, 0, i.dc(t, 18, 0, i.Ub(t, 19).transform("ch_odds"))), n(t, 23, 0, l.betslipTabContentHeight)
                }))
            }

            function Wl(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 2, "div", [
                    ["class", "col col-12 betslip-bet-information__label betslip-bet-information__label--cashTicket"]
                ], null, null, null, null, null)), (n()(), i.cc(1, null, [" ", ": "])), i.Wb(131072, s.j, [s.k, i.i])], null, (function(n, t) {
                    n(t, 1, 0, i.dc(t, 1, 0, i.Ub(t, 2).transform("ch_credit_amount")))
                }))
            }

            function Fl(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 2, "div", [
                    ["class", "col col-3 betslip-bet-information__label betslip-bet-information__label--margin"]
                ], null, null, null, null, null)), (n()(), i.cc(1, null, [" ", ": "])), i.Wb(131072, s.j, [s.k, i.i])], null, (function(n, t) {
                    n(t, 1, 0, i.dc(t, 1, 0, i.Ub(t, 2).transform("ch_stake")))
                }))
            }

            function Gl(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 18, "div", [
                    ["class", "grid grid-middle"]
                ], null, null, null, null, null)), i.Zb(512, null, Y.x, Y.y, [i.A, i.B, i.o, i.P]), i.Hb(2, 278528, null, 0, Y.k, [Y.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, Wl)), i.Hb(4, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, Fl)), i.Hb(6, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.Ib(7, 0, null, null, 11, "div", [
                    ["class", "col"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.openKeypad() && e);
                    return e
                }), null, null)), (n()(), i.Ib(8, 0, [
                    [2, 0],
                    ["inputStake", 1]
                ], null, 10, "input", [
                    ["class", "betslip-stake betslip-stake__input"],
                    ["type", "text"]
                ], [
                    [2, "ng-untouched", null],
                    [2, "ng-touched", null],
                    [2, "ng-pristine", null],
                    [2, "ng-dirty", null],
                    [2, "ng-valid", null],
                    [2, "ng-invalid", null],
                    [2, "ng-pending", null]
                ], [
                    [null, "ngModelChange"],
                    [null, "input"],
                    [null, "blur"],
                    [null, "compositionstart"],
                    [null, "compositionend"]
                ], (function(n, t, l) {
                    var e = !0,
                        o = n.component;
                    "input" === t && (e = !1 !== i.Ub(n, 12)._handleInput(l.target.value) && e);
                    "blur" === t && (e = !1 !== i.Ub(n, 12).onTouched() && e);
                    "compositionstart" === t && (e = !1 !== i.Ub(n, 12)._compositionStart() && e);
                    "compositionend" === t && (e = !1 !== i.Ub(n, 12)._compositionEnd(l.target.value) && e);
                    "ngModelChange" === t && (e = !1 !== o.stake && e);
                    return e
                }), null, null)), i.Zb(512, null, Y.x, Y.y, [i.A, i.B, i.o, i.P]), i.Hb(10, 278528, null, 0, Y.k, [Y.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), i.Xb(11, {
                    "betslip-stake__input--disabled": 0
                }), i.Hb(12, 16384, null, 0, jt.d, [i.P, i.o, [2, jt.a]], null, null), i.Zb(1024, null, jt.h, (function(n) {
                    return [n]
                }), [jt.d]), i.Hb(14, 671744, null, 0, jt.m, [
                    [8, null],
                    [8, null],
                    [8, null],
                    [6, jt.h]
                ], {
                    isDisabled: [0, "isDisabled"],
                    model: [1, "model"]
                }, {
                    update: "ngModelChange"
                }), i.Xb(15, {
                    noZeros: 0
                }), i.Wb(131072, s.b, [s.k, i.i]), i.Zb(2048, null, jt.i, null, [jt.m]), i.Hb(18, 16384, null, 0, jt.j, [
                    [4, jt.i]
                ], null, null)], (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, "grid grid-middle", l.isCashManagementOpened ? "betslip-bet-information--cashManagement" : "betslip-bet-information"), n(t, 4, 0, l.isCashManagementOpened), n(t, 6, 0, !l.isCashManagementOpened);
                    var e = n(t, 11, 0, l.isSnRoulette);
                    n(t, 10, 0, "betslip-stake betslip-stake__input", e);
                    var o = l.isSnRoulette,
                        r = i.dc(t, 14, 1, i.Ub(t, 16).transform(l.stake, n(t, 15, 0, !0)));
                    n(t, 14, 0, o, r)
                }), (function(n, t) {
                    n(t, 8, 0, i.Ub(t, 18).ngClassUntouched, i.Ub(t, 18).ngClassTouched, i.Ub(t, 18).ngClassPristine, i.Ub(t, 18).ngClassDirty, i.Ub(t, 18).ngClassValid, i.Ub(t, 18).ngClassInvalid, i.Ub(t, 18).ngClassPending)
                }))
            }

            function Zl(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "div", [
                    ["class", "betslip-button betslip-button--success"]
                ], [
                    [2, "betslip-button--disabled", null]
                ], [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.setStakeToBets(i.stake) && e);
                    return e
                }), null, null)), (n()(), i.Ib(1, 0, null, null, 0, "span", [
                    ["class", "icon icon-check betslipt-button__icon"]
                ], null, null, null, null, null))], null, (function(n, t) {
                    var l = t.component;
                    n(t, 0, 0, 0 === l.chips.length || 0 === l.stake || 0 === l.betslipInfo.events.length && !(l.configuration.preStake && l.configuration.hasOptionsSelected) || l.hasCombiBetStake() && l.betMode === l.BetModeEnum.SYSTEMBETMODE || l.isSnRoulette)
                }))
            }

            function Vl(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "div", [
                    ["class", "betslip-button betslip-button--danger"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.clearBetslip() && e);
                    return e
                }), null, null)), (n()(), i.Ib(1, 0, null, null, 0, "span", [
                    ["class", "icon icon-clear betslipt-button__icon"]
                ], null, null, null, null, null))], null, null)
            }

            function Kl(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "div", [
                    ["class", "betslip-button"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.printTicketById() && e);
                    return e
                }), null, null)), (n()(), i.Ib(1, 0, null, null, 0, "span", [
                    ["class", "icon icon-barcode betslipt-button__icon"]
                ], null, null, null, null, null))], null, null)
            }

            function Yl(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "div", [
                    ["class", "betslip-button betslip-button__printer"]
                ], [
                    [2, "betslip-button--disabled", null]
                ], [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== (!i.isDisabledPrint() && i.sendTicket()) && e);
                    return e
                }), null, null)), (n()(), i.Ib(1, 0, null, null, 0, "span", [
                    ["class", "icon icon-printer betslipt-button__icon"]
                ], null, null, null, null, null))], null, (function(n, t) {
                    n(t, 0, 0, t.component.isDisabledPrint())
                }))
            }

            function ql(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "div", [
                    ["class", "betslip-button betslip-button__printer"]
                ], [
                    [2, "betslip-button--disabled", null]
                ], [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== (!i.isDisabledPrintCashTicket() && i.sendCashManagement()) && e);
                    return e
                }), null, null)), (n()(), i.Ib(1, 0, null, null, 0, "span", [
                    ["class", "icon icon-printer betslipt-button__icon"]
                ], null, null, null, null, null))], null, (function(n, t) {
                    n(t, 0, 0, t.component.isDisabledPrintCashTicket())
                }))
            }

            function Xl(n) {
                return i.ec(2, [i.ac(671088640, 1, {
                    tabSet: 0
                }), i.ac(671088640, 2, {
                    inputStake: 0
                }), i.ac(671088640, 3, {
                    inputCashEntityName: 0
                }), i.ac(671088640, 4, {
                    tabContent: 0
                }), (n()(), i.Ib(4, 0, null, null, 27, "div", [
                    ["class", "grid grid-column betslip"]
                ], null, null, null, null, null)), (n()(), i.Ib(5, 0, null, null, 5, "div", [
                    ["class", "col betslip-header-section"]
                ], null, null, null, null, null)), i.Zb(512, null, Y.x, Y.y, [i.A, i.B, i.o, i.P]), i.Hb(7, 278528, null, 0, Y.k, [Y.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), i.Xb(8, {
                    "betslip-header-section--hide": 0
                }), (n()(), i.Ib(9, 0, null, null, 1, "grc-betslip-header", [], null, [
                    [null, "openedMenu"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "openedMenu" === t && (e = !1 !== i.showHiddenSection(l) && e);
                    return e
                }), gl, rl)), i.Hb(10, 114688, null, 0, il, [m.a, _.a, i.i], {
                    isMenuOpened: [0, "isMenuOpened"]
                }, {
                    openedMenu: "openedMenu"
                }), (n()(), i.xb(16777216, null, null, 1, null, Bl)), i.Hb(12, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, Rl)), i.Hb(14, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.Ib(15, 0, null, null, 16, "div", [
                    ["class", "grid grid-column betslip-footer-section"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, Gl)), i.Hb(17, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.Ib(18, 0, null, null, 1, "grc-betslip-chips", [], null, [
                    [null, "chipSelected"],
                    [null, "chipUnselected"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "chipSelected" === t && (e = !1 !== i.selectChip(l) && e);
                    "chipUnselected" === t && (e = !1 !== i.unselectChip(l) && e);
                    return e
                }), Il, kl)), i.Hb(19, 114688, null, 0, yl, [], {
                    chips: [0, "chips"],
                    chipsSelected: [1, "chipsSelected"],
                    isSnRoulette: [2, "isSnRoulette"]
                }, {
                    chipSelected: "chipSelected",
                    chipUnselected: "chipUnselected"
                }), (n()(), i.Ib(20, 0, null, null, 0, "hr", [
                    ["class", "betslip-separator"]
                ], null, null, null, null, null)), (n()(), i.Ib(21, 0, null, null, 10, "div", [
                    ["class", "betslip-buttons"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, Zl)), i.Hb(23, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, Vl)), i.Hb(25, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, Kl)), i.Hb(27, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, Yl)), i.Hb(29, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, ql)), i.Hb(31, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(n, t) {
                    var l = t.component,
                        e = n(t, 8, 0, l.hideHeaderSection);
                    n(t, 7, 0, "col betslip-header-section", e), n(t, 10, 0, l.isMenuOpened), n(t, 12, 0, l.isCashManagementOpened), n(t, 14, 0, !l.isCashManagementOpened), n(t, 17, 0, l.chips.length > 0), n(t, 19, 0, l.chips, l.chipsSelected, l.isSnRoulette), n(t, 23, 0, !l.isCashManagementOpened), n(t, 25, 0, !l.isCashManagementOpened), n(t, 27, 0, l.hasBarCodeButton), n(t, 29, 0, !l.isCashManagementOpened), n(t, 31, 0, l.isCashManagementOpened)
                }), null)
            }
            i.Eb("grc-page-betslip", Ml, (function(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-page-betslip", [], null, [
                    ["document", "keydown"],
                    ["document", "keyup.enter"],
                    ["window", "resize"]
                ], (function(n, t, l) {
                    var e = !0;
                    "document:keydown" === t && (e = !1 !== i.Ub(n, 1).onKeydown(l) && e);
                    "document:keyup.enter" === t && (e = !1 !== i.Ub(n, 1).onEnter() && e);
                    "window:resize" === t && (e = !1 !== i.Ub(n, 1).onResize() && e);
                    return e
                }), Xl, jl)), i.Hb(1, 245760, null, 0, Ml, [i.i, i.P, b.a, M.a, m.a, s.k, D.a, $n.a, s.k, Un.a, y], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                isMenuOpened: "isMenuOpened",
                isCashManagementOpened: "isCashManagementOpened"
            }, {
                openedMenu: "openedMenu"
            }, []);
            var Jl = l("ojct"),
                Ql = function() {
                    function n(n, t) {
                        this.modalStoreService = n, this.viewContainerRef = t, this.modelContentDestroyable = !0
                    }
                    return n.prototype.ngOnInit = function() {
                        this.modalStoreService.register(this.modalContent, this.viewContainerRef, this.modelContentDestroyable)
                    }, n.prototype.ngOnDestroy = function() {
                        this.modalStoreService.unregister(this.modalContent)
                    }, n
                }(),
                $l = function() {
                    function n(n, t) {
                        this.cd = n, this.modalStoreService = t, this.destroyOnClose = !0, this.clazz = !0, this.hidden = !0, this.isOpening = !1
                    }
                    return n.prototype.ngOnInit = function() {
                        var n = this;
                        this.id || (this.id = "main"), this.modalStoreService.toggleModal.subscribe((function(t) {
                            t.id === n.id && (t.open ? n.open() : n.close(), n.cd.markForCheck())
                        })), window.addEventListener("message", (function(t) {
                            "close modal shopadmin" === t.data && n.close()
                        }), !1)
                    }, n.prototype.open = function() {
                        this.hidden = !1, this.isOpening = !0
                    }, n.prototype.close = function() {
                        this.hidden || (this.isOpening = !1)
                    }, n.prototype.postClose = function(n) {
                        this.hidden = !0, n ? this.modalStoreService.postClose(this.id, n) : this.modalStoreService.postClose(this.id), this.cd.detectChanges()
                    }, n.prototype.onModalAnimationDone = function(n) {
                        0 == +n.toState && this.postClose()
                    }, n.prototype.onClick = function() {
                        this.closeOnClickOutside && this.close()
                    }, n.prototype.onDataSaved = function(n) {
                        this.postClose(n)
                    }, n
                }(),
                ne = [
                    [".modal[_nghost-%COMP%]{position:absolute;top:25px;left:0;z-index:99998;display:flex;width:100%;height:calc(100% - 25px);align-items:center;justify-content:center}.modal--hidden[_nghost-%COMP%]{display:none}.modal-content-container[_ngcontent-%COMP%]{perspective:1000px;perspective-origin:50% 50%}"]
                ],
                te = i.Gb({
                    encapsulation: 0,
                    styles: ne,
                    data: {
                        animation: [{
                            type: 7,
                            name: "modalAnimation",
                            definitions: [{
                                type: 0,
                                name: "0",
                                styles: {
                                    type: 6,
                                    styles: {
                                        opacity: 0
                                    },
                                    offset: null
                                },
                                options: void 0
                            }, {
                                type: 0,
                                name: "1",
                                styles: {
                                    type: 6,
                                    styles: {
                                        opacity: 1
                                    },
                                    offset: null
                                },
                                options: void 0
                            }, {
                                type: 1,
                                expr: "0 => 1",
                                animation: [{
                                    type: 3,
                                    steps: [{
                                        type: 4,
                                        styles: {
                                            type: 6,
                                            styles: {
                                                opacity: 1
                                            },
                                            offset: null
                                        },
                                        timings: "150ms ease-in"
                                    }, {
                                        type: 11,
                                        selector: ".modal-content",
                                        animation: [{
                                            type: 6,
                                            styles: {
                                                transform: "rotateY(-70deg)"
                                            },
                                            offset: null
                                        }, {
                                            type: 4,
                                            styles: {
                                                type: 6,
                                                styles: {
                                                    transform: "rotateY(0deg)"
                                                },
                                                offset: null
                                            },
                                            timings: "150ms ease-in"
                                        }],
                                        options: null
                                    }],
                                    options: null
                                }],
                                options: null
                            }, {
                                type: 1,
                                expr: "1 => 0",
                                animation: [{
                                    type: 3,
                                    steps: [{
                                        type: 4,
                                        styles: {
                                            type: 6,
                                            styles: {
                                                opacity: 0
                                            },
                                            offset: null
                                        },
                                        timings: "150ms ease-in"
                                    }, {
                                        type: 11,
                                        selector: ".modal-content",
                                        animation: [{
                                            type: 6,
                                            styles: {
                                                transform: "rotateY(0deg)"
                                            },
                                            offset: null
                                        }, {
                                            type: 4,
                                            styles: {
                                                type: 6,
                                                styles: {
                                                    transform: "rotateY(-70deg)"
                                                },
                                                offset: null
                                            },
                                            timings: "150ms ease-in"
                                        }],
                                        options: null
                                    }],
                                    options: null
                                }],
                                options: null
                            }],
                            options: {}
                        }]
                    }
                });

            function le(n) {
                return i.ec(0, [(n()(), i.xb(0, null, null, 0))], null, null)
            }

            function ee(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 3, "div", [
                    ["class", "modal-content-container"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0;
                    "click" === t && (e = !1 !== l.stopPropagation() && e);
                    return e
                }), null, null)), (n()(), i.Ib(1, 0, null, null, 2, "div", [
                    ["class", "modal-content"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, le)), i.Hb(3, 212992, null, 0, Ql, [Jl.a, i.eb], {
                    modalContent: [0, "modalContent"],
                    modelContentDestroyable: [1, "modelContentDestroyable"]
                }, null)], (function(n, t) {
                    var l = t.component;
                    n(t, 3, 0, l.id, l.destroyOnClose)
                }), null)
            }
            i.Eb("grc-modal", $l, (function(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-modal", [], [
                    [2, "modal", null],
                    [2, "modal--hidden", null],
                    [40, "@modalAnimation", 0]
                ], [
                    ["component", "@modalAnimation.done"],
                    [null, "click"],
                    ["document", "actionDataDialog"]
                ], (function(n, t, l) {
                    var e = !0;
                    "component:@modalAnimation.done" === t && (e = !1 !== i.Ub(n, 1).onModalAnimationDone(l) && e);
                    "click" === t && (e = !1 !== i.Ub(n, 1).onClick() && e);
                    "document:actionDataDialog" === t && (e = !1 !== i.Ub(n, 1).onDataSaved(l) && e);
                    return e
                }), ee, te)), i.Hb(1, 114688, null, 0, $l, [i.i, Jl.a], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), (function(n, t) {
                    n(t, 0, 0, i.Ub(t, 1).clazz, i.Ub(t, 1).hidden, i.Ub(t, 1).isOpening)
                }))
            }), {
                id: "id",
                closeOnClickOutside: "closeOnClickOutside",
                destroyOnClose: "destroyOnClose"
            }, {}, []);
            var ie = l("+iOv"),
                oe = function() {
                    function n(n, t, l) {
                        this.componentFactoryResolver = n, this.appRef = t, this.injector = l
                    }
                    return n.prototype.show = function(n) {
                        this.componentRef = this.componentFactoryResolver.resolveComponentFactory(ie.a).create(this.injector), this.componentRef.instance.message = n.input.message, this.componentRef.instance.isProcessing = n.input.isProcessing, this.appRef.attachView(this.componentRef.hostView);
                        var t = this.componentRef.hostView.rootNodes[0];
                        document.body.appendChild(t)
                    }, n.prototype.hide = function() {
                        this.componentRef && this.componentRef.destroy()
                    }, n
                }(),
                re = l("7HL8"),
                ue = function() {
                    function n(n, t, l, e, o, r, u, s) {
                        this.cd = n, this.coreService = t, this.basePageService = l, this.betslipService = e, this.printerService = o, this.waitingScreenService = r, this.modalService = u, this.externalConfigService = s, this.openedMenu = new i.q, this.playlists = [], this.closedMarkets = !1, this.errorConnection = !1, this.processing = !1, this.activatedGame = !1, this.isMenuOpened = !1, this.isCashManagementOpened = !1, this.allowCashManagement = !1, this.subscriptions = new un.a, this.integration = new x, this.integration.start()
                    }
                    return n.prototype.onRouterOutletActivate = function(n) {
                        this.isCashManagementOpened = n instanceof Pl.a
                    }, n.prototype.ngOnInit = function() {
                        var n, t, l, e, i = this;
                        this.allowCashManagement = null === (e = null === (l = null === (t = null === (n = this.coreService.getSessionController()) || void 0 === n ? void 0 : n.getSessionSettings()) || void 0 === t ? void 0 : t.calculationContext) || void 0 === l ? void 0 : l.ticketContext) || void 0 === e ? void 0 : e.cashTicket, this.coreService.getAllEventControllers().forEach((function(n) {
                            n.content.isPlaylistContent() && i.playlists.push(n.content._clData.playlist)
                        })), this.subscriptions.add(this.basePageService.closedMarkets.subscribe((function(n) {
                            i.closedMarkets = n, i.betslipService.enableFastbet(!n), i.cd.detectChanges()
                        }))), this.subscriptions.add(this.basePageService.activatedGame.subscribe((function(n) {
                            i.activatedGame = n, i.betslipService.enableFastbet(n), i.cd.markForCheck()
                        }))), this.subscriptions.add(Object(P.a)(this.coreService.getSessionController().messageManager.onRestartMessage).subscribe((function() {
                            i.integration.onRestart(), window.location.reload()
                        }))), this.subscriptions.add(this.betslipService.processing.subscribe((function(n) {
                            n ? i.waitingScreenService.show({
                                input: {
                                    message: "ch_processing",
                                    isProcessing: !0
                                }
                            }) : i.waitingScreenService.hide()
                        }))), this.subscriptions.add(this.coreService.onShortcut(rn.a.CloseModal).subscribe((function() {
                            i.modalService.closeLastOpened()
                        }))), this.betslipService.init(), this.printerService.init(), this.coreService.getShortcutController().disableKey(re.a.NumpadAdd), this.suscribeInactivityChange()
                    }, n.prototype.ngOnDestroy = function() {
                        this.betslipService.destroy(), this.subscriptions.unsubscribe()
                    }, n.prototype.onCashManagmentTabSelected = function(n) {
                        console.log(n)
                    }, n.prototype.showHiddenSection = function(n) {
                        this.isMenuOpened = n
                    }, n.prototype.showGameSelector = function() {
                        var n = this.externalConfigService.getEnvironmentConfig().configParams.showGameSelector;
                        return null == n || n
                    }, n.prototype.suscribeInactivityChange = function() {
                        var n = this,
                            t = this.coreService.getInactivityController(),
                            l = !1;
                        this.subscriptions.add(Object(P.a)(t.onStatusChange).subscribe((function(t) {
                            t.status === rn.b.IDLE && (l = !0, n.coreService.logOut(l))
                        })))
                    }, n
                }(),
                se = [
                    ["[_nghost-%COMP%] > .grid[_ngcontent-%COMP%]{height:100%}.hidden-section[_ngcontent-%COMP%]{position:absolute;z-index:12;width:calc(100% - 367px);height:100%;background-color:#455a64;opacity:.5}.left-section[_ngcontent-%COMP%]{max-width:calc(100% - 367px)}.header-section[_ngcontent-%COMP%]{position:relative;max-height:115px}.main-section[_ngcontent-%COMP%]{position:relative;padding:15px 15px 15px 0}.main-section-max-height[_ngcontent-%COMP%]{max-height:calc(100% - 80px - 124px)}.footer-section[_ngcontent-%COMP%]{position:relative;max-height:90px}.betslip-section[_ngcontent-%COMP%]{position:relative;min-width:367px;max-width:367px}.overlay[_ngcontent-%COMP%]{position:absolute;top:0;left:0;z-index:999;width:100%;height:100%}.modal[id=base-front][_ngcontent-%COMP%]{z-index:9;max-width:calc(100% - 368px)}.modal[id=base-front][_ngcontent-%COMP%]  .modal-content-container{width:100%;padding:0 20px}.modal[id=base-main-section][_ngcontent-%COMP%]{z-index:8;max-width:calc(100% - 383px);max-height:calc(100% - 235px);margin-top:105px}.modal[id=base-main-section][_ngcontent-%COMP%]  .modal-content-container{width:100%;height:100%}.modal[id=base-main-section][_ngcontent-%COMP%]  .modal-content-container>.modal-content{width:100%;height:100%}.modal[id=base-help][_ngcontent-%COMP%]  .modal-content-container{width:100%;height:100%;padding:65px 100px}.modal[id=base-help][_ngcontent-%COMP%]  .modal-content-container>:first-child{width:100%;height:100%}.modal[id=connections-problems][_ngcontent-%COMP%]  .modal-content-container{perspective:none;opacity:.7}"]
                ],
                ce = i.Gb({
                    encapsulation: 0,
                    styles: se,
                    data: {}
                });

            function ae(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 0, "div", [
                    ["class", "hidden-section"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 != (i.isMenuOpened = !i.isMenuOpened) && e);
                    return e
                }), null, null))], null, null)
            }

            function de(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-markets-closed", [], null, null, null, F, W)), i.Hb(1, 114688, null, 0, z, [], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }

            function pe(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-loading", [], null, null, null, K, V)), i.Hb(1, 114688, null, 0, G.a, [], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }

            function be(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 2, "div", [
                    ["class", "col footer-section"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 1, "grc-game-navbar", [], null, null, null, fn, dn)), i.Hb(2, 245760, null, 0, sn, [cn.b, m.a, r.l, _.a], {
                    playlists: [0, "playlists"],
                    allowCashManagement: [1, "allowCashManagement"],
                    isCashManagementOpened: [2, "isCashManagementOpened"]
                }, null)], (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, l.playlists, l.allowCashManagement, l.isCashManagementOpened)
                }), null)
            }

            function he(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 21, "div", [
                    ["class", "grid grid-no-wrap base"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, ae)), i.Hb(2, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.Ib(3, 0, null, null, 15, "div", [
                    ["class", "col grid grid-column left-section"]
                ], null, null, null, null, null)), (n()(), i.Ib(4, 0, null, null, 2, "div", [
                    ["class", "col header-section"]
                ], null, null, null, null, null)), (n()(), i.Ib(5, 0, null, null, 1, "grc-header", [], null, null, null, Xn, Hn)), i.Hb(6, 245760, null, 0, An, [i.i, _.a, m.a, Un.a], {
                    isCashManagementOpened: [0, "isCashManagementOpened"]
                }, null), (n()(), i.Ib(7, 0, null, null, 9, "div", [
                    ["class", "col main-section"]
                ], null, null, null, null, null)), i.Zb(512, null, Y.x, Y.y, [i.A, i.B, i.o, i.P]), i.Hb(9, 278528, null, 0, Y.k, [Y.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), i.Xb(10, {
                    "main-section-max-height": 0
                }), (n()(), i.Ib(11, 16777216, null, null, 1, "router-outlet", [], null, [
                    [null, "activate"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "activate" === t && (e = !1 !== i.onRouterOutletActivate(l) && e);
                    return e
                }), null, null)), i.Hb(12, 212992, null, 0, r.q, [r.b, i.eb, i.l, [8, null], i.i], null, {
                    activateEvents: "activate"
                }), (n()(), i.xb(16777216, null, null, 1, null, de)), i.Hb(14, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, pe)), i.Hb(16, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, be)), i.Hb(18, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.Ib(19, 0, null, null, 2, "div", [
                    ["class", "betslip-section"]
                ], null, null, null, null, null)), (n()(), i.Ib(20, 0, null, null, 1, "grc-page-betslip", [], null, [
                    [null, "openedMenu"],
                    ["document", "keydown"],
                    ["document", "keyup.enter"],
                    ["window", "resize"]
                ], (function(n, t, l) {
                    var e = !0,
                        o = n.component;
                    "document:keydown" === t && (e = !1 !== i.Ub(n, 21).onKeydown(l) && e);
                    "document:keyup.enter" === t && (e = !1 !== i.Ub(n, 21).onEnter() && e);
                    "window:resize" === t && (e = !1 !== i.Ub(n, 21).onResize() && e);
                    "openedMenu" === t && (e = !1 !== o.showHiddenSection(l) && e);
                    return e
                }), Xl, jl)), i.Hb(21, 245760, null, 0, Ml, [i.i, i.P, b.a, M.a, m.a, s.k, D.a, $n.a, s.k, Un.a, y], {
                    isMenuOpened: [0, "isMenuOpened"],
                    isCashManagementOpened: [1, "isCashManagementOpened"]
                }, {
                    openedMenu: "openedMenu"
                }), (n()(), i.Ib(22, 0, null, null, 1, "grc-modal", [
                    ["id", "base"]
                ], [
                    [2, "modal", null],
                    [2, "modal--hidden", null],
                    [40, "@modalAnimation", 0]
                ], [
                    ["component", "@modalAnimation.done"],
                    [null, "click"],
                    ["document", "actionDataDialog"]
                ], (function(n, t, l) {
                    var e = !0;
                    "component:@modalAnimation.done" === t && (e = !1 !== i.Ub(n, 23).onModalAnimationDone(l) && e);
                    "click" === t && (e = !1 !== i.Ub(n, 23).onClick() && e);
                    "document:actionDataDialog" === t && (e = !1 !== i.Ub(n, 23).onDataSaved(l) && e);
                    return e
                }), ee, te)), i.Hb(23, 114688, null, 0, $l, [i.i, Jl.a], {
                    id: [0, "id"],
                    closeOnClickOutside: [1, "closeOnClickOutside"]
                }, null), (n()(), i.Ib(24, 0, null, null, 1, "grc-modal", [
                    ["id", "base-information"]
                ], [
                    [2, "modal", null],
                    [2, "modal--hidden", null],
                    [40, "@modalAnimation", 0]
                ], [
                    ["component", "@modalAnimation.done"],
                    [null, "click"],
                    ["document", "actionDataDialog"]
                ], (function(n, t, l) {
                    var e = !0;
                    "component:@modalAnimation.done" === t && (e = !1 !== i.Ub(n, 25).onModalAnimationDone(l) && e);
                    "click" === t && (e = !1 !== i.Ub(n, 25).onClick() && e);
                    "document:actionDataDialog" === t && (e = !1 !== i.Ub(n, 25).onDataSaved(l) && e);
                    return e
                }), ee, te)), i.Hb(25, 114688, null, 0, $l, [i.i, Jl.a], {
                    id: [0, "id"],
                    closeOnClickOutside: [1, "closeOnClickOutside"]
                }, null), (n()(), i.Ib(26, 0, null, null, 1, "grc-modal", [
                    ["id", "base-help"]
                ], [
                    [2, "modal", null],
                    [2, "modal--hidden", null],
                    [40, "@modalAnimation", 0]
                ], [
                    ["component", "@modalAnimation.done"],
                    [null, "click"],
                    ["document", "actionDataDialog"]
                ], (function(n, t, l) {
                    var e = !0;
                    "component:@modalAnimation.done" === t && (e = !1 !== i.Ub(n, 27).onModalAnimationDone(l) && e);
                    "click" === t && (e = !1 !== i.Ub(n, 27).onClick() && e);
                    "document:actionDataDialog" === t && (e = !1 !== i.Ub(n, 27).onDataSaved(l) && e);
                    return e
                }), ee, te)), i.Hb(27, 114688, null, 0, $l, [i.i, Jl.a], {
                    id: [0, "id"],
                    closeOnClickOutside: [1, "closeOnClickOutside"]
                }, null), (n()(), i.Ib(28, 0, null, null, 1, "grc-modal", [
                    ["id", "base-front"]
                ], [
                    [2, "modal", null],
                    [2, "modal--hidden", null],
                    [40, "@modalAnimation", 0]
                ], [
                    ["component", "@modalAnimation.done"],
                    [null, "click"],
                    ["document", "actionDataDialog"]
                ], (function(n, t, l) {
                    var e = !0;
                    "component:@modalAnimation.done" === t && (e = !1 !== i.Ub(n, 29).onModalAnimationDone(l) && e);
                    "click" === t && (e = !1 !== i.Ub(n, 29).onClick() && e);
                    "document:actionDataDialog" === t && (e = !1 !== i.Ub(n, 29).onDataSaved(l) && e);
                    return e
                }), ee, te)), i.Hb(29, 114688, null, 0, $l, [i.i, Jl.a], {
                    id: [0, "id"],
                    closeOnClickOutside: [1, "closeOnClickOutside"]
                }, null), (n()(), i.Ib(30, 0, null, null, 1, "grc-modal", [
                    ["id", "base-main-section"]
                ], [
                    [2, "modal", null],
                    [2, "modal--hidden", null],
                    [40, "@modalAnimation", 0]
                ], [
                    ["component", "@modalAnimation.done"],
                    [null, "click"],
                    ["document", "actionDataDialog"]
                ], (function(n, t, l) {
                    var e = !0;
                    "component:@modalAnimation.done" === t && (e = !1 !== i.Ub(n, 31).onModalAnimationDone(l) && e);
                    "click" === t && (e = !1 !== i.Ub(n, 31).onClick() && e);
                    "document:actionDataDialog" === t && (e = !1 !== i.Ub(n, 31).onDataSaved(l) && e);
                    return e
                }), ee, te)), i.Hb(31, 114688, null, 0, $l, [i.i, Jl.a], {
                    id: [0, "id"],
                    closeOnClickOutside: [1, "closeOnClickOutside"]
                }, null), (n()(), i.Ib(32, 0, null, null, 1, "grc-modal", [
                    ["id", "shopadmin"]
                ], [
                    [2, "modal", null],
                    [2, "modal--hidden", null],
                    [40, "@modalAnimation", 0]
                ], [
                    ["component", "@modalAnimation.done"],
                    [null, "click"],
                    ["document", "actionDataDialog"]
                ], (function(n, t, l) {
                    var e = !0;
                    "component:@modalAnimation.done" === t && (e = !1 !== i.Ub(n, 33).onModalAnimationDone(l) && e);
                    "click" === t && (e = !1 !== i.Ub(n, 33).onClick() && e);
                    "document:actionDataDialog" === t && (e = !1 !== i.Ub(n, 33).onDataSaved(l) && e);
                    return e
                }), ee, te)), i.Hb(33, 114688, null, 0, $l, [i.i, Jl.a], {
                    id: [0, "id"],
                    closeOnClickOutside: [1, "closeOnClickOutside"],
                    destroyOnClose: [2, "destroyOnClose"]
                }, null), (n()(), i.Ib(34, 0, null, null, 1, "grc-modal", [
                    ["id", "connections-problems"]
                ], [
                    [2, "modal", null],
                    [2, "modal--hidden", null],
                    [40, "@modalAnimation", 0]
                ], [
                    ["component", "@modalAnimation.done"],
                    [null, "click"],
                    ["document", "actionDataDialog"]
                ], (function(n, t, l) {
                    var e = !0;
                    "component:@modalAnimation.done" === t && (e = !1 !== i.Ub(n, 35).onModalAnimationDone(l) && e);
                    "click" === t && (e = !1 !== i.Ub(n, 35).onClick() && e);
                    "document:actionDataDialog" === t && (e = !1 !== i.Ub(n, 35).onDataSaved(l) && e);
                    return e
                }), ee, te)), i.Hb(35, 114688, null, 0, $l, [i.i, Jl.a], {
                    id: [0, "id"],
                    closeOnClickOutside: [1, "closeOnClickOutside"]
                }, null)], (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, l.isMenuOpened), n(t, 6, 0, l.isCashManagementOpened);
                    var e = n(t, 10, 0, l.showGameSelector());
                    n(t, 9, 0, "col main-section", e), n(t, 12, 0), n(t, 14, 0, l.closedMarkets), n(t, 16, 0, !l.activatedGame), n(t, 18, 0, l.showGameSelector()), n(t, 21, 0, l.isMenuOpened, l.isCashManagementOpened);
                    n(t, 23, 0, "base", !0);
                    n(t, 25, 0, "base-information", !1);
                    n(t, 27, 0, "base-help", !1);
                    n(t, 29, 0, "base-front", !1);
                    n(t, 31, 0, "base-main-section", !1);
                    n(t, 33, 0, "shopadmin", !1, !1);
                    n(t, 35, 0, "connections-problems", !1)
                }), (function(n, t) {
                    n(t, 22, 0, i.Ub(t, 23).clazz, i.Ub(t, 23).hidden, i.Ub(t, 23).isOpening), n(t, 24, 0, i.Ub(t, 25).clazz, i.Ub(t, 25).hidden, i.Ub(t, 25).isOpening), n(t, 26, 0, i.Ub(t, 27).clazz, i.Ub(t, 27).hidden, i.Ub(t, 27).isOpening), n(t, 28, 0, i.Ub(t, 29).clazz, i.Ub(t, 29).hidden, i.Ub(t, 29).isOpening), n(t, 30, 0, i.Ub(t, 31).clazz, i.Ub(t, 31).hidden, i.Ub(t, 31).isOpening), n(t, 32, 0, i.Ub(t, 33).clazz, i.Ub(t, 33).hidden, i.Ub(t, 33).isOpening), n(t, 34, 0, i.Ub(t, 35).clazz, i.Ub(t, 35).hidden, i.Ub(t, 35).isOpening)
                }))
            }
            var ge = i.Eb("grc-page-base", ue, (function(n) {
                    return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 2, "grc-page-base", [], null, null, null, he, ce)), i.Zb(135680, null, r.q, r.q, [r.b, i.eb, i.l, [8, null], i.i]), i.Hb(2, 245760, null, 0, ue, [i.i, m.a, Un.a, M.a, qt, oe, $n.a, _.a], null, null)], (function(n, t) {
                        n(t, 2, 0)
                    }), null)
                }), {}, {
                    openedMenu: "openedMenu"
                }, []),
                fe = [
                    [".cash-ticket-container[_ngcontent-%COMP%]{display:grid;grid-template-rows:70% 30%;height:100%;width:100%}.cash-ticket-cards-container[_ngcontent-%COMP%]{display:grid;-moz-column-gap:100px;column-gap:100px;justify-content:center;align-content:space-evenly;grid-template-columns:repeat(3,300px)}.cash-ticket-card[_ngcontent-%COMP%]{height:400px;position:relative;border-radius:20px;display:grid;align-items:center;justify-content:center;font-size:2rem;padding:20px;background-color:#fff;text-align:center;align-content:space-evenly}.cash-ticket-card__number[_ngcontent-%COMP%]{position:absolute;top:0;font-family:DIN;font-size:100px;font-weight:700;color:rgba(0,0,0,.14)}.cash-ticket-card__icon[_ngcontent-%COMP%]{font-size:5rem;margin:0 auto;width:100px;border-radius:50px;height:100px;color:#fff}.cash-ticket-card__title[_ngcontent-%COMP%]{font-size:2rem;font-weight:700}.cash-ticket-card__description[_ngcontent-%COMP%]{font-size:1.5rem}.cash-ticket-scan-container[_ngcontent-%COMP%]{display:grid;grid-template-columns:75%;justify-content:center}.cash-ticket-scan-container[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{display:flex;justify-content:center;font-size:2rem;border-top:1px solid #000;align-items:center}.cash-ticket-scan__icon[_ngcontent-%COMP%]{font-size:5rem;width:100px;border-radius:50px;height:100px;text-align:center;border:1px solid #fff;background:#fff}.cash-ticket-scan__content[_ngcontent-%COMP%]{text-align:center;padding-left:40px}.cash-ticket-scan__content--title[_ngcontent-%COMP%]{font-weight:700;padding-bottom:10px}.cash-ticket-scan__content--description[_ngcontent-%COMP%]{font-size:1.5rem}"]
                ],
                me = i.Gb({
                    encapsulation: 0,
                    styles: fe,
                    data: {}
                });

            function _e(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 10, "div", [
                    ["class", "cash-ticket-card"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 1, "div", [
                    ["class", "cash-ticket-card__number"]
                ], null, null, null, null, null)), (n()(), i.cc(2, null, ["", ""])), (n()(), i.Ib(3, 0, null, null, 1, "div", [
                    ["class", "cash-ticket-card__icon"]
                ], null, null, null, null, null)), (n()(), i.Ib(4, 0, null, null, 0, "span", [
                    ["class", "icon icon-results"]
                ], null, null, null, null, null)), (n()(), i.Ib(5, 0, null, null, 2, "div", [
                    ["class", "cash-ticket-card__title"]
                ], null, null, null, null, null)), (n()(), i.cc(6, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(8, 0, null, null, 2, "div", [
                    ["class", "cash-ticket-card__description"]
                ], null, null, null, null, null)), (n()(), i.cc(9, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i])], null, (function(n, t) {
                    n(t, 2, 0, t.component.getCardId(1)), n(t, 6, 0, i.dc(t, 6, 0, i.Ub(t, 7).transform("ch_local_user_entity_title"))), n(t, 9, 0, i.dc(t, 9, 0, i.Ub(t, 10).transform("ch_local_user_entity_desc")))
                }))
            }

            function ve(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 10, "div", [
                    ["class", "cash-ticket-card"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 1, "div", [
                    ["class", "cash-ticket-card__number"]
                ], null, null, null, null, null)), (n()(), i.cc(2, null, ["", ""])), (n()(), i.Ib(3, 0, null, null, 1, "div", [
                    ["class", "cash-ticket-card__icon"]
                ], null, null, null, null, null)), (n()(), i.Ib(4, 0, null, null, 0, "span", [
                    ["class", "icon icon-results"]
                ], null, null, null, null, null)), (n()(), i.Ib(5, 0, null, null, 2, "div", [
                    ["class", "cash-ticket-card__title"]
                ], null, null, null, null, null)), (n()(), i.cc(6, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(8, 0, null, null, 2, "div", [
                    ["class", "cash-ticket-card__description"]
                ], null, null, null, null, null)), (n()(), i.cc(9, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i])], null, (function(n, t) {
                    n(t, 2, 0, t.component.getCardId(4)), n(t, 6, 0, i.dc(t, 6, 0, i.Ub(t, 7).transform("ch_cash_ticket_cashback_title"))), n(t, 9, 0, i.dc(t, 9, 0, i.Ub(t, 10).transform("ch_cash_ticket_cashback_desc")))
                }))
            }

            function ye(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 9, "div", [], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 1, "div", [
                    ["class", "cash-ticket-scan__icon"]
                ], null, null, null, null, null)), (n()(), i.Ib(2, 0, null, null, 0, "span", [
                    ["class", "icon icon-ticket-broken"]
                ], null, null, null, null, null)), (n()(), i.Ib(3, 0, null, null, 6, "div", [
                    ["class", "cash-ticket-scan__content grid grid-column"]
                ], null, null, null, null, null)), (n()(), i.Ib(4, 0, null, null, 2, "div", [
                    ["class", "cash-ticket-scan__content--title"]
                ], null, null, null, null, null)), (n()(), i.cc(5, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(7, 0, null, null, 2, "div", [
                    ["class", "cash-ticket-scan__content--description"]
                ], null, null, null, null, null)), (n()(), i.cc(8, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i])], null, (function(n, t) {
                    n(t, 5, 0, i.dc(t, 5, 0, i.Ub(t, 6).transform("ch_cash_ticket_scan_title"))), n(t, 8, 0, i.dc(t, 8, 0, i.Ub(t, 9).transform("ch_cash_ticket_scan_desc")))
                }))
            }

            function Ce(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 9, "div", [], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 1, "div", [
                    ["class", "cash-ticket-scan__icon"]
                ], null, null, null, null, null)), (n()(), i.Ib(2, 0, null, null, 0, "span", [
                    ["class", "icon icon-paytable"]
                ], null, null, null, null, null)), (n()(), i.Ib(3, 0, null, null, 6, "div", [
                    ["class", "cash-ticket-scan__content grid grid-column"]
                ], null, null, null, null, null)), (n()(), i.Ib(4, 0, null, null, 2, "div", [
                    ["class", "cash-ticket-scan__content--title"]
                ], null, null, null, null, null)), (n()(), i.cc(5, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(7, 0, null, null, 2, "div", [
                    ["class", "cash-ticket-scan__content--description"]
                ], null, null, null, null, null)), (n()(), i.cc(8, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i])], null, (function(n, t) {
                    n(t, 5, 0, i.dc(t, 5, 0, i.Ub(t, 6).transform("ch_local_user_scan_title"))), n(t, 8, 0, i.dc(t, 8, 0, i.Ub(t, 9).transform("ch_local_user_scan_desc")))
                }))
            }

            function ke(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 0, "div", [], null, null, null, null, null))], null, null)
            }

            function xe(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 43, "grc-tab-set", [
                    ["tabSetClass", ""]
                ], [
                    [8, "className", 0]
                ], [
                    [null, "selectedChange"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "selectedChange" === t && (e = !1 !== i.onTabCashManagementChange(l) && e);
                    return e
                }), Ot.b, Ot.a)), i.Hb(1, 4308992, null, 2, Pt.a, [i.i], {
                    sameContent: [0, "sameContent"],
                    hasBorder: [1, "hasBorder"],
                    hiddenTabs: [2, "hiddenTabs"],
                    selected: [3, "selected"],
                    ghost: [4, "ghost"],
                    isCashManagement: [5, "isCashManagement"],
                    tabSetClass: [6, "tabSetClass"]
                }, {
                    selectedChange: "selectedChange"
                }), i.ac(603979776, 1, {
                    tabsContent: 1
                }), i.ac(603979776, 2, {
                    tabsFixedContent: 1
                }), (n()(), i.Ib(4, 0, null, null, 2, "grc-tab", [], null, null, null, Jn.b, Jn.a)), i.Hb(5, 114688, [
                    [1, 4]
                ], 0, Qn.a, [], {
                    header: [0, "header"],
                    id: [1, "id"]
                }, null), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(7, 0, null, null, 36, "grc-tab-fixed", [
                    ["side", "content"]
                ], null, null, null, Mt.b, Mt.a)), i.Hb(8, 114688, [
                    [2, 4]
                ], 0, Tt.a, [], {
                    side: [0, "side"]
                }, null), (n()(), i.Ib(9, 0, null, 0, 32, "div", [
                    ["class", "cash-ticket-container"]
                ], null, null, null, null, null)), (n()(), i.Ib(10, 0, null, null, 26, "div", [
                    ["class", "cash-ticket-cards-container"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, _e)), i.Hb(12, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.Ib(13, 0, null, null, 10, "div", [
                    ["class", "cash-ticket-card"]
                ], null, null, null, null, null)), (n()(), i.Ib(14, 0, null, null, 1, "div", [
                    ["class", "cash-ticket-card__number"]
                ], null, null, null, null, null)), (n()(), i.cc(15, null, ["", ""])), (n()(), i.Ib(16, 0, null, null, 1, "div", [
                    ["class", "cash-ticket-card__icon"]
                ], null, null, null, null, null)), (n()(), i.Ib(17, 0, null, null, 0, "span", [
                    ["class", "icon icon-paytable"]
                ], null, null, null, null, null)), (n()(), i.Ib(18, 0, null, null, 2, "div", [
                    ["class", "cash-ticket-card__title"]
                ], null, null, null, null, null)), (n()(), i.cc(19, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(21, 0, null, null, 2, "div", [
                    ["class", "cash-ticket-card__description"]
                ], null, null, null, null, null)), (n()(), i.cc(22, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(24, 0, null, null, 10, "div", [
                    ["class", "cash-ticket-card"]
                ], null, null, null, null, null)), (n()(), i.Ib(25, 0, null, null, 1, "div", [
                    ["class", "cash-ticket-card__number"]
                ], null, null, null, null, null)), (n()(), i.cc(26, null, ["", ""])), (n()(), i.Ib(27, 0, null, null, 1, "div", [
                    ["class", "cash-ticket-card__icon"]
                ], null, null, null, null, null)), (n()(), i.Ib(28, 0, null, null, 0, "span", [
                    ["class", "icon icon-printer"]
                ], null, null, null, null, null)), (n()(), i.Ib(29, 0, null, null, 2, "div", [
                    ["class", "cash-ticket-card__title"]
                ], null, null, null, null, null)), (n()(), i.cc(30, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(32, 0, null, null, 2, "div", [
                    ["class", "cash-ticket-card__description"]
                ], null, null, null, null, null)), (n()(), i.cc(33, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.xb(16777216, null, null, 1, null, ve)), i.Hb(36, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.Ib(37, 0, null, null, 4, "div", [
                    ["class", "cash-ticket-scan-container"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, ye)), i.Hb(39, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, Ce)), i.Hb(41, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, 0, 1, null, ke)), i.Hb(43, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(n, t) {
                    var l = t.component;
                    n(t, 1, 0, !0, !0, !1, "cash-ticket", !1, !0, "");
                    n(t, 5, 0, i.dc(t, 5, 0, i.Ub(t, 6).transform("ch_cash_ticket")), "cash-ticket");
                    n(t, 8, 0, "content"), n(t, 12, 0, "local-user" === l.cashManagementTabSelected), n(t, 36, 0, "cash-ticket" === l.cashManagementTabSelected), n(t, 39, 0, "cash-ticket" === l.cashManagementTabSelected), n(t, 41, 0, "local-user" === l.cashManagementTabSelected), n(t, 43, 0, "local-user" === l.cashManagementTabSelected)
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 0, 0, i.Ub(t, 1).tabSetClass), n(t, 15, 0, l.getCardId(2)), n(t, 19, 0, i.dc(t, 19, 0, i.Ub(t, 20).transform("ch_cash_ticket_credit_title"))), n(t, 22, 0, i.dc(t, 22, 0, i.Ub(t, 23).transform("ch_cash_ticket_credit_desc"))), n(t, 26, 0, l.getCardId(3)), n(t, 30, 0, i.dc(t, 30, 0, i.Ub(t, 31).transform("ch_cash_ticket_ticket_title"))), n(t, 33, 0, i.dc(t, 33, 0, i.Ub(t, 34).transform("ch_cash_ticket_ticket_desc")))
                }))
            }
            var Ie = i.Eb("grc-cash-management", Pl.a, (function(n) {
                    return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-cash-management", [], null, null, null, xe, me)), i.Hb(1, 114688, null, 0, Pl.a, [Un.a, i.y], null, null)], (function(n, t) {
                        n(t, 1, 0)
                    }), null)
                }), {}, {}, []),
                Se = l("PdBy"),
                we = [
                    [""]
                ],
                Oe = i.Gb({
                    encapsulation: 0,
                    styles: we,
                    data: {}
                });

            function Pe(n) {
                return i.ec(0, [i.Tb(null, 0), (n()(), i.xb(0, null, null, 0))], null, null)
            }

            function Me(n) {
                return i.ec(2, [i.ac(402653184, 1, {
                    content: 0
                }), (n()(), i.xb(0, [
                    [1, 2]
                ], null, 0, null, Pe))], null, null)
            }
            i.Eb("grc-option", Se.a, (function(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-option", [], null, null, null, Me, Oe)), i.Hb(1, 114688, null, 0, Se.a, [], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                value: "value"
            }, {}, ["*"]);
            var Te = l("imdu"),
                je = [
                    ["[_nghost-%COMP%]{position:relative;display:block;width:87px;height:46px}input[type=checkbox][_ngcontent-%COMP%]{display:none}.toggle-button-switch[_ngcontent-%COMP%]{position:absolute;top:3px;left:3px;z-index:100;width:40px;height:40px;cursor:pointer;background-color:#fff;border-radius:100%;transition:left .3s}.toggle-button-text[_ngcontent-%COMP%]{display:flex;width:100%;height:100%;overflow:hidden;font-size:16px;font-weight:700;background-color:#9b9b9b;border-radius:23px;transition:background-color .3s}.toggle-button-text-off[_ngcontent-%COMP%], .toggle-button-text-on[_ngcontent-%COMP%]{display:flex;justify-content:space-around;align-items:center;width:100%;height:100%;font-weight:700;color:#fff;text-align:center}input[type=checkbox][_ngcontent-%COMP%]:checked ~ .toggle-button-switch[_ngcontent-%COMP%]{left:43px}input[type=checkbox][_ngcontent-%COMP%]:checked ~ .toggle-button-text[_ngcontent-%COMP%]{background-color:#618b31}"]
                ],
                Ee = i.Gb({
                    encapsulation: 0,
                    styles: je,
                    data: {}
                });

            function Ue(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 0, "input", [
                    ["id", "toggle-button-checkbox"],
                    ["type", "checkbox"]
                ], [
                    [8, "checked", 0]
                ], [
                    [null, "change"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "change" === t && (e = !1 !== i.changed.emit(l.target.checked) && e);
                    return e
                }), null, null)), (n()(), i.Ib(1, 0, null, null, 0, "label", [
                    ["class", "toggle-button-switch"],
                    ["for", "toggle-button-checkbox"]
                ], null, null, null, null, null)), (n()(), i.Ib(2, 0, null, null, 4, "div", [
                    ["class", "toggle-button-text"]
                ], null, null, null, null, null)), (n()(), i.Ib(3, 0, null, null, 1, "div", [
                    ["class", "toggle-button-text-on"]
                ], null, null, null, null, null)), (n()(), i.cc(-1, null, ["ON"])), (n()(), i.Ib(5, 0, null, null, 1, "div", [
                    ["class", "toggle-button-text-off"]
                ], null, null, null, null, null)), (n()(), i.cc(-1, null, ["OFF"]))], null, (function(n, t) {
                    n(t, 0, 0, t.component.isActive)
                }))
            }
            i.Eb("gr-toggle-button", Te.a, (function(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "gr-toggle-button", [], null, null, null, Ue, Ee)), i.Hb(1, 114688, null, 0, Te.a, [], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                isActive: "isActive"
            }, {
                changed: "changed"
            }, []);
            var Ae = l("Y53V"),
                Be = l("5tmv"),
                He = [
                    ["[_nghost-%COMP%]{display:flex;cursor:pointer}.select-option[_ngcontent-%COMP%]{font-size:20px;line-height:22px}.select-option--selected[_ngcontent-%COMP%]{font-weight:400;color:#1194f6}"]
                ],
                De = i.Gb({
                    encapsulation: 0,
                    styles: He,
                    data: {}
                });

            function Le(n) {
                return i.ec(0, [(n()(), i.xb(0, null, null, 0))], null, null)
            }

            function Ne(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 2, "span", [
                    ["class", "select-option text-left"]
                ], [
                    [2, "select-option--selected", null]
                ], null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, Le)), i.Hb(2, 606208, null, 0, Ae.a, [i.eb], {
                    grcOptionHost: [0, "grcOptionHost"]
                }, null)], (function(n, t) {
                    n(t, 2, 0, t.component.content)
                }), (function(n, t) {
                    n(t, 0, 0, t.component.isActive)
                }))
            }
            i.Eb("grc-select-option", Be.a, (function(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-select-option", [], null, null, null, Ne, De)), i.Hb(1, 114688, null, 0, Be.a, [], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                content: "content",
                isActive: "isActive"
            }, {}, []);
            var ze = l("yoGk"),
                Re = [
                    ["[_nghost-%COMP%]{position:relative;width:100%}.select[_ngcontent-%COMP%]{position:relative;padding:10px;color:#000;cursor:pointer;background-color:#eee;border-radius:2px}.select__value[_ngcontent-%COMP%]{font-size:20px;font-weight:400}.select__icon[_ngcontent-%COMP%]{padding:5px 0 5px 10px;font-size:12px;font-weight:700}.select__icon[_ngcontent-%COMP%]   .icon[_ngcontent-%COMP%]{display:inline-block;transition:transform .2s}.select--opened[_ngcontent-%COMP%]   .select__icon[_ngcontent-%COMP%]   .icon[_ngcontent-%COMP%]{transform:rotateX(180deg)}.options-container[_ngcontent-%COMP%]{position:absolute;top:124px;left:-186%;z-index:1000;display:flex;width:1000px;flex-wrap:wrap;padding:40px 0 0;font-size:20px;background-color:#fff;border-top-left-radius:2px;border-top-right-radius:2px;box-shadow:0 0 2px 0 rgba(0,0,0,.14),0 2px 2px 0 rgba(0,0,0,.12),0 1px 3px 0 rgba(0,0,0,.2);transform:translateY(-100%)}.options-container--item-bottom-separation[_ngcontent-%COMP%]{height:41px;margin-bottom:23px}"]
                ],
                We = i.Gb({
                    encapsulation: 0,
                    styles: Re,
                    data: {}
                });

            function Fe(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-select-option", [
                    ["class", "options-container--item-bottom-separation"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.select(n.context.$implicit.value) && e);
                    return e
                }), Ne, De)), i.Hb(1, 114688, null, 0, Be.a, [], {
                    content: [0, "content"],
                    isActive: [1, "isActive"]
                }, null)], (function(n, t) {
                    n(t, 1, 0, t.context.$implicit.content, t.context.$implicit.isSelected)
                }), null)
            }

            function Ge(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 2, "div", [
                    ["class", "grid grid-column"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, Fe)), i.Hb(2, 278528, null, 0, Y.l, [i.eb, i.Z, i.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(n, t) {
                    n(t, 2, 0, t.parent.context.$implicit)
                }), null)
            }

            function Ze(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 2, null, null, null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, Ge)), i.Hb(2, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(0, null, null, 0))], (function(n, t) {
                    n(t, 2, 0, t.context.$implicit.length > 0)
                }), null)
            }

            function Ve(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 5, "div", [
                    ["class", "grid grid-space-around options-container"]
                ], null, null, null, null, null)), i.Zb(512, null, Y.x, Y.y, [i.A, i.B, i.o, i.P]), i.Hb(2, 278528, null, 0, Y.k, [Y.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), i.Xb(3, {
                    "grid-2": 0,
                    "grid-3": 1,
                    "grid-4": 2
                }), (n()(), i.xb(16777216, null, null, 1, null, Ze)), i.Hb(5, 278528, null, 0, Y.l, [i.eb, i.Z, i.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(n, t) {
                    var l = t.component,
                        e = n(t, 3, 0, 2 === l.options.length, 3 === l.options.length, l.options.length >= 4);
                    n(t, 2, 0, "grid grid-space-around options-container", e), n(t, 5, 0, l.orderedGroupsOptions)
                }), null)
            }

            function Ke(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 2, "div", [], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 1, "grc-select-option", [], null, null, null, Ne, De)), i.Hb(2, 114688, null, 0, Be.a, [], {
                    content: [0, "content"]
                }, null)], (function(n, t) {
                    n(t, 2, 0, t.component.options.first.content)
                }), null)
            }

            function Ye(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, null, null, null, null, null, null, null)), (n()(), i.cc(1, null, ["", ""]))], null, (function(n, t) {
                    n(t, 1, 0, t.component.optionValue)
                }))
            }

            function qe(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "div", [
                    ["class", "select__icon"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 0, "span", [
                    ["class", "icon icon-down"]
                ], null, null, null, null, null))], null, null)
            }

            function Xe(n) {
                return i.ec(2, [(n()(), i.xb(16777216, null, null, 1, null, Ve)), i.Hb(1, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.Ib(2, 0, null, null, 8, "div", [
                    ["class", "grid grid-center"]
                ], null, null, null, null, null)), (n()(), i.Ib(3, 0, null, null, 7, "div", [
                    ["class", "grid grid-middle select"]
                ], [
                    [2, "select--opened", null]
                ], [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.toggle() && e);
                    return e
                }), null, null)), (n()(), i.Ib(4, 0, null, null, 4, "div", [
                    ["class", "col select__value"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, Ke)), i.Hb(6, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, Ye)), i.Hb(8, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, qe)), i.Hb(10, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(n, t) {
                    var l = t.component;
                    n(t, 1, 0, l.isOpened && l.options.length > 1), n(t, 6, 0, 1 === l.options.length), n(t, 8, 0, l.optionSelected), n(t, 10, 0, l.options.length > 1)
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 3, 0, l.isOpened && l.options.length > 1)
                }))
            }
            i.Eb("grc-select", ze.a, (function(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 2, "grc-select", [], [
                    [2, "select--opened", null]
                ], null, null, Xe, We)), i.Hb(1, 1163264, null, 1, ze.a, [], null, null), i.ac(603979776, 1, {
                    options: 1
                })], (function(n, t) {
                    n(t, 1, 0)
                }), (function(n, t) {
                    n(t, 0, 0, i.Ub(t, 1).isOpened)
                }))
            }), {
                optionsArray: "optionsArray",
                languageSelected: "languageSelected",
                orientation: "orientation"
            }, {
                openedChange: "openedChange",
                change: "change"
            }, []);
            var Je = l("mYlp"),
                Qe = l("k1pK"),
                $e = l("hIlf"),
                ni = function(n, t, l, e) {
                    return new(l || (l = Promise))((function(i, o) {
                        function r(n) {
                            try {
                                s(e.next(n))
                            } catch (t) {
                                o(t)
                            }
                        }

                        function u(n) {
                            try {
                                s(e.throw(n))
                            } catch (t) {
                                o(t)
                            }
                        }

                        function s(n) {
                            var t;
                            n.done ? i(n.value) : (t = n.value, t instanceof l ? t : new l((function(n) {
                                n(t)
                            }))).then(r, u)
                        }
                        s((e = e.apply(n, t || [])).next())
                    }))
                },
                ti = function(n, t) {
                    var l, e, i, o, r = {
                        label: 0,
                        sent: function() {
                            if (1 & i[0]) throw i[1];
                            return i[1]
                        },
                        trys: [],
                        ops: []
                    };
                    return o = {
                        next: u(0),
                        throw: u(1),
                        return: u(2)
                    }, "function" == typeof Symbol && (o[Symbol.iterator] = function() {
                        return this
                    }), o;

                    function u(o) {
                        return function(u) {
                            return function(o) {
                                if (l) throw new TypeError("Generator is already executing.");
                                for (; r;) try {
                                    if (l = 1, e && (i = 2 & o[0] ? e.return : o[0] ? e.throw || ((i = e.return) && i.call(e), 0) : e.next) && !(i = i.call(e, o[1])).done) return i;
                                    switch (e = 0, i && (o = [2 & o[0], i.value]), o[0]) {
                                        case 0:
                                        case 1:
                                            i = o;
                                            break;
                                        case 4:
                                            return r.label++, {
                                                value: o[1],
                                                done: !1
                                            };
                                        case 5:
                                            r.label++, e = o[1], o = [0];
                                            continue;
                                        case 7:
                                            o = r.ops.pop(), r.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = r.trys, (i = i.length > 0 && i[i.length - 1]) || 6 !== o[0] && 2 !== o[0])) {
                                                r = 0;
                                                continue
                                            }
                                            if (3 === o[0] && (!i || o[1] > i[0] && o[1] < i[3])) {
                                                r.label = o[1];
                                                break
                                            }
                                            if (6 === o[0] && r.label < i[1]) {
                                                r.label = i[1], i = o;
                                                break
                                            }
                                            if (i && r.label < i[2]) {
                                                r.label = i[2], r.ops.push(o);
                                                break
                                            }
                                            i[2] && r.ops.pop(), r.trys.pop();
                                            continue
                                    }
                                    o = t.call(n, r)
                                } catch (u) {
                                    o = [6, u], e = 0
                                } finally {
                                    l = i = 0
                                }
                                if (5 & o[0]) throw o[1];
                                return {
                                    value: o[0] ? o[1] : void 0,
                                    done: !0
                                }
                            }([o, u])
                        }
                    }
                },
                li = function() {
                    function n(n, t, l, e, i, o, r, u, s) {
                        this.cd = n, this.router = t, this.route = l, this.coreService = e, this.i18nService = i, this.externalConfigService = o, this.waitingScreenService = r, this.themeService = u, this.notificationsService = s, this.langBackofficeKey = "Backoffice", this.loginCredentials = {
                            hwId: null,
                            domain: "",
                            user: "",
                            password: "",
                            barcode: "",
                            pinHash: ""
                        }, this.passwordFormModified = !1, this.languageSelected = "", this.autoFullscreen = !0, this.allowRemember = !0, this.rememberme = !1, this.isHwIdFixed = !1, this.accountStatus = "Loading...", this.isLocked = !1, this.isActive = !1, this.isDisabled = !0, this.isCredentialFound = !0, this.isHwIdFound = !0, this.isPasswordVisible = !1, this.passwordVisibilityIcon = !1, this.showHidePassword = !1, this.showKeyboard = !1, this.showOptions = !1, this.selectLanguageIsOpened = !1, this.logging = !1, this.selectOrientation = ze.b, this.loginTabs = "manual", this.onlyNumbers = !1, this.activeVirtualKeyboard = !1, this.subscriptions = new un.a, this.originalShouldReuseRoute = this.router.routeReuseStrategy.shouldReuseRoute, this.router.routeReuseStrategy.shouldReuseRoute = function() {
                            return !1
                        }
                    }
                    return n.prototype.ngOnInit = function() {
                        this.externalConfigService.updateEnvironmentConfig(this.route.snapshot.queryParams), this.configParams = this.externalConfigService.getEnvironmentConfig().configParams;
                        var n = this.externalConfigService.getEnvironmentConfig().configParams.allowRemember;
                        this.allowRemember = !!("boolean" == typeof n && n || "string" == typeof n && "true" === n || "1" === n);
                        var t = this.configParams.showHidePassword;
                        if (this.showHidePassword = !!("boolean" == typeof t && t || "string" == typeof t && "true" === t), this.setupLanguagesList(), this.coreService.sessionExpired) {
                            var l = "" + this.i18nService.get("ch_session_expired");
                            this.notificationsService.danger(l)
                        }
                        this.initialLoad(), this.loginCredentials.barcode = "", this.loginCredentials.pinHash = ""
                    }, n.prototype.ngOnDestroy = function() {
                        this.router.routeReuseStrategy.shouldReuseRoute = this.originalShouldReuseRoute, this.subscriptions.unsubscribe()
                    }, n.prototype.onPasswordChange = function() {
                        this.passwordFormModified = !0
                    }, n.prototype.initialLoad = function() {
                        return ni(this, void 0, void 0, (function() {
                            var n;
                            return ti(this, (function(t) {
                                switch (t.label) {
                                    case 0:
                                        return this.isHwIdFixed = this.configParams.hwId && "" !== this.configParams.hwId, [4, this.loadFromStorage()];
                                    case 1:
                                        return t.sent(), n = 0, this.loginCredentials.hwId = this.configParams.hwId && "" !== this.configParams.hwId && ++n ? this.configParams.hwId : this.loginCredentials.hwId, this.loginCredentials.domain = this.configParams.domain && "" !== this.configParams.domain && ++n ? this.configParams.domain : this.loginCredentials.domain, this.loginCredentials.user = this.rememberme && this.configParams.user && "" !== this.configParams.user && ++n ? this.configParams.user : this.loginCredentials.user, this.loginCredentials.password = this.rememberme && this.configParams.password && "" !== this.configParams.password && ++n ? this.configParams.password : this.loginCredentials.password, this.passwordHash = this.rememberme && this.loginCredentials.password && "" !== this.loginCredentials.password ? this.loginCredentials.password : this.configParams.password, n ? [4, this.saveToLocalStorage()] : [3, 3];
                                    case 2:
                                        t.sent(), t.label = 3;
                                    case 3:
                                        return this.updateAccount(), this.setButtonState(), this.passwordVisibilityIcon = !this.loginCredentials.password, [2]
                                }
                            }))
                        }))
                    }, n.prototype.loadFromStorage = function() {
                        return ni(this, void 0, void 0, (function() {
                            return ti(this, (function(n) {
                                return this.getCredentialsFromStorage(), this.languageSelected = this.loadParam("lastLanguageSelected", this.languageSelected), this.autoFullscreen = this.loadBoolParam("autoFullscreen", this.autoFullscreen), this.accountDetails = this.loadJSONParam("accountDetails", this.accountDetails), [2]
                            }))
                        }))
                    }, n.prototype.loadJSONParam = function(n, t) {
                        var l = this.loadParam(n, "");
                        return null === l || "" === l ? t : JSON.parse(l)
                    }, n.prototype.loadBoolParam = function(n, t) {
                        return "1" === this.loadParam(n, t ? "1" : "0")
                    }, n.prototype.loadParam = function(n, t) {
                        var l = localStorage.getItem(n);
                        return null == l || "" === l || void 0 === l ? t : l
                    }, n.prototype.saveToLocalStorage = function() {
                        return ni(this, void 0, void 0, (function() {
                            return ti(this, (function(n) {
                                return this.saveParam("autoFullscreen", this.autoFullscreen ? "1" : "0"), this.saveParam("lastLanguageSelected", this.languageSelected), this.saveParam("accountDetails", JSON.stringify(this.accountDetails)), [2]
                            }))
                        }))
                    }, n.prototype.saveParam = function(n, t) {
                        null != t && "undefined" !== t || (t = ""), localStorage.setItem(n, t)
                    }, n.prototype.saveCredentials = function() {
                        return ni(this, void 0, void 0, (function() {
                            var n;
                            return ti(this, (function(t) {
                                switch (t.label) {
                                    case 0:
                                        return t.trys.push([0, 3, , 4]), this.loginCredentials && this.rememberme && this.allowRemember || (this.loginCredentials.user = "", this.loginCredentials.password = "", this.passwordHash = ""), n = this.encodeLoginCredentials(), localStorage.setItem("loginCredentials", JSON.stringify(n)), [4, this.coreService.getRetailCoreSessionController(this.coreService.getEnvironmentConfigController())];
                                    case 1:
                                        return [4, t.sent().getSessionService().setLocalStorage({
                                            version: 1,
                                            data: {
                                                credentials: JSON.stringify(n)
                                            },
                                            contextName: "loginCredentials"
                                        })];
                                    case 2:
                                        return t.sent(), [3, 4];
                                    case 3:
                                        return t.sent(), [3, 4];
                                    case 4:
                                        return [2]
                                }
                            }))
                        }))
                    }, n.prototype.setButtonState = function() {
                        "manual" === this.loginTabs ? this.loginCredentials.domain && this.loginCredentials.user && this.loginCredentials.password ? this.isDisabled = !1 : this.isDisabled = !0 : this.loginCredentials.barcode && this.loginCredentials.pinHash && 4 === this.loginCredentials.pinHash.length ? this.isDisabled = !1 : this.isDisabled = !0, this.cd.detectChanges()
                    }, n.prototype.getFocus = function() {
                        var n = this;
                        "manual" === this.loginTabs ? setTimeout((function() {
                            return n.hwIdInput.nativeElement.focus()
                        }), 200) : setTimeout((function() {
                            return n.barcodeInput.nativeElement.focus()
                        }), 200)
                    }, n.prototype.resetAccount = function() {
                        this.loginCredentials.hwId = "", this.updateAccount()
                    }, n.prototype.updateAccount = function() {
                        var n = this;
                        if (this.accountDetails && this.loginCredentials.hwId === this.accountDetails.hwId) return this.calcAccountStatus(), void this.cd.detectChanges();
                        if (this.accountDetails = null, this.loginCredentials.hwId && "" !== this.loginCredentials.hwId && null !== this.loginCredentials.hwId) {
                            this.accountStatus = "... Identifying account ...";
                            var t = this.externalConfigService.getEnvironmentConfig();
                            t.configParams.onlineHash = null, t.configParams.domain = null, t.configParams.user = null, t.configParams.password = null, this.coreService.findByHwId(t, this.processNullEncodeURIComponent(this.loginCredentials.hwId)).then((function(t) {
                                n.isHwIdFound = !0, n.accountDetails = {
                                    id: t.id,
                                    name: t.name,
                                    extId: t.extId,
                                    hwId: n.loginCredentials.hwId
                                }, n.calcAccountStatus(), n.saveToLocalStorage(), n.cd.detectChanges()
                            })).catch((function(t) {
                                n.isHwIdFound = !1, n.accountStatus = "Invalid account for [ " + n.loginCredentials.hwId + " ]", n.cd.detectChanges()
                            }))
                        } else this.isHwIdFound = !0, this.calcAccountStatus(), this.cd.detectChanges()
                    }, n.prototype.calcAccountStatus = function() {
                        this.accountDetails ? this.accountStatus = this.accountDetails.id + " | " + this.accountDetails.name + (this.accountDetails.extId ? " | " + this.accountDetails.extId : "") : this.accountStatus = "ch_SingleUserAccount"
                    }, n.prototype.onEnter = function() {
                        this.showOptions ? this.updateAccount() : this.isDisabled || this.logging || this.onSuccess()
                    }, n.prototype.onSuccess = function() {
                        this.error = "", this.cd.detectChanges(), this.login()
                    }, n.prototype.setupLanguagesList = function() {
                        this.languages = H.SupportedLanguagesInfo.getLanguageList();
                        var n = localStorage.getItem("lastLanguageSelected");
                        this.languageSelected = n || "", this.languages.unshift({
                            key: "[Backoffice]",
                            value: H.SupportedLanguages.NONE,
                            description: ""
                        })
                    }, n.prototype.onSelectLanguageChange = function(n) {
                        this.languageSelected = n
                    }, n.prototype.selectLanguageOnOpenedChange = function(n) {
                        this.selectLanguageIsOpened = n
                    }, n.prototype.onSwitchChanged = function(n) {
                        this.activeVirtualKeyboard = n, this.isActive = n
                    }, n.prototype.showVirtualKeyboard = function(n, t) {
                        void 0 === t && (t = !1), this.elementId = n, this.onlyNumbers = t, this.data = this.loginCredentials[this.elementId], this.showKeyboard = this.activeVirtualKeyboard
                    }, n.prototype.onInsertText = function(n) {
                        this.passwordFormModified = !0, this.activeVirtualKeyboard = !1, this.loginCredentials[this.elementId] = n, this.showVirtualKeyboard(), this.setButtonState(), this.activeVirtualKeyboard = this.isActive, this.passwordVisibilityIcon = !n, this.updateAccount(), this.cd.detectChanges()
                    }, n.prototype.togglePasswordVisibility = function() {
                        this.isPasswordVisible = !this.isPasswordVisible, this.cd.detectChanges()
                    }, n.prototype.onFocusPassword = function() {
                        var n = this.getSavedPassword();
                        (this.loginCredentials.password || this.error) && this.loginCredentials.password === n && (this.loginCredentials.password = ""), this.passwordVisibilityIcon = !0, this.setButtonState(), this.cd.detectChanges()
                    }, n.prototype.onFocusOutPassword = function() {
                        var n = this.getSavedPassword();
                        !this.loginCredentials.password && n && this.rememberme ? (this.passwordVisibilityIcon = !1, this.isPasswordVisible = !1, this.loginCredentials.password = n) : this.passwordVisibilityIcon = !0, this.setButtonState(), this.cd.detectChanges()
                    }, n.prototype.validatePinhash = function(n) {
                        (isNaN(n.data) || n.target.value.length > 4) && (n.target.value = n.target.value.slice(0, -1))
                    }, n.prototype.removeInput = function(n) {
                        this.loginCredentials[n] = "", this.setButtonState()
                    }, n.prototype.getSavedPassword = function() {
                        return JSON.parse(this.loadParam("loginCredentials", "")).password
                    }, n.prototype.login = function() {
                        var n = this;
                        "manual" === this.loginTabs ? (this.configParams.domain = this.loginCredentials.domain.trim(), this.configParams.user = this.loginCredentials.user.trim(), this.configParams.hwId = this.loginCredentials.hwId ? this.loginCredentials.hwId.trim() : null, this.configParams.domain = this.processNullEncodeURIComponent(this.configParams.domain), this.configParams.user = this.processNullEncodeURIComponent(this.configParams.user), this.configParams.hwId = this.processNullEncodeURIComponent(this.configParams.hwId), this.configParams.barcode = null, this.configParams.pin = null, !this.passwordFormModified || "" !== this.passwordHash && null !== this.passwordHash && this.passwordHash === this.loginCredentials.password ? this.configParams.password = this.loginCredentials.password : (this.configParams.password = rn.n.CryptoUtils.createMD5Hash(this.loginCredentials.password), this.loginCredentials.password = rn.n.CryptoUtils.createMD5Hash(this.loginCredentials.password)), this.isPasswordVisible = !1) : (this.configParams.barcode = this.loginCredentials.barcode.trim(), this.configParams.pin = rn.n.CryptoUtils.createMD5Hash(this.loginCredentials.pinHash)), this.saveToLocalStorage(), this.waitingScreenService.show({
                            input: {
                                message: "ch_logging",
                                isProcessing: !0
                            }
                        }), this.logging = !0, this.subscriptions.add(this.coreService.init(this.externalConfigService.getEnvironmentConfig()).pipe(Object(a.a)((function() {
                            var t, l = null === (t = n.coreService.getSessionController().sessionSettings.localizationContext.skin) || void 0 === t ? void 0 : t.toLowerCase();
                            return n.themeService.load({
                                name: l
                            })
                        })), Object(a.a)((function() {
                            var t, l = null === (t = n.coreService.getSessionController().sessionSettings.localizationContext.skin) || void 0 === t ? void 0 : t.toLowerCase(),
                                e = n.coreService.retailController.getCashierCoreI18NConfig();
                            return "default" !== l && n.coreService.setI18nLoader(e, l), n.coreService.initLocalization()
                        })), Object(a.a)((function() {
                            var t;
                            return "default" !== (null === (t = n.coreService.getSessionController().sessionSettings.localizationContext.skin) || void 0 === t ? void 0 : t.toLowerCase()) && "en_GB" === n.i18nService.getCurrentLanguage() ? n.i18nService.reloadLanguage(n.i18nService.getCurrentLanguage()) : Object(c.a)(null)
                        }))).subscribe((function() {
                            n.logging = !1, n.isCredentialFound = !0, n.waitingScreenService.hide(), n.saveCredentials();
                            var t = location.href.match(/(?:(?!\?)|\&)redirectTo\=([^&]*)(?=&|$)/);
                            t ? n.router.navigateByUrl(decodeURIComponent(t[1]) + "?" + location.href.split("?")[1].replace(new RegExp(t[0], "g"), "")) : n.goToFirstPlaylist()
                        }), (function(t) {
                            if (n.logging = !1, n.isCredentialFound = !1, n.waitingScreenService.hide(), t && t.message) {
                                console.error(t);
                                var l = n.notificationsService.processMessage(t.message.toLowerCase());
                                n.error = "" + n.i18nService.get("ch_" + l.message, {
                                    value: l.value,
                                    combiGroup: t.param && t.param.combiGroup
                                }), n.notificationsService.danger(n.error)
                            }
                            n.loadFromStorage(), n.updateAccount(), n.passwordVisibilityIcon = !1, n.loginCredentials.pinHash = "", n.cd.detectChanges()
                        })))
                    }, n.prototype.encodeLoginCredentials = function() {
                        var n = this.loginCredentials;
                        return this.loginCredentials.hwId && (n.hwId = window.btoa(this.loginCredentials.hwId)), n.domain = window.btoa(this.loginCredentials.domain), n.user = window.btoa(this.loginCredentials.user), n
                    }, n.prototype.decodeLoginCredentials = function() {
                        this.loginCredentials.hwId && (this.loginCredentials.hwId = window.atob(this.loginCredentials.hwId)), this.loginCredentials.domain = window.atob(this.loginCredentials.domain), this.loginCredentials.user = window.atob(this.loginCredentials.user)
                    }, n.prototype.getCredentialsFromStorage = function() {
                        return ni(this, void 0, void 0, (function() {
                            var n, t, l, e, i, o;
                            return ti(this, (function(r) {
                                switch (r.label) {
                                    case 0:
                                        return r.trys.push([0, 5, , 6]), n = this.getplatformsLocalServerUrl(), !localStorage.getItem("loginCredentials") || n ? [3, 1] : (this.loginCredentials = JSON.parse(this.loadParam("loginCredentials", "")), [3, 4]);
                                    case 1:
                                        return [4, this.coreService.getRetailCoreSessionController(this.coreService.getEnvironmentConfigController())];
                                    case 2:
                                        return t = r.sent().getSessionService(), l = this, i = (e = JSON).parse, [4, t.getLocalStorage("loginCredentials")];
                                    case 3:
                                        l.loginCredentials = i.apply(e, [r.sent().data.credentials]), r.label = 4;
                                    case 4:
                                        return this.setButtonState(), this.rememberme = !this.isDisabled, this.decodeLoginCredentials(), this.cd.detectChanges(), [3, 6];
                                    case 5:
                                        return o = r.sent(), console.error(o), [3, 6];
                                    case 6:
                                        return [2]
                                }
                            }))
                        }))
                    }, n.prototype.getplatformsLocalServerUrl = function() {
                        return this.configParams.platformsLocalServerUrl ? this.configParams.platformsLocalServerUrl : void 0
                    }, n.prototype.goToFirstPlaylist = function() {
                        var n, t = this.coreService.getInitialDisplayId(this.externalConfigService),
                            l = null;
                        if (t) {
                            var e = this.coreService.getAllEventControllers().find((function(n) {
                                return n.content._clDataParent && n.content._clDataParent.displayIds.includes(t)
                            }));
                            e && e.content ? l = e.content : console.log("Error, URL param displayId not found: " + t)
                        }
                        if (l || (l = null === (n = this.coreService.getAllEventControllers()[0]) || void 0 === n ? void 0 : n.content), !l) return this.router.navigate(["/cash", "cashManagement"], {
                            queryParamsHandling: "merge",
                            replaceUrl: !0
                        });
                        var i = void 0,
                            o = "";
                        l.isPlaylistContent() && (i = l, o = Object(O.a)(l._clData.playlist)), this.router.navigate(["cashier", o, i.playlistId], {
                            queryParamsHandling: "merge",
                            replaceUrl: !0
                        })
                    }, n.prototype.processNullEncodeURIComponent = function(n) {
                        return n && "null" !== n ? encodeURIComponent(n) : null
                    }, n
                }(),
                ei = ["body[_ngcontent-%COMP%] {\n        margin: 0;\n    }\n\n    .login-container[_ngcontent-%COMP%] {\n        width: 100%;\n        height: 100%;\n        background-image: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB3aWR0aD0iMTkyMCIgaGVpZ2h0PSIxMDQzIj48ZGVmcz48cGF0aCBpZD0iQSIgZD0iTTAgMGgxOTIwdjEwODBIMHoiLz48cmFkaWFsR3JhZGllbnQgY3g9IjM3LjMyMDQ3MDQlIiBjeT0iMi40ODMzNzA4OCUiIGZ4PSIzNy4zMjA0NzA0JSIgZnk9IjIuNDgzMzcwODglIiByPSI3NC44MDc5NzM0JSIgZ3JhZGllbnRUcmFuc2Zvcm09InRyYW5zbGF0ZSgwLjM3MzIwNSwwLjAyNDgzNCksc2NhbGUoMC4yMzcxOTIsMS4wMDAwMDApLHNjYWxlKDEuMDAwMDAwLDAuNjg4NjY5KSx0cmFuc2xhdGUoLTAuMzczMjA1LC0wLjAyNDgzNCkiIGlkPSJCIj48c3RvcCBzdG9wLWNvbG9yPSIjZmZmIiBvZmZzZXQ9IjAlIi8+PHN0b3Agc3RvcC1jb2xvcj0iI2ZmZiIgc3RvcC1vcGFjaXR5PSIwIiBvZmZzZXQ9IjEwMCUiLz48L3JhZGlhbEdyYWRpZW50PjxyYWRpYWxHcmFkaWVudCBjeD0iODYuOTcwNDc0MyUiIGN5PSIyLjIxMDUwMzklIiBmeD0iODYuOTcwNDc0MyUiIGZ5PSIyLjIxMDUwMzklIiByPSI5NS42MDc0MzgxJSIgZ3JhZGllbnRUcmFuc2Zvcm09InRyYW5zbGF0ZSgwLjg2OTcwNSwwLjAyMjEwNSksc2NhbGUoMC4yNjA3NjksMS4wMDAwMDApLHJvdGF0ZSgxODAuMDAwMDAwKSxzY2FsZSgxLjAwMDAwMCwwLjY4ODY2OSksdHJhbnNsYXRlKC0wLjg2OTcwNSwtMC4wMjIxMDUpIiBpZD0iQyI+PHN0b3Agc3RvcC1jb2xvcj0iI2ZmZiIgb2Zmc2V0PSIwJSIvPjxzdG9wIHN0b3AtY29sb3I9IiNmZmYiIHN0b3Atb3BhY2l0eT0iMCIgb2Zmc2V0PSIxMDAlIi8+PC9yYWRpYWxHcmFkaWVudD48cmFkaWFsR3JhZGllbnQgY3g9Ijc3LjU0NTg0MjglIiBjeT0iOTIuMzgwOTMxMiUiIGZ4PSI3Ny41NDU4NDI4JSIgZnk9IjkyLjM4MDkzMTIlIiByPSI5Mi44ODgzMjYzJSIgZ3JhZGllbnRUcmFuc2Zvcm09InRyYW5zbGF0ZSgwLjc3NTQ1OCwwLjkyMzgwOSksc2NhbGUoMC4yNjA3NjksMS4wMDAwMDApLHJvdGF0ZSgtMTc3LjQ1NDkyOSksc2NhbGUoMS4wMDAwMDAsMC42ODg2NjkpLHRyYW5zbGF0ZSgtMC43NzU0NTgsLTAuOTIzODA5KSIgaWQ9IkQiPjxzdG9wIHN0b3AtY29sb3I9IiNmZmYiIG9mZnNldD0iMCUiLz48c3RvcCBzdG9wLWNvbG9yPSIjZmZmIiBzdG9wLW9wYWNpdHk9IjAiIG9mZnNldD0iMTAwJSIvPjwvcmFkaWFsR3JhZGllbnQ+PGxpbmVhckdyYWRpZW50IHgxPSIxNS4zOTY1MjkyJSIgeTE9IjE1LjI3Mjc5MzclIiB4Mj0iNTAlIiB5Mj0iOTguNjIwMzkzOCUiIGlkPSJFIj48c3RvcCBzdG9wLWNvbG9yPSIjZmZmIiBzdG9wLW9wYWNpdHk9IjAiIG9mZnNldD0iLjA4MTI4NjEyNzIlIi8+PHN0b3Agc3RvcC1jb2xvcj0iI2ZmZiIgb2Zmc2V0PSIxMDAlIi8+PC9saW5lYXJHcmFkaWVudD48L2RlZnM+PGcgZmlsbC1ydWxlPSJldmVub2RkIj48bWFzayBpZD0iRiIgZmlsbD0iI2ZmZiI+PHVzZSB4bGluazpocmVmPSIjQSIvPjwvbWFzaz48ZyBmaWxsLXJ1bGU9Im5vbnplcm8iPjxwYXRoIG1hc2s9InVybCgjRikiIHRyYW5zZm9ybT0ibWF0cml4KC45NDU1MTkgLS4zMjU1NjggLjMyNTU2OCAuOTQ1NTE5IC0xNzEuNDQ5ODAzIDMzOC41MDQ3MTkpIiBkPSJNLTMxMy44MTMgMzg3LjUyNGgyNDc5djU4OGgtMjQ3OXoiIGZpbGw9InVybCgjQikiIG9wYWNpdHk9Ii4wNDYiLz48cGF0aCBtYXNrPSJ1cmwoI0YpIiB0cmFuc2Zvcm09Im1hdHJpeCguOTIwNTA1IC4zOTA3MzEgLS4zOTA3MzEgLjkyMDUwNSAzMDIuNjc1NDc2IC0zNTIuMjQxNjgyKSIgZD0iTS0xMTAuNDMzIDI3My43MjhoMjI1NC44NjV2NTg4SC0xMTAuNDMzeiIgZmlsbD0idXJsKCNDKSIgb3BhY2l0eT0iLjA1Ii8+PHBhdGggbWFzaz0idXJsKCNGKSIgdHJhbnNmb3JtPSJtYXRyaXgoLS45MjcxODQgLS4zNzQ2MDcgLjM3NDYwNyAtLjkyNzE4NCAxMTA5Ljg5NzQ0NCAxNTc5LjYxMzY2OCkiIGQ9Ik0tNDE4Ljk2IDM4Ny45MzZoMjI1NC44NjV2NTg4SC00MTguOTZ6IiBmaWxsPSJ1cmwoI0QpIiBvcGFjaXR5PSIuMDYiLz48cGF0aCBtYXNrPSJ1cmwoI0YpIiB0cmFuc2Zvcm09Im1hdHJpeCguOTQ1NTE5IC0uMzI1NTY4IC4zMjU1NjggLjk0NTUxOSA1Mi41MzE0NTUgNTczLjI0NDY5NykiIGQ9Ik02OTguNzczLTE2NC4zMzVoMjA4MC41NnY1ODhINjk4Ljc3M3oiIGZpbGw9InVybCgjRSkiIG9wYWNpdHk9Ii4wNSIvPjwvZz48L2c+PC9zdmc+'),\n            linear-gradient(0deg, #1e1e1e 0%, #3b3b3b 100%);\n        background-size: 100% 100%;\n    }\n\n    .splash-screen__bottom[_ngcontent-%COMP%] {\n        position: absolute;\n        bottom: 56px;\n        left: 0;\n        display: flex;\n        width: 100%;\n        align-items: center;\n        justify-content: space-between;\n        box-sizing: border-box;\n        flex-flow: row wrap;\n        padding: 0 96px;\n    }\n\n    .splash-screen__version[_ngcontent-%COMP%] {\n        font-size: 20px;\n        font-weight: bold;\n        color: #ffffff;\n    }\n\n    #hwId[_ngcontent-%COMP%]::-webkit-search-cancel-button {\n        -webkit-appearance: none;\n        background-color: rgba(0, 0, 0, 0.6);\n        -webkit-mask-image: url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%23777'><path d='M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z'/></svg>\");\n        background-size: 20px 20px;\n        height: 20px;\n        width: 20px;\n    }", [".login-tabs[_ngcontent-%COMP%]{width:100%;height:65px}.login-tabs__login-tab[_ngcontent-%COMP%]{cursor:pointer;background-color:#eee;-webkit-filter:opacity(.4);filter:opacity(.4);border-bottom:3px solid;padding:17px;font-size:22px;height:58px}.login-tabs__login-tab--active[_ngcontent-%COMP%]{background-color:#fafafa;-webkit-filter:opacity(1);filter:opacity(1)}.grid[_ngcontent-%COMP%]{width:100%;height:100%}.login-form[_ngcontent-%COMP%]{top:14%;position:relative;height:100%;text-align:center;vertical-align:middle}.login-logo[_ngcontent-%COMP%]{width:100%;height:100px;margin-bottom:30px;background-repeat:no-repeat;background-position:left;background-size:contain}.account_details[_ngcontent-%COMP%]{width:100%;min-height:60px;padding-left:10px;margin-bottom:40px;font-size:26px;border:1px solid #000;border-radius:2px}.tabs-content[_ngcontent-%COMP%]{padding:0 30px 20px}.tabs-content--scan-id[_ngcontent-%COMP%]{padding-top:72px;padding-bottom:75px}.scan-logo[_ngcontent-%COMP%]{margin-bottom:10px}.scan-title[_ngcontent-%COMP%]{width:100%;height:55px;color:rgba(0,0,0,.87);font-size:26px;font-weight:600;text-align:center}.scan-input[_ngcontent-%COMP%]{padding-left:10px}hr[_ngcontent-%COMP%]{margin-top:2rem;margin-bottom:2rem}.x-remove[_ngcontent-%COMP%]{position:absolute;right:50px;border-radius:50%;font:26px monospace;text-align:center;cursor:pointer;vertical-align:middle;background-color:transparent;content:url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%23777'><path d='M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z'/></svg>\");background-size:30px 30px;height:30px;width:30px;opacity:.7;top:.6rem}.x-remove[_ngcontent-%COMP%]:hover{opacity:1}.login[_ngcontent-%COMP%]{display:grid;width:600px;height:730px;background-color:#fff}.login__account_details[_ngcontent-%COMP%]{display:flex;justify-content:space-between;padding-left:35%;font-size:22px;padding-right:10%}.login__row[_ngcontent-%COMP%]{width:100%;display:flex}.login__row--hwid[_ngcontent-%COMP%]{margin-top:2rem;position:relative;display:inline-flex;align-items:center;box-sizing:border-box}.login__label[_ngcontent-%COMP%]{width:31.5%;font-size:21px;font-weight:500;display:grid;place-items:center right;margin-right:1rem}.login__input[_ngcontent-%COMP%]{width:56%;min-height:48px;margin-bottom:10px;font-size:20px;border:1px solid #000;border-radius:6px}.login__input--error[_ngcontent-%COMP%]{border:1px solid #b12828}.login__input--credentials[_ngcontent-%COMP%]{padding-left:15px}.login__input--hwid[_ngcontent-%COMP%]{position:relative;display:flex;align-items:center;margin-top:2rem}.login__input--hwid[_ngcontent-%COMP%]   input[_ngcontent-%COMP%]{padding-right:18px;box-sizing:border-box;width:56%;min-height:48px;margin-bottom:10px;font-size:20px;border:1px solid #000;border-radius:6px;padding-left:10px}.login__password--no-visible[_ngcontent-%COMP%]{-webkit-text-security:disc}.login__password--visible[_ngcontent-%COMP%]{-webkit-text-security:none}.login__icon-visibility[_ngcontent-%COMP%]{position:absolute;font-size:32px;margin-top:85px;margin-left:-50px}.login__rememberme-container[_ngcontent-%COMP%]{min-height:50px;margin-bottom:9px}.login__rememberme-text[_ngcontent-%COMP%]{align-self:center;font-size:16px;font-weight:400;text-transform:capitalize;margin-left:16px}.login__checkbox[_ngcontent-%COMP%]{position:relative;align-self:center;z-index:1;width:30px;height:30px;cursor:pointer;border-radius:4px;opacity:0}.login__checkbox[_ngcontent-%COMP%] + label[_ngcontent-%COMP%]{position:relative;display:flex;padding:0;margin-left:-30px;cursor:pointer;justify-content:center;align-items:center}.login__checkbox[_ngcontent-%COMP%] + label[_ngcontent-%COMP%]:before{display:inline-block;width:30px;height:30px;content:\"\";background-color:#f5f5f5;border:1px solid #000;border-radius:4px}.login__checkbox[_ngcontent-%COMP%]:checked + label[_ngcontent-%COMP%]:after{position:absolute;left:7px;width:6px;height:6px;content:\"\";background:#000;box-shadow:6px 0 0 #000,6px 0 0 #000,6px -6px 0 #000,6px -6px 0 #000,6px -10px 0 #000,6px -12px 0 #000;transform:rotate(45deg)}.login__title[_ngcontent-%COMP%]{margin-top:20px;margin-bottom:6px;text-align:left}.login__title--text[_ngcontent-%COMP%]{font-size:16px}.login__title--icon[_ngcontent-%COMP%]{font-size:22px}.login__ok-button[_ngcontent-%COMP%]{width:100%;padding:10px;text-align:center;min-height:60px;margin-top:20px;margin-bottom:30px;font-size:38px;font-weight:700;color:#fff;cursor:pointer;background-color:#618b31;border-radius:2px;box-shadow:0 0 2px 0 rgba(0,0,0,.14),0 2px 2px 0 rgba(0,0,0,.12),0 1px 3px 0 rgba(0,0,0,.2)}.login__ok-button--disabled[_ngcontent-%COMP%]{cursor:default;opacity:.27}.login__virtual-keyboard-container[_ngcontent-%COMP%]{max-height:46px}.login__virtual-keyboard-text[_ngcontent-%COMP%]{margin-right:15px;font-size:16px;align-self:center}.login__language-selector[_ngcontent-%COMP%]  .select{width:82%;margin-right:-18%;text-align:left}.login__language-option-description[_ngcontent-%COMP%]{font-size:14px;color:rgba(0,0,0,.5)}.login__language-option-description--selected[_ngcontent-%COMP%]{color:rgba(17,148,246,.5)}"]],
                ii = i.Gb({
                    encapsulation: 0,
                    styles: ei,
                    data: {}
                });

            function oi(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 0, "span", [
                    ["class", "login__icon-visibility icon"]
                ], [
                    [2, "icon-visibility", null],
                    [2, "icon-visibility-off", null]
                ], [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.togglePasswordVisibility() && e);
                    return e
                }), null, null))], null, (function(n, t) {
                    var l = t.component;
                    n(t, 0, 0, !l.isPasswordVisible, l.isPasswordVisible)
                }))
            }

            function ri(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 32, "div", [
                    ["class", ""]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 9, "div", [
                    ["class", "login__row"]
                ], null, null, null, null, null)), (n()(), i.Ib(2, 0, null, null, 2, "div", [
                    ["class", "login__label"]
                ], null, null, null, null, null)), (n()(), i.cc(3, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(5, 0, null, null, 5, "input", [
                    ["class", "login__input login__input--credentials"],
                    ["id", "domain"]
                ], [
                    [2, "login__input--error", null],
                    [2, "ng-untouched", null],
                    [2, "ng-touched", null],
                    [2, "ng-pristine", null],
                    [2, "ng-dirty", null],
                    [2, "ng-valid", null],
                    [2, "ng-invalid", null],
                    [2, "ng-pending", null]
                ], [
                    [null, "focus"],
                    [null, "keyup"],
                    [null, "ngModelChange"],
                    [null, "input"],
                    [null, "blur"],
                    [null, "compositionstart"],
                    [null, "compositionend"]
                ], (function(n, t, l) {
                    var e = !0,
                        o = n.component;
                    "input" === t && (e = !1 !== i.Ub(n, 6)._handleInput(l.target.value) && e);
                    "blur" === t && (e = !1 !== i.Ub(n, 6).onTouched() && e);
                    "compositionstart" === t && (e = !1 !== i.Ub(n, 6)._compositionStart() && e);
                    "compositionend" === t && (e = !1 !== i.Ub(n, 6)._compositionEnd(l.target.value) && e);
                    "focus" === t && (e = !1 !== o.showVirtualKeyboard(l.target.id) && e);
                    "keyup" === t && (e = !1 !== o.setButtonState() && e);
                    "ngModelChange" === t && (e = !1 !== (o.loginCredentials.domain = l) && e);
                    return e
                }), null, null)), i.Hb(6, 16384, null, 0, jt.d, [i.P, i.o, [2, jt.a]], null, null), i.Zb(1024, null, jt.h, (function(n) {
                    return [n]
                }), [jt.d]), i.Hb(8, 671744, null, 0, jt.m, [
                    [8, null],
                    [8, null],
                    [8, null],
                    [6, jt.h]
                ], {
                    model: [0, "model"]
                }, {
                    update: "ngModelChange"
                }), i.Zb(2048, null, jt.i, null, [jt.m]), i.Hb(10, 16384, null, 0, jt.j, [
                    [4, jt.i]
                ], null, null), (n()(), i.Ib(11, 0, null, null, 9, "div", [
                    ["class", "login__row"]
                ], null, null, null, null, null)), (n()(), i.Ib(12, 0, null, null, 2, "div", [
                    ["class", "login__label"]
                ], null, null, null, null, null)), (n()(), i.cc(13, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(15, 0, null, null, 5, "input", [
                    ["class", "login__input login__input--credentials"],
                    ["id", "user"]
                ], [
                    [2, "login__input--error", null],
                    [8, "autocomplete", 0],
                    [2, "ng-untouched", null],
                    [2, "ng-touched", null],
                    [2, "ng-pristine", null],
                    [2, "ng-dirty", null],
                    [2, "ng-valid", null],
                    [2, "ng-invalid", null],
                    [2, "ng-pending", null]
                ], [
                    [null, "focus"],
                    [null, "keyup"],
                    [null, "ngModelChange"],
                    [null, "input"],
                    [null, "blur"],
                    [null, "compositionstart"],
                    [null, "compositionend"]
                ], (function(n, t, l) {
                    var e = !0,
                        o = n.component;
                    "input" === t && (e = !1 !== i.Ub(n, 16)._handleInput(l.target.value) && e);
                    "blur" === t && (e = !1 !== i.Ub(n, 16).onTouched() && e);
                    "compositionstart" === t && (e = !1 !== i.Ub(n, 16)._compositionStart() && e);
                    "compositionend" === t && (e = !1 !== i.Ub(n, 16)._compositionEnd(l.target.value) && e);
                    "focus" === t && (e = !1 !== o.showVirtualKeyboard(l.target.id) && e);
                    "keyup" === t && (e = !1 !== o.setButtonState() && e);
                    "ngModelChange" === t && (e = !1 !== (o.loginCredentials.user = l) && e);
                    return e
                }), null, null)), i.Hb(16, 16384, null, 0, jt.d, [i.P, i.o, [2, jt.a]], null, null), i.Zb(1024, null, jt.h, (function(n) {
                    return [n]
                }), [jt.d]), i.Hb(18, 671744, null, 0, jt.m, [
                    [8, null],
                    [8, null],
                    [8, null],
                    [6, jt.h]
                ], {
                    model: [0, "model"]
                }, {
                    update: "ngModelChange"
                }), i.Zb(2048, null, jt.i, null, [jt.m]), i.Hb(20, 16384, null, 0, jt.j, [
                    [4, jt.i]
                ], null, null), (n()(), i.Ib(21, 0, null, null, 11, "div", [
                    ["class", "login__row"]
                ], null, null, null, null, null)), (n()(), i.Ib(22, 0, null, null, 2, "div", [
                    ["class", "login__label"]
                ], null, null, null, null, null)), (n()(), i.cc(23, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.xb(16777216, null, null, 1, null, oi)), i.Hb(26, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.Ib(27, 0, null, null, 5, "input", [
                    ["class", "login__input login__password login__input--credentials"],
                    ["id", "password"],
                    ["type", "password"]
                ], [
                    [2, "login__input--error", null],
                    [2, "login__password--visible", null],
                    [2, "login__password--no-visible", null],
                    [8, "autocomplete", 0],
                    [2, "ng-untouched", null],
                    [2, "ng-touched", null],
                    [2, "ng-pristine", null],
                    [2, "ng-dirty", null],
                    [2, "ng-valid", null],
                    [2, "ng-invalid", null],
                    [2, "ng-pending", null]
                ], [
                    [null, "focus"],
                    [null, "focusout"],
                    [null, "keyup"],
                    [null, "ngModelChange"],
                    [null, "input"],
                    [null, "blur"],
                    [null, "compositionstart"],
                    [null, "compositionend"]
                ], (function(n, t, l) {
                    var e = !0,
                        o = n.component;
                    "input" === t && (e = !1 !== i.Ub(n, 28)._handleInput(l.target.value) && e);
                    "blur" === t && (e = !1 !== i.Ub(n, 28).onTouched() && e);
                    "compositionstart" === t && (e = !1 !== i.Ub(n, 28)._compositionStart() && e);
                    "compositionend" === t && (e = !1 !== i.Ub(n, 28)._compositionEnd(l.target.value) && e);
                    "focus" === t && (o.showVirtualKeyboard(l.target.id), e = !1 !== o.onFocusPassword() && e);
                    "focusout" === t && (e = !1 !== o.onFocusOutPassword() && e);
                    "keyup" === t && (e = !1 !== o.setButtonState() && e);
                    "ngModelChange" === t && (e = !1 !== (o.loginCredentials.password = l) && e);
                    "ngModelChange" === t && (e = !1 !== o.onPasswordChange(l) && e);
                    return e
                }), null, null)), i.Hb(28, 16384, null, 0, jt.d, [i.P, i.o, [2, jt.a]], null, null), i.Zb(1024, null, jt.h, (function(n) {
                    return [n]
                }), [jt.d]), i.Hb(30, 671744, null, 0, jt.m, [
                    [8, null],
                    [8, null],
                    [8, null],
                    [6, jt.h]
                ], {
                    model: [0, "model"]
                }, {
                    update: "ngModelChange"
                }), i.Zb(2048, null, jt.i, null, [jt.m]), i.Hb(32, 16384, null, 0, jt.j, [
                    [4, jt.i]
                ], null, null)], (function(n, t) {
                    var l = t.component;
                    n(t, 8, 0, l.loginCredentials.domain), n(t, 18, 0, l.loginCredentials.user), n(t, 26, 0, l.showHidePassword && l.passwordVisibilityIcon), n(t, 30, 0, l.loginCredentials.password)
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 3, 0, i.dc(t, 3, 0, i.Ub(t, 4).transform("ch_domain"))), n(t, 5, 0, !l.isCredentialFound, i.Ub(t, 10).ngClassUntouched, i.Ub(t, 10).ngClassTouched, i.Ub(t, 10).ngClassPristine, i.Ub(t, 10).ngClassDirty, i.Ub(t, 10).ngClassValid, i.Ub(t, 10).ngClassInvalid, i.Ub(t, 10).ngClassPending), n(t, 13, 0, i.dc(t, 13, 0, i.Ub(t, 14).transform("ch_user"))), n(t, 15, 0, !l.isCredentialFound, l.rememberme && l.allowRemember, i.Ub(t, 20).ngClassUntouched, i.Ub(t, 20).ngClassTouched, i.Ub(t, 20).ngClassPristine, i.Ub(t, 20).ngClassDirty, i.Ub(t, 20).ngClassValid, i.Ub(t, 20).ngClassInvalid, i.Ub(t, 20).ngClassPending), n(t, 23, 0, i.dc(t, 23, 0, i.Ub(t, 24).transform("ch_password"))), n(t, 27, 1, [!l.isCredentialFound, l.isPasswordVisible, !l.isPasswordVisible, l.rememberme && l.allowRemember, i.Ub(t, 32).ngClassUntouched, i.Ub(t, 32).ngClassTouched, i.Ub(t, 32).ngClassPristine, i.Ub(t, 32).ngClassDirty, i.Ub(t, 32).ngClassValid, i.Ub(t, 32).ngClassInvalid, i.Ub(t, 32).ngClassPending])
                }))
            }

            function ui(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 10, "div", [
                    ["class", "col grid grid-2 grid-center login__rememberme-container"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 5, "input", [
                    ["class", "login__checkbox"],
                    ["id", "rememberme"],
                    ["type", "checkbox"]
                ], [
                    [2, "ng-untouched", null],
                    [2, "ng-touched", null],
                    [2, "ng-pristine", null],
                    [2, "ng-dirty", null],
                    [2, "ng-valid", null],
                    [2, "ng-invalid", null],
                    [2, "ng-pending", null]
                ], [
                    [null, "ngModelChange"],
                    [null, "change"],
                    [null, "blur"]
                ], (function(n, t, l) {
                    var e = !0,
                        o = n.component;
                    "change" === t && (e = !1 !== i.Ub(n, 2).onChange(l.target.checked) && e);
                    "blur" === t && (e = !1 !== i.Ub(n, 2).onTouched() && e);
                    "ngModelChange" === t && (e = !1 !== (o.rememberme = l) && e);
                    return e
                }), null, null)), i.Hb(2, 16384, null, 0, jt.b, [i.P, i.o], null, null), i.Zb(1024, null, jt.h, (function(n) {
                    return [n]
                }), [jt.b]), i.Hb(4, 671744, null, 0, jt.m, [
                    [8, null],
                    [8, null],
                    [8, null],
                    [6, jt.h]
                ], {
                    model: [0, "model"]
                }, {
                    update: "ngModelChange"
                }), i.Zb(2048, null, jt.i, null, [jt.m]), i.Hb(6, 16384, null, 0, jt.j, [
                    [4, jt.i]
                ], null, null), (n()(), i.Ib(7, 0, null, null, 0, "label", [], null, null, null, null, null)), (n()(), i.Ib(8, 0, null, null, 2, "span", [
                    ["class", "login__rememberme-text"]
                ], null, null, null, null, null)), (n()(), i.cc(9, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i])], (function(n, t) {
                    n(t, 4, 0, t.component.rememberme)
                }), (function(n, t) {
                    n(t, 1, 0, i.Ub(t, 6).ngClassUntouched, i.Ub(t, 6).ngClassTouched, i.Ub(t, 6).ngClassPristine, i.Ub(t, 6).ngClassDirty, i.Ub(t, 6).ngClassValid, i.Ub(t, 6).ngClassInvalid, i.Ub(t, 6).ngClassPending), n(t, 9, 0, i.dc(t, 9, 0, i.Ub(t, 10).transform("ch_rememberme")))
                }))
            }

            function si(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "div", [
                    ["class", "login__language-option-description"]
                ], [
                    [2, "login__language-option-description--selected", null]
                ], null, null, null, null)), (n()(), i.cc(1, null, [" ", " "]))], null, (function(n, t) {
                    n(t, 0, 0, t.component.languageSelected === t.parent.parent.context.$implicit.value), n(t, 1, 0, t.parent.parent.context.$implicit.description)
                }))
            }

            function ci(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 4, null, null, null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 1, "div", [], null, null, null, null, null)), (n()(), i.cc(2, null, ["", ""])), (n()(), i.xb(16777216, null, null, 1, null, si)), i.Hb(4, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(0, null, null, 0))], (function(n, t) {
                    n(t, 4, 0, t.parent.context.$implicit.description)
                }), (function(n, t) {
                    n(t, 2, 0, t.parent.context.$implicit.key)
                }))
            }

            function ai(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 3, "grc-option", [], null, null, null, Me, Oe)), i.Hb(1, 114688, [
                    [3, 4]
                ], 0, Se.a, [], {
                    value: [0, "value"]
                }, null), (n()(), i.xb(16777216, null, 0, 1, null, ci)), i.Hb(3, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(n, t) {
                    var l = t.component;
                    n(t, 1, 0, i.Mb(1, "", t.context.$implicit.value, "")), n(t, 3, 0, l.languages.length > 1)
                }), null)
            }

            function di(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 72, "div", [
                    ["class", "login-form"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 0, "div", [
                    ["class", "login-logo"]
                ], null, null, null, null, null)), (n()(), i.Ib(2, 0, null, null, 70, "div", [
                    ["class", "login"]
                ], null, null, null, null, null)), (n()(), i.Ib(3, 0, null, null, 69, "div", [
                    ["class", "tabs-content"]
                ], null, null, null, null, null)), (n()(), i.Ib(4, 0, null, null, 30, "div", [
                    ["class", "tabs-content tabs-content--scan-id"]
                ], [
                    [8, "hidden", 0]
                ], null, null, null, null)), (n()(), i.Ib(5, 0, null, null, 1, "div", [
                    ["class", "scan-logo grid grid-center grid-middle"]
                ], null, null, null, null, null)), (n()(), i.Ib(6, 0, null, null, 0, "img", [
                    ["alt", "Scan ID"],
                    ["height", "72px"],
                    ["src", "./assets/images/barcode_scan.svg"],
                    ["width", "72px"]
                ], null, null, null, null, null)), (n()(), i.Ib(7, 0, null, null, 3, "div", [
                    ["class", "scan-title"]
                ], null, null, null, null, null)), (n()(), i.Ib(8, 0, null, null, 2, "span", [], null, null, null, null, null)), (n()(), i.cc(9, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(11, 0, null, null, 11, "span", [
                    ["class", "login__input--hwid"]
                ], null, null, null, null, null)), (n()(), i.Ib(12, 0, null, null, 2, "div", [
                    ["class", "login__label"]
                ], null, null, null, null, null)), (n()(), i.cc(13, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(15, 0, [
                    [1, 0],
                    ["barcode", 1]
                ], null, 5, "input", [
                    ["class", ""],
                    ["id", "barcode"]
                ], [
                    [2, "login__input--error", null],
                    [2, "ng-untouched", null],
                    [2, "ng-touched", null],
                    [2, "ng-pristine", null],
                    [2, "ng-dirty", null],
                    [2, "ng-valid", null],
                    [2, "ng-invalid", null],
                    [2, "ng-pending", null]
                ], [
                    [null, "input"],
                    [null, "focus"],
                    [null, "ngModelChange"],
                    [null, "blur"],
                    [null, "compositionstart"],
                    [null, "compositionend"]
                ], (function(n, t, l) {
                    var e = !0,
                        o = n.component;
                    "input" === t && (e = !1 !== i.Ub(n, 16)._handleInput(l.target.value) && e);
                    "blur" === t && (e = !1 !== i.Ub(n, 16).onTouched() && e);
                    "compositionstart" === t && (e = !1 !== i.Ub(n, 16)._compositionStart() && e);
                    "compositionend" === t && (e = !1 !== i.Ub(n, 16)._compositionEnd(l.target.value) && e);
                    "input" === t && (e = !1 !== o.setButtonState() && e);
                    "focus" === t && (e = !1 !== o.showVirtualKeyboard(l.target.id) && e);
                    "ngModelChange" === t && (e = !1 !== (o.loginCredentials.barcode = l) && e);
                    return e
                }), null, null)), i.Hb(16, 16384, null, 0, jt.d, [i.P, i.o, [2, jt.a]], null, null), i.Zb(1024, null, jt.h, (function(n) {
                    return [n]
                }), [jt.d]), i.Hb(18, 671744, null, 0, jt.m, [
                    [8, null],
                    [8, null],
                    [8, null],
                    [6, jt.h]
                ], {
                    model: [0, "model"]
                }, {
                    update: "ngModelChange"
                }), i.Zb(2048, null, jt.i, null, [jt.m]), i.Hb(20, 16384, null, 0, jt.j, [
                    [4, jt.i]
                ], null, null), (n()(), i.Ib(21, 0, null, null, 1, "span", [
                    ["class", "x-remove"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.removeInput("barcode") && e);
                    return e
                }), null, null)), (n()(), i.cc(-1, null, ["x"])), (n()(), i.Ib(23, 0, null, null, 11, "div", [
                    ["class", "login__row"]
                ], null, null, null, null, null)), (n()(), i.Ib(24, 0, null, null, 2, "div", [
                    ["class", "login__label"]
                ], null, null, null, null, null)), (n()(), i.cc(25, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(27, 0, null, null, 7, "input", [
                    ["class", "login__input scan-input"],
                    ["id", "pinHash"],
                    ["maxlength", "4"],
                    ["type", "password"]
                ], [
                    [2, "login__input--error", null],
                    [1, "maxlength", 0],
                    [2, "ng-untouched", null],
                    [2, "ng-touched", null],
                    [2, "ng-pristine", null],
                    [2, "ng-dirty", null],
                    [2, "ng-valid", null],
                    [2, "ng-invalid", null],
                    [2, "ng-pending", null]
                ], [
                    [null, "input"],
                    [null, "focus"],
                    [null, "ngModelChange"],
                    [null, "blur"],
                    [null, "compositionstart"],
                    [null, "compositionend"]
                ], (function(n, t, l) {
                    var e = !0,
                        o = n.component;
                    "input" === t && (e = !1 !== i.Ub(n, 28)._handleInput(l.target.value) && e);
                    "blur" === t && (e = !1 !== i.Ub(n, 28).onTouched() && e);
                    "compositionstart" === t && (e = !1 !== i.Ub(n, 28)._compositionStart() && e);
                    "compositionend" === t && (e = !1 !== i.Ub(n, 28)._compositionEnd(l.target.value) && e);
                    "input" === t && (e = !1 !== o.validatePinhash(l) && e);
                    "input" === t && (e = !1 !== o.setButtonState() && e);
                    "focus" === t && (e = !1 !== o.showVirtualKeyboard(l.target.id, !0) && e);
                    "ngModelChange" === t && (e = !1 !== (o.loginCredentials.pinHash = l) && e);
                    return e
                }), null, null)), i.Hb(28, 16384, null, 0, jt.d, [i.P, i.o, [2, jt.a]], null, null), i.Hb(29, 540672, null, 0, jt.f, [], {
                    maxlength: [0, "maxlength"]
                }, null), i.Zb(1024, null, jt.g, (function(n) {
                    return [n]
                }), [jt.f]), i.Zb(1024, null, jt.h, (function(n) {
                    return [n]
                }), [jt.d]), i.Hb(32, 671744, null, 0, jt.m, [
                    [8, null],
                    [6, jt.g],
                    [8, null],
                    [6, jt.h]
                ], {
                    model: [0, "model"]
                }, {
                    update: "ngModelChange"
                }), i.Zb(2048, null, jt.i, null, [jt.m]), i.Hb(34, 16384, null, 0, jt.j, [
                    [4, jt.i]
                ], null, null), (n()(), i.Ib(35, 0, null, null, 21, "div", [
                    ["class", "tabs-content tabs-content--manual-login"]
                ], [
                    [8, "hidden", 0]
                ], null, null, null, null)), (n()(), i.Ib(36, 0, null, null, 11, "span", [
                    ["class", "login__input--hwid"]
                ], null, null, null, null, null)), (n()(), i.Ib(37, 0, null, null, 2, "div", [
                    ["class", "login__label"]
                ], null, null, null, null, null)), (n()(), i.cc(38, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(40, 0, [
                    [2, 0],
                    ["hwId", 1]
                ], null, 5, "input", [
                    ["id", "hwId"],
                    ["type", "text"]
                ], [
                    [2, "login__input--error", null],
                    [2, "ng-untouched", null],
                    [2, "ng-touched", null],
                    [2, "ng-pristine", null],
                    [2, "ng-dirty", null],
                    [2, "ng-valid", null],
                    [2, "ng-invalid", null],
                    [2, "ng-pending", null]
                ], [
                    [null, "change"],
                    [null, "focus"],
                    [null, "keyup"],
                    [null, "ngModelChange"],
                    [null, "input"],
                    [null, "blur"],
                    [null, "compositionstart"],
                    [null, "compositionend"]
                ], (function(n, t, l) {
                    var e = !0,
                        o = n.component;
                    "input" === t && (e = !1 !== i.Ub(n, 41)._handleInput(l.target.value) && e);
                    "blur" === t && (e = !1 !== i.Ub(n, 41).onTouched() && e);
                    "compositionstart" === t && (e = !1 !== i.Ub(n, 41)._compositionStart() && e);
                    "compositionend" === t && (e = !1 !== i.Ub(n, 41)._compositionEnd(l.target.value) && e);
                    "change" === t && (e = !1 !== o.updateAccount() && e);
                    "focus" === t && (e = !1 !== o.showVirtualKeyboard(l.target.id) && e);
                    "keyup" === t && (e = !1 !== o.setButtonState() && e);
                    "ngModelChange" === t && (e = !1 !== (o.loginCredentials.hwId = l) && e);
                    return e
                }), null, null)), i.Hb(41, 16384, null, 0, jt.d, [i.P, i.o, [2, jt.a]], null, null), i.Zb(1024, null, jt.h, (function(n) {
                    return [n]
                }), [jt.d]), i.Hb(43, 671744, null, 0, jt.m, [
                    [8, null],
                    [8, null],
                    [8, null],
                    [6, jt.h]
                ], {
                    model: [0, "model"]
                }, {
                    update: "ngModelChange"
                }), i.Zb(2048, null, jt.i, null, [jt.m]), i.Hb(45, 16384, null, 0, jt.j, [
                    [4, jt.i]
                ], null, null), (n()(), i.Ib(46, 0, null, null, 1, "span", [
                    ["class", "x-remove"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.resetAccount() && e);
                    return e
                }), null, null)), (n()(), i.cc(-1, null, ["x"])), (n()(), i.Ib(48, 0, null, null, 3, "span", [
                    ["class", "login__account_details"]
                ], null, null, null, null, null)), (n()(), i.Ib(49, 0, null, null, 2, "span", [
                    ["class", "login__title--text"]
                ], null, null, null, null, null)), (n()(), i.cc(50, null, [" ", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(52, 0, null, null, 0, "hr", [], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, ri)), i.Hb(54, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, ui)), i.Hb(56, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.Ib(57, 0, null, null, 2, "div", [
                    ["class", "login__ok-button"]
                ], [
                    [2, "login__ok-button--disabled", null]
                ], [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== (!i.isDisabled && i.onSuccess()) && e);
                    return e
                }), null, null)), (n()(), i.cc(58, null, [" ", " "])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(60, 0, null, null, 12, "div", [
                    ["class", "col grid grid-2 grid-center"]
                ], null, null, null, null, null)), (n()(), i.Ib(61, 0, null, null, 5, "div", [
                    ["class", "col grid grid-2 grid-center login__virtual-keyboard-container"]
                ], null, null, null, null, null)), (n()(), i.Ib(62, 0, null, null, 2, "span", [
                    ["class", "login__virtual-keyboard-text"]
                ], null, null, null, null, null)), (n()(), i.cc(63, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(65, 0, null, null, 1, "gr-toggle-button", [], null, [
                    [null, "changed"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "changed" === t && (e = !1 !== i.onSwitchChanged(l) && e);
                    return e
                }), Ue, Ee)), i.Hb(66, 114688, null, 0, Te.a, [], {
                    isActive: [0, "isActive"]
                }, {
                    changed: "changed"
                }), (n()(), i.Ib(67, 0, null, null, 5, "div", [
                    ["class", "col grid login__language-selector"]
                ], null, null, null, null, null)), (n()(), i.Ib(68, 0, null, null, 4, "grc-select", [
                    ["class", ""]
                ], [
                    [2, "select--opened", null]
                ], [
                    [null, "change"],
                    [null, "openedChange"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "change" === t && (e = !1 !== i.onSelectLanguageChange(l) && e);
                    "openedChange" === t && (e = !1 !== i.selectLanguageOnOpenedChange(l) && e);
                    return e
                }), Xe, We)), i.Hb(69, 1163264, null, 1, ze.a, [], {
                    optionsArray: [0, "optionsArray"],
                    languageSelected: [1, "languageSelected"],
                    orientation: [2, "orientation"]
                }, {
                    openedChange: "openedChange",
                    change: "change"
                }), i.ac(603979776, 3, {
                    options: 1
                }), (n()(), i.xb(16777216, null, null, 1, null, ai)), i.Hb(72, 278528, null, 0, Y.l, [i.eb, i.Z, i.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(n, t) {
                    var l = t.component;
                    n(t, 18, 0, l.loginCredentials.barcode);
                    n(t, 29, 0, "4"), n(t, 32, 0, l.loginCredentials.pinHash), n(t, 43, 0, l.loginCredentials.hwId), n(t, 54, 0, !l.showOptions), n(t, 56, 0, l.allowRemember), n(t, 66, 0, l.isActive), n(t, 69, 0, l.languages, l.languageSelected, l.selectOrientation.VERTICAL), n(t, 72, 0, l.languages)
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 4, 0, "scan" !== l.loginTabs), n(t, 9, 0, i.dc(t, 9, 0, i.Ub(t, 10).transform("ch_scan_credential"))), n(t, 13, 0, i.dc(t, 13, 0, i.Ub(t, 14).transform("ch_credentials"))), n(t, 15, 0, !l.isCredentialFound, i.Ub(t, 20).ngClassUntouched, i.Ub(t, 20).ngClassTouched, i.Ub(t, 20).ngClassPristine, i.Ub(t, 20).ngClassDirty, i.Ub(t, 20).ngClassValid, i.Ub(t, 20).ngClassInvalid, i.Ub(t, 20).ngClassPending), n(t, 25, 0, i.dc(t, 25, 0, i.Ub(t, 26).transform("ch_pin"))), n(t, 27, 0, !l.isCredentialFound, i.Ub(t, 29).maxlength ? i.Ub(t, 29).maxlength : null, i.Ub(t, 34).ngClassUntouched, i.Ub(t, 34).ngClassTouched, i.Ub(t, 34).ngClassPristine, i.Ub(t, 34).ngClassDirty, i.Ub(t, 34).ngClassValid, i.Ub(t, 34).ngClassInvalid, i.Ub(t, 34).ngClassPending), n(t, 35, 0, "manual" !== l.loginTabs), n(t, 38, 0, i.dc(t, 38, 0, i.Ub(t, 39).transform("ch_hardware_id"))), n(t, 40, 0, !l.isHwIdFound, i.Ub(t, 45).ngClassUntouched, i.Ub(t, 45).ngClassTouched, i.Ub(t, 45).ngClassPristine, i.Ub(t, 45).ngClassDirty, i.Ub(t, 45).ngClassValid, i.Ub(t, 45).ngClassInvalid, i.Ub(t, 45).ngClassPending), n(t, 50, 0, i.dc(t, 50, 0, i.Ub(t, 51).transform(l.accountStatus))), n(t, 57, 0, l.isDisabled), n(t, 58, 0, i.dc(t, 58, 0, i.Ub(t, 59).transform("ch_ok"))), n(t, 63, 0, i.dc(t, 63, 0, i.Ub(t, 64).transform("ch_virtual_keyboard"))), n(t, 68, 0, i.Ub(t, 69).isOpened)
                }))
            }

            function pi(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 2, null, null, null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 1, "grc-virtual-keyboard", [], null, [
                    [null, "success"],
                    ["document", "keydown"],
                    ["document", "keydown.backspace"],
                    ["document", "keydown.enter"],
                    ["document", "keydown.escape"],
                    ["document", "paste"]
                ], (function(n, t, l) {
                    var e = !0,
                        o = n.component;
                    "document:keydown" === t && (e = !1 !== i.Ub(n, 2).onKeyDown(l.key, l.keyCode, l.ctrlKey) && e);
                    "document:keydown.backspace" === t && (e = !1 !== i.Ub(n, 2).onBackspace() && e);
                    "document:keydown.enter" === t && (e = !1 !== i.Ub(n, 2).onEnter() && e);
                    "document:keydown.escape" === t && (e = !1 !== i.Ub(n, 2).onEsc() && e);
                    "document:paste" === t && (e = !1 !== i.Ub(n, 2).onPaste(l) && e);
                    "success" === t && (e = !1 !== o.onInsertText(l) && e);
                    return e
                }), Je.b, Je.a)), i.Hb(2, 114688, null, 0, Qe.a, [i.i, s.k], {
                    data: [0, "data"],
                    onlyNumbers: [1, "onlyNumbers"],
                    placeholder: [2, "placeholder"],
                    showHidePassword: [3, "showHidePassword"]
                }, {
                    success: "success"
                })], (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, l.data, l.onlyNumbers, l.elementId, l.showHidePassword)
                }), null)
            }

            function bi(n) {
                return i.ec(0, [i.ac(671088640, 1, {
                    barcodeInput: 0
                }), i.ac(671088640, 2, {
                    hwIdInput: 0
                }), (n()(), i.Ib(2, 0, null, null, 8, "div", [
                    ["class", "grid grid-column grid-middle grid-center login-container"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, di)), i.Hb(4, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, pi)), i.Hb(6, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.Ib(7, 0, null, null, 3, "div", [
                    ["class", "splash-screen__bottom"]
                ], null, null, null, null, null)), (n()(), i.Ib(8, 0, null, null, 2, "div", [
                    ["class", "splash-screen__bottom-left"]
                ], null, null, null, null, null)), (n()(), i.Ib(9, 0, null, null, 1, "div", [
                    ["class", "splash-screen__version"]
                ], null, null, null, null, null)), (n()(), i.cc(-1, null, ["CASHIER VERSION 1.72.9-5"]))], (function(n, t) {
                    var l = t.component;
                    n(t, 4, 0, !l.showKeyboard), n(t, 6, 0, l.showKeyboard)
                }), null)
            }
            var hi = i.Eb("grc-page-login", li, (function(n) {
                    return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-page-login", [], null, [
                        ["document", "keydown.enter"]
                    ], (function(n, t, l) {
                        var e = !0;
                        "document:keydown.enter" === t && (e = !1 !== i.Ub(n, 1).onEnter() && e);
                        return e
                    }), bi, ii)), i.Hb(1, 245760, null, 0, li, [i.i, r.l, r.a, m.a, s.k, _.a, oe, $e.a, b.a], null, null)], (function(n, t) {
                        n(t, 1, 0)
                    }), null)
                }), {}, {}, []),
                gi = l("qIYQ"),
                fi = l("2z2z"),
                mi = l("E6sH"),
                _i = l("1UiX"),
                vi = l("cS+c"),
                yi = l("Md+g"),
                Ci = l("eZM8"),
                ki = l("fHz3"),
                xi = l("iGSx"),
                Ii = l("l+fh"),
                Si = l("KhfW"),
                wi = l("fWpR"),
                Oi = function() {
                    function n() {
                        this.printTicket = new i.q, this.hasJackpot = !1, this.totalWon = 0, this.jackpotWon = 0, this.amountWon = 0
                    }
                    return n.prototype.ngOnInit = function() {
                        this.hasJackpot = this.hasJackpotWon(), this.jackpotWon = this.getJackpotWon(), this.amountWon = this.getAmountWon(), this.totalWon = this.getTotalWon()
                    }, n.prototype.printWinningTicket = function(n) {
                        this.printTicket.emit(n)
                    }, n.prototype.hasJackpotWon = function() {
                        return this.getJackpotWon() > 0
                    }, n.prototype.getJackpotWon = function() {
                        return this.serverTicket._clData.getTotalWonItemized().grossJackpot
                    }, n.prototype.getAmountWon = function() {
                        return this.serverTicket._clData.getTotalWonItemized().grossAmount
                    }, n.prototype.getTotalWon = function() {
                        return this.serverTicket._clData.getTotalWonItemized().gross
                    }, n
                }(),
                Pi = [Si.a, [".pay-prize-dialog[_ngcontent-%COMP%]{padding:0}.pay-prize-dialog__content[_ngcontent-%COMP%]{padding:64px 300px}.pay-prize-dialog__icon[_ngcontent-%COMP%]{margin-bottom:16px;font-size:64px}.pay-prize-dialog__pay-prize[_ngcontent-%COMP%]{font-size:44px;text-transform:capitalize}.pay-prize-dialog__footer[_ngcontent-%COMP%]{font-weight:700}.pay-prize-dialog__inline[_ngcontent-%COMP%]{width:100%;margin:35px 0 20px}.pay-prize-dialog__text[_ngcontent-%COMP%]{font-size:18px;text-transform:uppercase}.pay-prize-dialog__value[_ngcontent-%COMP%]{font-size:22px}.pay-prize-dialog__total-container[_ngcontent-%COMP%]{margin-top:59px}.pay-prize-dialog__total-won[_ngcontent-%COMP%]{margin-top:10px;font-size:44px}.pay-prize-dialog__buttons[_ngcontent-%COMP%]{padding:52px 120px}.pay-prize-dialog__button[_ngcontent-%COMP%]{padding:20px 100px;font-size:32px}"]],
                Mi = i.Gb({
                    encapsulation: 0,
                    styles: Pi,
                    data: {}
                });

            function Ti(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 14, "div", [
                    ["class", "grid grid-center grid-space-around pay-prize-dialog__inline"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 6, "div", [], null, null, null, null, null)), (n()(), i.Ib(2, 0, null, null, 2, "span", [
                    ["class", "pay-prize-dialog__text"]
                ], null, null, null, null, null)), (n()(), i.cc(3, null, ["", ": "])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(5, 0, null, null, 2, "span", [
                    ["class", "pay-prize-dialog__value"]
                ], null, null, null, null, null)), (n()(), i.cc(6, null, ["", ""])), i.Wb(131072, s.b, [s.k, i.i]), (n()(), i.Ib(8, 0, null, null, 6, "div", [], null, null, null, null, null)), (n()(), i.Ib(9, 0, null, null, 2, "span", [
                    ["class", "pay-prize-dialog__text"]
                ], null, null, null, null, null)), (n()(), i.cc(10, null, ["", ": "])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(12, 0, null, null, 2, "span", [
                    ["class", "pay-prize-dialog__value"]
                ], null, null, null, null, null)), (n()(), i.cc(13, null, [" ", ""])), i.Wb(131072, s.b, [s.k, i.i])], null, (function(n, t) {
                    var l = t.component;
                    n(t, 3, 0, i.dc(t, 3, 0, i.Ub(t, 4).transform("ch_won_amount"))), n(t, 6, 0, i.dc(t, 6, 0, i.Ub(t, 7).transform(l.amountWon))), n(t, 10, 0, i.dc(t, 10, 0, i.Ub(t, 11).transform("ch_jackpot"))), n(t, 13, 0, i.dc(t, 13, 0, i.Ub(t, 14).transform(l.jackpotWon)))
                }))
            }

            function ji(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 2, "span", [
                    ["class", "pay-prize-dialog__text"]
                ], null, null, null, null, null)), (n()(), i.cc(1, null, [" ", " "])), i.Wb(131072, s.j, [s.k, i.i])], null, (function(n, t) {
                    n(t, 1, 0, i.dc(t, 1, 0, i.Ub(t, 2).transform("ch_total_won")))
                }))
            }

            function Ei(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 2, "span", [
                    ["class", "pay-prize-dialog__text"]
                ], null, null, null, null, null)), (n()(), i.cc(1, null, [" ", ": "])), i.Wb(131072, s.j, [s.k, i.i])], null, (function(n, t) {
                    n(t, 1, 0, i.dc(t, 1, 0, i.Ub(t, 2).transform("ch_won_amount")))
                }))
            }

            function Ui(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 31, "div", [
                    ["class", "grid grid-column pay-prize-dialog"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 5, "div", [
                    ["class", "col grid grid-center"]
                ], null, null, null, null, null)), (n()(), i.Ib(2, 0, null, null, 4, "div", [
                    ["class", "pay-prize-dialog__content"]
                ], null, null, null, null, null)), (n()(), i.Ib(3, 0, null, null, 0, "div", [
                    ["class", "grid grid-center icon icon-check pay-prize-dialog__icon"]
                ], null, null, null, null, null)), (n()(), i.Ib(4, 0, null, null, 2, "div", [
                    ["class", "pay-prize-dialog__pay-prize"]
                ], null, null, null, null, null)), (n()(), i.cc(5, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(7, 0, null, null, 24, "div", [
                    ["class", "pay-prize-dialog__footer"]
                ], null, null, null, null, null)), (n()(), i.Ib(8, 0, null, null, 14, "div", [
                    ["class", "grid grid-middle grid-column"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, Ti)), i.Hb(10, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.Ib(11, 0, null, null, 11, "div", [
                    ["class", "grid grid-column grid-middle"]
                ], null, null, null, null, null)), i.Zb(512, null, Y.x, Y.y, [i.A, i.B, i.o, i.P]), i.Hb(13, 278528, null, 0, Y.k, [Y.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), i.Xb(14, {
                    "pay-prize-dialog__total-container": 0
                }), (n()(), i.Ib(15, 0, null, null, 4, "span", [], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, ji)), i.Hb(17, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, Ei)), i.Hb(19, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.Ib(20, 0, null, null, 2, "span", [
                    ["class", "pay-prize-dialog__total-won"]
                ], null, null, null, null, null)), (n()(), i.cc(21, null, [" ", ""])), i.Wb(131072, s.b, [s.k, i.i]), (n()(), i.Ib(23, 0, null, null, 8, "div", [
                    ["class", "grid grid-space-between pay-prize-dialog__buttons"]
                ], null, null, null, null, null)), (n()(), i.Ib(24, 0, null, null, 3, "div", [
                    ["class", "grid grid-center pay-prize-dialog__button pay-prize-dialog__button--ghost"],
                    ["grcModalClose", "base"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        o = n.component;
                    "click" === t && (e = !1 !== i.Ub(n, 25).onClick() && e);
                    "click" === t && (e = !1 !== o.printWinningTicket(!1) && e);
                    return e
                }), null, null)), i.Hb(25, 16384, null, 0, wi.a, [Jl.a], {
                    grcModalClose: [0, "grcModalClose"]
                }, null), (n()(), i.cc(26, null, [" ", " "])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(28, 0, null, null, 3, "div", [
                    ["class", "grid grid-center pay-prize-dialog__button pay-prize-dialog__button--success"],
                    ["grcModalClose", "base"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        o = n.component;
                    "click" === t && (e = !1 !== i.Ub(n, 29).onClick() && e);
                    "click" === t && (e = !1 !== o.printWinningTicket(!0) && e);
                    return e
                }), null, null)), i.Hb(29, 16384, null, 0, wi.a, [Jl.a], {
                    grcModalClose: [0, "grcModalClose"]
                }, null), (n()(), i.cc(30, null, [" ", " "])), i.Wb(131072, s.j, [s.k, i.i])], (function(n, t) {
                    var l = t.component;
                    n(t, 10, 0, l.hasJackpot);
                    var e = n(t, 14, 0, !l.hasJackpot);
                    n(t, 13, 0, "grid grid-column grid-middle", e), n(t, 17, 0, l.hasJackpot), n(t, 19, 0, !l.hasJackpot);
                    n(t, 25, 0, "base");
                    n(t, 29, 0, "base")
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 5, 0, i.dc(t, 5, 0, i.Ub(t, 6).transform("ch_pay_prize"))), n(t, 21, 0, i.dc(t, 21, 0, i.Ub(t, 22).transform(l.totalWon))), n(t, 26, 0, i.dc(t, 26, 0, i.Ub(t, 27).transform("ch_no"))), n(t, 30, 0, i.dc(t, 30, 0, i.Ub(t, 31).transform("ch_yes")))
                }))
            }
            var Ai = i.Eb("pay-prize-dialog", Oi, (function(n) {
                    return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "pay-prize-dialog", [], null, null, null, Ui, Mi)), i.Hb(1, 114688, null, 0, Oi, [], null, null)], (function(n, t) {
                        n(t, 1, 0)
                    }), null)
                }), {
                    serverTicket: "serverTicket"
                }, {
                    printTicket: "printTicket"
                }, []),
                Bi = function() {
                    function n() {}
                    return n.prototype.ngOnInit = function() {}, n
                }(),
                Hi = [
                    [".shortcuts-help-header[_ngcontent-%COMP%]{font-weight:700;text-transform:uppercase}.shortcuts-help-header__icon[_ngcontent-%COMP%]{padding-right:15px;font-size:50px}.shortcuts-help-header__title[_ngcontent-%COMP%]{font-size:26px}.shortcuts-help-header__subtitle[_ngcontent-%COMP%]{margin-bottom:5px;font-size:16px;font-weight:400}"]
                ],
                Di = i.Gb({
                    encapsulation: 0,
                    styles: Hi,
                    data: {}
                });

            function Li(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 9, "div", [
                    ["class", "grid grid-no-wrap shortcuts-help-header"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 1, "div", [
                    ["class", "col-middle"]
                ], null, null, null, null, null)), (n()(), i.Ib(2, 0, null, null, 0, "span", [
                    ["class", "icon icon-shortcuts shortcuts-help-header__icon"]
                ], null, null, null, null, null)), (n()(), i.Ib(3, 0, null, null, 6, "div", [
                    ["class", "grid grid-no-wrap grid-column grid-center"]
                ], null, null, null, null, null)), (n()(), i.Ib(4, 0, null, null, 2, "div", [
                    ["class", "shortcuts-help-header__subtitle"]
                ], null, null, null, null, null)), (n()(), i.cc(5, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(7, 0, null, null, 2, "div", [
                    ["class", "shortcuts-help-header__title"]
                ], null, null, null, null, null)), (n()(), i.cc(8, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i])], null, (function(n, t) {
                    n(t, 5, 0, i.dc(t, 5, 0, i.Ub(t, 6).transform("ch_shortcuts"))), n(t, 8, 0, i.dc(t, 8, 0, i.Ub(t, 9).transform("ch_help")))
                }))
            }
            i.Eb("grc-header-shortcuts-help", Bi, (function(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-header-shortcuts-help", [], null, null, null, Li, Di)), i.Hb(1, 114688, null, 0, Bi, [], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {}, {}, []);
            var Ni = function() {
                    function n() {
                        this.icons = ["arrow-up", "arrow-down", "arrow-right", "arrow-back"], this.columns = [{
                            title: "ch_actions",
                            shortcuts: [{
                                title: "ch_printer_ticket",
                                key: [
                                    ["enter"]
                                ]
                            }, {
                                title: "ch_print_last_ticket",
                                key: [
                                    ["alt"]
                                ]
                            }, {
                                title: "ch_next_betmode",
                                isAvailable: !0,
                                isIcon: !0,
                                key: [
                                    ["ctrl", this.icons[0]]
                                ]
                            }, {
                                title: "ch_previous_betmode",
                                isAvailable: !0,
                                isIcon: !0,
                                key: [
                                    ["ctrl", this.icons[1]]
                                ]
                            }, {
                                title: "ch_clear_betslip",
                                key: [
                                    ["supr"]
                                ]
                            }, {
                                title: "ch_close_popup",
                                key: [
                                    ["esc"]
                                ]
                            }, {
                                title: "ch_logout",
                                key: [
                                    ["alt", "L"]
                                ]
                            }]
                        }, {
                            title: "ch_navigation",
                            shortcuts: [{
                                title: "ch_previous_game",
                                isIcon: !0,
                                key: [
                                    [this.icons[3]]
                                ]
                            }, {
                                title: "ch_next_game",
                                isIcon: !0,
                                key: [
                                    [this.icons[2]]
                                ]
                            }, {
                                title: "ch_previous_market",
                                isIcon: !0,
                                key: [
                                    [this.icons[1]]
                                ]
                            }, {
                                title: "ch_next_market",
                                isIcon: !0,
                                key: [
                                    [this.icons[0]]
                                ]
                            }, {
                                title: "ch_pay_table_standings",
                                isAvailable: !0,
                                key: [
                                    ["alt", "P"]
                                ]
                            }, {
                                title: "ch_results_history",
                                key: [
                                    ["alt", "R"]
                                ]
                            }, {
                                title: "sa_shop_admin",
                                key: [
                                    ["alt", "S"]
                                ]
                            }, {
                                title: "ch_fastbet_help",
                                isAvailable: !0,
                                key: [
                                    ["space"]
                                ]
                            }]
                        }]
                    }
                    return n.prototype.ngOnInit = function() {}, n
                }(),
                zi = [
                    [".shortcuts-help-body__header[_ngcontent-%COMP%]{width:100%;padding:0 205px}.shortcuts-help-body__title[_ngcontent-%COMP%]{margin-bottom:34px;font-size:22px;text-transform:uppercase}.shortcut[_ngcontent-%COMP%]{margin-bottom:16px}.shortcut__title[_ngcontent-%COMP%]{max-width:285px;font-size:26px;text-transform:capitalize}.shortcut__key[_ngcontent-%COMP%]{display:flex;max-width:97px;height:47px;align-items:center;padding:0 20px;font-size:16px;text-transform:capitalize;border-radius:2px}.shortcut__key--big[_ngcontent-%COMP%]{font-size:26px}.shortcut__combination[_ngcontent-%COMP%]{padding:0 8px;font-size:24px}.shortcut__available[_ngcontent-%COMP%]{margin-top:5px;font-size:13px}"]
                ],
                Ri = i.Gb({
                    encapsulation: 0,
                    styles: zi,
                    data: {}
                });

            function Wi(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 2, "div", [
                    ["class", "shortcut__available"]
                ], null, null, null, null, null)), (n()(), i.cc(1, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i])], null, (function(n, t) {
                    n(t, 1, 0, i.dc(t, 1, 0, i.Ub(t, 2).transform("ch_available")))
                }))
            }

            function Fi(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 4, "span", [
                    ["class", "shortcut__key"]
                ], null, null, null, null, null)), i.Zb(512, null, Y.x, Y.y, [i.A, i.B, i.o, i.P]), i.Hb(2, 278528, null, 0, Y.k, [Y.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), i.Xb(3, {
                    "shortcut__key--big": 0
                }), (n()(), i.cc(4, null, ["", ""]))], (function(n, t) {
                    var l = n(t, 3, 0, "+" === t.parent.context.$implicit[t.parent.context.index]);
                    n(t, 2, 0, "shortcut__key", l)
                }), (function(n, t) {
                    n(t, 4, 0, t.parent.context.$implicit)
                }))
            }

            function Gi(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 0, "span", [], [
                    [8, "className", 0]
                ], null, null, null, null))], null, (function(n, t) {
                    n(t, 0, 0, i.Mb(1, "shortcut__key icon icon-", t.parent.context.$implicit, ""))
                }))
            }

            function Zi(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "span", [
                    ["class", "shortcut__combination"]
                ], null, null, null, null, null)), (n()(), i.cc(-1, null, ["+"]))], null, null)
            }

            function Vi(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 6, "div", [
                    ["class", "grid grid-center grid-middle"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, Fi)), i.Hb(2, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, Gi)), i.Hb(4, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, Zi)), i.Hb(6, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, !t.parent.parent.context.$implicit.isIcon || t.parent.parent.context.$implicit.isIcon && !l.icons.includes(t.context.$implicit)), n(t, 4, 0, t.parent.parent.context.$implicit.isIcon && l.icons.includes(t.context.$implicit)), n(t, 6, 0, t.parent.context.$implicit.length > 1 && t.context.index < t.parent.context.$implicit.length - 1)
                }), null)
            }

            function Ki(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 2, "span", [
                    ["class", "shortcut__combination"]
                ], null, null, null, null, null)), (n()(), i.cc(1, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i])], null, (function(n, t) {
                    n(t, 1, 0, i.dc(t, 1, 0, i.Ub(t, 2).transform("ch_or")))
                }))
            }

            function Yi(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 4, "div", [
                    ["class", "grid grid-center grid-middle"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, Vi)), i.Hb(2, 278528, null, 0, Y.l, [i.eb, i.Z, i.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, Ki)), i.Hb(4, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(n, t) {
                    n(t, 2, 0, t.context.$implicit), n(t, 4, 0, t.parent.context.$implicit.key.length > 1 && t.context.index < t.parent.context.$implicit.key.length - 1)
                }), null)
            }

            function qi(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 7, "div", [
                    ["class", "grid grid-left grid-middle shortcut"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 4, "div", [
                    ["class", "col grid grid-column shortcut__title"]
                ], null, null, null, null, null)), (n()(), i.cc(2, null, [" ", " "])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.xb(16777216, null, null, 1, null, Wi)), i.Hb(5, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, Yi)), i.Hb(7, 278528, null, 0, Y.l, [i.eb, i.Z, i.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(n, t) {
                    n(t, 5, 0, t.context.$implicit.isAvailable), n(t, 7, 0, t.context.$implicit.key)
                }), (function(n, t) {
                    n(t, 2, 0, i.dc(t, 2, 0, i.Ub(t, 3).transform(t.context.$implicit.title)))
                }))
            }

            function Xi(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 5, "div", [
                    ["class", "col grid grid-column"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 2, "div", [
                    ["class", "grid shortcuts-help-body__title"]
                ], null, null, null, null, null)), (n()(), i.cc(2, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.xb(16777216, null, null, 1, null, qi)), i.Hb(5, 278528, null, 0, Y.l, [i.eb, i.Z, i.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(n, t) {
                    n(t, 5, 0, t.context.$implicit.shortcuts)
                }), (function(n, t) {
                    n(t, 2, 0, i.dc(t, 2, 0, i.Ub(t, 3).transform(t.context.$implicit.title)))
                }))
            }

            function Ji(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 3, "div", [
                    ["class", "col grid shortcuts-help-body"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 2, "div", [
                    ["class", "grid shortcuts-help-body__header"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, Xi)), i.Hb(3, 278528, null, 0, Y.l, [i.eb, i.Z, i.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(n, t) {
                    n(t, 3, 0, t.component.columns)
                }), null)
            }
            i.Eb("grc-body-shortcuts-help", Ni, (function(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-body-shortcuts-help", [], null, null, null, Ji, Ri)), i.Hb(1, 114688, null, 0, Ni, [], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {}, {}, []);
            var Qi = l("AZLQ"),
                $i = [
                    [".shortcuts-help[_ngcontent-%COMP%]{position:relative;width:100%;height:100%}.shortcuts-help__cross-close[_ngcontent-%COMP%]{position:absolute;top:14px;right:0;z-index:99999;font-size:24px;cursor:pointer}.shortcuts-help--body-margin[_ngcontent-%COMP%]{margin-top:67px}.shortcuts-help[_ngcontent-%COMP%] > [_ngcontent-%COMP%]:last-child{width:100%;height:100%;padding:90px 0}"]
                ],
                no = i.Gb({
                    encapsulation: 0,
                    styles: $i,
                    data: {}
                });

            function to(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 5, "div", [
                    ["class", "grid grid-column shortcuts-help"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 0, "div", [
                    ["class", "shortcuts-help__cross-close icon icon-cancel"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.close.emit() && e);
                    return e
                }), null, null)), (n()(), i.Ib(2, 0, null, null, 1, "grc-header-shortcuts-help", [], null, null, null, Li, Di)), i.Hb(3, 114688, null, 0, Bi, [], null, null), (n()(), i.Ib(4, 0, null, null, 1, "grc-body-shortcuts-help", [], null, null, null, Ji, Ri)), i.Hb(5, 114688, null, 0, Ni, [], null, null)], (function(n, t) {
                    n(t, 3, 0), n(t, 5, 0)
                }), null)
            }
            var lo = i.Eb("grc-shortcuts-help", Qi.a, (function(n) {
                    return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-shortcuts-help", [], null, null, null, to, no)), i.Hb(1, 114688, null, 0, Qi.a, [], null, null)], (function(n, t) {
                        n(t, 1, 0)
                    }), null)
                }), {}, {
                    close: "close"
                }, []),
                eo = [
                    ["[_nghost-%COMP%]{position:absolute;top:0;left:0;z-index:99999;width:100%;height:100%}.waiting-screen[_ngcontent-%COMP%]{align-self:center;height:100%;font-size:36px;font-weight:700;color:#bdbdbd;text-align:center;text-transform:uppercase;background-color:#fafafa}.waiting-screen__processing[_ngcontent-%COMP%]{color:#fff;background-color:rgba(0,0,0,.8)}.waiting-screen--icon[_ngcontent-%COMP%]{margin-bottom:22px;font-size:60px}.waiting-screen--animate[_ngcontent-%COMP%]{margin-bottom:20px;-webkit-animation:1.2s linear infinite rotate-ring;animation:1.2s linear infinite rotate-ring}@-webkit-keyframes rotate-ring{0%{transform:rotate(0)}100%{transform:rotate(360deg)}}@keyframes rotate-ring{0%{transform:rotate(0)}100%{transform:rotate(360deg)}}"]
                ],
                io = i.Gb({
                    encapsulation: 0,
                    styles: eo,
                    data: {}
                });

            function oo(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "div", [], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 0, "img", [
                    ["alt", ""],
                    ["class", "waiting-screen--animate"],
                    ["src", "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAC4AAAAuCAMAAABgZ9sFAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAqUExURQAAAP///////////////////////////////////////////////////4a7yi8AAAANdFJOUwC07wpTiJzdzBtqPSzCC5LxAAABZElEQVRIx42WWRbDIAhFBTXitP/tNj3iVEXLl7FXAg+kUWo2HS3YsnwXUauTeYs556c8PO8SrRfh9AVm/PuU9nTAvMMzhl0ckPMezxmWiBJmGc+YRBoC+/IBBL7TsxLe7njtxCBbSq6XoEYZtoLNGfUNsxfYzM40HunGox6dW7k37OCendOpl6i7Z+fphKfuvigFx07tkC4H4xmPhdKctlMXcyyenWsg2cPqwVnzWXtgjdINT6x2CcrfcM8pliKpq5VCqarQxVhv9v5nMMixxxseOXaQL8Z6SYDLBDccuExxbH05U6wx4z9lNZxp7QY649Q6y+S7+5Fxv3NkjdwNXc5H4SZLDYAuo4AHAc03S+LrnIy/G7CJX8PqrM3NRR/Tpu3ogupgJjO8QZu+P73YU5/8EGLSOsUA/T+CvBDi1jZJWZneShZpD5N0d5oMg7lTM5kHRxaf67x6vyHcewbd+wWx/PgBSrMjPYgObLoAAAAASUVORK5CYII="]
                ], null, null, null, null, null))], null, null)
            }

            function ro(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 0, "div", [
                    ["class", "icon icon-canceled-events waiting-screen--icon"]
                ], null, null, null, null, null))], null, null)
            }

            function uo(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 10, "div", [
                    ["class", "grid grid-column grid-center waiting-screen"]
                ], null, null, null, null, null)), i.Zb(512, null, Y.x, Y.y, [i.A, i.B, i.o, i.P]), i.Hb(2, 278528, null, 0, Y.k, [Y.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), i.Xb(3, {
                    "waiting-screen__processing": 0
                }), (n()(), i.xb(16777216, null, null, 1, null, oo)), i.Hb(5, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, ro)), i.Hb(7, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.Ib(8, 0, null, null, 2, "div", [], null, null, null, null, null)), (n()(), i.cc(9, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i])], (function(n, t) {
                    var l = t.component,
                        e = n(t, 3, 0, l.isProcessing);
                    n(t, 2, 0, "grid grid-column grid-center waiting-screen", e), n(t, 5, 0, l.isProcessing), n(t, 7, 0, !l.isProcessing)
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 9, 0, i.dc(t, 9, 0, i.Ub(t, 10).transform(l.message)))
                }))
            }
            var so = i.Eb("grc-waiting-screen", ie.a, (function(n) {
                    return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-waiting-screen", [], null, null, null, uo, io)), i.Hb(1, 114688, null, 0, ie.a, [], null, null)], (function(n, t) {
                        n(t, 1, 0)
                    }), null)
                }), {
                    message: "message",
                    isProcessing: "isProcessing"
                }, {}, []),
                co = function() {
                    function n() {
                        this.isCashTicket = !1, this.statusTag = "ch_valid"
                    }
                    return n.prototype.ngOnInit = function() {
                        this.isRejected() || (this.gameIcon = this.getGameIcon(), this.stakeItemized = this.serverTicket._clData.getTotalStakeItemized(), this.expirationDate = this.serverTicket._clData.timeExpired, this.serverTicket._clData.isOpenOrPending() ? this.maxWinningItemized = this.serverTicket._clData.getTotalMaxWinningItemized() : (this.serverTicket._clData.isWon() || this.serverTicket._clData.isPaidout()) && (this.wonItemized = this.serverTicket._clData.getTotalWonItemized())), this.isCashTicket && (this.statusTag = this.isExpired ? "ch_ticket_status_expired" : this.statusTag, this.statusTag = this.isAlreadyPaidout ? "ch_ticket_status_paidout" : this.statusTag)
                    }, n.prototype.getTicketStatus = function() {
                        return this.isAlreadyPaidout ? this.isCashTicket ? "ch_already_paidout" : "sa_alreadypaidout_ticket" : "ch_ticket_status_" + this.serverTicket.status
                    }, n.prototype.getDescriptionTag = function() {
                        var n, t;
                        return (null === (n = this.serverTicket.details) || void 0 === n ? void 0 : n.events.length) > 0 && (null === (t = this.serverTicket.details) || void 0 === t ? void 0 : t.events[0]._clData.playlist.descriptionTag) || ""
                    }, n.prototype.isRejected = function() {
                        return this.serverTicket._clData.isRejected()
                    }, n.prototype.getGameIcon = function() {
                        var n = this.serverTicket.details.events.length > 0 && this.serverTicket.details.events[0]._clData.playlist;
                        if (!n) return this.serverTicket.gameType[0];
                        var t = n.filter;
                        if (t && t.isChFilter()) return t.competitionSubType;
                        if (t && t.isSnFilter()) {
                            var l = t.spinType === $.coreModel.SnFilter.SpinTypeEnum.EUROPEAN ? "" : "-" + t.spinType,
                                e = "";
                            return t.mode === $.coreModel.SnFilter.ModeEnum.DELUXE && (e = "-royale", l = l.slice(0, 3)), "" + this.serverTicket.gameType[0] + l + e
                        }
                        return Object(nn.a)(n) ? "color-color" : this.serverTicket.gameType[0]
                    }, n
                }(),
                ao = [
                    ['.ticket-info[_ngcontent-%COMP%]{min-width:780px;font-weight:400}.ticket-info__header[_ngcontent-%COMP%]{height:118px;text-transform:uppercase;background-color:#022c80}.ticket-info__header--highlight[_ngcontent-%COMP%]{background-color:#1967ff}.ticket-info__header-icon[_ngcontent-%COMP%]{margin-right:16px;font-size:54px;color:#fff}.ticket-info__header-info[_ngcontent-%COMP%]{margin-top:5px;font-size:40px;color:#fff;text-transform:uppercase}.ticket-info__header-subinfo[_ngcontent-%COMP%]{font-size:18px;color:rgba(255,255,255,.5)}.ticket-info__header--valid[_ngcontent-%COMP%]{background-color:#3f8080}.ticket-info__header--expired[_ngcontent-%COMP%]{background-color:#ff8140}.ticket-info__header--payout[_ngcontent-%COMP%]{background-color:#9e9e9e}.ticket-info__content[_ngcontent-%COMP%]{position:relative;padding:21px 88px 35px;background-color:#f0f0f0}.ticket-info__game-info[_ngcontent-%COMP%]{margin-left:-52px}.ticket-info__game-icon[_ngcontent-%COMP%]{font-size:40px}.ticket-info__game-name[_ngcontent-%COMP%]{margin-left:10px;font-size:32px;color:#253239;text-transform:uppercase}.ticket-info__paidout-warning[_ngcontent-%COMP%]{height:35px;padding:0 15px;margin-left:20px;font-size:20px;line-height:32px;color:#000;text-align:center;border-radius:12px}.ticket-info__paidout-warning--cashTicket[_ngcontent-%COMP%]{height:25px;padding:0 15px;font-size:15px;line-height:23px;color:#000;text-align:center;border-radius:12px;font-weight:700;margin-top:10px}.ticket-info__row[_ngcontent-%COMP%]{margin-top:16px}.ticket-info__row[_ngcontent-%COMP%]   .col[_ngcontent-%COMP%]{padding:0 8px}.ticket-info__info-label[_ngcontent-%COMP%]{font-size:16px;color:rgba(0,0,0,.6);text-transform:uppercase}.ticket-info__info-value[_ngcontent-%COMP%]{font-size:24px;color:rgba(0,0,0,.6)}.ticket-info__info-value--uppercase[_ngcontent-%COMP%]{text-transform:uppercase}.ticket-info__winnings-content[_ngcontent-%COMP%]{position:relative;padding:14px 52px 30px;background-color:#fafafa}.ticket-info__winnings-content--cashTicket[_ngcontent-%COMP%]{padding:21px 88px 35px}.ticket-info__winnings-content[_ngcontent-%COMP%]::before{position:absolute;bottom:0;left:0;display:block;width:100%;height:14px;content:"";background:radial-gradient(ellipse 38% 109% at 50% 0,rgba(0,0,0,.1) 0,rgba(0,0,0,0) 100%);background-repeat:no-repeat;background-size:100% 10px;transform:translateY(100%)}.ticket-info__winnings-label[_ngcontent-%COMP%]{font-size:16px;color:#000;text-transform:uppercase}.ticket-info__winnings-value[_ngcontent-%COMP%]{display:flex;align-items:center;font-size:30px;color:#000}.ticket-info__winnings-value--highlight[_ngcontent-%COMP%]{font-size:44px;font-weight:700;color:#618b31}.ticket-info__winnings-value--valid[_ngcontent-%COMP%]{color:#3f8080;font-weight:700;margin-top:8px}.ticket-info__winnings-value--expired[_ngcontent-%COMP%]{color:#ef3e44;font-weight:700;margin-top:8px}.ticket-info__divider[_ngcontent-%COMP%]{height:1px;margin:16px 0;background-color:#bfbfbf;border-width:.5px}.ticket-info__total-won[_ngcontent-%COMP%]{padding:0 8px}']
                ],
                po = i.Gb({
                    encapsulation: 0,
                    styles: ao,
                    data: {}
                });

            function bo(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 5, "div", [
                    ["class", "grid grid-middle ticket-info__game-info"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 1, "span", [], [
                    [8, "className", 0]
                ], null, null, null, null)), i.Yb(2, 1), (n()(), i.Ib(3, 0, null, null, 2, "span", [
                    ["class", "ticket-info__game-name"]
                ], null, null, null, null, null)), (n()(), i.cc(4, null, [" ", " "])), i.Wb(131072, s.j, [s.k, i.i])], null, (function(n, t) {
                    var l = t.component,
                        e = i.Mb(1, "\n                    game-icon\n                    game-icon-", i.dc(t, 1, 0, n(t, 2, 0, i.Ub(t.parent, 1), l.gameIcon)), "\n                    ticket-info__game-icon");
                    n(t, 1, 0, e), n(t, 4, 0, i.dc(t, 4, 0, i.Ub(t, 5).transform(l.getDescriptionTag())))
                }))
            }

            function ho(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "div", [
                    ["class", "ticket-info__info-value ticket-info__info-value--uppercase"]
                ], null, null, null, null, null)), (n()(), i.cc(1, null, [" ", " "]))], null, (function(n, t) {
                    n(t, 1, 0, t.component.serverTicket._clData.ticketType)
                }))
            }

            function go(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 2, "div", [
                    ["class", "ticket-info__info-value ticket-info__info-value--uppercase"]
                ], null, null, null, null, null)), (n()(), i.cc(1, null, [" ", " "])), i.Wb(131072, s.c, [s.k, i.i])], null, (function(n, t) {
                    var l = t.component;
                    n(t, 1, 0, i.dc(t, 1, 0, i.Ub(t, 2).transform(l.serverTicket.timeSend)))
                }))
            }

            function fo(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 7, "div", [
                    ["class", "col grid grid-column"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 2, "div", [
                    ["class", "ticket-info__info-label"]
                ], null, null, null, null, null)), (n()(), i.cc(2, null, ["", ":"])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.xb(16777216, null, null, 1, null, ho)), i.Hb(5, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, go)), i.Hb(7, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(n, t) {
                    var l = t.component;
                    n(t, 5, 0, !l.isCashTicket), n(t, 7, 0, l.isCashTicket)
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, i.dc(t, 2, 0, i.Ub(t, 3).transform(l.isCashTicket ? "ch_ticket_detail_date" : "ch_bet_type")))
                }))
            }

            function mo(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 6, "div", [
                    ["class", "col grid grid-column"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 2, "div", [
                    ["class", "ticket-info__info-label"]
                ], null, null, null, null, null)), (n()(), i.cc(2, null, [" ", ": "])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(4, 0, null, null, 2, "div", [
                    ["class", "ticket-info__info-value"]
                ], null, null, null, null, null)), (n()(), i.cc(5, null, [" ", " "])), i.Wb(131072, s.c, [s.k, i.i])], null, (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, i.dc(t, 2, 0, i.Ub(t, 3).transform(l.isCashTicket ? "ch_expiration_date" : "ch_ticket_detail_date"))), n(t, 5, 0, i.dc(t, 5, 0, i.Ub(t, 6).transform(l.isCashTicket ? l.expirationDate : l.serverTicket.timeSend)))
                }))
            }

            function _o(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 5, "div", [
                    ["class", "col grid grid-column"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 2, "div", [
                    ["class", "ticket-info__info-label"]
                ], null, null, null, null, null)), (n()(), i.cc(2, null, ["", ":"])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(4, 0, null, null, 1, "div", [
                    ["class", "ticket-info__info-value"]
                ], null, null, null, null, null)), (n()(), i.cc(5, null, ["", " - ", ""]))], null, (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, i.dc(t, 2, 0, i.Ub(t, 3).transform("ch_issued_by"))), n(t, 5, 0, l.serverTicket.unit.id, l.serverTicket.unit.name)
                }))
            }

            function vo(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 7, "div", [
                    ["class", "col grid grid-column"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 3, "div", [
                    ["class", "ticket-info__winnings-label"]
                ], null, null, null, null, null)), (n()(), i.cc(2, null, [" ", " (", "): "])), i.Wb(131072, s.j, [s.k, i.i]), i.Wb(131072, s.o, [s.k, i.i]), (n()(), i.Ib(5, 0, null, null, 2, "div", [
                    ["class", "ticket-info__winnings-value"]
                ], null, null, null, null, null)), (n()(), i.cc(6, null, [" ", " "])), i.Wb(131072, s.b, [s.k, i.i])], null, (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, i.dc(t, 2, 0, i.Ub(t, 3).transform("ch_stake_taxes")), i.dc(t, 2, 1, i.Ub(t, 4).transform(null == l.stakeItemized ? null : l.stakeItemized.taxesPercent))), n(t, 6, 0, i.dc(t, 6, 0, i.Ub(t, 7).transform(l.stakeItemized.taxesRounded)))
                }))
            }

            function yo(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 7, "div", [
                    ["class", "col grid grid-column"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 3, "div", [
                    ["class", "ticket-info__winnings-label"]
                ], null, null, null, null, null)), (n()(), i.cc(2, null, [" ", " (", "): "])), i.Wb(131072, s.j, [s.k, i.i]), i.Wb(131072, s.o, [s.k, i.i]), (n()(), i.Ib(5, 0, null, null, 2, "div", [
                    ["class", "ticket-info__winnings-value"]
                ], null, null, null, null, null)), (n()(), i.cc(6, null, [" ", " "])), i.Wb(131072, s.b, [s.k, i.i])], null, (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, i.dc(t, 2, 0, i.Ub(t, 3).transform("ch_total_payout_taxes")), i.dc(t, 2, 1, i.Ub(t, 4).transform(l.wonItemized.taxesPercent))), n(t, 6, 0, i.dc(t, 6, 0, i.Ub(t, 7).transform(l.wonItemized.taxesRounded)))
                }))
            }

            function Co(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 11, "div", [
                    ["class", "grid grid-3 ticket-info__row"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 6, "div", [
                    ["class", "col grid grid-column"]
                ], null, null, null, null, null)), (n()(), i.Ib(2, 0, null, null, 2, "div", [
                    ["class", "ticket-info__winnings-label"]
                ], null, null, null, null, null)), (n()(), i.cc(3, null, ["", ":"])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(5, 0, null, null, 2, "div", [
                    ["class", "ticket-info__winnings-value"]
                ], null, null, null, null, null)), (n()(), i.cc(6, null, [" ", " "])), i.Wb(131072, s.b, [s.k, i.i]), (n()(), i.xb(16777216, null, null, 1, null, vo)), i.Hb(9, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, yo)), i.Hb(11, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(n, t) {
                    var l = t.component;
                    n(t, 9, 0, l.stakeItemized && l.stakeItemized.taxesPercent && !l.isCashTicket), n(t, 11, 0, l.wonItemized && l.wonItemized.taxesPercent && l.wonItemized.taxesRounded && !l.isCashTicket)
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 3, 0, i.dc(t, 3, 0, i.Ub(t, 4).transform("ch_total_stake"))), n(t, 6, 0, i.dc(t, 6, 0, i.Ub(t, 7).transform(l.stakeItemized.netRounded)))
                }))
            }

            function ko(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 4, "div", [
                    ["class", "ticket-info__paidout-warning--cashTicket"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 0, "span", [
                    ["class", "icon icon-warning"]
                ], null, null, null, null, null)), (n()(), i.cc(2, null, [" ", " "])), i.Wb(131072, s.j, [s.k, i.i]), i.Yb(4, 1)], null, (function(n, t) {
                    var l = i.dc(t, 2, 0, n(t, 4, 0, i.Ub(t.parent.parent, 0), i.dc(t, 2, 0, i.Ub(t, 3).transform("ch_ticket_status_paidout"))));
                    n(t, 2, 0, l)
                }))
            }

            function xo(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 20, "div", [
                    ["class", "grid grid-2 ticket-info__row"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 6, "div", [
                    ["class", "col grid grid-column"]
                ], null, null, null, null, null)), (n()(), i.Ib(2, 0, null, null, 2, "div", [
                    ["class", "ticket-info__winnings-label"]
                ], null, null, null, null, null)), (n()(), i.cc(3, null, ["", ":"])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(5, 0, null, null, 2, "div", [
                    ["class", "ticket-info__winnings-value ticket-info__winnings-value--highlight"]
                ], null, null, null, null, null)), (n()(), i.cc(6, null, [" ", " "])), i.Wb(131072, s.b, [s.k, i.i]), (n()(), i.Ib(8, 0, null, null, 12, "div", [
                    ["class", "col grid grid-column"]
                ], null, null, null, null, null)), (n()(), i.Ib(9, 0, null, null, 2, "div", [
                    ["class", "ticket-info__winnings-label"]
                ], null, null, null, null, null)), (n()(), i.cc(10, null, ["", ":"])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(12, 0, null, null, 8, "div", [
                    ["class", "ticket-info__winnings-value"]
                ], null, null, null, null, null)), i.Zb(512, null, Y.x, Y.y, [i.A, i.B, i.o, i.P]), i.Hb(14, 278528, null, 0, Y.k, [Y.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), i.Xb(15, {
                    "ticket-info__winnings-value--valid": 0,
                    "ticket-info__winnings-value--expired": 1
                }), (n()(), i.cc(16, null, [" ", " "])), i.Wb(131072, s.j, [s.k, i.i]), i.Yb(18, 1), (n()(), i.xb(16777216, null, null, 1, null, ko)), i.Hb(20, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(n, t) {
                    var l = t.component,
                        e = n(t, 15, 0, !l.isAlreadyPaidout && !l.isExpired, l.isExpired);
                    n(t, 14, 0, "ticket-info__winnings-value", e), n(t, 20, 0, l.isAlreadyPaidout)
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 3, 0, i.dc(t, 3, 0, i.Ub(t, 4).transform("ch_credit_amount"))), n(t, 6, 0, i.dc(t, 6, 0, i.Ub(t, 7).transform(l.stakeItemized.netRounded))), n(t, 10, 0, i.dc(t, 10, 0, i.Ub(t, 11).transform("ch_status")));
                    var e = l.isAlreadyPaidout ? "" : i.dc(t, 16, 0, n(t, 18, 0, i.Ub(t.parent, 0), i.dc(t, 16, 0, i.Ub(t, 17).transform(l.statusTag))));
                    n(t, 16, 0, e)
                }))
            }

            function Io(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 14, "div", [
                    ["class", "grid grid-3 ticket-info__row"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 6, "div", [
                    ["class", "col grid grid-column"]
                ], null, null, null, null, null)), (n()(), i.Ib(2, 0, null, null, 2, "div", [
                    ["class", "ticket-info__winnings-label"]
                ], null, null, null, null, null)), (n()(), i.cc(3, null, ["", ":"])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(5, 0, null, null, 2, "div", [
                    ["class", "ticket-info__winnings-value"]
                ], null, null, null, null, null)), (n()(), i.cc(6, null, [" ", " "])), i.Wb(131072, s.b, [s.k, i.i]), (n()(), i.Ib(8, 0, null, null, 6, "div", [
                    ["class", "col grid grid-column"]
                ], null, null, null, null, null)), (n()(), i.Ib(9, 0, null, null, 2, "div", [
                    ["class", "ticket-info__winnings-label"]
                ], null, null, null, null, null)), (n()(), i.cc(10, null, ["", ":"])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(12, 0, null, null, 2, "div", [
                    ["class", "ticket-info__winnings-value"]
                ], null, null, null, null, null)), (n()(), i.cc(13, null, [" ", " "])), i.Wb(131072, s.b, [s.k, i.i])], null, (function(n, t) {
                    var l = t.component;
                    n(t, 3, 0, i.dc(t, 3, 0, i.Ub(t, 4).transform("ch_maximum_winning"))), n(t, 6, 0, i.dc(t, 6, 0, i.Ub(t, 7).transform(l.maxWinningItemized.netRounded))), n(t, 10, 0, i.dc(t, 10, 0, i.Ub(t, 11).transform("ch_potential_winning"))), n(t, 13, 0, i.dc(t, 13, 0, i.Ub(t, 14).transform(l.maxWinningItemized.totalMaxWinning)))
                }))
            }

            function So(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 6, "div", [
                    ["class", "col grid grid-column"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 2, "div", [
                    ["class", "ticket-info__winnings-label"]
                ], null, null, null, null, null)), (n()(), i.cc(2, null, ["", ":"])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(4, 0, null, null, 2, "div", [
                    ["class", "ticket-info__winnings-value"]
                ], null, null, null, null, null)), (n()(), i.cc(5, null, [" ", " "])), i.Wb(131072, s.b, [s.k, i.i])], null, (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, i.dc(t, 2, 0, i.Ub(t, 3).transform("ch_jackpot_won_text"))), n(t, 5, 0, i.dc(t, 5, 0, i.Ub(t, 6).transform(l.wonItemized.grossJackpot)))
                }))
            }

            function wo(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 4, "div", [
                    ["class", "ticket-info__paidout-warning"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 0, "span", [
                    ["class", "icon icon-warning"]
                ], null, null, null, null, null)), (n()(), i.cc(2, null, [" ", " "])), i.Wb(131072, s.j, [s.k, i.i]), i.Yb(4, 1)], null, (function(n, t) {
                    var l = i.dc(t, 2, 0, n(t, 4, 0, i.Ub(t.parent.parent.parent, 0), i.dc(t, 2, 0, i.Ub(t, 3).transform("ch_ticket_status_paidout"))));
                    n(t, 2, 0, l)
                }))
            }

            function Oo(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 8, "div", [
                    ["class", "ticket-info__total-won"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 2, "div", [
                    ["class", "ticket-info__winnings-label"]
                ], null, null, null, null, null)), (n()(), i.cc(2, null, [" ", " "])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(4, 0, null, null, 4, "div", [
                    ["class", "ticket-info__winnings-value ticket-info__winnings-value--highlight"]
                ], null, null, null, null, null)), (n()(), i.cc(5, null, [" ", " "])), i.Wb(131072, s.b, [s.k, i.i]), (n()(), i.xb(16777216, null, null, 1, null, wo)), i.Hb(8, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(n, t) {
                    n(t, 8, 0, t.component.isAlreadyPaidout)
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, i.dc(t, 2, 0, i.Ub(t, 3).transform("ch_total_won"))), n(t, 5, 0, i.dc(t, 5, 0, i.Ub(t, 6).transform(l.wonItemized.netRounded)))
                }))
            }

            function Po(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 20, null, null, null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 16, "div", [
                    ["class", "grid grid-3 ticket-info__row"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, So)), i.Hb(3, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.Ib(4, 0, null, null, 6, "div", [
                    ["class", "col grid grid-column"]
                ], null, null, null, null, null)), (n()(), i.Ib(5, 0, null, null, 2, "div", [
                    ["class", "ticket-info__winnings-label"]
                ], null, null, null, null, null)), (n()(), i.cc(6, null, ["", ":"])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(8, 0, null, null, 2, "div", [
                    ["class", "ticket-info__winnings-value"]
                ], null, null, null, null, null)), (n()(), i.cc(9, null, [" ", " "])), i.Wb(131072, s.b, [s.k, i.i]), (n()(), i.Ib(11, 0, null, null, 6, "div", [
                    ["class", "col grid grid-column"]
                ], null, null, null, null, null)), (n()(), i.Ib(12, 0, null, null, 2, "div", [
                    ["class", "ticket-info__winnings-label"]
                ], null, null, null, null, null)), (n()(), i.cc(13, null, ["", ":"])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(15, 0, null, null, 2, "div", [
                    ["class", "ticket-info__winnings-value"]
                ], null, null, null, null, null)), (n()(), i.cc(16, null, [" ", " "])), i.Wb(131072, s.b, [s.k, i.i]), (n()(), i.Ib(18, 0, null, null, 0, "div", [
                    ["class", "ticket-info__divider"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, Oo)), i.Hb(20, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(0, null, null, 0))], (function(n, t) {
                    var l = t.component;
                    n(t, 3, 0, l.wonItemized.grossJackpot), n(t, 20, 0, !l.isCashTicket)
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 6, 0, i.dc(t, 6, 0, i.Ub(t, 7).transform("ch_won_amount"))), n(t, 9, 0, i.dc(t, 9, 0, i.Ub(t, 10).transform(l.wonItemized.grossAmount))), n(t, 13, 0, i.dc(t, 13, 0, i.Ub(t, 14).transform("ch_net_amount"))), n(t, 16, 0, i.dc(t, 16, 0, i.Ub(t, 17).transform(l.wonItemized.netAmountRounded)))
                }))
            }

            function Mo(n) {
                return i.ec(2, [i.Wb(0, Y.u, []), i.Wb(0, Y.j, []), (n()(), i.Ib(2, 0, null, null, 47, "div", [
                    ["class", "ticket-info"]
                ], null, null, null, null, null)), (n()(), i.Ib(3, 0, null, null, 17, "div", [
                    ["class", "grid grid-center grid-middle ticket-info__header"]
                ], null, null, null, null, null)), i.Zb(512, null, Y.x, Y.y, [i.A, i.B, i.o, i.P]), i.Hb(5, 278528, null, 0, Y.k, [Y.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), i.Xb(6, {
                    "ticket-info__header--highlight": 0,
                    "ticket-info__header--alreadyPaidout": 1,
                    "ticket-info__header--valid": 2,
                    "ticket-info__header--expired": 3,
                    "ticket-info__header--payout": 4
                }), (n()(), i.Ib(7, 0, null, null, 1, "div", [
                    ["class", "ticket-info__header-icon"]
                ], null, null, null, null, null)), (n()(), i.Ib(8, 0, null, null, 0, "span", [
                    ["class", "icon icon-ticket"]
                ], null, null, null, null, null)), (n()(), i.Ib(9, 0, null, null, 11, "div", [
                    ["class", "grid grid-column"]
                ], null, null, null, null, null)), (n()(), i.Ib(10, 0, null, null, 2, "span", [
                    ["class", "ticket-info__header-subinfo"]
                ], null, null, null, null, null)), (n()(), i.cc(11, null, [" ", " "])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(13, 0, null, null, 7, "span", [
                    ["class", "ticket-info__header-info"]
                ], null, null, null, null, null)), (n()(), i.cc(14, null, [" ", " ", " "])), i.Yb(15, 1), i.Wb(131072, s.j, [s.k, i.i]), i.Yb(17, 1), i.Yb(18, 1), i.Wb(131072, s.j, [s.k, i.i]), i.Yb(20, 1), (n()(), i.Ib(21, 0, null, null, 16, "div", [
                    ["class", "ticket-info__content"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, bo)), i.Hb(23, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.Ib(24, 0, null, null, 8, "div", [
                    ["class", "grid grid-2 ticket-info__row"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, fo)), i.Hb(26, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.Ib(27, 0, null, null, 5, "div", [
                    ["class", "col grid grid-column"]
                ], null, null, null, null, null)), (n()(), i.Ib(28, 0, null, null, 2, "div", [
                    ["class", "ticket-info__info-label"]
                ], null, null, null, null, null)), (n()(), i.cc(29, null, ["", ":"])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(31, 0, null, null, 1, "div", [
                    ["class", "ticket-info__info-value ticket-info__info-value--uppercase"]
                ], null, null, null, null, null)), (n()(), i.cc(32, null, [" ", " "])), (n()(), i.Ib(33, 0, null, null, 4, "div", [
                    ["class", "grid grid-2 ticket-info__row"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, mo)), i.Hb(35, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, _o)), i.Hb(37, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.Ib(38, 0, null, null, 11, "div", [
                    ["class", "ticket-info__winnings-content"]
                ], null, null, null, null, null)), i.Zb(512, null, Y.x, Y.y, [i.A, i.B, i.o, i.P]), i.Hb(40, 278528, null, 0, Y.k, [Y.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), i.Xb(41, {
                    "ticket-info__winnings-content--cashTicket": 0
                }), (n()(), i.xb(16777216, null, null, 1, null, Co)), i.Hb(43, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, xo)), i.Hb(45, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, Io)), i.Hb(47, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, Po)), i.Hb(49, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(n, t) {
                    var l = t.component,
                        e = n(t, 6, 0, !l.isCashTicket && l.wonItemized, !l.isCashTicket && l.isAlreadyPaidout, l.isCashTicket && !l.isAlreadyPaidout && !l.isExpired, l.isCashTicket && l.isExpired, l.isCashTicket && l.isAlreadyPaidout);
                    n(t, 5, 0, "grid grid-center grid-middle ticket-info__header", e), n(t, 23, 0, !l.isCashTicket), n(t, 26, 0, "NONE" !== l.serverTicket._clData.ticketType), n(t, 35, 0, !(l.isCashTicket && !l.expirationDate) && l.serverTicket.timeSend), n(t, 37, 0, l.serverTicket.unit);
                    var i = n(t, 41, 0, l.isCashTicket);
                    n(t, 40, 0, "ticket-info__winnings-content", i), n(t, 43, 0, !l.isCashTicket && l.stakeItemized && l.stakeItemized.netRounded), n(t, 45, 0, l.isCashTicket), n(t, 47, 0, l.maxWinningItemized && !l.isCashTicket), n(t, 49, 0, l.wonItemized && !l.isCashTicket)
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 11, 0, i.dc(t, 11, 0, i.Ub(t, 12).transform("ch_status")));
                    var e = i.dc(t, 14, 0, n(t, 17, 0, i.Ub(t, 0), i.dc(t, 14, 0, i.Ub(t, 16).transform(l.isCashTicket ? "ch_cash_ticket" : i.dc(t, 14, 0, n(t, 15, 0, i.Ub(t, 1), l.getTicketStatus())))))),
                        o = i.dc(t, 14, 1, n(t, 20, 0, i.Ub(t, 0), i.dc(t, 14, 1, i.Ub(t, 19).transform(l.isCashTicket && (l.isExpired || l.isAlreadyPaidout) ? i.dc(t, 14, 1, n(t, 18, 0, i.Ub(t, 1), l.getTicketStatus())) : ""))));
                    n(t, 14, 0, e, o), n(t, 29, 0, i.dc(t, 29, 0, i.Ub(t, 30).transform("ch_ticket_id"))), n(t, 32, 0, l.serverTicket.ticketId)
                }))
            }
            i.Eb("grc-ticket-info", co, (function(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-ticket-info", [], null, null, null, Mo, po)), i.Hb(1, 114688, null, 0, co, [], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                serverTicket: "serverTicket",
                isAlreadyPaidout: "isAlreadyPaidout",
                isExpired: "isExpired",
                isCashTicket: "isCashTicket"
            }, {}, []);
            var To = function() {
                    function n() {
                        this.isCashTicket = !1, this.close = new i.q, this.confirm = new i.q
                    }
                    return n.prototype.ngOnInit = function() {}, n
                }(),
                jo = [
                    [".ticket-footer[_ngcontent-%COMP%]{padding:24px}.ticket-footer__text[_ngcontent-%COMP%]{font-size:28px;color:#000}.ticket-footer__icon[_ngcontent-%COMP%]{margin-right:13px;font-size:36px}.ticket-footer__buttons--cashTicket[_ngcontent-%COMP%]{width:100%;justify-content:space-around}.ticket-footer__button[_ngcontent-%COMP%]{display:inline-block;min-width:142px;padding:8px;font-size:20px;text-align:center;text-transform:uppercase;cursor:pointer;background-color:#fff;border:2px solid #000}.ticket-footer__button--primary[_ngcontent-%COMP%]{color:#fff;background-color:#618b31;border-color:#618b31;border-radius:2px;box-shadow:0 2px 4px 0 rgba(0,0,0,.14),0 3px 4px 0 rgba(0,0,0,.12),0 1px 5px 0 rgba(0,0,0,.2)}.ticket-footer__button[_ngcontent-%COMP%] + .ticket-footer__button[_ngcontent-%COMP%]{margin-left:12px}"]
                ],
                Eo = i.Gb({
                    encapsulation: 0,
                    styles: jo,
                    data: {}
                });

            function Uo(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 3, "div", [
                    ["class", "grid grid-middle ticket-footer__text"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 0, "span", [], [
                    [8, "className", 0]
                ], null, null, null, null)), (n()(), i.Ib(2, 0, null, null, 1, "span", [], null, null, null, null, null)), i.Tb(null, 0)], null, (function(n, t) {
                    var l = t.component;
                    n(t, 1, 0, i.Mb(1, "icon ", l.iconClass, " ticket-footer__icon"))
                }))
            }

            function Ao(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 6, "div", [
                    ["class", "ticket-footer__buttons"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 2, "div", [
                    ["class", "ticket-footer__button"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.close.emit() && e);
                    return e
                }), null, null)), (n()(), i.cc(2, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(4, 0, null, null, 2, "div", [
                    ["class", "ticket-footer__button ticket-footer__button--primary"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.confirm.emit() && e);
                    return e
                }), null, null)), (n()(), i.cc(5, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i])], null, (function(n, t) {
                    n(t, 2, 0, i.dc(t, 2, 0, i.Ub(t, 3).transform("ch_no"))), n(t, 5, 0, i.dc(t, 5, 0, i.Ub(t, 6).transform("ch_yes")))
                }))
            }

            function Bo(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 6, "div", [
                    ["class", "ticket-footer__buttons--cashTicket grid grid-middle grid-2"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 2, "div", [
                    ["class", "ticket-footer__button ticket-footer__button--primary grid grid-column"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.confirm.emit() && e);
                    return e
                }), null, null)), (n()(), i.cc(2, null, [" ", " "])), i.Wb(131072, s.j, [s.k, i.i]), (n()(), i.Ib(4, 0, null, null, 2, "div", [
                    ["class", "ticket-footer__button grid grid-column"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.close.emit() && e);
                    return e
                }), null, null)), (n()(), i.cc(5, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i])], null, (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, i.dc(t, 2, 0, i.Ub(t, 3).transform(l.isCashTicket ? "tk_pay" : "ch_yes"))), n(t, 5, 0, i.dc(t, 5, 0, i.Ub(t, 6).transform("ch_close")))
                }))
            }

            function Ho(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 6, "div", [
                    ["class", "grid grid-middle grid-space-between ticket-footer"]
                ], null, null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, Uo)), i.Hb(2, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, Ao)), i.Hb(4, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), i.xb(16777216, null, null, 1, null, Bo)), i.Hb(6, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, !l.isCashTicket), n(t, 4, 0, !l.isCashTicket), n(t, 6, 0, l.isCashTicket)
                }), null)
            }

            function Do(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 3, "div", [
                    ["class", "grid grid-middle grid-center ticket-footer"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 2, "div", [
                    ["class", "ticket-footer__button"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.close.emit() && e);
                    return e
                }), null, null)), (n()(), i.cc(2, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i])], null, (function(n, t) {
                    n(t, 2, 0, i.dc(t, 2, 0, i.Ub(t, 3).transform("ch_close")))
                }))
            }

            function Lo(n) {
                return i.ec(2, [(n()(), i.xb(16777216, null, null, 1, null, Ho)), i.Hb(1, 16384, null, 0, Y.m, [i.eb, i.Z], {
                    ngIf: [0, "ngIf"],
                    ngIfElse: [1, "ngIfElse"]
                }, null), (n()(), i.xb(0, [
                    ["closeTemplate", 2]
                ], null, 0, null, Do))], (function(n, t) {
                    n(t, 1, 0, t.component.hasConfirm, i.Ub(t, 2))
                }), null)
            }
            i.Eb("grc-ticket-footer", To, (function(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-ticket-footer", [], null, null, null, Lo, Eo)), i.Hb(1, 114688, null, 0, To, [], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                iconClass: "iconClass",
                hasConfirm: "hasConfirm",
                isCashTicket: "isCashTicket"
            }, {
                close: "close",
                confirm: "confirm"
            }, ["*"]);
            var No = l("SLOH"),
                zo = [
                    [".cancel-confirm-modal[_ngcontent-%COMP%]{background-color:#fafafa}"]
                ],
                Ro = i.Gb({
                    encapsulation: 0,
                    styles: zo,
                    data: {}
                });

            function Wo(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 6, "div", [
                    ["class", "cancel-confirm-modal"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 1, "grc-ticket-info", [], null, null, null, Mo, po)), i.Hb(2, 114688, null, 0, co, [], {
                    serverTicket: [0, "serverTicket"]
                }, null), (n()(), i.Ib(3, 0, null, null, 3, "grc-ticket-footer", [
                    ["iconClass", "icon-print-ticket"]
                ], null, [
                    [null, "close"],
                    [null, "confirm"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "close" === t && (e = !1 !== i.close() && e);
                    "confirm" === t && (e = !1 !== i.confirm() && e);
                    return e
                }), Lo, Eo)), i.Hb(4, 114688, null, 0, To, [], {
                    iconClass: [0, "iconClass"],
                    hasConfirm: [1, "hasConfirm"]
                }, {
                    close: "close",
                    confirm: "confirm"
                }), (n()(), i.cc(5, 0, [" ", " "])), i.Wb(131072, s.j, [s.k, i.i])], (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, l.serverTicket);
                    n(t, 4, 0, "icon-print-ticket", l.hasConfirm)
                }), (function(n, t) {
                    n(t, 5, 0, i.dc(t, 5, 0, i.Ub(t, 6).transform("ch_cancel_ticket")))
                }))
            }
            var Fo = i.Eb("cancel-confirm-modal", No.a, (function(n) {
                    return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "cancel-confirm-modal", [], null, null, null, Wo, Ro)), i.Hb(1, 114688, null, 0, No.a, [$n.a], null, null)], (function(n, t) {
                        n(t, 1, 0)
                    }), null)
                }), {
                    serverTicket: "serverTicket",
                    modalId: "modalId",
                    confirmed: "confirmed",
                    hasConfirm: "hasConfirm",
                    isAlreadyPaidout: "isAlreadyPaidout",
                    confirmOnClose: "confirmOnClose",
                    isCashTicket: "isCashTicket",
                    isExpired: "isExpired"
                }, {}, []),
                Go = l("lBSr"),
                Zo = [
                    [".cancel-print-confirm-modal[_ngcontent-%COMP%]{background-color:#fafafa}"]
                ],
                Vo = i.Gb({
                    encapsulation: 0,
                    styles: Zo,
                    data: {}
                });

            function Ko(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 6, "div", [
                    ["class", "cancel-print-confirm-modal"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 1, "grc-ticket-info", [], null, null, null, Mo, po)), i.Hb(2, 114688, null, 0, co, [], {
                    serverTicket: [0, "serverTicket"],
                    isAlreadyPaidout: [1, "isAlreadyPaidout"],
                    isExpired: [2, "isExpired"],
                    isCashTicket: [3, "isCashTicket"]
                }, null), (n()(), i.Ib(3, 0, null, null, 3, "grc-ticket-footer", [
                    ["iconClass", "icon-printer"]
                ], null, [
                    [null, "close"],
                    [null, "confirm"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "close" === t && (e = !1 !== i.close() && e);
                    "confirm" === t && (e = !1 !== i.confirm() && e);
                    return e
                }), Lo, Eo)), i.Hb(4, 114688, null, 0, To, [], {
                    iconClass: [0, "iconClass"],
                    hasConfirm: [1, "hasConfirm"]
                }, {
                    close: "close",
                    confirm: "confirm"
                }), (n()(), i.cc(5, 0, [" ", " "])), i.Wb(131072, s.j, [s.k, i.i])], (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, l.serverTicket, l.isAlreadyPaidout, l.isExpired, l.isCashTicket);
                    n(t, 4, 0, "icon-printer", l.hasConfirm)
                }), (function(n, t) {
                    n(t, 5, 0, i.dc(t, 5, 0, i.Ub(t, 6).transform("ch_print_ticket_question")))
                }))
            }
            var Yo = i.Eb("ticket-info-modal", Go.a, (function(n) {
                    return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "ticket-info-modal", [], null, null, null, Ko, Vo)), i.Hb(1, 114688, null, 0, Go.a, [$n.a], null, null)], (function(n, t) {
                        n(t, 1, 0)
                    }), null)
                }), {
                    serverTicket: "serverTicket",
                    modalId: "modalId",
                    confirmed: "confirmed",
                    hasConfirm: "hasConfirm",
                    isAlreadyPaidout: "isAlreadyPaidout",
                    confirmOnClose: "confirmOnClose",
                    isCashTicket: "isCashTicket",
                    isExpired: "isExpired"
                }, {}, []),
                qo = l("/4m3"),
                Xo = [
                    [".rebet-confirm-modal[_ngcontent-%COMP%]{background-color:#fafafa}"]
                ],
                Jo = i.Gb({
                    encapsulation: 0,
                    styles: Xo,
                    data: {}
                });

            function Qo(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 6, "div", [
                    ["class", "rebet-confirm-modal"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 1, "grc-ticket-info", [], null, null, null, Mo, po)), i.Hb(2, 114688, null, 0, co, [], {
                    serverTicket: [0, "serverTicket"]
                }, null), (n()(), i.Ib(3, 0, null, null, 3, "grc-ticket-footer", [
                    ["iconClass", "icon-print-ticket"]
                ], null, [
                    [null, "close"],
                    [null, "confirm"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "close" === t && (e = !1 !== i.close() && e);
                    "confirm" === t && (e = !1 !== i.confirm() && e);
                    return e
                }), Lo, Eo)), i.Hb(4, 114688, null, 0, To, [], {
                    iconClass: [0, "iconClass"],
                    hasConfirm: [1, "hasConfirm"]
                }, {
                    close: "close",
                    confirm: "confirm"
                }), (n()(), i.cc(5, 0, [" ", " "])), i.Wb(131072, s.j, [s.k, i.i])], (function(n, t) {
                    n(t, 2, 0, t.component.serverTicket);
                    n(t, 4, 0, "icon-print-ticket", !0)
                }), (function(n, t) {
                    n(t, 5, 0, i.dc(t, 5, 0, i.Ub(t, 6).transform("ch_rebet_ticket_question")))
                }))
            }
            var $o = i.Eb("rebet-confirm-modal", qo.a, (function(n) {
                    return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "rebet-confirm-modal", [], null, null, null, Qo, Jo)), i.Hb(1, 114688, null, 0, qo.a, [$n.a], null, null)], (function(n, t) {
                        n(t, 1, 0)
                    }), null)
                }), {
                    serverTicket: "serverTicket",
                    modalId: "modalId",
                    confirmed: "confirmed",
                    hasConfirm: "hasConfirm",
                    isAlreadyPaidout: "isAlreadyPaidout",
                    confirmOnClose: "confirmOnClose",
                    isCashTicket: "isCashTicket",
                    isExpired: "isExpired"
                }, {}, []),
                nr = l("zAiC"),
                tr = [
                    [".preticket-confirm-modal[_ngcontent-%COMP%]{background-color:#fafafa}"]
                ],
                lr = i.Gb({
                    encapsulation: 0,
                    styles: tr,
                    data: {}
                });

            function er(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 6, "div", [
                    ["class", "preticket-confirm-modal"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 1, "grc-ticket-info", [], null, null, null, Mo, po)), i.Hb(2, 114688, null, 0, co, [], {
                    serverTicket: [0, "serverTicket"]
                }, null), (n()(), i.Ib(3, 0, null, null, 3, "grc-ticket-footer", [
                    ["iconClass", "icon-print-ticket"]
                ], null, [
                    [null, "close"],
                    [null, "confirm"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "close" === t && (e = !1 !== i.close() && e);
                    "confirm" === t && (e = !1 !== i.confirm() && e);
                    return e
                }), Lo, Eo)), i.Hb(4, 114688, null, 0, To, [], {
                    iconClass: [0, "iconClass"],
                    hasConfirm: [1, "hasConfirm"]
                }, {
                    close: "close",
                    confirm: "confirm"
                }), (n()(), i.cc(5, 0, [" ", " "])), i.Wb(131072, s.j, [s.k, i.i])], (function(n, t) {
                    n(t, 2, 0, t.component.serverTicket);
                    n(t, 4, 0, "icon-print-ticket", !0)
                }), (function(n, t) {
                    n(t, 5, 0, i.dc(t, 5, 0, i.Ub(t, 6).transform("ch_preticket_validate")))
                }))
            }
            var ir = i.Eb("preticket-confirm-modal", nr.a, (function(n) {
                    return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "preticket-confirm-modal", [], null, null, null, er, lr)), i.Hb(1, 114688, null, 0, nr.a, [$n.a], null, null)], (function(n, t) {
                        n(t, 1, 0)
                    }), null)
                }), {
                    serverTicket: "serverTicket",
                    modalId: "modalId",
                    confirmed: "confirmed",
                    hasConfirm: "hasConfirm",
                    isAlreadyPaidout: "isAlreadyPaidout",
                    confirmOnClose: "confirmOnClose",
                    isCashTicket: "isCashTicket",
                    isExpired: "isExpired"
                }, {}, []),
                or = l("lwRT"),
                rr = [
                    [".ticket-cash-modal[_ngcontent-%COMP%]{background-color:#fafafa}"]
                ],
                ur = i.Gb({
                    encapsulation: 0,
                    styles: rr,
                    data: {}
                });

            function sr(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 4, "div", [
                    ["class", "ticket-cash-modal"]
                ], null, null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 1, "grc-ticket-info", [], null, null, null, Mo, po)), i.Hb(2, 114688, null, 0, co, [], {
                    serverTicket: [0, "serverTicket"],
                    isAlreadyPaidout: [1, "isAlreadyPaidout"],
                    isExpired: [2, "isExpired"],
                    isCashTicket: [3, "isCashTicket"]
                }, null), (n()(), i.Ib(3, 0, null, null, 1, "grc-ticket-footer", [
                    ["iconClass", "icon-print-ticket"]
                ], null, [
                    [null, "close"],
                    [null, "confirm"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "close" === t && (e = !1 !== i.close() && e);
                    "confirm" === t && (e = !1 !== i.confirm() && e);
                    return e
                }), Lo, Eo)), i.Hb(4, 114688, null, 0, To, [], {
                    iconClass: [0, "iconClass"],
                    hasConfirm: [1, "hasConfirm"],
                    isCashTicket: [2, "isCashTicket"]
                }, {
                    close: "close",
                    confirm: "confirm"
                })], (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, l.serverTicket, l.isAlreadyPaidout, l.isExpired, !0);
                    n(t, 4, 0, "icon-print-ticket", l.hasConfirm, !0)
                }), null)
            }
            var cr = i.Eb("ticket-cash-modal", or.a, (function(n) {
                    return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "ticket-cash-modal", [], null, null, null, sr, ur)), i.Hb(1, 114688, null, 0, or.a, [$n.a], null, null)], (function(n, t) {
                        n(t, 1, 0)
                    }), null)
                }), {
                    serverTicket: "serverTicket",
                    modalId: "modalId",
                    confirmed: "confirmed",
                    hasConfirm: "hasConfirm",
                    isAlreadyPaidout: "isAlreadyPaidout",
                    confirmOnClose: "confirmOnClose",
                    isCashTicket: "isCashTicket",
                    isExpired: "isExpired"
                }, {}, []),
                ar = l("HQhj"),
                dr = [
                    ["[_nghost-%COMP%]{display:block;opacity:1}.notification[_ngcontent-%COMP%]{width:100%;padding:10px}.notification__content[_ngcontent-%COMP%]{font-size:19px;text-align:center}.notification__close[_ngcontent-%COMP%]{text-decoration:underline;text-transform:uppercase;cursor:pointer}.notification--success[_ngcontent-%COMP%]{color:#fff;background-color:#618b31}.notification--warning[_ngcontent-%COMP%]{color:#fff;background-color:#db8727}.notification--info[_ngcontent-%COMP%]{color:#fff;background-color:#428bb8}.notification--danger[_ngcontent-%COMP%]{color:#fff;background-color:#b12828}"]
                ],
                pr = i.Gb({
                    encapsulation: 0,
                    styles: dr,
                    data: {}
                });

            function br(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 10, "div", [
                    ["class", "grid notification"]
                ], null, null, null, null, null)), i.Zb(512, null, Y.x, Y.y, [i.A, i.B, i.o, i.P]), i.Hb(2, 278528, null, 0, Y.k, [Y.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), i.Xb(3, {
                    "notification--success": 0,
                    "notification--warning": 1,
                    "notification--info": 2,
                    "notification--danger": 3
                }), (n()(), i.Ib(4, 0, null, null, 6, "div", [
                    ["class", "col notification__content"]
                ], null, null, null, null, null)), (n()(), i.Ib(5, 0, null, null, 0, "span", [], [
                    [8, "innerHTML", 1]
                ], null, null, null, null)), (n()(), i.Ib(6, 0, null, null, 1, "span", [], null, null, null, null, null)), (n()(), i.cc(-1, null, [" - "])), (n()(), i.Ib(8, 0, null, null, 2, "span", [
                    ["class", "notification__close"]
                ], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        i = n.component;
                    "click" === t && (e = !1 !== i.close.emit() && e);
                    return e
                }), null, null)), (n()(), i.cc(9, null, ["", ""])), i.Wb(131072, s.j, [s.k, i.i])], (function(n, t) {
                    var l = t.component,
                        e = n(t, 3, 0, l.isSuccess(), l.isWarning(), l.isInfo(), l.isDanger());
                    n(t, 2, 0, "grid notification", e)
                }), (function(n, t) {
                    n(t, 5, 0, t.component.content), n(t, 9, 0, i.dc(t, 9, 0, i.Ub(t, 10).transform("ch_dismiss")))
                }))
            }
            i.Eb("grc-notification", ar.a, (function(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-notification", [], null, [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0;
                    "click" === t && (e = !1 !== i.Ub(n, 1).onClick() && e);
                    return e
                }), br, pr)), i.Hb(1, 245760, null, 0, ar.a, [], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                content: "content",
                type: "type",
                duration: "duration",
                closeOnClick: "closeOnClick"
            }, {
                close: "close"
            }, []);
            var hr = function() {
                    function n(n, t) {
                        this.cd = n, this.notificationsService = t, this.notifications = []
                    }
                    return n.prototype.ngOnInit = function() {
                        this.configuration = this.notificationsService.getConfiguration(), this.notificationsService.register(this)
                    }, n.prototype.onClose = function(n) {
                        var t = this.notifications.splice(n, 1)[0];
                        this.notificationsService.close(t.id), this.cd.markForCheck()
                    }, n.prototype.addNotification = function(n) {
                        this.notifications.length > 0 && this.onClose(0), this.notifications.push(n), this.cd.markForCheck()
                    }, n
                }(),
                gr = [
                    ["[_nghost-%COMP%]{position:fixed;top:0;right:0;left:0;z-index:99999}.notification-item[_ngcontent-%COMP%]{position:absolute;top:0;width:100%}"]
                ],
                fr = i.Gb({
                    encapsulation: 0,
                    styles: gr,
                    data: {
                        animation: [{
                            type: 7,
                            name: "listAnimation",
                            definitions: [{
                                type: 1,
                                expr: "* => *",
                                animation: [{
                                    type: 11,
                                    selector: ":enter",
                                    animation: {
                                        type: 6,
                                        styles: {
                                            transform: "translateY(-100%)"
                                        },
                                        offset: null
                                    },
                                    options: {
                                        optional: !0
                                    }
                                }, {
                                    type: 11,
                                    selector: ":leave",
                                    animation: {
                                        type: 6,
                                        styles: {
                                            transform: "translateX(0%)"
                                        },
                                        offset: null
                                    },
                                    options: {
                                        optional: !0
                                    }
                                }, {
                                    type: 11,
                                    selector: ":enter",
                                    animation: {
                                        type: 12,
                                        timings: "300ms",
                                        animation: [{
                                            type: 4,
                                            styles: {
                                                type: 6,
                                                styles: {
                                                    transform: "translateY(0%)"
                                                },
                                                offset: null
                                            },
                                            timings: 150
                                        }]
                                    },
                                    options: {
                                        optional: !0
                                    }
                                }, {
                                    type: 11,
                                    selector: ":leave",
                                    animation: {
                                        type: 12,
                                        timings: "300ms",
                                        animation: [{
                                            type: 4,
                                            styles: {
                                                type: 6,
                                                styles: {
                                                    transform: "translateY(-100%)"
                                                },
                                                offset: null
                                            },
                                            timings: 150
                                        }]
                                    },
                                    options: {
                                        optional: !0
                                    }
                                }],
                                options: null
                            }],
                            options: {}
                        }]
                    }
                });

            function mr(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 2, "div", [
                    ["class", "notification-item"]
                ], [
                    [4, "zIndex", null]
                ], null, null, null, null)), (n()(), i.Ib(1, 0, null, null, 1, "grc-notification", [], null, [
                    [null, "close"],
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        o = n.component;
                    "click" === t && (e = !1 !== i.Ub(n, 2).onClick() && e);
                    "close" === t && (e = !1 !== o.onClose(n.context.index) && e);
                    return e
                }), br, pr)), i.Hb(2, 245760, null, 0, ar.a, [], {
                    content: [0, "content"],
                    type: [1, "type"],
                    duration: [2, "duration"],
                    closeOnClick: [3, "closeOnClick"]
                }, {
                    close: "close"
                })], (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, t.context.$implicit.content, t.context.$implicit.type, l.configuration.duration, l.configuration.closeOnClick)
                }), (function(n, t) {
                    n(t, 0, 0, t.context.$implicit.id)
                }))
            }

            function _r(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 2, "div", [], [
                    [24, "@listAnimation", 0]
                ], null, null, null, null)), (n()(), i.xb(16777216, null, null, 1, null, mr)), i.Hb(2, 278528, null, 0, Y.l, [i.eb, i.Z, i.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(n, t) {
                    n(t, 2, 0, t.component.notifications)
                }), (function(n, t) {
                    n(t, 0, 0, t.component.notifications.length)
                }))
            }
            i.Eb("grc-notifications", hr, (function(n) {
                return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "grc-notifications", [], null, null, null, _r, fr)), i.Hb(1, 114688, null, 0, hr, [i.i, b.a], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {}, {}, []);
            var vr = [
                    [""]
                ],
                yr = i.Gb({
                    encapsulation: 0,
                    styles: vr,
                    data: {}
                });

            function Cr(n) {
                return i.ec(2, [(n()(), i.Ib(0, 0, null, null, 1, "grc-notifications", [], null, null, null, _r, fr)), i.Hb(1, 114688, null, 0, hr, [i.i, b.a], null, null), (n()(), i.Ib(2, 16777216, null, null, 1, "router-outlet", [], null, null, null, null, null)), i.Hb(3, 212992, null, 0, r.q, [r.b, i.eb, i.l, [8, null], i.i], null, null)], (function(n, t) {
                    n(t, 1, 0), n(t, 3, 0)
                }), null)
            }
            var kr = i.Eb("app-root", L, (function(n) {
                    return i.ec(0, [(n()(), i.Ib(0, 0, null, null, 1, "app-root", [], null, null, null, Cr, yr)), i.Hb(1, 114688, null, 0, L, [D.a], null, null)], (function(n, t) {
                        n(t, 1, 0)
                    }), null)
                }), {}, {}, []),
                xr = l("NSYL"),
                Ir = l("wFw1"),
                Sr = l("ihYY"),
                wr = l("t/Na"),
                Or = l("M3iF"),
                Pr = l("tfG9"),
                Mr = l("/6R9"),
                Tr = function() {
                    function n(n, t, l) {
                        this.coreService = n, this.router = t, this.externalConfigService = l
                    }
                    return n.prototype.goToFirstPlaylist = function(n) {
                        var t, l = this.coreService.getInitialDisplayId(this.externalConfigService),
                            e = null;
                        if (l) {
                            var i = this.coreService.getAllEventControllers().find((function(n) {
                                return n.content._clDataParent && n.content._clDataParent.displayIds.includes(l)
                            }));
                            i && i.content ? e = i.content : console.log("Error, URL param displayId not found: " + l)
                        }
                        if (e || (e = null === (t = this.coreService.getAllEventControllers()[0]) || void 0 === t ? void 0 : t.content), e) {
                            var o = e.isPlaylistContent() && e,
                                r = this.getGameTypeBase(o._clData.playlist);
                            return this.router.navigate(["cashier", r, o.playlistId], {
                                queryParams: n,
                                replaceUrl: !0
                            })
                        }
                        return this.router.navigate(["/cash", "cashManagement"], {
                            queryParams: n,
                            replaceUrl: !0
                        })
                    }, n.prototype.getGameTypeBase = function(n) {
                        var t = "";
                        switch (n.gameType.val) {
                            case $.coreModel.GameType.ValEnum.CH:
                                var l = n.filter.isChFilter() && n.filter;
                                t = l.competitionType === $.coreModel.ChCompetitionType.SOCCER ? "soccer" : l.competitionType === $.coreModel.ChCompetitionType.LEAGUE ? "league" : "champion";
                                break;
                            case $.coreModel.GameType.ValEnum.HORSE:
                            case $.coreModel.GameType.ValEnum.TROTTING:
                            case $.coreModel.GameType.ValEnum.DOG:
                            case $.coreModel.GameType.ValEnum.SPEEDWAY:
                            case $.coreModel.GameType.ValEnum.MOTORBIKE:
                            case $.coreModel.GameType.ValEnum.DIRTTRACK:
                            case $.coreModel.GameType.ValEnum.KART:
                                t = "races";
                                break;
                            case $.coreModel.GameType.ValEnum.SN:
                                t = "spin2win";
                                break;
                            case $.coreModel.GameType.ValEnum.LL:
                                t = "mega6";
                                break;
                            case $.coreModel.GameType.ValEnum.SX:
                                t = "perfect6";
                                break;
                            case $.coreModel.GameType.ValEnum.RAINBOW:
                                t = "rainbow";
                                break;
                            case $.coreModel.GameType.ValEnum.KN:
                                t = "keno";
                                break;
                            case $.coreModel.GameType.ValEnum.S2W:
                                t = "spin2wheels";
                                break;
                            case $.coreModel.GameType.ValEnum.MMA:
                                return (n.filter.isMmaFilter() && n.filter.competitionType) === $.coreModel.MmaFilter.CompetitionTypeEnum.SINGLE ? "mma" : "mma-tournament";
                            default:
                                t = "another"
                        }
                        return t
                    }, n
                }(),
                jr = function() {
                    function n(n, t) {
                        this.coreService = n, this.router = t, this.loginPath = "login"
                    }
                    return n.prototype.canActivate = function(n, t) {
                        return !!this.coreService.isInitialized() || (this.redirectToLogin(), !1)
                    }, n.prototype.redirectToLogin = function() {
                        this.queryParams(), this.redirectTo();
                        var n = this.router.serializeUrl(this.router.createUrlTree([this.loginPath]));
                        this.router.navigateByUrl("" + n + (this.query ? this.query : ""))
                    }, n.prototype.queryParams = function() {
                        if (this.query = location.href.split("?")[1], this.query && this.query.length) {
                            this.query = "?" + this.query;
                            var n = this.query.match(/((?!\?)|\&)redirectTo\=[^&]*(?=&|$)/);
                            n && (this.query = this.query.replace(new RegExp(n[0], "g"), ""))
                        }
                    }, n.prototype.redirectTo = function() {
                        var n = location.href.split("#")[1];
                        if (location.href.includes("#") && !n.startsWith("/" + this.loginPath)) {
                            var t = n.split("?")[0];
                            this.query ? (this.query += (this.query && 0 === this.query.length ? "?" : "&") + "redirectTo=" + t, this.query += "" + this.query) : this.query = "?redirectTo=" + t
                        } else {
                            var l = location.href.split("?")[1];
                            this.query = l ? "?" + l : ""
                        }
                    }, n
                }(),
                Er = function() {
                    function n(n, t) {
                        this.coreService = n, this.routerUtils = t, this.loginPath = "login"
                    }
                    return n.prototype.canActivateChild = function(n, t) {
                        var l = +n.paramMap.get("playlistId");
                        return !!this.coreService.getPlaylistById(l) || (this.routerUtils.goToFirstPlaylist(n.queryParams), !1)
                    }, n
                }(),
                Ur = function() {
                    function n(n, t) {
                        this.coreService = n, this.routerUtils = t, this.loginPath = "login"
                    }
                    return n.prototype.canActivateChild = function(n, t) {
                        var l = +n.paramMap.get("playlistId"),
                            e = this.coreService.getPlaylistById(l),
                            i = this.routerUtils.getGameTypeBase(e);
                        return n.data.gameType === i || (this.routerUtils.goToFirstPlaylist(n.queryParams), !1)
                    }, n
                }(),
                Ar = function() {
                    function n(n, t) {
                        this.coreService = n, this.routerUtils = t
                    }
                    return n.prototype.canActivateChild = function(n, t) {
                        return !0
                    }, n
                }(),
                Br = function() {
                    function n(n, t) {
                        this.coreService = n, this.routerUtils = t, this.loginPath = "login"
                    }
                    return n.prototype.canActivate = function(n, t) {
                        return !this.coreService.isInitialized() || (this.routerUtils.goToFirstPlaylist(n.queryParams), !1)
                    }, n
                }(),
                Hr = function() {
                    function n(n) {
                        this.modalService = n
                    }
                    return n.prototype.handleError = function(n) {
                        var t = this;
                        /Loading chunk [\d]+ failed/.test(n.message) ? setTimeout((function() {
                            t.modalService.open("base-main-section", ie.a, {
                                inputs: {
                                    isProcessing: !1,
                                    message: "Connections problems. Retrying reconnection, wait a moment..."
                                }
                            })
                        }), 1e3) : console.error(n)
                    }, n
                }(),
                Dr = new i.x("ExternalConfigType"),
                Lr = new i.x("ExternalConfigClientPath"),
                Nr = new i.x("ExternalConfigEnvironmentPath"),
                zr = l("iFca"),
                Rr = new i.x("CashierCoreI18NConfigToken"),
                Wr = function() {
                    function n() {}
                    return n.forRoot = function(t) {
                        return {
                            ngModule: n,
                            providers: [{
                                provide: Rr,
                                useValue: t.i18n
                            }, m.a]
                        }
                    }, n
                }(),
                Fr = function() {
                    function n() {}
                    return n.prototype.parse = function(n) {
                        return (new r.c).parse(n)
                    }, n.prototype.serialize = function(n) {
                        return (new r.c).serialize(n).replace(/%2F/g, "/")
                    }, n
                }(),
                Gr = {
                    gameType: "league"
                },
                Zr = function() {
                    return Promise.all([l.e(3), l.e(0), l.e(17)]).then(l.bind(null, "45v1")).then((function(n) {
                        return n.LeagueModuleNgFactory
                    }))
                },
                Vr = {
                    gameType: "races"
                },
                Kr = function() {
                    return Promise.all([l.e(3), l.e(25)]).then(l.bind(null, "V5Ma")).then((function(n) {
                        return n.RacesModuleNgFactory
                    }))
                },
                Yr = {
                    gameType: "spin2win"
                },
                qr = function() {
                    return Promise.all([l.e(1), l.e(0), l.e(29)]).then(l.bind(null, "Vhf+")).then((function(n) {
                        return n.Spin2WinModuleNgFactory
                    }))
                },
                Xr = {
                    gameType: "spin2win"
                },
                Jr = function() {
                    return Promise.all([l.e(1), l.e(0), l.e(30)]).then(l.bind(null, "hjsW")).then((function(n) {
                        return n.Spin2WinRouletteModuleNgFactory
                    }))
                },
                Qr = {
                    gameType: "mega6"
                },
                $r = function() {
                    return Promise.all([l.e(1), l.e(0), l.e(23)]).then(l.bind(null, "WFeS")).then((function(n) {
                        return n.Mega6ModuleNgFactory
                    }))
                },
                nu = {
                    gameType: "perfect6"
                },
                tu = function() {
                    return Promise.all([l.e(1), l.e(0), l.e(24)]).then(l.bind(null, "F1PH")).then((function(n) {
                        return n.Perfect6ModuleNgFactory
                    }))
                },
                lu = {
                    gameType: "champion"
                },
                eu = function() {
                    return Promise.all([l.e(3), l.e(0), l.e(21)]).then(l.bind(null, "3KDL")).then((function(n) {
                        return n.ChampionsModuleNgFactory
                    }))
                },
                iu = {
                    gameType: "soccer"
                },
                ou = function() {
                    return Promise.all([l.e(3), l.e(0), l.e(27)]).then(l.bind(null, "597q")).then((function(n) {
                        return n.SoccerModuleNgFactory
                    }))
                },
                ru = {
                    gameType: "keno"
                },
                uu = function() {
                    return Promise.all([l.e(1), l.e(0), l.e(22)]).then(l.bind(null, "AZBE")).then((function(n) {
                        return n.KenoModuleNgFactory
                    }))
                },
                su = {
                    gameType: "rainbow"
                },
                cu = function() {
                    return Promise.all([l.e(1), l.e(0), l.e(26)]).then(l.bind(null, "QSLV")).then((function(n) {
                        return n.RainbowModuleNgFactory
                    }))
                },
                au = {
                    gameType: "spin2wheels"
                },
                du = function() {
                    return Promise.all([l.e(1), l.e(0), l.e(28)]).then(l.bind(null, "8oOL")).then((function(n) {
                        return n.Spin2WheelsModuleNgFactory
                    }))
                },
                pu = {
                    gameType: "mma"
                },
                bu = function() {
                    return l.e(18).then(l.bind(null, "bfb3")).then((function(n) {
                        return n.MmaModuleNgFactory
                    }))
                },
                hu = (Pl.a, function() {}),
                gu = l("4hpQ"),
                fu = l("7x4Y"),
                mu = function() {},
                _u = l("QFAn"),
                vu = l("iz+u"),
                yu = function() {},
                Cu = function() {},
                ku = function() {
                    function n() {}
                    return n.forRoot = function(t) {
                        return {
                            ngModule: n,
                            providers: [b.a, {
                                provide: zr.a,
                                useValue: t
                            }]
                        }
                    }, n
                }(),
                xu = function() {},
                Iu = i.Fb(B, [L], (function(n) {
                    return i.Rb([i.Sb(512, i.l, i.qb, [
                        [8, [N.a, ge, Ie, hi, gi.a, fi.a, Je.c, mi.a, _i.a, vi.a, yi.a, Ci.a, ki.a, xi.a, Ii.a, Ai, lo, so, Fo, Yo, $o, ir, cr, kr]],
                        [3, i.l], i.G
                    ]), i.Sb(5120, i.C, i.Cb, [
                        [3, i.C]
                    ]), i.Sb(4608, Y.o, Y.n, [i.C, [2, Y.C]]), i.Sb(5120, i.yb, i.Db, [i.I]), i.Sb(5120, i.c, i.zb, []), i.Sb(5120, i.A, i.Ab, []), i.Sb(5120, i.B, i.Bb, []), i.Sb(6144, i.S, null, [cn.b]), i.Sb(4608, cn.e, cn.g, []), i.Sb(5120, cn.c, (function(n, t, l, e, i, o, r, u) {
                        return [new cn.i(n, t, l), new cn.n(e), new cn.m(i, o, r, u)]
                    }), [Y.d, i.I, i.L, Y.d, Y.d, cn.e, i.rb, [2, cn.f]]), i.Sb(4608, cn.d, cn.d, [cn.c, i.I]), i.Sb(135680, cn.l, cn.l, [Y.d]), i.Sb(4608, cn.j, cn.j, [cn.d, cn.l, i.c]), i.Sb(5120, xr.a, Ir.e, []), i.Sb(5120, xr.c, Ir.f, []), i.Sb(4608, xr.b, Ir.d, [Y.d, xr.a, xr.c]), i.Sb(5120, i.Q, Ir.g, [cn.j, xr.b, i.I]), i.Sb(6144, cn.o, null, [cn.l]), i.Sb(4608, i.ab, i.ab, [i.I]), i.Sb(4608, Sr.b, Ir.c, [i.Q, Y.d]), i.Sb(4608, wr.h, wr.n, [Y.d, i.L, wr.l]), i.Sb(4608, wr.o, wr.o, [wr.h, wr.m]), i.Sb(5120, wr.a, (function(n) {
                        return [n]
                    }), [wr.o]), i.Sb(5120, r.a, r.A, [r.l]), i.Sb(4608, r.e, r.e, []), i.Sb(6144, r.g, null, [r.e]), i.Sb(135680, r.r, r.r, [r.l, i.F, i.j, i.y, r.g]), i.Sb(4608, r.f, r.f, []), i.Sb(5120, r.F, r.w, [r.l, Y.v, r.h]), i.Sb(5120, r.i, r.D, [r.B]), i.Sb(5120, i.b, (function(n) {
                        return [n]
                    }), [r.i]), i.Sb(4608, jt.r, jt.r, []), i.Sb(4608, Or.c, Or.c, []), i.Sb(4608, Pr.a, Pr.a, [Y.d]), i.Sb(4608, Un.a, Un.a, [cn.b, m.a, $n.a]), i.Sb(4608, oe, oe, [i.l, i.g, i.y]), i.Sb(4608, Mr.a, Mr.a, [$n.a]), i.Sb(4608, Xt.a, Xt.a, [$n.a, m.a, s.k]), i.Sb(4608, M.a, M.a, [$n.a, Mr.a, b.a, m.a, s.k, Xt.a, r.l]), i.Sb(4608, qt, qt, [$n.a, m.a]), i.Sb(4608, D.a, D.a, [i.Q]), i.Sb(4608, y, y, []), i.Sb(4608, Tr, Tr, [m.a, r.l, _.a]), i.Sb(4608, jr, jr, [m.a, r.l]), i.Sb(4608, Er, Er, [m.a, Tr]), i.Sb(4608, Ur, Ur, [m.a, Tr]), i.Sb(4608, Ar, Ar, [m.a, Tr]), i.Sb(4608, Br, Br, [m.a, Tr]), i.Sb(1073742336, Y.c, Y.c, []), i.Sb(512, Jl.a, Jl.a, []), i.Sb(512, $n.a, $n.a, [i.l, Jl.a]), i.Sb(512, i.p, Hr, [$n.a]), i.Sb(1024, i.H, (function() {
                        return [r.v()]
                    }), []), i.Sb(512, r.B, r.B, [i.y]), i.Sb(512, wr.k, wr.k, []), i.Sb(2048, wr.i, null, [wr.k]), i.Sb(512, wr.g, wr.g, [wr.i]), i.Sb(2048, wr.b, null, [wr.g]), i.Sb(512, wr.f, wr.j, [wr.b, i.y]), i.Sb(512, wr.c, wr.c, [wr.f]), i.Sb(512, s.e, s.e, []), i.Sb(512, s.i, s.i, []), i.Sb(512, s.g, s.g, []), i.Sb(256, s.a, void 0, []), i.Sb(256, s.n, !0, []), i.Sb(512, s.f, s.f, [s.a, s.n]), i.Sb(256, s.l, void 0, []), i.Sb(256, s.m, void 0, []), i.Sb(512, s.k, s.k, [s.e, s.i, s.g, s.f, s.l, s.m, s.n]), i.Sb(256, Dr, U, []), i.Sb(256, Nr, "./env.properties.json", []), i.Sb(256, Lr, "./clients/{id}/env.properties.json", []), i.Sb(512, _.a, _.a, [Dr, Nr, Lr]), i.Sb(512, cn.b, cn.k, [Y.d]), i.Sb(256, zr.a, {
                        duration: 1e4,
                        closeOnClick: !0
                    }, []), i.Sb(512, b.a, b.a, [cn.b, zr.a]), i.Sb(512, m.a, m.a, [_.a, i.y, s.k, b.a]), i.Sb(256, h.a, "clients/{{name}}/common.skin.css", []), i.Sb(512, $e.a, $e.a, [wr.c, h.a]), i.Sb(256, Rr, {
                        i18nUrl: "assets/i18n",
                        prefixPath: "retail_",
                        suffixPath: ".json",
                        defaultPrefixPath: "_default/retail_",
                        tagProfile: "CASHIER",
                        defaultLanguage: "en_GB"
                    }, []), i.Sb(1024, i.d, (function(n, t, l, e, i, o, u, s, c, a, d) {
                        return [cn.p(n), r.C(t), E(l, e, i, o, u, s, c, a, d)]
                    }), [
                        [2, i.H], r.B, wr.c, s.k, _.a, m.a, $e.a, i.y, b.a, Rr, f
                    ]), i.Sb(512, i.e, i.e, [
                        [2, i.d]
                    ]), i.Sb(131584, i.g, i.g, [i.I, i.rb, i.y, i.p, i.l, i.e]), i.Sb(1073742336, i.f, i.f, [i.g]), i.Sb(1073742336, cn.a, cn.a, [
                        [3, cn.a]
                    ]), i.Sb(1073742336, Ir.b, Ir.b, []), i.Sb(1073742336, wr.e, wr.e, []), i.Sb(1073742336, wr.d, wr.d, []), i.Sb(1073742336, s.h, s.h, []), i.Sb(1073742336, Wr, Wr, []), i.Sb(1024, r.u, r.y, [
                        [3, r.l]
                    ]), i.Sb(512, r.t, Fr, []), i.Sb(512, r.b, r.b, []), i.Sb(1024, Y.a, A, [Y.s]), i.Sb(256, r.h, {
                        initialNavigation: !1,
                        useHash: !0,
                        paramsInheritanceStrategy: "always"
                    }, []), i.Sb(1024, Y.i, r.x, [Y.s, [2, Y.a], r.h]), i.Sb(512, Y.h, Y.h, [Y.i, Y.s]), i.Sb(512, i.j, i.j, []), i.Sb(512, i.F, i.X, [i.j, [2, i.Y]]), i.Sb(1024, r.j, (function() {
                        return [
                            [{
                                path: "cashier",
                                component: ue,
                                canActivate: [jr],
                                canActivateChild: [Er, Ur],
                                children: [{
                                    path: "league/:playlistId",
                                    data: Gr,
                                    loadChildren: Zr
                                }, {
                                    path: "races/:playlistId",
                                    data: Vr,
                                    loadChildren: Kr
                                }, {
                                    path: "spin2win/:playlistId",
                                    data: Yr,
                                    loadChildren: qr
                                }, {
                                    path: "spin2win-roulette/:playlistId",
                                    data: Xr,
                                    loadChildren: Jr
                                }, {
                                    path: "mega6/:playlistId",
                                    data: Qr,
                                    loadChildren: $r
                                }, {
                                    path: "perfect6/:playlistId",
                                    data: nu,
                                    loadChildren: tu
                                }, {
                                    path: "champion/:playlistId",
                                    data: lu,
                                    loadChildren: eu
                                }, {
                                    path: "soccer/:playlistId",
                                    data: iu,
                                    loadChildren: ou
                                }, {
                                    path: "keno/:playlistId",
                                    data: ru,
                                    loadChildren: uu
                                }, {
                                    path: "rainbow/:playlistId",
                                    data: su,
                                    loadChildren: cu
                                }, {
                                    path: "spin2wheels/:playlistId",
                                    data: au,
                                    loadChildren: du
                                }, {
                                    path: "mma/:playlistId",
                                    data: pu,
                                    loadChildren: bu
                                }]
                            }, {
                                path: "cash",
                                component: ue,
                                canActivate: [jr],
                                canActivateChild: [Ar],
                                children: [{
                                    path: "cashManagement",
                                    component: Pl.a
                                }]
                            }, {
                                path: "login",
                                component: li,
                                canActivate: [Br]
                            }, {
                                path: "**",
                                redirectTo: "login"
                            }],
                            []
                        ]
                    }), []), i.Sb(1024, r.l, r.z, [i.g, r.t, r.b, Y.h, i.y, i.F, i.j, r.j, r.h, [2, r.s],
                        [2, r.k]
                    ]), i.Sb(1073742336, r.p, r.p, [
                        [2, r.u],
                        [2, r.l]
                    ]), i.Sb(1073742336, hu, hu, []), i.Sb(1073742336, jt.q, jt.q, []), i.Sb(1073742336, jt.e, jt.e, []), i.Sb(1073742336, gu.a, gu.a, []), i.Sb(1073742336, fu.a, fu.a, []), i.Sb(1073742336, mu, mu, []), i.Sb(1073742336, Or.b, Or.b, []), i.Sb(1073742336, _u.a, _u.a, []), i.Sb(1073742336, vu.a, vu.a, []), i.Sb(1073742336, yu, yu, []), i.Sb(1073742336, Cu, Cu, []), i.Sb(1073742336, ku, ku, []), i.Sb(1073742336, g.a, g.a, []), i.Sb(1073742336, xu, xu, []), i.Sb(1073742336, B, B, []), i.Sb(256, i.pb, !0, []), i.Sb(256, Ir.a, "BrowserAnimations", []), i.Sb(256, wr.l, "XSRF-TOKEN", []), i.Sb(256, wr.m, "X-XSRF-TOKEN", [])])
                }));
            o.a.production && Object(i.jb)();
            var Su = function() {
                    return cn.h().bootstrapModuleFactory(Iu)
                },
                wu = Su;
            o.a.hmr ? console.error("Ups! HMR is not enabled for webpack") : Su()
        }
    },
    [
        [0, 2, 5]
    ]
]);