(window.webpackJsonp = window.webpackJsonp || []).push([
    [1], {
        "3oWU": function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return u
            })), l.d(t, "b", (function() {
                return a
            }));
            var e = l("CcnG"),
                o = l("5EE+"),
                i = l("hkR0"),
                r = [
                    [".paytable-header[_ngcontent-%COMP%]{padding:40px 1200px 40px 40px;text-transform:uppercase}.paytable-header__icon[_ngcontent-%COMP%]{padding-right:5px;font-size:50px}.paytable-header__title[_ngcontent-%COMP%]{font-size:16px}.paytable-header__subtitle[_ngcontent-%COMP%]{font-size:26px;font-weight:700}"]
                ],
                u = e.Gb({
                    encapsulation: 0,
                    styles: r,
                    data: {}
                });

            function a(n) {
                return e.ec(2, [(n()(), e.Ib(0, 0, null, null, 8, "div", [
                    ["class", "grid grid-no-wrap paytable-header"]
                ], null, null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 1, "div", [
                    ["class", "col-middle"]
                ], null, null, null, null, null)), (n()(), e.Ib(2, 0, null, null, 0, "span", [], [
                    [8, "className", 0]
                ], null, null, null, null)), (n()(), e.Ib(3, 0, null, null, 5, "div", [
                    ["class", "grid grid-no-wrap grid-column grid-center"]
                ], null, null, null, null, null)), (n()(), e.Ib(4, 0, null, null, 1, "div", [
                    ["class", "paytable-header__title"]
                ], null, null, null, null, null)), (n()(), e.cc(5, null, ["", ""])), (n()(), e.Ib(6, 0, null, null, 2, "div", [
                    ["class", "paytable-header__subtitle"]
                ], null, null, null, null, null)), (n()(), e.cc(7, null, ["", ""])), e.Wb(131072, o.j, [o.k, e.i])], null, (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, e.Mb(1, "game-icon game-icon-", l.gameType, "-o paytable-header__icon")), n(t, 5, 0, l.gameTypeName), n(t, 7, 0, e.dc(t, 7, 0, e.Ub(t, 8).transform("ch_paytable")))
                }))
            }
            e.Eb("grc-header-paytable", i.a, (function(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "grc-header-paytable", [], null, null, null, a, u)), e.Hb(1, 114688, null, 0, i.a, [], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                playlist: "playlist"
            }, {}, [])
        },
        "96LH": function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return e
            }));
            l("hg3l"), l("t01L");
            var e = function() {
                function n(n, t) {
                    this.coreService = n, this.themeService = t
                }
                return n.prototype.resolve = function() {
                    return this.themeService.load({
                        name: this.coreService.getSessionController().getSessionSettings().localizationContext.skin.toLowerCase()
                    })
                }, n
            }()
        },
        "D1+H": function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return S
            }));
            var e = l("CcnG"),
                o = l("ZYCi"),
                i = l("5EE+"),
                r = l("CrY/"),
                u = l("pugT"),
                a = l("F/XL"),
                c = l("XlPw"),
                s = l("0/uQ"),
                p = l("9Z1F"),
                b = l("psW0"),
                d = l("xMyE"),
                h = l("15JJ"),
                m = l("7oEI"),
                f = l("GNnp"),
                g = l("+iOv"),
                v = l("sylN"),
                y = l("t01L"),
                C = l("sB3t"),
                x = l("NTJ2"),
                k = function(n, t, l, e) {
                    return new(l || (l = Promise))((function(o, i) {
                        function r(n) {
                            try {
                                a(e.next(n))
                            } catch (t) {
                                i(t)
                            }
                        }

                        function u(n) {
                            try {
                                a(e.throw(n))
                            } catch (t) {
                                i(t)
                            }
                        }

                        function a(n) {
                            var t;
                            n.done ? o(n.value) : (t = n.value, t instanceof l ? t : new l((function(n) {
                                n(t)
                            }))).then(r, u)
                        }
                        a((e = e.apply(n, t || [])).next())
                    }))
                },
                _ = function(n, t) {
                    var l, e, o, i, r = {
                        label: 0,
                        sent: function() {
                            if (1 & o[0]) throw o[1];
                            return o[1]
                        },
                        trys: [],
                        ops: []
                    };
                    return i = {
                        next: u(0),
                        throw: u(1),
                        return: u(2)
                    }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                        return this
                    }), i;

                    function u(i) {
                        return function(u) {
                            return function(i) {
                                if (l) throw new TypeError("Generator is already executing.");
                                for (; r;) try {
                                    if (l = 1, e && (o = 2 & i[0] ? e.return : i[0] ? e.throw || ((o = e.return) && o.call(e), 0) : e.next) && !(o = o.call(e, i[1])).done) return o;
                                    switch (e = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                        case 0:
                                        case 1:
                                            o = i;
                                            break;
                                        case 4:
                                            return r.label++, {
                                                value: i[1],
                                                done: !1
                                            };
                                        case 5:
                                            r.label++, e = i[1], i = [0];
                                            continue;
                                        case 7:
                                            i = r.ops.pop(), r.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = r.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                                r = 0;
                                                continue
                                            }
                                            if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                                r.label = i[1];
                                                break
                                            }
                                            if (6 === i[0] && r.label < o[1]) {
                                                r.label = o[1], o = i;
                                                break
                                            }
                                            if (o && r.label < o[2]) {
                                                r.label = o[2], r.ops.push(i);
                                                break
                                            }
                                            o[2] && r.ops.pop(), r.trys.pop();
                                            continue
                                    }
                                    i = t.call(n, r)
                                } catch (u) {
                                    i = [6, u], e = 0
                                } finally {
                                    l = o = 0
                                }
                                if (5 & i[0]) throw i[1];
                                return {
                                    value: i[0] ? i[1] : void 0,
                                    done: !0
                                }
                            }([i, u])
                        }
                    }
                },
                S = function() {
                    function n(n) {
                        this.injector = n, this.RETRY_INTERVAL_ON_EVENDATA_NO_SERVICE = 25e3, this.isInitialized = !1, this.subscriptions = new u.a, this.route = this.injector.get(o.a), this.router = this.injector.get(o.l), this.cd = this.injector.get(e.i), this.coreService = this.injector.get(y.a), this.betslipService = this.injector.get(v.a), this.baseService = this.injector.get(x.a), this.modalService = this.injector.get(m.a), this.i18NService = this.injector.get(i.k), this.notificationsService = this.injector.get(f.a)
                    }
                    return n.prototype.ngOnInit = function() {
                        var n = this;
                        this.hasCheckServiceError = !1, this.routeSubscription = this.route.paramMap.subscribe((function(t) {
                            n.currentParams = t, n.isInitialized && n.onDestroy(), n.onInit(t), n.isInitialized = !0
                        })), this.currentConnStateSubscription = this.baseService.currentConnState$.subscribe((function(t) {
                            t === r.ConnectionStateEnum.CONNECTED ? (n.onDestroy(), n.onInit(n.currentParams)) : t === r.ConnectionStateEnum.DISCONNECTED && (clearInterval(n.checkServiceErrorTimer), n.checkServiceErrorTimer = null, clearTimeout(n.modalTimeout), n.modalTimeout = null)
                        }))
                    }, n.prototype.ngOnDestroy = function() {
                        this.routeSubscription.unsubscribe(), this.currentConnStateSubscription.unsubscribe(), this.subscriptions.unsubscribe(), this.initCoreSubscription.unsubscribe(), clearTimeout(this.initTimeout), this.onDestroy()
                    }, n.prototype.onBeforeInit = function() {
                        return Object(a.a)(null)
                    }, n.prototype.onAfterInit = function() {
                        return Object(a.a)(null)
                    }, n.prototype.configureBetslip = function() {}, n.prototype.configureHeader = function() {}, n.prototype.configureShortcuts = function() {}, n.prototype.configureFastbet = function() {}, n.prototype.onClearBetslipUserSelections = function() {}, n.prototype.onEventBlockControllerClosedMarkets = function(n) {}, n.prototype.onEventBlockControllerEventData = function(n) {}, n.prototype.onEventBlockControllerReadyToStart = function(n) {}, n.prototype.onUpdateEventBlock = function() {}, n.prototype.onInit = function(n) {
                        var t = this;
                        this.baseService.closeMarkets(!1), this.subscriptions = new u.a, this.getPlaylist(+n.get("playlistId")), this.gameType = this.playlist.gameType.val.toLowerCase(), this.setHeader(), this.configureEBControllerConfigItem(), this.betslipService.clear(), this.coreService.currentGameType = this.playlist.gameType.val, this.initCoreSubscription = this.initEventBlockController().pipe(Object(p.a)((function(l) {
                            return l && t.handlerInitEventBlockControllerErrors(l), "NOT_BETTABLE_CONTENT" !== (null == l ? void 0 : l.message) || t.hasConnectionError() || t.hasServiceError() || (t.initTimeout = setTimeout((function() {
                                t.initCoreSubscription.unsubscribe(), t.onInit(n)
                            }), 1e4)), Object(c.a)(l)
                        })), Object(b.a)((function(n) {
                            try {
                                t.modalService.close("base-main-section")
                            } catch (l) {}
                            return t.posInit()
                        }))).subscribe()
                    }, n.prototype.getGameMode = function() {
                        return this.playlist.mode
                    }, n.prototype.hasContentAvailable = function() {
                        return this.eventBlockController instanceof r.EBControllerScheduled && "HAS_CONTENT" === this.eventBlockController.contentStatus
                    }, n.prototype.getStats = function() {
                        return k(this, void 0, void 0, (function() {
                            return _(this, (function(n) {
                                return [2, this.eventBlockController.getCurrentLazyStats(r.GetCurrentStatsMode.ON_PREAMBLE)]
                            }))
                        }))
                    }, n.prototype.getCurrentPayTable = function() {
                        return this.eventBlockController.getCurrentPayTable()
                    }, n.prototype.getS2WheelsPaytable = function() {
                        var n, t = [];
                        this.coreService.getSessionController().sessionSettings.calculationContext.oddContext.gameOddSettings.forEach((function(t) {
                            t.isS2wGameOddSettings() && (n = t)
                        }));
                        var l = n.payTable;
                        return Object.entries(l).forEach((function(n) {
                            var l = n[0],
                                e = n[1];
                            t.push({
                                oddId: l,
                                value: e
                            })
                        })), t
                    }, n.prototype.getEBControllerConfigItem = function() {
                        return {}
                    }, n.prototype.posInit = function() {
                        var n = this;
                        return this.displayNoContentScreen(), this.updateCurrentEventBlock(), this.eventBlock = this.eventBlockController.getCurrentEventBlockClosed(), this.eventBlock && this.eventBlock._clData.clientStatus === r.coreModel.EventBlock.ClientStatusEnum.CLOSEDMARKETS || (this.eventBlock = this.eventBlockController.getCurrentEventBlockOpen()), this.onBeforeInit().pipe(Object(d.a)((function() {
                            n.configureBetslip(), n.configureHeader(), n.setMaxMultiplier()
                        })), Object(b.a)((function() {
                            return n.onAfterInit()
                        })), Object(d.a)((function() {
                            n.subscribeEventBlockEvents(), n.configureShortcuts(), n.eventBlock && n.baseService.closeMarkets(n.eventBlock._clData.clientStatus === r.coreModel.EventBlock.ClientStatusEnum.CLOSEDMARKETS), n.cd.markForCheck()
                        })))
                    }, n.prototype.configureEBControllerConfigItem = function() {
                        this.eventBlockController.setConfig(Object.assign({}, this.eventBlockController.getConfig(), this.getEBControllerConfigItem()))
                    }, n.prototype.onDestroy = function() {
                        clearInterval(this.checkServiceErrorTimer), this.checkServiceErrorTimer = null, clearTimeout(this.modalTimeout), this.modalTimeout = null, this.subscriptions.unsubscribe(), this.initCoreSubscription.unsubscribe(), clearTimeout(this.initTimeout), this.baseService.activateGame(!1), this.betslipService.removeCurrentFastbetParser(), this.closeModalWindows(), this.stopEventBlockController(), this.coreService.isInitialized() && this.betslipService.clear()
                    }, n.prototype.closeModalWindows = function() {
                        this.modalService.close("base-main-section"), this.modalService.close("base-front"), this.modalService.close("base-information"), this.modalService.close("base-help")
                    }, n.prototype.setHeader = function() {
                        this.baseService.setHeaderState({
                            gameName: this.playlist.descriptionTag,
                            playList: this.playlist
                        })
                    }, n.prototype.setMaxMultiplier = function() {
                        this.betslipService.setMaxMultiplier(this.getWindowOpenSize())
                    }, n.prototype.getWindowOpenSize = function() {
                        return this.eventBlockController.getEventBlockOpen().length
                    }, n.prototype.initEventBlockController = function() {
                        var n;
                        return this.addEventblockDataErrorSubscription(), this.eventBlockController instanceof r.EBControllerScheduled && (this.eventBlockController.isRunning() || this.eventBlockController.isPaused() ? this.eventBlockController.isPaused() && (n = Object(s.a)(this.eventBlockController.unpause(!1))) : n = Object(s.a)(this.eventBlockController.init(!1))), n || (n = Object(a.a)([])), n
                    }, n.prototype.stopEventBlockController = function() {
                        this.eventBlockController instanceof r.EBControllerScheduled && this.eventBlockController && !this.eventBlockController.isPaused() && this.eventBlockController.pause()
                    }, n.prototype.getPlaylist = function(n) {
                        this.playlist = this.coreService.getPlaylistById(n), this.eventBlockController = this.coreService.getEventControllerByPlaylistId(n, this.getGameMode())
                    }, n.prototype.updateEventBlock = function(n) {
                        this.eventBlock = n, this.configureHeader(), this.setMaxMultiplier(), this.onUpdateEventBlock(), this.cd.detectChanges()
                    }, n.prototype.displayNoContentScreen = function() {
                        var n = this;
                        if (!this.hasContentAvailable()) {
                            this.betslipService.enableFastbet(!1);
                            var t, l = this.coreService.getNextEventblockDataDependOfPreviousResult(this.playlist.gameType);
                            t = l ? this.playlist.filter.isMmaFilter() ? "vw_waiting_for_results" : "vw_waiting_for_all_matches_to_finish" : "ch_empty_ebd_content", this.hasConnectionError() ? t = "Connections problems. Retrying reconnection, wait a moment..." : this.hasServiceError() && (t = "Service problems. Checking service status, wait a moment..."), this.modalTimeout = setTimeout((function() {
                                n.modalService.open("base-main-section", g.a, {
                                    inputs: {
                                        isProcessing: !1,
                                        message: t
                                    }
                                })
                            }), 3e3)
                        }
                    }, n.prototype.displayEventPlayingScreen = function() {
                        if (!this.hasContentAvailable()) {
                            var n = this.playlist.filter.isMmaFilter() ? "vw_waiting_for_results" : "vw_waiting_for_all_matches_to_finish";
                            this.betslipService.enableFastbet(!1), this.modalService.open("base-main-section", g.a, {
                                inputs: {
                                    isProcessing: !1,
                                    message: n
                                }
                            })
                        }
                    }, n.prototype.initEventBlockControllerErrorDialog = function(n) {
                        var t = this;
                        this.modalService.openDialog("base", {
                            type: "danger",
                            icon: "icon icon-warning",
                            iconColor: "#d43548",
                            text: "" + this.i18NService.get("ch_" + n.message.toLowerCase()),
                            buttons: [{
                                type: "danger",
                                text: "" + this.i18NService.get("ch_dismiss"),
                                action: function() {
                                    t.modalService.close("base")
                                }
                            }]
                        })
                    }, n.prototype.updateCurrentEventBlock = function() {
                        if ("HAS_CONTENT" === this.eventBlockController.contentStatus) {
                            this.baseService.closeMarkets(!1);
                            var n = this.eventBlockController.getCurrentEventBlockOpen();
                            n && (this.onEventBlockControllerReadyToStart(n), this.updateEventBlock(n), this.configureFastbet(), this.betslipService.enableFastbet(!0))
                        }
                    }, n.prototype.handlerInitEventBlockControllerErrors = function(n) {
                        n.message && ("NOT_BETTABLE_CONTENT" === n.message || this.hasConnectionError() || this.hasServiceError() ? this.displayNoContentScreen() : this.initEventBlockControllerErrorDialog(n))
                    }, n.prototype.subscribeEventBlockEvents = function() {
                        var n = this;
                        this.subscriptions.add(Object(C.a)(this.eventBlockController.onClosedMarkets).subscribe((function(t) {
                            n.baseService.closeMarkets(!0), n.betslipService.clear(), n.onEventBlockControllerClosedMarkets(t), n.setMaxMultiplier(), n.cd.detectChanges()
                        }))), this.subscriptions.add(Object(C.a)(this.eventBlockController.onContentStatusChange).pipe(Object(h.a)((function(t) {
                            return "HAS_CONTENT" === t.contentStatus ? Object(a.a)(t).pipe(Object(d.a)((function() {
                                n.modalService.close("base-main-section"), n.updateCurrentEventBlock()
                            })), Object(p.a)((function(n) {
                                return Object(a.a)(n)
                            }))) : Object(C.a)(n.eventBlockController.onAllPlayerStart).pipe(Object(d.a)((function() {
                                n.configureHeader(), n.baseService.closeMarkets(!1), n.displayEventPlayingScreen()
                            })))
                        })), Object(p.a)((function(n) {
                            return Object(a.a)(n)
                        }))).subscribe()), this.subscriptions.add(Object(C.a)(this.eventBlockController.onEventData).subscribe((function(t) {
                            n.onEventBlockControllerEventData(t), n.cd.detectChanges()
                        }))), this.subscriptions.add(Object(C.a)(this.eventBlockController.onAllPlayerStart).subscribe((function() {
                            n.updateCurrentEventBlock(), n.cd.detectChanges()
                        }))), this.subscriptions.add(Object(C.a)(this.eventBlockController.onAllPlayerEnd).subscribe((function() {
                            n.updateCurrentEventBlock(), n.cd.detectChanges()
                        }))), this.subscriptions.add(Object(C.a)(this.eventBlockController.onResultTimeout).subscribe((function() {
                            n.baseService.closedMarkets.next(!1), n.displayNoContentScreen(), n.updateCurrentEventBlock(), n.cd.detectChanges()
                        }))), this.subscriptions.add(this.betslipService.onClear.subscribe((function() {
                            n.onClearBetslipUserSelections(), n.cd.detectChanges()
                        })))
                    }, n.prototype.hasServiceError = function() {
                        var n;
                        if (!(null === (n = this.eventBlockController) || void 0 === n ? void 0 : n.eventDataError)) return !1;
                        var t = r.coreUtils.ErrorManager.getSessionError(r.coreUtils.SessionErrorCodEnum.TIMEOUT_PROBLEMS).message;
                        return (this.eventBlockController.eventDataError.message === r.coreUtils.ERROR_PROXY_API_CONNECTION_PROBLEMS.message || this.eventBlockController.eventDataError.message === t) && 0 === this.eventBlockController.getEventBlockOpen().length
                    }, n.prototype.hasConnectionError = function() {
                        return this.coreService.getSessionController().connection.connDiagnosis.currentConnDiagnosisData.connState === r.ConnectionStateEnum.DISCONNECTED
                    }, n.prototype.addEventblockDataErrorSubscription = function() {
                        var n = this;
                        this.subscriptions.add(Object(C.a)(this.eventBlockController.onEventDataError).subscribe((function() {
                            if (n.RETRY_INTERVAL_ON_EVENDATA_NO_SERVICE >= 1e3) {
                                if (n.hasServiceError()) {
                                    if (!n.checkServiceErrorTimer) {
                                        n.hasCheckServiceError = !0;
                                        try {
                                            n.baseService.closeMarkets(!1)
                                        } catch (t) {}
                                        n.onDestroy(), n.onInit(n.currentParams), n.checkServiceErrorTimer = setInterval((function() {
                                            if (n.hasServiceError()) {
                                                try {
                                                    n.baseService.closeMarkets(!1)
                                                } catch (t) {}
                                                n.onDestroy(), n.onInit(n.currentParams)
                                            } else clearInterval(n.checkServiceErrorTimer), n.checkServiceErrorTimer = null, n.hasCheckServiceError = !1
                                        }), n.RETRY_INTERVAL_ON_EVENDATA_NO_SERVICE)
                                    }
                                    n.displayNoContentScreen()
                                } else n.onDestroy(), n.onInit(n.currentParams);
                                n.cd.detectChanges()
                            }
                        })))
                    }, n
                }()
        },
        Wh5D: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return e
            }));
            var e = [".paytable[_ngcontent-%COMP%]{width:1600px;min-height:936px}.paytable__button-close[_ngcontent-%COMP%]{padding:24px 105px;margin-bottom:30px;align-self:center;font-size:22px;font-weight:700;text-transform:uppercase;cursor:pointer;border-radius:2px;box-shadow:0 4px 5px 0 rgba(0,0,0,.14),0 1px 10px 0 rgba(0,0,0,.12),0 2px 4px 0 rgba(0,0,0,.2)}.paytable__cross-close[_ngcontent-%COMP%]{position:absolute;top:49px;right:49px;z-index:99999;font-size:24px;cursor:pointer}.paytable--body-margin[_ngcontent-%COMP%]{height:100%;margin-top:33px;min-height:650px}.paytable__tab-buttons[_ngcontent-%COMP%]{margin-top:35px}"]
        },
        ftDe: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return o
            }));
            var e = l("CcnG"),
                o = function() {
                    function n(n) {
                        this.i18nService = n, this.currentPayTable = [], this.isS2Wheels = !1, this.isRainbow = !1, this.isKinel8 = !1, this.hasX = !1, this.buttons = [], this.close = new e.q, this.selectedChange = new e.q, this.paytableGame = [], this.buttonSelected = 0
                    }
                    return n.prototype.setPaytableInfo = function(n, t, l, e, o, i) {
                        var r = this;
                        void 0 === n && (n = []), void 0 === t && (t = []), void 0 === l && (l = []), void 0 === e && (e = []), void 0 === o && (o = []), void 0 === i && (i = []), this.paytableGame = [], t.forEach((function(t, u) {
                            var a = [];
                            t.forEach((function(n) {
                                var t, l = r.currentPayTable.find((function(t) {
                                        return t.oddId === n.odd
                                    })) || {},
                                    e = l.oddId,
                                    o = void 0 === e ? "" : e,
                                    i = l.value,
                                    u = void 0 === i ? "" : i;
                                a.push({
                                    odd: o,
                                    replacedOddName: n.oddNameToDisplay ? n.oddNameToDisplay : void 0,
                                    value: u || n.odd,
                                    subtitle: n && n.subtitle,
                                    showOddName: null === (t = n.showOddName) || void 0 === t || t,
                                    columnTitle: n.columnTitle,
                                    oddNameToDisplayTitle: n.oddNameToDisplayTitle
                                })
                            })), r.paytableGame.push({
                                marketTitle: n[u],
                                marketSubTitle: l[u],
                                longMarket: e[u],
                                columns: o[u],
                                rows: i[u],
                                odds: a
                            })
                        }))
                    }, n.prototype.onButtonActiveChange = function(n) {
                        this.buttonSelected = n, this.selectedChange.emit(n)
                    }, n
                }()
        },
        goQo: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return a
            })), l.d(t, "b", (function() {
                return j
            }));
            var e = l("CcnG"),
                o = l("Ip0R"),
                i = l("5EE+"),
                r = l("UhMo"),
                u = [
                    [".body-paytable-container[_ngcontent-%COMP%]{display:table;width:100%;height:100%}.body-paytable[_ngcontent-%COMP%]{height:100%;padding:0 60px;text-align:center;text-transform:capitalize;vertical-align:middle}.body-paytable[_ngcontent-%COMP%] > .col[_ngcontent-%COMP%]{display:inline-block;width:100%;padding:0 15px;margin-bottom:40px;vertical-align:top}.body-paytable[_ngcontent-%COMP%] > .col--two-columns[_ngcontent-%COMP%]{padding:0 10px}.body-paytable__content[_ngcontent-%COMP%]{height:100%}.body-paytable__title[_ngcontent-%COMP%]{height:34px;padding-bottom:11px;overflow:hidden;font-size:26px;font-weight:700;text-align:left;text-overflow:ellipsis;white-space:nowrap}.body-paytable--border-container__rainbow[_ngcontent-%COMP%]{padding-top:46px}.body-paytable__odd[_ngcontent-%COMP%]{max-height:54px;padding-left:2px;margin-top:1px;font-size:22px}.body-paytable__odd--container[_ngcontent-%COMP%]{width:30px}.body-paytable__odd--container--total-color[_ngcontent-%COMP%]{width:inherit;margin:0 8px}.body-paytable__odd--column-title[_ngcontent-%COMP%]{margin:-25px 0 11px;font-size:16px;font-weight:inherit}.body-paytable__odd--value[_ngcontent-%COMP%]{width:95px;height:102%;padding:10px 10px 10px 0;font-weight:700;text-align:right}.body-paytable__odd--value--rainbow[_ngcontent-%COMP%]{width:155px}.body-paytable__even[_ngcontent-%COMP%]{margin-left:8px}.one-column-per-row[_ngcontent-%COMP%]{display:table-cell;text-align:center;vertical-align:middle}.hit-ball[_ngcontent-%COMP%] > .col[_ngcontent-%COMP%]{max-width:850px;padding:0}.rainbow-odd-name[_ngcontent-%COMP%]{margin-right:56px;margin-left:8px}.rainbow-odd-name--title[_ngcontent-%COMP%]{margin-left:inherit}.x[_ngcontent-%COMP%]{font-size:20px;text-transform:lowercase}.market-without-name[_ngcontent-%COMP%]{padding-left:15px;margin-top:34px;margin-left:-30px}.odds-subtitles[_ngcontent-%COMP%]{padding:10px 0}"]
                ],
                a = e.Gb({
                    encapsulation: 0,
                    styles: u,
                    data: {}
                });

            function c(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 4, "div", [], [
                    [8, "className", 0],
                    [2, "body-paytable--two-columns", null]
                ], null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 3, "div", [
                    ["class", "body-paytable__content"]
                ], null, null, null, null, null)), (n()(), e.Ib(2, 16777216, null, null, 2, null, null, null, null, null, null, null)), e.Hb(3, 540672, null, 0, o.q, [e.eb], {
                    ngTemplateOutletContext: [0, "ngTemplateOutletContext"],
                    ngTemplateOutlet: [1, "ngTemplateOutlet"]
                }, null), e.Xb(4, {
                    market: 0
                })], (function(n, t) {
                    var l = n(t, 4, 0, t.context.$implicit);
                    n(t, 3, 0, l, t.context.$implicit.longMarket ? e.Ub(t.parent, 6) : e.Ub(t.parent, 5))
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 0, 0, e.Mb(1, "col col-", l.paytableGame[t.context.index].columns ? l.paytableGame[t.context.index].columns : "", ""), 2 === l.columnsPerRow[l.buttonSelected])
                }))
            }

            function s(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 2, "div", [
                    ["class", "body-paytable__title"]
                ], null, null, null, null, null)), (n()(), e.cc(1, null, [" ", " "])), e.Wb(131072, i.q, [i.k, e.i])], null, (function(n, t) {
                    n(t, 1, 0, e.dc(t, 1, 0, e.Ub(t, 2).transform(t.parent.context.market.marketTitle)))
                }))
            }

            function p(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 2, "div", [
                    ["class", "odds-subtitles"]
                ], [
                    [4, "font-weight", null]
                ], null, null, null, null)), (n()(), e.cc(1, null, [" ", " "])), e.Wb(131072, i.j, [i.k, e.i])], null, (function(n, t) {
                    n(t, 0, 0, 700), n(t, 1, 0, e.dc(t, 1, 0, e.Ub(t, 2).transform(t.parent.context.$implicit.subtitle)))
                }))
            }

            function b(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 2, "span", [], null, null, null, null, null)), (n()(), e.cc(1, null, ["", "\xa0"])), e.Wb(131072, i.j, [i.k, e.i])], null, (function(n, t) {
                    n(t, 1, 0, e.dc(t, 1, 0, e.Ub(t, 2).transform("vw_hit")))
                }))
            }

            function d(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 0, "span", [
                    ["class", "icon icon-star-full"]
                ], null, null, null, null, null))], null, null)
            }

            function h(n) {
                return e.ec(0, [(n()(), e.cc(0, null, ["", ""])), e.Wb(131072, i.q, [i.k, e.i])], null, (function(n, t) {
                    n(t, 0, 0, e.dc(t, 0, 0, e.Ub(t, 1).transform(t.parent.parent.parent.context.$implicit.replacedOddName)))
                }))
            }

            function m(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 5, "div", [
                    ["class", "body-paytable__even"]
                ], null, null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, b)), e.Hb(2, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.xb(16777216, null, null, 1, null, d)), e.Hb(4, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"],
                    ngIfElse: [1, "ngIfElse"]
                }, null), (n()(), e.xb(0, [
                    ["marketGroupTmpl", 2]
                ], null, 0, null, h))], (function(n, t) {
                    n(t, 2, 0, t.component.isKinel8), n(t, 4, 0, "Star" === t.parent.parent.context.$implicit.replacedOddName, e.Ub(t, 5))
                }), null)
            }

            function f(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 2, "span", [], null, null, null, null, null)), (n()(), e.cc(1, null, ["", ""])), e.Wb(131072, i.r, [i.k, e.i])], null, (function(n, t) {
                    var l = t.component;
                    n(t, 1, 0, e.dc(t, 1, 0, e.Ub(t, 2).transform(t.parent.parent.parent.context.$implicit.odd, l.playlist.gameType.val.toLowerCase())))
                }))
            }

            function g(n) {
                return e.ec(0, [(n()(), e.cc(0, null, ["", ""])), e.Wb(131072, i.r, [i.k, e.i])], null, (function(n, t) {
                    var l = t.component;
                    n(t, 0, 0, e.dc(t, 0, 0, e.Ub(t, 1).transform(t.parent.parent.parent.context.$implicit.odd, l.playlist.gameType.val)))
                }))
            }

            function v(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 3, "div", [
                    ["class", "body-paytable__even"]
                ], null, null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, f)), e.Hb(2, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"],
                    ngIfElse: [1, "ngIfElse"]
                }, null), (n()(), e.xb(0, [
                    ["marketOptionTmpl", 2]
                ], null, 0, null, g))], (function(n, t) {
                    n(t, 2, 0, t.component.isS2Wheels, e.Ub(t, 3))
                }), null)
            }

            function y(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "span", [
                    ["class", "x"]
                ], null, null, null, null, null)), (n()(), e.cc(-1, null, ["x"]))], null, null)
            }

            function C(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 8, null, null, null, null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, m)), e.Hb(2, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.xb(16777216, null, null, 1, null, v)), e.Hb(4, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.Ib(5, 0, null, null, 3, "div", [
                    ["class", "body-paytable__odd--value grid grid-middle grid-right"]
                ], null, null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, y)), e.Hb(7, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.cc(8, null, [" ", " "]))], (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, t.parent.context.$implicit.replacedOddName), n(t, 4, 0, !t.parent.context.$implicit.replacedOddName), n(t, 7, 0, l.hasX)
                }), (function(n, t) {
                    n(t, 8, 0, t.parent.context.$implicit.value)
                }))
            }

            function x(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 7, "div", [
                    ["class", "col grid grid-space-between grid-middle body-paytable__odd"]
                ], null, null, null, null, null)), e.Zb(512, null, o.x, o.y, [e.A, e.B, e.o, e.P]), e.Hb(2, 278528, null, 0, o.k, [o.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), e.Xb(3, {
                    "body-paytable__odd--background-gray": 0
                }), (n()(), e.xb(16777216, null, null, 1, null, p)), e.Hb(5, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.xb(16777216, null, null, 1, null, C)), e.Hb(7, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(n, t) {
                    var l = n(t, 3, 0, t.context.index % 2 != 0);
                    n(t, 2, 0, "col grid grid-space-between grid-middle body-paytable__odd", l), n(t, 5, 0, t.context.$implicit.subtitle), n(t, 7, 0, !t.context.$implicit.subtitle)
                }), null)
            }

            function k(n) {
                return e.ec(0, [(n()(), e.xb(16777216, null, null, 1, null, s)), e.Hb(1, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.Ib(2, 0, null, null, 2, "div", [
                    ["class", "body-paytable--border-container"]
                ], [
                    [2, "market-without-name", null]
                ], null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, x)), e.Hb(4, 278528, null, 0, o.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(n, t) {
                    n(t, 1, 0, "" !== t.context.market.marketTitle), n(t, 4, 0, t.context.market.odds)
                }), (function(n, t) {
                    n(t, 2, 0, "" === t.context.market.marketTitle)
                }))
            }

            function _(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "span", [], null, null, null, null, null)), (n()(), e.cc(1, null, ["", ""]))], null, (function(n, t) {
                    n(t, 1, 0, t.parent.context.market.marketSubTitle)
                }))
            }

            function S(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 3, "span", [
                    ["class", "rainbow-odd-name rainbow-odd-name--title"]
                ], null, null, null, null, null)), (n()(), e.cc(1, null, ["", ""])), e.Wb(131072, i.j, [i.k, e.i]), e.Yb(3, 1)], null, (function(n, t) {
                    var l = e.dc(t, 1, 0, n(t, 3, 0, e.Ub(t.parent.parent.parent.parent.parent, 0), e.dc(t, 1, 0, e.Ub(t, 2).transform(t.parent.parent.context.$implicit.oddNameToDisplayTitle))));
                    n(t, 1, 0, l)
                }))
            }

            function E(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 4, "span", [
                    ["class", "grid grid-right"]
                ], null, null, null, null, null)), (n()(), e.cc(1, null, [" ", " "])), e.Xb(2, {
                    value: 0
                }), e.Wb(131072, i.j, [i.k, e.i]), e.Yb(4, 1)], null, (function(n, t) {
                    var l = e.dc(t, 1, 0, n(t, 4, 0, e.Ub(t.parent.parent.parent.parent.parent, 0), e.dc(t, 1, 0, e.Ub(t, 3).transform(t.parent.parent.context.$implicit.columnTitle.tag, n(t, 2, 0, t.parent.parent.context.$implicit.columnTitle.value)))));
                    n(t, 1, 0, l)
                }))
            }

            function I(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 4, "div", [
                    ["class", "col grid body-paytable__odd--column-title"]
                ], null, null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, S)), e.Hb(2, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.xb(16777216, null, null, 1, null, E)), e.Hb(4, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(n, t) {
                    n(t, 2, 0, t.parent.context.$implicit.oddNameToDisplayTitle), n(t, 4, 0, null == t.parent.context.$implicit.columnTitle ? null : t.parent.context.$implicit.columnTitle.tag)
                }), null)
            }

            function O(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 2, null, null, null, null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, I)), e.Hb(2, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.xb(0, null, null, 0))], (function(n, t) {
                    n(t, 2, 0, t.context.$implicit.oddNameToDisplayTitle || (null == t.context.$implicit.columnTitle ? null : t.context.$implicit.columnTitle.tag))
                }), null)
            }

            function w(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 2, "div", [], [
                    [4, "font-weight", null]
                ], null, null, null, null)), (n()(), e.cc(1, null, ["", ""])), e.Wb(131072, i.j, [i.k, e.i])], null, (function(n, t) {
                    n(t, 0, 0, 700), n(t, 1, 0, e.dc(t, 1, 0, e.Ub(t, 2).transform(t.parent.context.$implicit.subtitle)))
                }))
            }

            function T(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 2, "div", [
                    ["class", "rainbow-odd-name"]
                ], null, null, null, null, null)), (n()(), e.cc(1, null, [" ", " "])), e.Wb(131072, i.q, [i.k, e.i])], null, (function(n, t) {
                    n(t, 1, 0, e.dc(t, 1, 0, e.Ub(t, 2).transform(t.parent.parent.context.$implicit.replacedOddName)))
                }))
            }

            function B(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 2, "div", [
                    ["class", "body-paytable__odd--container"]
                ], [
                    [2, "rainbow-odd-name", null],
                    [2, "body-paytable__odd--container--total-color", null]
                ], null, null, null, null)), (n()(), e.cc(1, null, [" ", " "])), e.Wb(131072, i.r, [i.k, e.i])], null, (function(n, t) {
                    var l = t.component;
                    n(t, 0, 0, l.isRainbow && (null == t.parent.parent.parent.parent.context.market ? null : t.parent.parent.parent.parent.context.market.marketTitle) !== l.rainbowMarkets.total_color, l.isRainbow && (null == t.parent.parent.parent.parent.context.market ? null : t.parent.parent.parent.parent.context.market.marketTitle) === l.rainbowMarkets.total_color), n(t, 1, 0, e.dc(t, 1, 0, e.Ub(t, 2).transform(t.parent.parent.context.$implicit.odd, l.playlist.gameType.val)))
                }))
            }

            function M(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "span", [
                    ["class", "x"]
                ], null, null, null, null, null)), (n()(), e.cc(-1, null, ["x"]))], null, null)
            }

            function P(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 8, null, null, null, null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, T)), e.Hb(2, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.xb(16777216, null, null, 1, null, B)), e.Hb(4, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.Ib(5, 0, null, null, 3, "div", [
                    ["class", "body-paytable__odd--value grid grid-middle grid-right"]
                ], [
                    [2, "body-paytable__odd--value--rainbow", null]
                ], null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, M)), e.Hb(7, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.cc(8, null, [" ", " "]))], (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, t.parent.context.$implicit.replacedOddName && t.parent.context.$implicit.showOddName), n(t, 4, 0, !t.parent.context.$implicit.replacedOddName && t.parent.context.$implicit.showOddName), n(t, 7, 0, l.hasX)
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 5, 0, l.isRainbow && (null == t.parent.parent.parent.context.market ? null : t.parent.parent.parent.context.market.marketTitle) !== l.rainbowMarkets.first_color && (null == t.parent.parent.parent.context.market ? null : t.parent.parent.parent.context.market.marketTitle) !== l.rainbowMarkets.total_color), n(t, 8, 0, t.parent.context.$implicit.value)
                }))
            }

            function N(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 7, "div", [
                    ["class", "col grid grid-space-between grid-middle body-paytable__odd"]
                ], null, null, null, null, null)), e.Zb(512, null, o.x, o.y, [e.A, e.B, e.o, e.P]), e.Hb(2, 278528, null, 0, o.k, [o.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), e.Xb(3, {
                    "body-paytable__odd--background-gray": 0
                }), (n()(), e.xb(16777216, null, null, 1, null, w)), e.Hb(5, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.xb(16777216, null, null, 1, null, P)), e.Hb(7, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(n, t) {
                    var l = n(t, 3, 0, t.context.index % 2 != 0);
                    n(t, 2, 0, "col grid grid-space-between grid-middle body-paytable__odd", l), n(t, 5, 0, t.context.$implicit.subtitle), n(t, 7, 0, !t.parent.context.$implicit.subtitle)
                }), null)
            }

            function R(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 4, "div", [], null, null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, O)), e.Hb(2, 278528, null, 0, o.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), (n()(), e.xb(16777216, null, null, 1, null, N)), e.Hb(4, 278528, null, 0, o.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(n, t) {
                    n(t, 2, 0, t.context.$implicit), n(t, 4, 0, t.context.$implicit)
                }), null)
            }

            function D(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 10, "div", [
                    ["class", "col grid grid-1 grid-center one-column-per-row--long-market"]
                ], [
                    [2, "hit-ball", null]
                ], null, null, null, null)), (n()(), e.Ib(1, 0, null, null, 9, "div", [], [
                    [2, "col", null]
                ], null, null, null, null)), (n()(), e.Ib(2, 0, null, null, 8, "div", [
                    ["class", "body-paytable__content"]
                ], null, null, null, null, null)), (n()(), e.Ib(3, 0, null, null, 4, "div", [
                    ["class", "body-paytable__title"]
                ], [
                    [2, "body-paytable__title--rainbow", null]
                ], null, null, null, null)), (n()(), e.cc(4, null, [" ", " "])), e.Wb(131072, i.q, [i.k, e.i]), (n()(), e.xb(16777216, null, null, 1, null, _)), e.Hb(7, 16384, null, 0, o.m, [e.eb, e.Z], {
                    ngIf: [0, "ngIf"]
                }, null), (n()(), e.Ib(8, 0, null, null, 2, "div", [
                    ["class", "body-paytable--border-container grid"]
                ], [
                    [2, "grid-space-between", null],
                    [2, "body-paytable--border-container__rainbow", null]
                ], null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, R)), e.Hb(10, 278528, null, 0, o.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(n, t) {
                    var l = t.component;
                    n(t, 7, 0, null == t.context.market ? null : t.context.market.marketSubTitle), n(t, 10, 0, l.sliceLongMarketOdds(t.context.market))
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 0, 0, !l.isRainbow), n(t, 1, 0, (null == t.context.market ? null : t.context.market.marketTitle) !== l.rainbowMarkets.first_color), n(t, 3, 0, l.isRainbow), n(t, 4, 0, e.dc(t, 4, 0, e.Ub(t, 5).transform(t.context.market.marketTitle))), n(t, 8, 0, !l.isRainbow || l.isRainbow && (null == t.context.market ? null : t.context.market.marketTitle) === l.rainbowMarkets.no_draw || l.isRainbow && (null == t.context.market ? null : t.context.market.marketTitle) === l.rainbowMarkets.total_color, l.isRainbow && (null == t.context.market ? null : t.context.market.marketTitle) !== l.rainbowMarkets.rainbow && (null == t.context.market ? null : t.context.market.marketTitle) !== l.rainbowMarkets.first_color)
                }))
            }

            function j(n) {
                return e.ec(2, [e.Wb(0, o.u, []), (n()(), e.Ib(1, 0, null, null, 3, "div", [
                    ["class", "col grid grid-center grid-column body-paytable-container"]
                ], null, null, null, null, null)), (n()(), e.Ib(2, 0, null, null, 2, "div", [], [
                    [8, "className", 0],
                    [2, "body-paytable--two-columns", null],
                    [2, "one-column-per-row", null]
                ], null, null, null, null)), (n()(), e.xb(16777216, null, null, 1, null, c)), e.Hb(4, 278528, null, 0, o.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null), (n()(), e.xb(0, [
                    ["shortMarket", 2]
                ], null, 0, null, k)), (n()(), e.xb(0, [
                    ["longMarket", 2]
                ], null, 0, null, D))], (function(n, t) {
                    n(t, 4, 0, t.component.paytableGame)
                }), (function(n, t) {
                    var l = t.component;
                    n(t, 2, 0, e.Mb(1, "body-paytable col grid grid-", l.columnsPerRow[l.buttonSelected], " grid-center"), 2 === l.columnsPerRow[l.buttonSelected], 1 === l.columnsPerRow[l.buttonSelected])
                }))
            }
            e.Eb("grc-body-paytable", r.a, (function(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "grc-body-paytable", [], null, null, null, j, a)), e.Hb(1, 49152, null, 0, r.a, [], null, null)], null, null)
            }), {
                paytableGame: "paytableGame",
                playlist: "playlist",
                isS2Wheels: "isS2Wheels",
                isRainbow: "isRainbow",
                isKinel8: "isKinel8",
                hasX: "hasX",
                buttons: "buttons",
                columnsPerRow: "columnsPerRow",
                buttonSelected: "buttonSelected"
            }, {
                selectedChange: "selectedChange"
            }, [])
        },
        pQ2l: function(n, t, l) {
            "use strict";
            l.d(t, "a", (function() {
                return a
            })), l.d(t, "b", (function() {
                return s
            }));
            var e = l("CcnG"),
                o = l("5EE+"),
                i = l("Ip0R"),
                r = l("ghVy"),
                u = [
                    [".tab-button[_ngcontent-%COMP%]{padding:14px 20px;font-size:18px;font-weight:700;text-transform:uppercase;cursor:pointer;outline:0}"]
                ],
                a = e.Gb({
                    encapsulation: 0,
                    styles: u,
                    data: {}
                });

            function c(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 2, "button", [
                    ["class", "tab-button"]
                ], [
                    [2, "tab-button--active", null]
                ], [
                    [null, "click"]
                ], (function(n, t, l) {
                    var e = !0,
                        o = n.component;
                    "click" === t && (e = !1 !== o.select(n.context.index) && e);
                    return e
                }), null, null)), (n()(), e.cc(1, null, [" ", "\n"])), e.Wb(131072, o.j, [o.k, e.i])], null, (function(n, t) {
                    var l = t.component;
                    n(t, 0, 0, t.context.$implicit.id === l.selected), n(t, 1, 0, e.dc(t, 1, 0, e.Ub(t, 2).transform(t.context.$implicit.title)))
                }))
            }

            function s(n) {
                return e.ec(2, [(n()(), e.xb(16777216, null, null, 1, null, c)), e.Hb(1, 278528, null, 0, i.l, [e.eb, e.Z, e.A], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(n, t) {
                    n(t, 1, 0, t.component.buttons)
                }), null)
            }
            e.Eb("grc-tab-buttons", r.a, (function(n) {
                return e.ec(0, [(n()(), e.Ib(0, 0, null, null, 1, "grc-tab-buttons", [], null, null, null, s, a)), e.Hb(1, 4308992, null, 0, r.a, [e.i], null, null)], (function(n, t) {
                    n(t, 1, 0)
                }), null)
            }), {
                buttons: "buttons"
            }, {
                selectedChange: "selectedChange"
            }, [])
        }
    }
]);