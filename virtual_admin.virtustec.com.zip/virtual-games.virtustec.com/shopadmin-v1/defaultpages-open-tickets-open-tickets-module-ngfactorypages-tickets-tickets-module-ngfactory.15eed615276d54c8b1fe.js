(window.webpackJsonp = window.webpackJsonp || []).push([
    [4], {
        "5SgW": function(l, n, t) {
            "use strict";
            t.d(n, "a", (function() {
                return e
            }));
            var e = function() {
                return function() {}
            }()
        },
        B0aO: function(l, n, t) {
            "use strict";
            t.d(n, "a", (function() {
                return o
            }));
            var e = t("CrY/"),
                u = t("psW0"),
                i = (t("t01L"), t("agnC"), function() {
                    for (var l = 0, n = 0, t = arguments.length; n < t; n++) l += arguments[n].length;
                    var e = Array(l),
                        u = 0;
                    for (n = 0; n < t; n++)
                        for (var i = arguments[n], o = 0, r = i.length; o < r; o++, u++) e[u] = i[o];
                    return e
                }),
                o = function() {
                    function l(l, n, t, u, i) {
                        this.cd = l, this.router = n, this.route = t, this.coreService = u, this.ticketService = i, this.ticketEventsGrouped = [], this.hideTicketId = !1, this.ValEnum = e.coreModel.GameType.ValEnum, this.clazz = !0
                    }
                    return l.prototype.ngOnInit = function() {
                        var l, n = this;
                        this.hideTicketId = this.coreService.getShopadminProfileSettings().hideTicketId, this.routeSubscription = this.route.data.pipe(Object(u.a)((function(t) {
                            return l = t, n.route.params
                        })), Object(u.a)((function(l) {
                            return n.ticketService.getTicket(l.ticketId)
                        }))).subscribe((function(t) {
                            t.length > 0 && (l.canShowOpen && t[0]._clData.isOpenOrPending() || l.canShowTickets && !t[0]._clData.isOpenOrPending()) ? (n.serverTicket = t[0], n.groupTicketEventsByEventBlock(), n.cd.detectChanges()) : n.onBack()
                        }))
                    }, l.prototype.ngOnDestroy = function() {
                        this.routeSubscription && this.routeSubscription.unsubscribe()
                    }, l.prototype.onBack = function() {
                        this.router.navigate(["../"], {
                            relativeTo: this.route,
                            queryParamsHandling: "preserve"
                        })
                    }, l.prototype.groupTicketEventsByEventBlock = function() {
                        this.ticketEventsGrouped = this.serverTicket.details.events.sort((function(l, n) {
                            return l.playlistId - n.playlistId || l.eventTime.getTime() - n.eventTime.getTime()
                        })).reduce((function(l, n) {
                            return l.length && l[l.length - 1][0].playlistId === n.playlistId && l[l.length - 1][0].eventTime.getTime() === n.eventTime.getTime() ? (l[l.length - 1].push(n), l) : i(l, [
                                [n]
                            ])
                        }), [])
                    }, l
                }()
        },
        H32O: function(l, n, t) {
            "use strict";
            t.d(n, "a", (function() {
                return e
            })), t("eFR5");
            var e = function() {
                return function() {}
            }()
        },
        OeD6: function(l, n, t) {
            "use strict";
            t.d(n, "a", (function() {
                return e
            }));
            var e = function() {
                return function() {}
            }()
        },
        eFR5: function(l, n, t) {
            "use strict";
            t.d(n, "a", (function() {
                return u
            }));
            var e = t("CrY/"),
                u = function() {
                    function l() {}
                    return l.prototype.transform = function(l, n, t) {
                        return t === e.coreModel.ChCompetitionType.SOCCER ? "" + this.getChampId(l) : n ? "CHAMPION" !== t && "WORLDCUP" !== t ? this.getChampId(l) + "/" + this.getMatchDay(l) : this.getChampId(l) + "/" + this.getMatchDay(l) + this.getWeekDay(l) : "WORLDCUP" === t ? this.getChampId(l) + "/" + this.getMatchDay(l) : this.getChampId(l) + "/" + this.getMatchDay(l) + this.getLegOrder(l)
                    }, l.prototype.getChampId = function(l) {
                        return this.getEventBlockData(l).champId
                    }, l.prototype.getWeekDay = function(l) {
                        return this.getEventBlockData(l).weekDay
                    }, l.prototype.getMatchDay = function(l) {
                        var n = this.getEventBlockData(l).matchDay;
                        return n < 10 ? "0" + n : n
                    }, l.prototype.getLegOrder = function(l) {
                        return this.getEventBlockData(l).legOrder
                    }, l.prototype.getEventBlockData = function(l) {
                        return l && l.data.isChEventBlockData() && l.data
                    }, l
                }()
        },
        pDrR: function(l, n, t) {
            "use strict";
            var e = t("CcnG"),
                u = ["[_nghost-%COMP%]{display:block;background-color:#eceff1}[_nghost-%COMP%]     .table{margin-top:0!important}[_nghost-%COMP%]     .table .table__header .table-cell{background-color:#eceff1}.ticket-event-info__header[_ngcontent-%COMP%]{padding:20px 18px;border:1px solid #c9c9c9;border-bottom:0}.ticket-event-info__won[_ngcontent-%COMP%]{color:#417505}.info-label[_ngcontent-%COMP%]{margin-bottom:8px;font-size:12px;color:#002d40}.info-value[_ngcontent-%COMP%]{font-size:24px;color:#002d40;text-transform:capitalize}"],
                i = t("5EE+"),
                o = t("Ip0R"),
                r = t("CrY/"),
                a = t("lql9"),
                c = function() {
                    function l(l, n) {
                        this.oddService = l, this.cd = n
                    }
                    return l.prototype.ngOnDestroy = function() {
                        var l;
                        null === (l = this.oddFormat) || void 0 === l || l.unsubscribe()
                    }, l.prototype.transform = function(l) {
                        var n = this;
                        return this.oddFormat = this.oddService.oddFormat$.subscribe((function(t) {
                            return n.updateValue(l, t)
                        })), this.oddValue
                    }, l.prototype.updateValue = function(l, n) {
                        var t = l instanceof r.coreModel.Odd ? l.value : l.oddValue;
                        switch (n) {
                            case r.coreModel.Odd.OddFormatEnum.DECIMAL:
                                this.oddValue = t;
                                break;
                            case r.coreModel.Odd.OddFormatEnum.HK:
                                this.oddValue = l._clData.hongKongValue;
                                break;
                            case r.coreModel.Odd.OddFormatEnum.AMERICAN_ROUNDED:
                                this.oddValue = l._clData.americanRoundedValue;
                                break;
                            default:
                                this.oddValue = l._clData[n.toLowerCase() + "Value"]
                        }
                        this.cd.markForCheck()
                    }, l
                }(),
                s = t("kmhj"),
                b = t("9pw4"),
                d = t("mrSG"),
                f = t("WGel"),
                p = t("Qkcr"),
                v = t("t01L"),
                g = t("7Dvu"),
                m = function() {
                    function l(l, n) {
                        var t = this;
                        this.i18nService = l, this.coreService = n, this.ticketBets = [], this.clazz = !0, this.columns = [{
                            id: "Match",
                            title: this.i18nService.get("sa_match"),
                            grow: 210
                        }, {
                            id: "Bet",
                            title: this.i18nService.get("ch_markets"),
                            function: function(l) {
                                return t.getBet(l)
                            },
                            grow: 100,
                            span: !1
                        }, {
                            id: "Selection",
                            title: this.i18nService.get("ch_selection"),
                            function: function(l) {
                                return t.getSelection(l)
                            },
                            grow: 170,
                            span: !0
                        }, {
                            id: "Odd",
                            title: this.i18nService.get("sa_odd"),
                            grow: 96
                        }, {
                            id: "Stake",
                            title: this.i18nService.get("sa_stake"),
                            grow: 96
                        }, {
                            id: "Won",
                            title: this.i18nService.get("sa_won"),
                            grow: 80
                        }, {
                            id: "Currency",
                            title: this.i18nService.get("sa_currency"),
                            grow: 80
                        }, {
                            id: "Status",
                            title: this.i18nService.get("sa_status"),
                            function: function(l) {
                                return t.i18nService.get("sa_ticket_status_" + l.status.toLowerCase())
                            },
                            grow: 70
                        }]
                    }
                    return Object.defineProperty(l.prototype, "eventIdGLTemplate", {
                        set: function(l) {
                            var n = this.columns.find((function(l) {
                                return "Match" === l.id
                            }));
                            n && (n.templateRef = l)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(l.prototype, "wonTemplate", {
                        set: function(l) {
                            var n = this.columns.find((function(l) {
                                return "Won" === l.id
                            }));
                            n && (n.templateRef = l)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(l.prototype, "stakeTemplate", {
                        set: function(l) {
                            var n = this.columns.find((function(l) {
                                return "Stake" === l.id
                            }));
                            n && (n.templateRef = l)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(l.prototype, "oddTemplate", {
                        set: function(l) {
                            var n = this.columns.find((function(l) {
                                return "Odd" === l.id
                            }));
                            n && (n.templateRef = l)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), l.prototype.ngOnInit = function() {
                        if ((this.serverTicket._clData.isOpen() || this.serverTicket._clData.isPending()) && (this.removeColumn("Won"), this.removeColumn("Status")), this.serverTicket.details.systemBets.length > 0 && (this.removeColumn("Stake"), this.removeColumn("Won")), this.serverTicket._clData.isCancelled()) {
                            var l = this.columns.find((function(l) {
                                return "Won" === l.id
                            }));
                            l && (l.title = this.i18nService.get("sa_refund")), this.removeColumn("Stake")
                        }
                        this.columns.find((function(l) {
                            return "Currency" === l.id
                        })).text = this.serverTicket.currency.code, this.playList = this.coreService.getPlaylistById(this.serverTicket.details.events[0].playlistId), this.setEventIdTitleColumn(), this.ticketBets = this.ticketEvents.reduce((function(l, n) {
                            return n.gameType.val === r.coreModel.GameType.ValEnum.GRANDPRIX && n.bets.find((function(l) {
                                return "show" === l.marketId
                            })) && n.bets.map((function(l) {
                                return l.marketId = "show" === l.marketId ? "grandprix_show" : l.marketId
                            })), l.push.apply(l, n.bets), l
                        }), [])
                    }, l.prototype.getBet = function(l) {
                        var n = this.ticketEvents[0].gameType.val.toString();
                        return this.i18nService.getMarketTag(n === f.I18NGameType.MMA ? "mma_" + l.marketId : l.marketId)
                    }, l.prototype.getSelection = function(l) {
                        var n = this.ticketEvents[0].gameType.val.toString();
                        if (Object(g.c)(this.playList)) return this.i18nService.getMarketOptionTag(f.I18NGameType[n], l.oddId, "", l.betParam, f.TagsProfile.TICKET, this.playList.assets);
                        if (n === f.I18NGameType.MMA) return "round" !== l.oddId ? "" + this.i18nService.getMarketOptionTag(f.I18NGameType.MMA, l.oddId) : "" + this.i18nService.getMarketOptionTag(f.I18NGameType.MMA, l.betParam);
                        if (l.betParam) {
                            var t = this.i18nService.getMarketOptionTag(f.I18NGameType[n], l.oddId, "", l.betParam);
                            return t.length > 0 ? t : l.betParam
                        }
                        var e = this.i18nService.getMarketOptionTag(f.I18NGameType[n], l.oddId, l.marketId);
                        return e.length > 0 ? e : l.oddId
                    }, l.prototype.getParticipants = function(l) {
                        return this.getTicketEventByBetIndex(l).data.participants
                    }, l.prototype.isTicketBetWon = function(l) {
                        return l.status === r.coreModel.TicketBet.StatusEnum.WON
                    }, l.prototype.isServerTicketCancelled = function() {
                        return this.serverTicket._clData.isCancelled()
                    }, l.prototype.getWonQuantity = function(l) {
                        return this.isTicketBetWon(l) ? l._clData.getWinningSingleItemized() : l._clData.getStakeSingleItemized().gross
                    }, l.prototype.getCancelledStake = function(l) {
                        return l._clData.getCancelledStakeSingleItemized().netRounded
                    }, l.prototype.isLeague = function() {
                        var l = this.serverTicket.details.events[0].data;
                        return l && l.isChTicketEventData() && l.competitionType === r.coreModel.ChCompetitionType.LEAGUE
                    }, l.prototype.getLeagueId = function() {
                        var l = this.serverTicket.details.events[0];
                        return (l.data.isChTicketEventData() && l.data.competitionType) === r.coreModel.ChCompetitionType.LEAGUE ? l.data.isChTicketEventData() && l.data.data.champId + "/" + l.data.data.matchDay : "TODO"
                    }, l.prototype.getGameName = function() {
                        return this.isFootball() ? this.getCompetitionType() : this.isKinel8(this.serverTicket.details.events[0].playlistId) ? this.serverTicket.details.events[0].playlistDescription : Object(g.c)(this.playList) ? "colourcolour" : this.ticketEvents[0].gameType.val
                    }, l.prototype.getCompetitionSubType = function() {
                        return this.serverTicket.details.events[0].data.competitionSubType
                    }, l.prototype.isKinel8 = function(l) {
                        var n = this.coreService.getPlaylistById(l);
                        return n && n.assets && "kinel8" === n.assets.iconId
                    }, l.prototype.isFootball = function() {
                        return this.serverTicket.details.events[0].gameType.val === r.coreModel.GameType.ValEnum.CH
                    }, l.prototype.getCompetitionType = function() {
                        var l = this.serverTicket.details.events[0].data;
                        return l ? l.isChTicketEventData() && l.competitionType : null
                    }, l.prototype.getTicketEventByBetIndex = function(l) {
                        for (var n, t = 0, e = 0, u = this.ticketEvents; e < u.length; e++) {
                            var i = u[e];
                            if (!(i.bets.length + t <= l)) {
                                n = i;
                                break
                            }
                            t += i.bets.length
                        }
                        return n
                    }, l.prototype.removeColumn = function(l) {
                        var n = this.columns.findIndex((function(n) {
                            return n.id === l
                        }));
                        n > -1 && this.columns.splice(n, 1)
                    }, l.prototype.getColumn = function(l) {
                        return this.columns.find((function(n) {
                            return n.id === l
                        }))
                    }, l.prototype.setEventIdTitleColumn = function() {
                        switch (this.serverTicket.gameType[0]) {
                            case r.coreModel.GameType.ValEnum.CH:
                                this.columns.find((function(l) {
                                    return "Match" === l.id
                                })).title = this.i18nService.get("sa_match");
                                break;
                            default:
                                this.removeColumn("Match"), this.getColumn("Bet").span = !1
                        }
                    }, l
                }(),
                h = function(l) {
                    function n(n, t) {
                        return l.call(this, n, t) || this
                    }
                    return Object(d.__extends)(n, l), n.prototype.getSelection = function(l) {
                        var n = this.ticketEvents[0].gameType.val.toString();
                        return this.i18nService.getMarketOptionTag(f.I18NGameType[n], this.getChampionsOddName(l))
                    }, n.prototype.getChampionsOddName = function(l) {
                        var n = this.serverTicket.details.events[0],
                            t = n.data.isChTicketEventData() && n.data.data.phase,
                            e = l.marketId.startsWith("Qualify"),
                            u = l.oddId;
                        return e && (u = t.toLowerCase() + "_" + l.oddId), u
                    }, n
                }(m),
                k = e.sb({
                    encapsulation: 0,
                    styles: [u],
                    data: {}
                });

            function T(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 3, "div", [
                    ["class", "info-value"]
                ], null, null, null, null, null)), (l()(), e.Nb(1, null, [" ", " [ ", " ] "])), e.Hb(131072, i.i, [i.j, e.i]), e.Jb(3, 1)], null, (function(l, n) {
                    var t = n.component,
                        u = t.ticketEvents[0].eventId,
                        i = e.Ob(n, 1, 1, l(n, 3, 0, e.Gb(n.parent.parent, 0), e.Ob(n, 1, 1, e.Gb(n, 2).transform("sa_game_" + t.getGameName().toLowerCase()))));
                    l(n, 1, 0, u, i)
                }))
            }

            function y(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 3, "div", [
                    ["class", "info-value"]
                ], null, null, null, null, null)), (l()(), e.Nb(1, null, [" ", " [ ", " ] "])), e.Hb(131072, i.i, [i.j, e.i]), e.Jb(3, 1)], null, (function(l, n) {
                    var t = n.component,
                        u = t.ticketEvents[0].eventId,
                        i = e.Ob(n, 1, 1, l(n, 3, 0, e.Gb(n.parent.parent, 0), e.Ob(n, 1, 1, e.Gb(n, 2).transform("sa_game_" + t.getCompetitionSubType().toLowerCase()))));
                    l(n, 1, 0, u, i)
                }))
            }

            function O(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 8, null, null, null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 7, "div", [
                    ["class", "info-group"]
                ], null, null, null, null, null)), (l()(), e.ub(2, 0, null, null, 2, "div", [
                    ["class", "info-label"]
                ], null, null, null, null, null)), (l()(), e.Nb(3, null, ["", ""])), e.Hb(131072, i.i, [i.j, e.i]), (l()(), e.jb(16777216, null, null, 1, null, T)), e.tb(6, 16384, null, 0, o.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.jb(16777216, null, null, 1, null, y)), e.tb(8, 16384, null, 0, o.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(l, n) {
                    var t = n.component;
                    l(n, 6, 0, "CHAMPION" !== t.getCompetitionType()), l(n, 8, 0, "CHAMPION" === t.getCompetitionType())
                }), (function(l, n) {
                    l(n, 3, 0, e.Ob(n, 3, 0, e.Gb(n, 4).transform("sa_event_id")))
                }))
            }

            function I(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 7, "div", [
                    ["class", "info-group"]
                ], null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 2, "div", [
                    ["class", "info-label"]
                ], null, null, null, null, null)), (l()(), e.Nb(2, null, ["", ""])), e.Hb(131072, i.i, [i.j, e.i]), (l()(), e.ub(4, 0, null, null, 3, "div", [
                    ["class", "info-value"]
                ], null, null, null, null, null)), (l()(), e.Nb(5, null, ["", " [ ", " ]"])), e.Hb(131072, i.i, [i.j, e.i]), e.Jb(7, 1)], null, (function(l, n) {
                    var t = n.component;
                    l(n, 2, 0, e.Ob(n, 2, 0, e.Gb(n, 3).transform("sa_league_id")));
                    var u = t.getLeagueId(),
                        i = e.Ob(n, 5, 1, l(n, 7, 0, e.Gb(n.parent, 0), e.Ob(n, 5, 1, e.Gb(n, 6).transform("sa_game_" + t.getGameName().toLowerCase()))));
                    l(n, 5, 0, u, i)
                }))
            }

            function _(l) {
                return e.Pb(0, [(l()(), e.Nb(0, null, [" ", " - ", "\n"]))], null, (function(l, n) {
                    var t = n.component;
                    l(n, 0, 0, t.getParticipants(n.context.index)[0].fifaCode, t.getParticipants(n.context.index)[1].fifaCode)
                }))
            }

            function C(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 3, "span", [], [
                    [2, "ticket-event-info__won", null]
                ], null, null, null, null)), (l()(), e.Nb(1, null, [" ", " "])), e.Ib(2, {
                    showSymbol: 0,
                    currency: 1
                }), e.Hb(131072, i.b, [i.j, e.i])], null, (function(l, n) {
                    var t = n.component;
                    l(n, 0, 0, t.isTicketBetWon(n.parent.context.data));
                    var u = e.Ob(n, 1, 0, e.Gb(n, 3).transform(t.getWonQuantity(n.parent.context.data).win, l(n, 2, 0, !1, t.serverTicket.currency)));
                    l(n, 1, 0, u)
                }))
            }

            function P(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 3, "span", [], null, null, null, null, null)), (l()(), e.Nb(1, null, [" ", " "])), e.Ib(2, {
                    showSymbol: 0,
                    currency: 1
                }), e.Hb(131072, i.b, [i.j, e.i])], null, (function(l, n) {
                    var t = n.component,
                        u = e.Ob(n, 1, 0, e.Gb(n, 3).transform(t.getCancelledStake(n.parent.parent.context.data), l(n, 2, 0, !1, t.serverTicket.currency)));
                    l(n, 1, 0, u)
                }))
            }

            function j(l) {
                return e.Pb(0, [(l()(), e.jb(16777216, null, null, 1, null, P)), e.tb(1, 16384, null, 0, o.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"],
                    ngIfElse: [1, "ngIfElse"]
                }, null), (l()(), e.jb(0, null, null, 0))], (function(l, n) {
                    l(n, 1, 0, n.component.isServerTicketCancelled(), e.Gb(n.parent, 3))
                }), null)
            }

            function G(l) {
                return e.Pb(0, [(l()(), e.Nb(0, null, ["", ""])), e.Ib(1, {
                    showSymbol: 0,
                    currency: 1
                }), e.Hb(131072, i.b, [i.j, e.i])], null, (function(l, n) {
                    var t = n.component,
                        u = e.Ob(n, 0, 0, e.Gb(n, 2).transform(0, l(n, 1, 0, !1, t.serverTicket.currency)));
                    l(n, 0, 0, u)
                }))
            }

            function S(l) {
                return e.Pb(0, [(l()(), e.jb(16777216, null, null, 1, null, C)), e.tb(1, 16384, null, 0, o.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"],
                    ngIfElse: [1, "ngIfElse"]
                }, null), (l()(), e.jb(0, [
                    ["refundTemplate", 2]
                ], null, 0, null, j)), (l()(), e.jb(0, [
                    ["lostTemplate", 2]
                ], null, 0, null, G))], (function(l, n) {
                    l(n, 1, 0, n.component.isTicketBetWon(n.context.data), e.Gb(n, 2))
                }), null)
            }

            function x(l) {
                return e.Pb(0, [(l()(), e.Nb(0, null, [" ", "\n"])), e.Ib(1, {
                    showSymbol: 0,
                    currency: 1
                }), e.Hb(131072, i.b, [i.j, e.i])], null, (function(l, n) {
                    var t = n.component,
                        u = e.Ob(n, 0, 0, e.Gb(n, 2).transform(n.context.data._clData.getStakeSingleItemized().gross, l(n, 1, 0, !1, t.serverTicket.currency)));
                    l(n, 0, 0, u)
                }))
            }

            function N(l) {
                return e.Pb(0, [(l()(), e.Nb(0, null, [" ", "\n"])), e.Hb(131072, c, [a.a, e.i])], null, (function(l, n) {
                    l(n, 0, 0, e.Ob(n, 0, 0, e.Gb(n, 1).transform(n.context.data)))
                }))
            }

            function M(l) {
                return e.Pb(2, [e.Hb(0, o.h, []), e.Lb(402653184, 1, {
                    eventIdGLTemplate: 0
                }), e.Lb(402653184, 2, {
                    wonTemplate: 0
                }), e.Lb(402653184, 3, {
                    stakeTemplate: 0
                }), e.Lb(402653184, 4, {
                    oddTemplate: 0
                }), (l()(), e.ub(5, 0, null, null, 3, "div", [
                    ["class", "ticket-event-info__header"]
                ], null, null, null, null, null)), (l()(), e.jb(16777216, null, null, 1, null, O)), e.tb(7, 16384, null, 0, o.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"],
                    ngIfElse: [1, "ngIfElse"]
                }, null), (l()(), e.jb(0, [
                    ["glInfoHeader", 2]
                ], null, 0, null, I)), (l()(), e.ub(9, 0, null, null, 1, "grsa-table", [
                    ["class", "table"]
                ], [
                    [2, "table", null]
                ], null, null, s.b, s.a)), e.tb(10, 4308992, null, 0, b.c, [e.i, e.l], {
                    columns: [0, "columns"],
                    rows: [1, "rows"]
                }, null), (l()(), e.jb(0, [
                    [1, 2],
                    ["eventIdGLTemplate", 2]
                ], null, 0, null, _)), (l()(), e.jb(0, [
                    [2, 2],
                    ["wonTemplate", 2]
                ], null, 0, null, S)), (l()(), e.jb(0, [
                    [3, 2],
                    ["stakeTemplate", 2]
                ], null, 0, null, x)), (l()(), e.jb(0, [
                    [4, 2],
                    ["oddTemplate", 2]
                ], null, 0, null, N))], (function(l, n) {
                    var t = n.component;
                    l(n, 7, 0, !t.isLeague(), e.Gb(n, 8)), l(n, 10, 0, t.columns, t.ticketBets)
                }), (function(l, n) {
                    l(n, 9, 0, e.Gb(n, 10).clazz)
                }))
            }
            var w = e.sb({
                encapsulation: 0,
                styles: [u],
                data: {}
            });

            function E(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 3, "div", [
                    ["class", "info-value"]
                ], null, null, null, null, null)), (l()(), e.Nb(1, null, [" ", " [ ", " ] "])), e.Hb(131072, i.i, [i.j, e.i]), e.Jb(3, 1)], null, (function(l, n) {
                    var t = n.component,
                        u = t.ticketEvents[0].eventId,
                        i = e.Ob(n, 1, 1, l(n, 3, 0, e.Gb(n.parent.parent, 0), e.Ob(n, 1, 1, e.Gb(n, 2).transform("sa_game_" + t.getGameName().toLowerCase()))));
                    l(n, 1, 0, u, i)
                }))
            }

            function D(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 3, "div", [
                    ["class", "info-value"]
                ], null, null, null, null, null)), (l()(), e.Nb(1, null, [" ", " [ ", " ] "])), e.Hb(131072, i.i, [i.j, e.i]), e.Jb(3, 1)], null, (function(l, n) {
                    var t = n.component,
                        u = t.ticketEvents[0].eventId,
                        i = e.Ob(n, 1, 1, l(n, 3, 0, e.Gb(n.parent.parent, 0), e.Ob(n, 1, 1, e.Gb(n, 2).transform("sa_game_" + t.getCompetitionSubType().toLowerCase()))));
                    l(n, 1, 0, u, i)
                }))
            }

            function H(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 8, null, null, null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 7, "div", [
                    ["class", "info-group"]
                ], null, null, null, null, null)), (l()(), e.ub(2, 0, null, null, 2, "div", [
                    ["class", "info-label"]
                ], null, null, null, null, null)), (l()(), e.Nb(3, null, ["", ""])), e.Hb(131072, i.i, [i.j, e.i]), (l()(), e.jb(16777216, null, null, 1, null, E)), e.tb(6, 16384, null, 0, o.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.jb(16777216, null, null, 1, null, D)), e.tb(8, 16384, null, 0, o.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(l, n) {
                    var t = n.component;
                    l(n, 6, 0, "CHAMPION" !== t.getCompetitionType()), l(n, 8, 0, "CHAMPION" === t.getCompetitionType())
                }), (function(l, n) {
                    l(n, 3, 0, e.Ob(n, 3, 0, e.Gb(n, 4).transform("sa_event_id")))
                }))
            }

            function L(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 7, "div", [
                    ["class", "info-group"]
                ], null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 2, "div", [
                    ["class", "info-label"]
                ], null, null, null, null, null)), (l()(), e.Nb(2, null, ["", ""])), e.Hb(131072, i.i, [i.j, e.i]), (l()(), e.ub(4, 0, null, null, 3, "div", [
                    ["class", "info-value"]
                ], null, null, null, null, null)), (l()(), e.Nb(5, null, ["", " [ ", " ]"])), e.Hb(131072, i.i, [i.j, e.i]), e.Jb(7, 1)], null, (function(l, n) {
                    var t = n.component;
                    l(n, 2, 0, e.Ob(n, 2, 0, e.Gb(n, 3).transform("sa_league_id")));
                    var u = t.getLeagueId(),
                        i = e.Ob(n, 5, 1, l(n, 7, 0, e.Gb(n.parent, 0), e.Ob(n, 5, 1, e.Gb(n, 6).transform("sa_game_" + t.getGameName().toLowerCase()))));
                    l(n, 5, 0, u, i)
                }))
            }

            function z(l) {
                return e.Pb(0, [(l()(), e.Nb(0, null, [" ", " - ", "\n"]))], null, (function(l, n) {
                    var t = n.component;
                    l(n, 0, 0, t.getParticipants(n.context.index)[0].fifaCode, t.getParticipants(n.context.index)[1].fifaCode)
                }))
            }

            function R(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 3, "span", [], [
                    [2, "ticket-event-info__won", null]
                ], null, null, null, null)), (l()(), e.Nb(1, null, [" ", " "])), e.Ib(2, {
                    showSymbol: 0,
                    currency: 1
                }), e.Hb(131072, i.b, [i.j, e.i])], null, (function(l, n) {
                    var t = n.component;
                    l(n, 0, 0, t.isTicketBetWon(n.parent.context.data));
                    var u = e.Ob(n, 1, 0, e.Gb(n, 3).transform(t.getWonQuantity(n.parent.context.data).win, l(n, 2, 0, !1, t.serverTicket.currency)));
                    l(n, 1, 0, u)
                }))
            }

            function B(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 3, "span", [], null, null, null, null, null)), (l()(), e.Nb(1, null, [" ", " "])), e.Ib(2, {
                    showSymbol: 0,
                    currency: 1
                }), e.Hb(131072, i.b, [i.j, e.i])], null, (function(l, n) {
                    var t = n.component,
                        u = e.Ob(n, 1, 0, e.Gb(n, 3).transform(t.getCancelledStake(n.parent.parent.context.data), l(n, 2, 0, !1, t.serverTicket.currency)));
                    l(n, 1, 0, u)
                }))
            }

            function W(l) {
                return e.Pb(0, [(l()(), e.jb(16777216, null, null, 1, null, B)), e.tb(1, 16384, null, 0, o.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"],
                    ngIfElse: [1, "ngIfElse"]
                }, null), (l()(), e.jb(0, null, null, 0))], (function(l, n) {
                    l(n, 1, 0, n.component.isServerTicketCancelled(), e.Gb(n.parent, 3))
                }), null)
            }

            function F(l) {
                return e.Pb(0, [(l()(), e.Nb(0, null, ["", ""])), e.Ib(1, {
                    showSymbol: 0,
                    currency: 1
                }), e.Hb(131072, i.b, [i.j, e.i])], null, (function(l, n) {
                    var t = n.component,
                        u = e.Ob(n, 0, 0, e.Gb(n, 2).transform(0, l(n, 1, 0, !1, t.serverTicket.currency)));
                    l(n, 0, 0, u)
                }))
            }

            function V(l) {
                return e.Pb(0, [(l()(), e.jb(16777216, null, null, 1, null, R)), e.tb(1, 16384, null, 0, o.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"],
                    ngIfElse: [1, "ngIfElse"]
                }, null), (l()(), e.jb(0, [
                    ["refundTemplate", 2]
                ], null, 0, null, W)), (l()(), e.jb(0, [
                    ["lostTemplate", 2]
                ], null, 0, null, F))], (function(l, n) {
                    l(n, 1, 0, n.component.isTicketBetWon(n.context.data), e.Gb(n, 2))
                }), null)
            }

            function A(l) {
                return e.Pb(0, [(l()(), e.Nb(0, null, [" ", "\n"])), e.Ib(1, {
                    showSymbol: 0,
                    currency: 1
                }), e.Hb(131072, i.b, [i.j, e.i])], null, (function(l, n) {
                    var t = n.component,
                        u = e.Ob(n, 0, 0, e.Gb(n, 2).transform(n.context.data._clData.getStakeSingleItemized().gross, l(n, 1, 0, !1, t.serverTicket.currency)));
                    l(n, 0, 0, u)
                }))
            }

            function J(l) {
                return e.Pb(0, [(l()(), e.Nb(0, null, [" ", "\n"])), e.Hb(131072, c, [a.a, e.i])], null, (function(l, n) {
                    l(n, 0, 0, e.Ob(n, 0, 0, e.Gb(n, 1).transform(n.context.data)))
                }))
            }

            function Q(l) {
                return e.Pb(2, [e.Hb(0, o.h, []), e.Lb(402653184, 1, {
                    eventIdGLTemplate: 0
                }), e.Lb(402653184, 2, {
                    wonTemplate: 0
                }), e.Lb(402653184, 3, {
                    stakeTemplate: 0
                }), e.Lb(402653184, 4, {
                    oddTemplate: 0
                }), (l()(), e.ub(5, 0, null, null, 3, "div", [
                    ["class", "ticket-event-info__header"]
                ], null, null, null, null, null)), (l()(), e.jb(16777216, null, null, 1, null, H)), e.tb(7, 16384, null, 0, o.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"],
                    ngIfElse: [1, "ngIfElse"]
                }, null), (l()(), e.jb(0, [
                    ["glInfoHeader", 2]
                ], null, 0, null, L)), (l()(), e.ub(9, 0, null, null, 1, "grsa-table", [
                    ["class", "table"]
                ], [
                    [2, "table", null]
                ], null, null, s.b, s.a)), e.tb(10, 4308992, null, 0, b.c, [e.i, e.l], {
                    columns: [0, "columns"],
                    rows: [1, "rows"]
                }, null), (l()(), e.jb(0, [
                    [1, 2],
                    ["eventIdGLTemplate", 2]
                ], null, 0, null, z)), (l()(), e.jb(0, [
                    [2, 2],
                    ["wonTemplate", 2]
                ], null, 0, null, V)), (l()(), e.jb(0, [
                    [3, 2],
                    ["stakeTemplate", 2]
                ], null, 0, null, A)), (l()(), e.jb(0, [
                    [4, 2],
                    ["oddTemplate", 2]
                ], null, 0, null, J))], (function(l, n) {
                    var t = n.component;
                    l(n, 7, 0, !t.isLeague(), e.Gb(n, 8)), l(n, 10, 0, t.columns, t.ticketBets)
                }), (function(l, n) {
                    l(n, 9, 0, e.Gb(n, 10).clazz)
                }))
            }
            var $ = function() {
                    function l(l) {
                        this.coreService = l, this.hideTicketId = !1, this.clazz = !0, this.iconName = "", this.gameName = "", this.showPrintButton = !1
                    }
                    return l.prototype.ngOnInit = function() {
                        this.playList = this.coreService.getPlaylistById(this.serverTicket.details.events[0].playlistId), this.iconName = this.playList ? Object(g.b)(this.playList) : "", this.gameName = this.playList ? Object(g.a)(this.playList, this.serverTicket.details.events[0].playlistDescription) : ""
                    }, l.prototype.print = function() {
                        if (!this.serverTicket.timePrint) {
                            var l = new r.coreModel.ServerTicket;
                            Object.assign(l, this.serverTicket), l.status = p.TicketStatus.OPEN, this.coreService.getPrintTicketController().reprint(l)
                        }
                    }, l.prototype.isServerTicketCancelled = function() {
                        return this.serverTicket._clData.isCancelled()
                    }, l.prototype.getWonQuantity = function() {
                        return this.isServerTicketCancelled() ? this.serverTicket._clData.getTotalStakeItemized().gross : this.serverTicket._clData.getTotalWonItemized().netRounded
                    }, l
                }(),
                K = e.sb({
                    encapsulation: 0,
                    styles: [
                        [".game-icon[_ngcontent-%COMP%]{font-size:32px}.info-group[_ngcontent-%COMP%] + .info-group[_ngcontent-%COMP%]{margin-top:20px}.info-label[_ngcontent-%COMP%]{margin-bottom:8px;font-size:12px;color:#a9b6be}.info-value[_ngcontent-%COMP%]{font-size:24px;color:#002d40;text-transform:capitalize}.info-value--small[_ngcontent-%COMP%]{font-size:18px}.info-value--big[_ngcontent-%COMP%]{font-size:36px}.info-value--success[_ngcontent-%COMP%]{color:#417505}.info-print-button[_ngcontent-%COMP%]{padding:8px;font-weight:700;color:#274a5c;cursor:pointer;border:1px solid #163c4c;box-shadow:0 2px 2px 0 rgba(119,151,178,.16);font-size:38px}"]
                    ],
                    data: {}
                });

            function U(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 3, "div", [
                    ["class", "col info-value"]
                ], null, null, null, null, null)), (l()(), e.Nb(1, null, [" ", " "])), e.Hb(131072, i.i, [i.j, e.i]), e.Jb(3, 1)], null, (function(l, n) {
                    var t = n.component,
                        u = e.Ob(n, 1, 0, l(n, 3, 0, e.Gb(n.parent, 0), e.Ob(n, 1, 0, e.Gb(n, 2).transform("sa_game_" + t.gameName.toLowerCase()))));
                    l(n, 1, 0, u)
                }))
            }

            function q(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 5, "div", [
                    ["class", "info-group"]
                ], null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 2, "div", [
                    ["class", "info-label"]
                ], null, null, null, null, null)), (l()(), e.Nb(2, null, ["", ""])), e.Hb(131072, i.i, [i.j, e.i]), (l()(), e.ub(4, 0, null, null, 1, "div", [
                    ["class", "info-value"],
                    ["id", "ticket-info-id"]
                ], null, null, null, null, null)), (l()(), e.Nb(5, null, ["", ""]))], null, (function(l, n) {
                    var t = n.component;
                    l(n, 2, 0, e.Ob(n, 2, 0, e.Gb(n, 3).transform("sa_ticket_id"))), l(n, 5, 0, t.serverTicket.ticketId)
                }))
            }

            function Y(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 14, "div", [
                    ["class", "grid info-group"]
                ], null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 5, "div", [
                    ["class", "col"]
                ], null, null, null, null, null)), (l()(), e.ub(2, 0, null, null, 2, "div", [
                    ["class", "info-label"]
                ], null, null, null, null, null)), (l()(), e.Nb(3, null, ["", ""])), e.Hb(131072, i.i, [i.j, e.i]), (l()(), e.ub(5, 0, null, null, 1, "div", [
                    ["class", "info-value info-value--small"]
                ], null, null, null, null, null)), (l()(), e.Nb(6, null, ["", ""])), (l()(), e.ub(7, 0, null, null, 7, "div", [
                    ["class", "col"]
                ], null, null, null, null, null)), (l()(), e.ub(8, 0, null, null, 2, "div", [
                    ["class", "info-label"]
                ], null, null, null, null, null)), (l()(), e.Nb(9, null, ["", ""])), e.Hb(131072, i.i, [i.j, e.i]), (l()(), e.ub(11, 0, null, null, 3, "div", [
                    ["class", "info-value info-value--small"]
                ], null, null, null, null, null)), (l()(), e.Nb(12, null, [" ", " x ", " "])), e.Ib(13, {
                    currency: 0
                }), e.Hb(131072, i.b, [i.j, e.i])], null, (function(l, n) {
                    var t = n.component;
                    l(n, 3, 0, e.Ob(n, 3, 0, e.Gb(n, 4).transform("sa_group"))), l(n, 6, 0, n.context.$implicit.grouping), l(n, 9, 0, e.Ob(n, 9, 0, e.Gb(n, 10).transform("sa_combination")));
                    var u = e.Ob(n, 12, 0, e.Gb(n, 14).transform(n.context.$implicit._clData.getStakeItemized().gross / n.context.$implicit.systemCount, l(n, 13, 0, t.serverTicket.currency)));
                    l(n, 12, 0, u, n.context.$implicit.systemCount)
                }))
            }

            function X(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 7, "div", [
                    ["class", "col"]
                ], null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 2, "div", [
                    ["class", "info-label"]
                ], null, null, null, null, null)), (l()(), e.Nb(2, null, ["", ""])), e.Hb(131072, i.i, [i.j, e.i]), (l()(), e.ub(4, 0, null, null, 3, "div", [
                    ["class", "info-value info-value--small"],
                    ["id", "ticket-info-stake-taxes"]
                ], null, null, null, null, null)), (l()(), e.Nb(5, null, [" ", " (", ") "])), e.Hb(131072, i.b, [i.j, e.i]), e.Hb(131072, i.n, [i.j, e.i])], null, (function(l, n) {
                    var t = n.component;
                    l(n, 2, 0, e.Ob(n, 2, 0, e.Gb(n, 3).transform("sa_stake_taxes"))), l(n, 5, 0, e.Ob(n, 5, 0, e.Gb(n, 6).transform(t.serverTicket._clData.getTotalStakeItemized().taxesRounded)), e.Ob(n, 5, 1, e.Gb(n, 7).transform(t.serverTicket._clData.getTotalStakeItemized().taxesPercent)))
                }))
            }

            function Z(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 17, null, null, null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 16, "div", [
                    ["class", "grid info-group"]
                ], null, null, null, null, null)), (l()(), e.ub(2, 0, null, null, 7, "div", [
                    ["class", "col"]
                ], null, null, null, null, null)), (l()(), e.ub(3, 0, null, null, 2, "div", [
                    ["class", "info-label"]
                ], null, null, null, null, null)), (l()(), e.Nb(4, null, ["", ""])), e.Hb(131072, i.i, [i.j, e.i]), (l()(), e.ub(6, 0, null, null, 3, "div", [
                    ["class", "info-value info-value--small"],
                    ["id", "ticket-info-total-max-winning"]
                ], null, null, null, null, null)), (l()(), e.Nb(7, null, [" ", " "])), e.Ib(8, {
                    currency: 0
                }), e.Hb(131072, i.b, [i.j, e.i]), (l()(), e.ub(10, 0, null, null, 7, "div", [
                    ["class", "col"]
                ], null, null, null, null, null)), (l()(), e.ub(11, 0, null, null, 2, "div", [
                    ["class", "info-label"]
                ], null, null, null, null, null)), (l()(), e.Nb(12, null, ["", ""])), e.Hb(131072, i.i, [i.j, e.i]), (l()(), e.ub(14, 0, null, null, 3, "div", [
                    ["class", "info-value info-value--small"],
                    ["id", "ticket-info-total-max-winning-gross"]
                ], null, null, null, null, null)), (l()(), e.Nb(15, null, [" ", " "])), e.Ib(16, {
                    currency: 0
                }), e.Hb(131072, i.b, [i.j, e.i])], null, (function(l, n) {
                    var t = n.component;
                    l(n, 4, 0, e.Ob(n, 4, 0, e.Gb(n, 5).transform("sa_maximum_winnings")));
                    var u = e.Ob(n, 7, 0, e.Gb(n, 9).transform(t.serverTicket._clData.getTotalMaxWinningItemized().totalMaxWinning, l(n, 8, 0, t.serverTicket.currency)));
                    l(n, 7, 0, u), l(n, 12, 0, e.Ob(n, 12, 0, e.Gb(n, 13).transform("sa_potential_winnings")));
                    var i = e.Ob(n, 15, 0, e.Gb(n, 17).transform(t.serverTicket._clData.getTotalMaxWinningItemized().gross, l(n, 16, 0, t.serverTicket.currency)));
                    l(n, 15, 0, i)
                }))
            }

            function ll(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 7, "div", [
                    ["class", "info-group"]
                ], null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 2, "div", [
                    ["class", "info-label"]
                ], null, null, null, null, null)), (l()(), e.Nb(2, null, ["", ""])), e.Hb(131072, i.i, [i.j, e.i]), (l()(), e.ub(4, 0, null, null, 3, "div", [
                    ["class", "info-value info-value--small"],
                    ["id", "ticket-info-jackpot"]
                ], null, null, null, null, null)), (l()(), e.Nb(5, null, [" ", " "])), e.Ib(6, {
                    currency: 0
                }), e.Hb(131072, i.b, [i.j, e.i])], null, (function(l, n) {
                    var t = n.component;
                    l(n, 2, 0, e.Ob(n, 2, 0, e.Gb(n, 3).transform("sa_jackpot_won")));
                    var u = e.Ob(n, 5, 0, e.Gb(n, 7).transform(t.serverTicket._clData.getTotalWonItemized().grossJackpot, l(n, 6, 0, t.serverTicket.currency)));
                    l(n, 5, 0, u)
                }))
            }

            function nl(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 2, null, null, null, null, null, null, null)), (l()(), e.Nb(1, null, [" ", " "])), e.Hb(131072, i.i, [i.j, e.i])], null, (function(l, n) {
                    l(n, 1, 0, e.Ob(n, 1, 0, e.Gb(n, 2).transform("sa_won")))
                }))
            }

            function tl(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 7, "div", [
                    ["class", "col"]
                ], null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 2, "div", [
                    ["class", "info-label"]
                ], null, null, null, null, null)), (l()(), e.Nb(2, null, ["", ""])), e.Hb(131072, i.i, [i.j, e.i]), (l()(), e.ub(4, 0, null, null, 3, "div", [
                    ["class", "info-value info-value--small"],
                    ["id", "ticket-info-payout-taxes"]
                ], null, null, null, null, null)), (l()(), e.Nb(5, null, [" ", " (", ") "])), e.Hb(131072, i.b, [i.j, e.i]), e.Hb(131072, i.n, [i.j, e.i])], null, (function(l, n) {
                    var t = n.component;
                    l(n, 2, 0, e.Ob(n, 2, 0, e.Gb(n, 3).transform("sa_payout_taxes"))), l(n, 5, 0, e.Ob(n, 5, 0, e.Gb(n, 6).transform(t.serverTicket._clData.getTotalWonItemized().taxesRounded)), e.Ob(n, 5, 1, e.Gb(n, 7).transform(t.serverTicket._clData.getTotalWonItemized().taxesPercent)))
                }))
            }

            function el(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 2, "div", [], null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 1, "button", [
                    ["class", "info-print-button"]
                ], null, [
                    [null, "click"]
                ], (function(l, n, t) {
                    var e = !0;
                    return "click" === n && (e = !1 !== l.component.print() && e), e
                }), null, null)), (l()(), e.ub(2, 0, null, null, 0, "span", [
                    ["class", "icon icon-printer"]
                ], null, null, null, null, null))], null, null)
            }

            function ul(l) {
                return e.Pb(0, [(l()(), e.jb(16777216, null, null, 1, null, ll)), e.tb(1, 16384, null, 0, o.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.ub(2, 0, null, null, 12, "div", [
                    ["class", "grid info-group"]
                ], null, null, null, null, null)), (l()(), e.ub(3, 0, null, null, 7, "div", [
                    ["class", "col"]
                ], null, null, null, null, null)), (l()(), e.ub(4, 0, null, null, 2, "div", [
                    ["class", "info-label"]
                ], null, null, null, null, null)), (l()(), e.jb(16777216, null, null, 1, null, nl)), e.tb(6, 16384, null, 0, o.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"],
                    ngIfElse: [1, "ngIfElse"]
                }, null), (l()(), e.ub(7, 0, null, null, 3, "div", [
                    ["class", "info-value info-value--big"],
                    ["id", "ticket-info-total-won"]
                ], [
                    [2, "info-value--success", null]
                ], null, null, null, null)), (l()(), e.Nb(8, null, [" ", " "])), e.Ib(9, {
                    currency: 0
                }), e.Hb(131072, i.b, [i.j, e.i]), (l()(), e.jb(16777216, null, null, 1, null, tl)), e.tb(12, 16384, null, 0, o.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.jb(16777216, null, null, 1, null, el)), e.tb(14, 16384, null, 0, o.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(l, n) {
                    var t = n.component;
                    l(n, 1, 0, t.serverTicket._clData.getTotalWonItemized().grossJackpot > 0), l(n, 6, 0, !t.isServerTicketCancelled(), e.Gb(n.parent, 39)), l(n, 12, 0, t.serverTicket._clData.isWon() || t.serverTicket._clData.isPaidout() && t.serverTicket._clData.getTotalWonItemized().taxesPercent > 0), l(n, 14, 0, !t.serverTicket.timePrint)
                }), (function(l, n) {
                    var t = n.component;
                    l(n, 7, 0, t.serverTicket._clData.isWon() || t.serverTicket._clData.isPaidout());
                    var u = e.Ob(n, 8, 0, e.Gb(n, 10).transform(t.getWonQuantity(), l(n, 9, 0, t.serverTicket.currency)));
                    l(n, 8, 0, u)
                }))
            }

            function il(l) {
                return e.Pb(0, [(l()(), e.Nb(0, null, [" ", " "])), e.Hb(131072, i.i, [i.j, e.i])], null, (function(l, n) {
                    l(n, 0, 0, e.Ob(n, 0, 0, e.Gb(n, 1).transform("sa_refund")))
                }))
            }

            function ol(l) {
                return e.Pb(2, [e.Hb(0, o.h, []), (l()(), e.ub(1, 0, null, null, 5, "div", [
                    ["class", "info-group"]
                ], null, null, null, null, null)), (l()(), e.ub(2, 0, null, null, 4, "div", [
                    ["class", "grid grid-middle"]
                ], null, null, null, null, null)), (l()(), e.ub(3, 0, null, null, 0, "span", [], [
                    [8, "className", 0]
                ], null, null, null, null)), (l()(), e.Nb(-1, null, ["\xa0\xa0 "])), (l()(), e.jb(16777216, null, null, 1, null, U)), e.tb(6, 16384, null, 0, o.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.jb(16777216, null, null, 1, null, q)), e.tb(8, 16384, null, 0, o.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.ub(9, 0, null, null, 6, "div", [
                    ["class", "info-group"]
                ], null, null, null, null, null)), (l()(), e.ub(10, 0, null, null, 2, "div", [
                    ["class", "info-label"]
                ], null, null, null, null, null)), (l()(), e.Nb(11, null, ["", ""])), e.Hb(131072, i.i, [i.j, e.i]), (l()(), e.ub(13, 0, null, null, 2, "div", [
                    ["class", "info-value info-value--small"],
                    ["id", "ticket-info-date"]
                ], null, null, null, null, null)), (l()(), e.Nb(14, null, ["", ""])), e.Hb(131072, i.c, [i.j, e.i]), (l()(), e.ub(16, 0, null, null, 6, "div", [
                    ["class", "grid info-group"]
                ], null, null, null, null, null)), (l()(), e.ub(17, 0, null, null, 5, "div", [
                    ["class", "col"]
                ], null, null, null, null, null)), (l()(), e.ub(18, 0, null, null, 2, "div", [
                    ["class", "info-label"]
                ], null, null, null, null, null)), (l()(), e.Nb(19, null, ["", ""])), e.Hb(131072, i.i, [i.j, e.i]), (l()(), e.ub(21, 0, null, null, 1, "div", [
                    ["class", "info-value info-value--small"],
                    ["id", "ticket-info-issued-by"]
                ], null, null, null, null, null)), (l()(), e.Nb(22, null, [" ", " - ", " "])), (l()(), e.jb(16777216, null, null, 1, null, Y)), e.tb(24, 278528, null, 0, o.k, [e.R, e.O, e.u], {
                    ngForOf: [0, "ngForOf"]
                }, null), (l()(), e.ub(25, 0, null, null, 10, "div", [
                    ["class", "grid info-group"]
                ], null, null, null, null, null)), (l()(), e.ub(26, 0, null, null, 7, "div", [
                    ["class", "col"]
                ], null, null, null, null, null)), (l()(), e.ub(27, 0, null, null, 2, "div", [
                    ["class", "info-label"]
                ], null, null, null, null, null)), (l()(), e.Nb(28, null, ["", ""])), e.Hb(131072, i.i, [i.j, e.i]), (l()(), e.ub(30, 0, null, null, 3, "div", [
                    ["class", "info-value info-value--small"],
                    ["id", "ticket-info-stake"]
                ], null, null, null, null, null)), (l()(), e.Nb(31, null, [" ", " "])), e.Ib(32, {
                    currency: 0
                }), e.Hb(131072, i.b, [i.j, e.i]), (l()(), e.jb(16777216, null, null, 1, null, X)), e.tb(35, 16384, null, 0, o.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.jb(16777216, null, null, 1, null, Z)), e.tb(37, 16384, null, 0, o.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"],
                    ngIfElse: [1, "ngIfElse"]
                }, null), (l()(), e.jb(0, [
                    ["wonTemplate", 2]
                ], null, 0, null, ul)), (l()(), e.jb(0, [
                    ["refundTagTemplate", 2]
                ], null, 0, null, il))], (function(l, n) {
                    var t = n.component;
                    l(n, 6, 0, t.gameName), l(n, 8, 0, !t.hideTicketId), l(n, 24, 0, t.serverTicket.details.systemBets), l(n, 35, 0, t.serverTicket.stakeTaxes), l(n, 37, 0, t.serverTicket._clData.isOpen() || t.serverTicket._clData.isPending(), e.Gb(n, 38))
                }), (function(l, n) {
                    var t = n.component;
                    l(n, 3, 0, e.yb(1, "game-icon game-icon-", t.iconName, "")), l(n, 11, 0, e.Ob(n, 11, 0, e.Gb(n, 12).transform("sa_date"))), l(n, 14, 0, e.Ob(n, 14, 0, e.Gb(n, 15).transform(t.serverTicket.timeRegister, "datetime"))), l(n, 19, 0, e.Ob(n, 19, 0, e.Gb(n, 20).transform("sa_issued_by"))), l(n, 22, 0, t.serverTicket.sellStaff.id, t.serverTicket.sellStaff.name), l(n, 28, 0, e.Ob(n, 28, 0, e.Gb(n, 29).transform("sa_total_stake")));
                    var u = e.Ob(n, 31, 0, e.Gb(n, 33).transform(t.serverTicket._clData.getTotalStakeItemized().netRounded, l(n, 32, 0, t.serverTicket.currency)));
                    l(n, 31, 0, u)
                }))
            }
            var rl = t("B0aO"),
                al = t("ZYCi"),
                cl = t("agnC");
            t.d(n, "a", (function() {
                return hl
            }));
            var sl = e.sb({
                encapsulation: 0,
                styles: [
                    ["[_nghost-%COMP%]   .grid[_ngcontent-%COMP%]:first-child{margin-bottom:20px}[_nghost-%COMP%]   .grid[_ngcontent-%COMP%]:last-child{margin:0 -17px}[_nghost-%COMP%]   .grid[_ngcontent-%COMP%]:last-child > .col[_ngcontent-%COMP%]{padding:0 17px}.page-title[_ngcontent-%COMP%]{margin-bottom:0}.ticket-details__back-button[_ngcontent-%COMP%]{padding:14px;margin-right:16px;font-weight:700;color:#274a5c;cursor:pointer;border:1px solid #163c4c;box-shadow:0 2px 2px 0 rgba(119,151,178,.16);text-transform:uppercase}.ticket-details__box[_ngcontent-%COMP%]{padding:30px;background-color:#fff;box-shadow:0 0 2px 0 rgba(0,0,0,.14),0 2px 2px 0 rgba(0,0,0,.12),0 1px 3px 0 rgba(0,0,0,.2)}.ticket-details__box[_ngcontent-%COMP%] + .ticket-details__box[_ngcontent-%COMP%]{margin-top:10px}grsa-ticket-event-info[_ngcontent-%COMP%] + grsa-ticket-event-info[_ngcontent-%COMP%]{margin-top:20px}"]
                ],
                data: {}
            });

            function bl(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 1, "grsa-ticket-event-info-ch", [], [
                    [2, "ticket-event-info", null]
                ], null, null, M, k)), e.tb(1, 114688, null, 0, h, [i.j, v.a], {
                    serverTicket: [0, "serverTicket"],
                    ticketEvents: [1, "ticketEvents"]
                }, null)], (function(l, n) {
                    l(n, 1, 0, n.component.serverTicket, n.context.$implicit)
                }), (function(l, n) {
                    l(n, 0, 0, e.Gb(n, 1).clazz)
                }))
            }

            function dl(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 2, null, null, null, null, null, null, null)), (l()(), e.jb(16777216, null, null, 1, null, bl)), e.tb(2, 278528, null, 0, o.k, [e.R, e.O, e.u], {
                    ngForOf: [0, "ngForOf"]
                }, null), (l()(), e.jb(0, null, null, 0))], (function(l, n) {
                    l(n, 2, 0, n.component.ticketEventsGrouped)
                }), null)
            }

            function fl(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 1, "grsa-ticket-event-info", [], [
                    [2, "ticket-event-info", null]
                ], null, null, Q, w)), e.tb(1, 114688, null, 0, m, [i.j, v.a], {
                    serverTicket: [0, "serverTicket"],
                    ticketEvents: [1, "ticketEvents"]
                }, null)], (function(l, n) {
                    l(n, 1, 0, n.component.serverTicket, n.context.$implicit)
                }), (function(l, n) {
                    l(n, 0, 0, e.Gb(n, 1).clazz)
                }))
            }

            function pl(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 2, null, null, null, null, null, null, null)), (l()(), e.jb(16777216, null, null, 1, null, fl)), e.tb(2, 278528, null, 0, o.k, [e.R, e.O, e.u], {
                    ngForOf: [0, "ngForOf"]
                }, null), (l()(), e.jb(0, null, null, 0))], (function(l, n) {
                    l(n, 2, 0, n.component.ticketEventsGrouped)
                }), null)
            }

            function vl(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 10, "div", [
                    ["class", "grid"]
                ], null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 3, "div", [
                    ["class", "col col-4"]
                ], null, null, null, null, null)), (l()(), e.ub(2, 0, null, null, 2, "div", [
                    ["class", "ticket-details__box"]
                ], null, null, null, null, null)), (l()(), e.ub(3, 0, null, null, 1, "grsa-ticket-info", [], [
                    [2, "ticket-info", null]
                ], null, null, ol, K)), e.tb(4, 114688, null, 0, $, [v.a], {
                    serverTicket: [0, "serverTicket"],
                    hideTicketId: [1, "hideTicketId"]
                }, null), (l()(), e.ub(5, 0, null, null, 5, "div", [
                    ["class", "col"]
                ], null, null, null, null, null)), e.tb(6, 16384, null, 0, o.o, [], {
                    ngSwitch: [0, "ngSwitch"]
                }, null), (l()(), e.jb(16777216, null, null, 1, null, dl)), e.tb(8, 278528, null, 0, o.p, [e.R, e.O, o.o], {
                    ngSwitchCase: [0, "ngSwitchCase"]
                }, null), (l()(), e.jb(16777216, null, null, 1, null, pl)), e.tb(10, 16384, null, 0, o.q, [e.R, e.O, o.o], null, null)], (function(l, n) {
                    var t = n.component;
                    l(n, 4, 0, t.serverTicket, t.hideTicketId), l(n, 6, 0, t.serverTicket.details.events[0].gameType.val), l(n, 8, 0, t.ValEnum.CH)
                }), (function(l, n) {
                    l(n, 3, 0, e.Gb(n, 4).clazz)
                }))
            }

            function gl(l) {
                return e.Pb(2, [e.Hb(0, o.u, []), (l()(), e.ub(1, 0, null, null, 11, "div", [
                    ["class", "page"]
                ], null, null, null, null, null)), (l()(), e.ub(2, 0, null, null, 8, "div", [
                    ["class", "grid grid-middle page-header"]
                ], null, null, null, null, null)), (l()(), e.ub(3, 0, null, null, 3, "div", [
                    ["class", "ticket-details__back-button"]
                ], null, [
                    [null, "click"]
                ], (function(l, n, t) {
                    var e = !0;
                    return "click" === n && (e = !1 !== l.component.onBack() && e), e
                }), null, null)), (l()(), e.ub(4, 0, null, null, 0, "span", [
                    ["class", "icon icon-arrow-back"]
                ], null, null, null, null, null)), (l()(), e.Nb(5, null, [" ", " "])), e.Hb(131072, i.i, [i.j, e.i]), (l()(), e.ub(7, 0, null, null, 3, "h3", [
                    ["class", "page-title"]
                ], null, null, null, null, null)), (l()(), e.Nb(8, null, ["", ""])), e.Hb(131072, i.i, [i.j, e.i]), e.Jb(10, 1), (l()(), e.jb(16777216, null, null, 1, null, vl)), e.tb(12, 16384, null, 0, o.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(l, n) {
                    l(n, 12, 0, n.component.serverTicket)
                }), (function(l, n) {
                    l(n, 5, 0, e.Ob(n, 5, 0, e.Gb(n, 6).transform("sa_back")));
                    var t = e.Ob(n, 8, 0, l(n, 10, 0, e.Gb(n, 0), e.Ob(n, 8, 0, e.Gb(n, 9).transform("sa_ticket_details"))));
                    l(n, 8, 0, t)
                }))
            }

            function ml(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 1, "grsa-page-ticket-details", [], [
                    [2, "ticket-details", null]
                ], null, null, gl, sl)), e.tb(1, 245760, null, 0, rl.a, [e.i, al.l, al.a, v.a, cl.a], null, null)], (function(l, n) {
                    l(n, 1, 0)
                }), (function(l, n) {
                    l(n, 0, 0, e.Gb(n, 1).clazz)
                }))
            }
            var hl = e.qb("grsa-page-ticket-details", rl.a, ml, {}, {}, [])
        }
    }
]);