(window.webpackJsonp = window.webpackJsonp || []).push([
    [17], {
        e9ah: function(l, t, n) {
            "use strict";
            n.r(t);
            var e = n("CcnG"),
                u = function() {
                    return function() {}
                }(),
                i = n("pMnS"),
                r = n("iGSx"),
                a = n("Ip0R"),
                o = function() {
                    function l() {
                        this.showItems = !0, this.rows = [], this.items = [], this.headers = !0, this.getHeader = function() {
                            return ""
                        }, this.numberCol = 1
                    }
                    return l.prototype.ngOnInit = function() {
                        this.items = this.items.filter((function(l) {
                            return l.playlist && l.playlist > 0 || "$$" === l.gameType
                        })), this.numberCol = this.getNumberCol(this.items.length)
                    }, l.prototype.ngOnChanges = function() {
                        this.items = this.items.filter((function(l) {
                            return l.playlist && l.playlist > 0 || "$$" === l.gameType
                        })), this.numberCol = this.getNumberCol(this.items.length)
                    }, l.prototype.getNumberCol = function(l) {
                        var t;
                        switch (l) {
                            case 0:
                                t = 11;
                                break;
                            case 1:
                                t = 9;
                                break;
                            case 2:
                                t = 8;
                                break;
                            case 3:
                                t = 7;
                                break;
                            default:
                                t = 3
                        }
                        return t
                    }, l
                }(),
                s = e.sb({
                    encapsulation: 0,
                    styles: [
                        [".turnover-table[_ngcontent-%COMP%]{white-space:nowrap;table-layout:fixed}.turnover-table--main[_ngcontent-%COMP%]{width:100%}.turnover-table__cell[_ngcontent-%COMP%], .turnover-table__head[_ngcontent-%COMP%]{width:200px;height:38px;padding:10px;font-size:14px;color:rgba(0,0,0,.87);text-align:right;vertical-align:middle;border:1px solid #e4e7e8}.turnover-table__head[_ngcontent-%COMP%]{font-weight:700;background-color:#eceff1}.turnover-table__cell[_ngcontent-%COMP%]{background-color:#fffffe}.turnover-table__cell--no-border-horizontal[_ngcontent-%COMP%]{border-right:0;border-left:0}.turnover-table__cell--no-border-right[_ngcontent-%COMP%]{border-right:0}.turnover-table__containter[_ngcontent-%COMP%] + .turnover-table__containter[_ngcontent-%COMP%]{margin-top:10px}.turnover-table__middle[_ngcontent-%COMP%]{overflow-x:auto}.turnover-table__row--highlight[_ngcontent-%COMP%]{font-weight:700}.turnover-table__row--highlight[_ngcontent-%COMP%]   .turnover-table__cell[_ngcontent-%COMP%]{background-color:#f9f9f9}.text-left[_ngcontent-%COMP%]{text-align:left}"]
                    ],
                    data: {}
                });

            function c(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 2, "thead", [], null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 1, "th", [
                    ["class", "turnover-table__head text-left"]
                ], null, null, null, null, null)), (l()(), e.Nb(2, null, [" ", " "]))], null, (function(l, t) {
                    l(t, 2, 0, t.component.title)
                }))
            }

            function d(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 3, "tr", [], [
                    [2, "turnover-table__row--highlight", null]
                ], null, null, null, null)), (l()(), e.ub(1, 0, null, null, 2, "td", [
                    ["class", "turnover-table__cell text-left"]
                ], [
                    [2, "turnover-table__cell--no-border-right", null]
                ], null, null, null, null)), (l()(), e.ub(2, 0, null, null, 1, "span", [], null, null, null, null, null)), (l()(), e.Nb(3, null, ["", ""]))], null, (function(l, t) {
                    var n = t.component;
                    l(t, 0, 0, t.context.$implicit.highlight);
                    var e = !t.context.$implicit.getCellText(n.items[0]);
                    l(t, 1, 0, e), l(t, 3, 0, t.context.$implicit.title)
                }))
            }

            function b(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 1, "th", [
                    ["class", "turnover-table__head"]
                ], null, null, null, null, null)), (l()(), e.Nb(1, null, [" ", " "]))], null, (function(l, t) {
                    l(t, 1, 0, t.component.getHeader(t.context.$implicit))
                }))
            }

            function m(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 2, "thead", [], null, null, null, null, null)), (l()(), e.jb(16777216, null, null, 1, null, b)), e.tb(2, 278528, null, 0, a.k, [e.R, e.O, e.u], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(l, t) {
                    l(t, 2, 0, t.component.items)
                }), null)
            }

            function g(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 2, "td", [
                    ["class", "turnover-table__cell"]
                ], [
                    [2, "turnover-table__cell--no-border-horizontal", null]
                ], null, null, null, null)), (l()(), e.ub(1, 0, null, null, 1, "span", [], null, null, null, null, null)), (l()(), e.Nb(2, null, ["", ""]))], null, (function(l, t) {
                    var n = !t.parent.context.$implicit.getCellText(t.context.$implicit);
                    l(t, 0, 0, n);
                    var e = t.parent.context.$implicit.getCellText(t.context.$implicit);
                    l(t, 2, 0, e)
                }))
            }

            function _(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 2, "tr", [], [
                    [2, "turnover-table__row--highlight", null]
                ], null, null, null, null)), (l()(), e.jb(16777216, null, null, 1, null, g)), e.tb(2, 278528, null, 0, a.k, [e.R, e.O, e.u], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(l, t) {
                    l(t, 2, 0, t.component.items)
                }), (function(l, t) {
                    l(t, 0, 0, t.context.$implicit.highlight)
                }))
            }

            function p(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 6, "div", [
                    ["class", "turnover-table__middle"]
                ], null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 5, "table", [
                    ["class", "turnover-table"]
                ], null, null, null, null, null)), (l()(), e.jb(16777216, null, null, 1, null, m)), e.tb(3, 16384, null, 0, a.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.ub(4, 0, null, null, 2, "tbody", [], null, null, null, null, null)), (l()(), e.jb(16777216, null, null, 1, null, _)), e.tb(6, 278528, null, 0, a.k, [e.R, e.O, e.u], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(l, t) {
                    var n = t.component;
                    l(t, 3, 0, n.headers), l(t, 6, 0, n.rows)
                }), null)
            }

            function f(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 2, "thead", [], null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 1, "th", [
                    ["class", "turnover-table__head"]
                ], null, null, null, null, null)), (l()(), e.Nb(2, null, [" ", " "]))], null, (function(l, t) {
                    l(t, 2, 0, t.component.getHeader())
                }))
            }

            function v(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 3, "tr", [], [
                    [2, "turnover-table__row--highlight", null]
                ], null, null, null, null)), (l()(), e.ub(1, 0, null, null, 2, "td", [
                    ["class", "turnover-table__cell"]
                ], null, null, null, null, null)), (l()(), e.ub(2, 0, null, null, 1, "span", [], null, null, null, null, null)), (l()(), e.Nb(3, null, ["", ""]))], null, (function(l, t) {
                    l(t, 0, 0, t.context.$implicit.highlight);
                    var n = t.context.$implicit.getCellText();
                    l(t, 3, 0, n)
                }))
            }

            function h(l) {
                return e.Pb(2, [(l()(), e.ub(0, 0, null, null, 16, "div", [
                    ["class", "grid grid-no-wrap turnover-table__container"]
                ], null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 6, "div", [], [
                    [8, "className", 0],
                    [2, "col-11", null]
                ], null, null, null, null)), (l()(), e.ub(2, 0, null, null, 5, "table", [
                    ["class", "turnover-table turnover-table--main"]
                ], null, null, null, null, null)), (l()(), e.jb(16777216, null, null, 1, null, c)), e.tb(4, 16384, null, 0, a.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.ub(5, 0, null, null, 2, "tbody", [], null, null, null, null, null)), (l()(), e.jb(16777216, null, null, 1, null, d)), e.tb(7, 278528, null, 0, a.k, [e.R, e.O, e.u], {
                    ngForOf: [0, "ngForOf"]
                }, null), (l()(), e.jb(16777216, null, null, 1, null, p)), e.tb(9, 16384, null, 0, a.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.ub(10, 0, null, null, 6, "div", [
                    ["class", "col col-1"]
                ], null, null, null, null, null)), (l()(), e.ub(11, 0, null, null, 5, "table", [
                    ["class", "turnover-table "]
                ], null, null, null, null, null)), (l()(), e.jb(16777216, null, null, 1, null, f)), e.tb(13, 16384, null, 0, a.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.ub(14, 0, null, null, 2, "tbody", [], null, null, null, null, null)), (l()(), e.jb(16777216, null, null, 1, null, v)), e.tb(16, 278528, null, 0, a.k, [e.R, e.O, e.u], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(l, t) {
                    var n = t.component;
                    l(t, 4, 0, n.headers), l(t, 7, 0, n.rows), l(t, 9, 0, n.showItems && n.items.length > 0), l(t, 13, 0, n.headers), l(t, 16, 0, n.rows)
                }), (function(l, t) {
                    var n = t.component;
                    l(t, 1, 0, e.yb(1, "col col-", n.numberCol, " turnover-table__left"), n.rows[0].highlight)
                }))
            }
            var I = n("5EE+"),
                O = function() {
                    function l() {}
                    return l.prototype.ngOnInit = function() {}, l
                }(),
                S = e.sb({
                    encapsulation: 0,
                    styles: [
                        [".settlement-pending[_ngcontent-%COMP%]{padding:18px;margin:0!important;font-size:16px;color:rgba(0,0,0,.87);background-color:#fffcda;box-shadow:0 2px 4px 0 rgba(0,0,0,.14),0 2px 4px 0 rgba(0,0,0,.12),0 1px 3px 0 rgba(160,160,160,.2)}.settlement-pending[_ngcontent-%COMP%] > *[_ngcontent-%COMP%]{padding:0 6px}.settlement-pending__icon[_ngcontent-%COMP%]{display:inline-block;font-size:20px;color:#000;-webkit-animation:2s linear infinite settlementPendingIconKeyframes;animation:2s linear infinite settlementPendingIconKeyframes}@-webkit-keyframes settlementPendingIconKeyframes{from{transform:rotate(0)}to{transform:rotate(360deg)}}@keyframes settlementPendingIconKeyframes{from{transform:rotate(0)}to{transform:rotate(360deg)}}"]
                    ],
                    data: {}
                });

            function y(l) {
                return e.Pb(2, [(l()(), e.ub(0, 0, null, null, 5, "div", [
                    ["class", "grid grid-middle settlement-pending"]
                ], null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 1, "div", [], null, null, null, null, null)), (l()(), e.ub(2, 0, null, null, 0, "span", [
                    ["class", "icon icon-loading-spinner settlement-pending__icon"]
                ], null, null, null, null, null)), (l()(), e.ub(3, 0, null, null, 2, "div", [
                    ["class", "col"]
                ], null, null, null, null, null)), (l()(), e.Nb(4, null, [" ", " "])), e.Hb(131072, I.i, [I.j, e.i])], null, (function(l, t) {
                    l(t, 4, 0, e.Ob(t, 4, 0, e.Gb(t, 5).transform("sa_generating_report")))
                }))
            }
            var x = n("CrY/"),
                C = n("t01L"),
                P = function() {
                    function l(l) {
                        this.coreService = l, this.selected = new e.n, this.reportItemized = {}
                    }
                    return l.prototype.ngOnInit = function() {
                        if (this.settlement.data && this.settlement.data.isSettlementReportData() && this.settlement.data.data && this.settlement.data.data.length > 0) {
                            var l = this.settlement.data.data[0];
                            this.reportItemized = l.total && l.total._clData.reportLineItemized, this.currency = this.coreService.getCurrency(this.settlement.data.data[0].currency), this.totalDataItemized = l.total
                        }
                        var t = this.totalDataItemized.won - this.totalDataItemized.paidOut,
                            n = this.totalDataItemized.jackpotWon - this.totalDataItemized.jackpotPaidOut,
                            e = this.totalDataItemized.megaJackpotWon - this.totalDataItemized.megaJackpotPaidOut;
                        this.totalIncome = this.reportItemized && this.reportItemized.stakeAmountNet + this.reportItemized.stakeAmountTaxes + this.totalDataItemized.directCashIn, this.totalPayments = this.reportItemized && this.reportItemized.paidAmountGross + this.reportItemized.jackpotPaidAmountGross + this.reportItemized.megajackpotPaidAmountGross + this.totalDataItemized.directCashOut, this.totalOutcome = this.totalPayments - this.reportItemized.paidAmountTaxes, this.totalBalance = this.totalIncome - this.totalOutcome, this.totalInformation = t + n + e + this.totalDataItemized.stakeTaxes + this.totalDataItemized.paidOutTaxes, this.totalNetBalance = this.totalBalance - this.totalInformation
                    }, l
                }(),
                j = e.sb({
                    encapsulation: 0,
                    styles: [
                        [".settlement[_ngcontent-%COMP%]{padding-top:12px;padding-bottom:12px;font-size:14px;color:rgba(0,0,0,.6);cursor:pointer;margin:0 -10px}.settlement[_ngcontent-%COMP%] > *[_ngcontent-%COMP%]{padding:0 10px}.settlement__row[_ngcontent-%COMP%]{width:100%}.settlement__title[_ngcontent-%COMP%]{font-weight:700}.settlement__date[_ngcontent-%COMP%]{font-size:13px}.settlement__quantity[_ngcontent-%COMP%]{font-size:16px;color:#417505;text-align:right}.settlement__range[_ngcontent-%COMP%]{font-size:10px;width:100%;text-align:center;position:relative;bottom:-20px}"]
                    ],
                    data: {}
                });

            function k(l) {
                return e.Pb(2, [(l()(), e.ub(0, 0, null, null, 30, "div", [
                    ["class", "grid grid-middle settlement"]
                ], null, [
                    [null, "click"]
                ], (function(l, t, n) {
                    var e = !0;
                    return "click" === t && (e = !1 !== l.component.selected.emit() && e), e
                }), null, null)), (l()(), e.ub(1, 0, null, null, 7, "div", [
                    ["class", "settlement__row"]
                ], null, null, null, null, null)), (l()(), e.ub(2, 0, null, null, 2, "span", [
                    ["class", "settlement__title"]
                ], null, null, null, null, null)), (l()(), e.Nb(3, null, ["", ""])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(5, 0, null, null, 3, "span", [
                    ["class", "settlement__date"]
                ], null, null, null, null, null)), (l()(), e.Nb(6, null, [" ", " ", " "])), e.Hb(131072, I.c, [I.j, e.i]), e.Hb(131072, I.c, [I.j, e.i]), (l()(), e.ub(9, 0, null, null, 3, "div", [
                    ["class", "col settlement__quantity"]
                ], null, null, null, null, null)), (l()(), e.Nb(10, null, [" ", " "])), e.Ib(11, {
                    currency: 0
                }), e.Hb(131072, I.b, [I.j, e.i]), (l()(), e.ub(13, 0, null, null, 1, "div", [
                    ["class", "settlement__link"]
                ], null, null, null, null, null)), (l()(), e.ub(14, 0, null, null, 0, "span", [
                    ["class", "icon icon-right"]
                ], null, null, null, null, null)), (l()(), e.ub(15, 0, null, null, 7, "div", [
                    ["class", "settlement__row"]
                ], null, null, null, null, null)), (l()(), e.ub(16, 0, null, null, 2, "span", [
                    ["class", "settlement__title"]
                ], null, null, null, null, null)), (l()(), e.Nb(17, null, ["", ""])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(19, 0, null, null, 3, "span", [
                    ["class", "settlement__date"]
                ], null, null, null, null, null)), (l()(), e.Nb(20, null, [" ", " ", " "])), e.Hb(131072, I.c, [I.j, e.i]), e.Hb(131072, I.c, [I.j, e.i]), (l()(), e.ub(23, 0, null, null, 7, "div", [
                    ["class", "settlement__range"]
                ], null, null, null, null, null)), (l()(), e.Nb(24, null, [" ", " ", " ", " ", " ", " ", " "])), e.Hb(131072, I.i, [I.j, e.i]), e.Hb(131072, I.c, [I.j, e.i]), e.Hb(131072, I.c, [I.j, e.i]), e.Hb(131072, I.i, [I.j, e.i]), e.Hb(131072, I.c, [I.j, e.i]), e.Hb(131072, I.c, [I.j, e.i])], null, (function(l, t) {
                    var n = t.component;
                    l(t, 3, 0, e.Ob(t, 3, 0, e.Gb(t, 4).transform("sa_requested"))), l(t, 6, 0, e.Ob(t, 6, 0, e.Gb(t, 7).transform(n.settlement.creationTime, "date")), e.Ob(t, 6, 1, e.Gb(t, 8).transform(n.settlement.creationTime, "time")));
                    var u = e.Ob(t, 10, 0, e.Gb(t, 12).transform(n.totalNetBalance || 0, l(t, 11, 0, n.currency)));
                    l(t, 10, 0, u), l(t, 17, 0, e.Ob(t, 17, 0, e.Gb(t, 18).transform("sa_generated"))), l(t, 20, 0, e.Ob(t, 20, 0, e.Gb(t, 21).transform(n.settlement.generationTime, "date")), e.Ob(t, 20, 1, e.Gb(t, 22).transform(n.settlement.generationTime, "time"))), l(t, 24, 0, e.Ob(t, 24, 0, e.Gb(t, 25).transform("sa_from")), e.Ob(t, 24, 1, e.Gb(t, 26).transform(n.settlement.startTime, "date")), e.Ob(t, 24, 2, e.Gb(t, 27).transform(n.settlement.startTime, "time")), e.Ob(t, 24, 3, e.Gb(t, 28).transform("sa_to")), e.Ob(t, 24, 4, e.Gb(t, 29).transform(n.settlement.endTime, "date")), e.Ob(t, 24, 5, e.Gb(t, 30).transform(n.settlement.startTime, "time")))
                }))
            }
            var z = n("n3kJ"),
                N = n("0/uQ"),
                G = function() {
                    function l(l) {
                        this.coreService = l, this.back = new e.n, this.reportItemized = {}, this.entityHasStakeTaxes = !1, this.entityHasPaidoutTaxes = !1, this.someCancelledStakesAreGreaterThatZero = !1
                    }
                    return l.prototype.ngOnInit = function() {
                        if (this.settlement.data && this.settlement.data.isSettlementReportData() && this.settlement.data.data && this.settlement.data.data.length > 0) {
                            var l = this.settlement.data.data[0];
                            this.reportItemized = l.total && l.total._clData.reportLineItemized, this.currency = this.coreService.getCurrency(this.settlement.data.data[0].currency), this.playlistDataItemized = l.accounts.map((function(l) {
                                return ("0" === l.playlistId || "0 - cash" === l.playlistId.toLowerCase()) && 0 === l.jackpotWon && 0 === l.jackpotPaidOut && (l._clData.playlistDescriptionTag = "sa_voucher_tickets"), {
                                    descriptionTag: l._clData.playlistDescriptionTag,
                                    playlistItem: l._clData.reportLineItemized
                                }
                            })), this.totalDataItemized = l.total
                        }
                        var t = this.totalDataItemized.won - this.totalDataItemized.paidOut,
                            n = this.totalDataItemized.jackpotWon - this.totalDataItemized.jackpotPaidOut,
                            e = this.totalDataItemized.megaJackpotWon - this.totalDataItemized.megaJackpotPaidOut;
                        this.settlement.entityId === this.coreService.getSessionController().sessionSettings.auth.unit.id && (this.accountName = " " + this.coreService.getSessionController().sessionSettings.auth.unit.name), this.settlement.creatorId === this.coreService.getSessionController().sessionSettings.auth.staff.id && (this.creatorName = " " + this.coreService.getSessionController().sessionSettings.auth.staff.name);
                        var u = this.coreService.getSessionController().sessionSettings.auth.unit.extId;
                        this.accountExternalId = u ? "-" + u : "";
                        var i = this.coreService.getSessionController().sessionSettings.auth.staff.extId;
                        this.creatorExternalId = i ? "-" + i : "", this.someCancelledStakesAreGreaterThatZero = this.playlistDataItemized.some((function(l) {
                            return l.playlistItem.cancelledStakeAmountNet > 0
                        })), this.entityHasStakeTaxes = this.totalDataItemized.stakeTaxes > 0, this.entityHasPaidoutTaxes = this.totalDataItemized.paidOutTaxes > 0, this.totalIncome = this.reportItemized && this.reportItemized.stakeAmountNet + this.reportItemized.stakeAmountTaxes + this.totalDataItemized.directCashIn, this.totalPayments = this.reportItemized && this.reportItemized.paidAmountGross + this.reportItemized.jackpotPaidAmountGross + this.reportItemized.megajackpotPaidAmountGross + this.totalDataItemized.directCashOut, this.totalOutcome = this.totalPayments - this.reportItemized.paidAmountTaxes, this.totalBalance = this.totalIncome - this.totalOutcome, this.totalInformation = t + n + e + this.totalDataItemized.stakeTaxes + this.totalDataItemized.paidOutTaxes, this.totalNetBalance = this.totalBalance - this.totalInformation, this.entityId = "" + this.settlement.entityId, this.creatorId = "" + this.settlement.creatorId, this.reportId = ("" + this.settlement.reportId).length < 7 ? ("000000" + this.settlement.reportId).slice(-6) : "" + this.settlement.reportId
                    }, l.prototype.print = function() {
                        Object(N.a)(this.coreService.getPrintTicketController().printReport({
                            reportType: z.c.SETTLEMENT,
                            data: this.settlement,
                            currency: this.coreService.getCurrency(this.settlement.data.isSettlementReportData() && this.settlement.data.data[0].currency),
                            auth: this.coreService.getSessionController().sessionSettings.auth,
                            printedOn: new Date
                        })).subscribe()
                    }, l
                }(),
                T = e.sb({
                    encapsulation: 0,
                    styles: [
                        [".settlement-details[_ngcontent-%COMP%]{width:100%;min-height:100%;background-color:#f3f6f8}.settlement-details__header[_ngcontent-%COMP%]{height:96px;padding:0 20px;font-size:16px;color:rgba(0,0,0,.87);text-transform:uppercase;background-color:#e0e9ee;margin:0 -12.5px}.settlement-details__header[_ngcontent-%COMP%] > *[_ngcontent-%COMP%]{padding:0 12.5px}.settlement-details__back[_ngcontent-%COMP%]{cursor:pointer}.settlement-details__date[_ngcontent-%COMP%], .settlement-details__time[_ngcontent-%COMP%]{font-size:14px;color:rgba(0,0,0,.87)}.settlement-details__time[_ngcontent-%COMP%]{font-weight:700}.settlement-details__date[_ngcontent-%COMP%]{margin-left:10px}.settlement-details__quantity[_ngcontent-%COMP%]{margin-top:5px;font-size:22px;color:#417505}.settlement-details__content[_ngcontent-%COMP%]{padding:20px}.settlement-details__grid[_ngcontent-%COMP%]{word-break:break-word;margin:0 -5px}.settlement-details__grid[_ngcontent-%COMP%] > *[_ngcontent-%COMP%]{padding:0 5px 4px}.settlement-details__square[_ngcontent-%COMP%]{margin-top:5px;border:1px solid #d8d8d8;font-weight:700;font-size:16px}.settlement-details__info[_ngcontent-%COMP%]{font-size:14px;color:rgba(0,0,0,.87)}.settlement-details__info--small[_ngcontent-%COMP%]{font-size:12px}.settlement-details__info--squared[_ngcontent-%COMP%]{margin-top:5px}.settlement-details__info--highlight[_ngcontent-%COMP%]{font-size:16px}.settlement-details__value[_ngcontent-%COMP%]{font-size:14px;color:rgba(0,0,0,.87);text-align:right;white-space:nowrap}.settlement-details__value--small[_ngcontent-%COMP%]{font-size:12px}.settlement-details__value--squared[_ngcontent-%COMP%]{margin-top:5px}.settlement-details__value--highlight[_ngcontent-%COMP%]{font-size:16px}.settlement-details__separator[_ngcontent-%COMP%]{padding-bottom:4px;margin-top:20px;margin-bottom:10px;font-size:16px;color:rgba(0,0,0,.87);border-bottom:1px solid #d8d8d8}.settlement-details__separator--half[_ngcontent-%COMP%]{margin-left:40%;width:60%;margin-top:0}.settlement-details__separator--thin[_ngcontent-%COMP%]{margin-left:80%;width:20%;margin-top:0}.settlement-details__separator-column[_ngcontent-%COMP%]{font-size:14px;padding-top:2px}"]
                    ],
                    data: {}
                });

            function w(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 6, null, null, null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 2, "div", [
                    ["class", "col text-right settlement-details__separator-column"]
                ], null, null, null, null, null)), (l()(), e.Nb(2, null, ["", ""])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(4, 0, null, null, 2, "div", [
                    ["class", "col text-right settlement-details__separator-column"]
                ], null, null, null, null, null)), (l()(), e.Nb(5, null, ["", ""])), e.Hb(131072, I.i, [I.j, e.i])], null, (function(l, t) {
                    l(t, 2, 0, e.Ob(t, 2, 0, e.Gb(t, 3).transform("sa_cancelled"))), l(t, 5, 0, e.Ob(t, 5, 0, e.Gb(t, 6).transform("sa_confirmed")))
                }))
            }

            function H(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 8, null, null, null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 3, "div", [
                    ["class", "col settlement-details__value"]
                ], null, null, null, null, null)), (l()(), e.Nb(2, null, [" ", " "])), e.Ib(3, {
                    currency: 0
                }), e.Hb(131072, I.b, [I.j, e.i]), (l()(), e.ub(5, 0, null, null, 3, "div", [
                    ["class", "col settlement-details__value"]
                ], null, null, null, null, null)), (l()(), e.Nb(6, null, [" ", " "])), e.Ib(7, {
                    currency: 0
                }), e.Hb(131072, I.b, [I.j, e.i])], null, (function(l, t) {
                    var n = t.component,
                        u = e.Ob(t, 2, 0, e.Gb(t, 4).transform(t.parent.context.$implicit.playlistItem.stakeAmountNet + t.parent.context.$implicit.playlistItem.cancelledStakeAmountNet, l(t, 3, 0, n.currency)));
                    l(t, 2, 0, u);
                    var i = t.parent.context.$implicit.playlistItem.cancelledStakeAmountNet ? e.Ob(t, 6, 0, e.Gb(t, 8).transform(t.parent.context.$implicit.playlistItem.cancelledStakeAmountNet, l(t, 7, 0, n.currency))) : "";
                    l(t, 6, 0, i)
                }))
            }

            function M(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 9, "div", [
                    ["class", "grid settlement-details__grid"]
                ], null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 2, "div", [
                    ["class", "col-5 settlement-details__info"]
                ], null, null, null, null, null)), (l()(), e.Nb(2, null, [" ", " "])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.jb(16777216, null, null, 1, null, H)), e.tb(5, 16384, null, 0, a.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.ub(6, 0, null, null, 3, "div", [
                    ["class", "col settlement-details__value"]
                ], null, null, null, null, null)), (l()(), e.Nb(7, null, [" ", " "])), e.Ib(8, {
                    currency: 0
                }), e.Hb(131072, I.b, [I.j, e.i])], (function(l, t) {
                    l(t, 5, 0, t.component.someCancelledStakesAreGreaterThatZero)
                }), (function(l, t) {
                    var n = t.component;
                    l(t, 2, 0, e.Ob(t, 2, 0, e.Gb(t, 3).transform(t.context.$implicit.descriptionTag)));
                    var u = e.Ob(t, 7, 0, e.Gb(t, 9).transform(t.context.$implicit.playlistItem.stakeAmountNet, l(t, 8, 0, n.currency)));
                    l(t, 7, 0, u)
                }))
            }

            function D(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 2, null, null, null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 0, "div", [
                    ["class", "col settlement-details__value"]
                ], null, null, null, null, null)), (l()(), e.ub(2, 0, null, null, 0, "div", [
                    ["class", "col settlement-details__value"]
                ], null, null, null, null, null))], null, null)
            }

            function R(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 2, null, null, null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 0, "div", [
                    ["class", "col settlement-details__value"]
                ], null, null, null, null, null)), (l()(), e.ub(2, 0, null, null, 0, "div", [
                    ["class", "col settlement-details__value"]
                ], null, null, null, null, null))], null, null)
            }

            function A(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 10, null, null, null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 9, "div", [
                    ["class", "grid settlement-details__grid"]
                ], null, null, null, null, null)), (l()(), e.ub(2, 0, null, null, 2, "div", [
                    ["class", "col-5 settlement-details__info"]
                ], null, null, null, null, null)), (l()(), e.Nb(3, null, [" ", " "])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(5, 0, null, null, 0, "div", [
                    ["class", "col settlement-details__value"]
                ], null, null, null, null, null)), (l()(), e.ub(6, 0, null, null, 3, "div", [
                    ["class", "col settlement-details__value"]
                ], null, null, null, null, null)), (l()(), e.Nb(7, null, [" ", " "])), e.Ib(8, {
                    currency: 0
                }), e.Hb(131072, I.b, [I.j, e.i]), (l()(), e.ub(10, 0, null, null, 0, "div", [
                    ["class", "col settlement-details__value"]
                ], null, null, null, null, null))], null, (function(l, t) {
                    var n = t.component;
                    l(t, 3, 0, e.Ob(t, 3, 0, e.Gb(t, 4).transform("sa_cancelled")));
                    var u = e.Ob(t, 7, 0, e.Gb(t, 9).transform(n.reportItemized && n.reportItemized.cancelledStakeAmountNet, l(t, 8, 0, n.currency)));
                    l(t, 7, 0, u)
                }))
            }

            function E(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 8, null, null, null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 7, "div", [
                    ["class", "grid text-bold settlement-details__grid"]
                ], null, null, null, null, null)), (l()(), e.ub(2, 0, null, null, 2, "div", [
                    ["class", "settlement-details__info"]
                ], null, null, null, null, null)), (l()(), e.Nb(3, null, [" ", " "])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(5, 0, null, null, 3, "div", [
                    ["class", "col settlement-details__value"]
                ], null, null, null, null, null)), (l()(), e.Nb(6, null, [" ", " "])), e.Ib(7, {
                    currency: 0
                }), e.Hb(131072, I.b, [I.j, e.i])], null, (function(l, t) {
                    var n = t.component;
                    l(t, 3, 0, e.Ob(t, 3, 0, e.Gb(t, 4).transform("sa_stake_taxes")));
                    var u = e.Ob(t, 6, 0, e.Gb(t, 8).transform(n.reportItemized && n.reportItemized.stakeAmountTaxes, l(t, 7, 0, n.currency)));
                    l(t, 6, 0, u)
                }))
            }

            function B(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 8, null, null, null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 7, "div", [
                    ["class", "grid text-bold settlement-details__grid"]
                ], null, null, null, null, null)), (l()(), e.ub(2, 0, null, null, 2, "div", [
                    ["class", "settlement-details__info"]
                ], null, null, null, null, null)), (l()(), e.Nb(3, null, [" ", " "])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(5, 0, null, null, 3, "div", [
                    ["class", "col settlement-details__value"]
                ], null, null, null, null, null)), (l()(), e.Nb(6, null, [" ", " "])), e.Ib(7, {
                    currency: 0
                }), e.Hb(131072, I.b, [I.j, e.i])], null, (function(l, t) {
                    var n = t.component;
                    l(t, 3, 0, e.Ob(t, 3, 0, e.Gb(t, 4).transform("sa_manual_cash_in")));
                    var u = e.Ob(t, 6, 0, e.Gb(t, 8).transform(n.totalDataItemized && n.totalDataItemized.directCashIn, l(t, 7, 0, n.currency)));
                    l(t, 6, 0, u)
                }))
            }

            function $(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 7, "div", [
                    ["class", "grid settlement-details__grid"]
                ], null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 2, "div", [
                    ["class", "col-6 settlement-details__info"]
                ], null, null, null, null, null)), (l()(), e.Nb(2, null, [" ", " "])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(4, 0, null, null, 3, "div", [
                    ["class", "col-6 settlement-details__value"]
                ], null, null, null, null, null)), (l()(), e.Nb(5, null, [" ", " "])), e.Ib(6, {
                    currency: 0
                }), e.Hb(131072, I.b, [I.j, e.i])], null, (function(l, t) {
                    var n = t.component;
                    l(t, 2, 0, e.Ob(t, 2, 0, e.Gb(t, 3).transform(t.parent.context.$implicit.descriptionTag)));
                    var u = e.Ob(t, 5, 0, e.Gb(t, 7).transform(t.parent.context.$implicit.playlistItem.paidAmountGross, l(t, 6, 0, n.currency)));
                    l(t, 5, 0, u)
                }))
            }

            function W(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 2, null, null, null, null, null, null, null)), (l()(), e.jb(16777216, null, null, 1, null, $)), e.tb(2, 16384, null, 0, a.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.jb(0, null, null, 0))], (function(l, t) {
                    l(t, 2, 0, t.context.$implicit.playlistItem.paidAmountGross > 0)
                }), null)
            }

            function J(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 7, "div", [
                    ["class", "grid settlement-details__grid"]
                ], null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 2, "div", [
                    ["class", "settlement-details__info"]
                ], null, null, null, null, null)), (l()(), e.Nb(2, null, [" ", " "])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(4, 0, null, null, 3, "div", [
                    ["class", "col settlement-details__value"]
                ], null, null, null, null, null)), (l()(), e.Nb(5, null, [" ", " "])), e.Ib(6, {
                    currency: 0
                }), e.Hb(131072, I.b, [I.j, e.i])], null, (function(l, t) {
                    var n = t.component;
                    l(t, 2, 0, e.Ob(t, 2, 0, e.Gb(t, 3).transform("sa_manual_cash_out")));
                    var u = e.Ob(t, 5, 0, e.Gb(t, 7).transform(n.totalDataItemized && n.totalDataItemized.directCashOut, l(t, 6, 0, n.currency)));
                    l(t, 5, 0, u)
                }))
            }

            function F(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 7, "div", [
                    ["class", "grid settlement-details__grid"]
                ], null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 2, "div", [
                    ["class", "settlement-details__info"]
                ], null, null, null, null, null)), (l()(), e.Nb(2, null, [" ", " "])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(4, 0, null, null, 3, "div", [
                    ["class", "col settlement-details__value"]
                ], null, null, null, null, null)), (l()(), e.Nb(5, null, [" ", " "])), e.Ib(6, {
                    currency: 0
                }), e.Hb(131072, I.b, [I.j, e.i])], null, (function(l, t) {
                    var n = t.component;
                    l(t, 2, 0, e.Ob(t, 2, 0, e.Gb(t, 3).transform("sa_jackpot")));
                    var u = e.Ob(t, 5, 0, e.Gb(t, 7).transform(n.reportItemized && n.reportItemized.jackpotPaidAmountGross, l(t, 6, 0, n.currency)));
                    l(t, 5, 0, u)
                }))
            }

            function q(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 7, "div", [
                    ["class", "grid settlement-details__grid"]
                ], null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 2, "div", [
                    ["class", "settlement-details__info"]
                ], null, null, null, null, null)), (l()(), e.Nb(2, null, [" ", " "])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(4, 0, null, null, 3, "div", [
                    ["class", "col settlement-details__value"]
                ], null, null, null, null, null)), (l()(), e.Nb(5, null, [" ", " "])), e.Ib(6, {
                    currency: 0
                }), e.Hb(131072, I.b, [I.j, e.i])], null, (function(l, t) {
                    var n = t.component;
                    l(t, 2, 0, e.Ob(t, 2, 0, e.Gb(t, 3).transform("sa_megajackpot")));
                    var u = e.Ob(t, 5, 0, e.Gb(t, 7).transform(n.reportItemized && n.reportItemized.megajackpotPaidAmountGross, l(t, 6, 0, n.currency)));
                    l(t, 5, 0, u)
                }))
            }

            function Z(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 16, null, null, null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 7, "div", [
                    ["class", "grid text-bold settlement-details__grid"]
                ], null, null, null, null, null)), (l()(), e.ub(2, 0, null, null, 2, "div", [
                    ["class", "settlement-details__info"]
                ], null, null, null, null, null)), (l()(), e.Nb(3, null, [" ", " "])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(5, 0, null, null, 3, "div", [
                    ["class", "col settlement-details__value"]
                ], null, null, null, null, null)), (l()(), e.Nb(6, null, [" ", " "])), e.Ib(7, {
                    currency: 0
                }), e.Hb(131072, I.b, [I.j, e.i]), (l()(), e.ub(9, 0, null, null, 7, "div", [
                    ["class", "grid text-bold settlement-details__grid"]
                ], null, null, null, null, null)), (l()(), e.ub(10, 0, null, null, 2, "div", [
                    ["class", "settlement-details__info"]
                ], null, null, null, null, null)), (l()(), e.Nb(11, null, [" ", " "])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(13, 0, null, null, 3, "div", [
                    ["class", "col settlement-details__value"]
                ], null, null, null, null, null)), (l()(), e.Nb(14, null, [" ", " "])), e.Ib(15, {
                    currency: 0
                }), e.Hb(131072, I.b, [I.j, e.i])], null, (function(l, t) {
                    var n = t.component;
                    l(t, 3, 0, e.Ob(t, 3, 0, e.Gb(t, 4).transform("sa_total_payments")));
                    var u = e.Ob(t, 6, 0, e.Gb(t, 8).transform(n.totalPayments, l(t, 7, 0, n.currency)));
                    l(t, 6, 0, u), l(t, 11, 0, e.Ob(t, 11, 0, e.Gb(t, 12).transform("sa_payment_taxes")));
                    var i = e.Ob(t, 14, 0, e.Gb(t, 16).transform(n.reportItemized && -1 * n.reportItemized.paidAmountTaxes, l(t, 15, 0, n.currency)));
                    l(t, 14, 0, i)
                }))
            }

            function L(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 2, "div", [
                    ["class", "text-bold settlement-details__separator"]
                ], null, null, null, null, null)), (l()(), e.Nb(1, null, [" ", " "])), e.Hb(131072, I.i, [I.j, e.i])], null, (function(l, t) {
                    l(t, 1, 0, e.Ob(t, 1, 0, e.Gb(t, 2).transform("sa_information")))
                }))
            }

            function U(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 7, "div", [
                    ["class", "grid settlement-details__grid"]
                ], null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 2, "div", [
                    ["class", "settlement-details__info"]
                ], null, null, null, null, null)), (l()(), e.Nb(2, null, [" ", " "])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(4, 0, null, null, 3, "div", [
                    ["class", "col settlement-details__value"]
                ], null, null, null, null, null)), (l()(), e.Nb(5, null, [" ", " "])), e.Ib(6, {
                    currency: 0
                }), e.Hb(131072, I.b, [I.j, e.i])], null, (function(l, t) {
                    var n = t.component;
                    l(t, 2, 0, e.Ob(t, 2, 0, e.Gb(t, 3).transform("sa_stake_taxes")));
                    var u = e.Ob(t, 5, 0, e.Gb(t, 7).transform(n.reportItemized && n.totalDataItemized.stakeTaxes || 0, l(t, 6, 0, n.currency)));
                    l(t, 5, 0, u)
                }))
            }

            function K(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 7, "div", [
                    ["class", "grid settlement-details__grid"]
                ], null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 2, "div", [
                    ["class", "settlement-details__info"]
                ], null, null, null, null, null)), (l()(), e.Nb(2, null, [" ", " "])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(4, 0, null, null, 3, "div", [
                    ["class", "col settlement-details__value"]
                ], null, null, null, null, null)), (l()(), e.Nb(5, null, [" ", " "])), e.Ib(6, {
                    currency: 0
                }), e.Hb(131072, I.b, [I.j, e.i])], null, (function(l, t) {
                    var n = t.component;
                    l(t, 2, 0, e.Ob(t, 2, 0, e.Gb(t, 3).transform("sa_winning_taxes_retained")));
                    var u = e.Ob(t, 5, 0, e.Gb(t, 7).transform(n.reportItemized && n.totalDataItemized.paidOutTaxes || 0, l(t, 6, 0, n.currency)));
                    l(t, 5, 0, u)
                }))
            }

            function X(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 7, "div", [
                    ["class", "grid settlement-details__grid"]
                ], null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 2, "div", [
                    ["class", "settlement-details__info"]
                ], null, null, null, null, null)), (l()(), e.Nb(2, null, [" ", " "])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(4, 0, null, null, 3, "div", [
                    ["class", "col settlement-details__value"]
                ], null, null, null, null, null)), (l()(), e.Nb(5, null, [" ", " "])), e.Ib(6, {
                    currency: 0
                }), e.Hb(131072, I.b, [I.j, e.i])], null, (function(l, t) {
                    var n = t.component;
                    l(t, 2, 0, e.Ob(t, 2, 0, e.Gb(t, 3).transform("sa_open_winning")));
                    var u = e.Ob(t, 5, 0, e.Gb(t, 7).transform(n.reportItemized && n.totalDataItemized.won - n.totalDataItemized.paidOut || 0, l(t, 6, 0, n.currency)));
                    l(t, 5, 0, u)
                }))
            }

            function Y(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 7, "div", [
                    ["class", "grid settlement-details__grid"]
                ], null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 2, "div", [
                    ["class", "settlement-details__info"]
                ], null, null, null, null, null)), (l()(), e.Nb(2, null, [" ", " "])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(4, 0, null, null, 3, "div", [
                    ["class", "col settlement-details__value"]
                ], null, null, null, null, null)), (l()(), e.Nb(5, null, [" ", " "])), e.Ib(6, {
                    currency: 0
                }), e.Hb(131072, I.b, [I.j, e.i])], null, (function(l, t) {
                    var n = t.component;
                    l(t, 2, 0, e.Ob(t, 2, 0, e.Gb(t, 3).transform("sa_jackpot_to_be_paid")));
                    var u = e.Ob(t, 5, 0, e.Gb(t, 7).transform(n.reportItemized && n.totalDataItemized.jackpotWon - n.totalDataItemized.jackpotPaidOut || 0, l(t, 6, 0, n.currency)));
                    l(t, 5, 0, u)
                }))
            }

            function Q(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 7, "div", [
                    ["class", "grid settlement-details__grid"]
                ], null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 2, "div", [
                    ["class", "settlement-details__info"]
                ], null, null, null, null, null)), (l()(), e.Nb(2, null, [" ", " "])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(4, 0, null, null, 3, "div", [
                    ["class", "col settlement-details__value"]
                ], null, null, null, null, null)), (l()(), e.Nb(5, null, [" ", " "])), e.Ib(6, {
                    currency: 0
                }), e.Hb(131072, I.b, [I.j, e.i])], null, (function(l, t) {
                    var n = t.component;
                    l(t, 2, 0, e.Ob(t, 2, 0, e.Gb(t, 3).transform("sa_megajackpot_to_be_paid")));
                    var u = e.Ob(t, 5, 0, e.Gb(t, 7).transform(n.reportItemized && n.totalDataItemized.megaJackpotWon - n.totalDataItemized.megaJackpotPaidOut || 0, l(t, 6, 0, n.currency)));
                    l(t, 5, 0, u)
                }))
            }

            function V(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 100, null, null, null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 8, "div", [
                    ["class", "grid text-bold settlement-details__separator"]
                ], null, null, null, null, null)), (l()(), e.ub(2, 0, null, null, 2, "div", [
                    ["class", "col-5"]
                ], null, null, null, null, null)), (l()(), e.Nb(3, null, ["", ""])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(5, 0, null, null, 2, "div", [
                    ["class", "col text-right settlement-details__separator-column"]
                ], null, null, null, null, null)), (l()(), e.Nb(6, null, ["", ""])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.jb(16777216, null, null, 1, null, w)), e.tb(9, 16384, null, 0, a.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.jb(16777216, null, null, 1, null, M)), e.tb(11, 278528, null, 0, a.k, [e.R, e.O, e.u], {
                    ngForOf: [0, "ngForOf"]
                }, null), (l()(), e.ub(12, 0, null, null, 0, "div", [
                    ["class", "settlement-details__separator"]
                ], [
                    [2, "settlement-details__separator--half", null],
                    [2, "settlement-details__separator--thin", null]
                ], null, null, null, null)), (l()(), e.ub(13, 0, null, null, 11, "div", [
                    ["class", "grid settlement-details__grid"]
                ], null, null, null, null, null)), (l()(), e.ub(14, 0, null, null, 2, "div", [
                    ["class", "col-5 settlement-details__info"]
                ], null, null, null, null, null)), (l()(), e.Nb(15, null, [" ", " "])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.jb(16777216, null, null, 1, null, D)), e.tb(18, 16384, null, 0, a.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.ub(19, 0, null, null, 3, "div", [
                    ["class", "col settlement-details__value"]
                ], null, null, null, null, null)), (l()(), e.Nb(20, null, [" ", " "])), e.Ib(21, {
                    currency: 0
                }), e.Hb(131072, I.b, [I.j, e.i]), (l()(), e.jb(16777216, null, null, 1, null, R)), e.tb(24, 16384, null, 0, a.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.jb(16777216, null, null, 1, null, A)), e.tb(26, 16384, null, 0, a.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.ub(27, 0, null, null, 7, "div", [
                    ["class", "grid text-bold settlement-details__grid"]
                ], null, null, null, null, null)), (l()(), e.ub(28, 0, null, null, 2, "div", [
                    ["class", "settlement-details__info"]
                ], null, null, null, null, null)), (l()(), e.Nb(29, null, [" ", " "])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(31, 0, null, null, 3, "div", [
                    ["class", "col settlement-details__value"]
                ], null, null, null, null, null)), (l()(), e.Nb(32, null, [" ", " "])), e.Ib(33, {
                    currency: 0
                }), e.Hb(131072, I.b, [I.j, e.i]), (l()(), e.jb(16777216, null, null, 1, null, E)), e.tb(36, 16384, null, 0, a.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.jb(16777216, null, null, 1, null, B)), e.tb(38, 16384, null, 0, a.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.ub(39, 0, null, null, 7, "div", [
                    ["class", "grid text-bold settlement-details__grid"]
                ], null, null, null, null, null)), (l()(), e.ub(40, 0, null, null, 2, "div", [
                    ["class", "settlement-details__info settlement-details__info--highlight"]
                ], null, null, null, null, null)), (l()(), e.Nb(41, null, [" ", " "])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(43, 0, null, null, 3, "div", [
                    ["class", "col settlement-details__value settlement-details__value--highlight"]
                ], null, null, null, null, null)), (l()(), e.Nb(44, null, [" ", " "])), e.Ib(45, {
                    currency: 0
                }), e.Hb(131072, I.b, [I.j, e.i]), (l()(), e.ub(47, 0, null, null, 6, "div", [
                    ["class", "grid text-bold settlement-details__separator"]
                ], null, null, null, null, null)), (l()(), e.ub(48, 0, null, null, 2, "div", [
                    ["class", "col-8"]
                ], null, null, null, null, null)), (l()(), e.Nb(49, null, ["", ""])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(51, 0, null, null, 2, "div", [
                    ["class", "col text-right settlement-details__separator-column"]
                ], null, null, null, null, null)), (l()(), e.Nb(52, null, ["", ""])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.jb(16777216, null, null, 1, null, W)), e.tb(55, 278528, null, 0, a.k, [e.R, e.O, e.u], {
                    ngForOf: [0, "ngForOf"]
                }, null), (l()(), e.jb(16777216, null, null, 1, null, J)), e.tb(57, 16384, null, 0, a.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.jb(16777216, null, null, 1, null, F)), e.tb(59, 16384, null, 0, a.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.jb(16777216, null, null, 1, null, q)), e.tb(61, 16384, null, 0, a.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.jb(16777216, null, null, 1, null, Z)), e.tb(63, 16384, null, 0, a.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.ub(64, 0, null, null, 7, "div", [
                    ["class", "grid text-bold settlement-details__grid"]
                ], null, null, null, null, null)), (l()(), e.ub(65, 0, null, null, 2, "div", [
                    ["class", "settlement-details__info settlement-details__info--highlight"]
                ], null, null, null, null, null)), (l()(), e.Nb(66, null, [" ", " "])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(68, 0, null, null, 3, "div", [
                    ["class", "col settlement-details__value settlement-details__value--highlight"]
                ], null, null, null, null, null)), (l()(), e.Nb(69, null, [" ", " "])), e.Ib(70, {
                    currency: 0
                }), e.Hb(131072, I.b, [I.j, e.i]), (l()(), e.ub(72, 0, null, null, 7, "div", [
                    ["class", "grid settlement-details__square"]
                ], null, null, null, null, null)), (l()(), e.ub(73, 0, null, null, 2, "div", [
                    ["class", "settlement-details__info settlement-details__info--squared settlement-details__info--highlight"]
                ], null, null, null, null, null)), (l()(), e.Nb(74, null, [" ", " "])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(76, 0, null, null, 3, "div", [
                    ["class", "col settlement-details__value settlement-details__value--squared settlement-details__value--highlight"]
                ], null, null, null, null, null)), (l()(), e.Nb(77, null, [" ", " "])), e.Ib(78, {
                    currency: 0
                }), e.Hb(131072, I.b, [I.j, e.i]), (l()(), e.jb(16777216, null, null, 1, null, L)), e.tb(81, 16384, null, 0, a.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.jb(16777216, null, null, 1, null, U)), e.tb(83, 16384, null, 0, a.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.jb(16777216, null, null, 1, null, K)), e.tb(85, 16384, null, 0, a.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.jb(16777216, null, null, 1, null, X)), e.tb(87, 16384, null, 0, a.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.jb(16777216, null, null, 1, null, Y)), e.tb(89, 16384, null, 0, a.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.jb(16777216, null, null, 1, null, Q)), e.tb(91, 16384, null, 0, a.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.ub(92, 0, null, null, 0, "div", [
                    ["class", "settlement-details__separator"]
                ], null, null, null, null, null)), (l()(), e.ub(93, 0, null, null, 7, "div", [
                    ["class", "grid text-bold settlement-details__grid"]
                ], null, null, null, null, null)), (l()(), e.ub(94, 0, null, null, 2, "div", [
                    ["class", "settlement-details__info settlement-details__info--highlight"]
                ], null, null, null, null, null)), (l()(), e.Nb(95, null, [" ", " "])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(97, 0, null, null, 3, "div", [
                    ["class", "col settlement-details__value settlement-details__value--highlight"]
                ], null, null, null, null, null)), (l()(), e.Nb(98, null, [" ", " "])), e.Ib(99, {
                    currency: 0
                }), e.Hb(131072, I.b, [I.j, e.i])], (function(l, t) {
                    var n = t.component;
                    l(t, 9, 0, n.someCancelledStakesAreGreaterThatZero), l(t, 11, 0, n.playlistDataItemized), l(t, 18, 0, !n.someCancelledStakesAreGreaterThatZero), l(t, 24, 0, n.someCancelledStakesAreGreaterThatZero), l(t, 26, 0, n.reportItemized && n.reportItemized.cancelledStakeAmountNet), l(t, 36, 0, n.reportItemized && n.reportItemized.stakeAmountTaxes), l(t, 38, 0, n.reportItemized && n.totalDataItemized.directCashIn), l(t, 55, 0, n.playlistDataItemized), l(t, 57, 0, n.totalDataItemized.directCashOut > 0), l(t, 59, 0, n.reportItemized.jackpotPaidAmountGross > 0), l(t, 61, 0, n.reportItemized.megajackpotPaidAmountGross > 0), l(t, 63, 0, n.entityHasPaidoutTaxes), l(t, 81, 0, n.totalInformation), l(t, 83, 0, n.totalDataItemized.stakeTaxes > 0), l(t, 85, 0, n.totalDataItemized.paidOutTaxes > 0), l(t, 87, 0, n.totalDataItemized.paidOut !== n.totalDataItemized.won), l(t, 89, 0, n.totalDataItemized.jackpotPaidOut !== n.totalDataItemized.jackpotWon), l(t, 91, 0, n.totalDataItemized.megaJackpotPaidOut !== n.totalDataItemized.megaJackpotWon)
                }), (function(l, t) {
                    var n = t.component;
                    l(t, 3, 0, e.Ob(t, 3, 0, e.Gb(t, 4).transform("sa_income"))), l(t, 6, 0, e.Ob(t, 6, 0, e.Gb(t, 7).transform("sa_turnover"))), l(t, 12, 0, n.someCancelledStakesAreGreaterThatZero, !n.someCancelledStakesAreGreaterThatZero), l(t, 15, 0, e.Ob(t, 15, 0, e.Gb(t, 16).transform("sa_turnover")));
                    var u = e.Ob(t, 20, 0, e.Gb(t, 22).transform(n.reportItemized && n.reportItemized.stakeAmountNet + n.reportItemized.cancelledStakeAmountNet, l(t, 21, 0, n.currency)));
                    l(t, 20, 0, u), l(t, 29, 0, e.Ob(t, 29, 0, e.Gb(t, 30).transform("sa_confirmed_stake")));
                    var i = e.Ob(t, 32, 0, e.Gb(t, 34).transform(n.reportItemized && n.reportItemized.stakeAmountNet, l(t, 33, 0, n.currency)));
                    l(t, 32, 0, i), l(t, 41, 0, e.Ob(t, 41, 0, e.Gb(t, 42).transform("sa_total_income")));
                    var r = e.Ob(t, 44, 0, e.Gb(t, 46).transform(n.totalIncome, l(t, 45, 0, n.currency)));
                    l(t, 44, 0, r), l(t, 49, 0, e.Ob(t, 49, 0, e.Gb(t, 50).transform("sa_outcome"))), l(t, 52, 0, e.Ob(t, 52, 0, e.Gb(t, 53).transform("sa_paid"))), l(t, 66, 0, e.Ob(t, 66, 0, e.Gb(t, 67).transform("sa_total_outcome")));
                    var a = e.Ob(t, 69, 0, e.Gb(t, 71).transform(n.totalOutcome, l(t, 70, 0, n.currency)));
                    l(t, 69, 0, a), l(t, 74, 0, e.Ob(t, 74, 0, e.Gb(t, 75).transform("sa_balance")));
                    var o = e.Ob(t, 77, 0, e.Gb(t, 79).transform(n.totalBalance || 0, l(t, 78, 0, n.currency)));
                    l(t, 77, 0, o), l(t, 95, 0, e.Ob(t, 95, 0, e.Gb(t, 96).transform("sa_net_balance")));
                    var s = e.Ob(t, 98, 0, e.Gb(t, 100).transform(n.totalNetBalance || 0, l(t, 99, 0, n.currency)));
                    l(t, 98, 0, s)
                }))
            }

            function ll(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 2, "div", [
                    ["class", "settlement-details__separator"]
                ], null, null, null, null, null)), (l()(), e.Nb(1, null, [" ", " "])), e.Hb(131072, I.i, [I.j, e.i])], null, (function(l, t) {
                    l(t, 1, 0, e.Ob(t, 1, 0, e.Gb(t, 2).transform("sa_no_data")))
                }))
            }

            function tl(l) {
                return e.Pb(2, [(l()(), e.ub(0, 0, null, null, 63, "div", [
                    ["class", "settlement-details"]
                ], null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 16, "div", [
                    ["class", "grid grid-middle settlement-details__header"]
                ], null, null, null, null, null)), (l()(), e.ub(2, 0, null, null, 0, "span", [
                    ["class", "icon icon-arrow-back settlement-details__back"]
                ], null, [
                    [null, "click"]
                ], (function(l, t, n) {
                    var e = !0;
                    return "click" === t && (e = !1 !== l.component.back.emit() && e), e
                }), null, null)), (l()(), e.ub(3, 0, null, null, 11, "div", [
                    ["class", "col grid grid-column"]
                ], null, null, null, null, null)), (l()(), e.ub(4, 0, null, null, 6, "div", [
                    ["class", "grid"]
                ], null, null, null, null, null)), (l()(), e.ub(5, 0, null, null, 2, "span", [
                    ["class", "settlement-details__time"]
                ], null, null, null, null, null)), (l()(), e.Nb(6, null, [" ", " "])), e.Hb(131072, I.c, [I.j, e.i]), (l()(), e.ub(8, 0, null, null, 2, "span", [
                    ["class", "settlement-details__date"]
                ], null, null, null, null, null)), (l()(), e.Nb(9, null, [" ", " "])), e.Hb(131072, I.c, [I.j, e.i]), (l()(), e.ub(11, 0, null, null, 3, "div", [
                    ["class", "settlement-details__quantity"]
                ], null, null, null, null, null)), (l()(), e.Nb(12, null, [" ", " "])), e.Ib(13, {
                    currency: 0
                }), e.Hb(131072, I.b, [I.j, e.i]), (l()(), e.ub(15, 0, null, null, 2, "div", [], null, null, null, null, null)), (l()(), e.ub(16, 0, null, null, 1, "div", [
                    ["class", "button button--icon"]
                ], null, [
                    [null, "click"]
                ], (function(l, t, n) {
                    var e = !0;
                    return "click" === t && (e = !1 !== l.component.print() && e), e
                }), null, null)), (l()(), e.ub(17, 0, null, null, 0, "span", [
                    ["class", "icon icon-printer"]
                ], null, null, null, null, null)), (l()(), e.ub(18, 0, null, null, 45, "div", [
                    ["class", "settlement-details__content"]
                ], null, null, null, null, null)), (l()(), e.ub(19, 0, null, null, 44, "div", [
                    ["class", "grid grid-column settlement-details__grid"]
                ], null, null, null, null, null)), (l()(), e.ub(20, 0, null, null, 5, "div", [
                    ["class", "grid settlement-details__grid"]
                ], null, null, null, null, null)), (l()(), e.ub(21, 0, null, null, 2, "div", [
                    ["class", "text-bold settlement-details__info settlement-details__info--small"]
                ], null, null, null, null, null)), (l()(), e.Nb(22, null, [" ", " "])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(24, 0, null, null, 1, "div", [
                    ["class", "col settlement-details__value settlement-details__value--small"]
                ], null, null, null, null, null)), (l()(), e.Nb(25, null, [" ", " "])), (l()(), e.ub(26, 0, null, null, 10, "div", [
                    ["class", "grid settlement-details__grid"]
                ], null, null, null, null, null)), (l()(), e.ub(27, 0, null, null, 2, "div", [
                    ["class", "text-bold settlement-details__info settlement-details__info--small"]
                ], null, null, null, null, null)), (l()(), e.Nb(28, null, [" ", " "])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(30, 0, null, null, 6, "div", [
                    ["class", "col settlement-details__value settlement-details__value--small"]
                ], null, null, null, null, null)), (l()(), e.ub(31, 0, null, null, 1, "span", [], null, null, null, null, null)), (l()(), e.Nb(32, null, ["(", ")"])), (l()(), e.ub(33, 0, null, null, 1, "span", [
                    ["class", "text-bold"]
                ], null, null, null, null, null)), (l()(), e.Nb(34, null, ["", ""])), (l()(), e.ub(35, 0, null, null, 1, "span", [], null, null, null, null, null)), (l()(), e.Nb(36, null, ["", ""])), (l()(), e.ub(37, 0, null, null, 10, "div", [
                    ["class", "grid settlement-details__grid"]
                ], null, null, null, null, null)), (l()(), e.ub(38, 0, null, null, 2, "div", [
                    ["class", "text-bold settlement-details__info settlement-details__info--small"]
                ], null, null, null, null, null)), (l()(), e.Nb(39, null, [" ", " "])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(41, 0, null, null, 6, "div", [
                    ["class", "col settlement-details__value settlement-details__value--small"]
                ], null, null, null, null, null)), (l()(), e.ub(42, 0, null, null, 1, "span", [], null, null, null, null, null)), (l()(), e.Nb(43, null, ["(", ")"])), (l()(), e.ub(44, 0, null, null, 1, "span", [
                    ["class", "text-bold"]
                ], null, null, null, null, null)), (l()(), e.Nb(45, null, ["", ""])), (l()(), e.ub(46, 0, null, null, 1, "span", [], null, null, null, null, null)), (l()(), e.Nb(47, null, ["", ""])), (l()(), e.ub(48, 0, null, null, 6, "div", [
                    ["class", "grid settlement-details__grid"]
                ], null, null, null, null, null)), (l()(), e.ub(49, 0, null, null, 2, "div", [
                    ["class", "text-bold settlement-details__info settlement-details__info--small"]
                ], null, null, null, null, null)), (l()(), e.Nb(50, null, [" ", " "])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(52, 0, null, null, 2, "div", [
                    ["class", "col settlement-details__value settlement-details__value--small"]
                ], null, null, null, null, null)), (l()(), e.Nb(53, null, [" ", " "])), e.Hb(131072, I.c, [I.j, e.i]), (l()(), e.ub(55, 0, null, null, 6, "div", [
                    ["class", "grid settlement-details__grid"]
                ], null, null, null, null, null)), (l()(), e.ub(56, 0, null, null, 2, "div", [
                    ["class", "text-bold settlement-details__info settlement-details__info--small"]
                ], null, null, null, null, null)), (l()(), e.Nb(57, null, [" ", " "])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(59, 0, null, null, 2, "div", [
                    ["class", "col settlement-details__value settlement-details__value--small"]
                ], null, null, null, null, null)), (l()(), e.Nb(60, null, [" ", " "])), e.Hb(131072, I.c, [I.j, e.i]), (l()(), e.jb(16777216, null, null, 1, null, V)), e.tb(63, 16384, null, 0, a.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"],
                    ngIfElse: [1, "ngIfElse"]
                }, null), (l()(), e.jb(0, [
                    ["noDataTemplate", 2]
                ], null, 0, null, ll))], (function(l, t) {
                    l(t, 63, 0, t.component.currency, e.Gb(t, 64))
                }), (function(l, t) {
                    var n = t.component;
                    l(t, 6, 0, e.Ob(t, 6, 0, e.Gb(t, 7).transform(n.settlement.generationTime, "time"))), l(t, 9, 0, e.Ob(t, 9, 0, e.Gb(t, 10).transform(n.settlement.generationTime, "date")));
                    var u = e.Ob(t, 12, 0, e.Gb(t, 14).transform(n.totalNetBalance || 0, l(t, 13, 0, n.currency)));
                    l(t, 12, 0, u), l(t, 22, 0, e.Ob(t, 22, 0, e.Gb(t, 23).transform("sa_report_id"))), l(t, 25, 0, n.reportId), l(t, 28, 0, e.Ob(t, 28, 0, e.Gb(t, 29).transform("sa_account_id"))), l(t, 32, 0, n.entityId), l(t, 34, 0, n.accountName), l(t, 36, 0, n.accountExternalId), l(t, 39, 0, e.Ob(t, 39, 0, e.Gb(t, 40).transform("sa_printed_by"))), l(t, 43, 0, n.creatorId), l(t, 45, 0, n.creatorName), l(t, 47, 0, n.creatorExternalId), l(t, 50, 0, e.Ob(t, 50, 0, e.Gb(t, 51).transform("sa_from"))), l(t, 53, 0, e.Ob(t, 53, 0, e.Gb(t, 54).transform(n.settlement.startTime, "datetime"))), l(t, 57, 0, e.Ob(t, 57, 0, e.Gb(t, 58).transform("sa_to"))), l(t, 60, 0, e.Ob(t, 60, 0, e.Gb(t, 61).transform(n.settlement.endTime, "datetime")))
                }))
            }
            var nl = n("7oEI"),
                el = n("6blF"),
                ul = n("psW0"),
                il = function() {
                    function l(l, t, n) {
                        this.coreService = l, this.i18nService = t, this.modalService = n, this.isRegisteringSettlement = !1
                    }
                    return l.prototype.formatCredit = function(l, t) {
                        if (void 0 !== l) {
                            var n = (t || this.currentSettlement).currency;
                            return n || (n = this.coreService.getWalletManager().getCurrentWallet().currency.code), this.i18nService.location.getCredit(l, {
                                currency: this.coreService.getCurrency(n)
                            })
                        }
                    }, l.prototype.getStake = function(l) {
                        if (!l) return this.getStatItemized(l).stakeAmountGross
                    }, l.prototype.getTaxes = function(l) {
                        if (!l) return this.getStatItemized().stakeAmountTaxes
                    }, l.prototype.getNetIncome = function(l) {
                        return this.getStatItemized(l).stakeAmountNet
                    }, l.prototype.getPaid = function(l) {
                        return this.getStatItemized(l).paidAmountGross
                    }, l.prototype.getPaidTaxes = function(l) {
                        if (!l) return this.getStatItemized().paidAmountTaxes
                    }, l.prototype.getCancelled = function(l) {
                        if (!l) return this.getStatItemized().cancelledStakeAmountGross
                    }, l.prototype.getJackpotPaid = function(l) {
                        if (!l) return this.getStatItemized().jackpotPaidAmountGross
                    }, l.prototype.getMegajackpotPaid = function(l) {
                        if (!l) return this.getStatItemized().megajackpotPaidAmountGross
                    }, l.prototype.getOutcome = function(l) {
                        if (!l) return this.getStatItemized().outcomeAmountGross
                    }, l.prototype.getOutcomeTaxes = function(l) {
                        if (!l) return this.getStatItemized().paidAmountTaxes
                    }, l.prototype.getNetTotalOutcome = function(l) {
                        if (!l) return this.getStatItemized().outcomeAmountNet
                    }, l.prototype.getBalance = function() {
                        return this.getStatItemized().balanceAmountGross
                    }, l.prototype.getBalanceTaxes = function() {
                        return this.getStatItemized().balanceAmountTaxes
                    }, l.prototype.getNetBalance = function() {
                        return this.getStatItemized().balanceAmountNet
                    }, l.prototype.getWon = function(l) {
                        return this.getStatItemized(l).wonAmountGross
                    }, l.prototype.getJackpotWon = function(l) {
                        return this.getStatItemized(l).jackpotWonAmountGross
                    }, l.prototype.getMegajackpotWon = function(l) {
                        return this.getStatItemized(l).megajackpotWonAmountGross
                    }, l.prototype.getBonus = function(l) {
                        return this.getStatItemized(l).bonusWonAmountGross
                    }, l.prototype.getNetTurnover = function(l) {
                        if (!l) return this.getStatItemized().turnoverAmountNet
                    }, l.prototype.getCapped = function(l) {
                        if (!l) return this.getStatItemized().cappedWonAmountGross
                    }, l.prototype.getCappedPaid = function(l) {
                        if (!l) return this.getStatItemized().cappedPaidAmountGross
                    }, l.prototype.getJackpotContribution = function(l) {
                        if (!l) return this.getStatItemized().jackpotContributionAmountGross
                    }, l.prototype.getMegaJackpotContribution = function(l) {
                        if (!l) return this.getStatItemized().megajackpotContributionAmountGross
                    }, l.prototype.getStatItemized = function(l) {
                        return l ? l._clData.statDetailItemized : this.currentSettlement._clData.statItemized
                    }, l.prototype.registerSettlement = function(l) {
                        var t = this;
                        return new el.a((function(l) {
                            var n = !1;
                            t.modalService.openDialog("base", {
                                text: t.i18nService.get("sa_proceed_with_settlement"),
                                textInfo: t.i18nService.get("sa_proceed_with_settlement_info_text"),
                                buttons: [{
                                    text: t.i18nService.get("sa_cancel").toUpperCase()
                                }, {
                                    type: "success",
                                    text: t.i18nService.get("sa_proceed").toUpperCase(),
                                    action: function() {
                                        n = !0, t.isRegisteringSettlement = !0
                                    }
                                }]
                            }).afterClosed.subscribe(null, null, (function() {
                                n ? l.next() : l.complete()
                            }))
                        })).pipe(Object(ul.a)((function() {
                            return Object(N.a)(t.coreService.registerSettlement(l))
                        })))
                    }, l.ngInjectableDef = e.Tb({
                        factory: function() {
                            return new l(e.Ub(C.a), e.Ub(I.j), e.Ub(nl.a))
                        },
                        token: l,
                        providedIn: "root"
                    }), l
                }(),
                rl = function() {
                    function l(l) {
                        this.turnoverService = l, this.settlements = [], this.ReportStatus = x.coreModel.ReportStatus, this.settlementsWithData = []
                    }
                    return l.prototype.ngOnInit = function() {
                        this.filterEmptySettlementReport()
                    }, l.prototype.ngOnChanges = function(l) {
                        l.settlements && !l.settlements.isFirstChange() && this.filterEmptySettlementReport()
                    }, l.prototype.onSettlementSelected = function(l) {
                        this.settlementSelected = l
                    }, l.prototype.onBackSettlementDetails = function() {
                        this.settlementSelected = null
                    }, l.prototype.hasSettlementData = function(l) {
                        return l.data && l.data.isSettlementReportData() && l.data.data.length > 0 && (l.status === this.ReportStatus.GENERATED || l.status === this.ReportStatus.RENDERED)
                    }, l.prototype.filterEmptySettlementReport = function() {
                        var l = this;
                        this.settlementsWithData = this.settlements.filter((function(t) {
                            return l.hasSettlementData(t)
                        })).sort((function(l, t) {
                            var n = l.creationTime instanceof Date ? l.creationTime.getTime() : null;
                            return (t.creationTime instanceof Date ? t.creationTime.getTime() : null) - n
                        }))
                    }, l.prototype.isRegisteringSettlement = function() {
                        return this.turnoverService.isRegisteringSettlement
                    }, l
                }(),
                al = e.sb({
                    encapsulation: 0,
                    styles: [
                        [".settlements[_ngcontent-%COMP%]{position:relative;width:100%;height:100%;overflow-x:hidden;background-color:#eceff1}.settlements__header[_ngcontent-%COMP%]{padding:38px 20px;font-size:16px;font-weight:700;color:rgba(0,0,0,.87);text-transform:uppercase;background-color:#e4e7e8}.settlements__content[_ngcontent-%COMP%]{padding:0 20px}.settlements__settlement[_ngcontent-%COMP%]{padding:12px 0;border-bottom:1px solid rgba(0,0,0,.15)}.settlements__settlement[_ngcontent-%COMP%]:last-child{border-bottom:0}.settlements__details[_ngcontent-%COMP%]{position:absolute;top:0;width:100%;height:100%}.settlements__pending-message[_ngcontent-%COMP%]{padding:12px 0;border-bottom:1px solid rgba(0,0,0,.15)}.settlements__pending-message[_ngcontent-%COMP%]:last-child{border-bottom:0}"]
                    ],
                    data: {
                        animation: [{
                            type: 7,
                            name: "settlementAnimation",
                            definitions: [{
                                type: 0,
                                name: "void",
                                styles: {
                                    type: 6,
                                    styles: {
                                        transform: "translateX(100%)"
                                    },
                                    offset: null
                                },
                                options: void 0
                            }, {
                                type: 0,
                                name: "*",
                                styles: {
                                    type: 6,
                                    styles: {
                                        transform: "translateX(0)"
                                    },
                                    offset: null
                                },
                                options: void 0
                            }, {
                                type: 1,
                                expr: ":enter, :leave",
                                animation: {
                                    type: 4,
                                    styles: null,
                                    timings: 100
                                },
                                options: null
                            }],
                            options: {}
                        }]
                    }
                });

            function ol(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 2, "div", [
                    ["class", "settlements__pending-message"]
                ], null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 1, "grsa-settlement-pending", [], null, null, null, y, S)), e.tb(2, 114688, null, 0, O, [], null, null)], (function(l, t) {
                    l(t, 2, 0)
                }), null)
            }

            function sl(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 1, "grsa-settlement", [], null, [
                    [null, "selected"]
                ], (function(l, t, n) {
                    var e = !0;
                    return "selected" === t && (e = !1 !== l.component.onSettlementSelected(l.parent.context.$implicit) && e), e
                }), k, j)), e.tb(1, 114688, null, 0, P, [C.a], {
                    settlement: [0, "settlement"]
                }, {
                    selected: "selected"
                })], (function(l, t) {
                    l(t, 1, 0, t.parent.context.$implicit)
                }), null)
            }

            function cl(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 2, "div", [
                    ["class", "settlements__settlement"]
                ], null, null, null, null, null)), (l()(), e.jb(16777216, null, null, 1, null, sl)), e.tb(2, 16384, null, 0, a.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(l, t) {
                    var n = t.component;
                    l(t, 2, 0, t.context.$implicit.status === n.ReportStatus.GENERATED || t.context.$implicit.status === n.ReportStatus.RENDERED)
                }), null)
            }

            function dl(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 2, null, null, null, null, null, null, null)), (l()(), e.jb(16777216, null, null, 1, null, cl)), e.tb(2, 278528, null, 0, a.k, [e.R, e.O, e.u], {
                    ngForOf: [0, "ngForOf"]
                }, null), (l()(), e.jb(0, null, null, 0))], (function(l, t) {
                    l(t, 2, 0, t.component.settlementsWithData)
                }), null)
            }

            function bl(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 2, "div", [
                    ["class", "settlements__details"]
                ], [
                    [24, "@settlementAnimation", 0]
                ], null, null, null, null)), (l()(), e.ub(1, 0, null, null, 1, "grsa-settlement-details", [], null, [
                    [null, "back"]
                ], (function(l, t, n) {
                    var e = !0;
                    return "back" === t && (e = !1 !== l.component.onBackSettlementDetails() && e), e
                }), tl, T)), e.tb(2, 114688, null, 0, G, [C.a], {
                    settlement: [0, "settlement"]
                }, {
                    back: "back"
                })], (function(l, t) {
                    l(t, 2, 0, t.component.settlementSelected)
                }), (function(l, t) {
                    l(t, 0, 0, void 0)
                }))
            }

            function ml(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 2, "div", [
                    ["class", "settlements__settlement"]
                ], null, null, null, null, null)), (l()(), e.Nb(1, null, [" ", " "])), e.Hb(131072, I.i, [I.j, e.i])], null, (function(l, t) {
                    l(t, 1, 0, e.Ob(t, 1, 0, e.Gb(t, 2).transform("sa_no_data")))
                }))
            }

            function gl(l) {
                return e.Pb(2, [(l()(), e.ub(0, 0, null, null, 11, "div", [
                    ["class", "settlements"]
                ], null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 3, "div", [
                    ["class", "settlements__header"]
                ], null, null, null, null, null)), (l()(), e.ub(2, 0, null, null, 2, "span", [], null, null, null, null, null)), (l()(), e.Nb(3, null, ["", ""])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(5, 0, null, null, 4, "div", [
                    ["class", "settlements__content"]
                ], null, null, null, null, null)), (l()(), e.jb(16777216, null, null, 1, null, ol)), e.tb(7, 16384, null, 0, a.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.jb(16777216, null, null, 1, null, dl)), e.tb(9, 16384, null, 0, a.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"],
                    ngIfElse: [1, "ngIfElse"]
                }, null), (l()(), e.jb(16777216, null, null, 1, null, bl)), e.tb(11, 16384, null, 0, a.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.jb(0, [
                    ["noDataTemplate", 2]
                ], null, 0, null, ml))], (function(l, t) {
                    var n = t.component;
                    l(t, 7, 0, n.isRegisteringSettlement()), l(t, 9, 0, n.settlementsWithData.length > 0, e.Gb(t, 12)), l(t, 11, 0, n.settlementSelected)
                }), (function(l, t) {
                    l(t, 3, 0, e.Ob(t, 3, 0, e.Gb(t, 4).transform("sa_latest_settlements")))
                }))
            }
            var _l = n("pugT"),
                pl = n("xMyE"),
                fl = n("2WpN"),
                vl = n("yU3L"),
                hl = function() {
                    for (var l = 0, t = 0, n = arguments.length; t < n; t++) l += arguments[t].length;
                    var e = Array(l),
                        u = 0;
                    for (t = 0; t < n; t++)
                        for (var i = arguments[t], r = 0, a = i.length; r < a; r++, u++) e[u] = i[r];
                    return e
                },
                Il = function() {
                    function l(l, t, n, e, u) {
                        var i = this;
                        this.cd = l, this.i18nService = t, this.loadingPanelService = n, this.coreService = e, this.turnoverService = u, this.incomeOutcome = {
                            income: this.i18nService.get("tk_income"),
                            outcome: this.i18nService.get("tk_outcome")
                        }, this.incomeRows = [{
                            title: this.i18nService.get("sa_gross_income"),
                            getCellText: function(l) {
                                return i.turnoverService.formatCredit(i.turnoverService.getStake(l), l)
                            }
                        }, {
                            title: this.i18nService.get("sa_taxes"),
                            getCellText: function(l) {
                                return i.turnoverService.formatCredit(i.turnoverService.getTaxes(l), l)
                            }
                        }, {
                            title: this.i18nService.get("sa_net_income"),
                            getCellText: function(l) {
                                return i.turnoverService.formatCredit(i.turnoverService.getNetIncome(l), l)
                            },
                            highlight: !0
                        }], this.outcomeRows = [{
                            title: this.i18nService.get("sa_paid"),
                            getCellText: function(l) {
                                return i.turnoverService.formatCredit(i.turnoverService.getPaid(l), l)
                            }
                        }, {
                            title: this.i18nService.get("sa_jackpot_paid"),
                            getCellText: function(l) {
                                return i.turnoverService.formatCredit(i.turnoverService.getJackpotPaid(l), l)
                            }
                        }, {
                            title: this.i18nService.get("sa_megajackpot_paid"),
                            getCellText: function(l) {
                                return i.turnoverService.formatCredit(i.turnoverService.getMegajackpotPaid(l), l)
                            }
                        }, {
                            title: this.i18nService.get("sa_outcome"),
                            highlight: !0,
                            getCellText: function(l) {
                                return i.turnoverService.formatCredit(i.turnoverService.getOutcome(l), l)
                            }
                        }, {
                            title: this.i18nService.get("sa_payout_taxes"),
                            getCellText: function(l) {
                                return i.turnoverService.formatCredit(i.turnoverService.getPaidTaxes(l), l)
                            }
                        }, {
                            title: this.i18nService.get("sa_taxes"),
                            getCellText: function(l) {
                                return i.turnoverService.formatCredit(i.turnoverService.getOutcomeTaxes(l), l)
                            }
                        }, {
                            title: this.i18nService.get("sa_net_total_outcome"),
                            getCellText: function(l) {
                                return i.turnoverService.formatCredit(i.turnoverService.getNetTotalOutcome(l), l)
                            },
                            highlight: !0
                        }], this.balanceRows = [{
                            title: this.i18nService.get("sa_balance"),
                            getCellText: function() {
                                return i.turnoverService.formatCredit(i.turnoverService.getBalance())
                            },
                            highlight: !0
                        }, {
                            title: this.i18nService.get("sa_taxes"),
                            getCellText: function() {
                                return i.turnoverService.formatCredit(i.turnoverService.getBalanceTaxes())
                            },
                            highlight: !0
                        }, {
                            title: this.i18nService.get("sa_net_balance"),
                            getCellText: function() {
                                return i.turnoverService.formatCredit(i.turnoverService.getNetBalance())
                            },
                            highlight: !0
                        }], this.wonInformationRows = [{
                            title: this.i18nService.get("sa_won"),
                            getCellText: function(l) {
                                return i.turnoverService.formatCredit(i.turnoverService.getWon(l), l)
                            }
                        }, {
                            title: this.i18nService.get("sa_jackpot_won"),
                            getCellText: function(l) {
                                return l ? "" : i.turnoverService.formatCredit(i.turnoverService.getJackpotWon(l), l)
                            }
                        }, {
                            title: this.i18nService.get("sa_megajackpot_won"),
                            getCellText: function(l) {
                                return l ? "" : i.turnoverService.formatCredit(i.turnoverService.getMegajackpotWon(l), l)
                            }
                        }, {
                            title: this.i18nService.get("sa_bonus"),
                            getCellText: function(l) {
                                return i.turnoverService.formatCredit(i.turnoverService.getBonus(l), l)
                            }
                        }, {
                            title: this.i18nService.get("sa_cancelled"),
                            getCellText: function(l) {
                                return i.turnoverService.formatCredit(i.turnoverService.getCancelled(l), l)
                            }
                        }, {
                            title: this.i18nService.get("sa_net_turnover"),
                            getCellText: function(l) {
                                return i.turnoverService.formatCredit(i.turnoverService.getNetTurnover(l), l)
                            }
                        }, {
                            title: this.i18nService.get("sa_capped_won"),
                            getCellText: function(l) {
                                return i.turnoverService.formatCredit(i.turnoverService.getCapped(l), l)
                            }
                        }, {
                            title: this.i18nService.get("sa_capped_paid"),
                            getCellText: function(l) {
                                return i.turnoverService.formatCredit(i.turnoverService.getCappedPaid(l), l)
                            }
                        }, {
                            title: this.i18nService.get("sa_jackpot_contribution"),
                            getCellText: function(l) {
                                return i.turnoverService.formatCredit(i.turnoverService.getJackpotContribution(l), l)
                            }
                        }, {
                            title: this.i18nService.get("sa_megajackpot_contribution"),
                            getCellText: function(l) {
                                return i.turnoverService.formatCredit(i.turnoverService.getMegaJackpotContribution(l), l)
                            }
                        }], this.isInformationOpened = !1, this.statsByPlaylist = [], this.settlements = [], this.totalStatsPending = !0, this.balance = "", this.settlementsByPage = 5, this.subscriptions = new _l.a, this.headerTitle = function(l) {
                            return i.getHeaderTitle(l)
                        }
                    }
                    return l.prototype.ngOnInit = function() {
                        var l, t = this;
                        this.subscriptions.add((l = this.coreService.getReportController().onReportGenerated, new el.a((function(t) {
                            var n = l.add((function(l) {
                                return t.next(l)
                            }));
                            return function() {
                                return l.remove(n)
                            }
                        }))).subscribe((function(l) {
                            l.report && t.onReportGenerated(l.report)
                        }))), this.getSettlements().pipe(Object(ul.a)((function() {
                            return t.getCurrentStats()
                        }))).subscribe((function() {
                            t.cd.detectChanges()
                        }))
                    }, l.prototype.ngOnDestroy = function() {
                        this.subscriptions.unsubscribe()
                    }, l.prototype.toggleInformation = function() {
                        this.isInformationOpened = !this.isInformationOpened
                    }, l.prototype.getSettlements = function() {
                        var l = this;
                        return this.coreService.getSettlementReport(this.settlementsByPage).pipe(Object(pl.a)((function(t) {
                            l.settlements = t
                        })))
                    }, l.prototype.getCurrentStats = function() {
                        var l, t = this,
                            n = this.loadingPanelService.show(this.turnoverContentContainer);
                        return this.totalStatsPending = !0, this.settlements.length > 0 && (l = this.settlements[0].endTime), this.coreService.getTurnoverData(l).pipe(Object(pl.a)((function(l) {
                            var e = l.statsByPlaylist;
                            t.totalStats = l.totalStats, t.turnoverService.currentSettlement = t.totalStats, t.statsByPlaylist = e, t.totalStats && (t.balance = t.turnoverService.formatCredit(t.turnoverService.getBalance())), t.loadingPanelService.hide(n), t.totalStatsPending = !1, t.cd.detectChanges()
                        })))
                    }, l.prototype.getHeaderTitle = function(l) {
                        var t = "sa_total";
                        return l && ((t = l._clData.playlistDescriptionTag || l.playlist) && !t.includes("0", 0) || "$$" !== l.gameType || (t = "sa_cash_ticket")), t ? this.i18nService.get(t) : ""
                    }, l.prototype.refresTotalStats = function() {
                        var l = this;
                        this.totalStatsPending || this.getCurrentStats().subscribe((function() {
                            l.cd.detectChanges()
                        }))
                    }, l.prototype.print = function() {
                        var l = this;
                        if (!this.totalStatsPending && this.totalStats && 0 !== this.statsByPlaylist.length) {
                            var t;
                            this.settlements.length > 0 && (t = this.settlements[0].endTime);
                            var n = this.loadingPanelService.show(this.turnoverContentContainer);
                            this.totalStatsPending = !0;
                            var e = {
                                reportType: z.c.TURNOVER,
                                data: {
                                    totalStats: this.totalStats,
                                    statsByPlaylist: this.statsByPlaylist
                                },
                                currency: this.coreService.getCurrency(this.totalStats.currency),
                                printedOn: new Date,
                                auth: this.coreService.getSessionController().sessionSettings.auth,
                                from: t,
                                to: new Date
                            };
                            return Object(N.a)(this.coreService.getPrintTicketController().printReport(e)).subscribe((function() {
                                l.loadingPanelService.hide(n), l.totalStatsPending = !1, l.cd.detectChanges()
                            }))
                        }
                    }, l.prototype.settlement = function() {
                        var l = this;
                        if (!this.totalStatsPending && this.totalStats && 0 !== this.statsByPlaylist.length) {
                            var t, n = this.loadingPanelService.show(this.turnoverContentContainer);
                            this.totalStatsPending = !0, this.settlements.length > 0 && (t = this.settlements[0].endTime);
                            var e = function() {
                                l.loadingPanelService.hide(n), l.totalStatsPending = !1, l.cd.detectChanges()
                            };
                            this.turnoverService.registerSettlement(t).pipe(Object(pl.a)((function(t) {
                                l.settlements = hl([t.report], l.settlements.slice(0, 4))
                            })), Object(ul.a)((function() {
                                return l.getCurrentStats()
                            })), Object(fl.a)((function() {
                                return e()
                            }))).subscribe((function() {
                                l.turnoverService.isRegisteringSettlement = !1, e()
                            }))
                        }
                    }, l.prototype.onRefreshSettlements = function(l) {
                        var t = this;
                        this.coreService.findReport(l).pipe(Object(pl.a)((function(l) {
                            t.settlements = hl([l], t.settlements.slice(1)), t.cd.detectChanges()
                        }))).subscribe()
                    }, l.prototype.onReportGenerated = function(l) {
                        var t = this.settlements.findIndex((function(t) {
                                return t.reportId === l.reportId
                            })),
                            n = this.settlements.slice(0, t);
                        n.push(l), n = n.concat(this.settlements.slice(t + 1)), this.settlements = n, this.cd.detectChanges()
                    }, l
                }(),
                Ol = e.sb({
                    encapsulation: 0,
                    styles: [
                        [".turnover__page[_ngcontent-%COMP%]{min-height:100%}.turnover__page[_ngcontent-%COMP%] > .page[_ngcontent-%COMP%]{width:calc(100% - 500px)}.turnover__buttons[_ngcontent-%COMP%]   .turnover__button[_ngcontent-%COMP%] + .turnover__button[_ngcontent-%COMP%]{margin-left:10px}.turnover__content-container[_ngcontent-%COMP%]{position:relative;background-color:#fff;border:1px solid #e4e7e8}.turnover__content-container--disabled[_ngcontent-%COMP%]{opacity:.2}.turnover__content-header[_ngcontent-%COMP%]{padding:20px 12px;font-size:22px;color:#000;background-color:#fafafa;border-bottom:1px solid #e4e7e8}.turnover__content[_ngcontent-%COMP%]{padding:10px}.turnover__footer-title[_ngcontent-%COMP%]{margin-bottom:10px;font-size:16px;font-weight:700;cursor:pointer}.turnover__content-footer[_ngcontent-%COMP%]{padding:10px;border-top:1px solid #e4e7e8}.turnover__dropdown-icon[_ngcontent-%COMP%]{transition:transform 150ms}.turnover__dropdown-icon--opened[_ngcontent-%COMP%]{transform:rotateZ(180deg)}.turnover__quantity[_ngcontent-%COMP%]{color:#417505}.turnover__last-settlements[_ngcontent-%COMP%]{min-width:500px;max-width:500px;min-height:100%}.turnover__table[_ngcontent-%COMP%] + .turnover__table[_ngcontent-%COMP%]{margin-top:28px}.turnover__table--income[_ngcontent-%COMP%]     .turnover-table__container>.turnover-table tr:last-child td, .turnover__table--income[_ngcontent-%COMP%]     .turnover-table__left th{color:#9ab480}.turnover__table--outcome[_ngcontent-%COMP%]     .turnover-table__container>.turnover-table tr:last-child td, .turnover__table--outcome[_ngcontent-%COMP%]     .turnover-table__left th{color:#f78ab6}"]
                    ],
                    data: {}
                });

            function Sl(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 11, "div", [
                    ["class", "turnover__content"]
                ], null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 3, "div", [
                    ["class", "turnover__table"]
                ], null, null, null, null, null)), (l()(), e.ub(2, 0, null, null, 2, "grsa-turnover-table", [
                    ["class", "turnover__table--income"]
                ], null, null, null, h, s)), e.tb(3, 638976, null, 0, o, [], {
                    title: [0, "title"],
                    rows: [1, "rows"],
                    items: [2, "items"],
                    getHeader: [3, "getHeader"]
                }, null), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(5, 0, null, null, 3, "div", [
                    ["class", "turnover__table"]
                ], null, null, null, null, null)), (l()(), e.ub(6, 0, null, null, 2, "grsa-turnover-table", [
                    ["class", "turnover__table--outcome"]
                ], null, null, null, h, s)), e.tb(7, 638976, null, 0, o, [], {
                    title: [0, "title"],
                    rows: [1, "rows"],
                    items: [2, "items"],
                    getHeader: [3, "getHeader"]
                }, null), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(9, 0, null, null, 2, "div", [
                    ["class", "turnover__table"]
                ], null, null, null, null, null)), (l()(), e.ub(10, 0, null, null, 1, "grsa-turnover-table", [], null, null, null, h, s)), e.tb(11, 638976, null, 0, o, [], {
                    showItems: [0, "showItems"],
                    rows: [1, "rows"],
                    items: [2, "items"],
                    headers: [3, "headers"]
                }, null)], (function(l, t) {
                    var n = t.component;
                    l(t, 3, 0, e.yb(1, "", e.Ob(t, 3, 0, e.Gb(t, 4).transform(n.incomeOutcome.income)), ""), n.incomeRows, n.statsByPlaylist, n.headerTitle), l(t, 7, 0, e.yb(1, "", e.Ob(t, 7, 0, e.Gb(t, 8).transform(n.incomeOutcome.outcome)), ""), n.outcomeRows, n.statsByPlaylist, n.headerTitle), l(t, 11, 0, !1, n.balanceRows, n.statsByPlaylist, !1)
                }), null)
            }

            function yl(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 3, null, null, null, null, null, null, null)), (l()(), e.ub(1, 0, null, null, 2, "div", [
                    ["class", "turnover__table"]
                ], null, null, null, null, null)), (l()(), e.ub(2, 0, null, null, 1, "grsa-turnover-table", [], null, null, null, h, s)), e.tb(3, 638976, null, 0, o, [], {
                    rows: [0, "rows"],
                    items: [1, "items"],
                    getHeader: [2, "getHeader"]
                }, null)], (function(l, t) {
                    var n = t.component;
                    l(t, 3, 0, n.wonInformationRows, n.statsByPlaylist, n.headerTitle)
                }), null)
            }

            function xl(l) {
                return e.Pb(2, [e.Hb(0, a.u, []), e.Lb(402653184, 1, {
                    turnoverContentContainer: 0
                }), (l()(), e.ub(2, 0, null, null, 34, "div", [
                    ["class", "grid turnover__page"]
                ], null, null, null, null, null)), (l()(), e.ub(3, 0, null, null, 30, "div", [
                    ["class", "col page"]
                ], null, null, null, null, null)), (l()(), e.ub(4, 0, null, null, 13, "div", [
                    ["class", "grid grid-middle grid-space-between page-header"]
                ], null, null, null, null, null)), (l()(), e.ub(5, 0, null, null, 3, "h3", [
                    ["class", "page-title"]
                ], null, null, null, null, null)), (l()(), e.Nb(6, null, ["", ""])), e.Hb(131072, I.i, [I.j, e.i]), e.Jb(8, 1), (l()(), e.ub(9, 0, null, null, 8, "div", [
                    ["class", "grid grid-middle turnover__buttons"]
                ], null, null, null, null, null)), (l()(), e.ub(10, 0, null, null, 1, "div", [
                    ["class", "button button--icon turnover__button"]
                ], [
                    [2, "button--disabled", null]
                ], [
                    [null, "click"]
                ], (function(l, t, n) {
                    var e = !0;
                    return "click" === t && (e = !1 !== l.component.refresTotalStats() && e), e
                }), null, null)), (l()(), e.ub(11, 0, null, null, 0, "span", [
                    ["class", "icon icon-reload"]
                ], null, null, null, null, null)), (l()(), e.ub(12, 0, null, null, 1, "div", [
                    ["class", "button button--icon turnover__button"]
                ], [
                    [2, "button--disabled", null]
                ], [
                    [null, "click"]
                ], (function(l, t, n) {
                    var e = !0;
                    return "click" === t && (e = !1 !== l.component.print() && e), e
                }), null, null)), (l()(), e.ub(13, 0, null, null, 0, "span", [
                    ["class", "icon icon-printer"]
                ], null, null, null, null, null)), (l()(), e.ub(14, 0, null, null, 3, "div", [
                    ["class", "button button--info turnover__button"]
                ], [
                    [2, "button--disabled", null]
                ], [
                    [null, "click"]
                ], (function(l, t, n) {
                    var e = !0;
                    return "click" === t && (e = !1 !== l.component.settlement() && e), e
                }), null, null)), (l()(), e.ub(15, 0, null, null, 2, "span", [], null, null, null, null, null)), (l()(), e.Nb(16, null, ["", ""])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(18, 0, [
                    [1, 0],
                    ["turnoverContentContainer", 1]
                ], null, 15, "div", [
                    ["class", "turnover__content-container"]
                ], [
                    [2, "turnover__content-container--disabled", null]
                ], null, null, null, null)), (l()(), e.ub(19, 0, null, null, 4, "div", [
                    ["class", "turnover__content-header"]
                ], null, null, null, null, null)), (l()(), e.Nb(20, null, [" ", ": "])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(22, 0, null, null, 1, "span", [
                    ["class", "turnover__quantity"]
                ], null, null, null, null, null)), (l()(), e.Nb(23, null, ["", ""])), (l()(), e.jb(16777216, null, null, 1, null, Sl)), e.tb(25, 16384, null, 0, a.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.ub(26, 0, null, null, 7, "div", [
                    ["class", "turnover__content-footer"]
                ], null, null, null, null, null)), (l()(), e.ub(27, 0, null, null, 4, "div", [
                    ["class", "grid turnover__footer-title"]
                ], null, [
                    [null, "click"]
                ], (function(l, t, n) {
                    var e = !0;
                    return "click" === t && (e = !1 !== l.component.toggleInformation() && e), e
                }), null, null)), (l()(), e.ub(28, 0, null, null, 2, "div", [
                    ["class", "col"]
                ], null, null, null, null, null)), (l()(), e.Nb(29, null, [" ", " "])), e.Hb(131072, I.i, [I.j, e.i]), (l()(), e.ub(31, 0, null, null, 0, "span", [
                    ["class", "icon icon-down turnover__dropdown-icon"]
                ], [
                    [2, "turnover__dropdown-icon--opened", null]
                ], null, null, null, null)), (l()(), e.jb(16777216, null, null, 1, null, yl)), e.tb(33, 16384, null, 0, a.l, [e.R, e.O], {
                    ngIf: [0, "ngIf"]
                }, null), (l()(), e.ub(34, 0, null, null, 2, "div", [
                    ["class", "turnover__last-settlements"]
                ], null, null, null, null, null)), (l()(), e.ub(35, 0, null, null, 1, "grsa-settlements", [], null, [
                    [null, "refresh"]
                ], (function(l, t, n) {
                    var e = !0;
                    return "refresh" === t && (e = !1 !== l.component.onRefreshSettlements(n) && e), e
                }), gl, al)), e.tb(36, 638976, null, 0, rl, [il], {
                    settlements: [0, "settlements"]
                }, null)], (function(l, t) {
                    var n = t.component;
                    l(t, 25, 0, n.totalStats), l(t, 33, 0, n.isInformationOpened), l(t, 36, 0, n.settlements)
                }), (function(l, t) {
                    var n = t.component,
                        u = e.Ob(t, 6, 0, l(t, 8, 0, e.Gb(t, 0), e.Ob(t, 6, 0, e.Gb(t, 7).transform("sa_turnover"))));
                    l(t, 6, 0, u), l(t, 10, 0, n.totalStatsPending), l(t, 12, 0, n.totalStatsPending || !n.totalStats || 0 === n.statsByPlaylist.length), l(t, 14, 0, n.totalStatsPending || !n.totalStats || 0 === n.statsByPlaylist.length), l(t, 16, 0, e.Ob(t, 16, 0, e.Gb(t, 17).transform("sa_settlements"))), l(t, 18, 0, n.totalStatsPending || !n.totalStats || 0 === n.statsByPlaylist.length), l(t, 20, 0, e.Ob(t, 20, 0, e.Gb(t, 21).transform("sa_balance"))), l(t, 23, 0, n.balance), l(t, 29, 0, e.Ob(t, 29, 0, e.Gb(t, 30).transform("sa_information"))), l(t, 31, 0, n.isInformationOpened)
                }))
            }

            function Cl(l) {
                return e.Pb(0, [(l()(), e.ub(0, 0, null, null, 1, "grsa-page-turnover", [], null, null, null, xl, Ol)), e.tb(1, 245760, null, 0, Il, [e.i, I.j, vl.a, C.a, il], null, null)], (function(l, t) {
                    l(t, 1, 0)
                }), null)
            }
            var Pl = e.qb("grsa-page-turnover", Il, Cl, {}, {}, []),
                jl = n("ZYCi"),
                kl = n("iz+u");
            n.d(t, "TurnoverModuleNgFactory", (function() {
                return zl
            }));
            var zl = e.rb(u, [], (function(l) {
                return e.Db([e.Eb(512, e.k, e.cb, [
                    [8, [i.a, r.a, Pl]],
                    [3, e.k], e.z
                ]), e.Eb(4608, a.n, a.m, [e.w, [2, a.A]]), e.Eb(4608, il, il, [C.a, I.j, nl.a]), e.Eb(1073742336, a.b, a.b, []), e.Eb(1073742336, jl.p, jl.p, [
                    [2, jl.u],
                    [2, jl.l]
                ]), e.Eb(1073742336, I.g, I.g, []), e.Eb(1073742336, kl.a, kl.a, []), e.Eb(1073742336, u, u, []), e.Eb(1024, jl.j, (function() {
                    return [
                        [{
                            path: "",
                            component: Il
                        }]
                    ]
                }), [])])
            }))
        }
    }
]);