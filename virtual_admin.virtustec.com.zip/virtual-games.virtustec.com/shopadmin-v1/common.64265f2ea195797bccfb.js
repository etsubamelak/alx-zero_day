(window.webpackJsonp = window.webpackJsonp || []).push([
    [0], {
        "Dx3/": function(t, e, n) {
            "use strict";
            n.d(e, "b", (function() {
                return r
            })), n.d(e, "c", (function() {
                return o
            })), n.d(e, "a", (function() {
                return i
            }));
            var r = "__CONNECTED__",
                o = "__DISCONNECTED__",
                i = "__CONNECTED_TOO__"
        },
        GH7p: function(t, e, n) {
            "use strict";
            n.r(e), n.d(e, "BrowserPrinter", (function() {
                return u
            }));
            var r = n("yKJU"),
                o = n("Ucdj"),
                i = n("CrY/"),
                l = function(t, e, n, r) {
                    return new(n || (n = Promise))((function(o, i) {
                        function l(t) {
                            try {
                                u(r.next(t))
                            } catch (e) {
                                i(e)
                            }
                        }

                        function s(t) {
                            try {
                                u(r.throw(t))
                            } catch (e) {
                                i(e)
                            }
                        }

                        function u(t) {
                            var e;
                            t.done ? o(t.value) : (e = t.value, e instanceof n ? e : new n((function(t) {
                                t(e)
                            }))).then(l, s)
                        }
                        u((r = r.apply(t, e || [])).next())
                    }))
                },
                s = function(t, e) {
                    var n, r, o, i, l = {
                        label: 0,
                        sent: function() {
                            if (1 & o[0]) throw o[1];
                            return o[1]
                        },
                        trys: [],
                        ops: []
                    };
                    return i = {
                        next: s(0),
                        throw: s(1),
                        return: s(2)
                    }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                        return this
                    }), i;

                    function s(i) {
                        return function(s) {
                            return function(i) {
                                if (n) throw new TypeError("Generator is already executing.");
                                for (; l;) try {
                                    if (n = 1, r && (o = 2 & i[0] ? r.return : i[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, i[1])).done) return o;
                                    switch (r = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                        case 0:
                                        case 1:
                                            o = i;
                                            break;
                                        case 4:
                                            return l.label++, {
                                                value: i[1],
                                                done: !1
                                            };
                                        case 5:
                                            l.label++, r = i[1], i = [0];
                                            continue;
                                        case 7:
                                            i = l.ops.pop(), l.trys.pop();
                                            continue;
                                        default:
                                            if (!((o = (o = l.trys).length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                                l = 0;
                                                continue
                                            }
                                            if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                                l.label = i[1];
                                                break
                                            }
                                            if (6 === i[0] && l.label < o[1]) {
                                                l.label = o[1], o = i;
                                                break
                                            }
                                            if (o && l.label < o[2]) {
                                                l.label = o[2], l.ops.push(i);
                                                break
                                            }
                                            o[2] && l.ops.pop(), l.trys.pop();
                                            continue
                                    }
                                    i = e.call(t, l)
                                } catch (s) {
                                    i = [6, s], r = 0
                                } finally {
                                    n = o = 0
                                }
                                if (5 & i[0]) throw i[1];
                                return {
                                    value: i[0] ? i[1] : void 0,
                                    done: !0
                                }
                            }([i, s])
                        }
                    }
                },
                u = function() {
                    function t(t, e, n) {
                        this.printerControllerConfig = t, this.onTicketPrinted = e, this.i18n = n, this.hasInitError = null, this.printer = new r.a
                    }
                    return t.prototype.getPrintersAvailable = function(t) {
                        return l(this, void 0, void 0, (function() {
                            return s(this, (function(t) {
                                return [2, void 0]
                            }))
                        }))
                    }, t.prototype.getPrinterToUse = function() {
                        return l(this, void 0, void 0, (function() {
                            return s(this, (function(t) {
                                throw new Error("ERROR: BROWSER MODE not support getPrinterToUse method.")
                            }))
                        }))
                    }, t.prototype.cleanPrinterToUse = function() {
                        return l(this, void 0, void 0, (function() {
                            return s(this, (function(t) {
                                throw new Error("ERROR: BROWSER MODE not support cleanPrinterToUse method.")
                            }))
                        }))
                    }, t.prototype.setPrinterToUse = function(t) {
                        return l(this, void 0, void 0, (function() {
                            return s(this, (function(t) {
                                throw new Error("ERROR: BROWSER MODE not support setPrinterToUse method.")
                            }))
                        }))
                    }, t.prototype.init = function() {
                        return l(this, void 0, void 0, (function() {
                            var t;
                            return s(this, (function(e) {
                                t = {
                                    scope: i.coreModel.ErrorInfo.ScopeEnum.CLIENT,
                                    errorCode: null,
                                    message: "BROWSERPRINTER_NOT_INIT",
                                    param: null,
                                    resource: null,
                                    extData: null,
                                    expiredTime: null
                                };
                                try {
                                    return [2, !0]
                                } catch (n) {
                                    throw console.log(n), t.param = n, this.hasInitError = t, n
                                }
                                return [2]
                            }))
                        }))
                    }, t.prototype.print = function(t) {
                        return l(this, void 0, void 0, (function() {
                            var e, n, r, l, u, a;
                            return s(this, (function(s) {
                                switch (s.label) {
                                    case 0:
                                        return this.isManagerAvailable() ? [4, this.loadTicketGenerator(i.coreModel.PrintProfileSettings.ContentTypeEnum.HTML)] : [3, 9];
                                    case 1:
                                        s.sent(), (e = new o.a).serverTickets = t.map((function(t) {
                                            return t.serverTicket
                                        })), n = t.length, r = 0, s.label = 2;
                                    case 2:
                                        if (!(r < n)) return [3, 8];
                                        l = t[r], s.label = 3;
                                    case 3:
                                        return s.trys.push([3, 6, , 7]), [4, this.ticketGenerator.createTicketBody(l)];
                                    case 4:
                                        return u = s.sent(), [4, this.printer.printHtml(u, {
                                            printMode: this.printerControllerConfig.browserPrinterMode ? this.printerControllerConfig.browserPrinterMode : o.b.DEFAULT,
                                            popupProperties: this.getWindowPopupProperties(),
                                            stylesheets: this.printerControllerConfig.cssBasePath + "ticket.css"
                                        })];
                                    case 5:
                                        return s.sent(), this.onTicketPrinted.execute({
                                            error: null,
                                            serverTicket: l.serverTicket,
                                            length: n,
                                            ndx: r
                                        }), e.successPrint.push(l.serverTicket), [3, 7];
                                    case 6:
                                        return a = s.sent(), e.failPrint.push({
                                            error: a,
                                            serverTicket: l.serverTicket
                                        }), [3, 7];
                                    case 7:
                                        return r++, [3, 2];
                                    case 8:
                                        return [2, e];
                                    case 9:
                                        throw new Error("ERROR: BrowserPrinter - print, no Manager available.")
                                }
                            }))
                        }))
                    }, t.prototype.printCashTicket = function(t) {
                        return l(this, void 0, void 0, (function() {
                            var e, n, r;
                            return s(this, (function(l) {
                                switch (l.label) {
                                    case 0:
                                        return this.isManagerAvailable() ? [4, this.loadTicketGenerator(i.coreModel.PrintProfileSettings.ContentTypeEnum.HTML)] : [3, 7];
                                    case 1:
                                        l.sent(), (e = new o.h).serverTicket = t.serverTicket, e.length = 1, e.ndx = 0, e.error = null, l.label = 2;
                                    case 2:
                                        return l.trys.push([2, 5, , 6]), [4, this.ticketGenerator.createCashTicketBody(t)];
                                    case 3:
                                        return n = l.sent(), [4, this.printer.printHtml(n, {
                                            printMode: this.printerControllerConfig.browserPrinterMode ? this.printerControllerConfig.browserPrinterMode : o.b.DEFAULT,
                                            popupProperties: this.getWindowPopupProperties(),
                                            stylesheets: this.printerControllerConfig.cssBasePath + "ticket.css"
                                        })];
                                    case 4:
                                        return l.sent(), this.onTicketPrinted.execute(e), [3, 6];
                                    case 5:
                                        return r = l.sent(), e.error = r, this.onTicketPrinted.execute(e), [3, 6];
                                    case 6:
                                        return [2, e];
                                    case 7:
                                        throw new Error("ERROR: BrowserPrinter - print, no Manager available.")
                                }
                            }))
                        }))
                    }, t.prototype.printLocalUserTicket = function(t, e) {
                        return l(this, void 0, void 0, (function() {
                            var n, r, l;
                            return s(this, (function(s) {
                                switch (s.label) {
                                    case 0:
                                        return this.isManagerAvailable() ? [4, this.loadTicketGenerator(i.coreModel.PrintProfileSettings.ContentTypeEnum.HTML)] : [3, 7];
                                    case 1:
                                        s.sent(), (n = new o.h).serverTicket = t.serverTicket, n.length = 1, n.ndx = 0, n.error = null, s.label = 2;
                                    case 2:
                                        return s.trys.push([2, 5, , 6]), [4, this.ticketGenerator.createLocalUserTicketBody(t, e)];
                                    case 3:
                                        return r = s.sent(), [4, this.printer.printHtml(r, {
                                            printMode: this.printerControllerConfig.browserPrinterMode ? this.printerControllerConfig.browserPrinterMode : o.b.DEFAULT,
                                            popupProperties: this.getWindowPopupProperties(),
                                            stylesheets: this.printerControllerConfig.cssBasePath + "ticket.css"
                                        })];
                                    case 4:
                                        return s.sent(), this.onTicketPrinted.execute(n), [3, 6];
                                    case 5:
                                        return l = s.sent(), n.error = l, this.onTicketPrinted.execute(n), [3, 6];
                                    case 6:
                                        return [2, n];
                                    case 7:
                                        throw new Error("ERROR: BrowserPrinter - print, no Manager available.")
                                }
                            }))
                        }))
                    }, t.prototype.printReport = function(t) {
                        return l(this, void 0, void 0, (function() {
                            var e;
                            return s(this, (function(n) {
                                switch (n.label) {
                                    case 0:
                                        return this.isManagerAvailable() ? [4, this.loadTicketGenerator(i.coreModel.PrintProfileSettings.ContentTypeEnum.HTML)] : [3, 7];
                                    case 1:
                                        n.sent(), n.label = 2;
                                    case 2:
                                        return n.trys.push([2, 5, , 6]), [4, this.ticketGenerator.createReportBody(t)];
                                    case 3:
                                        return e = n.sent(), [4, this.printer.printHtml(e, {
                                            printMode: this.printerControllerConfig.browserPrinterMode ? this.printerControllerConfig.browserPrinterMode : o.b.DEFAULT,
                                            popupProperties: this.getWindowPopupProperties(),
                                            stylesheets: this.printerControllerConfig.cssBasePath + "ticket.css"
                                        })];
                                    case 4:
                                        return n.sent(), [2];
                                    case 5:
                                        throw n.sent();
                                    case 6:
                                        return [3, 8];
                                    case 7:
                                        throw new Error("ERROR: BrowserPrinter - printReport, no Manager available.");
                                    case 8:
                                        return [2]
                                }
                            }))
                        }))
                    }, t.prototype.printLastResults = function(t) {
                        return l(this, void 0, void 0, (function() {
                            var e;
                            return s(this, (function(n) {
                                switch (n.label) {
                                    case 0:
                                        return this.isManagerAvailable() ? [4, this.loadTicketGenerator(i.coreModel.PrintProfileSettings.ContentTypeEnum.HTML)] : [3, 7];
                                    case 1:
                                        n.sent(), n.label = 2;
                                    case 2:
                                        return n.trys.push([2, 5, , 6]), [4, this.ticketGenerator.createLastResultsBody(t)];
                                    case 3:
                                        return e = n.sent(), [4, this.printer.printHtml(e, {
                                            printMode: this.printerControllerConfig.browserPrinterMode ? this.printerControllerConfig.browserPrinterMode : o.b.DEFAULT,
                                            popupProperties: this.getWindowPopupProperties(),
                                            stylesheets: this.printerControllerConfig.cssBasePath + "ticket.css"
                                        })];
                                    case 4:
                                        return n.sent(), [2];
                                    case 5:
                                        throw n.sent();
                                    case 6:
                                        return [3, 8];
                                    case 7:
                                        throw new Error("ERROR: BrowserPrinter - printLastResults, no Manager available.");
                                    case 8:
                                        return [2]
                                }
                            }))
                        }))
                    }, t.prototype.setLanguage = function(t) {
                        return l(this, void 0, void 0, (function() {
                            return s(this, (function(e) {
                                if (!this.isManagerAvailable()) throw new Error("ERROR: BrowserPrinter - setLanguage, no Manager available.");
                                return this.printerControllerConfig.langCode = t, [2]
                            }))
                        }))
                    }, t.prototype.setOddFormat = function(t) {
                        return l(this, void 0, void 0, (function() {
                            return s(this, (function(e) {
                                if (!this.isManagerAvailable()) throw new Error("ERROR: BrowserPrinter - setOddFormat, no Manager available.");
                                return this.printerControllerConfig.oddFormat = t, [2]
                            }))
                        }))
                    }, t.prototype.isManagerAvailable = function() {
                        if (null === this.hasInitError) return !0;
                        throw this.hasInitError
                    }, t.prototype.loadTicketGenerator = function(t) {
                        return l(this, void 0, void 0, (function() {
                            var e;
                            return s(this, (function(r) {
                                switch (r.label) {
                                    case 0:
                                        return t !== i.coreModel.PrintProfileSettings.ContentTypeEnum.HTML ? [3, 2] : [4, Promise.all([n.e(2), n.e(7)]).then(n.bind(null, "EACO"))];
                                    case 1:
                                        return e = r.sent(), this.ticketGenerator = new e.HtmlTicketGenerator(this.printerControllerConfig, this.i18n), [3, 4];
                                    case 2:
                                        return [4, Promise.all([n.e(2), n.e(9)]).then(n.bind(null, "iURD"))];
                                    case 3:
                                        e = r.sent(), this.ticketGenerator = new e.PosTicketGenerator(this.printerControllerConfig, this.i18n), r.label = 4;
                                    case 4:
                                        return [4, this.ticketGenerator.init()];
                                    case 5:
                                        return [2, r.sent()]
                                }
                            }))
                        }))
                    }, t.prototype.preloadCSS = function(t) {
                        return new Promise((function(e, n) {
                            var r = document.createElement("link");
                            r.setAttribute("rel", "stylesheet"), r.setAttribute("type", "text/css"), r.onload = function() {
                                e(!0)
                            }, r.setAttribute("href", t), document.getElementsByTagName("head")[0].appendChild(r)
                        }))
                    }, t.prototype.getWindowPopupProperties = function() {
                        return this.printerControllerConfig.browserPrinterMode === o.b.WINDOW_POPUP ? "fullscreen=yes" : ""
                    }, t
                }()
        },
        SHeQ: function(t, e, n) {
            "use strict";
            var r = n("CcnG"),
                o = n("Ip0R");
            n("yoGk"), n("t01L"), n("5EE+"), n.d(e, "a", (function() {
                return i
            })), n.d(e, "b", (function() {
                return d
            }));
            var i = r.sb({
                encapsulation: 0,
                styles: [
                    ["[_nghost-%COMP%]{position:relative;display:inline-block}.select[_ngcontent-%COMP%]{position:relative;display:inline-block;min-width:140px;padding:12px 36px 12px 16px;color:#002d40;cursor:pointer;background-color:#fff;border:1px solid #274a5c;margin-bottom:20px}.select__icon[_ngcontent-%COMP%]{position:absolute;top:50%;right:10px;margin-left:5px;font-size:10px;transform:translateY(-50%)}.select__options[_ngcontent-%COMP%]{position:absolute;top:1px;z-index:1;display:inline-block;width:100%;max-height:216px;overflow:auto;background-color:#fff;box-shadow:0 8px 10px 1px rgba(0,0,0,.14),0 3px 14px 3px rgba(0,0,0,.12),0 4px 5px 0 rgba(0,0,0,.2)}.select__option[_ngcontent-%COMP%]{display:block;padding:10px 16px;cursor:pointer}.select__option[_ngcontent-%COMP%]:hover{background-color:#ededed}.select--disabled[_ngcontent-%COMP%]{color:#9b9b9b;border-color:#9b9b9b}"]
                ],
                data: {}
            });

            function l(t) {
                return r.Pb(0, [(t()(), r.ub(0, 0, null, null, 0, null, null, null, null, null, null, null))], null, null)
            }

            function s(t) {
                return r.Pb(0, [(t()(), r.ub(0, 0, null, null, 3, null, null, null, null, null, null, null)), (t()(), r.jb(16777216, null, null, 2, null, l)), r.tb(2, 540672, null, 0, o.r, [r.R], {
                    ngTemplateOutletContext: [0, "ngTemplateOutletContext"],
                    ngTemplateOutlet: [1, "ngTemplateOutlet"]
                }, null), r.Ib(3, {
                    option: 0
                }), (t()(), r.jb(0, null, null, 0))], (function(t, e) {
                    var n = t(e, 3, 0, e.component.optionSelected);
                    t(e, 2, 0, n, r.Gb(e.parent, 12))
                }), null)
            }

            function u(t) {
                return r.Pb(0, [(t()(), r.ub(0, 0, null, null, 0, null, null, null, null, null, null, null))], null, null)
            }

            function a(t) {
                return r.Pb(0, [(t()(), r.ub(0, 0, null, null, 3, "div", [
                    ["class", "select__option"]
                ], null, [
                    [null, "click"]
                ], (function(t, e, n) {
                    var r = !0;
                    return "click" === e && (r = !1 !== t.component.onOptionClick(t.context.$implicit) && r), r
                }), null, null)), (t()(), r.jb(16777216, null, null, 2, null, u)), r.tb(2, 540672, null, 0, o.r, [r.R], {
                    ngTemplateOutletContext: [0, "ngTemplateOutletContext"],
                    ngTemplateOutlet: [1, "ngTemplateOutlet"]
                }, null), r.Ib(3, {
                    option: 0
                })], (function(t, e) {
                    var n = e.component,
                        o = t(e, 3, 0, e.context.$implicit);
                    t(e, 2, 0, o, n.optionTemplate ? n.optionTemplate : r.Gb(e.parent.parent, 12))
                }), null)
            }

            function c(t) {
                return r.Pb(0, [(t()(), r.ub(0, 0, null, null, 2, "div", [
                    ["class", "select__options"]
                ], [
                    [4, "left", "px"],
                    [4, "top", "px"]
                ], null, null, null, null)), (t()(), r.jb(16777216, null, null, 1, null, a)), r.tb(2, 278528, null, 0, o.k, [r.R, r.O, r.u], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(t, e) {
                    t(e, 2, 0, e.component._options)
                }), (function(t, e) {
                    var n = e.component;
                    t(e, 0, 0, n.selectPosition.left, n.selectPosition.top)
                }))
            }

            function p(t) {
                return r.Pb(0, [(t()(), r.Nb(0, null, [" ", " "]))], null, (function(t, e) {
                    t(e, 0, 0, e.component.getOption(e.context.option))
                }))
            }

            function h(t) {
                return r.Pb(0, [(t()(), r.Nb(-1, null, [" --- "]))], null, null)
            }

            function d(t) {
                return r.Pb(2, [r.Lb(671088640, 1, {
                    dateInput: 0
                }), (t()(), r.ub(1, 0, [
                    [1, 0],
                    ["selectInput", 1]
                ], null, 8, "div", [
                    ["class", "select"]
                ], null, [
                    [null, "click"]
                ], (function(t, e, n) {
                    var r = !0;
                    return "click" === e && (r = !1 !== t.component.toggleOptionsPanel() && r), r
                }), null, null)), r.Kb(512, null, o.x, o.y, [r.u, r.v, r.l, r.F]), r.tb(3, 278528, null, 0, o.i, [o.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), r.Ib(4, {
                    "select--disabled": 0
                }), (t()(), r.jb(16777216, null, null, 1, null, s)), r.tb(6, 16384, null, 0, o.l, [r.R, r.O], {
                    ngIf: [0, "ngIf"],
                    ngIfElse: [1, "ngIfElse"]
                }, null), (t()(), r.ub(7, 0, null, null, 2, "span", [
                    ["class", "select__icon"]
                ], null, null, null, null, null)), r.Kb(512, null, o.x, o.y, [r.u, r.v, r.l, r.F]), r.tb(9, 278528, null, 0, o.i, [o.x], {
                    klass: [0, "klass"],
                    ngClass: [1, "ngClass"]
                }, null), (t()(), r.jb(16777216, null, null, 1, null, c)), r.tb(11, 16384, null, 0, o.l, [r.R, r.O], {
                    ngIf: [0, "ngIf"]
                }, null), (t()(), r.jb(0, [
                    ["defaultOptionTemplate", 2]
                ], null, 0, null, p)), (t()(), r.jb(0, [
                    ["selectTemplate", 2]
                ], null, 0, null, h))], (function(t, e) {
                    var n = e.component,
                        o = t(e, 4, 0, n.disabled);
                    t(e, 3, 0, "select", o), t(e, 6, 0, n.optionSelected, r.Gb(e, 13)), t(e, 9, 0, "select__icon", n.openIcon), t(e, 11, 0, n.showOptions)
                }), null)
            }
        },
        rxiI: function(t, e, n) {
            "use strict";
            var r = n("CcnG");
            n("5zzm"), n.d(e, "a", (function() {
                return o
            })), n.d(e, "b", (function() {
                return i
            }));
            var o = r.sb({
                encapsulation: 0,
                styles: [
                    [""]
                ],
                data: {}
            });

            function i(t) {
                return r.Pb(2, [], null, null)
            }
        },
        yKJU: function(t, e, n) {
            "use strict";
            n.d(e, "a", (function() {
                return o
            }));
            var r = n("Ucdj"),
                o = function() {
                    function t() {}
                    return t.prototype.getfullHTML = function(t, e) {
                        return this._getMarkup(t, e, !1)
                    }, t.prototype.printElement = function(t, e) {
                        var n = this;
                        return new Promise((function(r, o) {
                            n._print(t.outerHTML, e).then((function(t) {
                                r(t)
                            }))
                        }))
                    }, t.prototype.printHtml = function(t, e) {
                        var n = this;
                        return new Promise((function(r, o) {
                            n._print(t, e).then((function(t) {
                                r(t)
                            }))
                        }))
                    }, t.prototype._print = function(t, e) {
                        var n = this;
                        return new Promise((function(o, i) {
                            var l, s, u, a, c = n._getMarkup(t, e = {
                                    printMode: (e = e || {}).printMode || r.b.DEFAULT,
                                    pageTitle: e.pageTitle || "",
                                    templateString: e.templateString || "",
                                    popupProperties: e.popupProperties || "",
                                    stylesheets: e.stylesheets || null,
                                    styles: e.styles || null
                                }),
                                p = !0;
                            e.printMode === r.b.WINDOW_POPUP || e.printMode === r.b.WINDOW ? (l = window.open("about:blank", "_blank", e.popupProperties), u = l.document, p = !1) : (a = "printElement_" + Math.round(99999 * Math.random()).toString(), (s = document.createElement("iframe")).setAttribute("id", a), s.setAttribute("src", "about:blank"), s.setAttribute("frameBorder", "0"), s.setAttribute("scrolling", "no"), s.setAttribute("style", "position:fixed;top:20%;z-index:-1"), document.body.appendChild(s), (u = s.contentWindow || s.contentDocument).document && (u = u.document), s = document.frames ? document.frames[a] : document.getElementById(a), l = s.contentWindow || s), focus(), u.open(), setTimeout((function() {
                                l.addEventListener("load", (function(t) {
                                    p ? (l.printPage(), s && (document.body.removeChild(document.getElementById(a)), o(!0))) : o(!1)
                                })), u.write(c), u.close()
                            }))
                        }))
                    }, t.prototype._getBaseHref = function() {
                        var t = window.location.port ? ":" + window.location.port : "";
                        return window.location.protocol + "//" + window.location.hostname + t + window.location.pathname
                    }, t.prototype._getMarkup = function(t, e, n) {
                        void 0 === n && (n = !0);
                        var o = e.templateString,
                            i = new RegExp(/{{\s*printBody\s*}}/gi),
                            l = [],
                            s = [],
                            u = [];
                        return o && i.test(o) && (t = o.replace(i, t)), u.push('<html><head><meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" /><meta charset="UTF-8"><title>' + (e.pageTitle || "") + "</title>"), e.stylesheets && (l = Array.isArray(e.stylesheets) ? e.stylesheets : [e.stylesheets]), l.forEach((function(t) {
                            u.push('<link rel="stylesheet" href="' + t + '">')
                        })), e.styles && (s = Array.isArray(e.styles) ? e.styles : [e.styles]), s.forEach((function(t) {
                            u.push('<style type="text/css">' + t + "</style>")
                        })), u.push('<base href="' + this._getBaseHref() + '" />'), u.push('</head><body class="pe-body cashier-ticket">'), u.push(t), !n || e.printMode !== r.b.WINDOW_POPUP && e.printMode !== r.b.DEFAULT || u.push('<script type="text/javascript">function printPage(){focus();print();' + (e.printMode === r.b.WINDOW_POPUP ? "close();" : "") + "}<\/script>"), u.push("</body></html>"), u.join("")
                    }, t
                }()
        }
    }
]);