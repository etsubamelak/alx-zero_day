(window.webpackJsonp = window.webpackJsonp || []).push([
    [15], {
        Xqvd: function(t, e, n) {
            "use strict";
            n.r(e);
            var l = n("CcnG"),
                r = n("mrSG"),
                a = n("9pw4"),
                i = n("CrY/"),
                u = function() {
                    function t(t) {
                        var e = this;
                        this.i18nService = t, this.getEventBlockTime = function(t) {
                            return e.i18nService.location.getDate(t.eventTime, "dateTime")
                        }
                    }
                    return t.prototype.getColumn = function(t) {
                        return this.columns.find((function(e) {
                            return e.id === t
                        }))
                    }, t.prototype.setTemplateRef = function(t, e) {
                        var n = this.getColumn(t);
                        n && (n.templateRef = e)
                    }, t.prototype.getResult = function(t, e) {
                        return t.result._clData.parseWonOdd.get(e)
                    }, t.prototype.getEventId = function(t) {
                        return t.events[0].eventId
                    }, t
                }(),
                o = n("WGel"),
                s = function(t) {
                    return t.CHAMPION = "CHAMPION", t.LIBERTADORES = "LIBERTADORES", t.WORLDCUP = "WORLDCUP", t
                }({}),
                c = function(t) {
                    function e(e) {
                        var n = t.call(this, e) || this;
                        return n.columns = [{
                            id: "EventId",
                            title: n.i18nService.get("sa_event_id"),
                            function: function(t) {
                                var e = t.events[0]._clData.playlist;
                                if (e.filter.isChFilter() && e.filter.competitionType === i.coreModel.ChCompetitionType.CHAMPION) {
                                    var l = t.data;
                                    return n.getEvent(t) + " \n(" + l.phase + ")"
                                }
                                return "" + n.getEvent(t)
                            },
                            verticalAlign: a.b.TOP,
                            whiteSpace: a.d.PRE,
                            grow: 100
                        }, {
                            id: "DateTime",
                            title: n.i18nService.get("sa_date_time"),
                            function: n.getEventBlockTime,
                            verticalAlign: a.b.TOP,
                            grow: 170
                        }, {
                            id: "Results",
                            title: n.i18nService.get("sa_match"),
                            verticalAlign: a.b.TOP,
                            grow: 150
                        }, {
                            id: "CorrectScore",
                            title: n.i18nService.getMarketTag(i.ChMarkets.Correct_Score),
                            verticalAlign: a.b.TOP,
                            grow: 70,
                            templateData: i.ChMarkets.Correct_Score
                        }, {
                            id: "Total_Goals",
                            title: n.i18nService.getMarketTag(i.ChMarkets.Total_Goals),
                            verticalAlign: a.b.TOP,
                            grow: 70,
                            templateData: i.ChMarkets.Total_Goals
                        }, {
                            id: "MatchResult",
                            title: n.i18nService.getMarketTag(i.ChMarkets.Match_Result),
                            verticalAlign: a.b.TOP,
                            grow: 100,
                            templateData: i.ChMarkets.Match_Result
                        }, {
                            id: "GoalGoal_NoGoal",
                            title: n.i18nService.getMarketTag(i.ChMarkets.GoalGoal_NoGoal),
                            verticalAlign: a.b.TOP,
                            grow: 100,
                            templateData: i.ChMarkets.GoalGoal_NoGoal
                        }, {
                            id: "DoubleChance",
                            title: n.i18nService.getMarketTag(i.ChMarkets.Double_Chance),
                            verticalAlign: a.b.TOP,
                            grow: 100,
                            templateData: i.ChMarkets.Double_Chance
                        }, {
                            id: "Double_Result",
                            title: n.i18nService.getMarketTag(i.ChMarkets.Double_Result),
                            verticalAlign: a.b.TOP,
                            grow: 100,
                            templateData: i.ChMarkets.Double_Result
                        }, {
                            id: "OverUnder05",
                            title: n.i18nService.getMarketTag(i.ChMarkets.Over_Under_0_5),
                            verticalAlign: a.b.TOP,
                            grow: 100,
                            templateData: i.ChMarkets.Over_Under_0_5
                        }, {
                            id: "OverUnder15",
                            title: n.i18nService.getMarketTag(i.ChMarkets.Over_Under_1_5),
                            verticalAlign: a.b.TOP,
                            grow: 100,
                            templateData: i.ChMarkets.Over_Under_1_5
                        }, {
                            id: "OverUnder25",
                            title: n.i18nService.getMarketTag(i.ChMarkets.Over_Under_2_5),
                            verticalAlign: a.b.TOP,
                            grow: 100,
                            templateData: i.ChMarkets.Over_Under_2_5
                        }, {
                            id: "OverUnder35",
                            title: n.i18nService.getMarketTag(i.ChMarkets.Over_Under_3_5),
                            verticalAlign: a.b.TOP,
                            grow: 100,
                            templateData: i.ChMarkets.Over_Under_3_5
                        }, {
                            id: "OverUnder45",
                            title: n.i18nService.getMarketTag(i.ChMarkets.Over_Under_4_5),
                            verticalAlign: a.b.TOP,
                            grow: 100,
                            templateData: i.ChMarkets.Over_Under_4_5
                        }, {
                            id: "Qualify",
                            title: n.i18nService.getMarketTag(i.ChMarkets.Qualify),
                            verticalAlign: a.b.TOP,
                            grow: 100,
                            templateData: i.ChMarkets.Qualify
                        }, {
                            id: "First_Half",
                            title: n.i18nService.getMarketTag(i.ChMarkets.First_Half),
                            verticalAlign: a.b.TOP,
                            grow: 100,
                            templateData: i.ChMarkets.First_Half
                        }, {
                            id: "1x2+OverUnder15",
                            title: n.i18nService.getMarketTag(i.ChMarkets._1x2_Scores_Over_Under_1_5),
                            verticalAlign: a.b.TOP,
                            grow: 170,
                            templateData: i.ChMarkets._1x2_Scores_Over_Under_1_5
                        }, {
                            id: "1x2+OverUnder25",
                            title: n.i18nService.getMarketTag(i.ChMarkets._1x2_Scores_Over_Under_2_5),
                            verticalAlign: a.b.TOP,
                            grow: 170,
                            templateData: i.ChMarkets._1x2_Scores_Over_Under_2_5
                        }, {
                            id: "1x2+OverUnder35",
                            title: n.i18nService.getMarketTag(i.ChMarkets._1x2_Scores_Over_Under_3_5),
                            verticalAlign: a.b.TOP,
                            grow: 170,
                            templateData: i.ChMarkets._1x2_Scores_Over_Under_3_5
                        }, {
                            id: "1x2+HomeOverUnder05",
                            title: n.i18nService.getMarketTag(i.ChMarkets.HomeAwayScores_Over_Under_0_5),
                            verticalAlign: a.b.TOP,
                            grow: 300,
                            templateData: i.ChMarkets.HomeAwayScores_Over_Under_0_5
                        }, {
                            id: "1x2+HomeOverUnder15",
                            title: n.i18nService.getMarketTag(i.ChMarkets.HomeAwayScores_Over_Under_1_5),
                            verticalAlign: a.b.TOP,
                            grow: 300,
                            templateData: i.ChMarkets.HomeAwayScores_Over_Under_1_5
                        }, {
                            id: "1x2+HomeOverUnder25",
                            title: n.i18nService.getMarketTag(i.ChMarkets.HomeAwayScores_Over_Under_2_5),
                            verticalAlign: a.b.TOP,
                            grow: 300,
                            templateData: i.ChMarkets.HomeAwayScores_Over_Under_2_5
                        }, {
                            id: "1x2+HomeOverUnder35",
                            title: n.i18nService.getMarketTag(i.ChMarkets.HomeAwayScores_Over_Under_3_5),
                            verticalAlign: a.b.TOP,
                            grow: 300,
                            templateData: i.ChMarkets.HomeAwayScores_Over_Under_3_5
                        }], n.competitionSubType = s, n
                    }
                    return Object(r.__extends)(e, t), Object.defineProperty(e.prototype, "resultsTemplate", {
                        set: function(t) {
                            this.setTemplateRef("Results", t)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "wonMarketTemplate", {
                        set: function(t) {
                            this.columns.slice(3).forEach((function(e) {
                                e.templateRef = t
                            }))
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.ngOnInit = function() {}, e.prototype.getWonOdd = function(t, e) {
                        var n = t.result._clData.parseWonOdd.get(e);
                        return this.translateWonOdds(n, t._clData.playlist.gameType.val)
                    }, e.prototype.getEvent = function(t) {
                        var e = this.getCompetitionSubType(t),
                            n = t.data.isChEventBlockData() && t.data,
                            l = e === this.competitionSubType.WORLDCUP;
                        return "GROUPS" === n.phase ? e === this.competitionSubType.CHAMPION || e === this.competitionSubType.LIBERTADORES || l ? this.getChampId(n) + "/" + this.getMatchDay(n) + this.getWeekDay(n) : this.getChampId(n) + "/" + this.getMatchDay(n) : l ? this.getChampId(n) + "/" + this.getMatchDay(n) : this.getChampId(n) + "/" + this.getMatchDay(n) + this.getLegOrder(n)
                    }, e.prototype.getChampId = function(t) {
                        return t.champId
                    }, e.prototype.getWeekDay = function(t) {
                        return t.weekDay
                    }, e.prototype.getMatchDay = function(t) {
                        var e = t.matchDay;
                        return e < 10 ? "0" + e : e
                    }, e.prototype.getLegOrder = function(t) {
                        return t.legOrder
                    }, e.prototype.getCompetitionSubType = function(t) {
                        var e = t._clData.playlist;
                        return e.filter.isChFilter() && e.filter.competitionSubType
                    }, e.prototype.isSoccer = function(t) {
                        var e = t.events[0]._clData.playlist;
                        return e.filter.isChFilter() && e.filter.competitionType === i.coreModel.ChCompetitionType.SOCCER
                    }, e.prototype.translateWonOdds = function(t, e) {
                        var n = this,
                            l = [];
                        return t ? (t.forEach((function(t) {
                            return l.push(n.i18nService.getMarketOptionTag(o.I18NGameType[e], t.oddId))
                        })), l.join(", ")) : null
                    }, e
                }(u),
                p = function(t) {
                    function e(e) {
                        var n = t.call(this, e) || this;
                        return n.columns = [], n.templates = {}, n
                    }
                    return Object(r.__extends)(e, t), Object.defineProperty(e.prototype, "resultsTemplate", {
                        set: function(t) {
                            this.templates.results = t, this.setTemplateRef("Results", t)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "wonMarketTemplate", {
                        set: function(t) {
                            var e = this;
                            this.templates.wonMarket = t, this.columns.slice(3).forEach((function(n) {
                                e.getColumn(n.title).templateRef = t
                            }))
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "trifectaTemplate", {
                        set: function(t) {
                            var e = this;
                            this.templates.withoutSpaceTemplate = t, this.columns.slice(3).forEach((function(n) {
                                e.getColumn(n.title).templateRef = t
                            }))
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.ngOnInit = function() {
                        this.eventBlocks && this.eventBlocks.length && this.setColumns()
                    }, e.prototype.ngOnChanges = function(t) {
                        t.eventBlocks && !t.eventBlocks.isFirstChange() && t.eventBlocks.currentValue.length && this.setColumns()
                    }, e.prototype.setColumns = function() {
                        var t, e, n, l;
                        this.columns = [{
                            id: "EventId",
                            title: this.i18nService.get("sa_event_id"),
                            function: this.getEventId,
                            grow: 120
                        }, {
                            id: "DateTime",
                            title: this.i18nService.get("sa_date_time"),
                            function: this.getEventBlockTime,
                            grow: 229
                        }, {
                            id: "Results",
                            title: this.i18nService.get("sa_results"),
                            grow: 160,
                            templateRef: this.templates.results
                        }, {
                            id: "Win",
                            title: this.i18nService.getMarketTag(i.DogMarkets.win),
                            grow: 120,
                            templateData: i.DogMarkets.win,
                            templateRef: this.templates.wonMarket
                        }, {
                            id: "Place",
                            title: this.i18nService.getMarketTag(i.DogMarkets.place),
                            grow: 120,
                            templateData: i.DogMarkets.place,
                            templateRef: this.templates.wonMarket
                        }], this.eventBlocks[0].events[0].data.participants.length > 4 && (t = this.columns).push.apply(t, [{
                            id: "Show",
                            title: this.i18nService.getMarketTag(i.DogMarkets.show),
                            grow: 120,
                            templateData: i.DogMarkets.show,
                            templateRef: this.templates.wonMarket
                        }]), (e = this.columns).push.apply(e, [{
                            id: "Exacta",
                            title: this.i18nService.getMarketTag(i.DogMarkets.exacta),
                            grow: 120,
                            templateData: i.DogMarkets.exacta,
                            templateRef: this.templates.wonMarket
                        }, {
                            id: "Quinella",
                            title: this.i18nService.getMarketTag(i.DogMarkets.quinella),
                            grow: 120,
                            templateData: i.DogMarkets.quinella,
                            templateRef: this.templates.wonMarket
                        }]), this.eventBlocks[0].events[0].data.participants.length > 4 && (n = this.columns).push.apply(n, [{
                            id: "Trifecta",
                            title: this.i18nService.getMarketTag(i.DogMarkets.trifecta),
                            grow: 120,
                            templateData: i.DogMarkets.trifecta,
                            templateRef: this.templates.withoutSpaceTemplate
                        }]), this.eventBlocks[0].events[0].data.participants.length < 10 && (l = this.columns).push.apply(l, [{
                            id: "OddEven",
                            title: this.i18nService.getMarketTag(i.DogMarkets.even_odd),
                            grow: 120,
                            templateData: i.DogMarkets.even_odd,
                            templateRef: this.templates.wonMarket
                        }, {
                            id: "OverUnder",
                            title: this.i18nService.getMarketTag(i.DogMarkets.over_under),
                            grow: 120,
                            templateData: i.DogMarkets.over_under,
                            templateRef: this.templates.wonMarket
                        }])
                    }, e.prototype.getWonOdds = function(t, e) {
                        return t.result._clData.parseWonOdd.get(e) || {
                            marketId: "TODO",
                            oddId: "TODO",
                            oddName: "TODO"
                        }
                    }, e.prototype.getBetParam = function(t, e) {
                        var n = "";
                        return e === i.DogMarkets.trifecta && (n = t.result.finalOutcome.slice(0, 3).join(",")), n
                    }, e.prototype.getGameType = function() {
                        return this.eventBlocks[0]._clData.gameType.val
                    }, e
                }(u),
                b = function(t) {
                    function e(e) {
                        var n = t.call(this, e) || this;
                        return n.columns = [{
                            id: "EventId",
                            title: n.i18nService.get("sa_event_id"),
                            function: n.getEventId,
                            grow: 140
                        }, {
                            id: "DateTime",
                            title: n.i18nService.get("sa_date_time"),
                            function: n.getEventBlockTime,
                            grow: 237
                        }, {
                            id: "Results",
                            title: n.i18nService.get("sa_results"),
                            grow: 800
                        }], n
                    }
                    return Object(r.__extends)(e, t), Object.defineProperty(e.prototype, "resultsTemplate", {
                        set: function(t) {
                            this.setTemplateRef("Results", t)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.ngOnInit = function() {}, e
                }(u),
                g = function(t) {
                    function e(e) {
                        var n = t.call(this, e) || this;
                        return n.columns = [{
                            id: "EventId",
                            title: n.i18nService.get("sa_event_id"),
                            verticalAlign: a.b.TOP,
                            function: n.getEventId,
                            grow: 120
                        }, {
                            id: "DateTime",
                            title: n.i18nService.get("sa_date_time"),
                            verticalAlign: a.b.TOP,
                            function: n.getEventBlockTime,
                            grow: 210
                        }, {
                            id: "Results",
                            title: n.i18nService.get("sa_results"),
                            grow: 582
                        }, {
                            id: "Clovers",
                            title: n.i18nService.get("sa_clovers"),
                            verticalAlign: a.b.TOP,
                            grow: 140,
                            templateData: function(t) {
                                return n.getClovers(t)
                            }
                        }, {
                            id: "PreballsSum",
                            title: n.i18nService.get("sa_preballs_sum"),
                            verticalAlign: a.b.TOP,
                            grow: 140,
                            templateData: function(t) {
                                return n.getPreballsSums(t)
                            }
                        }, {
                            id: "FirstBall",
                            title: n.i18nService.get("sa_first_ball"),
                            verticalAlign: a.b.TOP,
                            grow: 140,
                            templateData: function(t) {
                                return n.getFirstBall(t)
                            }
                        }, {
                            id: "LastBall",
                            title: n.i18nService.get("sa_last_ball"),
                            verticalAlign: a.b.TOP,
                            grow: 140,
                            templateData: function(t) {
                                return n.getLastBall(t)
                            }
                        }], n
                    }
                    return Object(r.__extends)(e, t), Object.defineProperty(e.prototype, "resultsTemplate", {
                        set: function(t) {
                            this.setTemplateRef("Results", t)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "numbersTemplate", {
                        set: function(t) {
                            var e = this;
                            ["Clovers", "PreballsSum"].forEach((function(n) {
                                e.getColumn(n).templateRef = t
                            }))
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "ballTemplate", {
                        set: function(t) {
                            var e = this;
                            ["FirstBall", "LastBall"].forEach((function(n) {
                                e.getColumn(n).templateRef = t
                            }))
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.ngOnInit = function() {}, e.prototype.getClovers = function(t) {
                        return this.getEventResultData(t).cloverBalls
                    }, e.prototype.getPreballsSums = function(t) {
                        return [t.events[0].result.finalOutcome.slice(0, 5).map((function(t) {
                            return parseInt(t, 0)
                        })).reduce((function(t, e) {
                            return t + e
                        }))]
                    }, e.prototype.getFirstBall = function(t) {
                        return t.events[0].result.finalOutcome[0]
                    }, e.prototype.getLastBall = function(t) {
                        var e = t.events[0].result.finalOutcome;
                        return e[e.length - 1]
                    }, e.prototype.getBallColor = function(t) {
                        return i.SessionController.gameManager.getSxGame().colors[t]
                    }, e.prototype.getEventResultData = function(t) {
                        var e = t.events[0].result.data;
                        return e.isSxEventResultData() && e
                    }, e
                }(u),
                m = function(t) {
                    function e(e) {
                        var n = t.call(this, e) || this;
                        return n.columns = [{
                            id: "EventId",
                            title: n.i18nService.get("sa_event_id"),
                            function: n.getEventId,
                            verticalAlign: a.b.TOP,
                            whiteSpace: a.d.PRE,
                            grow: 100
                        }, {
                            id: "DateTime",
                            title: n.i18nService.get("sa_date_time"),
                            function: n.getEventBlockTime,
                            verticalAlign: a.b.TOP,
                            grow: 170
                        }, {
                            id: "Results",
                            title: n.i18nService.get("sa_match"),
                            verticalAlign: a.b.TOP,
                            grow: 150
                        }, {
                            id: "CorrectScore",
                            title: n.i18nService.getMarketTag(i.ChMarkets.Correct_Score),
                            verticalAlign: a.b.TOP,
                            grow: 70,
                            templateData: i.ChMarkets.Correct_Score
                        }, {
                            id: "Total_Goals",
                            title: n.i18nService.getMarketTag(i.ChMarkets.Total_Goals),
                            verticalAlign: a.b.TOP,
                            grow: 70,
                            templateData: i.ChMarkets.Total_Goals
                        }, {
                            id: "MatchResult",
                            title: n.i18nService.getMarketTag(i.ChMarkets.Match_Result),
                            verticalAlign: a.b.TOP,
                            grow: 100,
                            templateData: i.ChMarkets.Match_Result
                        }, {
                            id: "GoalGoal_NoGoal",
                            title: n.i18nService.getMarketTag(i.ChMarkets.GoalGoal_NoGoal),
                            verticalAlign: a.b.TOP,
                            grow: 100,
                            templateData: i.ChMarkets.GoalGoal_NoGoal
                        }, {
                            id: "DoubleChance",
                            title: n.i18nService.getMarketTag(i.ChMarkets.Double_Chance),
                            verticalAlign: a.b.TOP,
                            grow: 100,
                            templateData: i.ChMarkets.Double_Chance
                        }, {
                            id: "Double_Result",
                            title: n.i18nService.getMarketTag(i.ChMarkets.Double_Result),
                            verticalAlign: a.b.TOP,
                            grow: 100,
                            templateData: i.ChMarkets.Double_Result
                        }, {
                            id: "OverUnder15",
                            title: n.i18nService.getMarketTag(i.ChMarkets.Over_Under_1_5),
                            verticalAlign: a.b.TOP,
                            grow: 100,
                            templateData: i.ChMarkets.Over_Under_1_5
                        }, {
                            id: "OverUnder25",
                            title: n.i18nService.getMarketTag(i.ChMarkets.Over_Under_2_5),
                            verticalAlign: a.b.TOP,
                            grow: 100,
                            templateData: i.ChMarkets.Over_Under_2_5
                        }], n
                    }
                    return Object(r.__extends)(e, t), Object.defineProperty(e.prototype, "resultsTemplate", {
                        set: function(t) {
                            this.setTemplateRef("Results", t)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "wonMarketTemplate", {
                        set: function(t) {
                            this.columns.slice(3).forEach((function(e) {
                                e.templateRef = t
                            }))
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.ngOnInit = function() {}, e.prototype.getWonOdd = function(t, e) {
                        var n = t.result._clData.parseWonOdd.get(e);
                        return this.translateWonOdds(n, t._clData.playlist.gameType.val)
                    }, e.prototype.translateWonOdds = function(t, e) {
                        var n = this,
                            l = [];
                        return t ? (t.forEach((function(t) {
                            return l.push(n.i18nService.getMarketOptionTag(o.I18NGameType[e], t.oddId))
                        })), l.join(", ")) : null
                    }, e
                }(u),
                f = n("t01L"),
                d = n("7Dvu"),
                h = function(t) {
                    function e(e, n) {
                        var l = t.call(this, e) || this;
                        return l.coreService = n, l.columns = [{
                            id: "EventId",
                            title: l.i18nService.get("sa_event_id"),
                            verticalAlign: a.b.TOP,
                            function: l.getEventId,
                            grow: 130
                        }, {
                            id: "DateTime",
                            title: l.i18nService.get("sa_date_time"),
                            verticalAlign: a.b.TOP,
                            function: l.getEventBlockTime,
                            grow: 210
                        }, {
                            id: "Results",
                            title: l.i18nService.get("sa_results"),
                            grow: 355
                        }, {
                            id: "FirstBallColor",
                            title: l.i18nService.get("sa_first_ball_color"),
                            verticalAlign: a.b.TOP,
                            grow: 160,
                            templateData: function(t) {
                                return l.getFirstBallColor(t)
                            }
                        }, {
                            id: "TotalRed",
                            title: l.i18nService.get("sa_total_red"),
                            verticalAlign: a.b.TOP,
                            grow: 160,
                            templateData: function(t) {
                                return l.getTotalRed(t)
                            }
                        }, {
                            id: "TotalGreen",
                            title: l.getTitle({
                                id: "TotalGreen",
                                tag: "sa_total_green"
                            }),
                            verticalAlign: a.b.TOP,
                            grow: 160,
                            templateData: function(t) {
                                return l.getTotalGreen(t)
                            }
                        }, {
                            id: "TotalBlue",
                            title: l.i18nService.get("sa_total_blue"),
                            verticalAlign: a.b.TOP,
                            grow: 160,
                            templateData: function(t) {
                                return l.getTotalBlue(t)
                            }
                        }, {
                            id: "WinningColor",
                            title: l.i18nService.get("sa_winning_color"),
                            verticalAlign: a.b.TOP,
                            grow: 160,
                            templateData: function(t) {
                                return "sa_rainbow_color_" + l.getWinningColor(l.getColors(t))
                            }
                        }], l
                    }
                    return Object(r.__extends)(e, t), Object.defineProperty(e.prototype, "resultsTemplate", {
                        set: function(t) {
                            this.setTemplateRef("Results", t)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "commonTemplate", {
                        set: function(t) {
                            var e = this;
                            ["TotalRed", "TotalGreen", "TotalBlue"].forEach((function(n) {
                                e.getColumn(n).templateRef = t
                            }))
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "colorTemplate", {
                        set: function(t) {
                            var e = this;
                            ["FirstBallColor", "WinningColor"].forEach((function(n) {
                                e.getColumn(n).templateRef = t
                            }))
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.ngOnInit = function() {}, e.prototype.getFirstBallColor = function(t) {
                        return "sa_rainbow_color_" + this.getBallColor(this.getEventResultFinalOutcome(t)[0])
                    }, e.prototype.getTotalRed = function(t) {
                        var e = this,
                            n = 0;
                        return this.getEventResultFinalOutcome(t).forEach((function(t) {
                            e.getBallColor(t) === i.RainbowColorType.RED && n++
                        })), n
                    }, e.prototype.getTotalGreen = function(t) {
                        var e = this,
                            n = 0;
                        return this.getEventResultFinalOutcome(t).forEach((function(t) {
                            e.getBallColor(t) === i.RainbowColorType.YELLOW && n++
                        })), n
                    }, e.prototype.getTotalBlue = function(t) {
                        var e = this,
                            n = 0;
                        return this.getEventResultFinalOutcome(t).forEach((function(t) {
                            e.getBallColor(t) === i.RainbowColorType.BLUE && n++
                        })), n
                    }, e.prototype.getWinningColor = function(t) {
                        var e = i.RainbowColorType.BLACK;
                        if (t[0].hits === t[1].hits) e = i.RainbowColorType.BLACK;
                        else switch (t[0].name) {
                            case i.RainbowColorType.RED:
                                e = i.RainbowColorType.RED;
                                break;
                            case i.RainbowColorType.YELLOW:
                                e = i.RainbowColorType.YELLOW;
                                break;
                            case i.RainbowColorType.BLUE:
                                e = i.RainbowColorType.BLUE
                        }
                        return e
                    }, e.prototype.getBallColor = function(t) {
                        return i.SessionController.gameManager.getRainbowGame().colors[t]
                    }, e.prototype.getStyle = function(t) {
                        return this.getBallColor(t)
                    }, e.prototype.getColors = function(t) {
                        this.getEventResultFinalOutcome(t);
                        var e = [];
                        return e.push(new i.coreModel.RainbowColorHits({
                            name: i.RainbowColorType.RED,
                            hits: this.getTotalRed(t)
                        })), e.push(new i.coreModel.RainbowColorHits({
                            name: i.RainbowColorType.YELLOW,
                            hits: this.getTotalGreen(t)
                        })), e.push(new i.coreModel.RainbowColorHits({
                            name: i.RainbowColorType.BLUE,
                            hits: this.getTotalBlue(t)
                        })), e.sort((function(t, e) {
                            return e.hits - t.hits
                        }))
                    }, e.prototype.getEventResultFinalOutcome = function(t) {
                        return t.events[0].result.finalOutcome
                    }, e.prototype.isColorColor = function() {
                        var t = this.coreService.getPlaylistsByGameType(i.GameTypeBuilder.build(i.coreModel.GameType.ValEnum.RAINBOW))[0];
                        return Object(d.c)(t)
                    }, e.prototype.getTitle = function(t) {
                        switch (t.id) {
                            case "TotalGreen":
                                return this.isColorColor() ? this.i18nService.get("sa_total_yellow") : this.i18nService.get(t.tag);
                            default:
                                return this.i18nService.get(t.tag)
                        }
                    }, e
                }(u),
                v = function(t) {
                    function e(e) {
                        var n = t.call(this, e) || this;
                        return n.S2wWheelType = i.S2wWheelType, n.columns = [{
                            id: "EventId",
                            title: n.i18nService.get("sa_event_id"),
                            function: n.getEventId,
                            verticalAlign: a.b.MIDDLE,
                            whiteSpace: a.d.PRE,
                            grow: 100
                        }, {
                            id: "DateTime",
                            title: n.i18nService.get("sa_date_time"),
                            function: n.getEventBlockTime,
                            verticalAlign: a.b.MIDDLE,
                            grow: 170
                        }, {
                            id: "Results",
                            title: n.i18nService.get("sa_numbers"),
                            verticalAlign: a.b.MIDDLE,
                            grow: 150,
                            templateData: [i.S2wMarkets.W36Numbers, i.S2wMarkets.W18Numbers]
                        }, {
                            id: "Colour",
                            title: n.i18nService.get("sa_colour"),
                            verticalAlign: a.b.MIDDLE,
                            grow: 70,
                            templateData: [i.S2wMarkets.W36Color, i.S2wMarkets.W18Color]
                        }, {
                            id: "Range",
                            title: n.i18nService.get("sa_range"),
                            verticalAlign: a.b.MIDDLE,
                            grow: 70,
                            templateData: [i.S2wMarkets.W36LowHigh, i.S2wMarkets.W18LowHigh]
                        }, {
                            id: "Even/Odd",
                            title: n.i18nService.get("sa_even_odd"),
                            verticalAlign: a.b.MIDDLE,
                            grow: 100,
                            templateData: [i.S2wMarkets.W36EvenOdd, i.S2wMarkets.W18EvenOdd]
                        }], n
                    }
                    return Object(r.__extends)(e, t), Object.defineProperty(e.prototype, "resultsTemplate", {
                        set: function(t) {
                            this.setTemplateRef("Results", t)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "wonMarketTemplate", {
                        set: function(t) {
                            this.columns.slice(3).forEach((function(e) {
                                e.templateRef = t
                            }))
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.ngOnInit = function() {}, e.prototype.getWonOdd36 = function(t, e) {
                        return this.getWonOdd(t, e[0])
                    }, e.prototype.getWonOdd18 = function(t, e) {
                        return this.getWonOdd(t, e[1])
                    }, e.prototype.getWonOdd = function(t, e) {
                        var n = t.result._clData.parseWonOdd.get(e);
                        return this.translateWonOdds(n, t._clData.playlist.gameType.val)
                    }, e.prototype.getColor = function(t, e) {
                        var n, l, r;
                        switch (t) {
                            case i.S2wWheelType.WHEEL18:
                                r = null === (n = i.SessionController.gameManager.getS2wGame().wheel18Colors[e]) || void 0 === n ? void 0 : n.toLowerCase();
                                break;
                            case i.S2wWheelType.WHEEL36:
                                r = null === (l = i.SessionController.gameManager.getS2wGame().wheel36Colors[e]) || void 0 === l ? void 0 : l.toLowerCase()
                        }
                        return "black" === r ? "k" : null == r ? void 0 : r.charAt(0)
                    }, e.prototype.translateWonOdds = function(t, e) {
                        var n = this,
                            l = [];
                        return t ? (t.forEach((function(t) {
                            return l.push(n.i18nService.getMarketOptionTag(o.I18NGameType[e], t.oddId))
                        })), l.join(", ")) : null
                    }, e
                }(u),
                _ = n("wF4r"),
                y = function() {
                    return (y = Object.assign || function(t) {
                        for (var e, n = 1, l = arguments.length; n < l; n++)
                            for (var r in e = arguments[n]) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
                        return t
                    }).apply(this, arguments)
                },
                O = function(t) {
                    function e(e) {
                        var n = t.call(this, e) || this;
                        return n.columns = [], n.templates = {}, n
                    }
                    return Object(r.__extends)(e, t), Object.defineProperty(e.prototype, "resultsTemplate", {
                        set: function(t) {
                            this.templates.results = t, this.setTemplateRef("Results", t)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "wonMarketTemplate", {
                        set: function(t) {
                            var e = this;
                            this.templates.wonMarket = t, this.columns.slice(3).forEach((function(n) {
                                e.getColumn(n.title).templateRef = t
                            }))
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "trifectaTemplate", {
                        set: function(t) {
                            var e = this;
                            this.templates.withoutSpaceTemplate = t, this.columns.slice(3).forEach((function(n) {
                                e.getColumn(n.title).templateRef = t
                            }))
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.ngOnInit = function() {
                        this.eventBlocks && this.eventBlocks.length && this.setColumns()
                    }, e.prototype.ngOnChanges = function(t) {
                        t.eventBlocks && !t.eventBlocks.isFirstChange() && t.eventBlocks.currentValue.length && this.setColumns()
                    }, e.prototype.setColumns = function() {
                        this.columns = [{
                            id: "EventId",
                            title: this.i18nService.get("sa_event_id"),
                            function: this.getEventId,
                            grow: 120
                        }, {
                            id: "DateTime",
                            title: this.i18nService.get("sa_date_time"),
                            function: this.getEventBlockTime,
                            grow: 229
                        }, {
                            id: "Results",
                            title: this.i18nService.get("sa_results"),
                            grow: 160,
                            templateRef: this.templates.results
                        }, {
                            id: "Win",
                            title: this.i18nService.getMarketTag("mma_" + i.MmaMarkets.win),
                            grow: 120,
                            templateData: i.MmaMarkets.win,
                            templateRef: this.templates.wonMarket
                        }, {
                            id: "Outcome",
                            title: this.i18nService.getMarketTag("mma_" + i.MmaMarkets.outcome),
                            grow: 120,
                            templateData: i.MmaMarkets.outcome,
                            templateRef: this.templates.wonMarket
                        }, {
                            id: "Fight Outcome",
                            title: this.i18nService.getMarketTag("mma_" + i.MmaMarkets.ko),
                            grow: 120,
                            templateData: i.MmaMarkets.ko,
                            templateRef: this.templates.wonMarket
                        }, {
                            id: "Over Under 1.5",
                            title: this.i18nService.getMarketTag("mma_" + i.MmaMarkets.over_under_1_5),
                            grow: 120,
                            templateData: i.MmaMarkets.over_under_1_5,
                            templateRef: this.templates.wonMarket
                        }, {
                            id: "Over Under 2.5",
                            title: this.i18nService.getMarketTag("mma_" + i.MmaMarkets.over_under_2_5),
                            grow: 120,
                            templateData: i.MmaMarkets.over_under_2_5,
                            templateRef: this.templates.wonMarket
                        }, {
                            id: "Round",
                            title: this.i18nService.getMarketTag("round_betting"),
                            grow: 120,
                            templateData: i.MmaMarkets.round,
                            templateRef: this.templates.wonMarket
                        }, {
                            id: "Correct Score",
                            title: this.i18nService.getMarketTag("mma_" + i.MmaMarkets.correct_score),
                            grow: 120,
                            templateData: i.MmaMarkets.correct_score,
                            templateRef: this.templates.wonMarket
                        }]
                    }, e.prototype.getWonOdds = function(t, e) {
                        var n = t.result._clData.parseWonOdd.get(e);
                        return n ? "round" !== n[0].oddId ? [y(y({}, n[0]), {
                            oddId: "" + this.i18nService.getMarketOptionTag(_.I18NGameType.MMA, n[0].oddId)
                        })] : [y(y({}, n[0]), {
                            oddId: n[0].oddId
                        })] : {
                            marketId: "TODO",
                            oddId: "TODO",
                            oddName: "TODO"
                        }
                    }, e.prototype.getBetParam = function(t, e) {
                        if (e === i.MmaMarkets.round) {
                            var n = i.SessionController.gameManager.getMmaGame().getAllRoundMarketOddByOutcome(t.result.finalOutcome);
                            return "" + this.i18nService.getMarketOptionTag(_.I18NGameType.MMA, n.complete.betParams)
                        }
                        return null
                    }, e.prototype.getGameType = function() {
                        return this.eventBlocks[0]._clData.gameType.val
                    }, e
                }(u),
                T = {
                    champion: c,
                    soccer: m,
                    league: c,
                    races: p,
                    sx: g,
                    rainbow: h,
                    s2w: v,
                    default: b,
                    mma: O
                },
                C = function() {
                    return function() {}
                }(),
                w = n("pMnS"),
                k = n("tTyv"),
                M = n("rxiI"),
                P = n("5zzm"),
                S = n("5EE+"),
                D = n("SHeQ"),
                I = n("yoGk"),
                R = n("Ip0R"),
                x = n("K9Ia"),
                j = n("ny24"),
                E = new l.r("ComponentInjector"),
                G = function() {
                    function t(t) {
                        this.componentOutlet = t
                    }
                    return Object.defineProperty(t.prototype, "componentRef", {
                        get: function() {
                            return this.componentOutlet._componentRef
                        },
                        enumerable: !0,
                        configurable: !0
                    }), t
                }();

            function B(t) {
                return new l.K(void 0, t, !0)
            }

            function W(t, e) {
                return function(n) {
                    return e(n, function(t, e) {
                        return void 0 === e && (e = !1), e ? B(t.currentValue) : new l.K(t.previousValue, t.currentValue, !1)
                    }(n, t))
                }
            }
            var A = {
                isFirstChanges: !1,
                onlyNewChanges: !1
            };

            function F(t) {
                return void 0 === t && (t = A), t.onlyNewChanges ? (e = t.isFirstChanges, function(t) {
                    return W(e, (function(e, n) {
                        t[e.key] || (t[e.key] = n)
                    }))
                }) : function(t) {
                    return function(e) {
                        return W(t, (function(t, n) {
                            return e[t.key] = n
                        }))
                    }
                }(t.isFirstChanges);
                var e
            }

            function N() {}
            var L = F({
                    isFirstChanges: !0
                }),
                U = F({
                    onlyNewChanges: !0
                }),
                H = function() {
                    function t(t, e) {
                        this.differs = t, this.cfr = e, this.checkInit = this.failInit, this.lastComponentInst = null, this.inputsDiffer = this.differs.find({}).create(), this.compFactory = null, this.outputsShouldDisconnect$ = new x.a, this.outputsChanged = function() {
                            return !1
                        }
                    }
                    return Object.defineProperty(t.prototype, "compRef", {
                        get: function() {
                            return this.compInjector.componentRef
                        },
                        enumerable: !0,
                        configurable: !0
                    }), Object.defineProperty(t.prototype, "componentInst", {
                        get: function() {
                            return this.compRef ? this.compRef.instance : null
                        },
                        enumerable: !0,
                        configurable: !0
                    }), Object.defineProperty(t.prototype, "componentInstChanged", {
                        get: function() {
                            return this.lastComponentInst !== this.componentInst && (this.lastComponentInst = this.componentInst, !0)
                        },
                        enumerable: !0,
                        configurable: !0
                    }), Object.defineProperty(t.prototype, "compCdr", {
                        get: function() {
                            return this.compRef ? this.compRef.injector.get(l.i) : null
                        },
                        enumerable: !0,
                        configurable: !0
                    }), t.prototype.ngOnDestroy = function() {
                        this._disconnectOutputs()
                    }, t.prototype.init = function(t, e) {
                        if (void 0 === e && (e = {}), this.checkInit = t ? N : this.failInit, this.compInjector = t, e.trackOutputChanges) {
                            var n = this.differs.find({}).create();
                            this.outputsChanged = function(t) {
                                return !!n.diff(t)
                            }
                        }
                    }, t.prototype.update = function(t, e, n, l) {
                        this.checkInit(), this.updateIO(t, e);
                        var r = this.componentInstChanged;
                        if (r || n) {
                            var a = this._getInputsChanges(this.inputs);
                            a && this._updateInputChanges(a), this.updateInputs(r || !this.lastInputChanges)
                        }(r || l) && this.bindOutputs()
                    }, t.prototype.maybeUpdate = function() {
                        if (this.checkInit(), this.componentInstChanged) return this.updateInputs(!0), void this.bindOutputs();
                        if (this.outputsChanged(this.outputs) && this.bindOutputs(), this.inputs) {
                            var t = this._getInputsChanges(this.inputs);
                            if (t) {
                                var e = !!this.lastInputChanges;
                                this._updateInputChanges(t), e && this.updateInputs()
                            }
                        }
                    }, t.prototype.updateIO = function(t, e) {
                        this.inputs = t, this.outputs = e
                    }, t.prototype.updateInputs = function(t) {
                        void 0 === t && (t = !1), t && this._updateCompFactory();
                        var e = this.componentInst,
                            n = this.inputs;
                        n && e && (n = this._resolveInputs(n), Object.keys(n).forEach((function(t) {
                            return e[t] = n[t]
                        })), this.compCdr && this.compCdr.markForCheck(), this.notifyOnInputChanges(this.lastInputChanges, t))
                    }, t.prototype.bindOutputs = function() {
                        var t = this;
                        this._disconnectOutputs();
                        var e = this.componentInst,
                            n = this.outputs;
                        n && e && (n = this._resolveOutputs(n), Object.keys(n).filter((function(t) {
                            return e[t]
                        })).forEach((function(l) {
                            return e[l].pipe(Object(j.a)(t.outputsShouldDisconnect$)).subscribe(n[l])
                        })))
                    }, t.prototype.notifyOnInputChanges = function(t, e) {
                        void 0 === t && (t = {}), this.componentInst.ngOnChanges && (e && (t = this._collectFirstChanges()), this.componentInst.ngOnChanges(t))
                    }, t.prototype._disconnectOutputs = function() {
                        this.outputsShouldDisconnect$.next()
                    }, t.prototype._getInputsChanges = function(t) {
                        return this.inputsDiffer.diff(this.inputs)
                    }, t.prototype._updateInputChanges = function(t) {
                        this.lastInputChanges = this._collectChangesFromDiffer(t)
                    }, t.prototype._collectFirstChanges = function() {
                        var t = {},
                            e = this.inputs;
                        return Object.keys(e).forEach((function(n) {
                            return t[n] = B(e[n])
                        })), this._resolveChanges(t)
                    }, t.prototype._collectChangesFromDiffer = function(t) {
                        var e = {};
                        return t.forEachAddedItem(L(e)), t.forEachItem(U(e)), this._resolveChanges(e)
                    }, t.prototype._resolveCompFactory = function() {
                        try {
                            try {
                                return this.cfr.resolveComponentFactory(this.compRef.componentType)
                            } catch (t) {
                                return this.cfr.resolveComponentFactory(this.compRef.instance.constructor)
                            }
                        } catch (t) {
                            return null
                        }
                    }, t.prototype._updateCompFactory = function() {
                        this.compFactory = this._resolveCompFactory()
                    }, t.prototype._resolveInputs = function(t) {
                        return this.compFactory ? this._remapIO(t, this.compFactory.inputs) : t
                    }, t.prototype._resolveOutputs = function(t) {
                        return this.compFactory ? this._remapIO(t, this.compFactory.outputs) : t
                    }, t.prototype._resolveChanges = function(t) {
                        return this.compFactory ? this._remapIO(t, this.compFactory.inputs) : t
                    }, t.prototype._remapIO = function(t, e) {
                        var n = this,
                            l = {};
                        return Object.keys(t).forEach((function(r) {
                            var a = n._findPropByTplInMapping(r, e) || r;
                            l[a] = t[r]
                        })), l
                    }, t.prototype._findPropByTplInMapping = function(t, e) {
                        var n, l;
                        try {
                            for (var a = Object(r.__values)(e), i = a.next(); !i.done; i = a.next()) {
                                var u = i.value;
                                if (u.templateName === t) return u.propName
                            }
                        } catch (o) {
                            n = {
                                error: o
                            }
                        } finally {
                            try {
                                i && !i.done && (l = a.return) && l.call(a)
                            } finally {
                                if (n) throw n.error
                            }
                        }
                        return null
                    }, t.prototype.failInit = function() {
                        throw Error("IoService: ComponentInjector was not set! Please call init() method!")
                    }, t
                }(),
                $ = function() {
                    function t(t, e) {
                        this.differs = t, this.cfr = e
                    }
                    return t.prototype.create = function() {
                        return new H(this.differs, this.cfr)
                    }, t
                }(),
                z = new l.r("WindowRef"),
                V = function() {
                    return function(t) {
                        this.injector = t, this.nativeWindow = this.injector.get(z, null)
                    }
                }(),
                q = function() {
                    function t(t, e) {
                        this.vcr = t, this.cfr = e, this.ndcDynamicCreated = new l.n
                    }
                    return t.prototype.ngOnChanges = function(t) {
                        t.ndcDynamicComponent && this.createDynamicComponent()
                    }, t.prototype.createDynamicComponent = function() {
                        this.vcr.clear(), this.componentRef = null, this.ndcDynamicComponent && (this.componentRef = this.vcr.createComponent(this.cfr.resolveComponentFactory(this.ndcDynamicComponent), 0, this._resolveInjector(), this.ndcDynamicContent), this.ndcDynamicCreated.emit(this.componentRef))
                    }, t.prototype._resolveInjector = function() {
                        var t = this.ndcDynamicInjector || this.vcr.injector;
                        return this.ndcDynamicProviders && (t = l.s.create({
                            providers: this.ndcDynamicProviders,
                            parent: t
                        })), t
                    }, t
                }(),
                J = function() {
                    function t(t, e, n, l) {
                        this.injector = t, this.ioService = e, this.componentInjectorType = n, this.componentOutletInjector = l, this.componentInjector = this.injector.get(this.componentInjectorType, null), this.ioService.init(this.compInjector)
                    }
                    return Object.defineProperty(t.prototype, "inputs", {
                        get: function() {
                            return this.ndcDynamicInputs || this.ngComponentOutletNdcDynamicInputs
                        },
                        enumerable: !0,
                        configurable: !0
                    }), Object.defineProperty(t.prototype, "outputs", {
                        get: function() {
                            return this.ndcDynamicOutputs || this.ngComponentOutletNdcDynamicOutputs
                        },
                        enumerable: !0,
                        configurable: !0
                    }), Object.defineProperty(t.prototype, "compInjector", {
                        get: function() {
                            return this.componentOutletInjector || this.componentInjector
                        },
                        enumerable: !0,
                        configurable: !0
                    }), t.prototype.ngOnChanges = function(t) {
                        this.ioService.update(this.inputs, this.outputs, this.inputsChanged(t), this.outputsChanged(t))
                    }, t.prototype.ngDoCheck = function() {
                        this.ioService.maybeUpdate()
                    }, t.prototype.inputsChanged = function(t) {
                        return "ngComponentOutletNdcDynamicInputs" in t || "ndcDynamicInputs" in t
                    }, t.prototype.outputsChanged = function(t) {
                        return "ngComponentOutletNdcDynamicOutputs" in t || "ndcDynamicOutputs" in t
                    }, t
                }();

            function K() {
                return window
            }
            var Y = function() {
                    function t() {}
                    return t.withComponents = function(e, n) {
                        return void 0 === n && (n = q), {
                            ngModule: t,
                            providers: [{
                                provide: l.a,
                                useValue: e,
                                multi: !0
                            }, {
                                provide: E,
                                useValue: n
                            }, $, {
                                provide: z,
                                useFactory: K
                            }, V]
                        }
                    }, t
                }(),
                Q = n("0/uQ"),
                X = n("yU3L"),
                Z = new l.r("ResultTableTemplates"),
                tt = function() {
                    function t(t, e, n, l, r) {
                        this.cd = t, this.coreService = e, this.route = n, this.loadingPanelService = l, this.resultTableTemplates = r, this.gameTypes = [], this.playlists = []
                    }
                    return t.prototype.ngOnInit = function() {
                        var t = this;
                        this.routeSubscription = this.route.queryParamMap.subscribe((function(e) {
                            var n;
                            t.gameTypes = t.getAllGameTypes(), t.gameTypeSelected = t.gameTypes[0], e.has("resultsGameType") && (t.gameTypeSelected = t.gameTypes.find((function(t) {
                                return t === e.get("resultsGameType")
                            })) || t.gameTypeSelected), e.has("resultsPlaylistId") && (n = +e.get("resultsPlaylistId")), t.getPlaylistsByGameType(n), t.playlistSelected && (t.getLastHistory(), t.onGameTypeSelected(t.gameTypeSelected), t.onPlaylistSelected(t.playlistSelected.id.toString()))
                        }))
                    }, t.prototype.ngOnDestroy = function() {
                        this.resetPagination(), this.routeSubscription && this.routeSubscription.unsubscribe(), this.historySubscription && this.historySubscription.unsubscribe()
                    }, t.prototype.getPlaylistsByGameType = function(t) {
                        var e = this;
                        if (this.playlists = this.coreService.getPlaylistsByGameType(i.GameTypeBuilder.build(i.coreModel.GameType.ValEnum[this.gameTypeSelected in i.coreModel.ChCompetitionType ? i.coreModel.GameType.ValEnum.CH : this.gameTypeSelected])).filter((function(t) {
                                return t.mode !== i.coreModel.Playlist.ModeEnum.ONDEMAND
                            })).filter((function(t) {
                                var n = !0;
                                return t.filter && t.filter.isChFilter() && (n = t.filter.competitionType === e.gameTypeSelected), n
                            })), this.playlists.length > 0) {
                            var n = this.playlists[0];
                            t && (n = this.playlists.find((function(e) {
                                return e.id === t
                            })) || n), this.playlistSelected = n
                        }
                    }, t.prototype.onGameTypeSelected = function(t) {
                        this.resetPagination(), this.eventBlocks = [], this.gameTypeSelected = t, this.getPlaylistsByGameType(), this.setTemplateByGameType(), this.getLastHistory()
                    }, t.prototype.onPlaylistSelected = function(t) {
                        this.playlistSelected = this.playlists.find((function(e) {
                            return e.id === Number(t)
                        })), this.getLastHistory()
                    }, t.prototype.onPrintLastResult = function() {
                        this.eventBlocks && this.eventBlocks.length > 0 && this.coreService.getPrintTicketController().printLastResults(this.eventBlocks)
                    }, t.prototype.getLastHistory = function() {
                        var t = this;
                        this.historySubscription && (this.historySubscription.unsubscribe(), this.loadingPanelService.hide(this.loadingPanel)), this.loadingPanel = this.loadingPanelService.show(this.resultsTable), this.historySubscription = Object(Q.a)(this.coreService.getEventControllerByPlaylistId(this.playlistSelected.id).historyManager.getLastHistory(10)).subscribe((function(e) {
                            void 0 === e && (e = []), t.eventBlocks = e, t.loadingPanelService.hide(t.loadingPanel), t.cd.detectChanges()
                        }))
                    }, t.prototype.setTemplateByGameType = function() {
                        switch (this.gameTypeSelected) {
                            case i.coreModel.GameType.ValEnum.DOG:
                            case i.coreModel.GameType.ValEnum.HORSE:
                            case i.coreModel.GameType.ValEnum.TROTTING:
                            case i.coreModel.GameType.ValEnum.SPEEDWAY:
                            case i.coreModel.GameType.ValEnum.KART:
                            case i.coreModel.GameType.ValEnum.MOTORBIKE:
                            case i.coreModel.GameType.ValEnum.DIRTTRACK:
                                this.templateSelected = this.resultTableTemplates.races;
                                break;
                            default:
                                var t = this.gameTypeSelected.toLowerCase();
                                this.templateSelected = this.resultTableTemplates[t], this.templateSelected || (this.templateSelected = this.resultTableTemplates.default)
                        }
                        this.cd.detectChanges()
                    }, t.prototype.getAllGameTypes = function() {
                        return this.coreService.getAllEventControllers().values().filter((function(t) {
                            return t.content.isPlaylistContent() && t.content._clData.playlist.mode !== i.coreModel.Playlist.ModeEnum.ONDEMAND
                        })).map((function(t) {
                            var e = t.content.isPlaylistContent() && t.content._clData.playlist;
                            return e.filter && e.filter.isChFilter() ? e.filter.competitionType : e.gameType.val
                        })).filter((function(t, e, n) {
                            return n.indexOf(t) === e
                        }))
                    }, t.prototype.resetPagination = function() {
                        var t, e;
                        null === (e = this.coreService.getEventControllerByPlaylistId(null === (t = this.playlistSelected) || void 0 === t ? void 0 : t.id)) || void 0 === e || e.historyManager.resetPagination()
                    }, t
                }(),
                et = n("ZYCi"),
                nt = l.sb({
                    encapsulation: 0,
                    styles: [
                        ['.results[_ngcontent-%COMP%]{overflow:auto}.results__select[_ngcontent-%COMP%] + .results__select[_ngcontent-%COMP%]{margin-left:20px}.results__table[_ngcontent-%COMP%]{position:relative;max-height:700px;overflow-x:auto;overflow-y:auto}.result[_ngcontent-%COMP%]:nth-child(n+6){margin-top:10px}.result--winner[_ngcontent-%COMP%]{font-family:"Open Sans Bold"}.result-grid--gl[_ngcontent-%COMP%]{max-width:700px}.button--info[_ngcontent-%COMP%]{margin-bottom:20px}']
                    ],
                    data: {}
                });

            function lt(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 3, "grsa-select-option", [], null, null, null, M.b, M.a)), l.tb(1, 114688, [
                    [2, 4]
                ], 0, P.a, [], {
                    id: [0, "id"],
                    value: [1, "value"]
                }, null), l.Jb(2, 1), l.Hb(131072, S.i, [S.j, l.i])], (function(t, e) {
                    var n = e.context.$implicit,
                        r = l.Ob(e, 1, 1, l.Gb(e, 3).transform(l.Ob(e, 1, 1, t(e, 2, 0, l.Gb(e.parent, 1), "sa_game_" + e.context.$implicit))));
                    t(e, 1, 0, n, r)
                }), null)
            }

            function rt(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 2, "grsa-select-option", [], null, null, null, M.b, M.a)), l.tb(1, 114688, [
                    [3, 4]
                ], 0, P.a, [], {
                    id: [0, "id"],
                    value: [1, "value"]
                }, null), l.Hb(131072, S.i, [S.j, l.i])], (function(t, e) {
                    t(e, 1, 0, e.context.$implicit.id, l.Ob(e, 1, 1, l.Gb(e, 2).transform(e.context.$implicit.descriptionTag)))
                }), null)
            }

            function at(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 4, "grsa-select", [
                    ["class", "results__select"]
                ], null, [
                    [null, "selectedChange"],
                    ["document", "click"]
                ], (function(t, e, n) {
                    var r = !0,
                        a = t.component;
                    return "document:click" === e && (r = !1 !== l.Gb(t, 1).onClick(n) && r), "selectedChange" === e && (r = !1 !== a.onPlaylistSelected(n) && r), r
                }), D.b, D.a)), l.tb(1, 4833280, null, 1, I.a, [l.i, l.F, l.l, f.a, S.j], {
                    selected: [0, "selected"]
                }, {
                    selectedChange: "selectedChange"
                }), l.Lb(603979776, 3, {
                    options: 1
                }), (t()(), l.jb(16777216, null, null, 1, null, rt)), l.tb(4, 278528, null, 0, R.k, [l.R, l.O, l.u], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(t, e) {
                    var n = e.component;
                    t(e, 1, 0, n.playlistSelected.id), t(e, 4, 0, n.playlists)
                }), null)
            }

            function it(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 0, null, null, null, null, null, null, null))], null, null)
            }

            function ut(t) {
                return l.Pb(2, [l.Hb(0, R.u, []), l.Hb(0, R.h, []), l.Lb(402653184, 1, {
                    resultsTable: 0
                }), (t()(), l.ub(3, 0, null, null, 25, "div", [
                    ["class", "page"]
                ], null, null, null, null, null)), (t()(), l.ub(4, 0, null, null, 4, "div", [
                    ["class", "page-header"]
                ], null, null, null, null, null)), (t()(), l.ub(5, 0, null, null, 3, "h3", [
                    ["class", "page-title"]
                ], null, null, null, null, null)), (t()(), l.Nb(6, null, ["", ""])), l.Hb(131072, S.i, [S.j, l.i]), l.Jb(8, 1), (t()(), l.ub(9, 0, null, null, 12, "div", [
                    ["class", "grid grid-space-between"]
                ], null, null, null, null, null)), (t()(), l.ub(10, 0, null, null, 7, "div", [
                    ["class", "col"]
                ], null, null, null, null, null)), (t()(), l.ub(11, 0, null, null, 4, "grsa-select", [
                    ["class", "results__select"]
                ], null, [
                    [null, "selectedChange"],
                    ["document", "click"]
                ], (function(t, e, n) {
                    var r = !0,
                        a = t.component;
                    return "document:click" === e && (r = !1 !== l.Gb(t, 12).onClick(n) && r), "selectedChange" === e && (r = !1 !== a.onGameTypeSelected(n) && r), r
                }), D.b, D.a)), l.tb(12, 4833280, null, 1, I.a, [l.i, l.F, l.l, f.a, S.j], {
                    selected: [0, "selected"]
                }, {
                    selectedChange: "selectedChange"
                }), l.Lb(603979776, 2, {
                    options: 1
                }), (t()(), l.jb(16777216, null, null, 1, null, lt)), l.tb(15, 278528, null, 0, R.k, [l.R, l.O, l.u], {
                    ngForOf: [0, "ngForOf"]
                }, null), (t()(), l.jb(16777216, null, null, 1, null, at)), l.tb(17, 16384, null, 0, R.l, [l.R, l.O], {
                    ngIf: [0, "ngIf"]
                }, null), (t()(), l.ub(18, 0, null, null, 3, "div", [
                    ["class", "button button--info"]
                ], null, [
                    [null, "click"]
                ], (function(t, e, n) {
                    var l = !0;
                    return "click" === e && (l = !1 !== t.component.onPrintLastResult() && l), l
                }), null, null)), (t()(), l.Nb(19, null, ["", ""])), l.Hb(131072, S.i, [S.j, l.i]), l.Jb(21, 1), (t()(), l.ub(22, 0, [
                    [1, 0],
                    ["resultsTable", 1]
                ], null, 6, "div", [
                    ["class", "results__table"]
                ], null, null, null, null, null)), (t()(), l.jb(16777216, null, null, 5, null, it)), l.tb(24, 671744, null, 0, R.j, [l.R], {
                    ngComponentOutlet: [0, "ngComponentOutlet"]
                }, null), l.Kb(131584, null, H, H, [l.v, l.k]), l.tb(26, 16384, null, 0, G, [R.j], null, null), l.tb(27, 802816, null, 0, J, [l.s, H, E, [2, G]], {
                    ngComponentOutletNdcDynamicInputs: [0, "ngComponentOutletNdcDynamicInputs"]
                }, null), l.Ib(28, {
                    eventBlocks: 0
                })], (function(t, e) {
                    var n = e.component;
                    t(e, 12, 0, n.gameTypeSelected), t(e, 15, 0, n.gameTypes), t(e, 17, 0, n.playlists.length > 1), t(e, 24, 0, n.templateSelected);
                    var l = t(e, 28, 0, n.eventBlocks);
                    t(e, 27, 0, l)
                }), (function(t, e) {
                    var n = l.Ob(e, 6, 0, t(e, 8, 0, l.Gb(e, 0), l.Ob(e, 6, 0, l.Gb(e, 7).transform("sa_results"))));
                    t(e, 6, 0, n);
                    var r = l.Ob(e, 19, 0, t(e, 21, 0, l.Gb(e, 0), l.Ob(e, 19, 0, l.Gb(e, 20).transform("sa_print_last_results"))));
                    t(e, 19, 0, r)
                }))
            }

            function ot(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 1, "grsa-page-results", [], null, null, null, ut, nt)), l.tb(1, 245760, null, 0, tt, [l.i, f.a, et.a, X.a, Z], null, null)], (function(t, e) {
                    t(e, 1, 0)
                }), null)
            }
            var st = l.qb("grsa-page-results", tt, ot, {}, {}, []),
                ct = function() {
                    function t() {
                        this.isWinner = !1
                    }
                    return t.prototype.ngOnInit = function() {
                        var t, e = +this.grsaGlParticipantWinner.result.finalOutcome[0] + +this.grsaGlParticipantWinner.result.finalOutcome[2],
                            n = +this.grsaGlParticipantWinner.result.finalOutcome[1] + +this.grsaGlParticipantWinner.result.finalOutcome[3];
                        e > n ? t = 0 : n > e && (t = 1), this.isWinner = +this.grsaGlParticipantWinnerIndex === t
                    }, t
                }(),
                pt = function() {
                    function t() {}
                    return t.prototype.transform = function(t, e) {
                        var n = this.hasPenalty(t, e) ? "*" : "",
                            l = this.getParticipant(t, e) + " " + this.getGoals(t, e) + " " + n + " ";
                        return 1 === e && (l = " " + this.getGoals(t, e) + " " + n + " " + this.getParticipant(t, e)), l
                    }, t.prototype.getParticipant = function(t, e) {
                        var n = t.data.participants[e];
                        return n.isFootballParticipant() && n.fifaCode
                    }, t.prototype.getGoals = function(t, e) {
                        return +t.result.finalOutcome[e] + +t.result.finalOutcome[e + 2]
                    }, t.prototype.getClassifiedTeam = function(t) {
                        return t.classifiedTeam
                    }, t.prototype.hasPenalty = function(t, e) {
                        var n = t.result.data.isChEventResultData() && t.result.data,
                            l = this.getClassifiedTeam(n);
                        return n.penalty && l && t.data.participants[e].id === l
                    }, t
                }(),
                bt = n("kmhj"),
                gt = l.sb({
                    encapsulation: 0,
                    styles: [
                        [".soccer-results-table__event[_ngcontent-%COMP%] + .soccer-results-table__event[_ngcontent-%COMP%]{margin-top:6px}"]
                    ],
                    data: {}
                });

            function mt(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 10, "div", [
                    ["class", "soccer-results-table__event"]
                ], null, null, null, null, null)), (t()(), l.ub(1, 0, null, null, 3, "span", [], [
                    [2, "result--winner", null]
                ], null, null, null, null)), l.tb(2, 81920, null, 0, ct, [], {
                    grsaGlParticipantWinner: [0, "grsaGlParticipantWinner"],
                    grsaGlParticipantWinnerIndex: [1, "grsaGlParticipantWinnerIndex"]
                }, null), (t()(), l.Nb(3, null, ["", ""])), l.Jb(4, 2), (t()(), l.ub(5, 0, null, null, 1, "span", [], null, null, null, null, null)), (t()(), l.Nb(-1, null, ["-"])), (t()(), l.ub(7, 0, null, null, 3, "span", [], [
                    [2, "result--winner", null]
                ], null, null, null, null)), l.tb(8, 81920, null, 0, ct, [], {
                    grsaGlParticipantWinner: [0, "grsaGlParticipantWinner"],
                    grsaGlParticipantWinnerIndex: [1, "grsaGlParticipantWinnerIndex"]
                }, null), (t()(), l.Nb(9, null, ["", ""])), l.Jb(10, 2)], (function(t, e) {
                    t(e, 2, 0, e.context.$implicit, 0), t(e, 8, 0, e.context.$implicit, 1)
                }), (function(t, e) {
                    t(e, 1, 0, l.Gb(e, 2).isWinner);
                    var n = l.Ob(e, 3, 0, t(e, 4, 0, l.Gb(e.parent.parent, 0), e.context.$implicit, 0));
                    t(e, 3, 0, n), t(e, 7, 0, l.Gb(e, 8).isWinner);
                    var r = l.Ob(e, 9, 0, t(e, 10, 0, l.Gb(e.parent.parent, 0), e.context.$implicit, 1));
                    t(e, 9, 0, r)
                }))
            }

            function ft(t) {
                return l.Pb(0, [(t()(), l.jb(16777216, null, null, 1, null, mt)), l.tb(1, 278528, null, 0, R.k, [l.R, l.O, l.u], {
                    ngForOf: [0, "ngForOf"]
                }, null), (t()(), l.jb(0, null, null, 0))], (function(t, e) {
                    t(e, 1, 0, e.context.data.events)
                }), null)
            }

            function dt(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 1, "div", [
                    ["class", "soccer-results-table__event"]
                ], null, null, null, null, null)), (t()(), l.Nb(1, null, [" ", " "]))], null, (function(t, e) {
                    t(e, 1, 0, e.component.getWonOdd(e.context.$implicit, e.parent.context.templateData))
                }))
            }

            function ht(t) {
                return l.Pb(0, [(t()(), l.jb(16777216, null, null, 1, null, dt)), l.tb(1, 278528, null, 0, R.k, [l.R, l.O, l.u], {
                    ngForOf: [0, "ngForOf"]
                }, null), (t()(), l.jb(0, null, null, 0))], (function(t, e) {
                    t(e, 1, 0, e.context.data.events)
                }), null)
            }

            function vt(t) {
                return l.Pb(2, [l.Hb(0, pt, []), l.Lb(671088640, 1, {
                    resultsTemplate: 0
                }), l.Lb(671088640, 2, {
                    wonMarketTemplate: 0
                }), (t()(), l.ub(3, 0, null, null, 1, "grsa-table", [], [
                    [2, "table", null]
                ], null, null, bt.b, bt.a)), l.tb(4, 4308992, null, 0, a.c, [l.i, l.l], {
                    columns: [0, "columns"],
                    rows: [1, "rows"]
                }, null), (t()(), l.jb(0, [
                    [1, 2],
                    ["resultsTemplate", 2]
                ], null, 0, null, ft)), (t()(), l.jb(0, [
                    [2, 2],
                    ["wonMarketTemplate", 2]
                ], null, 0, null, ht))], (function(t, e) {
                    var n = e.component;
                    t(e, 4, 0, n.columns, n.eventBlocks)
                }), (function(t, e) {
                    t(e, 3, 0, l.Gb(e, 4).clazz)
                }))
            }

            function _t(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 1, "grsa-soccer-results-table", [], null, null, null, vt, gt)), l.tb(1, 114688, null, 0, m, [S.j], null, null)], (function(t, e) {
                    t(e, 1, 0)
                }), null)
            }
            var yt = l.qb("grsa-soccer-results-table", m, _t, {
                    eventBlocks: "eventBlocks"
                }, {}, []),
                Ot = l.sb({
                    encapsulation: 0,
                    styles: [
                        [".gl-results-table__event[_ngcontent-%COMP%] + .gl-results-table__event[_ngcontent-%COMP%]{margin-top:6px}"]
                    ],
                    data: {}
                });

            function Tt(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 10, "div", [
                    ["class", "gl-results-table__event"]
                ], null, null, null, null, null)), (t()(), l.ub(1, 0, null, null, 3, "span", [], [
                    [2, "result--winner", null]
                ], null, null, null, null)), l.tb(2, 81920, null, 0, ct, [], {
                    grsaGlParticipantWinner: [0, "grsaGlParticipantWinner"],
                    grsaGlParticipantWinnerIndex: [1, "grsaGlParticipantWinnerIndex"]
                }, null), (t()(), l.Nb(3, null, ["", ""])), l.Jb(4, 2), (t()(), l.ub(5, 0, null, null, 1, "span", [], null, null, null, null, null)), (t()(), l.Nb(-1, null, ["-"])), (t()(), l.ub(7, 0, null, null, 3, "span", [], [
                    [2, "result--winner", null]
                ], null, null, null, null)), l.tb(8, 81920, null, 0, ct, [], {
                    grsaGlParticipantWinner: [0, "grsaGlParticipantWinner"],
                    grsaGlParticipantWinnerIndex: [1, "grsaGlParticipantWinnerIndex"]
                }, null), (t()(), l.Nb(9, null, ["", ""])), l.Jb(10, 2)], (function(t, e) {
                    t(e, 2, 0, e.context.$implicit, 0), t(e, 8, 0, e.context.$implicit, 1)
                }), (function(t, e) {
                    t(e, 1, 0, l.Gb(e, 2).isWinner);
                    var n = l.Ob(e, 3, 0, t(e, 4, 0, l.Gb(e.parent.parent, 0), e.context.$implicit, 0));
                    t(e, 3, 0, n), t(e, 7, 0, l.Gb(e, 8).isWinner);
                    var r = l.Ob(e, 9, 0, t(e, 10, 0, l.Gb(e.parent.parent, 0), e.context.$implicit, 1));
                    t(e, 9, 0, r)
                }))
            }

            function Ct(t) {
                return l.Pb(0, [(t()(), l.jb(16777216, null, null, 1, null, Tt)), l.tb(1, 278528, null, 0, R.k, [l.R, l.O, l.u], {
                    ngForOf: [0, "ngForOf"]
                }, null), (t()(), l.jb(0, null, null, 0))], (function(t, e) {
                    t(e, 1, 0, e.context.data.events)
                }), null)
            }

            function wt(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 1, "div", [
                    ["class", "gl-results-table__event"]
                ], null, null, null, null, null)), (t()(), l.Nb(1, null, [" ", " "]))], null, (function(t, e) {
                    t(e, 1, 0, e.component.getWonOdd(e.context.$implicit, e.parent.context.templateData))
                }))
            }

            function kt(t) {
                return l.Pb(0, [(t()(), l.jb(16777216, null, null, 1, null, wt)), l.tb(1, 278528, null, 0, R.k, [l.R, l.O, l.u], {
                    ngForOf: [0, "ngForOf"]
                }, null), (t()(), l.jb(0, null, null, 0))], (function(t, e) {
                    t(e, 1, 0, e.context.data.events)
                }), null)
            }

            function Mt(t) {
                return l.Pb(2, [l.Hb(0, pt, []), l.Lb(671088640, 1, {
                    resultsTemplate: 0
                }), l.Lb(671088640, 2, {
                    wonMarketTemplate: 0
                }), (t()(), l.ub(3, 0, null, null, 1, "grsa-table", [], [
                    [2, "table", null]
                ], null, null, bt.b, bt.a)), l.tb(4, 4308992, null, 0, a.c, [l.i, l.l], {
                    columns: [0, "columns"],
                    rows: [1, "rows"]
                }, null), (t()(), l.jb(0, [
                    [1, 2],
                    ["resultsTemplate", 2]
                ], null, 0, null, Ct)), (t()(), l.jb(0, [
                    [2, 2],
                    ["wonMarketTemplate", 2]
                ], null, 0, null, kt))], (function(t, e) {
                    var n = e.component;
                    t(e, 4, 0, n.columns, n.eventBlocks)
                }), (function(t, e) {
                    t(e, 3, 0, l.Gb(e, 4).clazz)
                }))
            }

            function Pt(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 1, "grsa-gl-results-table", [], null, null, null, Mt, Ot)), l.tb(1, 114688, null, 0, c, [S.j], null, null)], (function(t, e) {
                    t(e, 1, 0)
                }), null)
            }
            var St = l.qb("grsa-gl-results-table", c, Pt, {
                    eventBlocks: "eventBlocks"
                }, {}, []),
                Dt = l.sb({
                    encapsulation: 0,
                    styles: [
                        [".gl-results-table__event[_ngcontent-%COMP%]{line-height:24px}"]
                    ],
                    data: {}
                });

            function It(t) {
                return l.Pb(0, [(t()(), l.Nb(0, null, [" ", "\n"]))], null, (function(t, e) {
                    var n = e.context.data.events[0].result.finalOutcome.join(" - ");
                    t(e, 0, 0, n)
                }))
            }

            function Rt(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 1, null, null, null, null, null, null, null)), (t()(), l.Nb(-1, null, [","]))], null, null)
            }

            function xt(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 6, null, null, null, null, null, null, null)), (t()(), l.ub(1, 0, null, null, 5, "span", [], null, null, null, null, null)), (t()(), l.Nb(2, null, [" ", ""])), l.Ib(3, {
                    betParams: 0
                }), l.Hb(131072, S.o, [S.j, l.i]), (t()(), l.jb(16777216, null, null, 1, null, Rt)), l.tb(6, 16384, null, 0, R.l, [l.R, l.O], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(t, e) {
                    t(e, 6, 0, !e.context.last)
                }), (function(t, e) {
                    var n = e.component,
                        r = l.Ob(e, 2, 0, l.Gb(e, 4).transform(e.context.$implicit.oddId, n.getGameType(), t(e, 3, 0, n.getBetParam(e.parent.context.data.events[0], e.parent.context.templateData))));
                    t(e, 2, 0, r)
                }))
            }

            function jt(t) {
                return l.Pb(0, [(t()(), l.jb(16777216, null, null, 1, null, xt)), l.tb(1, 278528, null, 0, R.k, [l.R, l.O, l.u], {
                    ngForOf: [0, "ngForOf"]
                }, null), (t()(), l.jb(0, null, null, 0))], (function(t, e) {
                    t(e, 1, 0, e.component.getWonOdds(e.context.data.events[0], e.context.templateData))
                }), null)
            }

            function Et(t) {
                return l.Pb(0, [(t()(), l.Nb(0, null, [" ", "\n"]))], null, (function(t, e) {
                    var n = e.context.data.events[0].result.finalOutcome.join(",");
                    t(e, 0, 0, n)
                }))
            }

            function Gt(t) {
                return l.Pb(2, [l.Lb(402653184, 1, {
                    resultsTemplate: 0
                }), l.Lb(402653184, 2, {
                    wonMarketTemplate: 0
                }), l.Lb(402653184, 3, {
                    trifectaTemplate: 0
                }), (t()(), l.ub(3, 0, null, null, 1, "grsa-table", [], [
                    [2, "table", null]
                ], null, null, bt.b, bt.a)), l.tb(4, 4308992, null, 0, a.c, [l.i, l.l], {
                    columns: [0, "columns"],
                    rows: [1, "rows"]
                }, null), (t()(), l.jb(0, [
                    [1, 2],
                    ["resultsTemplate", 2]
                ], null, 0, null, It)), (t()(), l.jb(0, [
                    [2, 2],
                    ["wonMarketTemplate", 2]
                ], null, 0, null, jt)), (t()(), l.jb(0, [
                    [3, 2],
                    ["withoutSpaceTemplate", 2]
                ], null, 0, null, Et))], (function(t, e) {
                    var n = e.component;
                    t(e, 4, 0, n.columns, n.eventBlocks)
                }), (function(t, e) {
                    t(e, 3, 0, l.Gb(e, 4).clazz)
                }))
            }

            function Bt(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 1, "grsa-races-results-table", [], null, null, null, Gt, Dt)), l.tb(1, 638976, null, 0, p, [S.j], null, null)], (function(t, e) {
                    t(e, 1, 0)
                }), null)
            }
            var Wt = l.qb("grsa-races-results-table", p, Bt, {
                    eventBlocks: "eventBlocks"
                }, {}, []),
                At = l.sb({
                    encapsulation: 0,
                    styles: [
                        [".sx-results-table__event[_ngcontent-%COMP%]{margin-right:10px;font-weight:700}"]
                    ],
                    data: {}
                });

            function Ft(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 1, "span", [
                    ["class", "sx-results-table__event"]
                ], null, null, null, null, null)), (t()(), l.Nb(1, null, [" ", " "]))], null, (function(t, e) {
                    t(e, 1, 0, e.context.$implicit)
                }))
            }

            function Nt(t) {
                return l.Pb(0, [(t()(), l.jb(16777216, null, null, 1, null, Ft)), l.tb(1, 278528, null, 0, R.k, [l.R, l.O, l.u], {
                    ngForOf: [0, "ngForOf"]
                }, null), (t()(), l.jb(0, null, null, 0))], (function(t, e) {
                    t(e, 1, 0, e.context.data.events[0].result.finalOutcome)
                }), null)
            }

            function Lt(t) {
                return l.Pb(0, [(t()(), l.Nb(0, null, [" ", "\n"]))], null, (function(t, e) {
                    var n = e.context.templateData(e.context.data).join(", ");
                    t(e, 0, 0, n)
                }))
            }

            function Ut(t) {
                return l.Pb(0, [(t()(), l.Nb(0, null, [" ", " ", "\n"])), l.Hb(131072, S.i, [S.j, l.i])], null, (function(t, e) {
                    var n = e.component,
                        r = e.context.templateData(e.context.data),
                        a = l.Ob(e, 0, 1, l.Gb(e, 1).transform("sa_sx_color_" + n.getBallColor(e.context.templateData(e.context.data))));
                    t(e, 0, 0, r, a)
                }))
            }

            function Ht(t) {
                return l.Pb(2, [l.Lb(671088640, 1, {
                    resultsTemplate: 0
                }), l.Lb(402653184, 2, {
                    numbersTemplate: 0
                }), l.Lb(402653184, 3, {
                    ballTemplate: 0
                }), (t()(), l.ub(3, 0, null, null, 1, "grsa-table", [], [
                    [2, "table", null]
                ], null, null, bt.b, bt.a)), l.tb(4, 4308992, null, 0, a.c, [l.i, l.l], {
                    columns: [0, "columns"],
                    rows: [1, "rows"]
                }, null), (t()(), l.jb(0, [
                    [1, 2],
                    ["resultsTemplate", 2]
                ], null, 0, null, Nt)), (t()(), l.jb(0, [
                    [2, 2],
                    ["numbersTemplate", 2]
                ], null, 0, null, Lt)), (t()(), l.jb(0, [
                    [3, 2],
                    ["ballTemplate", 2]
                ], null, 0, null, Ut))], (function(t, e) {
                    var n = e.component;
                    t(e, 4, 0, n.columns, n.eventBlocks)
                }), (function(t, e) {
                    t(e, 3, 0, l.Gb(e, 4).clazz)
                }))
            }

            function $t(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 1, "grsa-sx-results-table", [], null, null, null, Ht, At)), l.tb(1, 114688, null, 0, g, [S.j], null, null)], (function(t, e) {
                    t(e, 1, 0)
                }), null)
            }
            var zt = l.qb("grsa-sx-results-table", g, $t, {
                    eventBlocks: "eventBlocks"
                }, {}, []),
                Vt = l.sb({
                    encapsulation: 0,
                    styles: [
                        [".rainbow-results-table[_ngcontent-%COMP%]{display:flex}.rainbow-results-table__ball[_ngcontent-%COMP%]{display:flex;width:24px;height:24px;margin-right:8px;font-size:14px;font-weight:700;border-radius:50px;justify-content:center;align-items:center}.rainbow-results-table__ball--r[_ngcontent-%COMP%]{color:rgba(213,0,0,.87);border:2px solid #d50000}.rainbow-results-table__ball--g[_ngcontent-%COMP%]{color:#007304;border:2px solid #007304}.rainbow-results-table__ball--y[_ngcontent-%COMP%]{color:#f79500;border:2px solid #f79500}.rainbow-results-table__ball--b[_ngcontent-%COMP%]{color:#003d95;border:2px solid #003d95}.rainbow-results-table__ball--k[_ngcontent-%COMP%]{color:rgba(0,0,0,.87);border:2px solid #000}"]
                    ],
                    data: {}
                });

            function qt(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 2, "div", [], [
                    [8, "className", 0]
                ], null, null, null, null)), (t()(), l.ub(1, 0, null, null, 1, "span", [], [
                    [8, "className", 0]
                ], null, null, null, null)), (t()(), l.Nb(2, null, ["", ""]))], null, (function(t, e) {
                    var n = e.component;
                    t(e, 0, 0, l.yb(1, "rainbow-results-table__ball rainbow-results-table__ball--", n.getStyle(e.context.$implicit), "")), t(e, 1, 0, l.yb(1, "rainbow-results-table__ball-number rainbow-results-table__ball-number--", n.getStyle(e.context.$implicit), "")), t(e, 2, 0, e.context.$implicit)
                }))
            }

            function Jt(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 2, "div", [
                    ["class", "rainbow-results-table"]
                ], null, null, null, null, null)), (t()(), l.jb(16777216, null, null, 1, null, qt)), l.tb(2, 278528, null, 0, R.k, [l.R, l.O, l.u], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(t, e) {
                    t(e, 2, 0, e.context.data.events[0].result.finalOutcome)
                }), null)
            }

            function Kt(t) {
                return l.Pb(0, [(t()(), l.Nb(0, null, [" ", "\n"]))], null, (function(t, e) {
                    var n = e.context.templateData(e.context.data);
                    t(e, 0, 0, n)
                }))
            }

            function Yt(t) {
                return l.Pb(0, [(t()(), l.Nb(0, null, [" ", "\n"])), l.Hb(131072, S.i, [S.j, l.i])], null, (function(t, e) {
                    var n = l.Ob(e, 0, 0, l.Gb(e, 1).transform(e.context.templateData(e.context.data)));
                    t(e, 0, 0, n)
                }))
            }

            function Qt(t) {
                return l.Pb(2, [l.Lb(671088640, 1, {
                    resultsTemplate: 0
                }), l.Lb(402653184, 2, {
                    commonTemplate: 0
                }), l.Lb(402653184, 3, {
                    colorTemplate: 0
                }), (t()(), l.ub(3, 0, null, null, 1, "grsa-table", [], [
                    [2, "table", null]
                ], null, null, bt.b, bt.a)), l.tb(4, 4308992, null, 0, a.c, [l.i, l.l], {
                    columns: [0, "columns"],
                    rows: [1, "rows"]
                }, null), (t()(), l.jb(0, [
                    [1, 2],
                    ["resultsTemplate", 2]
                ], null, 0, null, Jt)), (t()(), l.jb(0, [
                    [2, 2],
                    ["commonTemplate", 2]
                ], null, 0, null, Kt)), (t()(), l.jb(0, [
                    [3, 2],
                    ["colorTemplate", 2]
                ], null, 0, null, Yt))], (function(t, e) {
                    var n = e.component;
                    t(e, 4, 0, n.columns, n.eventBlocks)
                }), (function(t, e) {
                    t(e, 3, 0, l.Gb(e, 4).clazz)
                }))
            }

            function Xt(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 1, "grsa-rainbow-results-table", [], null, null, null, Qt, Vt)), l.tb(1, 114688, null, 0, h, [S.j, f.a], null, null)], (function(t, e) {
                    t(e, 1, 0)
                }), null)
            }
            var Zt = l.qb("grsa-rainbow-results-table", h, Xt, {
                    eventBlocks: "eventBlocks"
                }, {}, []),
                te = l.sb({
                    encapsulation: 0,
                    styles: [
                        [".s2w-results[_ngcontent-%COMP%]     .table-cell{padding:10px;justify-content:center;align-items:center}.s2w-results-table[_ngcontent-%COMP%]{display:flex}.s2w-results-table__ball[_ngcontent-%COMP%]{display:flex;width:35px;height:35px;margin-right:8px;font-size:18px;font-weight:700;border-radius:3px;justify-content:center;align-items:center}.s2w-results-table__ball--r[_ngcontent-%COMP%]{color:#fff;background-color:#c11026}.s2w-results-table__ball--g[_ngcontent-%COMP%]{color:#fff;background-color:#619b1f}.s2w-results-table__ball--b[_ngcontent-%COMP%]{color:#fff;background-color:#3863d5}.s2w-results-table__ball--y[_ngcontent-%COMP%]{color:#000;background-color:#d8c803}.s2w-results-table__ball--k[_ngcontent-%COMP%]{color:#fff;background-color:#000}.s2w-results-table__ball[_ngcontent-%COMP%]   .s2w-wheel-36-circle[_ngcontent-%COMP%]{width:30px;height:30px;color:#fff;background-color:#000;border-radius:50px;justify-content:center;align-items:center}"]
                    ],
                    data: {}
                });

            function ee(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 2, "div", [
                    ["class", "s2w-results-table s2w-wheel-36-circle"]
                ], null, null, null, null, null)), (t()(), l.ub(1, 0, null, null, 1, "span", [], [
                    [8, "className", 0]
                ], null, null, null, null)), (t()(), l.Nb(2, null, ["", ""]))], null, (function(t, e) {
                    t(e, 1, 0, l.yb(1, "s2w-results-table__ball-number s2w-results-table__ball-number--", e.parent.context.data.events[0].result.finalOutcome[0], "")), t(e, 2, 0, e.parent.context.data.events[0].result.finalOutcome[0])
                }))
            }

            function ne(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 0, "span", [
                    ["class", "icon icon-star-full"]
                ], null, null, null, null, null))], null, null)
            }

            function le(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 1, "span", [], [
                    [8, "className", 0]
                ], null, null, null, null)), (t()(), l.Nb(1, null, ["", ""]))], null, (function(t, e) {
                    t(e, 0, 0, l.yb(1, "s2w-results-table__ball-number s2w-results-table__ball-number--", e.parent.context.data.events[0].result.finalOutcome[1], "")), t(e, 1, 0, e.parent.context.data.events[0].result.finalOutcome[1])
                }))
            }

            function re(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 0, "span", [
                    ["class", "icon icon-star-full"]
                ], null, null, null, null, null))], null, null)
            }

            function ae(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 8, "div", [
                    ["class", "s2w-results-table"]
                ], null, null, null, null, null)), (t()(), l.ub(1, 0, null, null, 3, "div", [], [
                    [8, "className", 0]
                ], null, null, null, null)), (t()(), l.jb(16777216, null, null, 1, null, ee)), l.tb(3, 16384, null, 0, R.l, [l.R, l.O], {
                    ngIf: [0, "ngIf"],
                    ngIfElse: [1, "ngIfElse"]
                }, null), (t()(), l.jb(0, [
                    ["star", 2]
                ], null, 0, null, ne)), (t()(), l.ub(5, 0, null, null, 3, "div", [], [
                    [8, "className", 0]
                ], null, null, null, null)), (t()(), l.jb(16777216, null, null, 1, null, le)), l.tb(7, 16384, null, 0, R.l, [l.R, l.O], {
                    ngIf: [0, "ngIf"],
                    ngIfElse: [1, "ngIfElse"]
                }, null), (t()(), l.jb(0, [
                    ["star", 2]
                ], null, 0, null, re))], (function(t, e) {
                    t(e, 3, 0, "0" !== e.context.data.events[0].result.finalOutcome[0], l.Gb(e, 8)), t(e, 7, 0, "0" !== e.context.data.events[0].result.finalOutcome[1], l.Gb(e, 8))
                }), (function(t, e) {
                    var n = e.component;
                    t(e, 1, 0, l.yb(1, "s2w-results-table__ball s2w-results-table__ball--", n.getColor(n.S2wWheelType.WHEEL36, e.context.data.events[0].result.finalOutcome[0]), "")), t(e, 5, 0, l.yb(1, "s2w-results-table__ball s2w-results-table__ball--", n.getColor(n.S2wWheelType.WHEEL18, e.context.data.events[0].result.finalOutcome[1]), ""))
                }))
            }

            function ie(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 3, "div", [
                    ["class", "s2w-results-table__event"]
                ], null, null, null, null, null)), (t()(), l.Nb(1, null, [" ", " - ", " "])), l.Hb(131072, S.i, [S.j, l.i]), l.Hb(131072, S.i, [S.j, l.i])], null, (function(t, e) {
                    var n = e.component;
                    t(e, 1, 0, l.Ob(e, 1, 0, l.Gb(e, 2).transform(n.getWonOdd36(e.context.$implicit, e.parent.context.templateData))), l.Ob(e, 1, 1, l.Gb(e, 3).transform(n.getWonOdd18(e.context.$implicit, e.parent.context.templateData))))
                }))
            }

            function ue(t) {
                return l.Pb(0, [(t()(), l.jb(16777216, null, null, 1, null, ie)), l.tb(1, 278528, null, 0, R.k, [l.R, l.O, l.u], {
                    ngForOf: [0, "ngForOf"]
                }, null), (t()(), l.jb(0, null, null, 0))], (function(t, e) {
                    t(e, 1, 0, e.context.data.events)
                }), null)
            }

            function oe(t) {
                return l.Pb(2, [l.Lb(671088640, 1, {
                    resultsTemplate: 0
                }), l.Lb(671088640, 2, {
                    wonMarketTemplate: 0
                }), (t()(), l.ub(2, 0, null, null, 1, "grsa-table", [
                    ["class", "s2w-results"]
                ], [
                    [2, "table", null]
                ], null, null, bt.b, bt.a)), l.tb(3, 4308992, null, 0, a.c, [l.i, l.l], {
                    columns: [0, "columns"],
                    rows: [1, "rows"]
                }, null), (t()(), l.jb(0, [
                    [1, 2],
                    ["resultsTemplate", 2]
                ], null, 0, null, ae)), (t()(), l.jb(0, [
                    [2, 2],
                    ["wonMarketTemplate", 2]
                ], null, 0, null, ue))], (function(t, e) {
                    var n = e.component;
                    t(e, 3, 0, n.columns, n.eventBlocks)
                }), (function(t, e) {
                    t(e, 2, 0, l.Gb(e, 3).clazz)
                }))
            }

            function se(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 1, "grsa-s2w-results-table", [], null, null, null, oe, te)), l.tb(1, 114688, null, 0, v, [S.j], null, null)], (function(t, e) {
                    t(e, 1, 0)
                }), null)
            }
            var ce = l.qb("grsa-s2w-results-table", v, se, {
                    eventBlocks: "eventBlocks"
                }, {}, []),
                pe = l.sb({
                    encapsulation: 0,
                    styles: [
                        [""]
                    ],
                    data: {}
                });

            function be(t) {
                return l.Pb(0, [(t()(), l.Nb(0, null, [" ", "\n"]))], null, (function(t, e) {
                    var n = e.context.data.events[0].result.finalOutcome.join(" - ");
                    t(e, 0, 0, n)
                }))
            }

            function ge(t) {
                return l.Pb(2, [l.Lb(402653184, 1, {
                    resultsTemplate: 0
                }), (t()(), l.ub(1, 0, null, null, 1, "grsa-table", [], [
                    [2, "table", null]
                ], null, null, bt.b, bt.a)), l.tb(2, 4308992, null, 0, a.c, [l.i, l.l], {
                    columns: [0, "columns"],
                    rows: [1, "rows"]
                }, null), (t()(), l.jb(0, [
                    [1, 2],
                    ["resultsTemplate", 2]
                ], null, 0, null, be))], (function(t, e) {
                    var n = e.component;
                    t(e, 2, 0, n.columns, n.eventBlocks)
                }), (function(t, e) {
                    t(e, 1, 0, l.Gb(e, 2).clazz)
                }))
            }

            function me(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 1, "grsa-default-results-table", [], null, null, null, ge, pe)), l.tb(1, 114688, null, 0, b, [S.j], null, null)], (function(t, e) {
                    t(e, 1, 0)
                }), null)
            }
            var fe = l.qb("grsa-default-results-table", b, me, {
                    eventBlocks: "eventBlocks"
                }, {}, []),
                de = l.sb({
                    encapsulation: 0,
                    styles: [
                        [".gl-results-table__event[_ngcontent-%COMP%]{line-height:24px}"]
                    ],
                    data: {}
                });

            function he(t) {
                return l.Pb(0, [(t()(), l.Nb(0, null, [" ", "\n"]))], null, (function(t, e) {
                    var n = e.context.data.events[0].result.finalOutcome.join(" - ");
                    t(e, 0, 0, n)
                }))
            }

            function ve(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 1, null, null, null, null, null, null, null)), (t()(), l.Nb(-1, null, [","]))], null, null)
            }

            function _e(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 3, "span", [], null, null, null, null, null)), (t()(), l.Nb(1, null, [" ", " "])), (t()(), l.jb(16777216, null, null, 1, null, ve)), l.tb(3, 16384, null, 0, R.l, [l.R, l.O], {
                    ngIf: [0, "ngIf"]
                }, null)], (function(t, e) {
                    t(e, 3, 0, !e.parent.context.last)
                }), (function(t, e) {
                    t(e, 1, 0, e.parent.context.$implicit.oddId)
                }))
            }

            function ye(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 1, "span", [], null, null, null, null, null)), (t()(), l.Nb(1, null, [" ", " "]))], null, (function(t, e) {
                    t(e, 1, 0, e.component.getBetParam(e.parent.parent.context.data.events[0], e.parent.parent.context.templateData))
                }))
            }

            function Oe(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 4, null, null, null, null, null, null, null)), (t()(), l.jb(16777216, null, null, 1, null, _e)), l.tb(2, 16384, null, 0, R.l, [l.R, l.O], {
                    ngIf: [0, "ngIf"]
                }, null), (t()(), l.jb(16777216, null, null, 1, null, ye)), l.tb(4, 16384, null, 0, R.l, [l.R, l.O], {
                    ngIf: [0, "ngIf"]
                }, null), (t()(), l.jb(0, null, null, 0))], (function(t, e) {
                    t(e, 2, 0, "round" !== e.parent.context.templateData), t(e, 4, 0, "round" === e.parent.context.templateData)
                }), null)
            }

            function Te(t) {
                return l.Pb(0, [(t()(), l.jb(16777216, null, null, 1, null, Oe)), l.tb(1, 278528, null, 0, R.k, [l.R, l.O, l.u], {
                    ngForOf: [0, "ngForOf"]
                }, null), (t()(), l.jb(0, null, null, 0))], (function(t, e) {
                    t(e, 1, 0, e.component.getWonOdds(e.context.data.events[0], e.context.templateData))
                }), null)
            }

            function Ce(t) {
                return l.Pb(0, [(t()(), l.Nb(0, null, [" ", "\n"]))], null, (function(t, e) {
                    var n = e.context.data.events[0].result.finalOutcome.join(",");
                    t(e, 0, 0, n)
                }))
            }

            function we(t) {
                return l.Pb(2, [l.Lb(402653184, 1, {
                    resultsTemplate: 0
                }), l.Lb(402653184, 2, {
                    wonMarketTemplate: 0
                }), l.Lb(402653184, 3, {
                    trifectaTemplate: 0
                }), (t()(), l.ub(3, 0, null, null, 1, "grsa-table", [], [
                    [2, "table", null]
                ], null, null, bt.b, bt.a)), l.tb(4, 4308992, null, 0, a.c, [l.i, l.l], {
                    columns: [0, "columns"],
                    rows: [1, "rows"]
                }, null), (t()(), l.jb(0, [
                    [1, 2],
                    ["resultsTemplate", 2]
                ], null, 0, null, he)), (t()(), l.jb(0, [
                    [2, 2],
                    ["wonMarketTemplate", 2]
                ], null, 0, null, Te)), (t()(), l.jb(0, [
                    [3, 2],
                    ["withoutSpaceTemplate", 2]
                ], null, 0, null, Ce))], (function(t, e) {
                    var n = e.component;
                    t(e, 4, 0, n.columns, n.eventBlocks)
                }), (function(t, e) {
                    t(e, 3, 0, l.Gb(e, 4).clazz)
                }))
            }

            function ke(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 1, "grsa-mma-results-table", [], null, null, null, we, de)), l.tb(1, 638976, null, 0, O, [S.j], null, null)], (function(t, e) {
                    t(e, 1, 0)
                }), null)
            }
            var Me = l.qb("grsa-mma-results-table", O, ke, {
                    eventBlocks: "eventBlocks"
                }, {}, []),
                Pe = n("7x4Y");
            n.d(e, "ResultsModuleNgFactory", (function() {
                return Se
            }));
            var Se = l.rb(C, [], (function(t) {
                return l.Db([l.Eb(512, l.k, l.cb, [
                    [8, [w.a, k.a, st, yt, St, Wt, zt, Zt, ce, fe, Me]],
                    [3, l.k], l.z
                ]), l.Eb(4608, R.n, R.m, [l.w, [2, R.A]]), l.Eb(4608, X.a, X.a, [l.g, l.s, l.k]), l.Eb(4608, $, $, [l.v, l.k]), l.Eb(5120, z, K, []), l.Eb(4608, V, V, [l.s]), l.Eb(1073742336, R.b, R.b, []), l.Eb(1073742336, et.p, et.p, [
                    [2, et.u],
                    [2, et.l]
                ]), l.Eb(1073742336, Y, Y, []), l.Eb(1073742336, S.g, S.g, []), l.Eb(1073742336, Pe.a, Pe.a, []), l.Eb(1073742336, C, C, []), l.Eb(1024, et.j, (function() {
                    return [
                        [{
                            path: "",
                            component: tt
                        }]
                    ]
                }), []), l.Eb(256, E, q, []), l.Eb(256, Z, T, [])])
            }))
        },
        kmhj: function(t, e, n) {
            "use strict";
            var l = n("CcnG"),
                r = n("5EE+"),
                a = n("Ip0R"),
                i = n("UtUQ"),
                u = l.sb({
                    encapsulation: 0,
                    styles: [
                        [".table-cell[_nghost-%COMP%]{display:table-cell;padding:15px 10px;font-size:16px;color:#373a3c;border:1px solid #c9c9c9}.table-cell--left[_nghost-%COMP%]{text-align:left}.table-cell--center[_nghost-%COMP%]{text-align:center}.table-cell--right[_nghost-%COMP%]{text-align:right}.table-cell--top[_nghost-%COMP%]{vertical-align:top}.table-cell--middle[_nghost-%COMP%]{vertical-align:middle}.table-cell--bottom[_nghost-%COMP%]{vertical-align:bottom}.table-cell--spanned[_nghost-%COMP%]{border-right:0;border-left:0}.table-cell--white-space-pre[_nghost-%COMP%]{white-space:pre}"]
                    ],
                    data: {}
                });

            function o(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 3, "span", [], null, null, null, null, null)), (t()(), l.Nb(1, null, ["", ""])), l.Jb(2, 1), l.Hb(131072, r.i, [r.j, l.i])], null, (function(t, e) {
                    var n = e.component,
                        r = l.Ob(e, 1, 0, l.Gb(e, 3).transform(l.Ob(e, 1, 0, t(e, 2, 0, l.Gb(e.parent.parent, 0), n.tag + n.text))));
                    t(e, 1, 0, r)
                }))
            }

            function s(t) {
                return l.Pb(0, [(t()(), l.Nb(0, null, ["", ""]))], null, (function(t, e) {
                    t(e, 0, 0, e.component.text)
                }))
            }

            function c(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 3, null, null, null, null, null, null, null)), (t()(), l.jb(16777216, null, null, 1, null, o)), l.tb(2, 16384, null, 0, a.l, [l.R, l.O], {
                    ngIf: [0, "ngIf"],
                    ngIfElse: [1, "ngIfElse"]
                }, null), (t()(), l.jb(0, [
                    ["withoutTagTemplate", 2]
                ], null, 0, null, s))], (function(t, e) {
                    t(e, 2, 0, e.component.hasTag, l.Gb(e, 3))
                }), null)
            }

            function p(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 1, null, null, null, null, null, null, null)), (t()(), l.Nb(1, null, [" ", " "]))], null, (function(t, e) {
                    t(e, 1, 0, e.component.definition.title)
                }))
            }

            function b(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 1, null, null, null, null, null, null, null)), (t()(), l.Nb(1, null, [" ", ""]))], null, (function(t, e) {
                    t(e, 1, 0, e.component.text)
                }))
            }

            function g(t) {
                return l.Pb(0, [(t()(), l.jb(0, null, null, 0))], null, null)
            }

            function m(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 3, null, null, null, null, null, null, null)), (t()(), l.jb(16777216, null, null, 2, null, g)), l.tb(2, 540672, null, 0, a.r, [l.R], {
                    ngTemplateOutletContext: [0, "ngTemplateOutletContext"],
                    ngTemplateOutlet: [1, "ngTemplateOutlet"]
                }, null), l.Ib(3, {
                    data: 0,
                    templateData: 1,
                    index: 2
                }), (t()(), l.jb(0, null, null, 0))], (function(t, e) {
                    var n = e.component,
                        l = t(e, 3, 0, n.data, n.definition.templateData, n.index);
                    t(e, 2, 0, l, n.definition.templateRef)
                }), null)
            }

            function f(t) {
                return l.Pb(2, [l.Hb(0, a.h, []), (t()(), l.ub(1, 0, null, null, 9, null, null, null, null, null, null, null)), l.tb(2, 16384, null, 0, a.o, [], {
                    ngSwitch: [0, "ngSwitch"]
                }, null), (t()(), l.jb(16777216, null, null, 1, null, c)), l.tb(4, 278528, null, 0, a.p, [l.R, l.O, a.o], {
                    ngSwitchCase: [0, "ngSwitchCase"]
                }, null), (t()(), l.jb(16777216, null, null, 1, null, p)), l.tb(6, 278528, null, 0, a.p, [l.R, l.O, a.o], {
                    ngSwitchCase: [0, "ngSwitchCase"]
                }, null), (t()(), l.jb(16777216, null, null, 1, null, b)), l.tb(8, 278528, null, 0, a.p, [l.R, l.O, a.o], {
                    ngSwitchCase: [0, "ngSwitchCase"]
                }, null), (t()(), l.jb(16777216, null, null, 1, null, m)), l.tb(10, 278528, null, 0, a.p, [l.R, l.O, a.o], {
                    ngSwitchCase: [0, "ngSwitchCase"]
                }, null)], (function(t, e) {
                    t(e, 2, 0, e.component.template), t(e, 4, 0, "textTemplate"), t(e, 6, 0, "titleTemplate"), t(e, 8, 0, "dateTemplate"), t(e, 10, 0, "templateRefTemplate")
                }), null)
            }
            n("9pw4"), n.d(e, "a", (function() {
                return d
            })), n.d(e, "b", (function() {
                return y
            }));
            var d = l.sb({
                encapsulation: 0,
                styles: [
                    [".table[_nghost-%COMP%]{display:table;margin-bottom:20px;border-collapse:collapse;background-color:#fffffe;width:100%}.table__header[_ngcontent-%COMP%]{display:table-header-group}.table__header[_ngcontent-%COMP%]     .table-cell{padding:10px;font-weight:700;color:#274a5c;background-color:#f9faf9}.table__body[_ngcontent-%COMP%]{display:table-row-group}.table-row[_ngcontent-%COMP%]{display:table-row;width:100%}"]
                ],
                data: {}
            });

            function h(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 1, "grsa-table-cell", [], [
                    [8, "className", 0],
                    [2, "table-cell", null]
                ], null, null, f, u)), l.tb(1, 114688, null, 0, i.a, [], {
                    definition: [0, "definition"]
                }, null)], (function(t, e) {
                    t(e, 1, 0, e.context.$implicit)
                }), (function(t, e) {
                    t(e, 0, 0, l.Gb(e, 1).classes, l.Gb(e, 1).clazz)
                }))
            }

            function v(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 1, "grsa-table-cell", [], [
                    [4, "min-width", "px"],
                    [8, "className", 0],
                    [2, "table-cell", null]
                ], null, null, f, u)), l.tb(1, 114688, null, 0, i.a, [], {
                    definition: [0, "definition"],
                    data: [1, "data"],
                    index: [2, "index"]
                }, null)], (function(t, e) {
                    t(e, 1, 0, e.context.$implicit, e.parent.context.$implicit, e.parent.context.index)
                }), (function(t, e) {
                    t(e, 0, 0, e.context.$implicit.width, l.Gb(e, 1).classes, l.Gb(e, 1).clazz)
                }))
            }

            function _(t) {
                return l.Pb(0, [(t()(), l.ub(0, 0, null, null, 2, "div", [
                    ["class", "table-row"]
                ], null, null, null, null, null)), (t()(), l.jb(16777216, null, null, 1, null, v)), l.tb(2, 278528, null, 0, a.k, [l.R, l.O, l.u], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(t, e) {
                    t(e, 2, 0, e.component.columns)
                }), null)
            }

            function y(t) {
                return l.Pb(2, [(t()(), l.ub(0, 0, null, null, 2, "div", [
                    ["class", "table__header"]
                ], null, null, null, null, null)), (t()(), l.jb(16777216, null, null, 1, null, h)), l.tb(2, 278528, null, 0, a.k, [l.R, l.O, l.u], {
                    ngForOf: [0, "ngForOf"]
                }, null), (t()(), l.ub(3, 0, null, null, 2, "div", [
                    ["class", "table__body"]
                ], null, null, null, null, null)), (t()(), l.jb(16777216, null, null, 1, null, _)), l.tb(5, 278528, null, 0, a.k, [l.R, l.O, l.u], {
                    ngForOf: [0, "ngForOf"]
                }, null)], (function(t, e) {
                    var n = e.component;
                    t(e, 2, 0, n.columns), t(e, 5, 0, n.rows)
                }), null)
            }
        }
    }
]);